package com.equifax.cms.fusion.test.INQpage;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.qapojos.PdlLayoutMasterPojo;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;

public class InqStatsView
{
    WebDriver driver;
    ProjectDashBoardPage ProjDashBoardPage;
    CommonMethods commMethods;
    OracleDBHelper oracleDB;

    public InqStatsView(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);

        // PageFactory.initElements(driver, this);
    }

    @Step("Shipping File Name in the Inq. stats")
    public String shFileInInqStats(String fileName)
    {
        String[] a = driver.findElement(By.xpath("//div[contains(text(),'" + fileName + "')]")).getText().trim().split(":");
        return a[1];
    }

    public boolean readDateFromFile(String path, String fieldName) throws SQLException, ParseException
    {
        PdlLayoutMasterPojo pdlPojo = new PdlLayoutMasterPojo();
        oracleDB = new OracleDBHelper();
        oracleDB.getConnection();
        pdlPojo = oracleDB.getStartEndPosFromPdlPurpose("INQUIRY_POSTING", fieldName);
        SimpleDateFormat format = new SimpleDateFormat("mm/dd/yyyy");
        boolean flag = false;

        try
        {

            File file = new File(path);

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);
            String sCurrentLine;
            while ((sCurrentLine = br.readLine()) != null)
            {
                int startposition = pdlPojo.getStartPos();
                int endPosition = pdlPojo.getEndPos();
                int finalPosition = startposition + endPosition;
                System.out.println("the current line is" + sCurrentLine);
                String fieldArray = sCurrentLine.substring(startposition, finalPosition - 1);
                try
                {
                    format.parse(fieldArray);
                    return true;
                } catch (ParseException e)
                {
                    return false;
                }

            }
            br.close();

        } catch (IOException e)
        {
            e.printStackTrace();
        }

        return flag;
    }

    @Step("Shipped File under Inquiry GpExport Section")
    public String getShippedFileName()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Shipped File')]")).getText();
    }

    @Step("Shipped File under Inquiry GpExport Section")
    public String getShippedFileRecCount()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Shipped File')]/following::div[1]")).getText();
    }

    public String getInqGpExportFileLocation()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Records Written To')]")).getText();
    }

    public List<String> checkWokItemsCreatedForParticularProcess(String process)
    {

        String rowId = driver.findElement(By.xpath("//*[@id='tablejob-tree']/tbody/tr[1]")).getAttribute("data-key");
        rowId = rowId.split("(?<=\\D)(?=\\d)")[1];
        return getListOfWorkItemsWithSameDataKey(rowId);
    }

    public void moveToUsedInputProcessStats(String processToExpand)
    {
        List<String> dataKeys = new ArrayList<>();
        Map<String, String> map = new HashMap<>();
        List<WebElement> rowsInfo = driver.findElements(By.xpath("//table[@id='tablejob-tree']/tbody/tr"));
        for (WebElement ele : rowsInfo)
        {
            String dataKey = ele.getAttribute("data-key");
            dataKeys.add(dataKey);
        }

        int i = 0;
        while (i < dataKeys.size())
        {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            Object rowsInfo1 = js.executeScript("return $('#job-tree').jqxTreeGrid('getRow','" + dataKeys.get(i) + "')");
            map = (Map<String, String>) rowsInfo1;
            String rowId = null;

            String row = rowsInfo1.toString();

            rowId = getUid(row);
            if (rowId.equalsIgnoreCase(processToExpand))
            {
                js.executeScript("$('#job-tree').jqxTreeGrid('ensureRowVisible', '" + dataKeys.get(i) + "')");
                break;
            }

            i++;
        }

    }

    private String getUid(String row)
    {
        String uidVal;
        String[] strSplit = row.split(",");
        uidVal = strSplit[20].substring(strSplit[20].indexOf("name") + 4).trim();
        System.out.println("uidVal" + uidVal + ":Rowinfo:" + row);
        uidVal = uidVal.substring(1, uidVal.length());
        return uidVal;
    }

    public List<String> getListOfWorkItemsWithSameDataKey(String rowId)
    {
        List<WebElement> elements = new ArrayList<>();
        List<WebElement> spanList = new ArrayList<>();
        List<String> finalList = new ArrayList<>();
        elements = driver.findElements(By.xpath("//*[@id='tablejob-tree']/tbody/tr"));
        for (int i = 2; i < elements.size(); i++)
        {

            String id = elements.get(i).getAttribute("id");
            String keyVal = elements.get(i).getAttribute("data-key");
            if (keyVal.contains(rowId))
            {
                spanList = driver.findElements(By.xpath("//tr[@id='" + id + "']/td[2]/span"));

                String text = spanList.get(4).getText();
                finalList.add(text);

            }
        }
        return finalList;
    }

    public void collapseWorkItems(String pName)
    {
        driver.findElement(By.xpath("//span[contains(text(),'" + pName + "')]/preceding::span[1]")).click();
    }
}

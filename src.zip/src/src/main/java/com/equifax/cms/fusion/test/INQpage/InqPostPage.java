package com.equifax.cms.fusion.test.INQpage;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapojos.PdlLayoutMasterPojo;

public class InqPostPage
{

    WebDriver driver;
    PdlLayoutMasterPojo pdlPojo;

    public InqPostPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(10000, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//span[contains(text(),'IQ')]")
    WebElement ProcessId;

    @FindBy(id = "processName")
    WebElement ProcessNameField;

    @FindBy(id = "isTestOnly1")
    WebElement Yes_Rbtn;

    @FindBy(id = "isTestOnly2")
    WebElement No_Rbtn;

    @FindBy(id = "mainPostingType1")
    WebElement NetDown_Rbtn;

    @FindBy(id = "mainPostingType2")
    WebElement ShipPopulation_Rbtn;

    @FindBy(id = "mainPostingType3")
    WebElement NoInq_Rbtn;

    @FindBy(xpath = "//div[@id='shippedDateDiv']/img")
    WebElement calender_Btn;

    @FindBy(xpath = ".//*[@id='inquiryInputDiv']/div[6]/div[3]/div[2]/div[3]/img")
    WebElement PostInfo_Calender_Btn;

    @FindBy(id = "fromProcessId")
    WebElement Process_Fld;

    @FindBy(id = "jobId")
    WebElement Job_Fld;

    @FindBy(id = "itemTableId")
    public WebElement Data_Fld;

    @FindBy(id = "sourceProcessId")
    WebElement ShProc_drpDwn;

    @FindBy(id = "sourceJobId")
    WebElement ShJob_DrpDwn;

    @FindBy(id = "project_sel1")
    WebElement Current_Rbtn;

    @FindBy(id = "project_sel2")
    WebElement PrjSrcField_Rbtn;

    @FindBy(id = "infoProjectNumberCol")
    WebElement PrjSrcField_DrpDown;

    @FindBy(id = "member_sel1")
    WebElement Member_Rbtn;

    @FindBy(id = "member_sel2")
    WebElement MemSrcField_Rbtn;

    @FindBy(id = "infoMemberNumber")
    WebElement MemField;

    @FindBy(id = "infoMemberNumberCol")
    WebElement MemSrcField_DrpDown;

    @FindBy(id = "type_sel1")
    WebElement Type_Rbtn;

    @FindBy(id = "infoInquiryType")
    WebElement Type_DrpDown;

    @FindBy(id = "type_sel2")
    WebElement TypeSrcField_Rbtn;

    @FindBy(id = "infoInquiryTypeCol")
    WebElement TypeSrcField_DrpDown;

    @FindBy(id = "date_sel1")
    public WebElement CreditFile_Rbtn;

    @FindBy(id = "date_sel3")
    public WebElement Date_Rbtn;

    @FindBy(xpath = "(//input[@id='date_sel3']/following::img)[1]")
    WebElement Date_DateImg;

    @FindBy(id = "date_sel2")
    WebElement DateSrcFld_Rbtn;

    @FindBy(id = "infoPostingMonthCol")
    WebElement Month_DrpDown;

    @FindBy(id = "infoPostingDateCol")
    WebElement Day_DrpDown;

    @FindBy(id = "infoPostingCenturyCol")
    WebElement Century_DrpDown;

    @FindBy(id = "infoPostingYearCol")
    WebElement Year_DrpDown;

    @FindBy(id = "customerId")
    public WebElement NCcust_Id;

    @FindBy(id = "Save")
    WebElement Save_Btn;

    @FindBy(id = "shippedDate")
    WebElement shipped_date;

    @FindBy(xpath = "//a[contains(text(),'<< Back')]")
    WebElement BackBtn;

    @FindBy(id = "Submit")
    WebElement Submit_Btn;

    @Step("Process Name field = \"{0}\"")
    public void processNameField(String procName)
    {
        ProcessNameField.clear();
        ProcessNameField.sendKeys(procName);
    }

    @Step("Click Test Only Radio Button")
    public void selectTestOnly(String testOnly)
    {
        if (testOnly.equalsIgnoreCase("Yes"))
        {
            Yes_Rbtn.click();
        } else if (testOnly.equalsIgnoreCase("No"))
        {
            No_Rbtn.click();
        } else
        {
            System.out.println("Provide proper information in the input data sheet !!!");
        }
    }

    @Step("set date when Net Down")
    public void selectDateForNetDown(String month, String day, String year)
    {
        int targetDay = Integer.valueOf(day), targetMonth = Integer.valueOf(month), targetYear = Integer.valueOf(year);
        boolean increment = true;

        String dateToSet = day + "/" + month + "/" + year;

        // getCurrentDayMonth();

        getTargetDayMonthYear(dateToSet, targetDay, targetMonth, targetYear);

        int jumMonthBy = calculateMonthsToJump(month, day, year);

        System.out.println(increment);

        calender_Btn.click();

        for (int i = 0; i < jumMonthBy; i++)
        {
            if (increment)
            {
                driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
            } else
            {
                driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
            }
            // Thread.sleep(1000);
        }

        driver.findElement(By.linkText(Integer.toString(targetDay))).click();

    }

    @Step("set date when Net Down")
    public void selectDateForShippedPop(String month, String day, String year)
    {
        int targetDay = Integer.valueOf(day), targetMonth = Integer.valueOf(month), targetYear = Integer.valueOf(year);
        boolean increment = true;
        String dateToSet = day + "/" + month + "/" + year;

        getCurrentDayMonth();

        getTargetDayMonthYear(dateToSet, targetDay, targetMonth, targetYear);

        int jumMonthBy = calculateMonthsToJump(month, day, year);
        // System.out.println(jumMonthBy);
        System.out.println(increment);

        Date_DateImg.click();

        for (int i = 0; i < jumMonthBy; i++)
        {
            if (increment)
            {
                driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
            } else
            {
                driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[1]/span")).click();
            }
            // Thread.sleep(1000);
        }

        driver.findElement(By.linkText(Integer.toString(targetDay))).click();

    }

    @Step("View Stats for submitted net down inq")
    public void viewNetDownInqStats(String processName)
    {
        driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[contains(text(),'" + processName + "')]//following::td[5]/a"))
                .click();
    }

    @Step("Select Net Down field")
    public void selectNetDown()
    {
        NetDown_Rbtn.click();
    }

    @Step("Select Shipped Population field")
    public void selectShipPopulation()
    {
        ShipPopulation_Rbtn.click();
    }

    @Step("Select No Inquiries field")
    public void selectNoInq()
    {
        NoInq_Rbtn.click();
    }

    @Step("Clicked on Shipped Date image")
    public void clickShDateImg()
    {
        calender_Btn.click();
    }

    @Step("Clicked Posting Information Shipped Date image")
    public void clickPostInfDateImg()
    {
        PostInfo_Calender_Btn.click();
    }

    @Step("Select the Shipped Date = \"{0}\" \"{1}\" \"{2}\"")
    public void selectDate() throws InterruptedException
    {
        clickShDateImg();
        String day = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
        System.out.println("day : " + day);
        int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        if (day.startsWith("0"))
        {
            driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();

        } else
        {
            driver.findElement(By.xpath("(//a[contains(text(), '" + day + "')])[1]")).click();
        }
    }

    public static String getCurrentDayMonth()
    {

        int currenttDate = 0, currenttMonth = 0, currenttYear = 0;
        Calendar cal = Calendar.getInstance();
        currenttDate = cal.get(Calendar.DAY_OF_MONTH);
        currenttMonth = cal.get(Calendar.MONTH) + 1;
        currenttYear = cal.get(Calendar.YEAR);
        String date = String.valueOf(currenttDate) + "," + String.valueOf(currenttMonth) + "," + String.valueOf(currenttYear);
        return date;
    }

    public static void getTargetDayMonthYear(String dateString, int targetDay, int targetMonth, int targetYear)
    {

        int firstIndex = dateString.indexOf("/");
        int lastIndex = dateString.lastIndexOf("/");

        String day = dateString.substring(0, firstIndex);
        targetDay = Integer.parseInt(day);

        String month = dateString.substring(firstIndex + 1, lastIndex);
        targetMonth = Integer.parseInt(month);

        String year = dateString.substring(lastIndex + 1, dateString.length());
        targetYear = Integer.parseInt(year);

    }

    public static int calculateMonthsToJump(String month, String day, String year)
    {
        String currentDate = getCurrentDayMonth();
        int targetDay = Integer.valueOf(day), targetMonth = Integer.valueOf(month), targetYear = Integer.valueOf(year);
        boolean increment = true;
        int jumMonthBy = 0;
        int cmpcurrenttDate = Integer.valueOf(currentDate.split(",")[0]), currenttMonth = Integer.valueOf(currentDate.split(",")[1]), currenttYear = Integer
                .valueOf(currentDate.split(",")[2]);

        if (targetMonth - currenttMonth > 0)
        {
            jumMonthBy = targetMonth - currenttMonth;

        } else
        {
            jumMonthBy = currenttMonth - targetMonth;
            increment = false;
        }
        return jumMonthBy;
    }

    @Step("Select the Shipped Date = \"{0}\" \"{1}\" \"{2}\"")
    public void selectDateForNoInq() throws InterruptedException
    {
        Thread.sleep(5000);
        calender_Btn.click();
        driver.findElement(By.linkText("17")).click();

    }

    @Step("Select Process Field = \"{0}\"")
    public void selectProcessField(String proc)
    {
        String delim = ",";
        StringTokenizer st = new StringTokenizer(proc, delim);
        Select sel = new Select(Process_Fld);
        while (st.hasMoreTokens())
        {
            sel.selectByVisibleText(st.nextToken());
        }
    }

    @Step("Select Job Field = \"{0}\"")
    public void selectJobField(String job)
    {
        Select sl = new Select(Job_Fld);
        sl.selectByVisibleText(job);
    }

    @Step("Select Data Field = \"{0}\"")
    public void selectDataField(String data)
    {
        Select sl = new Select(Data_Fld);
        sl.selectByVisibleText(data);
    }

    @Step("Selected the Shipped Process Field = \"{0}\"")
    public void selShFldDrpDwn(String shProc)
    {
        Select sel = new Select(ShProc_drpDwn);
        sel.selectByVisibleText(shProc);
    }

    @Step("Selected the Shipped Job Field = \"{0}\"")
    public void selShJobDrpDwn(String job)
    {
        Select sel = new Select(ShJob_DrpDwn);
        sel.selectByVisibleText(job);
    }

    public List<String> getDataFlds()
    {
        List<String> currentOptions = new ArrayList<>();
        List<WebElement> matches = Data_Fld.findElements(By.tagName("option"));
        for (WebElement match : matches)
        {
            currentOptions.add(match.getText());
        }
        return currentOptions;
    }

    @Step("Select the Project # Fields = \"{0}\"")
    public void selectProjectOpt(String project, String value)
    {
        if ("Current".equalsIgnoreCase(project))
        {
            // Current_Rbtn.click();

        } else if ("Src_Field".equalsIgnoreCase(project))
        {
            PrjSrcField_Rbtn.click();
            Select sl = new Select(PrjSrcField_DrpDown);
            sl.selectByVisibleText(value);

        } else
        {
            System.out.println("Provide a proper input in the input Data sheet !!!");
        }
    }

    @Step("Select the Member # Fields = \"{0}\"")
    public void selectMemberOpt(String mem, String value)
    {
        if ("Member".equalsIgnoreCase(mem))
        {
            // Member_Rbtn.click();
            MemField.clear();
            MemField.sendKeys(value);

        } else if ("Src_Field".equalsIgnoreCase(mem))
        {
            MemSrcField_Rbtn.click();
            Select sl = new Select(MemSrcField_DrpDown);
            sl.selectByVisibleText(value);

        } else
        {
            System.out.println("Provide a proper input in the input Data sheet !!!");
        }
    }

    @Step("Select the Type Fields = \"{0}\"")
    public void selectTypeOptns(String typeFld, String value)
    {
        if ("Type".equalsIgnoreCase(typeFld))
        {
            Type_Rbtn.click();
            Select sl1 = new Select(Type_DrpDown);
            sl1.selectByVisibleText(value);

        } else if ("Src_Field".equalsIgnoreCase(typeFld))
        {
            TypeSrcField_Rbtn.click();
            Select sl2 = new Select(TypeSrcField_DrpDown);
            sl2.selectByVisibleText(value);

        } else
        {
            System.out.println("Provide a proper input in the input Data sheet !!!");
        }
    }

    @Step("Select the Date section options = \"{0}\" \"{1}\" \"{2}\" \"{3}\" \"{4}\"")
    public void selectDateOptnsforShippedFile(String date, String month, String day, String century, String year) throws InterruptedException
    {
        if ("Credit_File".equalsIgnoreCase(date))
        {
            CreditFile_Rbtn.click();

        } else if ("Date".equalsIgnoreCase(date))
        {
            Date_DateImg.click();
            Thread.sleep(1000);
            // driver.findElement(By.xpath("(.//*[@id='ui-datepicker-div']/table/tbody/tr/td[@data-year='"+year+"' AND
            // @data-month='"+month+"']/a[contains(text(),'"+day1+"')])")).click();
            // String day1 = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
            // System.out.println("day : " + day1);
            int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            if (day.startsWith("0"))
            {
                driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();
                // String a =(String) day.subSequence(1,1);
                // driver.findElement(By.xpath("//a[contains(text(), '"+a+"')]")).click();
            } else
            {
                driver.findElement(By.xpath("//a[contains(text(), '" + day + "')]")).click();
            }

        } else if ("Src_Field".equalsIgnoreCase(date))
        {
            DateSrcFld_Rbtn.click();
            Select mon = new Select(Month_DrpDown);
            mon.selectByVisibleText(month);
            Select day1 = new Select(Day_DrpDown);
            day1.selectByVisibleText(day);
            Select cen = new Select(Century_DrpDown);
            cen.selectByVisibleText(century);
            Select yr = new Select(Year_DrpDown);
            yr.selectByVisibleText(year);

        } else
        {
            System.out.println("Provide a proper input in the input Data sheet !!!");
        }
    }

    @Step("Select the Date section options = \"{0}\" \"{1}\" \"{2}\" \"{3}\" \"{4}\"")
    public void selectDateOptns(String date, String month, String day, String century, String year) throws InterruptedException
    {
        if ("Credit_File".equalsIgnoreCase(date))
        {
            CreditFile_Rbtn.click();

        } else if ("Date".equalsIgnoreCase(date))
        {
            Date_DateImg.click();
            Thread.sleep(1000);
            // driver.findElement(By.xpath("(.//*[@id='ui-datepicker-div']/table/tbody/tr/td[@data-year='"+year+"' AND
            // @data-month='"+month+"']/a[contains(text(),'"+day1+"')])")).click();
            String day1 = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
            System.out.println("day : " + day1);
            int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            if (day1.startsWith("0"))
            {
                driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day1.charAt(1))) - 1] + "']")).click();
                // String a =(String) day.subSequence(1,1);
                // driver.findElement(By.xpath("//a[contains(text(), '"+a+"')]")).click();
            } else
            {
                driver.findElement(By.xpath("//a[contains(text(), '" + day1 + "')]")).click();
            }

        } else if ("Src_Field".equalsIgnoreCase(date))
        {
            DateSrcFld_Rbtn.click();
            Select mon = new Select(Month_DrpDown);
            mon.selectByVisibleText(month);
            Select day1 = new Select(Day_DrpDown);
            day1.selectByVisibleText(day);
            Select cen = new Select(Century_DrpDown);
            cen.selectByVisibleText(century);
            Select yr = new Select(Year_DrpDown);
            yr.selectByVisibleText(year);

        } else
        {
            System.out.println("Provide a proper input in the input Data sheet !!!");
        }
    }

    @Step("Select the Data Sources = \"{0}\"")
    public void selectDataSrc(String fld)
    {

        String dataSrc[] = fld.split(",");
        int i = 0;
        while (i < dataSrc.length)
        {
            // driver.findElement(By.xpath("//input[@name='" + st.nextToken() + "DataSource']")).click();
            if ("Credit".equalsIgnoreCase(fld))
            {
                WebElement ele = driver.findElement(By.xpath("//input[@id='chkBoxDataSources1']"));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", ele);

                if (!driver.findElement(By.xpath("//input[@id='chkBoxDataSources1']")).isSelected())
                {
                    driver.findElement(By.xpath("//input[@id='chkBoxDataSources1']")).click();
                }
            }

            if ("NC+".equalsIgnoreCase(fld))
            {
                driver.findElement(By.xpath("//input[@id='chkBoxDataSources2']")).click();
            }

            if ("MLA".equalsIgnoreCase(fld))
            {
                driver.findElement(By.xpath("//input[@id='chkBoxDataSources3']")).click();
            }
            i++;
        }
    }

    @Step("Select the NC+ Customer ID # = \"{0}\" \"{1}\"")
    public void selectNCcustID(String srcData, String ncCustId)
    {
        if (srcData.contains("NC"))
        {
            Select nc = new Select(NCcust_Id);
            nc.selectByVisibleText(ncCustId);
        }
    }

    @Step("Save the process")
    public void clickSave()
    {
        Save_Btn.click();
    }

    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        BackBtn.click();
    }

    @Step("Submitted the process")
    public void clickSubmit()
    {
        Submit_Btn.click();
    }

    @Step
    public void clickGearBoxExpand()
    {
        WebElement ele = driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr[1]/td[2]/img)"));
        ele.click();
        driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr[2]/td[3]/img)")).click();
    }

    @Step
    public List<String> getArtifactNames(String selType)
    {
        List<String> artifactList = new ArrayList<>();

        if (!"No_Inq".equalsIgnoreCase(selType))
        {
            String artifact1 = driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr[3]/td[3])")).getText();
            String artifact2 = driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr[4]/td[3])")).getText();
            // String artifact3 = driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr[5]/td[3])")).getText();
            artifactList.add(artifact1);
            artifactList.add(artifact2);
            // artifactList.add(artifact3);
        }

        return artifactList;

    }

    @Step
    public String getFixedFilePathForInqGpExport()
    {
        String fixedFilePath = driver.findElement(By.xpath("//div[contains(text(),'INQ_GP_EXPORT')]//parent::div//parent::div//following::div[5]"))
                .getText();
        int a = fixedFilePath.indexOf('/');
        int b = fixedFilePath.indexOf(':');
        fixedFilePath = fixedFilePath.substring(a, b);
        fixedFilePath = fixedFilePath.trim();
        System.out.println("OutputTable Name : " + fixedFilePath);
        return fixedFilePath;
    }

    @Step
    public String getShippedDateValidationMessage()
    {

        WebElement ele = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/li/label"));
        String s1 = ele.getText();
        System.out.println("jkghdv" + s1);
        String s = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/li/label")).getText();
        return s;
    }

    // getInq Posting Xjob File path
    @Step
    public String getOutputPath()
    {
        String xjobFilePath = driver.findElement(By.xpath("//div[contains(text(),'Inquiry Posting Xjob Stat File Path')]//following-sibling::div"))
                .getText();
        // String s = driver.findElement(By.xpath("//*[@id='ResultTab']/div[1]/div[2]/div[5]/div[2]")).getText();
        return xjobFilePath;
    }

    // getInq Posting Xjob File path
    @Step
    public String getStatFileContent()
    {
        String xjobFilePath = driver.findElement(
                By.xpath("//div[contains(text(),'Inquiry Posting Xjob Stat File Content')]//following-sibling::div[1]/a[1]")).getText();
        // String s = driver.findElement(By.xpath("//*[@id='ResultTab']/div[1]/div[2]/div[5]/div[2]")).getText();
        return xjobFilePath;
    }

    @Step
    public void clickStatLink()
    {

        driver.findElement(By.xpath("//a[contains(text(),'STATS')]")).click();

    }

    public String statsContent()
    {
        return driver.findElement(By.xpath("//a[contains(text(),'STATS')]/following::div/div[2]")).getText();
    }

    @Step("Validate if output file dispalyed")
    public boolean isOutputFileDisplayed()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'/nas/a4data/AppData/InqPost')]")).isDisplayed();
    }

    @Step("Validate if inquiry accounting table inserted successfully")
    public String validateAccountingTableInsert()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'PROJECT ACCOUNTING')]/following::div[2]/div[1]")).getText();
    }

    @Step("Validate if distribution stats dispalyed")
    public boolean isDistributionStatsDisplayed()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Distribution Stats')]")).isDisplayed();
    }

    @Step("Fetch the Row Ids")
    public List<String> getTheRowIds(String assignedId)
    {
        List<String> rowId_List = new ArrayList<String>();
        String tr_Id_1 = driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr[1]//following::tr[2]")).getAttribute(
                "id");
        rowId_List.add(tr_Id_1);
        String tr_Id_2 = driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr[1]//following::tr[3]")).getAttribute(
                "id");
        rowId_List.add(tr_Id_2);
        String tr_Id_3 = driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr[1]//following::tr[4]")).getAttribute(
                "id");
        rowId_List.add(tr_Id_3);
        return rowId_List;
    }

    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

    public boolean isHomePageDisplayed()
    {
        boolean val = false;
        try
        {
            if (isElementPresent(By.xpath("//h3[@class='fusion-h3Title'][(text()='Inquiries')]")))
            {
                val = true;
            }
        } catch (Exception e)
        {
            return false;
        }
        return val;
    }
}

package com.equifax.cms.fusion.test.IPPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class IpStatsView
{
    WebDriver driver;
    ProjectDashBoardPage ProjDashBoardPage;
    CommonMethods commMethods;

    public IpStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[contains(text(),'ANALYZE Report')]")
    WebElement AnalyzeReport_Link;

    @FindBy(xpath = "//a[contains(text(),'COMPARE Report')]")
    WebElement CompareReport_Link;

    @Step("Fetched Output Table Name IP")
    public String getOutputTableNameIP()
    {
        // driver.switchTo().frame("sb-player");
        // String outputTableName = driver.findElement(By.xpath("//div[contains(text(),'Total number of records loaded')]")).getText();
        String outputTableName = driver.findElement(By.xpath("(//div[contains(text(),'Total number of records loaded')])[1]")).getText();
        // //div[contains(text(),'Total number of records loaded')][1]/following::div[2]
        int a = outputTableName.indexOf('[') + 1;
        System.out.println("Value of a is:" + a);
        int b = outputTableName.indexOf(']');
        System.out.println("Value of b is:" + b);
        outputTableName = outputTableName.substring(a, b);
        outputTableName = outputTableName.trim();
        System.out.println("OutputTable Name : " + outputTableName);
        return outputTableName;
    }

    @Step("Fetched IN_PREPARE filename")
    public String getInPrepareFileNameIP()
    {
        // String fileName = driver.findElement(By.xpath("//div[contains(text(), 'Revised File copied to location')]//following::div[2]")).getText();
        String fileName = driver.findElement(By.xpath("//div[contains(text(),'Revised File copied to location')]/following::div[2]/div[1]"))
                .getText();
        return fileName;
    }

    @Step("Get field counts")
    public String getFieldCountsDataTypesIP(int idNo)
    {
        // String fileCount = driver.findElement(By.xpath("html/body/div/div[1]/table[1]/tbody/tr[" + idNo + "]/td[2]")).getText();
        String fileCount = driver.findElement(By.xpath("//th[contains(text(),'Field Count')]/parent::tr/following::tr[1]/td[2]")).getText();
        return fileCount;
    }

    @Step("Get Analyze field names")
    public List<String> fieldsSelected(String[] fieldsInLayoutSplit)
    {
        List<String> fieldsSelected = new ArrayList<>();
        for (int i = 2; i <= fieldsInLayoutSplit.length; i++)
        {
            String fieldName = driver.findElement(By.xpath("//table[@id='details']/tbody/tr[2]/td")).getText();
            fieldsSelected.add(fieldName);
        }
        return fieldsSelected;
    }

    @Step("Get runtime values")
    public String getRunTimeValuesIP(int idNo)
    {
        // String runtimeVal = driver.findElement(By.xpath("html/body/div/div[1]/table/tbody/tr[2]/td[" + idNo + "]")).getText();

        String runTimeA = driver.findElement(By.xpath("//td[contains(text(),'Date/Time')]/following::td[1]")).getText();
        return runTimeA;
    }

    @Step("Get runtime values")
    public String getRunTimeValuesA()
    {
        String runTimeA = driver.findElement(By.xpath("//td[contains(text(),'Date/Time')]/following::td[1]")).getText();
        return runTimeA;
    }

    @Step("Get runtime values")
    public String getRunTimeValuesB()
    {
        String runTimeB = driver.findElement(By.xpath("//td[contains(text(),'Date/Time')]/following::td[2]")).getText();
        return runTimeB;
    }

    @Step("Fetched the Row Count IP")
    public Long getLastRowCountStatsIP() throws InterruptedException
    {
        // driver.switchTo().frame("sb-player");
        // String recCount = driver.findElement(By.xpath("//div[contains(text(),'Total number of records loaded')]//following::div[1]")).getText();
        String recCount = driver.findElement(By.xpath("//div[contains(text(),'Total number of records loaded')][1]/following::div[2]")).getText();
        // div[contains(text(),'Total number of records loaded')][1]/following::div[2]

        String a2 = "";
        if (recCount.contains(","))
        {
            String[] a1 = recCount.split(",");
            for (int i = 0; i < a1.length; i++)
            {
                a2 = a2 + a1[i];
                System.out.println(a2);
            }
            recCount = a2;
            System.out.println(recCount);
        }
        Long LongRecCount = Long.parseLong(recCount);
        System.out.println(LongRecCount);
        return LongRecCount;
    }

    @Step("Clicked Analyze Report link")
    public void clickAnalyzeReport()
    {
        driver.findElement(By.xpath("//div[contains(text(),'Data CheckANALYZE Report ')][1]/following-sibling::div[1]/a")).click();
    }

    @Step("Clicked Compare Report link")
    public void clickCompareReport()
    {
        driver.findElement(By.xpath("//div[contains(text(),'Data CheckCOMPARE Report ')][1]/following-sibling::div[1]/a")).click();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getConstantCountFromGP(String query, String constValue) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + query + " where constant = '" + constValue + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Column Names From Green Plum for Table = \"{0}\"")
    public List<String> getColumnNamesFromGP(String tableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> columnNames = new ArrayList<>();

        query1 = "select column_name from information_schema.columns where table_schema = 'fusion_stage' and upper(table_name) = '" + tableName + "'";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            columnNames.add(rs.getString(1));
        }
        conn.close();
        return columnNames;
    }

    public static String removeComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }
}

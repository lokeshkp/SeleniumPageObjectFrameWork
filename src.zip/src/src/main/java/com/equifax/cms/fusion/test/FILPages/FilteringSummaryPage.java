package com.equifax.cms.fusion.test.FILPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class FilteringSummaryPage
{
    WebDriver driver;
    public Select selType;

    public FilteringSummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    // id('inputSummaryTableSplit')/x:tbody/x:tr/x:td[3]
    // @FindBy(xpath = ".//*[@class='inputSummaryTableSplit']/tbody/tr/td[3]")
    @FindBy(xpath = ".//*[@class='greyBg odd']/td[3]")
    WebElement sumRange;

    @FindBy(xpath = "id('flForm')/x:span[1]")
    WebElement summProcName;

    @FindBy(xpath = "id('inputSummaryTableSplit')/x:tbody/x:tr/x:td[1]")
    WebElement procNameForTable;

    @FindBy(xpath = "id('inputSummaryTableSplit')/x:tbody/x:tr/x:td[2]")
    WebElement job;

    @FindBy(xpath = "id('inputSummaryTableSplit')/x:tbody/x:tr/x:td[3]")
    WebElement data;

    @FindBy(xpath = "id('inputSummaryTableSplit')/x:tbody/x:tr/x:td[4]")
    WebElement count;

    @FindBy(name = "submitButton")
    WebElement submit_Btn;

    @FindBy(id = "backButton")
    WebElement back_Btn;

    @Step("Get Range/value content from summary")
    public String getRangeValueContent()
    {
        return sumRange.getText();
    }

    @Step("Clicked Submit Button on Summary Page")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    @Step("Clicked Back Button on Summary Page")
    public void clickBack_Button()
    {
        back_Btn.click();
    }
    
    public String getProcessSelected() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Process')])[3]/following::tbody[1]/tr/td[1]")).getText();
    }
    
    public String getJobNoDisplayed() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Process')])[3]/following::tbody[1]/tr/td[2]")).getText();
    }
    
    public String getDataSelected() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Process')])[3]/following::tbody[1]/tr/td[3]")).getText();
    }
    
    
    
    public String getOutputTableNameProvided() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Output Table Name')])/following::table[1]/tbody/tr/td[2]/input[3]")).getAttribute("value");
    }
    
    public String getPerformCutsSelected() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Perform Cuts')])/following::span[1]")).getText();
    }
    
    public String getG1NameProvided() {
        String grpName = driver.findElement(By.xpath("(.//*[contains(text(),'Group 1')])")).getText();
        String[] arrGrpName = grpName.split(":");
        return arrGrpName[1].trim();
    }
    
    //(.//*[contains(text(),'Desired Output')])/following::text()
    
    public String getDesiredOutputCount() {
         String doc = driver.findElement(By.xpath(".//*[@class='summary-filter-desired']")).getText();
         String[] arrDoc = doc.split(":");
         return arrDoc[1].trim();
       
    }
    
    public String getFieldNameSelected() {
        String fieldName = driver.findElement(By.xpath("(.//*[contains(text(),'Field Name')])/following::tbody/tr/td[1]")).getText();
        String[] arrFieldName = fieldName.split(":");
        return arrFieldName[1].replace(",",".").trim();
    }
    public String getOperatorSelected() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Field Name')])/following::tbody/tr/td[2]")).getText();
    }
    public String getRangeValuesSelected() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Field Name')])/following::tbody/tr/td[3]")).getText();
    }
    
    public String getProcessIDSummary() 
    {
        String processName  = driver.findElement(By.xpath(".//*[@id='flForm']/span[1]")).getText();
        String[] arrProcessName = processName.split(":");
        return arrProcessName[0].trim();
    }

}

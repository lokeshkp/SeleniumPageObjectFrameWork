package com.equifax.cms.fusion.test.IZpages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class IZstats
{
    WebDriver driver;

    public IZstats(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//div[contains(text(),'ZIPCODE_EXPANDED_STATS')]")
    WebElement ZIPCODE_EXT_STATS;

    @FindBy(xpath = "//div[contains(text(),'State Totals')]")
    WebElement stateTotals;

    @Step("Get the name on Stats")
    public String jobStatsHeader()
    {
        String hdr = ZIPCODE_EXT_STATS.getText().trim();
        return hdr;
    }

    @Step("Get the heading for state totals on Stats")
    public String stateTotalHeader()
    {
        String hdr = stateTotals.getText().trim();
        return hdr;
    }

    @Step("Get state counts on Stats")
    public List<String> getStateCounts()
    {
        List<String> stateCounts = new ArrayList<>();

        List<WebElement> elements = driver.findElements(By.id("right-row"));

        for (int i = 2; i < elements.size(); i++)
        {
            stateCounts.add(elements.get(i).getText());
        }

        List<WebElement> elementsOdd = driver.findElements(By.id("right-rowOdd"));

        for (int i = 2; i < elementsOdd.size(); i++)
        {
            stateCounts.add(elementsOdd.get(i).getText());
        }

        return stateCounts;
    }

    @Step("Get state names on Stats")
    public List<String> getStateNames()
    {
        List<String> stateNames = new ArrayList<>();

        List<WebElement> elements = driver.findElements(By.id("left-child-child-row"));

        for (int i = 0; i < elements.size(); i++)
        {
            stateNames.add(elements.get(i).getText());
        }

        List<WebElement> elementsOdd = driver.findElements(By.id("left-child-child-rowOdd"));

        for (int i = 0; i < elementsOdd.size(); i++)
        {
            stateNames.add(elementsOdd.get(i).getText());
        }

        return stateNames;
    }

}

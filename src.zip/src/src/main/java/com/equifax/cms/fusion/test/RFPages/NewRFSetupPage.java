package com.equifax.cms.fusion.test.RFPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class NewRFSetupPage {

    WebDriver driver;

    public NewRFSetupPage(WebDriver driver){

        this.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//label[contains(text(), 'Process Name:')]/span")
    WebElement Ele_ProcessID;

    @FindBy(id = "name")
    WebElement Ele_ProcessName;

    @FindBy(id = "fromProcessId")
    WebElement Ele_Process;

    @FindBy(id = "itemTableId")
    WebElement Ele_Data;

    @FindBy(id = "hhdChk")
    WebElement Ele_Householding;

    @FindBy(id = "subOptionCode1")
    WebElement Ele_StandardHholding;

    @FindBy(id = "NHHDOptChk")
    WebElement Ele_NegativeHholdDrop;

    @FindBy(id = "HHDOptChk")
    WebElement Ele_HholdSplitRegHholdDrop;

    @FindBy(id = "subOptionCode2")
    WebElement Ele_CustomHholding;

    @FindBy(id = "options3.checked1")
    WebElement Ele_CustomerElimination;

    @FindBy(id = "options4.checked1")
    WebElement Ele_Suppression;

    @FindBy(id = "options5.checked1")
    WebElement Ele_Dedupe;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;

    public WebElement ProcessID(){
        return Ele_ProcessID;
    }
    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        BackBtn.click();
    }

    @Step ("Provided the Process Name field = \"{0}\"")
    public void processNameField(String processName){
        Ele_ProcessName.sendKeys(processName);
    }

    @Step ("Selected the process field = \"{0}\"")
    public void selectProcessField(String Process){
        Select selType = new Select(Ele_Process);
        selType.selectByVisibleText(Process);
    }

    @Step ("Selected the Data field = \"{0}\"")
    public void selectDataField(String Data){
        Select selpor = new Select(Ele_Data);
        selpor.selectByVisibleText(Data);
    }

    @Step ("Select House Holding")
    public void clickHholding(){
        Ele_Householding.click();
    }

    @Step ("Select Negative House Hold Drop")
    public void clickNegativeHholdDrop(){
        Ele_NegativeHholdDrop.click();
    }

    @Step ("Select House Hold Split/Regular House Hold Drop")
    public void clickHholdSplitRegHholdDrop(){
        Ele_HholdSplitRegHholdDrop.click();
    }

    @Step ("Select Custom House Holding")
    public void clickCustomHholding(){
        Ele_CustomHholding.click();
    }

    @Step ("Select Customer Elimination")
    public void clickCustomerElimination(){
        Ele_CustomerElimination.click();
    }

    @Step ("Select Suppression")
    public void clickSuppression(){
        Ele_Suppression.click();
    }

    @Step ("Select Dedupe")
    public void clickDedupe(){
        Ele_Dedupe.click();
    }

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }

    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }

    @Step("Error message is ")
    public String getErrMsg(){
        return ErrorMessage.getText();
    }
}

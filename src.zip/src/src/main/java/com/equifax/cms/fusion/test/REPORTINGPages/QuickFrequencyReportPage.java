package com.equifax.cms.fusion.test.REPORTINGPages;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class QuickFrequencyReportPage
{
    WebDriver driver;
    public Select selType;

    public QuickFrequencyReportPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(80, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//div[@id='toolbarreport-grid']/div[1]/div[2]/input[1]")
    WebElement addReportLayout;

    @FindBy(id = "removeButton")
    WebElement removeReportLayout;

    @FindBy(id = "reportTitle")
    WebElement reportTitle;

    @FindBy(id = "allRecordsAccRej")
    WebElement allRecordCheckBox;

    @FindBy(xpath = "//label[contains(text(), 'Process Name:')]")
    WebElement Ele_ProcessID;

    @FindBy(id = "name")
    WebElement processName_Field;

    @FindBy(id = "fromProcessId")
    WebElement process_DD;

    // @FindBy(xpath = ".//*[@id='selectedContent']/div/span[1]")

    @FindBy(xpath = "//span[@id='rowFieldData']")
    WebElement selected_field;

    @FindBy(id = "itemTableId")
    WebElement data_DD;

    @FindBy(id = "addRowField")
    public WebElement add_Btn;

    @FindBy(id = "addRowField")
    public WebElement addFirstDim;

    @FindBy(id = "remove")
    public WebElement remove_Btn;

    @FindBy(xpath = "//div[@id='showhideranges']/div/input[@id='isCreateRanges']")
    public WebElement CreateRanges_CB;

    @FindBy(id = "isZeroCountRange")
    public WebElement ZeroCntRanges_CB;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr/td[2]/input[@id='rowStartValue']")
    public WebElement StartingValue_Fld;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr[2]/td[2]/input[@id='rowEndValue']")
    public WebElement EndValue_Fld;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr[3]/td[2]/input[@id='rowIncrementRange']")
    public WebElement Increment_Fld;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr[4]/td[2]/input[@id='rowValToIsol1']")
    public WebElement valToIso1;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr[4]/td[2]/input[2]")
    public WebElement valToIso2;

    @FindBy(xpath = "//div[@id='1stDimRange']/table/tbody/tr[4]/td[2]/input[3]")
    public WebElement valToIso3;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement save_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][3]")
    WebElement submit_Btn;

    @FindBy(id = "addRowField")
    WebElement firstDimension;

    @FindBy(id = "addColumnField")
    WebElement secondDimension;

    @FindBy(id = "addControlField")
    WebElement thirdDimension;

    @FindBy(id = "columnStartValue")
    WebElement columnStartValue;

    @FindBy(id = "columnEndValue")
    WebElement columnEndValue;

    @FindBy(id = "columnIncrementRange")
    WebElement columnIncrementRange;

    public boolean isSelectedFieldDisplayed(String Field)
    {
        boolean flag = false;
        try
        {
            // String field = driver.findElement(By.xpath(".//*[@id='selectedContent']/div/span[1]")).getText();
            String field = driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']/div[1]/div[1]/div/span[2]")).getText();
            System.out.println(field);
            if (field.contains(Field))
            {
                flag = true;
            }
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
        return flag;

    }

    public String getErrorMessage1()
    {
        return driver.findElement(By.xpath("//div[@class='copyErrMsg errMsgExt']/span")).getText();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']/span")).getText();
    }

    public String getErrorText()
    {
        return driver.findElement(By.xpath("//div[@class='winErrMsg errMsg errMsgExt']/span[@id='textMsg'][1]")).getText();
    }

    @Step("Get the Process Id")
    public String getProcId()
    {
        String[] a = Ele_ProcessID.getText().split(":");
        System.out.println("Process Id: " + a[1]);
        String value = a[1].trim();
        return value;
    }

    @Step("Provided the Process Name field = \"{0}\"")
    public void inputProcessName(String processName)
    {
        if (!"NA".equalsIgnoreCase(processName))
        {
            processName_Field.sendKeys(processName);
        }
    }

    @Step("Get Process Name")
    public String processNameValue()
    {
        return processName_Field.getAttribute("value");
    }

    @Step("Get Selected Process")
    public String getSelectedProcess()
    {
        Select selType = new Select(process_DD);
        return selType.getFirstSelectedOption().getText();
    }

    @Step("Selected the process field = \"{0}\"")
    public void selectProcessField(String Process) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(Process))
        {
            Select selType = new Select(process_DD);
            selType.selectByVisibleText(Process);
            Thread.sleep(2000);
        }
    }

    @Step("Selected the Data field = \"{0}\"")
    public void selectDataField(String Data) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(Data))
        {
            Select selpor = new Select(data_DD);
            selpor.selectByVisibleText(Data);
            Thread.sleep(10000);
        }
    }

    @Step("Select Table and Field under Report Field")
    public void selectTableField(String table, String field)
    {
        // Steps to follow to select a field
        // 1. Get group index by table name
        // 2. Using group index get group details
        // 3. Get subrows from the group
        // 4. Get uid based on columnName
        // 5. Select row from there using selectRow

        List<WebElement> elements = driver.findElements(By.xpath(".//*[@class=' jqx-grid-group-cell']/div/parent::div/parent::div"));
        int i = 0;
        while (i < elements.size())
        {
            String mainStr = elements.get(i).getText();
            String mainId = elements.get(i).getAttribute("id");
            String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
            if (tableName.equalsIgnoreCase(table))
            {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");

                int rowNo = Integer.parseInt(mainId.substring(3, 4));
                int j = 0;
                // Get group info
                ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup','" + rowNo + "').subrows");

                String rowId = null;
                while (j < rowsInfo.size())
                {
                    String row = rowsInfo.get(j).toString();
                    if (row.contains(field))
                    {
                        rowId = getUid(row);
                        break;
                    }
                    j++;
                }

                // Selects row
                js.executeScript("$('#dual-list-data-table-1').jqxGrid('selectrow','" + rowId + "')");
                break;
            }
            i++;
        }
    }

    private String getUid(String row)
    {
        String uidVal;
        String[] strSplit = row.split(",");
        uidVal = strSplit[0].substring(strSplit[0].indexOf("uid") + 4).trim();
        return uidVal;
    }

    public void selTableFlds1(String table) throws InterruptedException
    {
        Thread.sleep(3000);
        driver.findElement(By.xpath(".//div[@id='contenttabledual-list-data-table-1']//div[contains(text(),'" + table + "')]//preceding::div[1]"))
                .click();

        driver.findElement(By.xpath(".//*[@id='addRowField']")).click();
    }

    public void selFields(String table, String fields)
    {
        StringTokenizer st = new StringTokenizer(fields, ",");
        while (st.hasMoreElements())
        {
            driver.findElement(
                    By.xpath(".//div[@id='contenttabledual-list-data-table-1']//div[contains(text(),'" + table
                            + "')]//following::div[contains(text(),'" + st.nextToken() + "')]")).click();
            addFirstDim.click();
        }

    }

    public void clickAddFieldButton()
    {
        add_Btn.click();
    }

    @Step("Clicked the backword button")
    public void clickBackwordButton()
    {
        remove_Btn.click();
    }

    @Step("Clicked Create Range button")
    public void clickCreateRangeBtn(String createRanges)
    {
        if ("Y".equalsIgnoreCase(createRanges))
        {
            // CreateRanges_CB.click();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", CreateRanges_CB);
        } else if ("N".equalsIgnoreCase(createRanges))
        {

        }

    }

    @Step("Is Create Ranges Visible")
    public boolean isCreateRangeVisible()
    {
        return CreateRanges_CB.isDisplayed();
    }

    @Step("Is Create Ranges Checked")
    public boolean isCreateRangeSelected()
    {
        return CreateRanges_CB.isSelected();
    }

    @Step("Clicked Show Zero Count Ranges")
    public void clickZeroCountRanges(String showZeroCountRanges)
    {
        if ("Y".equalsIgnoreCase(showZeroCountRanges))
        {
            ZeroCntRanges_CB.click();
        } else if ("N".equalsIgnoreCase(showZeroCountRanges))
        {

        }
    }

    @Step("Provided Starting Value = \"{0}\"")
    public void inputStartingValue(String strtValue)
    {
        if (!"NA".equalsIgnoreCase(strtValue))
        {
            StartingValue_Fld.sendKeys(strtValue);
        }
    }

    @Step("Provided Ending Value = \"{0}\"")
    public void inputEndingValue(String endValue)
    {
        if (!"NA".equalsIgnoreCase(endValue))
        {
            EndValue_Fld.sendKeys(endValue);
        }
    }

    @Step("Provided Increment Value = \"{0}\"")
    public void inputIncrement(String increment)
    {
        if (!"NA".equalsIgnoreCase(increment))
        {
            Increment_Fld.sendKeys(increment);
        }
    }

    @Step("Provided Values to Isolate = \"{0}\"")
    public void valuesToIsolate(String value)
    {
        if (!"NA".equalsIgnoreCase(value))
        {
            String delim = ",";
            int i = 1;
            StringTokenizer val = new StringTokenizer(value, delim);
            while (val.hasMoreTokens())
            {
                driver.findElement(By.xpath(".//*[@id='rowValToIsol" + i + "']")).sendKeys(val.nextToken());
                i++;
            }
        }
    }

    public Long getCountOfRecordSelecProcessing()
    {
        return Long.parseLong(RemoveComma(driver.findElement(
                By.xpath(".//*[contains(text(),'Input Records selected for processing')]/following::div[1]")).getText()));
    }

    public String getReportSelectedTableName()
    {
        return driver.findElement(
                By.xpath(".//*[contains(text(),' //*[contains(text(),'Report selected Table Name')]/following::div[1]')]/following::div[1]"))
                .getText();
    }

    // *[contains(text(),'Report selected Table Name')]/following::div[1]
    @Step("{method}")
    public static String RemoveComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }

    @Step("Clicked Back button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Clicked Save button")
    public void clickSaveButton()
    {
        save_Btn.click();
    }

    @Step("Clicked Submit button")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    @Step("Check Accepts Rejects display status")
    public String accRejDisplaystatus()
    {
        return driver.findElement(By.xpath(".//*[@class='codeTypes']")).getAttribute("style");

    }

    @Step("Duplicate Quick Freq Process")
    public void duplicateProcess()
    {
        driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//*[@class='grey-button saveDetails'][contains(text(),'OK')]")).click();
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Step("get selected field")
    public String getSelectedField()
    {
        String s = selected_field.getText().trim();
        return s;

    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public void selectAllRecordsCheckBox()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", allRecordCheckBox);

    }

    public void clickFirstDimArrow()
    {
        firstDimension.click();
    }

    public void clickSecondDimArrow()
    {
        secondDimension.click();
    }

    public void clickThirdDimArrow()
    {
        thirdDimension.click();
    }

    public String getDimensionaReportData()
    {
        return driver.findElement(By.xpath("//h5[contains(text(),'1 Dimension Report')]/following::div[3]/div[2]/div/div/div/div/span[2]")).getText();
    }

    public String getDimensionReportRightColData()
    {
        return driver.findElement(By.xpath("//h5[contains(text(),'1 Dimension Report')]/following::div[3]/div[2]/div/div/div[2]/div/span")).getText();
    }

    @Step("Group data into ranges")
    public void checkGroupDataRanges()
    {
        driver.findElement(By.xpath("//input[@id='isCreateRanges']")).click();
    }

    @Step("Get start value")
    public void startingValue(String startVal)
    {
        if (!"NA".equalsIgnoreCase(startVal))
        {
            columnStartValue.sendKeys(startVal);
        }
    }

    @Step("Get end value")
    public void endValue(String endValue)
    {
        if (!"NA".equalsIgnoreCase(endValue))
        {
            columnStartValue.sendKeys(endValue);
        }
    }

    @Step("Get increment")
    public void incrementValue(String incrementValue)
    {
        if (!"NA".equalsIgnoreCase(incrementValue))
        {
            columnStartValue.sendKeys(incrementValue);
        }
    }

    @Step("Click add report file")
    public void clickAddReportLayout()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", addReportLayout);

    }

    @Step("Enter Report Title")
    public void setReportTitle(String title)
    {
        reportTitle.sendKeys(title);
    }

    @Step("Click Save report details")
    public void clickReportDetailSave()
    {
        driver.findElement(By.xpath("//div[@id='layout-section']/div[7]/input[1]")).click();
    }

    @Step("Click Cancel report details")
    public void clickReportDetailCancel()
    {
        driver.findElement(By.xpath("//div[@id='layout-section']/div[7]/input[2]")).click();
    }

    @Step("click edit report File")
    public void clickEditReportFile()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(By.xpath("//div[@id='contenttablereport-grid']/div/div[6]/div/input"));
        js.executeScript("arguments[0].click();", element);

    }

    @Step("select a particular report File")
    public void selectReportFileToEdit(String processName)
    {
        WebElement elementToSelect = driver.findElement(By.xpath("//div[contains(text(),'testReport')]/parent::div/parent::div/div[2]"));
        elementToSelect.click();
    }

}

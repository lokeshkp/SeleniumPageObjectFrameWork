package com.equifax.cms.fusion.test.RFPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class HholdingKeyConfigPage {

    WebDriver driver;

    public HholdingKeyConfigPage(WebDriver driver){
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

    }

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/h3")
    WebElement ScreenTitle;

    @FindBy(id = "householdKey1")
    WebElement Ele_Standard;

    @FindBy(id = "householdKey2")
    WebElement Ele_Custom;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;


    @Step ("Select Standard Option")
    public void clickStandardRbutton(){
        if(Ele_Standard.isSelected()){
            System.out.println("Not required to select");
        }
        else
        {
            Ele_Standard.click();
        }
    }

    @Step ("Select Custom Option")
    public void clickCustomRbutton(){
        Ele_Custom.click();
    }

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }

    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }

    @Step ("Screen Title:")
    public String getTitle(){
        return ScreenTitle.getText();

    }

    @Step("Error message is ")
    public String getErrMsg(){
        return ErrorMessage.getText();
    }

    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        BackBtn.click();
    }
}


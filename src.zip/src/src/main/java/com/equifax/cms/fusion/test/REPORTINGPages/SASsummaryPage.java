package com.equifax.cms.fusion.test.REPORTINGPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class SASsummaryPage {
	WebDriver driver;
	public SASsummaryPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = "//input[@name='submitButton']")
	WebElement SubmitBtn;
	
	
	@Step("Clicked Submit Button")
	public void clickSubmitButton(){
		SubmitBtn.click();
	}
}

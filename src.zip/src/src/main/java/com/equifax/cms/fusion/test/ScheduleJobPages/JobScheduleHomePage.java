package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class JobScheduleHomePage
{

    WebDriver driver;

    public JobScheduleHomePage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    private static final Logger LOGGER = LoggerFactory.getLogger(ScheduleJobHomePage.class);
    OracleDBHelper oracleDb;

    @Step("Click on Schedule Job Tab")
    public void clickScheduleJobTab()
    {
        WebElement ele = driver.findElement(By.xpath("//div[@class='expandable']/ul/li/div[2]/a"));
        ele.click();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    public String getTemplateJson(String id)
    {
        String sql = "select runtime_config_json from job_schedule_history_config where schedule_id = ?";
        PreparedStatement statement = null;
        String field = null;
        try
        {
            statement = oracleDb.getConnection().prepareStatement(sql);
            statement.setString(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();

            field = rs.getString("runtime_config_json");

        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return field;

    }
}

package com.equifax.cms.fusion.test.REPORTINGPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class CreateFICOreportsPage {
	
	WebDriver driver;
	public Select selType;

	public CreateFICOreportsPage(WebDriver driver){

		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "name")
	WebElement ProcNameFld;
	
	@FindBy(id = "fromProcessId")
	WebElement ProcessFld;
	
	@FindBy(xpath = "//input[@value='Submit']")
	WebElement SubmitBtn;
	
	@Step("Provided the Process Name Field = \"{0}\"")
	public void processNameFld(String procName){
		ProcNameFld.sendKeys(procName);
	}
	
	@Step("Selec the Process Field = \"{0}\"")
	public void selectProcFld(String procFld){
		selType = new Select(ProcessFld);
		selType.selectByVisibleText(procFld);
	}
	
	@Step("Click Submit button")
	public void clickSubmitBtn(){
		SubmitBtn.click();
	}
}

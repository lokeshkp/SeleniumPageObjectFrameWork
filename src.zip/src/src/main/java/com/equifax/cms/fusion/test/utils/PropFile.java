package com.equifax.cms.fusion.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class PropFile {

	public static String filePath = System.getProperty("user.dir")+"\\src\\test\\resources\\qa2\\InputSheet.properties";
	public static Properties prop;
	public static FileInputStream fis;

	static {
		File file = new File(filePath);
		FileInputStream fis = null;

		try {
			fis = new FileInputStream(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		prop = new Properties();

		try {
			prop.load(fis);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		}

	public static String getValue(String property) {
		String returnValue = "";
		returnValue = prop.getProperty(property);
		return returnValue;
	}

}

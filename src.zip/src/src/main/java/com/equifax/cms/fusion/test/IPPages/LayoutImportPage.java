package com.equifax.cms.fusion.test.IPPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class LayoutImportPage {

		WebDriver driver;
		
	public LayoutImportPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "layoutFilePath")
	WebElement Ele_LayoutFileLocation;
	
	@FindBy(id = "rowNoOfFirstField")
	WebElement Ele_RowNoOfFirstField;
	
	@FindBy(id = "colNoUserDefinedName")
	WebElement Ele_UserDefinedName;
	
	@FindBy(id = "colNoStartPos")
	WebElement Ele_StartPosition;
	
	@FindBy(id = "colNoEndPos")
	WebElement Ele_EndPosition;
	
	@FindBy(xpath = "//td[contains(text(),'Length')]")
	public WebElement Ele_Length;
	
	@FindBy(id = "cleanse1")
	WebElement InvalidChar_ChckBox;
	
	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement BackBtn;
	
	@FindBy(id = "submitLayout")
	WebElement ContinueButton;
	
	@FindBy(xpath = "//table[contains(text(),'MLA_TRANSACTION_ID')]")
    public WebElement mlaTableText;
	
	@Step("Provide File Location \"{0}\"")
	public void inputLayoutFileLocation(String fileLocation){
		Ele_LayoutFileLocation.sendKeys(fileLocation);
	}
	
	@Step("Clear Layout File Location")
	public void clearLayoutFileLocation(){
		Ele_LayoutFileLocation.clear();
	}
	
	@Step("Provide Row No. of the First Field\"{0}\"")
	public void inputRowNoOfFirstField(String RowNo){
		Ele_RowNoOfFirstField.sendKeys(RowNo);
	}
	
	@Step("Clear Row No. of First Field")
	public void clearRowNoOfFirstField(){
		Ele_RowNoOfFirstField.clear();
	}
	
	@Step("Provide User Defined Name \"{0}\"")
	public void inputUserDefinedName(String UserDefNameNo){
		Ele_UserDefinedName.sendKeys(UserDefNameNo);
	}
	
	@Step("Clear User Defined Name")
	public void clearUserDefinedName(){
		Ele_UserDefinedName.clear();
	}
	
	@Step("Provide Start Position \"{0}\"")
	public void inputStartPosition(String startPosition){
		Ele_StartPosition.sendKeys(startPosition);
	}
	
	@Step("Clear Start Position")
	public void clearStartPosition(){
		Ele_StartPosition.clear();
	}
	
	@Step("Provide End Position \"{0}\"")
	public void inputEndPosition(String endPosition){
		Ele_EndPosition.sendKeys(endPosition);
	}
	
	@Step("Clear End Position")
	public void clearEndPosition(){
		Ele_EndPosition.clear();
	}
	
	@Step("Selected Translate Invalid Characters to Blanks")
	public void selectInvalidCharChckBox(){
		InvalidChar_ChckBox.click();
	}
	
	@Step("Clicked on Back button")
	public void clickBackBtn(){
		BackBtn.click();
	}
	
	@Step("Click the Continue button")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
}

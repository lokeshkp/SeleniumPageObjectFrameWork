package com.equifax.cms.fusion.test.SHPages;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import ru.yandex.qatools.allure.annotations.Step;

public class ShippingStats
{
    WebDriver driver;

    public ShippingStats(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    public List<String> getShFileRecCount()
    {
        List<WebElement> recWebEle = driver.findElements(By.xpath("//div[contains(text(),'Number of Records shipped')]//following::div[1]"));
        List<String> recCount = new ArrayList<String>();
        for (WebElement temp : recWebEle)
        {
            recCount.add(temp.getText());
        }
        return recCount;
    }

    public Long countOfFirstOP()
    {
        String opCount = driver.findElement(By.xpath("(//div[contains(text(),'Total number of records')]//following::div[1])[1]")).getText();
        return Long.parseLong(opCount);
    }

    @Step("Get the Count of Records Shipped From Shipping Stats")
    public HashMap<String, Long> getTheCountOfRecordsShipped(String fileName)
    {
        HashMap<String, Long> shFileNameAndRecordCntMap = new HashMap<String, Long>();
        String[] fileArr = fileName.split(",");
        for (String file : fileArr)
        {

            String recordCnt = driver.findElement(
                    By.xpath("(//div[starts-with(text()," + file
                            + ")]//following::div[contains(text(),'Number of Records shipped')][1]/following::div[1])[1]")).getText();
            recordCnt = recordCnt.replaceAll(",$", "");
            shFileNameAndRecordCntMap.put(file, Long.parseLong(recordCnt));
        }

        return shFileNameAndRecordCntMap;
    }

    @Step("Get the Count of  Shipped File In Shipping Stats")
    public Integer getTheCountOfShippedFiles()
    {

        List<WebElement> shFilesCountList = driver.findElements(By.xpath("//div[starts-with(text(),'File Name')]/following::div[1]"));
        int noOfShippedFiles = shFilesCountList.size();

        return noOfShippedFiles;
    }

    @Step("Get the Count of Records From Output Stats")
    public HashMap<String, Long> getTheCountOfRecordsOfFileFromOPStats(String fileNames)
    {
        HashMap<String, Long> OPFileNameAndRecordCntMap = new HashMap<String, Long>();
        String[] fileArr = fileNames.split(",");
        for (String file : fileArr)
        {
            String recordCnt = driver.findElement(
                    By.xpath("//div[contains(text(),'Number of split files created')]//following::div[contains(text()," + file
                            + ")]//following::div[1")).getText();
            recordCnt = recordCnt.replaceAll(",$", "");
            OPFileNameAndRecordCntMap.put(file, Long.parseLong(recordCnt));
        }

        return OPFileNameAndRecordCntMap;
    }
    @Step("Fetching The count of work items formed and their Names")
    public List<String> getTheCountandNamesOfWorkItem(String procId,String procName) throws InterruptedException
    {
        String processNameForStats=procId+"_"+procName;
        String processNameWithColon=procId+":"+procName;
        List<String> itemNameList=new ArrayList<String>();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameWithColon + "')]/preceding::span[1]")).click();
        List<WebElement> elements = driver.findElements(By.xpath("//table[@id='tablejob-tree']//tr"));
        if (elements.size() == 4)
        {
            List<WebElement> itemIlements = driver.findElements(By.xpath("//span[starts-with(text(),'SHP')]"));
            for(WebElement ele:itemIlements)
            {
                itemNameList.add(ele.getText());
            }
        }


        return itemNameList;

    }
}

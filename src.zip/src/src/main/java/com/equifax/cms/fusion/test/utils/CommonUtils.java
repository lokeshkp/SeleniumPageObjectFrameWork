package com.equifax.cms.fusion.test.utils;

import java.io.File;
import java.io.IOException;

import com.google.common.hash.HashCode;
import com.google.common.hash.Hashing;
import com.google.common.io.Files;

public class CommonUtils {

	/**
	 * compare files byte wise return false files not present
	 *
	 * @param src
	 * @param desc
	 * @return {@link Boolean}
	 * @throws IOException
	 */
	public static boolean bytewiseCompare(final String src, final String desc) throws IOException {

		File source = validateFile(src);
		File target = validateFile(desc);

		return Files.asByteSource(source).contentEquals(Files.asByteSource(target));
	}

	private static File validateFile(final String src) throws IOException {
		File source = new File(src);
		if (!source.exists()) {
			throw new IOException("Not able to compare the file , source file doest not exist - " + src);
		}
		return source;
	}

	/**
	 * Files.hash(file, Hashing.sha1());
	 */

	public static boolean compareFilesSHA1(final String src, final String desc) throws IOException {

		File source = validateFile(src);
		File target = validateFile(desc);

		HashCode hashSource = Files.hash(source, Hashing.md5());
		HashCode hashTraget = Files.hash(target, Hashing.md5());

		return hashSource.equals(hashTraget);
	}

	}
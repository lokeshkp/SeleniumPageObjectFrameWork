package com.equifax.cms.fusion.test.RFPages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class SuppressionOptionsPage {

    WebDriver driver;

    public SuppressionOptionsPage(WebDriver driver){

        this.driver = driver;

        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "(.//*[@id='subOptionCode'])[1]")
    WebElement Ele_CIDSuppression;

    @FindBy(xpath = "(.//*[@id='subOptionCode'])[2]")
    WebElement Ele_SSNSuppression;

    @FindBy(xpath = "(.//*[@id='subOptionCode'])[3]")
    WebElement Ele_CustomSuppression;

    @FindBy(xpath = "(.//*[@id='subOptionCode'])[4]")
    WebElement Ele_RollingSuppression;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/h3")
    WebElement ScreenTitle;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/div[1]")
    WebElement ErrorMessage;

    @FindBy(id = "rsProcessId")
    WebElement Ele_Rolling_Supp;

    @FindBy(id = "suppDays")
    WebElement Ele_Supp_Days;

    @Step ("Screen Title:")
    public String getTitle(){
        return ScreenTitle.getText();
    }

    @Step("Error message is ")
    public String getErrMsg(){
        return ErrorMessage.getText();
    }

    @Step ("Select CID Suppression")
    public void selectCIDSuppressionRbutton()
    {
        if(Ele_CIDSuppression.isSelected())
        {
            System.out.println("Not required to select");
        }
        else
        {
            Ele_CIDSuppression.click();
        }
    }

    @Step ("Select SSN Suppression")
    public void selectSSNSuppressionRbutton(){
        Ele_SSNSuppression.click();
    }

    @Step ("Select Custom Suppression")
    public void selectCustomSuppressionRbutton(){
        Ele_CustomSuppression.click();
    }

    @Step ("Select Rolling Suppression")
    public void selectRollingSuppressionRbutton(){
        Ele_RollingSuppression.click();
    }

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }

    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }

    @Step ("Select the Suppression Type = \"{0}\"")
    public void selectSuppressionType(String type){

        if("CID".equalsIgnoreCase(type))
        {
            selectCIDSuppressionRbutton();

        } else if ("SSN".equalsIgnoreCase(type)){
            selectSSNSuppressionRbutton();

        } else if ("Custom".equalsIgnoreCase(type)){
            selectCustomSuppressionRbutton();

        } else if ("Rolling".equalsIgnoreCase(type)){
            selectRollingSuppressionRbutton();

        } else {
            System.out.println("Wrong information has provided in the input Data sheet !!!");
        }

    }
    @Step ("Select the Suppression Type = \"{0}\"")
    public void selectSuppType(String type){

        if("CID Suppression".equalsIgnoreCase(type))
        {
            selectCIDSuppressionRbutton();

        } else if ("SSN Suppression".equalsIgnoreCase(type)){
            selectSSNSuppressionRbutton();

        } else if ("Custom Suppression".equalsIgnoreCase(type)){
            selectCustomSuppressionRbutton();

        } else if ("Rolling Suppression".equalsIgnoreCase(type)){
            selectRollingSuppressionRbutton();

        } else {
            System.out.println("Wrong information has provided in the input Data sheet !!!");
        }

    }
    @Step ("Select Rolling Suppression Process and Suppression Days From The Suppression Table when Rolling Suppression Option Is Selected")
    public void selectRollingSuppProcAndSuppDays(String rollingSuppProc,String suppDays) throws InterruptedException
    {
        boolean suppressionTableDisplayed=driver.findElement(By.xpath("//div[starts-with(text(),'Suppression Table')]")).isDisplayed();
        if(suppressionTableDisplayed)
        {

            Select select = new Select(Ele_Rolling_Supp);
            select.selectByVisibleText(rollingSuppProc);
            Thread.sleep(1000);
            Ele_Supp_Days.clear();
            Ele_Supp_Days.sendKeys(suppDays);
        }

    }
    @Step("Fetch The Error Message")
    public String fetchTheErrMsg()
    {
        String errorMsg=driver.findElement(By.xpath("//div[@class='errMsg']")).getText();
        return errorMsg;
    }

    @Step ("Validate Process Present in the Drop Down")//Validates Rolling Suppression Process Present in the Drop Down When Rolling Suppression Option is selected
    public boolean isProcessPresent(String rollingSuppProc) throws InterruptedException
    {
        WebElement dropdown = driver.findElement(By.id("rsProcessId"));
        Select select = new Select(dropdown);
        boolean match = false;
        List<WebElement> options = select.getOptions();
        for(WebElement option:options)
        {

            for (int i=0; i<options.size(); i++){
                if (option.getText().equalsIgnoreCase(rollingSuppProc)){
                    match = true;
                }
            }

        }
        return match;
    }
}

package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ScheduleJobPageQA
{
    
    WebDriver driver;
    public Select selType;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    public ScheduleJobPageQA(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    @FindBy(id = "scheduleName")
    WebElement schedule_Name;

    @FindBy(id = "processId")
    WebElement processId;

    @FindBy(id = "state1")
    WebElement activeState;

    @FindBy(id = "state2")
    WebElement inactiveState;

    @FindBy(id = "jobNotifyEmailIds")
    WebElement jobNotify_EmailIds;

    @FindBy(id = "allNotifyEmailIds")
    WebElement allNotify_EmailIds;

    @FindBy(id = "failureNotifyEmailIds")
    WebElement failureNotify_EmailIds;

    @FindBy(xpath = ".//*[@id='automationForm']/div/a")
    WebElement back_Button;

    @FindBy(xpath = ".//*[@id='automationForm']/div/input[1]")
    WebElement save_Button;

    @FindBy(xpath = ".//*[@id='automationForm']/div/input[2]")
    WebElement continue_Button;

    public void inputScheduleName(String scheduleName)
    {
        if (!"NA".equalsIgnoreCase(scheduleName))
        {
            Date date = new Date();
            String dateInput = dateFormat.format(date);
            schedule_Name.clear();
            schedule_Name.sendKeys(scheduleName+"_"+dateInput);

        }
    }
    
    public void selecStack(String stackName) 
    {
        if(!"NA".equalsIgnoreCase(stackName)) 
        {
            Select sl = new Select(processId);
            sl.selectByVisibleText(stackName);
        }
    }
    
    public void selectState(String state)
    {
        if (!"NA".equalsIgnoreCase(state))
        {
            if ("ACTIVE".equalsIgnoreCase(state) && !activeState.isSelected())
            {
                activeState.click();
            } else if ("INACTIVE".equalsIgnoreCase(state) && !inactiveState.isSelected())
            {
                inactiveState.click();
            }
        }
    }
    
    public void inputScheduleStartEndFailureMailId(String sefJobMail)
    {
        if(!"NA".equalsIgnoreCase(sefJobMail)) {
        jobNotify_EmailIds.clear();
        jobNotify_EmailIds.sendKeys(sefJobMail);}
    }

    public void inputScheduleAndStepStartEndFailureMailId(String mail)
    {
        if(!"NA".equalsIgnoreCase(mail)) {
        allNotify_EmailIds.clear();
        allNotify_EmailIds.sendKeys(mail);}
    }

    public void inputScheduleFailureMailId(String failureMail)
    {
        if(!"NA".equalsIgnoreCase(failureMail)) {
        failureNotify_EmailIds.clear();
        failureNotify_EmailIds.sendKeys(failureMail);
        }
    }
    
    public void clickBackButton()
    {
        back_Button.click();
    }

    public void clickSave()
    {
        save_Button.click();
    }

    public void clickContinue()
    {
        continue_Button.click();
    }
    
    public boolean isActiveRBPresent() 
    {
        try 
        {
            activeState.click();
            return true;
        }catch(org.openqa.selenium.NoSuchElementException e) 
        {
            return false;
        }
    }
    
    public boolean isInActiveRBPresent() 
    {
        try 
        {
            inactiveState.click();
            return true;
        }catch(org.openqa.selenium.NoSuchElementException e) 
        {
            return false;
        }
    }
    
    public String getErrorMessage() 
    {
        return driver.findElement(By.xpath(".//*[@id='textMsg']/span")).getText();
    }


}

package com.equifax.cms.fusion.test.OPPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.NotDirectoryException;
import java.nio.file.Path;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.GreenPlumDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class OpStatsView
{
    WebDriver driver;
    ProjectDashBoardPage ProjDashBoardPage;
    CommonMethods commMethods;
    private GreenPlumDBHelper greenPlumConnect;
    private static final Logger LOGGER = LoggerFactory.getLogger(OpStatsView.class);

    @FindBy(id = "closeButton")
    WebElement close_stats;

    @FindBy(xpath = "//a[contains(text(),'Close')]")
    WebElement CloseBtnOnStats;

    public void clickToCloseStats()
    {
        driver.findElement(By.xpath("//div[@class='jqx-window-close-button jqx-window-close-button-classic jqx-icon-close jqx-icon-close-classic']")).click();

    }

    public OpStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    public void click_DC_ANALYZE_Report()
    {
        driver.findElement(By.xpath("(.//*[contains(text(),'ANALYZE Report ')])[3]")).click();
    }

    public void click_DC_COMPARE_Report()
    {
        driver.findElement(By.xpath("(.//*[contains(text(),'COMPARE Report ')])[3]")).click();
    }

    @Step("Fetched Source Table Names")
    public String getSplitTableNameOP()
    {
        String opSourceTableName = driver.findElement(By.xpath(".//div[contains(text(),'OUTPUT SPLIT TABLE')]/following::div[1]")).getText();
        return opSourceTableName;
    }

    @Step("Get Output File Folder Path")
    public String getFileFolderLocation()
    {
        String opSourceTableName = driver.findElement(By.xpath("//div[contains(text(),'Intermediate File Folder')]/following::div[5]/div[2]"))
                .getText();
        return opSourceTableName;
    }

    @Step("Fetched Source Table Count")
    public Long getSplitTableCountOP() throws NumberFormatException, ParseException
    {
        //String opSourceTableCount = driver.findElement(By.xpath(".//div[contains(text(),'OUTPUT SPLIT TABLE')]/following::div[2]/div[2]")).getText();
        // return Long.parseLong(opSourceTableCount);
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opSourceTableCount = driver.findElement(By.xpath(".//div[contains(text(),'OUTPUT SPLIT TABLE')]/following::div[2]/div[2]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return Long.valueOf(numberFormat.parse(opSourceTableCount).toString());
    }

    @Step("Fetched Source Table Names")
    public String getSourceTableNameOP()
    {
        String opSourceTableName = driver.findElement(By.xpath("(.//div[contains(text(),'Source Table')]/following-sibling::div)[1]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return opSourceTableName;
    }

    @Step("Fetched Source Table Names")
    public String getSourceInputTableName()
    {
        String opSourceTableName = driver.findElement(By.xpath("//div[contains(text(),'Source Table')]/following::div[1]")).getText();
        return opSourceTableName;
    }

    @Step("Is Output Capped View Created In Stats")
    public boolean isCappedViewFormedInStats()
    {
        boolean isCappedViewFormed=false;
        isCappedViewFormed=driver.findElement(By.xpath("//*[contains(text(),'OUTPUT CAPPING VIEW')]")).isDisplayed();
        return isCappedViewFormed;
    }

    @Step("Fetched Output Table Name")
    public String getOutputTableNameOP()
    {//*[contains(text(),'OUTPUT CAPPING VIEW')]//following::div[1]
        String opTableName = driver.findElement(By.xpath(".//div[contains(text(),'_OT_GPCAP_OUTPUTTBL')]")).getText();
        //String opTableName = driver.findElement(By.xpath("//div[starts-with(text(),'OUTPUT CAPPING VIEW')]//parent::div/div[2]")).getText();
        return opTableName;
    }




    public Integer fetchTheCountOfOutputCappingViewFormed()
    {//*[contains(text(),'OUTPUT CAPPING VIEW')]//following::div[1]
        //String opTableName = driver.findElement(By.xpath(".//div[contains(text(),'_OT_GPCAP_OUTPUTTBL')]")).getText();

        List<WebElement> elements= driver.findElements(By.xpath("//div[starts-with(text(),'OUTPUT CAPPING VIEW')]"));
        return elements.size();
    }

    @Step("Fetched Output Split TAble Name")
    public String getOutputSplitTableName()

    {
        String opTableName = driver.findElement(By.xpath(".//div[contains(text(),'_OT_GPSPLIT')]")).getText();
        return opTableName;
    }

    /*
     * @Step("Fetched Source Table Count") public Long getSourceTableCountOP() { String opSourceTableCount =
     * driver.findElement(By.xpath("//div[contains(text(),'Source Table')]/following::div[1]")).getText(); return Long.valueOf(opSourceTableCount); }
     */
    @Step("Fetched Source Table Count")
    public Long getSourceTableCountOP() throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opSourceTableCount = driver.findElement(By.xpath("//div[contains(text(),'Source Table')]/following::div[2]/div[2]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return Long.valueOf(numberFormat.parse(opSourceTableCount).toString());
    }
    //public Long getSourceTableCountOP() throws NumberFormatException, ParseException
    //{
    //    NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
    //    String opSourceTableCount = driver.findElement(By.xpath("//div[contains(text(),'Source Table')]/following::div[2]/div[2]")).getText();
    //    return Long.valueOf(numberFormat.parse(opSourceTableCount).toString());
    //}
    @Step("Fetched the count of record selected for processing")
    public Long getCountOfRecordsSelectedForProcessing() throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opSourceTableCount = driver.findElement(By.xpath("//div[contains(text(),'Input Records Selected For Processing')]//following::div[1]")).getText();
        return Long.valueOf(numberFormat.parse(opSourceTableCount).toString());
    }

    @Step("Fetched Split Table Count")
    public Long getSpitTableCountOP() throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opSourceTableCount = driver.findElement(By.xpath("//div[contains(text(),'OUTPUT SPLIT TABLE')]/following::div[2]/div[2]")).getText();
        return Long.valueOf(numberFormat.parse(opSourceTableCount).toString());
    }

    @Step("Fetched Output Table Count")
    public Long getOutputTableCountOP() throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opTableCount = driver.findElement(By.xpath("//div[contains(text(),'_OT_GPCAP_OUTPUTTBL')]/following::div[12]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return Long.valueOf(numberFormat.parse(opTableCount).toString());
    }

    @Step("Fetched Seeding Table Name")
    public String getSeedingTableNameOP()
    {
        String opSeedingTableName = driver.findElement(By.xpath(".//div[contains(text(),'Output Seed Table')]/following::div[1]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return opSeedingTableName;
    }

    @Step("Fetched Records as per Distribution ")
    public Long getcapRecDisrt(String recType) throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String count = driver.findElement(By.xpath("//div[contains(text(),'" + recType + "-')]/following::div[1]")).getText();
        return Long.valueOf(numberFormat.parse(count).toString());
    }

    @Step("Fetched Seeding Table Count")
    public Long getSeedingTableCountOP() throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String opSeedingTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Output Seed Table')]/following::div[4]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return Long.valueOf(numberFormat.parse(opSeedingTableCount).toString());
    }

    public boolean isMaskScramLinItemPresent()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            String aa = driver.findElement(By.xpath(".//*[contains(text(),'Records affected by applying masking/scrambling')]")).getText();
            System.out.println(aa);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public Long getCountofMaskScramRec()
    {
        String record=driver.findElement(By.xpath(".//*[contains(text(),'Records affected by applying masking/scrambling')]//following::div[1]")).getText().replaceAll(",","").replaceAll("\\s+","");
        return Long.valueOf(record);
    }

    public boolean verifyMoveStament(HashMap<String, String> col1)
    {
        boolean result = false;
        for (Map.Entry<String, String> entry : col1.entrySet())
        {
            if (entry.getValue().equalsIgnoreCase(entry.getKey()))
            {
                result = true;
            } else
            {
                return false;
            }
        }
        return result;

    }

    @Step("Close stats")
    public void clickCloseStats()
    {
        CloseBtnOnStats.click();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    public HashMap<String, String> getCol1Values(String table, String dataToOuptut, String opLayoutField) throws SQLException
    {
        Connection conn = gpConnect();
        String query;
        HashMap<String, String> records = new HashMap<>();

        query = "select " + dataToOuptut + "," + opLayoutField + " from fusion_stage." + table + " limit 5";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        int column1Pos = rs.findColumn(dataToOuptut);
        int column2Pos = rs.findColumn(opLayoutField);
        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            String column2 = rs.getString(column2Pos);
            records.put(column1, column2);
        }

        return records;

    }
    public List<String> fetchTheRecordDistributionInstats(List<String> recordTypeList)
    {
        List<String> records = new ArrayList<String>();
        for(String recordType:recordTypeList)
        {
            if(recordType!=null)
            {
                records.add(driver.findElement(By.xpath("//div[starts-with(text(),'"+recordType+"')]/following::div[1]")).getText().replaceAll(",","").replaceAll("\\s+",""));
            }
        }

        return records;
    }


    public List<String> fetchTheRecordBasedOnFailCode(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query;
        List<String> records = new ArrayList<String>();

        query = "select COUNT(fail_code) from fusion_stage." + table + " GROUP BY fail_code";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        int column1Pos = rs.findColumn("count");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            records.add(column1);
        }

        return records;

    }

    public List<String> fetchTheFailCode(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query;
        List<String> records = new ArrayList<String>();

        query = "select fail_code from fusion_stage." + table + " GROUP BY fail_code";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("fail_code");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            records.add(column1);
        }

        return records;

    }
    public Long getTheCountOfRecordSelectedForProcessingInGp(String table1,String table2) throws SQLException
    {
        Connection conn = gpConnect();

        String query;

        PreparedStatement statement = null;
        Long count = null;

        query =  " select count(*) CNT from fusion_stage."+ table1 +" lcr,fusion_stage."+ table2 + " hdr where lcr.dp_sequence_num=hdr.dp_sequence_num";

        System.out.println("GP Query : " + query);
        // statement = greenPlumConnect.getConnection().prepareStatement(query);

        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        count = rs.getLong("CNT");

        return count;
    }

    public String getRecordTypesNotInMoveStmt(String recordType, String movRecType)
    {
        List<String> recType = new ArrayList<>();
        String recordTypeSplit[] = recordType.split(",");
        String movRecTypeSplit[] = movRecType.split(",");
        for (String s : recordTypeSplit)
        {
            for (int i = 0; i < movRecTypeSplit.length; i++)
            {
                if (s != movRecTypeSplit[i])
                {
                    recType.add(s);
                }
            }
        }
        return recType.get(0);

    }

    public List<String> getColValuesWhenReplacedWithLiteral(String table, String data1, String recType, String moveRec) throws SQLException
    {
        Connection conn = gpConnect();
        String query = null;
        List<String> records = new ArrayList<>();
        String recordType = getRecordTypesNotInMoveStmt(recType, moveRec);
        List<String> accCodes = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                "U", "V", "W", "X", "Y", "Z");
        List<String> rejCodes = Arrays.asList("NH", "FR", "NP", "PS", "RJ", "RP", "ID", "IP", "CE", "RD", "DP", "HS", "ND", "DB", "CT", "DD", "SR",
                "NA", "SN", "NX", "RS", "DN", "DS");
        if (accCodes.contains(recordType))
        {

            query = "select " + data1 + " from fusion_stage." + table + " where acc_code ='" + recordType + "' limit 5";
            System.out.println("GP Query : " + query);
        }
        if (rejCodes.contains(recordType))
        {

            query = "select " + data1 + " from fusion_stage." + table + " where fail_code ='" + recordType + "' limit 5";
            System.out.println("GP Query : " + query);
        }

        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        int column1Pos = rs.findColumn(data1);

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            records.add(column1);
        }

        return records;

    }

    // incomplete

    public HashMap<String, String> getColValuesWhenMoveStmntPerformed(String table, String data1, String data2) throws SQLException
    {
        Connection conn = gpConnect();
        String query;
        HashMap<String, String> records = new HashMap<>();

        query = "select " + data1 + "," + data2 + " from fusion_stage." + table + "where acc_code ='' limit 5";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        int column1Pos = rs.findColumn(data1);
        int column2Pos = rs.findColumn(data2);
        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            String column2 = rs.getString(column2Pos);
            records.put(column1, column2);
        }

        return records;

    }

    public List<String> getCountForAcceptCodes(String table, String recordType) throws SQLException
    {
        List<String> accCodes = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                "U", "V", "W", "X", "Y", "Z");
        List<String> rejCodes = Arrays.asList("NH", "FR", "NP", "PS", "RJ", "RP", "ID", "IP", "CE", "RD", "DP", "HS", "ND", "DB", "CT", "DD", "SR",
                "NA", "SN", "NX", "RS", "DN", "DS");
        Connection conn = gpConnect();
        List<String> countsList = new ArrayList<>();
        String query;
        String records[] = recordType.split(";");
        String accepts[] = records[0].split(",");
        String rejects[] = records[1].split(",");
        PreparedStatement statement = null;
        Long count = null;

        for (String acc : accepts)
        {
            query = "select count(*) CNT from fusion_stage." + table + "  where acc_code ='" + acc + "' and record_status != 'R'";
            System.out.println("GP Query : " + query);
            // statement = greenPlumConnect.getConnection().prepareStatement(query);

            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            // ResultSet rs = statement.executeQuery();
            rs.next();
            count = rs.getLong("CNT");
            countsList.add(count.toString());
        }

        return countsList;

    }

    public String getRecordTypeDistribution(String fileName)
    {
        return driver.findElement(
                By.xpath("//div[contains(text(),'" + fileName
                        + "')]/following::div[22]/div[contains(text(),'Record Type Distribution')]/following ::div[2]/div[1]")).getText();
    }

    public String getRecordTypeDistributionCount()
    {
        return driver
                .findElement(
                        By.xpath("//div[contains(text(),'.fixed')]/following::div[11]/div[contains(text(),'Record Type Distribution')]/following ::div[2]/div[2]"))
                        .getText();
    }

    public Long getDistributedFileCounts(int groups)
    {
        List<String> fileDistributionList = new ArrayList<>();
        Long total = 0L;
        for (int i = 0; i < groups; i++)
        {
            String perFileCount = driver.findElement(
                    By.xpath("//div[contains(text(),'File1')]/following::div[14]/div[contains(text(),'Record Type Distribution')]/following ::div[2]/div[2]")).getText();
            fileDistributionList.add(perFileCount);
        }
        for (String s : fileDistributionList)
        {
            total = total + Long.valueOf(s);
        }
        return total;
    }

    // div[contains(text(),'File1_0')]/following::div[11]/div[contains(text(),'Record Type Distribution')]/following ::div[2]/div[1]
    public List<String> getCountForRejectCodes(String table, String recordType) throws SQLException
    {

        List<String> rejCodes = Arrays.asList("NH", "FR", "NP", "PS", "RJ", "RP", "ID", "IP", "CE", "RD", "DP", "HS", "ND", "DB", "CT", "DD", "SR",
                "NA", "SN", "NX", "RS", "DN", "DS");
        Connection conn = gpConnect();
        List<String> countsList = new ArrayList<>();
        String query;
        String records[] = recordType.split(";");

        String rejects[] = records[1].split(",");
        PreparedStatement statement = null;
        Long count = null;

        for (String rej : rejects)
        {
            query = "select count(*) CNT from fusion_stage." + table + "  where fail_code ='" + rej + "' and record_status = 'R'";
            System.out.println("GP Query : " + query);
            // statement = greenPlumConnect.getConnection().prepareStatement(query);

            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();

            // ResultSet rs = statement.executeQuery();
            rs.next();
            count = rs.getLong("CNT");
            countsList.add(count.toString());
        }

        return countsList;

    }

    public Long getCountForFileRecordType(String table, String recordType) throws SQLException
    {

        Connection conn = gpConnect();

        String query;

        PreparedStatement statement = null;
        Long count = null;

        query = "select count(*) CNT from fusion_stage." + table + "  where acc_code ='" + recordType + "' and record_status != 'R'";
        System.out.println("GP Query : " + query);
        // statement = greenPlumConnect.getConnection().prepareStatement(query);

        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        count = rs.getLong("CNT");

        return count;

    }

    public static int getFilesCount(Path dir) throws IOException, NotDirectoryException
    {
        int c = 0;
        if (Files.isDirectory(dir))
        {
            try (DirectoryStream<Path> files = Files.newDirectoryStream(dir))
            {
                for (Path file : files)
                {
                    if (Files.isRegularFile(file) || Files.isSymbolicLink(file))
                    {
                        // symbolic link also looks like file
                        c++;
                    }
                }
            }
        } else
        {
            throw new NotDirectoryException(dir + " is not directory");
        }

        return c;
    }

    public String getErrorWarningMessage()
    {
        String s = driver.findElement(By.xpath("//div[@id='jqxWarnings']/div/div/table/tbody/tr[2]/td[3]")).getText();
        return s;
    }

    @Step("Clicked the FFF Process OP_Split work item stats")
    public void clickOT_GPSPLITstats(String assignedId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr[1]//following::tr[3]/td[3]/following::td[5]/a")).click();
    }

    public List<String> getFieldValueFromOpTable(String inputTable) throws SQLException
    {

        Connection conn = gpConnect();
        String query;

        List<String> rejectField = new ArrayList<>();

        query = "select num_trade from fusion_stage." + inputTable + " limit 5";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("num_trade");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            rejectField.add(column1);
        }

        return rejectField;

    }

    // op_ID_040
    public List<String> getdpSeqNumbersFromHeaderTableForAcc(String inputTable, String recType) throws SQLException
    {
        List<String> accCodes = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T",
                "U", "V", "W", "X", "Y", "Z");

        Connection conn = gpConnect();
        String recTypes[] = recType.split(",");
        String query;
        List<String> accField = new ArrayList<>();

        if (accCodes.contains(recTypes[0]))
        {
            query = "select dp_sequence_num from fusion_stage." + inputTable + "  where acc_code ='" + recTypes[0]
                    + "' and record_status != 'R' order by dp_sequence_num desc limit 5";
            System.out.println("GP Query : " + query);
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            int column1Pos = rs.findColumn("dp_sequence_num");

            while (rs.next())
            {
                String column1 = rs.getString(column1Pos);

                accField.add(column1);
            }
        }

        return accField;
        // statement = greenPlumConnect.getConnection().prepareStatement(query);

    }

    public List<String> getdpSeqNumbersFromHeaderTableForRej(String inputTable, String recType) throws SQLException
    {
        // selectField= "dp_sequence_number";
        List<String> rejCodes = Arrays.asList("NH", "FR", "NP", "PS", "RJ", "RP", "ID", "IP", "CE", "RD", "DP", "HS", "ND", "DB", "CT", "DD", "SR",
                "NA", "SN", "NX", "RS", "DN", "DS");

        Connection conn = gpConnect();
        String recTypes[] = recType.split(",");
        String query;

        List<String> rejectField = new ArrayList<>();
        if (rejCodes.contains(recType))
        {
            query = "select dp_sequence_num from fusion_stage." + inputTable + "  where fail_code ='" + recTypes[0]
                    + "' limit 5";
            System.out.println("GP Query : " + query);
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            int column1Pos = rs.findColumn("dp_sequence_num");

            while (rs.next())
            {
                String column1 = rs.getString(column1Pos);

                rejectField.add(column1);
            }

        }
        return rejectField;
        // statement = greenPlumConnect.getConnection().prepareStatement(query);

    }

    public List<String> getUpdatedDefaultValForAptNum(String opTable) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();

        query = "select apt_no from fusion_stage." + opTable + " limit 5";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("apt_no");
        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            fieldValue.add(column1);
        }
        return fieldValue;
    }

    public List<String> getDpSeqNumForEmptyAptNum(String inputTable) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();

        query = "select dp_sequence_num from fusion_stage." + inputTable + " limit 5";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("dp_sequence_num");
        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            fieldValue.add(column1);
        }
        return fieldValue;
    }

    public List<String> getAptNumUpdatedValue(List<String> seqNum, String opTable) throws SQLException
    {

        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();
        for (String dp : seqNum)
        {
            query = "select CITY from fusion_stage." + opTable + "  where dp_sequence_num =" + dp;
            System.out.println("GP Query : " + query);
            // statement = greenPlumConnect.getConnection().prepareStatement(query);

            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            int column1Pos = rs.findColumn("CITY");
            while (rs.next())
            {
                String column1 = rs.getString(column1Pos);
                fieldValue.add(column1);
            }
        }
        return fieldValue;
    }

    public String getRandomDpSequenceNum(String inputTable) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        String sequenceNum = null;

        query = "select dp_sequence_num from fusion_stage." + inputTable + "  limit 1";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("dp_sequence_num");
        rs.next();
        sequenceNum = rs.getString(column1Pos);

        return sequenceNum;
    }

    public List<String> getMoveFieldValueForSelectedDpSeqNum(String field, String outputTable, List<String> finalList) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();
        for (int i = 0; i < finalList.size(); i++)
        {
            query = "select " + field + " from fusion_stage." + outputTable + " where dp_sequence_num ='" + finalList.get(i) + "'";
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            int column1Pos = rs.findColumn(field);
            rs.next();
            String column1 = rs.getString(column1Pos);
            fieldValue.add(column1);
        }

        return fieldValue;
    }
    public List<String> getRecordWhereMoveStatementNOtPerformed(String field, String outputTable ,String dataToOuptut)throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<String>();
        query = "select dp_sequence_num from fusion_stage." + outputTable + " where + field + ='" + dataToOuptut + "'"+" limit 5";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn(field);
        while( rs.next()){
            String column1 = rs.getString(column1Pos);
            fieldValue.add(column1);

        }
        return fieldValue;
    }


    public List<String> getSortListSeqByGpNum(String field, String splitTable) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();
        query = "select dp_sequence_num from fusion_stage." + splitTable + "where " + field + "!=" + 0 + " order by gp_sequence_num asc";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn(field);
        rs.next();
        String column1 = rs.getString(column1Pos);
        fieldValue.add(column1);

        return fieldValue;
    }

    public List<String> getSortListSeqByFieldName(String field, String splitTable) throws SQLException
    {
        String query = null;
        Connection conn = gpConnect();
        List<String> fieldValue = new ArrayList<>();
        query = "select dp_sequence_num from fusion_stage." + splitTable + "where " + field + "!=" + 0 + " order by " + field + " asc";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn(field);
        rs.next();
        String column1 = rs.getString(column1Pos);
        fieldValue.add(column1);

        return fieldValue;
    }

    public List<String> getRowColumnVauesForSelectedDpSeqNum(String outputTable, String seqNum) throws SQLException
    {
        String object = null;
        String query = null;
        Connection conn = gpConnect();
        List<String> values = new ArrayList<>();
        query = "select * from fusion_stage." + outputTable + " where dp_sequence_num = " + seqNum;
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData metaData = rs.getMetaData();
        int columnCount = metaData.getColumnCount();
        rs.next();
        for (int columnIndex = 1; columnIndex <= columnCount; columnIndex++)
        {
            object = rs.getString(columnIndex);
            System.out.printf("%s, ", object == null ? "NULL" : object.toString());
            values.add(object);
        }

        return values;

    }

    public boolean validateMoveSuccessful(List<String> fieldValues)
    {
        boolean status = false;
        for (String val : fieldValues)
        {
            {
                status = true;
            }
        }
        return status;
    }

    public Long getInputCountForPaddedField(String inputTable) throws SQLException
    {

        String query = null;
        Connection conn = gpConnect();
        query = "select COUNT(*) AS CNT from fusion_stage." + inputTable + " where  cnx_key is null";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        Long count = rs.getLong("CNT");
        return count;
    }

    public Long getTheCountOf(String inputTable) throws SQLException
    {

        String query = null;
        Connection conn = gpConnect();
        query = "select COUNT(*) AS CNT from fusion_stage." + inputTable + " where  cnx_key is null";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        Long count = rs.getLong("CNT");
        return count;
    }

    public Long getTheTotalCountOfRecordsInGroups(List<String> grpList)
    {
        Long totalRecord=0L;

        for(String grp:grpList)
        {
            String record=	driver.findElement(By.xpath("//div[contains(text(),'Total Output:"+grp+"')]//following::div[2]")).getText().replaceAll(",","");

            totalRecord=totalRecord+Long.valueOf(record);
        }
        return totalRecord;
    }


    public Long getCappingTblCountForPaddedField(String opTable) throws SQLException
    {
        String object = null;
        String query = null;
        Connection conn = gpConnect();
        List<String> values = new ArrayList<>();
        query = "select COUNT(*) AS CNT from fusion_stage." + opTable + " where cnx_key = 0";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        Long count = rs.getLong("CNT");
        return count;
    }

    public Long getCountForFieldWithDefaultpadding(String table) throws SQLException
    {
        String object = null;
        String query = null;
        Connection conn = gpConnect();
        List<String> values = new ArrayList<>();
        query = "select COUNT(*) AS CNT from fusion_stage." + table + " where acc_code is null";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        // ResultSet rs = statement.executeQuery();
        rs.next();
        Long count = rs.getLong("CNT");
        return count;
    }

    @Step("Fetch Number of masked columns ")
    public String getMaskedColumnsCount()

    {
        return driver.findElement(By.xpath("//div[contains(text(),'Number of masked columns')]/following::div[1]")).getText();

    }

    @Step("Fetch Number of scrambled columns ")
    public Integer getScrambledColumnsCount()

    {
        return driver.findElements(By.xpath("//div[contains(text(),'Number of scrambled columns')]/following::div[1]")).size();

    }

    public int readLayoutFileToGetTestDataColumnCount(String path)
    {
        int count = 0;
        try
        {
            String verify;
            File file = new File(path);

            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            while ((verify = br.readLine()) != null)
            {

                String linesplit[] = verify.split(",");
                String isTestLayout = linesplit[linesplit.length - 1];
                if ("Y".equals(isTestLayout))
                {
                    count++;
                }

            }
            br.close();

        } catch (IOException e)
        {
            e.printStackTrace();
        }
        return count;
    }

    @Step("Fetch the table Name from the stats")
    public String fetchTheTableName()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'OUTPUT CAPPING VIEW')]/parent::div//div[2]")).getText();

    }

    public List<String> fetchTheValuesOfMDBDateColumn(String outputTable) throws SQLException
    {

        String query = null;
        Connection conn = gpConnect();
        List<String> colValues = new ArrayList<>();
        query = "select mdb_date from fusion_stage." + outputTable + " limit 5";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int colIndex=rs.findColumn("mdb_date");
        while(rs.next())
        {
            colValues.add(rs.getString(colIndex));
        }

        return colValues;

    }

    public List<String> fetchTheTableNames() throws SQLException
    {
        List<String> tableNames=new ArrayList<String>();
        tableNames.add(driver.findElement(By.xpath("//div[contains(text(),'Datamenu LCR Table')]/following::div[1]")).getText());
        tableNames.add(driver.findElement(By.xpath("//div[contains(text(),'Datamenu HEADER Table')]/following::div[1]")).getText());
        return tableNames;

    }
    @Step("Fetch the Output File Path")
    public String fetchTheOutputFilePath()
    {
        return driver.findElement(By.xpath("//div[starts-with(text(),'Output Folder')]/parent::div/div[2]")).getText();
    }
    //    @Step("Fetch the Output File Path")
    //    public String fetchTheOutputFilePath()
    //    {
    //        return driver.findElement(By.xpath("//div[starts-with(text(),'Output Folder')]/parent::div/div[2]")).getText();
    //    }
    public boolean readFileAndFetchTheResult(String path,int startPos,int endPos) throws SQLException
    {
        boolean matched=false;File f = null;
        String recordFromTable = null;
        try
        {
            f = new File(path);
            if (f.exists() && !f.isDirectory())
            {
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {

                    String sCurrentLine;
                    int i=0;
                    while ((sCurrentLine = br.readLine()) != null && i<5)
                    {
                        System.out.println(sCurrentLine);
                        int spaceCount=0;

                        String fetchedDataForField1 = sCurrentLine.substring(startPos,endPos);
                        if(fetchedDataForField1.equalsIgnoreCase("20170530"))
                        {
                            matched=true;
                        }
                        else
                        {
                            matched=false;
                        }

                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

            } else
            {

                System.out.println("file not found !!!!");

            }
        }
        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }



        return matched;

    }

    /*    public List<String> fetchTheRecordTypeDistribution()
    {
    List<String> fetchedRecordDistribution=new ArrayList<String>();
    List<WebElement> elements = driver.findElements(By.xpath("//div[contains(text(),'.fixed')]//following::div[contains(text(),'Record Type Distribution')]//parent::div//following::div/div[1]"));
    for(int i = 0; i < elements.size(); ++i)
    {
       // String fetchedRecord = elements.get(i).findElement(By.xpath("./div[1]")).getText();
    	 String fetchedRecord = elements.get(i).getText();
        String[] fetchedRecordArr=fetchedRecord.split(":");
    if(!fetchedRecordArr[0].isEmpty()){
        String record=fetchedRecordArr[0].replaceAll("\\s+","");

        String[] recArr=record.split("-");
        fetchedRecordDistribution.add(recArr[0].trim());
    }

    }
    return fetchedRecordDistribution;
    }*/
    public Integer CountOfSplitFileCreated()
    {
        return Integer.parseInt(driver.findElement(By.xpath("//div[contains(text(),'Number of split files created')]/following::div[1]")).getText());
    }

    public Long clickToViewStatsOfOpGPCapItem(String stackId,String opId)
    {
        driver.findElement(By.xpath("//span[starts-with(text(),'"+stackId+"')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[starts-with(text(),'"+opId+"')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[starts-with(text(),'OT_GPCAP')]//parent::td//following::td[6]//a")).click();
        String recordsSelectedForProcessing= driver.findElement(By.xpath("//div[starts-with(text(),'Input Records Selected For Processing')]//following::div[1]")).getText().replaceAll(",","").replaceAll("\\s+","");
        Long recordCount=Long.valueOf(recordsSelectedForProcessing);
        return recordCount;
    }
    public Long clickToViewStatsOfOpGPCapItem(String stackId,String opId,String group)
    {
        driver.findElement(By.xpath("//span[starts-with(text(),'"+stackId+"')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[starts-with(text(),'"+opId+"')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[starts-with(text(),'FILTER_GPFILTER')]//parent::td//following::td[6]//a")).click();
        String recordsSelectedForProcessing= driver.findElement(By.xpath("//div[starts-with(text(),'"+group+"')]//following::div[3]//div[3]")).getText().replaceAll(",","").replaceAll("\\s+","");
        Long recordCount=Long.valueOf(recordsSelectedForProcessing);
        return recordCount;
    }
    public String getTheTitleFromDCReport()
    {
        return	driver.findElement(By.xpath("//div[@id='popupTitle']//div[1]")).getText();
    }

    public String getTheErrorMessageFromStats()
    {
        return  driver.findElement(By.xpath("//div[@id='css3table']//tr[2]/td[3]")).getText();
    }

    public String getTheStatusAndViewErrorStats(String opId) throws InterruptedException
    {
        WebElement elem = driver.findElement(By.xpath("//span[contains(text(),'" + opId + "')]//following::td[6]/div"));
        new Actions(driver).moveToElement(elem).click().perform();
        elem.click();
        //driver.findElement(By.xpath("//span[starts-with(text(),'"+opId+"_')]//preceding::span[1]")).click();
        //driver.findElement(By.xpath("//span[starts-with(text(),'"+opId+":')]//preceding::span[1]")).click();
        String status=  driver.findElement(By.xpath("//span[starts-with(text(),'OT_GPEXPORT')]//parent::td//following::td[2]/div")).getText();
        driver.findElement(By.xpath("//span[starts-with(text(),'OT_GPEXPORT')]//parent::td//following::td[6]//a")).click();
        Thread.sleep(4000);
        driver.findElement(By.xpath("//li[@id='jqxSummaryJobTabsTab2']")).click();

        return status;
    }
    @Step("Check whether the digits are scrambled or not")
    public static boolean isDigitsScrambled(String a, String b) {
        if (a == null) {
            return b == null;
        } else if (b == null) {
            return false;
        }
        char[] left = a.toCharArray();
        char[] right = b.toCharArray();
        Arrays.sort(left);
        Arrays.sort(right);
        return Arrays.equals(left, right);
    }
    //span[starts-with(text(),'FILTER_GPFILTER')]//parent::td//following::td[6]//a

    @Step("Fetchinh The Count Of Files Formed")
    public Integer getTheCountOfFilesFormed()
    {
        List<WebElement> elementList=driver.findElements(By.xpath("//div[contains(text(),'.fixed')]"));
        int countOfFilesFormed=elementList.size();
        return  countOfFilesFormed ;
    }
    public boolean isMoveStatementCorrectlyPerformed(String inputTable) throws SQLException
    {

        Connection conn = gpConnect();
        // String recTypes[] = recType.split(",");
        boolean isPerformed=false;
        String query;

        List<String> records = new ArrayList<>();

        query = "select num_trade from fusion_stage." + inputTable + " LIMIT 5";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        // int column1Pos = rs.findColumn("dp_sequence_num");
        int column1Pos = rs.findColumn("num_trade");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            records.add(column1);
        }
        for(String record:records)
        {
            if(record.equalsIgnoreCase("10"))
            {
                isPerformed=true;
            }
        }
        return isPerformed;


    }
    
    public Integer fetchTheNumberOfHeaderRecordsWritten()
    {
    
    	return Integer.valueOf(driver.findElement(By.xpath("//*[starts-with(text(),'File')]//following::div[starts-with(text(),'Number of Header records written')]/parent::div/div[2]")).getText());
    }
    public Long fetchAcceptRecords(String inputTable) throws SQLException
    {

        Connection conn = gpConnect();
        // String recTypes[] = recType.split(",");
    	//long records = 0;
        String query;

     

        query = "select count(*) from fusion_stage." + inputTable + " where fail_code is null";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        // int column1Pos = rs.findColumn("dp_sequence_num");
       // int column1Pos = rs.findColumn("num_trade");

    	long records = 0;
		while (rs.next()) {
			records = rs.getLong(1)+1;
		}
		conn.close();
		return records;
        


    }
    public Long fetchRejectRecords(String inputTable) throws SQLException
    {

        Connection conn = gpConnect();
        // String recTypes[] = recType.split(",");
    	//long records = 0;
        String query;

     

        query = "select count(*) from fusion_stage." + inputTable + " where fail_code is not null";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        // int column1Pos = rs.findColumn("dp_sequence_num");
       // int column1Pos = rs.findColumn("num_trade");

    	long records = 0;
		while (rs.next()) {
			records = rs.getLong(1)+1;
		}
		conn.close();
		return records;
        


    }
    public List<Long> fetchTheRecordsPerFile(String fileName)
    {
    	List<Long> records=new ArrayList<Long>();
    	String[] fileArr= fileName.split(",");
    	List<String> fileNameList=Arrays.asList(fileArr);
    	for(String name:fileNameList)
    	{
    		String value=driver.findElement(By.xpath("//*[starts-with(text(),'File "+name+"')]//following::div")).getText().replaceAll(",","").replaceAll("\\s+","");
    		records.add(Long.valueOf(value));
        }
    	
    return records;
    }
    public String fetchTheHeading()
    {
    
    	return driver.findElement(By.xpath(" //div[contains(text(),'File Accepts.csv')]//following::div[contains(text(),'Number of masked columns')]//parent::div//preceding::div[1]/parent::div/div[1]")).getText();
    }
 
}

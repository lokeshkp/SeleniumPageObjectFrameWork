package com.equifax.cms.fusion.test.MJpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

public class MatchJoinStatsView
{
    WebDriver driver;

    public MatchJoinStatsView(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    public Long getCountOfMasterRecMatched()
    {
        return Long.parseLong(RemoveComma(
                driver.findElement(By.xpath(".//*[contains(text(),'The number of records in the Master table that matched')]/following-sibling::div"))
                .getText()));
    }

    public Long getCountOfMasterRecNotMatched()
    {
        return Long
                .parseLong(RemoveComma(driver
                        .findElement(By
                                .xpath(".//*[contains(text(),'The number of records in the Master file that did not match')]/following-sibling::div"))
                                .getText()));
    }

    public Long getCountOfMatchRecNotMatched()
    {
        return Long
                .parseLong(RemoveComma(driver
                        .findElement(By
                                .xpath(".//*[contains(text(),'The number of records in the Match table that did not match')]/following-sibling::div"))
                                .getText()));
    }

    public Long getCountOfMasterRecordsInTable()
    {
        return Long.parseLong(RemoveComma(
                driver.findElement(By.xpath(".//*[contains(text(),'Count of records in the Master table')]//following::div[1]")).getText()));
    }

    public Long getCountOfMasRecSelecProcessing()
    {
        return Long.parseLong(RemoveComma(driver
                .findElement(By.xpath(".//*[contains(text(),'Count of master records selected for processing')]/following::div[1]")).getText()));
    }

    public Long getCountOfMatchRecordsInTable()
    {
        return Long.parseLong(RemoveComma(
                driver.findElement(By.xpath(".//*[contains(text(),'Count of records in the Match table')]//following::div[1]")).getText()));
    }

    public Long getCountOfMatRecSelecProcessing()
    {
        return Long.parseLong(RemoveComma(
                driver.findElement(By.xpath(".//*[contains(text(),'Count of Match Records selected for processing')]/following::div[1]")).getText()));
    }
    public Long getCountOfRecordsInMasterTable()
    {
        return Long.parseLong(RemoveComma(
                driver.findElement(By.xpath(".//*[contains(text(),'Count of records in the Master table ')]/following::div[1]")).getText()));
    }

    public String getAppendedColumnNames()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'The names of columns added')]//following::div[1]")).getText();
    }


    @Step("{method}")
    public static String RemoveComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }

}

package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class JobExecutionDetails
{

    WebDriver driver;

    public JobExecutionDetails(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//label[contains(text(), 'Name:')]")
    WebElement Ele_ProcessID;

    @FindBy(id = "scheduleName")
    WebElement schedule_Name;

    @FindBy(id = "processId")
    WebElement processId;

    @FindBy(id = "state1")
    WebElement activeState;

    @FindBy(id = "state2")
    WebElement inactiveState;

    @FindBy(id = "jobNotifyEmailIds")
    WebElement jobNotify_EmailIds;

    @FindBy(id = "allNotifyEmailIds")
    WebElement allNotify_EmailIds;

    @FindBy(id = "failureNotifyEmailIds")
    WebElement failureNotify_EmailIds;

    @FindBy(xpath = ".//*[@id='automationForm']/div/a")
    WebElement back_Button;

    @FindBy(xpath = ".//*[@id='automationForm']/div/input[1]")
    WebElement save_Button;

    @FindBy(xpath = ".//*[@id='automationForm']/div/input[2]")
    WebElement continue_Button;

    public void setProcessName(String processName)
    {
        schedule_Name.clear();
        schedule_Name.sendKeys(processName);
    }

    @Step("Get the Process Id")
    public String getProcId()
    {
        String[] a = Ele_ProcessID.getText().split(":");
        System.out.println("Process Id: " + a[1]);
        String value = a[1].trim();
        return value;
    }

    @Step("Select Process Field = \"{0}\"")
    public void selectProcessField(String process)
    {
        Select sl = new Select(processId);
        sl.selectByVisibleText(process);
    }

    public void setjobNotifyEmailId(String jobMail)
    {
        jobNotify_EmailIds.clear();
        jobNotify_EmailIds.sendKeys(jobMail);
    }

    public void setallNotifyEmailIds(String allMail)
    {
        allNotify_EmailIds.clear();
        allNotify_EmailIds.sendKeys(allMail);
    }

    public void setfailureNotifyEmailIds(String failureMail)
    {
        failureNotify_EmailIds.clear();
        failureNotify_EmailIds.sendKeys(failureMail);
    }

    public void setActiveState()
    {
        activeState.click();
    }

    public void setInactiveState()
    {
        inactiveState.click();
    }

    public void clickBackButton()
    {
        back_Button.click();
    }

    public void clickSave()
    {
        save_Button.click();
    }

    public void clickContinue()
    {
        continue_Button.click();
    }
}

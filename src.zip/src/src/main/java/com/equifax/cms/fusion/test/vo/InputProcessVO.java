package com.equifax.cms.fusion.test.vo;

public class InputProcessVO extends AbsctractVO {

	String type;
	String purpose;
	String location;
	String format;
	String recordLength;
	String startingSeq;
	private String inputLayout;
	private String layoutName;
    private String layoutNameNew;
    String delimiter;
    String isDataCheck;
    String fileIdentifier;
    String blankFields;
    String singleValueFields;
    String unknownFields;
    String runtimeB;
    String searchLayoutFromOtherProj;

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getFormat() {
		return format;
	}

	public void setFormat(String format) {
		this.format = format;
	}

	public String getRecordLength() {
		return recordLength;
	}

	public void setRecordLength(String recordLength) {
		this.recordLength = recordLength;
	}

	public String getStartingSeq() {
		return startingSeq;
	}

	public void setStartingSeq(String startingSeq) {
		this.startingSeq = startingSeq;
	}

	@Override
	public String toString() {
		StringBuilder sb = new StringBuilder(super.toString())
				.append("Type : ")
				.append(type)
				.append("\nPurpose : ")
				.append(purpose)
				.append("\nLocation : ")
				.append(location)
				.append("\nFormat : ")
				.append(format);
		return sb.toString();
	}

	public String getInputLayout() {
		return inputLayout;
	}

	public void setInputLayout(String inputLayout) {
		this.inputLayout = inputLayout;
	}

	public String getLayoutName() {
		return layoutName;
	}

	public void setLayoutName(String layoutName) {
		this.layoutName = layoutName;
	}

    public String getDelimiter()
    {
        return delimiter;
    }

    public void setDelimiter(String delimiter)
    {
        this.delimiter = delimiter;
    }

    public String getIsDataCheck()
    {
        return isDataCheck;
    }

    public void setIsDataCheck(String isDataCheck)
    {
        this.isDataCheck = isDataCheck;
    }

    public String getFileIdentifier()
    {
        return fileIdentifier;
    }

    public void setFileIdentifier(String fileIdentifier)
    {
        this.fileIdentifier = fileIdentifier;
    }

    public String getBlankFields()
    {
        return blankFields;
    }

    public void setBlankFields(String blankFields)
    {
        this.blankFields = blankFields;
    }

    public String getSingleValueFields()
    {
        return singleValueFields;
    }

    public void setSingleValueFields(String singleValueFields)
    {
        this.singleValueFields = singleValueFields;
    }

    public String getUnknownFields()
    {
        return unknownFields;
    }

    public void setUnknownFields(String unknownFields)
    {
        this.unknownFields = unknownFields;
    }

    public String getRuntimeB()
    {
        return runtimeB;
    }

    public void setRuntimeB(String runtimeB)
    {
        this.runtimeB = runtimeB;
    }

    public String getSearchLayoutFromOtherProj()
    {
        return searchLayoutFromOtherProj;
    }

    public void setSearchLayoutFromOtherProj(String searchLayoutFromOtherProj)
    {
        this.searchLayoutFromOtherProj = searchLayoutFromOtherProj;
    }

    public String getLayoutNameNew()
    {
        return layoutNameNew;
    }

    public void setLayoutNameNew(String layoutNameNew)
    {
        this.layoutNameNew = layoutNameNew;
    }

}

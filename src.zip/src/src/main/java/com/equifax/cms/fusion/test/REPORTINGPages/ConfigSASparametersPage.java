package com.equifax.cms.fusion.test.REPORTINGPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ConfigSASparametersPage {

	WebDriver driver;
	public Select sel; 
	public ConfigSASparametersPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}

	@FindBy(xpath = "//img[@alt='edit']")
	WebElement SelectDataImg;

	@FindBy(id = "fromProcessId")
	WebElement ProcessFld;

	@FindBy(id = "itemTableId")
	WebElement DataFld;

	@FindBy(xpath = "//a[contains(text(),'Save')]")
	WebElement ProcDataSaveBtn;
	
	@FindBy(xpath = "//input[@value='Save']")
	WebElement SaveBtn;

	@FindBy(xpath = "(//input[@name='submitButton'])[3]")
	WebElement ContinueBtn;

	@Step("Clicked on Data Image")
	public void clickDataImg(){
		SelectDataImg.click();
	}

	@Step("Provided Process field = \"{0}\"")
	public void selectProcessFld(String process){
		sel = new Select(ProcessFld);
		sel.selectByVisibleText(process);
	}

	@Step("Provided Data field = \"{0}\"")
	public void selectDataFld(String data){
		sel = new Select(DataFld);
		sel.selectByVisibleText(data);
	}

	@Step("Clicked Process & Data Save button")
	public void clickProcDataSaveBtn(){
		ProcDataSaveBtn.click();
	}
	
	@Step("Clicked Save button")
	public void clickSaveBtn(){
		SaveBtn.click();
	}

	@Step("Clicked Continue button")
	public void clickContinueBtn(){
		ContinueBtn.click();
	}
}

package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class ModuleOutputsPage {

		WebDriver driver;
		public String DynamicIdJXHKON_MAP;
		public String DynamicIdJXHKON_IDSCN;
		
	public ModuleOutputsPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "numPerAccept")
	WebElement Ele_NumerAccCode;
	
	@FindBy(id = "numPerReject")
	WebElement Ele_NumperRejCode;
	
	@FindBy(id = "holdForMove")
	WebElement HoldAddiDataAppend;
	
	@FindBy(xpath = "//input[@class='apModuleName']")
	public WebElement OutputTblName;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement ContinueButton;
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[1]/label[1]")
	WebElement ErrorMessageAudit_Accepts;
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[1]/label[2]")
	WebElement ErrorMessageAudit_Rejects;
	
	@FindBy(xpath = ".//*[@value='MAP001']")
	WebElement OutputTableNameJXHTestKontable;
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[2]/label")
	WebElement ErrorMessage;

	@FindBy(xpath = ".//*[@value='IDSCAN']")
	WebElement OutputTableNameJXHTestKonIDScan;

	@Step("Clear Output Table Name for JXH_TEST_KONTABLE IDSCAN")
	public void ClearOutputTableNameJXHTESTKONIDScan(){
		OutputTableNameJXHTestKonIDScan.clear();
	}

	@Step("Input Output Table Name for JXH_TEST_KONTABLE IDSCAN : \"{0}\" ")
	public void InputOutputTableNameJXHTESTKONIDScan(String Name){
		OutputTableNameJXHTestKonIDScan.clear();
		OutputTableNameJXHTestKonIDScan.sendKeys(Name);
		DynamicIdJXHKON_IDSCN = OutputTableNameJXHTestKonIDScan.getAttribute("id");
	}

	@Step("Get Error Message")
	public String getErrorMessage(){
		return ErrorMessage.getText();
	}
	
	@Step("Input Output Table Name for JXH_TEST_KONTABLE MAP001 : \"{0}\" ")
	public void InputOutputTableNameJXHTESTKON(String Name){
		OutputTableNameJXHTestKontable.clear();
		OutputTableNameJXHTestKontable.sendKeys(Name);
		DynamicIdJXHKON_MAP = OutputTableNameJXHTestKontable.getAttribute("id");
	}

	@Step("Clear Output Table Name for JXH_TEST_KONTABLE MAP001")
	public void DynClearOutputTableNameJXHTESTKONMAP(){
		driver.findElement(By.id(DynamicIdJXHKON_MAP)).clear();
	}

	@Step("Clear Output Table Name for JXH_TEST_KONTABLE IDSCAN")
	public void DynClearOutputTableNameJXHTESTKON_IDSCN(){
		driver.findElement(By.id(DynamicIdJXHKON_IDSCN)).clear();
	}
	

	@Step("Input Output Table Name for JXH_TEST_KONTABLE MAP001 : \"{0}\" ")
	public void DynInputOutputTableNameJXH_KON_MAP(String Name){
		driver.findElement(By.id(DynamicIdJXHKON_MAP)).clear();
		driver.findElement(By.id(DynamicIdJXHKON_MAP)).sendKeys(Name);
	}

	@Step("Input Output Table Name for JXH_TEST_KONTABLE IDSCAN : \"{0}\" ")
	public void DynInputOutputTableNameJXH_KON_IDSCN(String Name){
		driver.findElement(By.id(DynamicIdJXHKON_IDSCN)).clear();
		driver.findElement(By.id(DynamicIdJXHKON_IDSCN)).sendKeys(Name);
	}

	@Step("Get Error Message Accepts")
	public String getErrorMessage_Accepts(){
		return ErrorMessageAudit_Accepts.getText();
	}

	@Step("Get Error Message Rejects")
	public String getErrorMessage_Rejects(){
		return ErrorMessageAudit_Rejects.getText();
	}

	@Step("Input Number Per Accept Code : \"{0}\" ")
	public void InputnumperAcceptCodeField(String accValue){
		Ele_NumerAccCode.clear();
		Ele_NumerAccCode.sendKeys(accValue);
	}

	@Step("Input Number Per Reject Code : \"{0}\" ")
	public void InputnumperRejectCodeField(String rejValue){
		Ele_NumperRejCode.clear();
		Ele_NumperRejCode.sendKeys(rejValue);
	}

	@Step("Click Hold Data Append")
	public void clickHoldAddiDataAppend(){
		HoldAddiDataAppend.click();
	}

	@Step("Provided the Output table Name = \"{0}\"")
	public void inputOutputTbleName(String tblName){
		OutputTblName.clear();
		OutputTblName.sendKeys(tblName);
	}
	
	@Step("Click Continue Button on Module Outputs Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
}

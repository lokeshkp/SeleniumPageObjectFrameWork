package com.equifax.cms.fusion.test.OPPages;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class OpRecordTypesPage
{

    WebDriver driver;

    public OpRecordTypesPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "(.//*[@type='radio'])[2]")
    public WebElement recordGroup_RB;

    @FindBy(xpath = "(.//*[@type='radio'])[1]")
    public WebElement recordType_RB;

    //@FindBy(xpath = "((.//*[@value='RECORD_TYPE']))[1]")
    @FindBy(xpath = "((.//*[@value='RECORD_TYPE']))[2]")
    WebElement recordType_RB2;

    @FindBy(xpath = "(.//*[@id='splitSelectionType'])[1]")
    WebElement ByRecType;

    @FindBy(id = "fileText")
    WebElement Ele_FileName;

    @FindBy(xpath = ".//a[contains(text(),'All Records')]")
    WebElement Ele_AllRecords;

    @FindBy(xpath = ".//img[@alt='Add']")
    WebElement Ele_Forward;

    @FindBy(xpath = ".//img[@alt='Remove']")
    WebElement Ele_Remove;

    @FindBy(id = "addNewFile")
    WebElement AddFile_btn;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = "(//input[@id='chkWarning'])")
    WebElement warningButton;

    public void clickToCheckWarning()
    {
        warningButton.click();
    }


    public void clickOkPopup()
    {
        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
    }

    public void clickCancelPopup()
    {
        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[2]")).click();
    }

    @Step("Is Add File Button Disabled ")
    public boolean isAddFileButtonDisabled()
    {
        boolean  isDisabled=false;
        if( driver.findElement(By.xpath("  //input[@id='addNewFile']")).getAttribute("class").equalsIgnoreCase("large-button-split disabledbutton"))
        {
            isDisabled=true;
        }
        return isDisabled;
    }
    public List<String> getFileNames()
    {
        List<String> fileNameList=new ArrayList<String>();
        List<WebElement> elements= driver.findElements(By.xpath("//*[contains(@id,'fileText')]"));
        for(WebElement ele:elements)
        {
            fileNameList.add(ele.getAttribute("value"));
        }
        return fileNameList;
    }
    public String getFirstFileName()
    {
        return driver.findElement(By.xpath(".//*[@id='fileText0']")).getAttribute("value");
    }

    public String getSecondFileName()
    {
        return driver.findElement(By.xpath(".//*[@id='fileText1']")).getAttribute("value");
    }

    public void selectSplitRecord(String record, String process)
    {
    	//driver.switchTo().frame("sb-player");
        if ("Record Type".equalsIgnoreCase(record))
        {
        	//if ("MJ".startsWith(process) || "RN".startsWith(process) || "FL".startsWith(process))
            if (process.startsWith("MJ") || process.startsWith("RN") || process.startsWith("FL") || process.startsWith("DNS") || process.startsWith("MLA") )
            {
                if (!recordType_RB.isSelected())
                {
                    recordType_RB.click();
//                    if (driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).isDisplayed())
//                    {
//                        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
//                    }
                }

            } else
            {
                if (!recordType_RB2.isSelected())
                {
                    recordType_RB2.click();
//                    if (driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).isDisplayed())
//                    {
//                        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
//                    }
                }

            }
        } else if ("Record Groups".equalsIgnoreCase(record))
        {
            if (!recordGroup_RB.isSelected())
            {
                recordGroup_RB.click();
//                if (driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).isDisplayed())
//                {
//                    driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
//                }
            }
        }
    }

    public void selectSplitRecord_RB(String splitRecords)
    {
        if ("Record Type".equalsIgnoreCase(splitRecords))
        {
            if (!recordType_RB.isSelected())
            {
                recordType_RB.click();
                /*if (driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).isDisplayed())
                {
                    recordType_RB.click();
                    driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
                }*/
            }
        } else if ("Record Groups".equalsIgnoreCase(splitRecords))
        {
            if (!recordGroup_RB.isSelected())
            {
                recordGroup_RB.click();
                if (driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).isDisplayed())
                {
                    driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
                }
            }

        }

    }

    @Step("Provide File Name = \"{0}\"")
    public void inputfileName(String filename, int i)
    {
        driver.findElement(By.xpath("(.//*[@class='fileText'])[" + i + "]")).sendKeys(filename);
    }

    public void inputFileNameUI(String FileName)
    {
        driver.findElement(By.xpath(".//*[@id='fileText']")).sendKeys(FileName);
    }

    public void clickPopUpOk()
    {
        driver.findElement(By.id("popup_ok")).click();
    }

    public boolean isPopUpDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            String aa = driver.findElement(By.id("popup_container")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.xpath(".//*[@class='error']")).getText();
    }

    @Step("Select All Records")
    public void clickAllRecords()
    {
        Ele_AllRecords.click();
    }

    @Step("Click forward button")
    public void clickForward()
    {
        Ele_Forward.click();
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public static void selectRecordTypes1(String record, String fileName)
    {
        String delims1 = ";";
        String delims2 = ",";
        String splitString1 = fileName;
        String NCPsplitString1 = record;
        StringTokenizer stMain = new StringTokenizer(splitString1, delims1);
        StringTokenizer NCPstMain = new StringTokenizer(NCPsplitString1, delims1);

        /*
         * if(record.equalsIgnoreCase("All Records")){ String dynpath = ".//a[contains(text(),'"+ record +"')]";
         * driver.findElement(By.xpath(dynpath)).click(); }
         */

        while (stMain.hasMoreElements())
        {
            // fileNameField(fileName);

        }

    }
    public boolean isRecordTypesSelectionDisabled()
    {
        boolean isDisabled=false;
        String className=driver.findElement(By.xpath("//*[contains(text(),'Available Record Types/Groups')]/following::div")).getAttribute("class");
        if(className.equals("content1 disabledbutton"))

        {
            isDisabled=true;
        }
        return isDisabled;
    }


    public void selectRecTypes(String fileName)
    {
        String delims1 = ";";
        String comma = ",";
        int i = 1;
        StringTokenizer stMain = new StringTokenizer(fileName, delims1);
        while (stMain.hasMoreElements())
        {
            String[] splitString = stMain.nextToken().split(comma);
            String dynPath = ".//a[contains(text(),'" + splitString[0] + "')]";
            driver.findElement(By.xpath(dynPath)).click();
            clickForward();
            driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[3]/div/div/div/div/div[" + i + "]/div[1]/input"))
            .sendKeys(splitString[1]);
        }
        i++;
        AddFile_btn.click();
    }

    public void removeSelectedRecords()
    {

        driver.findElement(By.xpath("//div[@class='selected-fields_fileSplit selected-fields_recType']/div[3]/div[1]/ul/li")).click();
        Ele_Remove.click();
        driver.findElement(By.xpath("//div[@class='selected-fields_fileSplit selected-fields_recType']/div[3]/div[2]/ul/li")).click();
        Ele_Remove.click();

    }
    public void removeSelectedFile(String fileName)
    {
        driver.findElement(By.xpath("//input[@value='"+fileName+"']//following::a[1]/img")).click();
        /*String[] recTypeArr=recordType.split(",");
        List<String> recList=Arrays.asList(recTypeArr);
        for(String rec:recList)
        {
            driver.findElement(By.xpath("//span[@id='"+rec+"']//parent::li")).click();
            Ele_Remove.click();
        }



            for (int j = 0; j < recTypeArr.length; j++)
            {

                    List<WebElement> elements= driver.findElements(By.xpath("//li[starts-with(@title,'" + recTypeArr[j] + "')]"));

                    for(WebElement ele:elements)
                    {
                        String styleEle=ele.getAttribute("style");
                        if(!styleEle.equalsIgnoreCase("display: none;"))
                        {
                            String id=ele.getAttribute("id");
                            driver.findElement(By.xpath("//li[@id='"+id+"']//a")).click();
                        }

                    }

                }
                driver.findElement(By.xpath("(.//*[@alt='Remove'])[" + (j + 1) + "]")).click();
            }
        }*/

    }

    public void selectRecordTypes(String recType)
    {
        if ("All Records".equalsIgnoreCase(recType))
        {
            driver.findElement(By.xpath(".//*[@title='All Records']")).click();
            driver.findElement(By.xpath(".//*[@alt='Add'][1]")).click();
        } else if ("NA".equalsIgnoreCase(recType))
        {}
        else
        {
            String[] pArr = recType.split(";");
            for (int i = 0; i < pArr.length; i++)
            {
                String[] sArr = pArr[i].split(",");
                for (int j = 0; j < sArr.length; j++)
                {
                    if ("All Accepts".equalsIgnoreCase(sArr[j]))
                    {
                        driver.findElement(By.xpath(".//*[@title='All Accepts']")).click();
                    } else if ("All Rejects".equalsIgnoreCase(sArr[j]))
                    {
                        driver.findElement(By.xpath(".//*[@title='All Rejects']")).click();
                    } else
                    {//li[@title='A']
                        List<WebElement> elements= driver.findElements(By.xpath("//li[starts-with(@title,'" + sArr[j] + "')]"));

                        for(WebElement ele:elements)
                        {
                            String styleEle=ele.getAttribute("style");
                            if(!styleEle.equalsIgnoreCase("display: none;"))
                            {
                                String id=ele.getAttribute("id");
                                driver.findElement(By.xpath("//li[@id='"+id+"']")).click();
                            }

                        }

                    }
                    driver.findElement(By.xpath("(.//*[@alt='Add'])[" + (i + 1) + "]")).click();
                }
            }
        }
    }

    public void createFilesWithName(String files)
    {
        String[] fileName = files.split(",");
        int grpCount = fileName.length;
        System.out.println(grpCount);
        if (1 == grpCount)
        {
            inputfileName(files, 1);
        } else
        {
            for (int i = 0; i < grpCount - 1; i++)
            {
                AddFile_btn.click();
            }
            for (int i = 0; i < grpCount; i++)
            {
                inputfileName(fileName[i], i + 1);
            }
        }

    }

    public String getErrorText()
    {
        String error = driver.findElement(By.xpath("//div[@class='cmsContent']//div[@class= 'errMsg errMsgExt']//span")).getText();
        return error;
    }

    public void selectRecordTypesScreen(String splitRecords, String process, String filenames, String recordType)
    {
        if (!process.startsWith("IP"))
        {
            selectSplitRecord(splitRecords, process);
            createFilesWithName(filenames);
            selectRecordTypes(recordType);

        } else if (process.startsWith("IP"))
        {
            createFilesWithName(filenames);

        }
    }

    public void selectRecordTypes(String splitRecords, String process, String filenames, String recordType)
    {
        if (!process.startsWith("IP"))
        {
            selectSplitRecord(splitRecords, process);
            createFilesWithName(filenames);
            try {
				Thread.sleep(2000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            selectRecordTypes(recordType);

        } else if (process.startsWith("IP"))
        {
            createFilesWithName(filenames);
        }
    }

    //    public boolean isGroupPresent(String name)
    //    {
    //        try
    //        {
    //            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
    //            System.out.println(driver.findElement(By.id(name)).getText());
    //            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    //            return true;
    //
    //        } catch (org.openqa.selenium.NoSuchElementException e)
    //        {
    //            return false;
    //        }
    //    }

    public boolean isRecordPresentInAvaliableFields(String recordType)
    {
        boolean isPresent=false;
        List<WebElement> elements= driver.findElements(By.xpath("//div[starts-with(text(),'Available Record Types/Groups')]//following::ul[2]//li[@class='groups']/a"));

        int i=0;
        while(i<elements.size())
        {
            if(recordType.contains(elements.get(i).getText()))
            {
                isPresent=true;
                i++;
            }
        }
        return  isPresent;
    }

    public int noOfGroupsSelected()
    {
        return driver.findElements(By.xpath("//div[contains(text(),'Record')]//parent::div//div[@class='content11']//ul")).size();
    }

    public boolean isGroupsSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            System.out.println(driver.findElement(By.xpath("(.//*[@class='FieldName groups']/span)[1]")).getText());
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }
    public boolean isSelectionclearedForRecordTypeScreen()
    {
        boolean isCleared=false;
        String text= driver.findElement(By.xpath("//div[@class='selectDiv1']//ul[@class='thead']/parent::div//following::div[1]")).getText();
        if(text.equalsIgnoreCase(""))
        {
            isCleared=true;
        }
        return isCleared;
    }
    public boolean isSelectionRetained(String selectedRecordTypes)
    {
        boolean isRetained=false;
        String recordType=null;
        List<WebElement> elements=driver.findElements(By.xpath("//div[@class='selectDiv1']//div[@class='content10']//ul//li"));
        for(WebElement ele:elements)
        {
            if(selectedRecordTypes.contains(ele.getAttribute("title"))){isRetained=true;}

        }
        return isRetained;
    }
    //div[starts-with(text(),'Record Group')]//following::div[2]
    public String getTheLabel(String recordType)
    {
        String[] recordArr=recordType.split(",");

        String heading= driver.findElement(By.xpath("//span[starts-with(text(),'"+recordArr[0]+"')]//preceding::div[contains(@class,'subHeading')]")).getText();
        return heading;
    }
}

package com.equifax.cms.fusion.test.qapages;

import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.testng.Assert.fail;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.hamcrest.CoreMatchers;
import org.junit.Assert;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class CommonMethods
{
    private static final Logger LOGGER = LoggerFactory.getLogger(CommonMethods.class);
    public WebDriver driver;
    private boolean acceptNextAlert = true;
    private OracleDBHelper oracleDBHelper;
    private ProjectDashBoardPage projectDashboardPage;

    public CommonMethods(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    @FindBy(id = "allRecordsGroups")
    WebElement allRecordsGroups;

    @FindBy(xpath = "//label[contains(text(), 'Process Name:')]")
    WebElement Ele_ProcessID;

    @FindBy(id = "allRecordsAccRej")
    public WebElement Ele_AllRecRegardlessOfType;

    @FindBy(id = "acceptCodeChkbx_0")
    WebElement Ele_Accepts;
    // **********
    @FindBy(id = "linkAccept_0")
    WebElement Ele_Accepts_Exclusion;

    @FindBy(id = "stepAcceptLabel_0")
    WebElement selected_Accepts_Exclusion_Id;

    @FindBy(id = "allRecordsGroups")
    public WebElement all_RecordsGroups;

    @FindBy(id = "cms_search")
    public WebElement searchProjTab;

    @FindBy(xpath = "//a[@id='cms_search']")
    WebElement Ele_Search_Tab;

    @FindBy(id = "projectNumber")
    public WebElement project_Number;

    @FindBy(id = "searchButton")
    public WebElement projSearch_Button;

    @FindBy(xpath = ".//*[@id='qc']/a")
    WebElement QC_Tab;

    // *********
    @FindBy(id = "checkAll")
    WebElement Ele_AllRejects;

    @FindBy(xpath = ".//*[@id='home']/a")
    WebElement Ele_Home_Tab;

    @FindBy(xpath = "//div[@id='shippedDateDiv']/img")
    WebElement calender_Btn;
    @FindBy(id = "itemTableId")
    WebElement Ele_Data;

    @Step("Get the Process Id")
    public String getProcId()
    {
        String[] a = Ele_ProcessID.getText().split(":");
        System.out.println("Process Id: " + a[1]);
        String value = a[1].trim();
        return value;
    }

    @Step("Clicked Home Tab")
    public void clickHomeTab()
    {
        new WebDriverWait(driver, 10).until(ExpectedConditions.presenceOfElementLocated(By.id("home")));
        Ele_Home_Tab.click();
    }

    @Step("Generated Final Process Name")
    public String getFinalProcessName()
    {
        String[] pName = driver.findElement(By.xpath(".//*[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process ID :" + pName[1].trim());
        return pName[1].trim();
    }

    @Step("Generated Assigned ID For Process Selected Process Name")
    public String getAssignedIdForTheProcess()
    {
        String[] pName = driver.findElement(By.xpath("//label[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process ID :" + pName[0].trim());
        return pName[0].trim();
    }

    @Step("Generated Assigned ID For Process Selected Process Name From The Summary")
    // it is fetching from the summary page ,assigned ID of the
    // process
    public String getAssignedIdForTheProcessFromTheSummary()
    {
        String[] pName = driver.findElement(By.xpath("//label[contains(text(),'Process Name:')]/following::span[1]")).getText().split(":");
        System.out.println("Generated Process ID :" + pName[0].trim());
        return pName[0].trim();
    }

    @Step("Generated Final Process Name")
    public String getFinalProcessNameColon()
    {
        String[] pName = driver.findElement(By.xpath(".//*[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process Name :" + pName[1].trim());
        return pName[1].trim();
    }

    @Step("Generated Final Process Name")
    public String getFinalProcessNameColon_Space(String processName)
    {
        String[] pName = driver.findElement(By.xpath(".//*[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process Name :" + pName[1].trim() + ": " + processName);
        return pName[1].trim() + ": " + processName;
    }

    @Step("Generated Final Process Name")
    public String getFinalProcessNameColonWithoutSpace(String processName)
    {
        String[] pName = driver.findElement(By.xpath(".//*[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process Name :" + pName[1].trim() + ":" + processName);
        return pName[1].trim() + ":" + processName;
    }

    @Step("Generated Final Process Name For Stats")
    public String getFinalProcessNameForStats(String processName)
    {
        String[] pName = driver.findElement(By.xpath(".//*[contains(text(),'Process Name:')]")).getText().split(":");
        System.out.println("Generated Process Name :" + pName[1].trim() + ":" + processName);
        return pName[1].trim() + "_" + processName;
    }

    @Step("Selected all Records checkbox")
    public void selectAllRecordsCheckBox()
    {
        // Ele_AllRecRegardlessOfType.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", Ele_AllRecRegardlessOfType);
    }

    @Step("Selected Accepts checkbox")
    public void selectAcceptsCheckBox()
    {
        Ele_Accepts.click();
    }

    // ***********************//
    @Step("click on excluison gearbox for accept")
    public void clickAcceptsExclusionGearBox()
    {
        Ele_Accepts_Exclusion.click();
    }

    public boolean isElementPresent_Xpath(String xpath)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.xpath(xpath)).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isElementPresent_ID(String id)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.id(id)).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public String isElementPresentAreAcceptRecordTypes(String id)
    {
        return driver.findElement(By.xpath("//a[@id='" + id + "']/parent::li")).getAttribute("class");
    }

    public String getTextMsgError()
    {
        // return driver.findElement(By.id("textMsg")).getText();
        return driver.findElement(By.xpath("//h2[contains(text(),'Output Setup')]/following::div[@class='errMsg errMsgExt'][1]/span[@id='textMsg']"))
                .getText();

    }

    public String getTextError()
    {
        return driver.findElement(
                By.xpath("//h2[contains(text(),'Output Setup')]/following::div[@class='copyErrMsg errMsgExt'][1]/span[@id='textMsg']")).getText();
    }

    public String getRecTypeErrMsg()
    {
        return driver.findElement(By.xpath("//h3[contains(text(),'Record Types')]/following::div[@class='errMsg errMsgExt'][1]/span[@id='textMsg']"))
                .getText();
    }

    public String getErrMsgClass()
    {
        return driver.findElement(By.xpath(".//*[@class='errMsg']")).getText();
    }

    public String getErMsg()
    {
        return driver.findElement(By.id("erMsg")).getText();
    }

    public void writeProcessName(String sheet, int colno, String Name) throws IOException
    {
        try
        {
            FileInputStream fileIn = new FileInputStream(new File(System.getProperty("user.dir") + PropertiesUtils.getProperty("path")));
            XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
            XSSFSheet sheetToBeWritten = workbook.getSheet(sheet);
            XSSFRow row;
            Iterator<org.apache.poi.ss.usermodel.Row> rowIterator = sheetToBeWritten.iterator();
            while (rowIterator.hasNext())
            {
                row = (XSSFRow) rowIterator.next();
                if (row.getRowNum() != 0)
                {
                    XSSFCell cell = row.getCell(colno);
                    cell.setCellValue(Name);
                }
            }
            fileIn.close();
            FileOutputStream outFile = new FileOutputStream(new File(System.getProperty("user.dir") + PropertiesUtils.getProperty("path")));
            workbook.write(outFile);
            outFile.close();
        } catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void writeProcessName_Reg(String TC_ID, String sheet, int colno, String Name) throws IOException
    {
        try
        {
            FileInputStream fileIn = new FileInputStream(new File(System.getProperty("user.dir") + PropertiesUtils.getProperty("path")));
            XSSFWorkbook workbook = new XSSFWorkbook(fileIn);
            XSSFSheet sheetToBeWritten = workbook.getSheet(sheet);
            XSSFRow row;
            Iterator<org.apache.poi.ss.usermodel.Row> rowIterator = sheetToBeWritten.iterator();
            while (rowIterator.hasNext())
            {
                row = (XSSFRow) rowIterator.next();
                System.out.println(row.getCell(0));
                if (row.getCell(0).toString().equalsIgnoreCase(TC_ID))
                {
                    XSSFCell cell = row.getCell(colno);
                    cell.setCellValue(Name);
                }
            }
            fileIn.close();
            FileOutputStream outFile = new FileOutputStream(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"));
            workbook.write(outFile);
            outFile.close();
        } catch (FileNotFoundException e)
        {
            e.printStackTrace();
        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Step("Selected All Rejects checkbox")
    public void selectAllRejectsCheckBox()
    {
        Ele_AllRejects.click();
    }

    @Test
    @Step("Verify if \"{0}\" Equals \"{1}\" ")
    public void verifyboolean(boolean a, boolean b)
    {
        assertThat(a, is(b));
    }

    @Test
    @Step("Verify if \"{0}\" Equals \"{1}\" ")
    public void verifyDate(Date a, Date b)
    {
        assertThat(a, is(b));
    }

    @Test
    @Step("Verify if Actual \"{0}\" is Equal Expected \"{1}\" ")
    public void verifyString(String a, String b)
    {

        assertThat(a, is(b));
    }

    @Test
    @Step("All the Inputs are Provided Process should be \"{1}\" but actual is \"{0}\" ")
    public void verifyStringEB(String a, String b)
    {
        assertThat(a, is(b));
    }

    @Test
    @Step("Verify if \"{0}\" Equals \"{1}\" ")
    public void verifyLong(Long a, Long b)
    {
        assertThat(a, is(b));
    }

    @Test
    @Step("Verify if \"{0}\" Equals \"{1}\" ")
    public void verifyInt(int a, int b)
    {
        assertThat(a, is(b));
    }

    @Test
    @Step("Verify if \"{0}\" contains \"{1}\" ")
    public void verifyContainsString(String a, String b)
    {
        assertThat(a, CoreMatchers.containsString(b));
    }

    @Attachment("Exception Message {0}")
    public byte[] captureExceptionMessage(String error)
    {
        return error.getBytes();
    }

    public TestWatcher screenshotOnFailure = new TestWatcher()
    {
        @Override
        protected void failed(Throwable e, Description description)
        {
            captureExceptionMessage(e.getMessage());
            makeScreenshotOnFailure();
        }

        public byte[] makeScreenshotOnFailure()
        {
            return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
        }
    };

    @Step("Login")
    public void userLogin()
    {
        // get user name from property file
        driver.get(PropertiesUtils.getProperty("base.url"));
        driver.findElement(By.id("username")).clear();
        driver.findElement(By.id("username")).sendKeys(PropertiesUtils.getProperty("user"));
        driver.findElement(By.id("password")).clear();
        driver.findElement(By.id("password")).sendKeys(PropertiesUtils.getProperty("password"));
        driver.findElement(By.id("submitButton")).click();
    }

    // Search a project
    @Step("Search project")
    public void searchProject()
    {
        driver.findElement(By.id("cms_search")).click();
        driver.findElement(By.id("projectNumber")).clear();
        driver.findElement(By.id("projectNumber")).sendKeys(PropertiesUtils.getProperty("project"));
        driver.findElement(By.id("searchButton")).click();
        driver.findElement(By.linkText(PropertiesUtils.getProperty("project"))).click();
    }

    /*
     * @Step("Search project") public void searchProjectUsingParam(String project) { driver.findElement(By.id("cms_search")).click();
     * driver.findElement(By.id("projectNumber")).clear(); driver.findElement(By. id("projectNumber")).sendKeys(PropertiesUtils.getProperty(project));
     * driver.findElement(By.id("searchButton")).click(); driver.findElement(By.linkText (PropertiesUtils.getProperty("project"))).click(); }
     */
    @Step("Search specific project")
    public void searchSpecificProject(String projNum)
    {
        Ele_Search_Tab.click();
        project_Number.clear();
        project_Number.sendKeys(projNum);
        projSearch_Button.click();
    }

    @Step("Search Project for Copy \"{1}\"")
    public void searchProjforCopy(String copyProjNum)
    {
        driver.findElement(By.id("cms_search")).click();
        driver.findElement(By.id("projectNumber")).clear();
        driver.findElement(By.id("projectNumber")).sendKeys(copyProjNum);
        driver.findElement(By.id("searchButton")).click();
        driver.findElement(By.xpath("//a[contains(text(),'" + copyProjNum + "')]")).click();
    }

    public void waitForElement(String Path) throws InterruptedException
    {
        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                Assert.fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath(Path)))
                {
                    break;
                }
            } catch (Exception e)
            {

            }
            Thread.sleep(1000);
        }
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getSurplusRecFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where nth_flag = 'R'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getDateinRLSTable(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select rolling_date from fusion_stage." + query + " limit 1";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records = null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public List<String> getMetaDatainRLSTable(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select * from fusion_stage." + query + " limit 1";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ArrayList<String> colName = new ArrayList<String>();
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData records = null;
        records = rs.getMetaData();
        int columnCount = records.getColumnCount();
        for (int i = 1; i <= columnCount; i++)
        {
            String columnName = records.getColumnName(i);
            colName.add(columnName);
        }

        conn.close();
        return colName;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGP(String query, String rejects) throws SQLException
    {

        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";

        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where fail_code in" + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Filtering Group = \"{1}\"")
    public long getRecordsGPFilterGroup(String table, String group) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where group_name='" + group + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    // ////////////////////////////////////////////////////////////////////////
    /* MATCH JOIN QUERIES */
    // ////////////////////////////////////////////////////////////////////////

    public boolean ifAppendedColumnExists(String masTab, String appField)
    {
        try
        {
            String query1 = null;
            Connection conn = gpConnect();

            query1 = "select count(*) from fusion_stage." + masTab + " where " + appField + " is NULL";
            System.out.println("GP Query : " + query1);
            PreparedStatement ps = conn.prepareStatement(query1);

            ResultSet rs = ps.executeQuery();
            long records = 0;
            while (rs.next())
            {
                records = rs.getLong(1);
            }
            conn.close();
            return true;
        } catch (java.sql.SQLException e)
        {
            return false;
        }

    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJ_Join_2_Match_Keys(String masTab, String matTab, String masKey1, String masKey2) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();

        query1 = "select count(*) from fusion_stage." + masTab + " e JOIN fusion_stage." + matTab + " v ON e." + masKey1 + " = v." + masKey1
                + " AND e." + masKey2 + " = v." + masKey2;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJ_Join_1_Match_Key(String masTab, String matTab, String masKey1) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();

        query1 = "select count(*) from fusion_stage." + masTab + " e JOIN fusion_stage." + matTab + " v ON e." + masKey1 + " = v." + masKey1;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJ(String table, String flag) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();
        if (flag.equalsIgnoreCase("A") || flag.equalsIgnoreCase("R"))
        {
            query1 = "select count(*) from fusion_stage." + table + " where match_flag='" + flag + "'";
        } else if (flag.equalsIgnoreCase("NULL"))
        {
            query1 = "select count(*) from fusion_stage." + table + " where match_flag is NULL";
        }
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJNULL_OR_R(String table) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();

        query1 = "select count(*) from fusion_stage." + table + " where match_flag is NULL OR match_flag='R'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJNULL(String table) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();

        query1 = "select count(*) from fusion_stage." + table + " where match_flag is NULL";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJNotNULL(String table) throws SQLException
    {
        String query1 = null;
        Connection conn = gpConnect();

        query1 = "select count(*) from fusion_stage." + table + " where match_flag is not NULL";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Output Table = \"{0}\" and Match Flag = \"{1}\"")
    public long getRecordsGPMJ_Append_Null(String table, String matchP, String appended) throws SQLException
    {
        String query1 = null;
        String matchID[] = matchP.split(":");
        String newApp = appended.replace(",", "_");
        Connection conn = gpConnect();
        query1 = "select count(*) from fusion_stage." + table + " where " + "A_" + matchID[0].trim() + "_" + newApp + " is NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    // ////////////////////////////////////////////////////////////////////////
    /* DNS QUERIES */
    // ////////////////////////////////////////////////////////////////////////

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPDNSMatchwithNightly(String query1, String query2) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where cid in (select cid from fusion_stage." + query2
                + " where fail_code is NULL)";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public boolean getRecordsFromHDRfailcode_RJ(String query1) throws SQLException
    {
        boolean status = true;
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where fail_code ='RJ'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        if (records == 0)
        {
            status = false;
        }
        return status;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromDNSfailcode_RJ(String query1) throws SQLException
    {

        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where fail_code ='RJ' and dns_tag is null";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromHDRfailcode_RJ(String query1) throws SQLException
    {

        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where fail_code ='RJ'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;
    }

    // ////////////////////////////////////////////////////////////////////////
    /* FILTERING QUERIES */
    // ////////////////////////////////////////////////////////////////////////

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_for_FL_AGE(String query, String fromto) throws SQLException
    {
        String range[] = fromto.split(",");
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE between '" + range[0] + "' and '" + range[1] + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_for_F_NAME(String query, String name) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where F_NAME like '" + name + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_AGE_NOT_EQUAL(String query, String age) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE NOT like '" + age + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_AGE_GREATER(String query, String age) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE > '" + age + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_AGE_GREATEREQUAL(String query, String age) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE >= '" + age + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_AGE_LESS(String query, String age) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE < '" + age + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_AGE_LESSEQUAL(String query, String age) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE <= '" + age + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_F_NAME_AND_AGE_RANGE(String query, String fromto, String name) throws SQLException
    {
        String range[] = fromto.split(",");
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where AGE between '" + range[0] + "' and '" + range[1] + "' OR F_NAME ='"
                + name + "'";
        // select * from fusion_stage.I7917_DM_GPLOAD_HEADER where AGE Between
        // '21' AND '50' OR F_NAME ='JOHN'
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPForPPCode(String query, String recordType) throws SQLException
    {
        Connection conn = gpConnect();
        String ppCode = "A" + recordType;

        String query1 = "select count(*) from fusion_stage." + query + "  where pp_code = '" + ppCode + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_TABLE_COLUMN_VALUE(String table, String column, String value) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where " + column + " = '" + value + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_RS_R_DNSTAG_DN(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where RECORD_STATUS = 'R' AND FAIL_CODE = 'DN'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public Map<String, String> getMap_FL_DP_FC_GRP(String table, String group) throws SQLException
    {
        Map<String, String> mapDpFc = new HashMap<String, String>();
        Connection conn = gpConnect();
        String query1 = "select dp_sequence_num,fail_code from fusion_stage." + table + "  where group_name = '" + group + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String dpSeq;
        String failCode;
        while (rs.next())
        {
            dpSeq = rs.getString("dp_sequence_num");
            failCode = rs.getString("fail_code");
            mapDpFc.put(dpSeq, failCode);
        }
        conn.close();
        return mapDpFc;

    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public Map<String, String> getMap_FL_FC_NOT_NULL(String table) throws SQLException
    {
        Map<String, String> mapDpFc = new HashMap<String, String>();
        Connection conn = gpConnect();
        String query1 = "select dp_sequence_num,fail_code from fusion_stage." + table + " where FAIL_CODE is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String dpSeq;
        String failCode;
        while (rs.next())
        {
            dpSeq = rs.getString("dp_sequence_num");
            failCode = rs.getString("fail_code");
            mapDpFc.put(dpSeq, failCode);
        }
        conn.close();
        return mapDpFc;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public boolean is_FL_FAIL_CODE_MATCH(Map<String, String> map, String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select dp_sequence_num,fail_code from fusion_stage." + table;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        boolean flag = false;
        while (rs.next())
        {
            String dp_seq = rs.getString(1);
            String fail_code = rs.getString(2);
            if (map.containsKey(dp_seq))
            {
                if (map.get(dp_seq).equalsIgnoreCase(fail_code))
                {
                    flag = true;
                } else
                {
                    flag = false;
                }

            }
        }
        conn.close();
        return flag;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getCountofRecordsFOR_AND_CONDITION(String table, String firstField, String from, String to, String secondField, String value)
            throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where " + firstField + " Between " + from + " and " + to + " and "
                + secondField + " = '" + value + "'";
        // select * from fusion_stage.I38083_DM_GPLOAD_HEADER where AGE Between
        // 21 and 50 and NUM_TRADE = '5'
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public boolean ifFailCodeMatchesDP_Num(Map<String, String> map, String header) throws SQLException
    {
        Connection conn = gpConnect();
        boolean flag = false;
        String query2 = "select dp_sequence_num,fail_code from fusion_stage." + header;
        PreparedStatement ps2 = conn.prepareStatement(query2);
        ResultSet rs2 = ps2.executeQuery();
        while (rs2.next())
        {
            String dp_seq = rs2.getString(1);
            String fail_code = rs2.getString(2);
            if (map.containsKey(dp_seq))
            {
                if (map.get(dp_seq) != null)
                {
                    if (map.get(dp_seq).equalsIgnoreCase(fail_code))
                    {
                        flag = true;
                    } else
                    {
                        flag = false;
                        break;
                    }
                }

            }
        }
        conn.close();
        return flag;

    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public boolean if_FC_CT_for_ACC_SAME_REJ(Map<String, String> map, String header) throws SQLException
    {
        Connection conn = gpConnect();
        boolean flag = false;
        String query2 = "select dp_sequence_num,fail_code from fusion_stage." + header;
        PreparedStatement ps2 = conn.prepareStatement(query2);
        ResultSet rs2 = ps2.executeQuery();
        while (rs2.next())
        {
            String dp_seq = rs2.getString(1);
            String fail_code = rs2.getString(2);
            if (map.containsKey(dp_seq))
            {
                if (map.get(dp_seq) != null)
                {
                    if (fail_code == null)
                    {
                        if (map.get(dp_seq).equalsIgnoreCase("CT"))
                        {
                            flag = true;
                        } else
                        {
                            flag = false;
                        }
                    } else
                    {
                        if (map.get(dp_seq).equalsIgnoreCase(fail_code))
                        {
                            flag = true;
                        } else
                        {
                            flag = false;
                        }
                    }
                }

            }
        }
        conn.close();
        return flag;

    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_Fail_Code(String table, String failCode) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where FAIL_CODE = '" + failCode + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_COLUMN_IS_NULL(String table, String column) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where " + column + " is NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_COLUMN_IS_NOT_NULL(String table, String column) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where " + column + " is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_COLUMN_IS_NOT_NULL_AND_FAIL_CODE_DN(String table, String column) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + table + " where " + column + " is NOT NULL OR FAIL_CODE = 'DN'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_M_I_NOT_EQUAL_NULL(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where M_I is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_MLA_NOT_EQUAL_NULL(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where mla_status is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRGP_Char_Range_M_I(String query, String fromTO) throws SQLException
    {
        Connection conn = gpConnect();
        String arrFromTo[] = fromTO.split(",");
        String query1 = "select count(*) from fusion_stage." + query + " where M_I BETWEEN " + "'" + arrFromTo[0].toUpperCase() + "'" + " AND " + "'"
                + arrFromTo[1].toUpperCase() + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRGP_FF_CSZ_SPACES(String query, String value) throws SQLException, InterruptedException
    {
        Connection conn = gpConnect();
        String withSpaces = value.replace("^", " ");
        System.out.println(withSpaces);
        Thread.sleep(5000);
        String query1 = "select count(*) from fusion_stage." + query + " where freeform_city_state_zip = " + "'" + withSpaces + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_M_I_EQUAL_NULL(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where M_I is NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_with_Grp_Name(String query, String grpName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where group_name = " + "'" + grpName + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_Group_A_R(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select * from fusion_stage." + query;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData metaData;
        String columnName = null;
        while (rs.next())
        {
            metaData = rs.getMetaData();
            columnName = metaData.getColumnLabel(2);
        }
        String query2 = "select count(*) from fusion_stage." + query + " where " + columnName + " = 'A' or " + columnName + " = 'R'";
        PreparedStatement ps2 = conn.prepareStatement(query2);
        ResultSet rs2 = ps2.executeQuery();
        long records = 0;
        while (rs2.next())
        {
            records = rs2.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFGP_GroupCondi_NULL(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select * from fusion_stage." + query;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData metaData;
        String columnName = null;
        while (rs.next())
        {
            metaData = rs.getMetaData();
            columnName = metaData.getColumnLabel(2);
        }
        String query2 = "select count(*) from fusion_stage." + query + " where " + columnName + " is NULL";
        PreparedStatement ps2 = conn.prepareStatement(query2);
        ResultSet rs2 = ps2.executeQuery();
        long records = 0;
        while (rs2.next())
        {
            records = rs2.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPFailCodeNotNull(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where fail_code is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPFailCodeNull(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where fail_code is  NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPWhoseDNSTAGIsNull(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where dns_tag is NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_dnstag_NotNull(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " WHERE coalesce(dns_tag,'') != ''";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsToBeProcessedForDNS(String inputTableName, String parentTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = " SELECT COUNT(*) FROM FUSION_STAGE." + inputTableName + " mj" + "join fusion_stage." + parentTableName
                + " h on (mj.dp_sequence_num = h.dp_sequence_num)" + " WHERE (MATCH_FLAG='A' OR MATCH_FLAG IS NULL) and fail_code is null;";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_dnstag_A(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where dns_tag like 'A'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_dnstag_D(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where dns_tag = 'D'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPDNS(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query;
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGPDNS_RS_A(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where record_status='A'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_CID_Not_Match(String query1, String query2) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where cid not in (select cid from fusion_stage." + query2 + ")";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_CID_Match(String query1, String query2) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where cid in (select cid from " + query2 + ")";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP_DNS_CID_Not_Match_CID1(String query1, String query2) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where cid1 not in (select cid from " + query2 + ")";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromDNS_Tab_Popu(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from " + query1;
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    // added
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public boolean validateDNS_TAGColumnOfDNSProcess(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select dns_tag from fusion_stage." + query + " where fail_code is NOT NULL";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        boolean result = false;
        while (rs.next())
        {
            String DNS_TAG_Status = rs.getString(1);
            if ("".equals(DNS_TAG_Status))
            {
                result = true;
            }
        }
        conn.close();
        return result;
    }

    // END OF DNS QUERIES

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFHDR_RECORD_STATUS_A(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where record_status = 'A'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching City Column From GreenPlum for Table = \"{0}\"")
    public boolean getCityColumnFromGP(String TableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select city from fusion_stage." + TableName;
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        boolean flag = true;
        while (rs.next())
        {
            if (!rs.getString(1).equalsIgnoreCase(""))
            {
                flag = false;
            }
        }
        return flag;

    }

    // ////////////////////////////////////////////////////////////////////////
    /* OUTPUT QUERIES */
    // ////////////////////////////////////////////////////////////////////////

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String isResequence_ColumnPresent(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select * from fusion_stage." + query1 + " limit 1";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        ResultSetMetaData rsmd = rs.getMetaData();
        String colName = rsmd.getColumnName(2);
        return colName.toUpperCase();

    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFOT_GP_CAP_AGE_CAPPED(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where age = '9'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFOT_GP_CAP_F_NAME(String query1, String name) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where F_NAME ='" + name + "'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFAUDIT_SAMPLE_ACC_CODE_NOTNULL(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where acc_code is not null";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFAUDIT_SAMPLE_REJ_CODE_NOTNULL(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where rej_code is not NULL";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFAUDIT_SAMPLE_FAIL_CODE_NOTNULL(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where fail_code is not NULL";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFAUDIT_SAMPLE_RJ(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where rej_code = 'RJ'";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRFAUDIT_SAMPLE_RJ_NOTNULL(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1 + " where rej_code is not NULL";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long gRF_CAP_CID_AAAAA(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select count(*) from fusion_stage." + query + " where CID = 'AAAAAAAAAAAAAAAAAA'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    // *****************************************************
    // FULL FILE FIXED QUERIES
    // *****************************************************
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getTotalRecordsOfTheInputTable(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + query1;
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Column Data From Green Plum for Table = \"{0}\"")
    public HashMap<String, String> getColumnsDataFromTheTable(String query1) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select dp_sequence_num,cid from fusion_stage." + query1 + " " + "limit 5";
        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        HashMap<String, String> records = new HashMap<String, String>();
        int column1Pos = rs.findColumn("dp_sequence_num");
        int column2Pos = rs.findColumn("cid");
        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            String column2 = rs.getString(column2Pos);
            records.put(column1, column2);
        }

        return records;
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Attachment
    public String acceptAlert()
    {
        String alertText = null;
        try
        {
            Alert alert = driver.switchTo().alert();
            alertText = alert.getText();
            if (acceptNextAlert)
            {
                alert.accept();
            } else
            {
                alert.dismiss();
            }
            System.out.println(alertText);

        } catch (Exception e)
        {

        } finally
        {
            acceptNextAlert = true;
            driver.switchTo().defaultContent();
        }
        return alertText;
    }

    public void selectRecordsReject(String chItems)
    {
        if ("ALL".equalsIgnoreCase(chItems))
        {
            // driver.findElement(By.id("checkAll")).click();
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", driver.findElement(By.id("checkAll")));
        } else
        {
            String delimiter = ",";
            StringTokenizer eachChkBoxText = new StringTokenizer(chItems, delimiter);
            while (eachChkBoxText.hasMoreTokens())
            {
                String dynamicId = getRecTypeChckBoxId(eachChkBoxText.nextToken());
                System.out.println("DYNAMIC_ID : " + dynamicId);
                WebElement checkBox = driver.findElement(By.id(dynamicId));
                if (!checkBox.isSelected())
                {
                    checkBox.click();
                }
            }
        }
    }

    // ***********************************************************//
    public void clickRejectsExclusionGearBox(String reject)
    {

        String delimiter = ",";
        StringTokenizer eachChkBoxText = new StringTokenizer(reject, delimiter);
        while (eachChkBoxText.hasMoreTokens())
        {
            String dynamicId = getRecTypeChckBoxId(eachChkBoxText.nextToken());
            System.out.println("DYNAMIC_ID : " + dynamicId);
            WebElement checkBox = driver.findElement(By.id(dynamicId));
            if (!checkBox.isSelected())
            {
                checkBox.click();
            }
        }
    }

    // ***************************************************************************
    private enum RECORDREJECT
    {
        NH, nh, FR, fr, NP, np, PS, ps, RJ, rj, RP, rp, ID, id, IP, ip, CE, ce, RD, rd, DP, dp, HS, hs, ND, nd, DB, db, CT, ct, DD, dd, SR, sr, NA, na, SN, sn, NX, nx, RS, rs, DS, ds, DN, dn
    }

    public static String getRecTypeChckBoxId(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "rejectCodeChkbx_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "rejectCodeChkbx_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "rejectCodeChkbx_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "rejectCodeChkbx_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "rejectCodeChkbx_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "rejectCodeChkbx_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "rejectCodeChkbx_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "rejectCodeChkbx_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "rejectCodeChkbx_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "rejectCodeChkbx_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "rejectCodeChkbx_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "rejectCodeChkbx_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "rejectCodeChkbx_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "rejectCodeChkbx_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "rejectCodeChkbx_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "rejectCodeChkbx_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "rejectCodeChkbx_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "rejectCodeChkbx_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "rejectCodeChkbx_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "rejectCodeChkbx_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "rejectCodeChkbx_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "rejectCodeChkbx_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "rejectCodeChkbx_22";
            break;

        }
        return dynamicCheckBoxId;
    }

    public static String clickRejectExclusionGearBox(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "linkReject_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "linkReject_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "linkReject_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "linkReject_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "linkReject_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "linkReject_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "linkReject_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "linkReject_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "linkReject_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "linkReject_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "linkReject_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "linkReject_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "linkReject_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "linkReject_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "linkReject_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "linkReject_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "linkReject_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "linkReject_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "linkReject_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "linkReject_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "linkReject_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "linkReject_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "linkReject_22";
            break;

        }
        return dynamicCheckBoxId;
    }

    public static String getSelectedExclusionIdForRejectRecordTypes(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "stepRejectLabel_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "stepRejectLabel_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "stepRejectLabel_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "stepRejectLabel_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "stepRejectLabel_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "stepRejectLabel_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "stepRejectLabel_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "stepRejectLabel_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "stepRejectLabel_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "stepRejectLabel_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "stepRejectLabel_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "stepRejectLabel_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "stepRejectLabel_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "stepRejectLabel_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "stepRejectLabel_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "stepRejectLabel_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "stepRejectLabel_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "stepRejectLabel_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "stepRejectLabel_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "stepRejectLabel_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "stepRejectLabel_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "stepRejectLabel_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "stepRejectLabel_22";
            break;

        }
        return dynamicCheckBoxId;
    }

    public void selectRecordTypes(String process, String allRecords, String accepts, String rejects)
    {
        if (!"NA".equalsIgnoreCase(allRecords))
        {
            if (process.startsWith("IP"))
            {
                System.out.println("Record Types are auto selected and disabled");

            } else
            {
                if (allRecords.equalsIgnoreCase("ON"))
                {
                    selectAllRecordsCheckBox();

                } else
                {
                    if (accepts.equalsIgnoreCase("ON"))
                    {
                        selectAcceptsCheckBox();
                    }
                    if (!rejects.equalsIgnoreCase("OFF"))
                    {
                        selectRecordsReject(rejects);

                    }
                }
            }
        }
    }

    public void selectRecordTypesMaster(String process, String allRecords, String accepts, String rejects)
    {
        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");

        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                selectAllRecordsCheckBox();

            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                    selectAcceptsCheckBox();
                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    selectRecordsReject(rejects);

                }
            }
        }
    }

    // **********************************************************************//

    public List<String> fetchTheListOfAvaliableExclusionsForAcceptRecordType(String acceptExclusion) throws InterruptedException
    {
        List<String> fetchedAvaliableExlusions = new ArrayList<String>();

        if (acceptExclusion.equalsIgnoreCase("ON"))
        {
            clickAcceptsExclusionGearBox();
            Thread.sleep(3000);
            driver.switchTo().frame("sb-player");
            List<WebElement> exclusionList = driver.findElements(By.xpath("//th[contains(text(),'Process Steps')]/following::span"));
            for (WebElement exclusion : exclusionList)
            {
                fetchedAvaliableExlusions.add(exclusion.getText());
            }

        }
        driver.findElement(By.xpath("//div[@class='buttons']/a[contains(text(),'Save')]")).click();

        return fetchedAvaliableExlusions;

    }

    public void selectExclusionForRecordTypes(String process, String accepts, String rejects, String exclusions) throws InterruptedException
    {

        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");

        } else
        {

            if (accepts.equalsIgnoreCase("ON"))
            {
                clickAcceptsExclusionGearBox();
                driver.switchTo().frame("sb-player");
                Thread.sleep(3000);
                selectExlusionForRandomNth(exclusions);
                driver.switchTo().defaultContent();
            }
            if (!rejects.equalsIgnoreCase("OFF"))
            {
                selectExlusionForReject(rejects, exclusions);
                driver.switchTo().defaultContent();

            }
        }
    }

    public void selectExlusionForRandomNth(String exclusions) throws InterruptedException
    {

        List<String> exclusionList = new ArrayList<String>(Arrays.asList(exclusions.split(",")));
        for (String exclusion : exclusionList)
        {
            // List<WebElement> eleList =
            // driver.findElements(By.xpath("//div[@class='modal-content']/div[1]/table/tbody/tr"));
            // driver.findElement(By.xpath("//td[contains(text(),'exclusions')]")).click();
            WebElement ele = driver.findElement(By.xpath("//span[contains(text(),'" + exclusion + "')]/parent::td//parent::tr/td[1]/input"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", ele);

        }
        // Thread.sleep(2500);
        // ele1.click();
        // Actions actions = new Actions(driver);
        // WebElement button =
        // driver.findElement(By.xpath("//a[@class='grey-button closePopup']"));
        WebElement button = driver.findElement(By.xpath("//a[text()='Save']"));
        // button.click();
        button.click();
        // JavascriptExecutor js = (JavascriptExecutor) driver;
        // js.executeScript("arguments[0].click();", button);
        // //div[@class='modal-content']/div[2]/a
        // actions.doubleClick(button);
        // actions.click(button);
        driver.switchTo().defaultContent();
    }

    public void selectExlusionForReject(String rejects, String exclusions) throws InterruptedException
    {
        String delimiter = ",";
        StringTokenizer eachChkBoxText = new StringTokenizer(rejects, delimiter);

        while (eachChkBoxText.hasMoreTokens())
        {
            String dynamicId = clickRejectExclusionGearBox(eachChkBoxText.nextToken());
            System.out.println("DYNAMIC_ID : " + dynamicId);
            driver.findElement(By.id(dynamicId)).click();
            driver.switchTo().frame("sb-player");
            Thread.sleep(2000);
            selectExlusionForRandomNth(exclusions);
            Thread.sleep(3000);
        }

    }

    public HashMap<String, String> getSelectedExlusion(String accepts, String rejects)
    {

        HashMap<String, String> selectedExclusionMap = new HashMap<String, String>();
        if (accepts.equalsIgnoreCase("ON"))
        {
            String selected_Exclusion_Accept = selected_Accepts_Exclusion_Id.getText();
            selectedExclusionMap.put("Accept", selected_Exclusion_Accept);
        }
        if (!rejects.equalsIgnoreCase("NA"))
        {
            List<String> rejectRecordTypesList = new ArrayList<String>(Arrays.asList(rejects.split(",")));
            for (String rejectRecordType : rejectRecordTypesList)
            {
                String dynamicId = getSelectedExclusionIdForRejectRecordTypes(rejectRecordType);
                System.out.println("DYNAMIC_ID : " + dynamicId);
                String selected_Exclusion_Reject = driver.findElement(By.id(dynamicId)).getText();
                selectedExclusionMap.put(rejectRecordType, selected_Exclusion_Reject);

            }
        }
        return selectedExclusionMap;

    }

    // *********************************************************************//
    @Step("Status of the Process in DataProcessing Process Home screen")
    public String getProcessStatusForDataProcessing()
    {
        String status = driver.findElement(By.xpath("//table[@id='dnsTable']/tbody/tr[1]/td[3]")).getText();
        return status;
    }

    @Step("Status of the Process in Process Home screen")
    public String getProcessStatus()
    {
        String status = driver.findElement(By.xpath("//div[@id='contentjqxgridJobListing']/div/div/div[1]/div[3]/div[1]")).getText();
        return status;
    }

    @Step("Status of the Process in Process Home screen")
    public String getInquiryProcessStatus()
    {
        String status = driver.findElement(By.xpath("//div[@id='contentjqxgridJobListing']/div/div/div[1]/div[3]/div[1]")).getText();
        return status;
    }

    @Step("Status of the Process in DataProcessing Process Home screen")
    public String getDPProcessStatus()
    {
        String status = driver.findElement(By.xpath("//div[@id='contentjqxgridJobListing']/div/div/div[1]/div[3]/div[1]")).getText();
        return status;
    }

    @Step("Select the Group Name = \"{0}\"")
    public void selectTheGroupsMatch(String groups)
    {
        if (!groups.equalsIgnoreCase("NA"))
        {
            WebElement grp = driver.findElement(By.xpath("(//label[contains(text(),'Group(s)')])[2]"));
            if (grp.isDisplayed())
            {
                if ("All Records".equalsIgnoreCase(groups))
                {
                    driver.findElement(By.xpath("(//label[contains(text(),'" + groups + "')]//preceding::input[1])[3]")).click();
                } else
                {
                    String comma = ",";
                    StringTokenizer stMain = new StringTokenizer(groups, comma);
                    while (stMain.hasMoreElements())
                    {
                        driver.findElement(
                                By.xpath("(//div[@class='groupNamesDivForMatch']/input[@value='" + stMain.nextToken() + "']/preceding::input[1])[1]"))
                                .click();
                    }
                }
            }
        }
    }

    @Step("Select the Group Name = \"{0}\"")
    public void selectTheGroups(String groups) throws InterruptedException
    {
        Thread.sleep(3000);
        if (!groups.equalsIgnoreCase("NA"))
        {
            WebElement grp = driver.findElement(By.xpath("//label[contains(text(),'Group(s)')]"));
            if (grp.isDisplayed())
            {
                if ("All Records".equalsIgnoreCase(groups))
                {
                    driver.findElement(By.xpath("//div[@id='groupsDiv']/ul/input")).click();
                } else
                {
                    String comma = ",";
                    StringTokenizer stMain = new StringTokenizer(groups, comma);
                    while (stMain.hasMoreElements())
                    {
                        Thread.sleep(2500);

                        driver.findElement(
                                By.xpath("(//div[@class='groupNamesDiv']/input[@value='" + stMain.nextToken() + "']/preceding::input[1])[1]"))
                                .click();

                    }
                }
            }
        }
    }

    // added
    @Step("Select the Group Name = \"{0}\"")
    public void selectTheGroupsForTheProcess(String groups) throws InterruptedException
    {
        Thread.sleep(3000);
        if (!groups.equalsIgnoreCase("NA"))
        {
            WebElement grp = driver.findElement(By.xpath("//label[contains(text(),'Group(s)')]"));
            if (grp.isDisplayed())
            {
                if ("All Records".equalsIgnoreCase(groups))
                {
                    driver.findElement(By.xpath("//label[contains(text(),'" + groups + "')]//preceding::input[1]")).click();
                } else
                {
                    String[] grpArr = groups.split(",");
                    List<String> grpsList = Arrays.asList(grpArr);
                    for (String grps : grpsList)
                    {
                        WebElement element = driver.findElement(By.xpath("(//div[@class='groupNamesDiv']/input[@value='" + grps
                                + "']/preceding::input[1])[1]"));
                        JavascriptExecutor js = (JavascriptExecutor) driver;
                        js.executeScript("arguments[0].click();", element);

                    }

                }
            }
        }
    }

    @Step("Read file and return list")
    public List<String> readFile(String filePath)
    {
        String line = null;
        BufferedReader bf = null;
        List<String> arr = new ArrayList<>();
        try
        {
            bf = new BufferedReader(new FileReader(getAbsoluteInFilePath(filePath)));
            while ((line = bf.readLine()) != null)
            {
                arr.add(line);
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        } finally
        {
            try
            {
                bf.close();
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        int length = arr.size();
        return arr;
    }

    public static String getAbsoluteInFilePath(String path)
    {
        // String bbf =
        // "/pools/dropzone/Test/test_Import_fixed/444_records_130.fixed";

        if (path.startsWith("/nas/dropzone"))
        {
            path = path.replace("/nas/dropzone", "V:").replace("/", "\\\\");
        } else if (path.startsWith("/nas/users/mshamis/fusion"))
        {
            path = path.replace("/nas/users", "U:").replace("/", "\\\\");
        }
        if (path.startsWith("/nas/users"))
        {
            path = path.replace("/nas/users", "U:").replace("/", "\\\\");
        }

        return path;
    }

    @Step("Read file and return string")
    public String readFileString(String filePath)
    {
        String line = null;
        BufferedReader bf = null;
        String str = "";
        try
        {
            bf = new BufferedReader(new FileReader(filePath));
            while ((line = bf.readLine()) != null)
            {
                str += str + line;
            }
        } catch (IOException e)
        {
            e.printStackTrace();
        } finally
        {
            try
            {
                bf.close();
            } catch (IOException e)
            {
                e.printStackTrace();
            }
        }

        return str;
    }

    @Step("Validate All records checked")
    public boolean isAllRecordsChckboxChecked()
    {
        return Ele_AllRecRegardlessOfType.isSelected();
    }

    @Step("Select All Groups checked")
    public void checkAllGroups()
    {
        all_RecordsGroups.click();
    }

    @Step("Split a string using a delimiter")
    public String[] splitString(String str, String delimiter)
    {
        String[] result = null;

        if (delimiter.equalsIgnoreCase("Comma"))
        {
            delimiter = ",";
        }

        if (str != null)
        {
            result = str.split(delimiter);
        }
        return result;
    }

    // added to select specific process summary from the homepage
    public void selectViewSummaryFromAssignedId(String assignedId) throws InterruptedException
    {
        driver.manage().deleteAllCookies();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#jqxgridJobListing').jqxGrid('getrows');");
        String rowId = null;
        int j = 0;
        while (j < rowsInfo.size())
        {
            String row = rowsInfo.get(j).toString();
            if (row.contains("name=" + assignedId))
            {
                rowId = getUid(row);
                // js.executeScript("$('#jqxgridJobListing').jqxGrid('selectrow', "
                // + rowId + ")");
                // String rowIndx= (String)
                // js.executeScript("$('#jqxgridJobListing').jqxGrid('getrowvisibleindex',0);");
                // rowVisibleIndex =
                // $('#jqxgridJobListing').jqxGrid('getrowvisibleindex',
                // selectedrowindex);
                Long rowzi = (Long) js.executeScript(" return $('#jqxgridJobListing').jqxGrid('getrowvisibleindex'," + rowId + ");");
                // Long rowInd= (Long)
                // js.executeScript("return $('#jqxgridJobListing').jqxGrid('getselectedrowindex');");
                // System.out.println("dd"+rowIndx);
                // js.executeScript("$('#jqxgridJobListing').jqxGrid('ensurerowvisible',"+rowIndx+")");

                // js.executeScript("$('#jqxgridJobListing').jqxGrid('ensurerowvisible', "
                // + rowzi + "); ");
                js.executeScript("$('#jqxgridJobListing').jqxGrid('ensurerowvisible', " + rowzi + "); ");
                break;
            }
            j++;

        }

        driver.findElement(
                By.xpath("//div[@id='contenttablejqxgridJobListing']//div[contains(text(),'" + assignedId
                        + "')]//parent::div/parent::div/div[1]//img")).click();
        Thread.sleep(3000);
        // table[@id='DataTables_Table_0']/tbody/tr[1]/td[1]/img[1]
        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    Thread.sleep(3000);
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(10000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
        Thread.sleep(3000);
    }

    public String drpDwnFldRetained()
    {
        String fld = driver.findElement(By.xpath(".//*[@selected='']")).getText();
        return fld;
    }

    /**
     * @Step("Select the Group Name = \"{0}\"") public void selectTheGroups1(String groups){ WebElement grp = driver.findElement
     *               (By.xpath("//label[contains(text(),'Group(s)')]")); if(grp.isDisplayed()){ String comma = ","; StringTokenizer stMain = new
     *               StringTokenizer(groups, comma); while (stMain.hasMoreElements()) { if("All Records".equalsIgnoreCase(groups)){ driver.findElement
     *               (By.xpath("//label[contains(text(),'"+groups +"')]//preceding::input[1]")).click(); } else { driver.findElement
     *               (By.xpath("(//div[@class='groupNamesDiv']/input[@value='" +groups+"']/preceding::input[1])[1]")).click(); } } } }
     */

    @Step("getProcess job Number")
    public String getJobNum()
    {
        return driver.findElement(By.xpath("//table[@id='tablejob-tree']/tbody/tr[1]/td[3]")).getText();

    }

    public String RemoveComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }

    public void searchProcessOnDashboardAndViewStats(String processName) throws InterruptedException
    {
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processName + "')]/parent::td[1]/following::td[6]/div/a")).click();

    }

    public void clearFilter() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@class='jqx-icon-close']")).click();

    }

    public String searchProcessOnDashboardAndGetTheJobNo(String processName) throws InterruptedException
    {
        // String[] procArr = processName.split(":");
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        String jobNo = driver.findElement(By.xpath("//span[contains(text(),'" + processName + "')]/parent::td[1]/following::td[1]")).getText();
        return jobNo;
    }

    public void clickToViewWorkItemsInDashBoardPage(String processName) throws InterruptedException
    {
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processName + "')]//preceding::span[1]")).click();
    }

    public List<String> getProcessListToApproveInQC(String processId) throws SQLException, InterruptedException
    {

        QC_Tab.click();

        Thread.sleep(10000);
        Connection conn = oracleDBHelper.getConnection();
        String query = null;
        List<String> records = new ArrayList<>();
        query = "select distinct(pm.assigned_id) as Pid from qc_item qc,qc_item_shipping_input_xref qcx,shipping_input_xref sxref,process_master pm where sxref.shipping_process_id = "
                + processId + " and qcx.shipping_input_xref_id = sxref.id and qcx.qc_item_id = qc.id and qc.process_id = pm.id";

        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        int column1Pos = rs.findColumn("Pid");

        while (rs.next())
        {
            String column = rs.getString(column1Pos);
            records.add(column);
        }
        return records;
    }

    public String getShippingProcessId(String assignedId, String name) throws SQLException
    {
        oracleDBHelper = new OracleDBHelper();

        String column = null;
        Connection conn = oracleDBHelper.getConnection();
        String query;

        // List<String> rejectField = new ArrayList<>();

        query = "select id from process_master where assigned_id = '" + assignedId + "'and name='" + name + "'";
        System.out.println("AAAAAAAAAAAAAAAAAAAAAAA: " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        int column1Pos = rs.findColumn("id");

        while (rs.next())
        {
            column = rs.getString(column1Pos);
            System.out.println("column" + column);
        }
        return column;

    }

    public boolean testErrorClassEnabled()
    {

        boolean errStyle = driver.findElement(By.xpath("//div[@class='errMsg']")).isDisplayed();
        System.out.println("test---->>" + errStyle);
        return errStyle;

    }

    public boolean isAllGroupsSelected()
    {
        return allRecordsGroups.isSelected() && allRecordsGroups.isDisplayed();
    }

    public void clickAllGroups()
    {
        allRecordsGroups.click();
    }

    private String getUid(String row)
    {
        String uidVal;
        String[] strSplit = row.split(",");
        uidVal = strSplit[0].substring(strSplit[0].indexOf("boundindex") + 6).trim();
        System.out.println("uidVal" + uidVal + ":Rowinfo:" + row);
        return uidVal;
    }

    // ******************Sample File**********************
    @Step("Fetch Column Data")
    public List<String> fetchColumnData(String itemNo) throws SQLException
    {
        List<String> mapDpFc = new ArrayList<String>();
        oracleDBHelper = new OracleDBHelper();
        Connection conn = oracleDBHelper.getConnection();
        String query = null;
        // List<String> records = new ArrayList<>();
        query = "select id  from work_item where item_number=" + itemNo + "";

        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();

        long id = 0;
        while (rs.next())
        {
            id = rs.getLong(1);
        }
        query = "select id from work_item_artifact where work_item_id=" + id + "";

        PreparedStatement ps1 = conn.prepareStatement(query);
        ResultSet rs1 = ps1.executeQuery();

        long id1 = 0;
        while (rs1.next())
        {
            id1 = rs1.getLong(1);
        }
        query = "select column_name,data_type from work_item_column where table_id=" + id1 + "";

        PreparedStatement ps2 = conn.prepareStatement(query);
        ResultSet rs2 = ps2.executeQuery();
        String colName;
        String dataType;

        while (rs2.next())
        {
            colName = rs2.getString("column_name");
            dataType = rs2.getString("data_type");
            mapDpFc.add(colName);
            mapDpFc.add(dataType);
        }
        conn.close();

        return mapDpFc;

    }

    @Step("Fetching Record  From Green Plum for Table = \"{0}\"")
    public List<String> getTheDroppedRecordsDpSequenceNumber(String tableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = " select dp_sequence_num from fusion_stage" + tableName + " where ssn_dedup_flag='D'";

        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<String> records = new ArrayList<String>();
        int column1Pos = rs.findColumn("dp_sequence_num");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);

            records.add(column1);
        }

        return records;
    }

    @Step("Fetching Record  From Green Plum for Table = \"{0}\"")
    public List<String> getRecords(String tableName) throws SQLException
    {
        List<String> recordArr = new ArrayList<String>();
        Connection conn = gpConnect();
        String query = "select dp_sequence_num,cnx_key from fusion_stage." + tableName + " limit 1";

        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<String> records = new ArrayList<String>();
        int column1Pos = rs.findColumn("dp_sequence_num");
        int column2Pos = rs.findColumn("cnx_key");

        while (rs.next())
        {
            String column1 = rs.getString(column1Pos);
            String column2 = String.valueOf(rs.getLong(column2Pos));

            records.add(column1);
            records.add(column2);

        }

        return records;
    }

    @Step("Fetching Record  From Green Plum for Table = \"{0}\"")
    public String getRecordFromDp_s(String tableName, String seqNum) throws SQLException
    {
        String record = null;
        Connection conn = gpConnect();
        String query = " select dp_sequence_num,cnx_key from fusion_stage." + tableName + " where dp_sequence_num=" + seqNum + "";

        System.out.println("GP Query : " + query);
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        List<String> records = new ArrayList<String>();

        int column2Pos = rs.findColumn("cnx_key");

        while (rs.next())
        {

            record = String.valueOf(rs.getLong(column2Pos));

        }

        return record;
    }

    public void clickToCloseStats()
    {
        driver.findElement(By.xpath("//div[@class='jqx-window-close-button jqx-window-close-button-classic jqx-icon-close jqx-icon-close-classic']"))
                .click();

    }

    public String getTheSelectedOption()
    {

        Select select = new Select(Ele_Data);
        WebElement option = select.getFirstSelectedOption();
        return option.getText();
    }

    public void writeTheDataIntoFile(String processId) throws IOException

    {

        try
        {
            String newLine = System.getProperty("line.separator");
            // String content = "This is the content to write into file";

            File file = new File("C:/Shraddha/importFileProcessName.txt");

            // if file doesnt exists, then create it
            if (!file.exists())
            {
                file.createNewFile();
            }

            FileWriter fw = new FileWriter(file.getAbsoluteFile());
            BufferedWriter bw = new BufferedWriter(fw);
            bw.write(newLine + processId);
            bw.close();

            System.out.println("Done");

        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    @Step("Fetch The Execution Status Of The Dependent Process")
    public String searchProcessOnDashboardAndGetTheExecutionStatus(String processName) throws InterruptedException
    {

        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        // span[contains(text(),'OP453')]/parent::td[1]/following::td[2]/div
        String executionStatus = driver.findElement(By.xpath("//span[contains(text(),'" + processName + "')]/parent::td[1]/following::td[2]/div"))
                .getText();
        clearFilter();
        return executionStatus;
    }

    public String getTheExecutionStatus(String process) throws InterruptedException
    {

        String[] processNameArr = process.split(":");
        String requiredProcessName = processNameArr[0] + "_" + processNameArr[1];

        String finalStatus = null;
        String status = searchProcessOnDashboardAndGetTheExecutionStatus(requiredProcessName);
        switch (status)
        {
        case "PROCESSING":
            LOGGER.info("Dependent Process " + process + " is in Processing state");

            String fetchedStatus = verifyStatusForBaseProcess(requiredProcessName);

            switch (fetchedStatus)
            {
            case "PASS":
                finalStatus = "COMPLETED";
                LOGGER.info("Dependent Process " + process + " is Successfully Completed");
                break;
            case "FAIL":
                finalStatus = "FAILED";
                LOGGER.info("Dependent Process " + process + " is Failed");
                LOGGER.info("Following is the error trace for failed job" + "" + "--->" + fetchTheErrorTraceForFailedJob(requiredProcessName));
                break;
            }
            LOGGER.info("Dependent Process " + process + " is now " + finalStatus + "");
            break;
        case "COMPLETED":
            finalStatus = "COMPLETED";
            LOGGER.info("Dependent Process " + process + " is Successfully Completed");

            break;
        case "FAILED":
            finalStatus = "FAILED";
            LOGGER.info("Dependent Process " + process + " is Failed");
            LOGGER.info("Following is the error trace for failed job" + "" + "--->" + fetchTheErrorTraceForFailedJob(requiredProcessName));
            break;

        default:
            LOGGER.info("Invalid Execution Status");
        }
        return finalStatus;
    }

    @Step("Verify Process Status for Process = \"{0}\"")
    public String verifyStatusForBaseProcess(String completeProcessName) throws InterruptedException
    {
        try
        {
            Thread.sleep(15000);
            // clearFilter();

            clickHomeTab();
            Thread.sleep(15000);

            refresh: while (true)
            {
                try
                {

                    handleAlert();
                    String[] procArr = completeProcessName.split(":");
                    // String requiredProcessName = procArr[0]+"_"+procArr[1];
                    String status = searchProcessOnDashboardAndGetTheExecutionStatus(completeProcessName);
                    System.out.println("status: " + status);
                    if (status.equalsIgnoreCase("FAILED"))
                    {
                        System.out.println(completeProcessName + " Process failed \n Terminated the process!!!");
                        return "FAIL";
                    } else if (status.equalsIgnoreCase("COMPLETED"))
                    {
                        System.out.println(completeProcessName + "Process got completed !!!");
                        break;
                    } else
                    {
                        // clearFilter();
                        Thread.sleep(15000);
                        driver.navigate().refresh();
                        continue refresh;
                    }

                } catch (Exception e)
                {
                    Thread.sleep(15000);
                    driver.navigate().refresh();
                    continue refresh;
                }
            }
            return "PASS";

        } catch (Exception e)
        {
            e.printStackTrace();
            return "FAIL";
        }
    }

    public void handleAlert()
    {
        if (isAlertPresent())
        {
            Alert alert = driver.switchTo().alert();

            System.out.println(alert.getText());
            alert.accept();
            driver.switchTo().defaultContent();
        }
    }

    public boolean isAlertPresent()
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException ex)
        {
            return false;
        }
    }

    public String fetchTheErrorTraceForFailedJob(String procName) throws InterruptedException
    {
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(procName);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + procName + "')]/parent::td[1]/following::td[6]//a")).click();
        driver.findElement(By.xpath("//h3[text()='Error/Warnings Stats']")).isDisplayed();
        String errorTrace = driver.findElement(
                By.xpath("//div[@id='jqxWarnings']//div[@class='jqxCmsContent']//div[@id='css3table']//table//tr[2]//td[3]")).getText();
        driver.findElement(By.xpath("//div[@class='jqx-window-close-button jqx-window-close-button-classic jqx-icon-close jqx-icon-close-classic'"))
                .click();
        Thread.sleep(2500);
        clearFilter();
        return errorTrace;
    }

    public void viewProcessesBasedOnRoles(String role)
    {
        driver.findElement(By.xpath("//div[@id='dropdownlistArrowfusion-role']")).click();
        driver.findElement(By.xpath("//div[contains(text(),'" + role + "')]")).click();
    }

    // CMS FusionCF2-2148
    // [NF] Need abiltiy to Search for Projects within Fusion by "FA" Name or Customer Name
    // also for this story i think changes are yet not deployed on devqa

    public void searchProjWithinCustomerName(String custName, String analyst, String qcAnalyst)
    {
        driver.findElement(By.id("cms_search")).click();
        driver.findElement(By.id("projectNumber")).clear();
        driver.findElement(By.id("projectNumber")).sendKeys(PropertiesUtils.getProperty("project"));

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxComboForCustName').jqxComboBox('selectItem','" + custName + "')");
        js.executeScript("$('#jqxComboForAnalystName').jqxComboBox('selectItem','" + analyst + "')");
        js.executeScript("$('#jqxComboForQCName').jqxComboBox('selectItem','" + qcAnalyst + "')");
        driver.findElement(By.id("searchButton")).click();
    }

    public void searchProjWithCustomerName(String custName)
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxComboForCustName').jqxComboBox('selectItem','" + custName + "')");
        driver.findElement(By.id("searchButton")).click();
    }

    public void searchProjWithAnalystName(String analyst)
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxComboForQCName').jqxComboBox('selectItem','" + analyst + "')");
        driver.findElement(By.id("searchButton")).click();
    }

    public void searchProjWithQCAnalystName(String qcAnalyst)
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxComboForAnalystName').jqxComboBox('selectItem','" + qcAnalyst + "')");

        driver.findElement(By.id("searchButton")).click();
    }

    public void clickSearchTab()
    {
        driver.findElement(By.id("cms_search")).click();
    }

    public void clickProjectSearchButton()
    {
        driver.findElement(By.id("searchButton")).click();
    }

    public void setprojectNumber(String project)
    {

        driver.findElement(By.id("projectNumber")).clear();
        driver.findElement(By.id("projectNumber")).sendKeys(project);
    }

    public String getSearchResultsText()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td")).getText();

    }
    
    public void waitForLoad(WebDriver driver)
    {
        ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>()
                {
            @Override
            public Boolean apply(WebDriver driver)
            {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
                };
                WebDriverWait wait = new WebDriverWait(driver, 8000);
                wait.until(pageLoadCondition);
    }          
}
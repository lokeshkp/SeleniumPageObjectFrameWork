package com.equifax.cms.fusion.test.json;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "statType", "hidden", "statItems" })
public class Stat {

	@JsonProperty("statType")
	private String statType;
	@JsonProperty("hidden")
	private Boolean hidden;
	@JsonProperty("statItems")
	private List<StatItem> statItems = new ArrayList<StatItem>();
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The statType
	 */
	@JsonProperty("statType")
	public String getStatType() {
		return statType;
	}

	/**
	 * 
	 * @param statType
	 *            The statType
	 */
	@JsonProperty("statType")
	public void setStatType(String statType) {
		this.statType = statType;
	}

	/**
	 * 
	 * @return The hidden
	 */
	@JsonProperty("hidden")
	public Boolean getHidden() {
		return hidden;
	}

	/**
	 * 
	 * @param hidden
	 *            The hidden
	 */
	@JsonProperty("hidden")
	public void setHidden(Boolean hidden) {
		this.hidden = hidden;
	}

	/**
	 * 
	 * @return The statItems
	 */
	@JsonProperty("statItems")
	public List<StatItem> getStatItems() {
		return statItems;
	}

	/**
	 * 
	 * @param statItems
	 *            The statItems
	 */
	@JsonProperty("statItems")
	public void setStatItems(List<StatItem> statItems) {
		this.statItems = statItems;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}

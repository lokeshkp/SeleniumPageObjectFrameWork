package com.equifax.cms.fusion.test.utils;

public enum ProcessType {

	SOURCE_MATCH("SM", "Source Match"), INPUT("INPUT", "Input process"), 
	INPUT_DELIM("INPUT_DELIM", "Input Delimited process"), RANDOM_NTH("RANDOM_NTH", "Random Nth process");

	String description;
	String processType;

	ProcessType(String processType, String description) {
		this.processType = processType;
		this.description = description;
	}

	public String getProcessType() {
		return processType;
	}

	public String getDescription() {
		return description;
	}

	@Override
	public String toString() {
		return processType;
	}
}

package com.equifax.cms.fusion.test.SFPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class EditMoveStPage
{
    WebDriver driver;
    public Select sel;

    public EditMoveStPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(id = "name")
    WebElement Name_Fld;

    @FindBy(id = "master-checkbox")
    WebElement Check_All;

    @FindBy(xpath = "//a[contains(text(),'Columns')]")
    WebElement Columns_Btn;

    @FindBy(id = "columnsSelection")
    WebElement ColumnCount;

    @FindBy(xpath = "//a[contains(text(),'Save')]")
    WebElement SaveEditCol_Btn;

    @Step("Click on Back button")
    public void clickBackButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[1]")).click();
    }

    @Step("Click on Save button")
    public void clickSaveButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[2]")).click();
    }

    @Step("Click on Continue button")
    public void clickContinueButton()
    {
        WebElement ele = driver.findElement(By.xpath("(.//*[@class='orange-btn'])[3]"));
        ele.click();
    }

    @Step("Provide Edit Move Statement Name")
    public void inputMovStName(String movStName)
    {
        if (!"NA".equalsIgnoreCase(movStName))
        {
            Name_Fld.sendKeys(movStName);
        }
    }

    @Step("Save move statement")
    public void clickMoveStmntSave()
    {

        driver.findElement(By.xpath(".//*[@class='buttons']/input[1]")).click();
    }

    @Step("Continue click on move statement")
    public void continueClick()
    {

        driver.findElement(By.xpath(".//*[@class='buttons']/input[2]")).click();
    }

    @Step("Select Move Statement fields = \"{0}\"")
    public void selectMoveStFields(String movFields)
    {
        if ("ALL".equalsIgnoreCase(movFields))
        {
            Check_All.click();
        } else
        {
            String delimiter = ",";
            StringTokenizer stMain = new StringTokenizer(movFields, delimiter);
            while (stMain.hasMoreElements())
            {
                driver.findElement(By.xpath("//input[@value='" + stMain.nextToken() + "']/preceding::td[2]/input[1]")).click();
            }
        }
    }

    @Step("Click Columns button")
    public void clickColumnsBtn()
    {
        Columns_Btn.click();
    }

    @Step("Select the Colomn Count = \"{0}\"")
    public void selectColumnCount(String count)
    {
        sel = new Select(ColumnCount);
        sel.selectByVisibleText(count);
    }

    @Step("Provide column Positions = \"{0}\" \"{1}\" \"{2}\"")
    public void columnPositions(String count, String literal)
    {
        String delims1 = ";";
        String sup = "-";
        int i = 0;
        StringTokenizer stMain = new StringTokenizer(literal, delims1);
        while (stMain.hasMoreElements())
        {
            String[] splitString = stMain.nextToken().split(sup);
            if ("1".equalsIgnoreCase(count))
            {
                driver.findElement(By.xpath("//input[@id='colValPosList0.columnPosition']")).sendKeys(splitString[0]);
                driver.findElement(By.xpath("//input[@id='colValPosList0.valuePosition']")).sendKeys(splitString[1]);

            } else
            {
                driver.findElement(By.xpath("//input[@id='colValPosList" + i + ".columnPosition']")).sendKeys(splitString[0]);
                driver.findElement(By.xpath("//input[@id='colValPosList" + i + ".valuePosition']")).sendKeys(splitString[1]);
                i++;
            }
        }
    }

    @Step("Save in Edit Columns screen")
    public void clickSaveEditCol()
    {
        SaveEditCol_Btn.click();
    }

    public void editMoveStatement(String fProName, String movFields, String colCount, String literalValue)
    {
        if (!"NA".equalsIgnoreCase(movFields))
        {
            inputMovStName(fProName);
            selectMoveStFields(movFields);
            clickColumnsBtn();
            selectColumnCount(colCount);
            columnPositions(colCount, literalValue);
            clickSaveEditCol();
        } else if ("ALL".equalsIgnoreCase(movFields))
        {

        }
    }

    public boolean isApplyChangesBtnEnabled()
    {
        try
        {
            String view = driver.findElement(By.id("applyChangesButton")).getAttribute("class");
            if ("anchorButtonSmall_2".equalsIgnoreCase(view))
            {
                return true;
            } else
            {
                return false;
            }
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public int getNoOfRowsDisplayed()
    {
        int rows = driver.findElements(By.xpath(".//*[@id='table_body']/tr")).size();
        return rows;

    }

    public String getFirstLiteralOfMoveStatement()
    {
        return driver.findElement(By.xpath(".//*[@id='table_body']/tr[1]/td[3]/input")).getAttribute("value");
    }

    public String getLastLiteralofMoveStatement()
    {
        return driver.findElement(By.xpath(".//*[@id='table_body']/tr[56]/td[3]/input")).getAttribute("value");
    }

    public int countOfSorterIMG()
    {
        return driver.findElements(By.xpath(".//*[@id='table_body']/tr/td[1]/span")).size();
    }

}

package com.equifax.cms.fusion.test.MJpages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataProcessingTabMJ
{
    WebDriver driver;
    public Select selType;

    public DataProcessingTabMJ(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Match Join")
    WebElement MatchJoinButton;

    @Step("Clicked Match Join Button")
    public void clickMatchJoinButton()
    {
        MatchJoinButton.click();
    }

  //  @Step("Fetched Process Status")
   // public String getProcessStatus()
    //{
       // String status = driver.findElement(By.xpath("//table[@id='dnsTable']/tbody/tr[1]/td[3]/div")).getText();
      ///  return status;
   // }
  
    
  @Step("Fetched Process Status")
     public String getProcessStatus()
     {
         String status = driver.findElement(By.xpath("//div[@class='jqx-grid-content jqx-widget-content']//div[@id='row0jqxgridJobListing']/div[3]/div")).getText();
        return status;
     }
    @Step("Clicked Duplicate for MJ Process")
    public void selectDuplicateMJ()
    {
        driver.findElement(By.xpath(".//*[@id='dnsTable_wrapper']/div[2]/div[2]/table/tbody/tr[1]/td[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.id("dup-row")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Step("Clicked Summary for MJ Process")
    public void selectSummaryMJ()
    {

        driver.findElement(By.xpath(".//*[@id='dnsTable_wrapper']/div[2]/div[2]/table/tbody/tr[1]/td[1]")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Summary")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Summary")).click();

    }

    @Step("Clicked Summary for MJ Process")//edits only first recent process
    public void selectEditMJ()
    {

        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']//parent::div/div[1]//img[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
    }

        
    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

}

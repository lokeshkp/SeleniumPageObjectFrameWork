package com.equifax.cms.fusion.test.RFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;

public class RFCommonMethods {

    WebDriver driver;
    private CommonMethods commonMethods;
    private boolean acceptNextAlert = true;
    public RFCommonMethods(WebDriver driver){
        this.driver = driver;

    }

    @FindBy(xpath = "(.//*[@id='fileOption'])[1]")
    WebElement Ele_FromImportFile;

    @FindBy(id = "fromProcessId")
    WebElement Ele_ProcessSupprFile;

    @FindBy(id = "shippedFileId")
    WebElement Ele_ProcessSupprShippedFile;

    @FindBy(id = "itemTableId")
    WebElement Ele_DataSupprFile;

    @FindBy(xpath = "(.//*[@id='fileOption'])[2]")
    WebElement Ele_FromPreviousProject;

    @FindBy(id = "prioritySelection1")
    WebElement Ele_HighestPriority;

    @FindBy(id = "prioritySelection2")
    WebElement Ele_LowestPriority;

    @FindBy(id = "linkAccept_0")
    WebElement Ele_Accepts_Exclusion;

    @FindBy(id = "projectNumber")
    WebElement Ele_Previous_Project;

    @Step("click on excluison gearbox for accept")
    public void clickAcceptsExclusionGearBox()
    {
        Ele_Accepts_Exclusion.click();
    }
    @Step ("Select From Imported File = \"{0}\"")
    public void selectImportedFileRbutton(String processFile){
        WebElement file = Ele_FromImportFile;

        if("yes".equalsIgnoreCase(processFile)){
            if(file.isSelected()){
                System.out.println("Option is already selected...");
            } else {
                file.click();
            }
        }
    }

    @Step ("Select Process File = \"{0}\"")
    public void selectProcessForImpFile(String process){
        Select psf = new Select(Ele_ProcessSupprFile);
        psf.selectByVisibleText(process);
    }

    @Step ("Select Data File = \"{0}\"")
    public void selectDataForImpFile(String data){
        Select psf = new Select(Ele_DataSupprFile);
        psf.selectByVisibleText(data);
    }

    @Step ("Provide the Previous Project Name When From Imported File Option Is Selected In Suppression File And Click On Search Button")
    public void previousProjectNameField(String projectName) throws InterruptedException
    {
        Ele_Previous_Project.clear();
        Ele_Previous_Project.sendKeys(projectName);
        Thread.sleep(1000);
        driver.findElement(By.id("searchButton")).click();
        Thread.sleep(2000);
    }

    @Step ("Select Shipped File = \"{0}\"")
    public void selectShippedFileForPreviousProjectFile(String shippedFile) throws InterruptedException
    {
        /*        Select select = new Select(Ele_ProcessSupprShippedFile);
        select.selectByVisibleText(shippedFile);*/
        /*Ele_ProcessSupprShippedFile.click();
        WebElement grp = driver.findElement(By.id("shippedFileId"));
        List<WebElement> dropdown = grp.findElements(By.tagName("option"));
        for(WebElement drop:dropdown)
        {
            if(drop.getText().startsWith(shippedFile))
            {

                String value=drop.getAttribute("value");
                Thread.sleep(5000);
                Select select = new Select(Ele_ProcessSupprShippedFile);
                WebDriverWait wait = new WebDriverWait(driver, 30);
                new WebDriverWait(driver,100).until(ExpectedConditions.visibilityOfElementLocated(By.id("shippedFileId")));
                commonMethods.waitForElement(driver.findElement(By.xpath("//*[@id='shippedFileId']")));
                Thread.sleep(5000);
                select.selectByValue(value);
                  Thread.sleep(5000);
                break;

            }

        }
        Thread.sleep(3000);*/
        By byXpath = By.xpath("//select[@id='shippedFileId']/option[contains(text(),'"+shippedFile+"')]");
        driver.findElement(byXpath).click();
    }


    @Step ("Select From Previous Project option")
    public void selectPreviousProjectRbutton()
    {
        Ele_FromPreviousProject.click();
    }
    @Step ("Select From Previous Project option = \"{0}\"")
    public void selectPreviousProjectbutton(String processFile){
        WebElement previousProj =  Ele_FromPreviousProject;

        if("yes".equalsIgnoreCase(processFile)){
            if(previousProj.isSelected())
            {
                System.out.println("Option is already selected...");
            } else {
                previousProj.click();
            }
        }
    }
    @Step ("Select Record Status = \"{0}\"")
    public void selectRecordStatus(String recStatus){

        if("Tag".equalsIgnoreCase(recStatus)){
            if(driver.findElement(By.id("recordStatus1")).isSelected())
            {
                System.out.println("Not required to select");
            }
            else
            {
                driver.findElement(By.id("recordStatus1")).click();
            }


        } else if ("Reject".equalsIgnoreCase(recStatus))
        {
            driver.findElement(By.id("recordStatus2")).click();

        } else if ("Drop".equalsIgnoreCase(recStatus))
        {
            driver.findElement(By.id("recordStatus3")).click();

        } else
        {
            System.out.println("Wrong information has given in the Input Excel sheet!!!");
        }
    }

    @Step ("Select Keep Highest = \"{0}\"")
    public void selectPriorityLevel(String priSelection){
        WebElement keepHighest = Ele_HighestPriority;
        WebElement keepLowest = Ele_LowestPriority;
        if("high".equalsIgnoreCase(priSelection)){
            if(keepHighest.isSelected()){
                System.out.println("Keep Highest is already selected, not required to select..");
            } else {
                keepHighest.click();
            }
        } else if("low".equalsIgnoreCase(priSelection)){
            if(keepLowest.isSelected()){
                System.out.println("Keep Lowest is already selected, not required to select..");
            } else {
                keepLowest.click();
            }
        } else {
            System.out.println("Provide proper information in input excel sheet...");
        }
    }

    @Step ("Select custom fields and priority field = \"{0}\" \"{1}\"")
    public void selectCustomFields(String customField, String priorityField){
        String delimiter = ",";
        StringTokenizer field = new StringTokenizer(customField, delimiter);
        while(field.hasMoreTokens()){
            String dynPath = ".//a[contains(text(),'"+field.nextToken()+"')]";
            driver.findElement(By.xpath(dynPath)).click();
            driver.findElement(By.id("add_dedupe")).click();
        }
        String dynPath1 = ".//a[contains(text(),'"+priorityField+"')]";
        driver.findElement(By.xpath(dynPath1)).click();
        driver.findElement(By.id("add_dedupe2")).click();
    }
    public List<String> getAvaliableExlusionsFromExclusionPopupForAcceptRecordType() throws InterruptedException
    {


        clickAcceptsExclusionGearBox();
        driver.switchTo().frame("sb-player");
        Thread.sleep(1000);

        List<String> fetchedExclusions=fetchExclusionsFromThePopup();


        return fetchedExclusions;
    }
    public List<String> getAvaliableExlusionsFromExclusionPopupForRejectRecordType(String rejects) throws InterruptedException
    {
        List<String> fetchedExclusions=new ArrayList<String>();

        String delimiter = ",";
        StringTokenizer eachChkBoxText = new StringTokenizer(rejects, delimiter);

        while (eachChkBoxText.hasMoreTokens())
        {
            String dynamicId = clickRejectExclusionGearBox(eachChkBoxText.nextToken());
            System.out.println("DYNAMIC_ID : " + dynamicId);
            driver.findElement(By.id(dynamicId)).click();
            driver.switchTo().frame("sb-player");
            Thread.sleep(2000);
            List<String> exclusionList=fetchExclusionsFromThePopup();
            fetchedExclusions.addAll(exclusionList);
        }

        return  fetchedExclusions;

    }
    public List<String> fetchExclusionsFromThePopup()
    {

        List<String> exclusionList=new ArrayList<String>();
        List<WebElement> elementList=driver.findElements(By.xpath("//h3[contains(text(),'Select Exclusions')]/following::div/table/tbody/tr/td[2]/span"));
        for(int i = 0; i < elementList.size(); ++i)
        {
            String fetchedExlusion = elementList.get(i).getText();
            exclusionList.add(fetchedExlusion);
        }
        return exclusionList;
    }
    private enum RECORDREJECT
    {
        NH, nh, FR, fr, NP, np, PS, ps, RJ, rj, RP, rp, ID, id, IP, ip, CE, ce, RD, rd, DP, dp, HS, hs, ND, nd, DB, db, CT, ct, DD, dd, SR, sr, NA, na, SN, sn, NX, nx, RS, rs, DS, ds, DN, dn
    }

    public static String clickRejectExclusionGearBox(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "linkReject_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "linkReject_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "linkReject_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "linkReject_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "linkReject_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "linkReject_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "linkReject_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "linkReject_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "linkReject_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "linkReject_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "linkReject_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "linkReject_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "linkReject_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "linkReject_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "linkReject_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "linkReject_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "linkReject_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "linkReject_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "linkReject_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "linkReject_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "linkReject_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "linkReject_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "linkReject_22";
            break;

        }
        return dynamicCheckBoxId;
    }
    @Step("Get Page Title")
    public String getPageTitle()
    {
        return driver.findElement(By.xpath(".//*[@class='fusion-h3Title']")).getText();
    }
    @Step("Fetching the job id from the configuration page")
    public String  getJobfield()
    {

        String jobfieldValue=driver.findElement(By.xpath("//span[@id='jobId']")).getText();

        return jobfieldValue;
    }
    @Step("Fetching the job id from the configuration page")
    public String  getTheInputFromTheSourceMatchSumm()
    {

        String procName=driver.findElement(By.xpath(" //h2[starts-with(text(),'Input')]/following::table[@id='smDataTable']/tbody/tr/td[1]")).getText();
       //[] inputProcNameArr=procName.split(":");

        return procName;
    }

    //h2[starts-with(text(),'Input')]/following::table[@id='smDataTable']/tbody/tr/td[1]
    public boolean isRefinmentProcessPresent(String refinmentProcName)
    {
        Boolean processFound = false;
        List<WebElement> options = driver.findElements(By.xpath("//select[@id='fromProcessId']/option"));

        for(int i=1; i<options.size(); i++)
        {
            if(options.get(i).getText().equalsIgnoreCase(refinmentProcName))
            {
                processFound=true;
                options.get(i).click();
                break;
            }

        }
        return processFound;
    }
    @Step("Fetch the Process Name")
    public String getProcessNameFromSummary()
    {
        String pName = driver.findElement(By.xpath("//label[starts-with(text(),'Process Name:')]/following::span[1]")).getText();
        String procNameFromSummary=pName.replaceAll("\\s+","");
        return procNameFromSummary;
    }

    public void handleAlert() throws InterruptedException
    {
        boolean a;
        a = isAlertPresent();
        if (a)
        {
            try
            {
                Alert alert = driver.switchTo().alert();
                String alertText = alert.getText();
                if (acceptNextAlert)
                {
                    alert.accept();
                } else
                {
                    alert.dismiss();
                }
                System.out.println(alertText);
            } catch (Exception e)
            {

            } finally
            {
                acceptNextAlert = true;
            }
        }
    }
    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }
    @Step("Select the Group Name = \"{0}\"")
    public void selectTheGroupsForRefinmentProcess(String groups) throws InterruptedException
    {
        Thread.sleep(3000);
        if (!groups.equalsIgnoreCase("NA"))
        {
            WebElement grp = driver.findElement(By.xpath("//label[contains(text(),'Group(s)')]"));
            if (grp.isDisplayed())
            {
                if ("All Records".equalsIgnoreCase(groups))
                {
                    driver.findElement(By.xpath("//label[text()='" + groups + "']//preceding::input[1]")).click();
                } else
                {
                    String comma = ",";
                    StringTokenizer stMain = new StringTokenizer(groups, comma);
                    while (stMain.hasMoreElements())
                    {
                        driver.findElement(
                                By.xpath("(//div[@class='groupNamesDiv']/input[@value='" + stMain.nextToken() + "']/preceding::input[1])[1]"))
                                .click();
                    }
                }
            }
        }
    }


}

package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataOriginPage {

		WebDriver driver;
		
	public DataOriginPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "dataOrigin")
	public WebElement Ele_dataOrigin;
	
	@FindBy(xpath = ".//input[@type='submit']")
	WebElement ContinueButton;
	
	@Step("Select Data Origin Field :  \"{0}\"")
	public void selectDataOriginField(String FieldType)
	{
		Select selType = new Select(Ele_dataOrigin);
		selType.selectByVisibleText(FieldType);
	}
	
	@Step("Click Continue Button on Data Origin Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
}

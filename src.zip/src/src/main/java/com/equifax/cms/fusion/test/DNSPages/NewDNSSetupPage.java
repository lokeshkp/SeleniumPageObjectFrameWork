package com.equifax.cms.fusion.test.DNSPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class NewDNSSetupPage {
	
	WebDriver driver;
	public Select selType;
	
	public NewDNSSetupPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "name")
	public WebElement DNSProcessName_Field;
	
	@FindBy(id = "fromProcessId")
	WebElement DNSInputProcess_DD;
	
	@FindBy(xpath = ".//*[@id='fromProcessId']/option[1]")
	WebElement ProcessSelectOption;
	
	@FindBy(xpath = "(.//*[@selected='selected'])[2]")
	WebElement DNS_DataDD_SELECTED;
	
	@FindBy(id = "itemTableId")
	public WebElement DNSInputData_DD;
	
	@FindBy(id = "jobId")
	WebElement  DNSJobNo;
	
	@FindBy(id = "listVirtualArtifacts0.userProvidedName")
	WebElement DNSOutputTableNameField;
	
	@FindBy(xpath = ".//*[@id='dnsForm']/div[3]/a")
	WebElement BackButton;
	
	@FindBy(xpath = "//input[@value='Save']")
	WebElement SaveButton;
	
	@FindBy(xpath = ".//*[@id='dnsForm']/div[3]/input[2]")
	WebElement SubmitButton;
	
	@FindBy(id = "textMsg")
	WebElement textMessage;
	
	@FindBy(id = "erMsg")
	WebElement errorMessage;
	
	@FindBy(id = "allRecordsGroups")
	WebElement AllRecsGrp;
	
	@FindBy(xpath = ".//*[@id='groupNames0'][1]")
	WebElement Grp1;
	
	@FindBy(xpath = ".//*[@name='groupNames[1].isSelected']")
	WebElement Grp2;
	
	@FindBy(xpath = ".//*[@name='groupNames[2].isSelected']")
	WebElement Grp3;
	
	@FindBy(xpath = ".//*[@id='listVirtualArtifacts0.generatedName']")
	WebElement outputTableName;
	
	@FindBy(id = "ppCodeDiv")
	WebElement ppCodeSelection;
	
	@FindBy(xpath = "(.//*[@class='fusion-h3Title'])[3]")
	WebElement PageTitle;
	
	@Step("DNS Process Page Title")
	public String pageTitle(){
		return PageTitle.getText().trim();
	}
	
	@Step("{method}")
	public boolean isRecordSelectionDispalyed() {
		try {
			ppCodeSelection.click();
			return true;
		}catch(org.openqa.selenium.NoSuchElementException e){
			return false;
		}
		
	}
	
	@Step("{method}")
	public String getDNS_Data_DD_Selected(){
		return DNS_DataDD_SELECTED.getAttribute("value");	
	}
	
	@Step("{method}")
	public String getDefaultOPName() {
		return outputTableName.getAttribute("value");
	}
	
	@Step("{method}")
	public String getDNSOPName() {
		return DNSOutputTableNameField.getAttribute("value");
	}
	
	@Step("{method}")
	public boolean isAllRecordsSelected() {
		return AllRecsGrp.isSelected();
	}
	
	@Step("{method}")
	public boolean isGrp1Selected() {
		return Grp1.isSelected();
	}
	
	@Step("{method}")
	public boolean isGrp2Selected() {
		return Grp2.isSelected();
	}
	
	@Step("{method}")
	public boolean isGrp3Selected() {
		return Grp3.isSelected();
	}
	
	@Step("{method}")
	public String getJobNo() {
		return DNSJobNo.getText();
	}
	
	@Step("{method}")
	public String gettextMessage() {
		return textMessage.getText();
	}
	
	@Step("Fetch Error Message")
	public String getErrorMessage() {
		return errorMessage.getText();
	}
	
	@Step("Provided Process Name as : {0}")
	public void inputProcessName(String ProcessName){
		DNSProcessName_Field.clear();
		DNSProcessName_Field.sendKeys(ProcessName);
	}
	
	@Step("Selected Input Process as : {0}")
	public void selectProcess(String Process){
		selType = new Select(DNSInputProcess_DD);
		selType.selectByVisibleText(Process);
	}
	
	@Step("Selected Data as : {0}")
	public void selectData(String Data) throws InterruptedException{
		Thread.sleep(10000);
		selType = new Select(DNSInputData_DD);
		selType.selectByVisibleText(Data);
	}
	
	@Step("Provided Output Table Name as : {0}")
	public void inputOutputTableName(String Name){
		DNSOutputTableNameField.clear();
		DNSOutputTableNameField.sendKeys(Name);
	}
	
	@Step("Clicked Back Button")
	public void clickBackButton(){
		BackButton.click();
	}
	
	@Step("Clicked Save Button")
	public void clickSaveButton() {
		SaveButton.click();
		
	}
	
	@Step("Clicked Submit Button")
	public void clickSubmitButton(){
		SubmitButton.click();
	}
	
}

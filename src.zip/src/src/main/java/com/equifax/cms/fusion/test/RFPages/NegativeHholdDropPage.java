package com.equifax.cms.fusion.test.RFPages;

import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class NegativeHholdDropPage {

		WebDriver driver;
		
	public NegativeHholdDropPage(WebDriver driver){		
		this.driver = driver;
		
	}
	
	@FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/h3")
	WebElement ScreenTitle;
	
	@FindBy(id = "textMsg")
	WebElement ErrorMessage;
	
	@FindBy(id = "addButton")
	WebElement AddCondition;
	
	@FindBy(xpath = ".//*[@id='DataTables_Table_0']/tbody/tr/td[1]/input[1]")
	WebElement Ele_CriteriaLevel;
	
	@FindBy(xpath = ".//*[@id='DataTables_Table_0']/tbody/tr/td[2]/input")
	WebElement Ele_TagValue;
	
	@FindBy(xpath = ".//*[@id='DataTables_Table_0']/tbody/tr/td[3]/input")
	WebElement Ele_RejectCode;
	
	@FindBy(xpath = ".//input[@value='Save']")
	WebElement SaveButton;
	
	@FindBy(xpath = "(.//*[@name='submitButton'])[2]")
	WebElement ContinueButton;
	
	@Step ("Click Add Button")
	public void clickAddCondition(){
		AddCondition.click();
	}
	
	@Step ("Criteria Level value = \"{0}\"")
	public void criteriaLevel(String critLevel){
		Ele_CriteriaLevel.sendKeys(critLevel);
	}
	
	@Step ("Clear Criteria Level value")
	public void clearCriteriaLevel(){
		Ele_CriteriaLevel.clear();
	}
	
	@Step ("Tag value = \"{0}\"")
	public void tagValue(String tagValue){
		Ele_TagValue.sendKeys(tagValue);
	}
	
	@Step ("Reject Code = \"{0}\"")
	public void rejectCode(String rejCode){
		Ele_RejectCode.sendKeys(rejCode);
	}
	
	@Step ("Saved the process")
	public void clickSaveButton(){
		SaveButton.click();
	}
	
	@Step ("Continue the process")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
	@Step ("Screen Title:")
	public String getTitle(){
		return ScreenTitle.getText();	
	}
	
	@Step("Error message is ")
	public String getErrMsg(){
		return ErrorMessage.getText();
	}
	
	}


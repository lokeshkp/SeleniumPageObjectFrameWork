package com.equifax.cms.fusion.test.INQpage;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class InqSummaryPage {
	WebDriver driver;
	
	public InqSummaryPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = "//button[@id='Submit']")
	WebElement Submit_Btn;
	
	@Step("Submit the Process")
	public void clickSubmitButton() {
		Submit_Btn.click();
	}

}

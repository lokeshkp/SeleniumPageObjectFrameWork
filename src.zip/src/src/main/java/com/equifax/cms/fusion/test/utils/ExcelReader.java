package com.equifax.cms.fusion.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.vo.InputLayoutVO;
import com.equifax.cms.fusion.test.vo.InputProcessVO;
import com.equifax.cms.fusion.test.vo.RandomNthVO;
import com.equifax.cms.fusion.test.vo.SMProcessInputVO;

public class ExcelReader {

	private static final String TEST_DATA = "testdata";

	private static final Logger LOGGER = LoggerFactory.getLogger(ExcelReader.class);

	private XSSFWorkbook workbook;
	private Map<String, String> properties;
	private Map<String, String> xRef;

	public ExcelReader() {
		loadInputDataFile();
		loadTestProperties();
	}

	private void loadInputDataFile() {

		try {

			// load environment
			String env = PropertiesUtils.getEnvironment();
			// load test data for that environment
			String data = PropertiesUtils.getProperty(TEST_DATA);
			String filePath = env + "/" + data;
			LOGGER.debug("-- loading data file >>> {} ", filePath);
			ClassLoader classLoader = getClass().getClassLoader();
			File resource = new File(classLoader.getResource(filePath).getFile());

			FileInputStream file = new FileInputStream(resource);
			workbook = new XSSFWorkbook(file);

		} catch (FileNotFoundException e) {
			LOGGER.error("unable to open exel input file error {} ", e.getMessage());
			e.printStackTrace();
			System.exit(-9);
		} catch(IOException io) {
			LOGGER.error("unable to open exel input file error {} ", io.getMessage());
			io.printStackTrace();
			System.exit(-9);
		}
	}

	// to retrieve SM data from excel, read from data sheet SM
	

	// to get test system properties
	// store in test data input Test_Data_Input.xlsx in TEST_PROPERTIES sheet
	// e.g
	// project_number = 2000
	// INPUT_FILE_PATH = /nas/user/jbodeddula/d
	public Map<String,String> getTestProperties() {

		if (null == properties) {
			loadTestProperties();
		}
		return properties;
	}

	// load properties from TEST_PROPERTIES only once
	private void loadTestProperties() {
		XSSFSheet sheet = workbook.getSheet("TEST_PROPERTIES");
		// properties = new HashMap<String, String>();
		// 0 line is header line
		// skipping the header , all process should have the same column
		// type
		LOGGER.debug("loading xpath reference  TEST_PROPERTIES sheet ");
		properties = getKeyValue(sheet);
	}

	public Map<String, String> getXpathRef() {

		if (null == xRef) {
			LOGGER.debug("loading xpath reference  EXT_XPATH_LINKS sheet ");
			XSSFSheet sheet = workbook.getSheet("EXT_XPATH_LINKS");
			xRef = getKeyValue(sheet);
		}

		return xRef;

	}

	private Map<String, String> getKeyValue(XSSFSheet sheet) {

		Map<String, String> map = new HashMap<String, String>();
		for (int rownum = 1; rownum < sheet.getPhysicalNumberOfRows(); rownum++) {

			XSSFRow row = sheet.getRow(rownum);
			String key = getCellValue(row, 0);
			String value = getCellValue(row, 1);
			map.put(key, value);

		}
		return map;
	}

	// to retrieve input process data from excel, read from data sheet INPUT
	/**
	 * read excel data and converts to {@link InputProcessVO}
	 *
	 * @return {@link List}
	 */
	public List<InputProcessVO> getInputProcessData() {

		XSSFSheet sheet = workbook.getSheet(ProcessType.INPUT.processType);
		List<InputProcessVO> list = new ArrayList<InputProcessVO>();

		// 0 line is header line
		// skipping the header , all process should have the same column type
		for (int rownum = 1; rownum < sheet.getPhysicalNumberOfRows(); rownum++) {

			XSSFRow row = sheet.getRow(rownum);
			InputProcessVO vo = new InputProcessVO();
			vo.setTestScenario(getCellValue(row, 0));
			vo.setProcessName(getCellValue(row, 1));
			vo.setType(getCellValue(row, 2));
			vo.setPurpose(getCellValue(row, 3));
			vo.setLocation(getCellValue(row, 4));
			vo.setFormat(getCellValue(row, 5));
			vo.setRecordLength(getCellValue(row, 6));
			vo.setStartingSeq(getCellValue(row, 7));
			vo.setOutputTable(getCellValue(row, 8));
			vo.setInputLayout(getCellValue(row, 9));
			vo.setLayoutName(getCellValue(row, 10));
			vo.setOperation(getCellValue(row, 11));
			vo.setExpectedStatus(getCellValue(row, 12));
            vo.setDelimiter(getCellValue(row, 13));
            vo.setIsDataCheck(getCellValue(row, 14));
            vo.setFileIdentifier(getCellValue(row, 15));
            vo.setBlankFields(getCellValue(row, 16));
            vo.setSingleValueFields(getCellValue(row, 17));
            vo.setUnknownFields(getCellValue(row, 18));
            vo.setRuntimeB(getCellValue(row, 19));
            vo.setSearchLayoutFromOtherProj(getCellValue(row, 20));
            list.add(vo);
		}

		return list;
	}

	private String getCellValue(XSSFRow row, int rownum) {

		if (null != row.getCell(rownum)) {
			XSSFCell cell = row.getCell(rownum);
			cell.setCellType(Cell.CELL_TYPE_STRING);
			return cell.getStringCellValue();
		} else {
			return null;
		}
	}

	@Override
	protected void finalize() throws Throwable {
		workbook.close();
		super.finalize();
	}

	// get layout name
	/**
	 * returns details for the specific layout, return empty list if layout is
	 * null
	 *
	 * @param layoutName
	 * @return {@link InputLayoutVO}
	 */
	public List<InputLayoutVO> getInputLayout(String layoutName) {
		XSSFSheet sheet = workbook.getSheet("INPUT_LAYOUT");

		List<InputLayoutVO> list = new ArrayList<InputLayoutVO>();
		// 0 line is header line
		// skipping the header , all process should have the same column
		// type
		for (int rownum = 1; rownum < sheet.getPhysicalNumberOfRows(); rownum++) {

			XSSFRow row = sheet.getRow(rownum);

			if (layoutName.equalsIgnoreCase(getCellValue(row, 0))) {
				InputLayoutVO vo = new InputLayoutVO();
				vo.setLayoutName(getCellValue(row, 0));
				vo.setFieldType(getCellValue(row, 1));
				vo.setFieldName(getCellValue(row, 2));
				vo.setStartPos(getCellValue(row, 3));
				vo.setEndPos(getCellValue(row, 4));
                vo.setConstName(getCellValue(row, 5));
                vo.setConstValue(getCellValue(row, 6));
                vo.setPurpose(getCellValue(row, 7));
                vo.setFileType(getCellValue(row, 8));
                vo.setHeaderRows(getCellValue(row, 9));
                vo.setCheckCleanse(getCellValue(row, 10));
                vo.setCheckSingle(getCellValue(row, 11));
                vo.setCheckMulti(getCellValue(row, 12));

				list.add(vo);
			}

		}
		return list;
	}

	// to retrieve SM data from excel, read from data sheet SM
	public List<RandomNthVO> getRandomNthInputData() {

		XSSFSheet sheet = workbook.getSheet(ProcessType.RANDOM_NTH.processType);
		if (null == sheet) {
			LOGGER.error(">>> unable to open data input excel sheet.\n Check  " + ProcessType.RANDOM_NTH.processType);
			LOGGER.error("Sheet name present in the data file.");
		}
		List<RandomNthVO> list = new ArrayList<RandomNthVO>();

		// 0 line is header line
		// skipping the header , all process should have the same column type
		for (int rownum = 1; rownum < sheet.getPhysicalNumberOfRows(); rownum++) {

			XSSFRow row = sheet.getRow(rownum);
			RandomNthVO vo = new RandomNthVO();
			vo.setTestScenario(getCellValue(row, 0));
			vo.setProcessName(getCellValue(row, 1));
			vo.setInputProcess(getCellValue(row, 2));
			vo.setData(getCellValue(row, 3));
			vo.setOutputTable(getCellValue(row, 4));
			vo.setNumOfOutput(getCellValue(row, 5));
			vo.setRecordType(getCellValue(row, 6));
			vo.setOperation(getCellValue(row, 7));
			vo.setExpectedStatus(getCellValue(row, 8));
			list.add(vo);
		}

		return list;
	}

	
	
	public List<SMProcessInputVO> getSourceMatchInputData() {
		// TODO Auto-generated method stub
		return null;
	}

//	// Dirty test
//	// Since don't want to added test for test
//	// however it bad
//	public static void main(String[] args) {
//		ExcelReader reader = new ExcelReader();
//		List<InputProcessVO> list = reader.getnputProcessData();
//		System.out.println(list.toString());
//	}
}

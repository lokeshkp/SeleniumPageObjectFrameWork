package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ConfigDeStandPage {

		WebDriver driver;
		public Select selType;
		
	public ConfigDeStandPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "runDeStd")
	public WebElement Ele_RunDEStandards;
	
	@FindBy(id = "useSameOptionForAllCriteria")
	public WebElement CB_UseSameOption;
	
	@FindBy(id = "useSameDateCheckForAllCriteria")
	public WebElement CB_useSameDateCheck;
	
	@FindBy(id = "source")
	public WebElement DD_Source;
	
	@FindBy(xpath = "(.//*[@selected='selected'])[1]")
	public WebElement AllCritCodeSrcValue;
	
	@FindBy(xpath = ".//*[@id='useSameDateCheckForAllCriteria']")
	public WebElement dateWithinSixMonths;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement ContinueButton;
	
	@Step("Select Souorce as :  \"{0}\" ")
	public void selectSource(String val){
		Select sl = new Select(DD_Source);
		sl.selectByValue(val);
	}
	
	@Step("Click Use Same Option For All Criteria Check Box")
	public void clickuseSameOption(){
		CB_UseSameOption.click();
	}
	
	@Step("Click Use Same Date Check For All Criteria Check Box")
	public void clickuseSameDateCheck(){
		CB_useSameDateCheck.click();
	}
	
	@Step("Click Run DE Standard Check Box")
	public void clickRunDeStandardsChckBox(){
		Ele_RunDEStandards.click();
	}
	
	@Step("Click Continue Button on Configure DE Stndrd Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
	@Step("Select Run DE Standard Check Box")
	public void selectRunDeStandardCheckBox(String deStandard){
		if(deStandard.equalsIgnoreCase("ON")){
			if(Ele_RunDEStandards.isSelected()){
				System.out.println("Run DE Standards is already been selected");
			} else {
				clickRunDeStandardsChckBox();
			}
		} else {
			if(Ele_RunDEStandards.isSelected()){
				clickRunDeStandardsChckBox();
			} else {
				System.out.println("Run DE Standards is already been unselected");
			}
		}
	}
	
}

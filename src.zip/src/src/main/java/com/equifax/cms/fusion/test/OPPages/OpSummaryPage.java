package com.equifax.cms.fusion.test.OPPages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class OpSummaryPage
{
    WebDriver driver;

    public OpSummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//table[@id='inputSummaryTableSplit']/tbody/tr/td[1]")
    WebElement Process;

    @FindBy(xpath = "//*[@id='inputSummaryTableSplit']/tbody/tr/td[2]")
    WebElement Job;

    @FindBy(xpath = "//*[@id='inputSummaryTableSplit']/tbody/tr/td[3]")
    WebElement Data;

    @FindBy(name = "submitButton")
    WebElement SubmitButton;

    @Step("Clicked Sumbit button on summary screen")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }

    public boolean isFilterGroupDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            String aa = driver.findElement(By.xpath(".//*[contains(text(),'FILTERTBL')]/table")).getText();
            System.out.println(aa);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }
    @Step("Process Name in Summary screen")
    public String processNameInSummary()
    {
        String procName = driver.findElement(By.xpath("//label[contains(text(),'Process Name')]//following::span[1]")).getText();
        return procName;
    }


    @Step("Process field in Summary screen")
    public String processInSumry()
    {
        String proc = Process.getText().replaceAll("\\s+", "").trim();
        return proc;
    }

    @Step("Job field in Summary screen")
    public String jobInSumry()
    {
        String job = Job.getText().replaceAll("\\s+", "").trim();
        return job;
    }

    @Step("data field in Summary screen")
    public String dataInSumry()
    {
        String job = Data.getText().replaceAll("\\s+", "").trim();
        return job;
    }

    public String layoutName()
    {
        return driver.findElement(By.xpath(".//*[@id='outputProcessForm']/table[4]/tbody/tr[1]/td[2]")).getText();
    }

    public List<String> selectedRecordTypeAndFileName()
    {
        List<String> recordlist=new ArrayList<String>();
        List<WebElement> elements=driver.findElements(By.xpath("//div[contains(text(),'Output 1')]//following::th[contains(text(),'Record Types Included')]//following::tbody/tr/td"));
        for(WebElement ele:elements)
        {
            recordlist.add(ele.getText());
        }
        return recordlist;
    }

    public String selectedfileName()
    {
        return driver.findElement(By.xpath(".//th[contains(text(),'File Name:')]/following::tbody/tr/td[2]")).getText();
    }

    public String selectedSortOptionMatch()
    {
        return driver.findElement(By.xpath(".//*[@id='outputGroup']/div[2]/span[3]")).getText();
    }

    public String dataCheckPerformed()
    {
        return driver.findElement(By.xpath(".//*[@id='outputProcessForm']/label[4]")).getText();
    }

    public String tableUsedForOutput()
    {
        return driver.findElement(By.xpath("//*[starts-with(text(),'Output Table Name')]//following::tbody//td[2]")).getText().replaceAll("\\s+","");
    }

    public String aliasUsedForOutputTable()
    {
        return driver.findElement(By.xpath(".//*[@id='newLayoutTable']/tbody/tr/td[2]")).getText();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.id("erMsg")).getText();
    }

    public String getFieldOfSort()
    {
        return driver.findElement(By.xpath("//*[contains(text(),'Sort Options')]/following::tbody/tr/td[1]")).getText();
    }

    public String getOrderOfSort()
    {
        return driver.findElement(By.xpath("//*[contains(text(),'Sort Options')]//following::table[1]/tbody/tr/td[2]")).getText();
    }

    public String getFileIdentifierDC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[1]")).getText();
    }

    public String getMaxBlankFieldDC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[3]")).getText();
    }

    public String getMaxSingleFieldDC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[5]")).getText();
    }

    public String getMaxUnknownFieldDC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[7]")).getText();
    }

    public String getRunTimeADC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[9]")).getText();
    }

    public String getRunTimeBDC()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'File Identifier')]/following::td[11]")).getText();
    }

    public String getFileFormat()
    {
        return driver.findElement(By.xpath(".//*[@id='outputProcessForm']/table[4]/tbody/tr[4]/td[2]")).getText();
    }

    public String getFilePurpose()
    {
        return driver.findElement(By.xpath(".//*[@id='outputProcessForm']/table[4]/tbody/tr[3]/td[2]")).getText();
    }

    public String getSummarySplitDetail()
    {
        return driver.findElement(By.xpath("//*[contains(text(),'File Splitting: ')]")).getText();
    }

    public String getSummaryMoveStatementFieldName()
    {
        return driver.findElement(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr[1]/td[2]")).getText();
    }

    public String getSummaryMoveStatementData()
    {
        return driver.findElement(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr[1]/td[3]")).getText();
    }

    public String getSummaryMoveStatementRecordTypes()
    {
        return driver.findElement(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr[1]/td[1]")).getText();
    }

    // label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr[1]/td[1]
    public List<List<String>> getMoveStatementRows()
    {
        int i;
        List<List<String>> finalList = new ArrayList<List<String>>();
        List<String> tdList = new ArrayList<>();
        List<String> tdList2 = new ArrayList<>();
        List<WebElement> table = driver.findElements(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr"));
        for (i = 1; i <= table.size(); i++)
        {

            if (i == 1)
            {
                List<WebElement> td1 = table.get(i).findElements(By.tagName("td"));
                for (WebElement ele : td1)
                {
                    String text = ele.getText();
                    tdList.add(text);
                }
            } else
            {
                List<WebElement> td1 = table.get(i).findElements(By.tagName("td"));
                for (WebElement ele : td1)
                {
                    String text = ele.getText();
                    tdList2.add(text);
                }
            }
        }
        finalList.add(tdList);
        finalList.add(tdList2);
        return finalList;
    }
    public List<String> getTheFieldNamesForOutputMoveStatement()
    {
        List<String> fieldNameList=new ArrayList<String>();
        List<WebElement> elements=driver.findElements(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr/td[1]"));
        for(WebElement ele:elements)
        {
            fieldNameList.add(ele.getText());
        }
        return fieldNameList;
    }
    public List<String> getTheRecordTypesForOutputMoveStatement()
    {
        List<String> recordTypeList=new ArrayList<String>();
        List<WebElement> elements=driver.findElements(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr/td[4]"));
        for(WebElement ele:elements)
        {
            recordTypeList.add(ele.getText());
        }
        return recordTypeList;
    }
    public List<String> getTheDataToOutputForOutputMoveStatement()
    {
        List<String> dataToOutputList=new ArrayList<String>();
        List<WebElement> elements=driver.findElements(By.xpath("//label[contains(text(),'Move Statements')]/following:: table[1]/tbody/tr/td[2]"));
        for(WebElement ele:elements)
        {
            dataToOutputList.add(ele.getText());
        }
        return dataToOutputList;
    }


    public String getSelectedDataTableFromSummary()
    {

        return driver
                .findElement(By.xpath("//table[@id='inputSummaryTableSplit']/thead/tr/th[contains(text(),'Process')]/following::tbody/tr/td[3]"))
                .getText();

    }

    public String getSelectedMoveFieldCompleteName()
    {
        String dymanicField = "//label[contains(text(),'Sort Options')]/following::table/tbody/tr/td";
        String fieldName = driver.findElement(By.xpath(dymanicField)).getText();
        // String value[] = fieldName.split(" ");
        // String splitVal[] = value[1].split("\\.");
        // String str = splitVal[1] + "_" + splitVal[2];
        return fieldName;
    }
    public Integer getTheCountRowsFormedForSortOptions() throws InterruptedException
    {
        Thread.sleep(3000);
        List<WebElement> elements= driver.findElements(By.xpath("//*[contains(text(),'Sort Options')]/following::tbody[1]/tr"));
        return elements.size();
    }
    public Integer getTheCountColumnsFormedForSortOptions()
    {
        List<WebElement> elements=  driver.findElements(By.xpath("//*[contains(text(),'Sort Options')]/following::tbody[1]/tr/td"));
        return elements.size();
    }

    public String getFirstFieldSelectedForSort()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Sort Options')]/following::tbody[1]/tr/td[1])[1]")).getText();
    }

    public String getSecondFieldSelectedSort()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Sort Options')]/following::tbody[1]/tr/td[1])[2]")).getText();
    }

    public String getFirstColumnHeaderSortTable()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Sort Options')]/following::thead[1]/tr/th)[1]")).getText();
    }

    public String getSecondColumnHeaderSortTable()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Sort Options')]/following::thead[1]/tr/th)[2]")).getText();
    }

    /* public boolean isRecordNotSortDisplayed()
    {
        try
        {
            System.out.println(driver.findElement(By.xpath(".//*[contains(text(),'Records will not be sorted.')]")).getText());
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }
     */
    public boolean isRecordNotSortDisplayed()
    {

        String text=   driver.findElement(By.xpath("//label[contains(text(),'Sort Options:')]//following::span[1]")).getText();
        if(text.equalsIgnoreCase("Records will not be sorted.")){return true;}
        else{return false;}


    }
    
   public String getTheTagName()
   {
	   return driver.findElement(By.xpath("//*[@value='View / Validate']")).getTagName();
	   
   }
   
   public boolean isFieldPresent(String fields)
   {
	   boolean found=false;
	  String[] fieldArr= fields.split(",");
	  List<String> fieldList=Arrays.asList(fieldArr);
			  
	   String winHandleBefore = driver.getWindowHandle();
	   driver.findElement(By.xpath("//*[@value='View / Validate']")).click();
	
	for(String winHandle : driver.getWindowHandles()){
	    driver.switchTo().window(winHandle);
	  List<WebElement> elements= driver.findElements(By.xpath("//table/tbody/tr/td[2]"));
	  for(WebElement ele:elements)
	  {
		 if(fieldList.contains(ele.getText()))
				 {
			 found=true;
				 }
	  }
	  
	}
	driver.close();
	driver.switchTo().window(winHandleBefore);
	return found;
   }
	

   
public void clickOnButtonValidateTheLayout()
{
driver.findElement(By.xpath("//*[@value='View / Validate']")).click();
}

public String fetchTheWarningMessage()
{ 
	String warnMessage=null;

	// It will return the parent window name as a String
	String parent=driver.getWindowHandle();
	driver.findElement(By.xpath("//*[@value='View / Validate']")).click();
	// This will return the number of windows opened by Webdriver and will return Set of St//rings
	Set<String>s1=driver.getWindowHandles();
	// Now we will iterate using Iterator
	Iterator<String> I1= s1.iterator();
	 
	while(I1.hasNext())
	{
	 
	   String child_window=I1.next();
	 
	// Here we will compare if parent window is not equal to child window then we            will close
	 
	if(!parent.equals(child_window))
	{
	driver.switchTo().window(child_window);
	 warnMessage=driver.findElement(By.xpath("//div[@class='warnMsg']//span")).getText();
	System.out.println(driver.switchTo().window(child_window).getTitle());
	
	driver.close();
	}
	//driver.close();
	
}
	driver.switchTo().window(parent);
	return warnMessage;
}
}
  /*public String getSecondRecordGroupName()
    {
        return driver.findElement(By.xpath("//div[starts-with(text(),'Output 2')]/following::tbody/tr/td[1]")).getText();
    }*/


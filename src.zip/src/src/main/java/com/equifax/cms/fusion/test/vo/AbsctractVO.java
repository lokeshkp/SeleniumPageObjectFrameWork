package com.equifax.cms.fusion.test.vo;

public class AbsctractVO {

	protected String processName;


	protected String outputTable;
	protected String operation;
	protected String expectedStatus;
	private String testScenario;

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getOutputTable() {
		return outputTable;
	}

	public void setOutputTable(String outputTable) {
		this.outputTable = outputTable;
	}

	public String getOperation() {
		return operation;
	}

	public void setOperation(String operation) {
		this.operation = operation;
	}

	public String getExpectedStatus() {
		return expectedStatus;
	}

	public void setExpectedStatus(String expectedStatus) {
		this.expectedStatus = expectedStatus;
	}

	public String getTestScenario() {
		return testScenario;
	}

	public void setTestScenario(String testScenario) {
		this.testScenario = testScenario;
	}

	@Override
	public String toString() {

		StringBuilder builder = new StringBuilder()
				.append(" Process Name : ")
				.append(processName)				
				.append("\n Output Table Name : ")
				.append(outputTable)
				.append("\n");

		return builder.toString();
	}
}

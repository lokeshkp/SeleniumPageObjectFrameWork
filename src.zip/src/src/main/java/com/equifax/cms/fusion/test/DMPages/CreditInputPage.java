package com.equifax.cms.fusion.test.DMPages;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class CreditInputPage
{

    WebDriver driver;

    public CreditInputPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(id = "pullCreditByCID")
    public WebElement pullByCID;

    @FindBy(id = "pullCreditByCNX")
    public WebElement pullByCNX;

    @FindBy(id = "20160524_1PCT")
    WebElement Ele_LatestDataSet;

    @FindBy(id = "golden_current")
    public WebElement RecentGldenDatast_rbtn;

    @FindBy(id = "weekly_current")
    public WebElement RecentWklyDatast_rbtn;

    @FindBy(id = "add")
    WebElement AddButton;

    @FindBy(id = "remove")
    WebElement Remove_Btn;

    @FindBy(xpath = ".//input[@type='submit']")
    WebElement ContinueButton;

    @FindBy(id = "uniqueCidIndex")
    public WebElement CB_Unique_CID;

    @FindBy(id = "current")
    public WebElement Rad_Use_recent_dataset;

    @FindBy(id = "notcurrent")
    WebElement Rad_specific_dataset;

    @FindBy(id = "archive")
    public WebElement CB_Hundred_perc;

    @FindBy(id = "segmentCMS")
    public WebElement cb_segmentCMS;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;

    @FindBy(id = "dimensions")
    public WebElement dimensionsChkBox;

    @Step("Get Error Message on Credit Input Screen")
    public String getErrorMessage()
    {
        return ErrorMessage.getText();
    }

    @Step("Selected the available DataSet(s) = \"{0}\"")
    public void selectAvailablDataset(String dataSet)
    {
        if ("RECENT_GOLDEN".equalsIgnoreCase(dataSet))
        {
            RecentGldenDatast_rbtn.click();
        } else if ("RECENT_WEEKLY".equalsIgnoreCase(dataSet))
        {
            RecentWklyDatast_rbtn.click();
        } else if ("CURRENT".equalsIgnoreCase(dataSet))
        {
            Rad_Use_recent_dataset.click();
        }
    }

    @Step("Selected the Specific Dataset radio button")
    public void selectSpcificDataSet()
    {
        Rad_specific_dataset.click();
    }

    @Step("Select 100% Data Set Check Box")
    public void sel_Hundred_perc_CB()
    {
        CB_Hundred_perc.click();
    }

    @Step("Select Use Recent Dataset ")
    public void sel_Use_recent_Dataset_Rad()
    {
        Rad_Use_recent_dataset.click();
    }

    @Step("Click Unique CID Index Check Box")
    public void click_Unique_CID()
    {
        CB_Unique_CID.click();
    }

    @Step("Select Latest Dataset Radio Button")
    public void clickLatestDataSet()
    {
        Ele_LatestDataSet.click();
    }

    @Step("Selected the Dimensions Check Box")
    public void selectDimensionsCB()
    {
        dimensionsChkBox.click();
    }

    @Step("Click Add Button")
    public void clickAddButton()
    {
        AddButton.click();
    }

    @Step("Clicked on Remve Button")
    public void clickRemoveBtn()
    {
        Remove_Btn.click();
    }

    @Step("Click Continue Button on Credit Input Screen")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public void selectPullType_CB(String pull)
    {
        if (pull.equalsIgnoreCase("CID"))
        {
            pullByCID.click();
        } else if (pull.equalsIgnoreCase("Connexus"))
        {
            pullByCNX.click();
        }
    }

    @Step("Select the Data Set Type = \"{0}\"")
    public void selectDataSetType(String dataSetType)
    {
        if ("100".equalsIgnoreCase(dataSetType))
        {
            driver.findElement(By.xpath("//label[contains(text(),'" + dataSetType + "')]//preceding::input[2]")).click();
            driver.findElement(By.xpath("//label[contains(text(), 'Dimensions')]//parent::div")).getAttribute("id");
        } else if ("1".equalsIgnoreCase(dataSetType))
        {
            driver.findElement(By.xpath("(//label[contains(text(),'" + dataSetType + "')]//preceding::input[2])[2]")).click();
        }
    }

    @Step("Find parent id for the Dimensions Check Box")
    public String getParentIdTextForDimensionsCB()
    {
        return driver.findElement(By.xpath("//label[contains(text(), 'Dimensions')]//parent::div")).getAttribute("id");

    }

    @Step("Find li id for the available datasets")
    public List<String> getLiIdForDimensionsCB()
    {
        List<String> idList = new ArrayList<>();

        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='showhidediv']/div[2]/div[1]/div[2]/div[1]/div[2]/descendant::li"));

        for (int i = 0; i < elements.size(); i++)
        {
            WebElement temp = elements.get(i);
            if (temp.getAttribute("style").contains("list-item"))
            {
                idList.add(temp.getAttribute("id"));
            }
        }

        return idList;
    }

    @Step("Get dimensions datasets in the available datasets")
    public List<WebElement> getDimensionsDatasetsFromAvailableDatasets()
    {
        List<WebElement> dimList = new ArrayList<>();

        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='showhidediv']/div[2]/div[1]/div[2]/div[1]/div[2]/descendant::li"));

        for (int i = 0; i < elements.size(); i++)
        {
            WebElement temp = elements.get(i);
            if (temp.getAttribute("id").contains("dimensions"))
            {
                dimList.add(temp);
            }
        }

        return dimList;
    }

    @Step("Get id for datasets in the available datasets")
    public List<String> getDatasetIdsFromAvailableDatasets()
    {
        List<String> list = new ArrayList<>();

        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='showhidediv']/div[2]/div[1]/div[2]/div[1]/div[2]/descendant::li/a"));

        for (int i = 0; i < elements.size(); i++)
        {
            WebElement temp = elements.get(i);
            list.add(temp.getAttribute("id"));
        }

        return list;
    }

    @Step("Get all available datasets")
    public List<WebElement> getAvailableDatasets()
    {
        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='showhidediv']/div[2]/div[1]/div[2]/div[1]/div[2]/descendant::li"));
        return elements;
    }

    @Step("Compare dimension datasets with available dataset")
    public List<WebElement> getDimensionDatasets(String availableDS) throws ParseException
    {
        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='" + availableDS + "']/parent::li/ul/li/a"));
        return elements;
    }

    public void selectSpecificDataSet(String dataSet)
    {

        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='tableavailableDataSetGrid']/tbody/tr"));
        int i = 0;
        while (i < elements.size())
        {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String str = (String) js.executeScript("var a= $('#availableDataSetGrid').jqxTreeGrid('getRow','" + i
                    + "'); return a.dataSetWithProperties;");

            System.out.println(str);
            if (str.equals(dataSet))
            {
                js.executeScript("$('#availableDataSetGrid').jqxTreeGrid('ensureRowVisible', " + i + ")");
                js.executeScript("$('#availableDataSetGrid').jqxTreeGrid('selectRow'," + i + ")");
                driver.findElement(By.xpath("//div[@id='addDataSetButton']")).click();
                break;
            }

            i++;
        }

    }

}

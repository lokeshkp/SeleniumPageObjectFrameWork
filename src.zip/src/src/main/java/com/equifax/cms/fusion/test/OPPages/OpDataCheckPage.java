package com.equifax.cms.fusion.test.OPPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class OpDataCheckPage
{

    WebDriver driver;
    public Select sel;

    public OpDataCheckPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "isDataCheck")
    public WebElement Ele_DataCheckCheckBox;

    @FindBy(id = "fileIdentifier")
    public WebElement FileIdentifierFld_Ddwn;

    @FindBy(id = "maxNoOfBlankFields")
    public WebElement MaxNoBlankFlds;

    @FindBy(id = "maxNoOfSingleFields")
    WebElement MaxNoSingleFlds;

    @FindBy(id = "maxNoOfUnknownFields")
    WebElement MaxNoUnKnownFlds;

    @FindBy(id = "runtimeB")
    WebElement RunTimeBFld_Ddwn;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement SaveBtn;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = "(//input[@name='submitButton'])[2]")
    WebElement OPContinue_btn;

    @Step("Click DataCheck check box")
    public void selectDataCheckCheckbox(String fileFormat, String purpose, String dataCheck, String fileIden, String maxNoBlank, String maxNoSingle,
            String maxNoUnknown, String runTimeB)
    {
        if (!"Apply Capping".equalsIgnoreCase(purpose))
        {
            if (!"ASCII_Delimited".equalsIgnoreCase(fileFormat))
            {
                if ("N".equalsIgnoreCase(dataCheck))
                {
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("arguments[0].click();", Ele_DataCheckCheckBox);
                    // Ele_DataCheckCheckBox.click();
                    System.out.println("No Data Check");
                } else if ("Y".equalsIgnoreCase(dataCheck))
                {
                    selectFileIdentifier(fileIden);
                    maxNoBlankFlds(maxNoBlank);
                    maxNoSingleFlds(maxNoSingle);
                    maxNoUnknwonFlds(maxNoUnknown);
                    selectRunTimeB(runTimeB);
                }
            }
        }
    }

    public String isDataCheckReq()
    {
        String isDataCheckReq = "Y";
        if (Ele_DataCheckCheckBox.getAttribute("value").equals(""))
        {
            isDataCheckReq = "N";
        }
        return isDataCheckReq;
    }

    // Added to check whether datacheck required or not and if required perform necessary actions
    @Step("Click DataCheck check box")
    public void performDataCheck(String fileFormat, String purpose, String dataCheck, String fileIden, String maxNoBlank, String maxNoSingle,
            String maxNoUnknown, String runTimeB)
    {
        if (!"Apply Capping".equalsIgnoreCase(purpose))
        {

            if ("N".equalsIgnoreCase(dataCheck))
            {
                Ele_DataCheckCheckBox.click();
                System.out.println("No Data Check");
            } else if ("Y".equalsIgnoreCase(dataCheck))
            {
                selectFileIdentifier(fileIden);
                maxNoBlankFlds(maxNoBlank);
                maxNoSingleFlds(maxNoSingle);
                maxNoUnknwonFlds(maxNoUnknown);
                selectRunTimeB(runTimeB);
            }
        }
    }

    @Step("Select the File Identifier = \"{0}\"")
    public void selectFileIdentifier(String fileIden)
    {
        sel = new Select(FileIdentifierFld_Ddwn);
        sel.selectByVisibleText(fileIden);
    }

    @Step("Provide Max Number of Blank Fields = \"{0}\"")
    public void maxNoBlankFlds(String maxNoBlank)
    {
        if (!"NA".equalsIgnoreCase(maxNoBlank))
        {
            MaxNoBlankFlds.sendKeys(maxNoBlank);
        }
    }

    @Step("Provide Max Number of Single Field values = \"{0}\"")
    public void maxNoSingleFlds(String maxNoSingle)
    {
        if (!"NA".equalsIgnoreCase(maxNoSingle))
        {
            MaxNoSingleFlds.sendKeys(maxNoSingle);
        }
    }

    @Step("Provide Max Number of Unknown Field values = \"{0}\"")
    public void maxNoUnknwonFlds(String maxNoUnknown)
    {
        if (!"NA".equalsIgnoreCase(maxNoUnknown))
        {
            MaxNoUnKnownFlds.sendKeys(maxNoUnknown);
        }
    }

    @Step("Select the Run Time B Field value = \"{0}\"")
    public void selectRunTimeB(String runTimeB)
    {
        sel = new Select(RunTimeBFld_Ddwn);
        sel.selectByVisibleText(runTimeB);
    }

    @Step("Clicked the Save button")
    public void clickSaveBtn()
    {
        SaveBtn.click();
    }

    @Step("Click Continue button on Data Check Page")
    public void clickContinueButton()
    {

        ContinueButton.click();
    }

    @Step("Click Continue button on Data Check Page")
    public void clickContinueBtnOP()
    {
        OPContinue_btn.click();
    }

    public String fetchTheMaxBlankField()
    {
        return MaxNoBlankFlds.getAttribute("value");
    }
}

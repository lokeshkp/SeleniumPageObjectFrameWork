package com.equifax.cms.fusion.test.RLSPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class RollingSuppSetupPage
{
    WebDriver driver;
    public Select selType;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    Date date;

    public RollingSuppSetupPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
    }

    @FindBy(id = "dateToApply")
    public WebElement dateSelected;

    @FindBy(id = "allRecordsAccRej")
    public WebElement Ele_AllRecRegardlessOfType;

    @FindBy(id = "name")
    WebElement ProcessName_Fld;

    @FindBy(id = "suppressionType1")
    WebElement UpdateExistSupTbl_Rbtn;

    @FindBy(id = "inputRollingSupression")
    WebElement SelectExistSupTbl_Ddwn;

    @FindBy(id = "suppressionType2")
    WebElement CreateSupTbl_Rbtn;

    @FindBy(id = "listVirtualArtifacts0.userProvidedName")
    public WebElement SupTblName_Fld;

    @FindBy(id = "previousProject")
    WebElement PrevProj_Fld;

    @FindBy(id = "searchButton")
    WebElement Search_Btn;

    @FindBy(id = "fromProcessId")
    WebElement Process_Ddwn;

    @FindBy(id = "itemTableId")
    WebElement Data_Ddwn;

    @FindBy(id = "dateType1")
    WebElement CurrentDate_Rbtn;

    @FindBy(id = "dateType2")
    WebElement CustomDate_Rbtn;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement Save_Btn;

    @FindBy(xpath = "(//input[@name='submitButton'])[2]")
    WebElement Submit_Btn;

    public String getProcessthosehasCIDarelisted_STYLE()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Process those has CID are listed')]")).getAttribute("style");
    }

    public String getTextErrorMessage()
    {
        return driver.findElement(By.id("txtMsg")).getText();
    }

    public String getNoOfSuppDaysDispl()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Date to apply')]/following::td[6]/label")).getText();
    }

    public String getJobNoDisplayed()
    {
        return driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText();
    }

    @Step("Click on Audit Tab = \"{0}\"")
    public void inputProcessName(String procName)
    {
        if (!"NA".equalsIgnoreCase(procName))
        {
            ProcessName_Fld.sendKeys(procName);
        }
    }

    @Step("Selected Update existing Suppression Table Radio Button")
    public void clickUpdateExistSupTbl()
    {
        UpdateExistSupTbl_Rbtn.click();
    }

    @Step("Selected Existing Suppression Table = \"{0}\"")
    public void selectExistSupTbl(String existSupTbl)
    {
        selType = new Select(SelectExistSupTbl_Ddwn);
        selType.selectByVisibleText(existSupTbl);
    }

    @Step("Selected Create New Suppression Table Radio Button")
    public void clickCreateNewtSupTbl()
    {
        CreateSupTbl_Rbtn.click();
    }

    @Step("Provided Suppression Table Name = \"{0}\"")
    public void inputSupTblName(String SupTblName)
    {
        SupTblName_Fld.clear();
        SupTblName_Fld.sendKeys("RLS" + SupTblName);
    }

    @Step("Provided Suppression Table Name = \"{0}\"")
    public void inputSupTblName1(String SupTblName)
    {
        SupTblName_Fld.clear();
        SupTblName_Fld.sendKeys(SupTblName);
    }

    @Step("Provided Previous Project Number = \"{0}\"")
    public void inputPrevProjNumClickSearch(String projNum)
    {
        if (!"NA".equalsIgnoreCase(projNum))
        {
            PrevProj_Fld.clear();
            PrevProj_Fld.sendKeys(projNum);
            clickSearchBtn();
        }
    }

    @Step("Clicked Search button")
    public void clickSearchBtn()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        // WebElement element = driver.findElement(By.xpath("//div[@class='refineParam']/div[@class='buttons']/input[2]"));
        js.executeScript("arguments[0].click();", Search_Btn);
        // Search_Btn.click();
    }

    @Step("Selected Process = \"{0}\"")
    public void selectProcess(String process)
    {
        if (!"NA".equalsIgnoreCase(process))
        {
            selType = new Select(Process_Ddwn);
            selType.selectByVisibleText(process);
        }
    }

    @Step("Selected Data = \"{0}\"")
    public void selectData(String data)
    {
        if (!"NA".equalsIgnoreCase(data))
        {
            selType = new Select(Data_Ddwn);
            selType.selectByVisibleText(data);
        }
    }

    @Step("Click Save button")
    public void clickOnSave()
    {
        Save_Btn.click();
    }

    @Step("Click Submit button")
    public void clickOnSubmit()
    {
        Submit_Btn.click();
    }

    public boolean isAllRecordsDisabled()
    {
        return Ele_AllRecRegardlessOfType.isSelected();
    }

    @Step("Select Date to Apply = \"{0}\"")
    public void selectDateToApply(String dateType, String date)
    {
        if ("CurrentDate".equalsIgnoreCase(dateType))
        {
            CurrentDate_Rbtn.click();
        } else if ("CustomDate".equalsIgnoreCase(dateType))
        {
            CustomDate_Rbtn.click();

            String day = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
            System.out.println("day : " + day);
            int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
            if (day.startsWith("0"))
            {
                driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();
            } else
            {
                driver.findElement(By.xpath("(//a[contains(text(), '" + day + "')])[1]")).click();
            }
        }
    }

    @Attachment(value = "Page screenshot", type = "image/png")
    public byte[] captureScreenshot(WebDriver d)
    {
        return ((TakesScreenshot) d).getScreenshotAs(OutputType.BYTES);
    }

    @Step("Fetched the Rolling Suppression Table Count from Stats")
    public Long getRollingSupTableCount()
    {
        String rsTableCount = driver.findElement(By.xpath("//div[@id='css3table']/div[6]/div[2]")).getText();
        return Long.parseLong(rsTableCount);
    }

    public void selectRLSOptionTable(String suppOption, String suppTable)
    {
        if ("UpdateExisting".equalsIgnoreCase(suppOption))
        {
            clickUpdateExistSupTbl();
            selectExistSupTbl(suppTable);
        } else if ("CreateNew".equalsIgnoreCase(suppOption))
        {
            clickCreateNewtSupTbl();
            date = new Date();
            inputSupTblName(dateFormat.format(date));

        }

    }

    @Step("Get the Suppression Table list")
    public List<String> getSuppTableList()
    {
        List<WebElement> allSuggestions = driver.findElements(By.xpath("//label[contains(text(),'Select Existing')]/following::select[1]/option"));
        List<String> suppTablelist = new ArrayList<>();
        for (WebElement suggestion : allSuggestions)
        {
            String option = suggestion.getText();
            suppTablelist.add(option);

        }
        return suppTablelist;
    }

    @Step("Get the Input Table list")
    public List<String> getInputTableList()
    {
        List<WebElement> allSuggestions = driver.findElements(By.xpath("//select[@id='itemTableId']/option"));
        List<String> suppTablelist = new ArrayList<>();
        for (WebElement suggestion : allSuggestions)
        {
            String option = suggestion.getAttribute("value");
            suppTablelist.add(option);

        }
        return suppTablelist;
    }

    @Step("Uncheck PS from Rejects")
    public void uncheckPSFromRejects()
    {
        driver.findElement(By.xpath("//td[contains(text(),'PS')]/preceding::td[1]/input")).click();
    }

    public String getInputRecordCountFromUsedProcess()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Number of Records shipped')]/following::div[1]")).getText();
    }

    public String getInputRecordCountFromStats()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Total Input Records')]/following::div[1]")).getText();
    }

    public boolean isShippedFiledisplayed(String shpFile)
    {
        WebElement ele = driver.findElement(By.xpath("//div[@id='fileList']//label[contains(text(),'" + shpFile + "')]"));
        return ele.isDisplayed();
    }

    public String getTableName()
    {
        return SupTblName_Fld.getAttribute("value");
    }

    public boolean isGroupsDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            int i = driver.findElements(By.xpath(".//*[@class='inneritem']/div/input")).size();
            System.out.println(i);
            driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isCheckBoxDisplayedShipping()
    {
        boolean flag = false;
        try
        {
            int i = driver.findElements(By.xpath(".//*[@name='shippedFiles']")).size();
            for (int j = 0; j < i; j++)
            {
                String type = driver.findElement(By.xpath(".//*[@id='file" + j + "']")).getAttribute("type");
                if ("checkbox".equalsIgnoreCase(type))
                {
                    flag = true;
                } else
                {
                    flag = false;
                }
            }
        } catch (Exception e)
        {
            return false;
        }
        return flag;
    }

    @Step("Get rolled records count")
    public String getRolledRecordCount()
    {
        String count = driver.findElement(By.xpath("//div[contains(text(),'Total records added')]/following::div[1]")).getText();
        return count;
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching Greenplum table count match with  = \"{0}\"")
    public long getGpTbleCountForRollingStatus(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where rolling_status  ='A' ";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    public String getJobNumberFromSummary()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td[2]")).getText();
    }

}

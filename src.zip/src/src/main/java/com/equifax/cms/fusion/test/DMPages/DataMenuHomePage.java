package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

public class DataMenuHomePage
{

    WebDriver driver;

    public DataMenuHomePage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    /*
     * @FindBy(linkText = "Data Menu") WebElement DataMenuButton;
     */

    @FindBy(xpath = "(//a[@class='bg-img'])[1]")
    WebElement DataMenuButton;

    @FindBy(xpath = ".//*[@id='contentArea']/div[4]/ul/li/ul[2]/li/div[2]/a")
    WebElement DMexpressButton;

    @Step("Click Data Menu Home Button")
    public void clickDataMenuButton()
    {
        DataMenuButton.click();
    }

    @Step("Click Data Menu Express Button")
    public void clickDMexpressButton()
    {
        DMexpressButton.click();
    }

    @Step("Verified the status of the Process ")
    public String GetStatusDM(String procId)
    {
        String status = driver.findElement(By.xpath("//div[contains(text(),'" + procId + "')]//following::div[1]/div")).getText();
        return status;
    }

}

package com.equifax.cms.fusion.test.DMPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class PreSelectsPage {

	WebDriver driver;
	public PreSelectsPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "textMsg")
	public WebElement textMessage;
	
	@FindBy(id = "chkBoxHaspanicNamesOnly")
	public WebElement Hispanic_Names_CB;
	
	@FindBy(id = "chkBoxMale")
	public WebElement Male_CB;
	
	@FindBy(id = "chkBoxFemale")
	public WebElement Female_CB;
	
	@FindBy(id = "chkBoxUnknownGender")
	public WebElement Neutral_CB;
	
	@FindBy(name="listPreSelectAgeDetails[0].lowAge")
	public WebElement Age_Range_1_LowAge;
	
	@FindBy(name="listPreSelectAgeDetails[0].highAge")
	public WebElement Age_Range_1_HighAge;
	
	@FindBy(name="listPreSelectAgeDetails[1].lowAge")
	public WebElement Age_Range_2_LowAge;
	
	@FindBy(name="listPreSelectAgeDetails[1].highAge")
	public WebElement Age_Range_2_HighAge;
	
	@FindBy(name="listPreSelectAgeDetails[2].lowAge")
	public WebElement Age_Range_3_LowAge;
	
	@FindBy(name="listPreSelectAgeDetails[2].highAge")
	public WebElement Age_Range_3_HighAge;
	
	@FindBy(name="listPreSelectAgeDetails[3].lowAge")
	public WebElement Age_Range_4_LowAge;
	
	@FindBy(name="listPreSelectAgeDetails[3].highAge")
	public WebElement Age_Range_4_HighAge;
	
	@FindBy(name="listPreSelectAgeDetails[4].lowAge")
	public WebElement Age_Range_5_LowAge;
	
	@FindBy(name="listPreSelectAgeDetails[4].highAge")
	public WebElement Age_Range_5_HighAge;
	
	@FindBy(xpath = ".//*[@id='input-preselect-form']/div[2]/input")
	WebElement Continue_Btn;
	
	@FindBy(xpath = ".//*[@id='input-preselect-form']/div[2]/a")
	WebElement Back_Btn;
	
	@Step("Check Hispanic Check box")
	public void checkHispanicCB() {
		if(!Hispanic_Names_CB.isSelected()) {
			Hispanic_Names_CB.click();
		}
	}
	
	@Step("Unheck Hispanic Check box")
	public void uncheckHispanicCB() {
		if(Hispanic_Names_CB.isSelected()) {
			Hispanic_Names_CB.click();
		}
	}
	
	@Step("Check Male Check box")
	public void checkMaleCB() {
		if(!Male_CB.isSelected()) {
			Male_CB.click();
		}
	}
	
	@Step("Unheck Male Check box")
	public void uncheckMaleCB() {
		if(Male_CB.isSelected()) {
			Male_CB.click();
		}
	}
	
	@Step("Check Female Check box")
	public void checkFemaleCB() {
		if(!Female_CB.isSelected()) {
			Female_CB.click();
		}
	}
	
	@Step("Unheck Female Check box")
	public void uncheckFemaleCB() {
		if(Female_CB.isSelected()) {
			Female_CB.click();
		}
	}
	
	@Step("Check Neutral Check box")
	public void checkNeutralCB() {
		if(!Neutral_CB.isSelected()) {
			Neutral_CB.click();
		}
	}
	
	@Step("Unheck Neutral Check box")
	public void uncheckNeutralCB() {
		if(Neutral_CB.isSelected()) {
			Neutral_CB.click();
		}
	}
	
	@Step("Provided Low and High Age for Range 1")
	public void inputAgeRange1(String low,String high) {
		Age_Range_1_LowAge.clear();
		Age_Range_1_HighAge.clear();
		Age_Range_1_LowAge.sendKeys(low);
		Age_Range_1_HighAge.sendKeys(high);
	}
	
	@Step("Provided Low and High Age for Range 2")
	public void inputAgeRange2(String low,String high) {
		Age_Range_2_LowAge.clear();
		Age_Range_2_HighAge.clear();
		Age_Range_2_LowAge.sendKeys(low);
		Age_Range_2_HighAge.sendKeys(high);
	}
	
	@Step("Provided Low and High Age for Range 3")
	public void inputAgeRange3(String low,String high) {
		Age_Range_3_LowAge.clear();
		Age_Range_3_HighAge.clear();
		Age_Range_3_LowAge.sendKeys(low);
		Age_Range_3_HighAge.sendKeys(high);
	}
	
	@Step("Provided Low and High Age for Range 4")
	public void inputAgeRange4(String low,String high) {
		Age_Range_4_LowAge.clear();
		Age_Range_4_HighAge.clear();
		Age_Range_4_LowAge.sendKeys(low);
		Age_Range_4_HighAge.sendKeys(high);
	}
	
	@Step("Provided Low and High Age for Range 5")
	public void inputAgeRange5(String low,String high) {
		Age_Range_5_LowAge.clear();
		Age_Range_5_HighAge.clear();
		Age_Range_5_LowAge.sendKeys(low);
		Age_Range_5_HighAge.sendKeys(high);
	}
	
	@Step("Clicked Continue Button on Preselect Page")
	public void clickContinue() {
		Continue_Btn.click();
	}
	
	@Step("Clicked Back Button on Preselect Page")
	public void clickBack() {
		Back_Btn.click();
	}
	
	@Step("Selected Gender and Hispanic Only")
	public void selectGenderCB(String gender) {
		if(gender.contains("H")||gender.contains("h")) {
			Hispanic_Names_CB.click();
		}
		if(gender.contains("M")||gender.contains("m")) {
			Male_CB.click();
		}
		if(gender.contains("F")||gender.contains("f")) {
			Female_CB.click();
		}
		if(gender.contains("N")||gender.contains("n")){
			Neutral_CB.click();
		}
	}
	
	@Step("Provided the Age values in Pre-Select screen")
	public void inputAgeRanges(String age) {
		StringTokenizer stMain = new StringTokenizer(age,":");
		int i = 0;
		while(stMain.hasMoreElements()) {
			String range1 = stMain.nextToken();
			String range1Age[] = range1.split(",");
			driver.findElement(By.name("listPreSelectAgeDetails["+i+"].lowAge")).sendKeys(range1Age[0]);
			driver.findElement(By.name("listPreSelectAgeDetails["+i+"].highAge")).sendKeys(range1Age[1]);
			i++;
		}
	}
}

package com.equifax.cms.fusion.test.vo;

public class SMProcessInputVO extends AbsctractVO {

	private String inputProcess;
	protected String data;

	public String getInputProcess() {
		return inputProcess;
	}

	public void setInputProcess(String inputProcess) {
		this.inputProcess = inputProcess;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}
}

package com.equifax.cms.fusion.test.DCpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataComparePage
{

    WebDriver driver;
    public Select selType;

    public DataComparePage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "(//input[@name='submitButton'])[2]")
    WebElement Continue_Btn;

    public void selectLeftField(String table, String field)
    {
        WebElement ele = driver
                .findElement(By.xpath("(.//*[contains(text(),'"+table+"')]/following-sibling::ul/li/a[@title='"+field+"'])[1]"));
        Actions action = new Actions(driver);
        action.doubleClick(ele).perform();
    }

    @Step("Selected the Master Fields = \"{0}\" \"{1}\" \"{2}\"")
    public void selectLeftFields(String leftF1, String leftF2, String leftF3) throws InterruptedException
    {
        if (!("NA".equalsIgnoreCase(leftF1)))
        {
            String[] mas1F = leftF1.split(",");
            selectLeftField(mas1F[0], mas1F[1]);
        }
        if (!("NA".equalsIgnoreCase(leftF2)))
        {
            Thread.sleep(3000);
            String[] mas2F = leftF2.split(",");
            selectLeftField(mas2F[0], mas2F[1]);
        }
        if (!("NA".equalsIgnoreCase(leftF3)))
        {
            Thread.sleep(3000);
            String[] mas3F = leftF3.split(",");
            selectLeftField(mas3F[0], mas3F[1]);
        }
    }

    public void selectRightField(String table, String field)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            WebElement ele = driver.findElement(By.xpath("(.//*[contains(text(),'"+table+"')]/following::li[@title='"+field+"'])[2]"));
            Actions action = new Actions(driver);
            action.doubleClick(ele).perform();
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        } catch (Exception e)
        {
            WebElement ele = driver.findElement(By.xpath("(.//*[contains(text(),'"+table+"')]/following::li[@title='"+field+"'])[1]"));
            Actions action = new Actions(driver);
            action.doubleClick(ele).perform();
        }
    }

    @Step("Selected the Right Fields = \"{0}\" \"{1}\" \"{2}\"")
    public void selectRightFields(String rightF1, String rightF2, String rightF3)
    {
        if (!("NA".equalsIgnoreCase(rightF1)))
        {
            String[] mat1F = rightF1.split(",");
            selectRightField(mat1F[0], mat1F[1]);
            // clickAddMatchButton();
        }
        if (!("NA".equalsIgnoreCase(rightF2)))
        {
            String[] mat2F = rightF2.split(",");
            selectRightField(mat2F[0], mat2F[1]);
            // clickAddMatchButton();
        }
        if (!("NA".equalsIgnoreCase(rightF3)))
        {
            String[] mat3F = rightF3.split(",");
            selectRightField(mat3F[0], mat3F[1]);
            // clickAddMatchButton();
        }
    }

    @Step("Click on Continue button")
    public void clickContinueBtn()
    {
        Continue_Btn.click();
    }

    public void clickSaveButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[2]")).click();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.id("textMsg")).getText();
    }

    public boolean isElementDisplayedForLeft()
    {
        return !driver.findElements(By.xpath(".//*[@class='row1']")).isEmpty();
    }

    public boolean isElementDisplayedForRight()
    {
        return !driver.findElements(By.xpath(".//*[@class='row2']")).isEmpty();
    }

    public boolean isSearchBoxPresentforLeft()
    {
        return !driver.findElements(By.id("searchBox1")).isEmpty();
    }

    public boolean isSearchBoxPresentforRight()
    {
        return !driver.findElements(By.id("searchBox2")).isEmpty();
    }

    public void selectFieldLeft(String field)
    {
        if (!("NA".equalsIgnoreCase(field)))
        {
            String[] mat1F = field.split(",");
            driver.findElement(By.xpath("(.//*[contains(text(),'"+ mat1F[1] +"')])[1]")).click();
        }
    }
    
    public String getLeftTableField() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'HEADER.CID')])[1]")).getText();
    }
    
    public String getRightTableField() {
        return driver.findElement(By.xpath("(.//*[contains(text(),'HEADER.CID')])[2]")).getText();
    }

    public void selectFieldRight(String field)
    {
        if (!("NA".equalsIgnoreCase(field)))
        {
            String[] mat1F = field.split(",");
            driver.findElement(By.xpath("(.//*[contains(text(),'"+ mat1F[1] +"')])[2]")).click();
        }
    }

    public void clickAddLeft()
    {
        driver.findElement(By.id("add")).click();
    }

    public void clickRemoveLeft()
    {
        driver.findElement(By.id("remove")).click();
    }

    public void clickAddRight()
    {
        driver.findElement(By.id("add2")).click();
    }

    public boolean isFieldSelected(String field)
    {
        String[] mat1F = field.split(",");
        int a = driver.findElements(By.xpath(".//*[contains(text(),'"+ mat1F[1] +"')]")).size();
        System.out.println(a);
        if (a == 4)
        {
            return true;
        } else
        {
            return false;
        }

    }

}

package com.equifax.cms.fusion.test.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.json.JobStats;
import com.equifax.cms.fusion.test.qapojos.PdlLayoutMasterPojo;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Database Utils obtain database connection and have helper methods to execute SQL Queries
 * 
 * @author sxr236
 * 
 */
public class OracleDBHelper
{

    private static final Logger LOGGER = LoggerFactory.getLogger(OracleDBHelper.class);

    private Connection connection;

    // get oracle database connection
    private Connection initConnection()
    {
        Connection connection = null;
        try
        {
            // Class.forName("oracle.jdbc.driver.OracleDriver");
            DriverManager.registerDriver(new oracle.jdbc.OracleDriver());
            String host = PropertiesUtils.getProperty("ora.host");
            String user = PropertiesUtils.getProperty("ora.user");
            String password = PropertiesUtils.getProperty("ora.password");
            // DriverManager.registerDriver (new oracle.jdbc.OracleDriver());
            connection = DriverManager.getConnection(host, user, password);
            // connection = DriverManager.getConnection("jdbc:oracle:thin:fusion_lb_qa2/fusion_lb_qa2@172.21.51.43:1521:cmsfudev");
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {0}\n Trace {1}\n ", e.getMessage(), e);
        }
        return connection;
    }

    // return single connection at any point of time
    // no "double-check" since there is no multithreading
    public synchronized Connection getConnection()
    {
        if (null == connection)
        {
            LOGGER.debug("Init database .... ");
            connection = initConnection();
        }
        return connection;
    }

    /**
     * return job status for given jobId, will return 'null' in case jobId not found
     * 
     * @param jobId
     * @return status - Submitted job status
     */

    public String getStatusForJob(long id)
    {
        String sql = "SELECT ID,STATUS,JOB_NUMBER FROM FULFILLMENT_JOB WHERE JOB_NUMBER = ?";
        PreparedStatement statement = null;
        String status = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                status = rs.getString("STATUS");
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return status;
    }

    public Long getLayoutIdFromProcessId(long id)
    {
        String sql = "SELECT LAYOUT_ID FROM PROCESS_ARTIFACT WHERE PROCESS_ID = ?";
        PreparedStatement statement = null;
        Long layoutId = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                layoutId = rs.getLong("LAYOUT_ID");
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return layoutId;

    }

    public List<String> getInputFieldsFromLayoutId(long id)
    {
        String sql = "SELECT NAME FROM INPUT_FILE_FIELD WHERE LAYOUT_ID = ?";
        PreparedStatement statement = null;
        List<String> fields = new ArrayList<String>();
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                fields.add(rs.getString("NAME"));
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return fields;

    }

    public List<String> getPredictedShippedFiles(String projectNum, String assignedId)
    {
        String sql = "select pa.user_provided_name from process_artifact pa where pa.process_id in (select pm.id from process_master pm,"
                + " project_master pr where pm.project_master_id=pr.id and pr.project_number=? and  pm.assigned_id= ?)";
        PreparedStatement statement = null;
        List<String> fields = new ArrayList<String>();
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setString(1, projectNum);
            statement.setString(2, assignedId);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                fields.add(rs.getString("USER_PROVIDED_NAME"));
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return fields;

    }

    /**
     * get job status and job stat conent from DB
     * 
     * @param jobId
     * @return {@link JobDetailsVO}
     */
    public List<JobDetailsVO> getStatusDetails(long id)
    {

        String sql = "SELECT FJ.JOB_NUMBER ,  JS.JOB_ID ,WIT.ITEM_ID , JS.ID, FJ.STATUS, W.STATUS \"WORK_ITEM_STATUS\" , "
                + " WIT.STAT_CONTENT , W.ITEM_NAME FROM  WORK_ITEM_STAT_MASTER WIT, WORK_ITEM W  , "
                + " JOB_PROCESS_STEP JS  , FULFILLMENT_JOB FJ WHERE w.JOB_PROCESS_STEP_ID = JS.ID "
                + " AND WIT.ITEM_ID = W.ID AND JS.JOB_ID =  FJ.ID AND FJ.JOB_NUMBER =  ?";
        PreparedStatement statement = null;
        List<JobDetailsVO> list = new ArrayList<JobDetailsVO>();

        try
        {

            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);
            // execute select SQL stetement
            ResultSet rs = statement.executeQuery();

            while (rs.next())
            {
                JobDetailsVO details = new JobDetailsVO();
                details.setItemName(rs.getString("ITEM_NAME"));
                details.setJobId(rs.getLong("JOB_ID"));
                details.setJobNumber(rs.getLong("JOB_NUMBER"));
                // FULFILLMENT_JOB status
                details.setJobStatus(rs.getString("STATUS"));
                // Job Process Step Id
                details.setJobStepId(rs.getLong("ID"));
                String content = rs.getString("STAT_CONTENT");
                details.setStatContent(content);
                // WORK_ITEM status
                details.setWorkItemStatus(rs.getString("WORK_ITEM_STATUS"));

                ObjectMapper mapper = new ObjectMapper();
                JobStats value = mapper.readValue(content, JobStats.class);
                details.setStats(value);
                LOGGER.info(" >> Job Stats -- %d\n", value.getStats().size());
                list.add(details);

            }
        } catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());

        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return list;
    }

    public PdlLayoutMasterPojo getStartEndPosFromPdlPurpose(String purpose, String field) throws SQLException
    {
        PdlLayoutMasterPojo pdlLayoutPojo = new PdlLayoutMasterPojo();
        PreparedStatement statement = null;
        try
        {
            String sql = "select *  from pdl_layout_master where pdl_purpose= ? and field_name= ?";
            statement = getConnection().prepareStatement(sql);
            statement.setString(1, purpose);
            statement.setString(2, field);

            ResultSet rs = statement.executeQuery();
            ResultSetMetaData metaData = rs.getMetaData();
            int columnCount = metaData.getColumnCount();
            while (rs.next())
            {

                pdlLayoutPojo.setPdlPurpose(rs.getString("PDL_PURPOSE"));
                pdlLayoutPojo.setOrdinalPosition(rs.getInt("ORDINAL_POSITION"));
                pdlLayoutPojo.setFieldName(rs.getString("FIELD_NAME"));
                // FULFILLMENT_JOB status
                pdlLayoutPojo.setFieldType(rs.getString("FIELD_TYPE"));
                // Job Process Step Id
                pdlLayoutPojo.setStartPos(rs.getInt("START_POSITION"));

                pdlLayoutPojo.setEndPos(rs.getInt("END_POSITION"));
                pdlLayoutPojo.setStepFlag(rs.getString("STEP_FLAG"));
                pdlLayoutPojo.setFieldPosition(rs.getInt("FIELD_POSITION"));
                pdlLayoutPojo.setLength(rs.getInt("LENGTH"));

            }

        } catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }

        return pdlLayoutPojo;
    }

    public List<PdlLayoutMasterPojo> fetchPdlLayoutMasterPojoList(String purpose, String field[]) throws SQLException
    {
        List<PdlLayoutMasterPojo> pdlPojoList = new ArrayList<PdlLayoutMasterPojo>();

        for (String element : field)
        {

            PdlLayoutMasterPojo pdlLayoutPojo = new PdlLayoutMasterPojo();
            PreparedStatement statement = null;
            try
            {
                String sql = "select *  from pdl_layout_master where pdl_purpose= ? and field_name= ?";
                statement = getConnection().prepareStatement(sql);
                statement.setString(1, purpose);
                statement.setString(2, element);

                ResultSet rs = statement.executeQuery();
                ResultSetMetaData metaData = rs.getMetaData();
                int columnCount = metaData.getColumnCount();
                while (rs.next())
                {

                    pdlLayoutPojo.setPdlPurpose(rs.getString("PDL_PURPOSE"));
                    pdlLayoutPojo.setOrdinalPosition(rs.getInt("ORDINAL_POSITION"));
                    pdlLayoutPojo.setFieldName(rs.getString("FIELD_NAME"));
                    // FULFILLMENT_JOB status
                    pdlLayoutPojo.setFieldType(rs.getString("FIELD_TYPE"));
                    // Job Process Step Id
                    pdlLayoutPojo.setStartPos(rs.getInt("START_POSITION"));

                    pdlLayoutPojo.setEndPos(rs.getInt("END_POSITION"));
                    pdlLayoutPojo.setStepFlag(rs.getString("STEP_FLAG"));
                    pdlLayoutPojo.setFieldPosition(rs.getInt("FIELD_POSITION"));
                    pdlLayoutPojo.setLength(rs.getInt("LENGTH"));
                    pdlPojoList.add(pdlLayoutPojo);

                }

            } catch (SQLException se)
            {
                LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", se.getMessage());
            } catch (Exception e)
            {
                LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
            }
        }

        return pdlPojoList;
    }

    public String getJobEntryInFulfillmentJobTable(String jobName)
    {
        String sql = "select job_number  from fulfillment_job  where job_name=?";
        PreparedStatement statement = null;
        String jobNumber = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setString(1, jobName);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                jobNumber = rs.getString("job_number");
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", jobName, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }

        return jobNumber;
    }

    public List<String> getSearchProjListBySingleParameter(String field, String value)
    {
        List<String> projList = new ArrayList<>();
        String sql = "select * from project_master where " + field + " like '" + value + "%'";
        PreparedStatement statement = null;
        String projNumber = "";
        try
        {
            statement = getConnection().prepareStatement(sql);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                projNumber = rs.getString("project_number");
                projList.add(projNumber);
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", projNumber, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return projList;
    }

    public List<String> getProjectListOnTwoFieldSelections(String firstField, String secondField, String firstValue, String secondValue)
    {
        List<String> projList = new ArrayList<>();
        String sql = "select * from project_master where " + firstField + " like '" + firstValue + "%' and " + secondField + " like '" + secondValue
                + "%';";
        PreparedStatement statement = null;
        String projNumber = "";
        try
        {
            statement = getConnection().prepareStatement(sql);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                projNumber = rs.getString("project_number");
                projList.add(projNumber);
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", projNumber, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return projList;
    }

    public List<String> getProjectListwithThreeParameterSelections(String firstField, String secondField, String thirdField, String firstValue,
            String secondValue, String thirdVal)
    {
        List<String> projList = new ArrayList<>();
        String sql = "select * from project_master where " + firstField + " like '" + firstValue + "%' and " + secondField + " like '" + secondValue
                + "%' and " + thirdField + " like '" + thirdVal + "%';";
        PreparedStatement statement = null;
        String projNumber = "";
        try
        {
            statement = getConnection().prepareStatement(sql);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                projNumber = rs.getString("project_number");
                projList.add(projNumber);
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", projNumber, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return projList;
    }

    public List<String> getProjectListWithAllParameterSelections(String firstField, String secondField, String thirdField, String fourthField,
            String firstValue, String secondValue, String thirdVal, String fourthVal)
    {
        List<String> projList = new ArrayList<>();
        String sql = "select * from project_master where " + firstField + " like '" + firstValue + "%' and " + secondField + " like '" + secondValue
                + "%' and " + thirdField + " like '" + thirdVal + "%'  and " + fourthField + " like '" + fourthVal + "%';";
        PreparedStatement statement = null;
        String projNumber = "";
        try
        {
            statement = getConnection().prepareStatement(sql);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                projNumber = rs.getString("project_number");
                projList.add(projNumber);
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", projNumber, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return projList;
    }

    public List<String> getProjectListOnProjectNumAndAnalystName(String partialProjectVal, String analyst, String field)
    {
        List<String> projList = new ArrayList<>();
        String sql = "select * from project_master where project_number like '" + partialProjectVal + "%' and " + field + " like '" + analyst + "%';";
        PreparedStatement statement = null;
        String projNumber = "";
        try
        {
            statement = getConnection().prepareStatement(sql);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                projNumber = rs.getString("project_number");
                projList.add(projNumber);
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", projNumber, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return projList;
    }

    public void closeConnection()
    {
        try
        {
            connection.close();
        } catch (Exception e)
        {

        }
    }
}

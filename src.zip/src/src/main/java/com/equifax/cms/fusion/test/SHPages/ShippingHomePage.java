package com.equifax.cms.fusion.test.SHPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ShippingHomePage {
	WebDriver driver;
	public Select selType;
	public ShippingHomePage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = ".//*[@id='shipping']/a")
	WebElement shippingHomeTab_Btn;
	
	@FindBy(xpath = ".//*[@id='contentArea']/div[4]/div[2]/div[1]/ul/li/div[2]/a")
	WebElement shippingProcess_Btn;
	
	
	public void clickShippingHomeTab() {
		shippingHomeTab_Btn.click();
	}

	public void clickShippingProcess() {
		shippingProcess_Btn.click();
	}
	
	@Step("Status of the Shipping process")
	public String getStatusSH(){
		//String status = driver.findElement(By.xpath(".//table[@id='DataTables_Table_0']/tbody/tr[1]/td[3]/div")).getText();
		//as per new changes
		
		String status = driver.findElement(By.xpath("//div[@class='jqx-grid-content jqx-widget-content']//div[@id='row0jqxgridJobListing']/div[3]/div")).getText();
		return status;
	}
}

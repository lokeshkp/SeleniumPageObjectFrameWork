package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ProcessNamePage {

	WebDriver driver;

	public ProcessNamePage(WebDriver driver) {

		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		// PageFactory.initElements(driver, this);
	}

	@FindBy(id = "processName")
	WebElement Ele_processName;

	@FindBy(id = "datapumpSeries")
	WebElement Datapump_Series;

	@FindBy(xpath = ".//input[@type='submit']")
	WebElement ContinueButton;

	@FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/div/label")
	WebElement ErrorMessageProcessName;

	@Step("Input Process Name =  \"{0}\"")
	public void InputProcessNameField(String ProName) {
		Ele_processName.sendKeys(ProName);
	}

	@Step("Selected the datapump series option = \"{0}\"")
	public void selDatapumpSeries(String datapumpSer) {
		if (!"NA".equalsIgnoreCase(datapumpSer)) {
			Select sel = new Select(Datapump_Series);
			sel.selectByVisibleText(datapumpSer);
		}
	}

	@Step("Click Continue Button on Process Name Page")
	public void clickContinueButton() {
		ContinueButton.click();
	}

	@Step("Get Error Message")
	public String getErrorMessage() {
		return ErrorMessageProcessName.getText();
	}

}

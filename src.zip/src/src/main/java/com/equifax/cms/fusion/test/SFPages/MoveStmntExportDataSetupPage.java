package com.equifax.cms.fusion.test.SFPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class MoveStmntExportDataSetupPage
{
    WebDriver driver;
    public Select selType;

    public MoveStmntExportDataSetupPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "performMoveStatement")
    WebElement PerformMoveSt_ChckBox;

    @FindBy(id = "add_SampleFile")
    WebElement Forward_Btn;

    @Step("Click Perform Move Statements")
    public void selectPerformMoveSt_CB(String perfomMoveSt)
    {
        if (!"NA".equalsIgnoreCase(perfomMoveSt))
        {
            if ("Y".equalsIgnoreCase(perfomMoveSt) && !PerformMoveSt_ChckBox.isSelected())
            {
                // PerformMoveSt_ChckBox.click();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", PerformMoveSt_ChckBox);
            } else if ("N".equalsIgnoreCase(perfomMoveSt) && PerformMoveSt_ChckBox.isSelected())
            {
                PerformMoveSt_ChckBox.click();
            }
        }
    }

    public void clickSearchMovStmntButton()
    {
        driver.findElement(By.id("moveStmtSearchButton")).click();

    }

    @Step("Select the available Tables for Move Statement = \"{0}\"")
    public void selectAvailableTables(String tableNames) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(tableNames) && !"ALL".equalsIgnoreCase(tableNames))
        {
            String comma = ",";
            StringTokenizer stMain = new StringTokenizer(tableNames, comma);
            while (stMain.hasMoreElements())
            {
                String dynPath = "//a[contains(text(),'" + stMain.nextToken() + "')]";
                driver.findElement(By.xpath(dynPath)).click();
                Forward_Btn.click();
            }
        } else if ("ALL".equalsIgnoreCase(tableNames))
        {
            Thread.sleep(2000);
            driver.findElement(By.id("addAll_SampleFile")).click();
        }
    }

    @Step("Select Move Layout in the Grid")
    public void selectMoveLayout(String moveLayout, String movStName)
    {
        if (moveLayout.equalsIgnoreCase("Create New"))
        {
            driver.findElement(By.xpath("//label[contains(text(),'" + moveLayout + "')]/preceding::td[1]/input")).click();
        } else if ("ExistingLayout".equalsIgnoreCase(moveLayout))
        {
            driver.findElement(By.xpath("//td[contains(text(),'" + movStName + "')]/preceding::td[1]/input")).click();
        }

    }

    public void clickBackButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[1]")).click();
    }

    public void clickSaveButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[2]")).click();
    }

    public void clickContinueButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[3]")).click();
    }

    public void performMoveStatement(String perfomMoveSt, String tableNames, String moveLayout, String movStName) throws InterruptedException
    {
        if (!"N".equalsIgnoreCase(perfomMoveSt))
        {
            selectPerformMoveSt_CB(perfomMoveSt);
            Thread.sleep(5000);
            selectAvailableTables(tableNames);
            selectMoveLayout(moveLayout, movStName);
        }
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.id("textMsg")).getText();
    }

    public boolean isCreateNewRBtnPresent()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            String type = driver.findElement(By.xpath(".//*[contains(text(),'Create New')]/preceding::td[1]/input")).getAttribute("type");
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            if (type.equalsIgnoreCase("radio"))
            {
                return true;
            } else
            {
                return false;
            }

        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isTablePresent(String table)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            String tab = driver.findElement(By.xpath("(.//*[contains(text(),'" + table + "')])[1]")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            if (tab.endsWith(table))
            {
                return true;
            } else
            {
                return false;
            }
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isTableSelectedForMove()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            int i = driver.findElements(By.xpath(".//*[@id='selectedArtifacts']/div")).size();
            System.out.println(i);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isExistingMoveStatementPresent()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            int i = driver.findElements(By.xpath(".//*[@id='fileLayout-table']/tbody/tr")).size();
            System.out.println(i);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public int countOfTableAvialofMove()
    {
        return driver.findElements(By.xpath(".//*[@id='artifactsHierarchy']/li")).size();
    }

    public int getCountOfExistingMoveStatement(String name)
    {
        return driver.findElements(By.xpath(".//*[contains(text(),'" + name + "')]")).size();
    }

    public String getAppendedDate(String name)
    {
        // problem in splitting the date
        String a = driver.findElement(By.xpath("(.//*[contains(text(),'" + name + ".')])[1]")).getText();
        String[] arrA = a.split(".");
        String s = a.split(".")[0];
        return arrA[1];

    }

    public void clickPerformMoveStatement()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", PerformMoveSt_ChckBox);
    }
}

package com.equifax.cms.fusion.test.SRPPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class StandardReportPages
{
    WebDriver driver;
    public Select selType;

    public StandardReportPages(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//label[contains(text(), 'Process Name:')]")
    WebElement Ele_ProcessID;

    @FindBy(id = "name")
    public WebElement processName_Field;

    @FindBy(id = "fromProcessId")
    WebElement process_DD;

    @FindBy(id = "itemTableId")
    WebElement data_DD;

    @FindBy(id = "jobNumbersMap")
    WebElement job_Map;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement save_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][3]")
    WebElement submit_Btn;

    public String getErrorMsg_Text()
    {
        return driver.findElement(By.id("textMsg")).getText();
    }

    @Step("Select Range Value")
    public void clickRangeValueRadioButton(String rangeOption)
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + rangeOption + "')]//preceding::td[1]/input")).click();
    }

    @Step("Is Specific Range Value Selected")
    public boolean isSpecificRangeValueRadioButton(String rangeOption)

    {
        String option = rangeOption.trim();
        boolean val = driver.findElement(By.xpath("//td[contains(text(),'" + option + "')]/preceding::input[1]")).isSelected();
        return val;
    }

    @Step("Get the Process Id")
    public String getProcId()
    {
        String[] a = Ele_ProcessID.getText().split(":");
        System.out.println("Process Id: " + a[1]);
        String value = a[1].trim();
        return value;
    }

    @Step("Provided the Process Name field = \"{0}\"")
    public void inputProcessName(String processName)
    {
        if (!"NA".equalsIgnoreCase(processName))
        {
            processName_Field.clear();
            processName_Field.sendKeys(processName);
        }
    }

    @Step("Get Process Name")
    public String processNameValue()
    {
        return processName_Field.getAttribute("value");
    }

    @Step("Get Selected Process")
    public String getSelectedProcess()
    {
        Select selType = new Select(process_DD);
        return selType.getFirstSelectedOption().getText();
    }

    @Step("Get Selected Process")
    public String getSelectedData()
    {
        Select selType = new Select(data_DD);
        return selType.getFirstSelectedOption().getText();
    }

    @Step("Selected the process field = \"{0}\"")
    public void selectProcessField(String Process) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(Process))
        {
            Select selType = new Select(process_DD);
            selType.selectByVisibleText(Process);
            Thread.sleep(2000);
        }
    }

    @Step("Selected the Job field When Multiple archive = \"{0}\"")
    public void selectJobField(String job) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(job))
        {
            Select selType = new Select(job_Map);
            selType.selectByVisibleText(job);
            Thread.sleep(2000);
        }
    }

    @Step("Selected the Data field = \"{0}\"")
    public void selectDataField(String Data) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(Data))
        {
            Select selpor = new Select(data_DD);
            selpor.selectByVisibleText(Data);
            Thread.sleep(10000);
        }
    }

    @Step("Clicked Back button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Clicked Save button")
    public void clickSaveButton()
    {
        save_Btn.click();
    }

    @Step("Clicked Submit button")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    @Step("Get error message text")
    public String getErrorMessage()
    {
        return driver.findElement(By.xpath("//span[@id='erMsg']")).getText();
    }

    @Step("Validate if three radio buttons are displayed")
    public boolean ifThreeRadioButtonsDisplayed()
    {
        List<String> radioType = new ArrayList<>();
        boolean result = false;
        String type1 = driver.findElement(By.xpath("//td[contains(text(),'10 Point Increment')]//preceding::td[1]/input")).getAttribute("type");
        String type2 = driver.findElement(By.xpath("//td[contains(text(),'20 Point Increment')]//preceding::td[1]/input")).getAttribute("type");
        String type3 = driver.findElement(By.xpath("//td[contains(text(),'50 Point Increment')]//preceding::td[1]/input")).getAttribute("type");
        radioType.add(type1);
        radioType.add(type2);
        radioType.add(type3);
        for (String s : radioType)
        {
            if (s.equalsIgnoreCase("radio"))
            {
                result = true;
            } else
            {
                return result;
            }
        }
        return result;
    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isSelectElementPresent()
    {
        return isElementPresent(By.id("fromProcessId"));

    }

    public boolean isOptionAvailable()
    {
        return isElementPresent(By.xpath("//select[@id='fromProcessId']/option[1]"));
    }

    public boolean isDistributionReportInStats()
    {
        return isElementPresent(By.xpath("//a[contains(text(),'DISTRIBUTION_REPORT')]"));

    }

    public String getTableSelected()
    {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[2]")).getText();
    }

    public String getRangeValueSelected()
    {
        return driver.findElement(By.xpath(".//*[@checked='checked']/following::td")).getText();
    }

    public String getSRPStatus()
    {
        return driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div[1]/div[3]/div[1]")).getText();
    }
}

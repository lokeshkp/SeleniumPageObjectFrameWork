package com.equifax.cms.fusion.test.RFPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class RFHomePage
{

    WebDriver driver;

    public RFHomePage(WebDriver driver)
    {
        this.driver = driver;

    }

    @FindBy(xpath = ".//a[contains(text(),'+ New Refinement Setup')]")
    WebElement NewRFSetupButton;

    @Step("Clicked Refinement Setup button")
    public void clickRFSetupButton()
    {
        NewRFSetupButton.click();
    }

    @Step("Process Status is ")
    public String getProcessStatus(String procId)
    {
        String status = driver.findElement(By.xpath("//div[contains(text(),'" + procId + "')]//following::div[1]/div")).getText();
        return status;
    }

}

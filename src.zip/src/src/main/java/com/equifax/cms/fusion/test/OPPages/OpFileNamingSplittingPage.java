package com.equifax.cms.fusion.test.OPPages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class OpFileNamingSplittingPage
{

    WebDriver driver;

    public OpFileNamingSplittingPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "startingFileNumber")
    public WebElement Ele_StartingFileNum;

    @FindBy(id = "fileSplitter")
    public WebElement Ele_FileSplittingRequired;

    @FindBy(id = "chkMaxNoOfRecordsToFile")
    public WebElement Ele_PerformOutputLimit;

    @FindBy(id = "dividefile")
    public WebElement divideFileIntoGrps_RB;

    @FindBy(id = "outputFilename")
    WebElement Ele_DivideFileIntoGrpNo;

    @FindBy(id = "fileSplit")
    public WebElement splitByRecsPerFile_RB;

    @FindBy(id = "splitFile")
    WebElement Ele_SplitFileNo;

    @FindBy(id = "outputFieldSplit")
    public WebElement splitByField_RB;

    @FindBy(id = "outputFieldId")
    WebElement Ele_SplitFieldField;

    @FindBy(id = "secondarySplitFlag")
    WebElement Ele_SecondarySplit;

    @FindBy(id = "fileSize")
    public WebElement splitFileBySize_RB;

    @FindBy(id = "dividefileUnderSplitField")
    WebElement secondarySplit_DivideFileElement;

    @FindBy(id = "secondaryOutputFilename")
    WebElement groupPerSplit;

    @FindBy(id = "fileSplitUnderSplitField")
    WebElement fileSplit_UnderSplitField;

    @FindBy(id = "secondarySplitFile")
    WebElement secondary_SplitFile;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    // Ele_SecondarySplit
    @Step("Check Whether Secondary Split Option Is Enabled Or Not")
    public boolean isSecondarySplitChecked()
    {
        return  Ele_SecondarySplit.isSelected();

    }
    public String isPerformOutputLimitReq()
    {
        String isOutputLimiReq="Y";
        if(Ele_PerformOutputLimit.getAttribute("value").equals(""))
        {
            isOutputLimiReq="N";
        }
        return isOutputLimiReq;
    }
    public String isFilesplittingReq()
    {
        String isFileSplitReq="Y";
        if(Ele_FileSplittingRequired.getAttribute("value").equals(""))
        {
            isFileSplitReq="N";
        }
        return isFileSplitReq;
    }
    public String getErrorMessage()
    {
        return driver.findElement(By.id("textMsg")).getText();
    }

    public void selectOutputSplit(String fileSplitReq, String grpNum, String numOfFiles, String splitField)
    {
        if (!"N".equalsIgnoreCase(fileSplitReq))
        {
            clickFileSplitReq();
            if (!"NA".equalsIgnoreCase(grpNum))
            {
                clickDivideFileIntoGrps();
                divideFileIntoGrpsValue(grpNum);
            }
            if (!"NA".equalsIgnoreCase(numOfFiles))
            {
                clickSplitPerFile();
                splitPerFileValue(numOfFiles);
            }
            if (!"NA".equalsIgnoreCase(splitField))
            {
                clickSplitField();
                selectSplitFieldByField(splitField);
            }
        }
    }
    public void selectOutputSecondarySplit(String fileSplitReq,String splitField, String secondarySplitReq, String secondarySplitByFile,String secondarySplitByRecord)
    {
        if ("Y".equalsIgnoreCase(fileSplitReq))
        {
            if (!"NA".equalsIgnoreCase(splitField))
            {
                if ("Y".equalsIgnoreCase(secondarySplitReq))
                {
                    Ele_SecondarySplit.click();
                    if(!"NA".equalsIgnoreCase(secondarySplitByFile))
                    {
                        secondarySplit_DivideFileElement.click();
                        groupPerSplit.clear();
                        groupPerSplit.sendKeys(secondarySplitByFile);
                    }
                    if(!"NA".equalsIgnoreCase(secondarySplitByRecord))
                    {
                        fileSplit_UnderSplitField.click();
                        secondary_SplitFile.clear();
                        secondary_SplitFile.sendKeys(secondarySplitByRecord);
                    }
                }
            }
        }
    }


    public String getLayoutNameSplitPage()
    {
        String[] name = driver.findElement(By.xpath("((.//*[@class='fileSummaryBlock'])[4]/div)[1]")).getText().split(":");
        return name[1].trim();
    }

    @Step("Provide Starting File Number field value = \"{0}\"")
    public void StartingFileNumField(String FileNum)
    {
        if (!"NA".equalsIgnoreCase(FileNum))
        {
            Ele_StartingFileNum.sendKeys(FileNum);
        }
    }

    public boolean isFileSplittingChecked()
    {
        return Ele_FileSplittingRequired.isSelected();
    }

    public boolean isSplitByFieldChecked()
    {
        return splitByField_RB.isSelected();
    }

    @Step("Select File Splitting Required field")
    public void clickFileSplitReq()
    {
        Ele_FileSplittingRequired.click();
    }

    @Step("Select Divide File evenly into Groups")
    public void clickDivideFileIntoGrps()
    {
        divideFileIntoGrps_RB.click();
    }

    @Step("Check if Divide File evenly into Groups option Selected")
    public boolean isDivideFileIntoGrpsSelected()
    {
        return divideFileIntoGrps_RB.isSelected();
    }

    @Step("Check if File Split sec option Selected")
    public boolean isFileSplitUnderSecSplitSelected()
    {
        return fileSplit_UnderSplitField.isSelected();
    }

    @Step("Divide File evenly into Groups = \"{0}\"")
    public void divideFileIntoGrpsValue(String grpNum)
    {
        Ele_DivideFileIntoGrpNo.sendKeys(grpNum);
    }

    @Step("Get group count when Divide File evenly into Groups = \"{0}\"")
    public String getGroupDivisionCount()
    {
        return Ele_DivideFileIntoGrpNo.getAttribute("value");
    }

    @Step("Select File Split per file field")
    public void clickSplitPerFile()
    {
        splitByRecsPerFile_RB.click();
    }

    @Step("Check if Divide File evenly into Groups option Selected")
    public boolean isSplitByRecordsSelected()
    {
        return splitByRecsPerFile_RB.isSelected();
    }

    @Step("Check if Secondary Split Selected")
    public boolean isSecondarySplitSelected()
    {
        return Ele_SecondarySplit.isSelected();
    }

    @Step("Check if Secondary Split-Divide File Selected")
    public boolean isSecondarySplitDivideFileSelected()
    {
        return secondarySplit_DivideFileElement.isSelected();
    }

    @Step("Check if Secondary Split-File by Records Selected")
    public boolean isSecondarySplitRecordsFileSelected()
    {
        return fileSplit_UnderSplitField.isSelected();
    }

    @Step("Get group count when Divide File evenly into Groups = \"{0}\"")
    public String getSplitByRecordsCount()
    {
        return Ele_SplitFileNo.getAttribute("value");
    }

    @Step("File Split per file field = \"{0}\"")
    public void splitPerFileValue(String numOfFiles)
    {
        Ele_SplitFileNo.sendKeys(numOfFiles);
    }

    @Step("Select Split File field")
    public void clickSplitField()
    {
        splitByField_RB.click();
    }

    @Step("Select secondary Split Required field")
    public void clickSecondarySplitReq(String secondarySplitReq)
    {
        if(secondarySplitReq.equalsIgnoreCase("Y"))
        {
            Ele_SecondarySplit.click();
        }
    }

    @Step("Select Split field by field")
    public void selectSplitFieldByField(String splitField)
    {
        Select spField = new Select(Ele_SplitFieldField);
        spField.selectByVisibleText(splitField);

    }

    @Step("Select Split field by field")
    public String getSecSplitGroupsSelected()
    {
        return groupPerSplit.getAttribute("value");

    }

    @Step("Select Split field by Records field")
    public String getSecSplitRecordsSelected()
    {
        return secondary_SplitFile.getText();
    }

    @Step("Select divide File Fir Secondary Split")
    public void clickDivideFileSecondarySplit()
    {
        secondarySplit_DivideFileElement.click();
    }

    @Step("Select divide File Fir Secondary Split")
    public void clickSplitFileSecondarySplit()
    {
        fileSplit_UnderSplitField.click();
    }

    @Step("File Split per file field For Secondary Split= \"{0}\"")
    public void secondarySplitPerFileValue(String numOfFiles)
    {
        secondary_SplitFile.sendKeys(numOfFiles);
    }

    @Step("Divider file For Secondary Split= \"{0}\"")
    public void secondarySplitDivideFileIntoGroups(String groups)
    {
        groupPerSplit.sendKeys(groups);
    }

    public String getSplitDetailsForSummary(String fileSplitReq, String grpNum, String numOfFiles, String splitField)
    {
        String label = "";
        if ("Y".equalsIgnoreCase(fileSplitReq))
        {
            if (!"NA".equalsIgnoreCase(grpNum))
            {
                //label = "Split File By " + grpNum + " Records Per File ";
                label="Divide File Evenly Into " + grpNum + " Groups";
            } else if (!"NA".equalsIgnoreCase(numOfFiles))
            {
                label = "Split File By " + numOfFiles + " Records Per File ";

            } else if (!"NA".equalsIgnoreCase(splitField))
            {
                label = "Split By Field " + splitField;
            }
        }
        return label;
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public boolean isReSequenceDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            String aa = driver.findElement(By.xpath("(.//*[contains(text(),'.RE_SEQUENCE_NUM')])")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public void selectSecondarySplitOptions(String secSplitReq, String secondarySplit)
    {
        if (!"N".equalsIgnoreCase(secSplitReq))
        {
            String splitOption[] = secondarySplit.split(",");
            if ("DIVIDE".equalsIgnoreCase(splitOption[0]))
            {
                clickDivideFileSecondarySplit();
                secondarySplitDivideFileIntoGroups(splitOption[1]);

            } else
            {
                clickSplitFileSecondarySplit();
                secondarySplitPerFileValue(splitOption[1]);
            }
        }
    }
    @Step("Checking whether MDB_DATE is present in the drop down list or not")
    public boolean IsMDBDatePresent()
    {
        boolean isMDB_DatePresent=true;
        clickSplitField();
        WebElement selectElement = driver.findElement(By.id("outputFieldId"));
        Select select = new Select(selectElement);
        List<WebElement> allOptions = select.getOptions();
        //List<WebElement>elements=driver.findElements(By.xpath("//select[@id='outputFieldId']"));
        String search = "MDB_DATE";
        for(WebElement ele: allOptions)
        {
            if(!ele.getText().trim().contains(search))
            {
                isMDB_DatePresent=false;
            }

        }
        return isMDB_DatePresent;

    }

}

package com.equifax.cms.fusion.test.OPPages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class OpMoveStatementsPage
{

    WebDriver driver;

    public OpMoveStatementsPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "addnewrow")
    WebElement AddButton;

    @FindBy(xpath = ".//*[@id='outputMoveTable']/tbody/tr/td[2]/span/a")
    WebElement LayoutFieldDropdown;

    @FindBy(xpath = ".//*[@id='outputMoveTable']/tbody/tr/td[2]/span/input")
    WebElement LayoutFieldValue;

    @FindBy(xpath = "(.//*[@id='0']/img)[1]")
    WebElement RecTypesImg;

    @FindBy(xpath = "(.//*[@id='0']/img)[2]")
    WebElement DataToOp;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(id = "addAll_opMoveRecType")
    WebElement clickFastForward_Btn;

    @FindBy(id = "enterBlank")
    public WebElement blankFill_RB;

    @FindBy(id = "enterLiteral")
    public WebElement enterLiteral_RB;

    @FindBy(id = "selectField")
    public WebElement selectField_RB;

    public List<String> getAvailableRecordsType()
    {
        List<WebElement> webElements = driver.findElements(By.xpath(".//*[@id='content-item-0']/ul/li/a"));
        List<String> availRecs = new ArrayList<String>();
        for (WebElement we : webElements)
        {
            String[] recordArr = we.getText().split("-");
            availRecs.add(recordArr[0].trim());

        }
        return availRecs;
    }

    public String getBlankFill()
    {
        return driver.findElement(By.xpath(".//*[@id='enterBlank']/following::span[1]")).getText();
    }

    public String getEnterLiteral()
    {
        return driver.findElement(By.xpath(".//*[@id='enterLiteral']/following::span[1]")).getText();
    }

    public String getSelectField()
    {
        return driver.findElement(By.xpath(".//*[@id='selectField']/following::span[1]")).getText();
    }

    public void clickDataToOutputIcon()
    {
        //driver.findElement(By.xpath("(.//*[@id='0']/img)[2]")).click();
        driver.findElement(By.xpath("(.//*[@class='shadow_box_trigger_dataOp']/img)")).click();
    }

    public void clickRecordTypeIcon()
    {
        //driver.findElement(By.xpath("(.//*[@id='0']/img)[1]")).click();
    	driver.findElement(By.xpath("(.//*[@class='shadow_box_trigger_recType']/img)")).click();
    }

    @Step("Click add button")
    public void clickAddButton()
    {
        AddButton.click();
    }

    @Step("Select the Output Layout Field and Start Position = \"{0}\"")
    public void selectLayoutFieldValue(String value)
    {
        LayoutFieldDropdown.click();
        LayoutFieldValue.sendKeys(value);
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Click add all record >>")
    public void clickAddAllRecords()
    {
        clickFastForward_Btn.click();
    }

    @Step("Continue the process")
    public void clickContinueButton(String process)
    {
        if (!process.startsWith("IP") && !process.startsWith("DNS"))
        {
            ContinueButton.click();
        }
    }

    public String getSelectedRecords()
    {
        return driver.findElement(By.xpath("//div[@class='selected-fields_opMoveRecType']/div/div/ul/li/span")).getText();
    }

    public void clickBackButton()
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[1]")).click();
    }

    public void selectLayoutField(String layoutField)
    {

        int i = 1;
        clickAddButton();
        String dynamicDropdown = ".//*[@id='outputMoveTable']/tbody/tr[" + i + "]/td[2]/span/a";
        String dymanicField = "//a[contains(text(),'" + layoutField + "')]";
        driver.findElement(By.xpath(dynamicDropdown)).click();
        driver.findElement(By.xpath(dymanicField)).click();

    }

    @Step("Select Output Layout field = \"{0}\"")
    public void selectLayoutField(String layoutField, int i, int j) throws InterruptedException
    {

        // int i = 1;
        clickAddButton();
        Thread.sleep(2000);
        String dynamicDropdown = ".//*[@id='outputMoveTable']/tbody/tr[" + (i + 1) + "]/td[2]/span/a";
        driver.findElement(By.xpath(dynamicDropdown)).click();
        Thread.sleep(2000);
        List<WebElement> list = driver.findElements(By.xpath(".//*[@id='ui-id-" + (j + 1) + "']/li//a[contains(text(),'" + layoutField + "')]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", list.get(0));

    }

    @Step("Is Field Present In Move Statement Screen")
    public boolean isFieldPresentForMovStat(String layoutField) throws InterruptedException
    {
        boolean isPresent=false;
        Thread.sleep(2000);
        clickAddButton();
        Thread.sleep(2000);
        String dynamicDropdown = ".//*[@id='outputMoveTable']/tbody/tr[1]/td[2]/span/a";
        driver.findElement(By.xpath(dynamicDropdown)).click();
        Thread.sleep(2000);
        List<WebElement> list = driver.findElements(By.xpath(".//*[@id='ui-id-1']/li//a"));
        for(WebElement ele:list)
        {
            String[] fieldArr=ele.getText().split("\\.");
            if(fieldArr[0].trim().equalsIgnoreCase(layoutField))
            {

                isPresent=true;
            }


        }
        return isPresent;
    }

    public void selectOutputMoveStmnt(String field, String recType, String dataToOutput, String process) throws InterruptedException
    {
    	if (!process.startsWith("DNS") &&!process.startsWith("IP"))
        {
        	
            if (!"NA".equalsIgnoreCase(field))
            {
                selectLayoutField(field, 0, 0);
            }
            if (!"NA".equalsIgnoreCase(recType))
            {
                // driver.switchTo().frame("sb-player");
                selectRecTypes(recType);
            }
            if (!"NA".equalsIgnoreCase(dataToOutput))
            {
                // driver.switchTo().frame("outputMoveForm");
                selectDatatoOutput(dataToOutput);
            }
        }
    }

    // Working method for selecting multiple rows, pass layoutFieldsSelect variable
    public void selectOutputMoveStmnt(String field, String recType, String dataToOutput, String process, String layoutFieldsSelect)
            throws InterruptedException
            {
        String fieldSplit[] = field.split(",");
        String recTypeSplit[] = recType.split(";");
        String dataToOutputSplit[] = dataToOutput.split(";");
        int i = 0;
        int j = 0;
        String layoutFieldSelectSplit[] = layoutFieldsSelect.split(",");
        int length = layoutFieldSelectSplit.length;
        if (!process.startsWith("IP"))
        {
            if (!"NA".equalsIgnoreCase(field))
            {
                while (i < fieldSplit.length)
                {
                    selectLayoutField(fieldSplit[i], i, j);
                    j = j + length + 1;
                    i++;
                }
            }
            i = 0;
            if (!"NA".equalsIgnoreCase(recType))
            {
                // driver.switchTo().frame("sb-player");
                while (i < fieldSplit.length)
                {
                    selectRecTypes(recTypeSplit[i]);
                    i++;
                }

            }
            i = 0;
            if (!"NA".equalsIgnoreCase(dataToOutput))
            {
                // driver.switchTo().frame("outputMoveForm");
                while (i < fieldSplit.length)
                {
                    selectDatatoOutput(dataToOutputSplit[i]);
                    i++;
                }
            }
        }
            }

    public void selectLayout(String layout)
    {
        String delimiter = ",";
        StringTokenizer eachChkBoxText = new StringTokenizer(layout, delimiter);

        while (eachChkBoxText.hasMoreTokens())
        {
            int i = 1;
            if (!"NA".equalsIgnoreCase(layout))
            {
                String dynamicDropdown = ".//*[@id='outputMoveTable']/tbody/tr[" + i + "]/td[2]/span/a";
                String dymanicField = ".//a[contains(text(),'" + eachChkBoxText.nextToken() + "')]";
                clickAddButton();
                driver.findElement(By.xpath(dynamicDropdown)).click();
                driver.findElement(By.xpath(dymanicField)).click();

            }
            i++;
        }

    }

    public void clickRecordTypeImg() throws InterruptedException
    {
        AddButton.click();
        Thread.sleep(2000);
        String dynImage = "//*[@id='0']/img";
        driver.findElement(By.xpath(dynImage)).click();

        driver.switchTo().frame(0);
    }

    @Step("Select Move Statement Record Types = \"{0}\"")
    public void selectRecTypes(String recType, int i) throws InterruptedException
    {
        String[] recTypeArr=recType.split(",");
        String dynImage = "(.//*[@id='" + i + "']/img)[1]";
        driver.findElement(By.xpath(dynImage)).click();
        driver.switchTo().frame(0);
        // If else done as single alphabet record types have an extra space after them
        if (recTypeArr.length == 1)
        {
            driver.findElement(By.xpath("//*[@title='" + recTypeArr[0] + "']/a")).click();
            //driver.findElement(By.xpath(".//a[@id = '" + recTypeArr[0] + ' ' + "']")).click();
            driver.findElement(By.id("add_file_split1")).click();
            driver.findElement(By.xpath("(.//a[contains(text(),'Save')])[1]")).click();
            Thread.sleep(2000);
        } else
        {
            List<String> recList=Arrays.asList(recTypeArr);
            for(String rec:recList)
            {
                //driver.findElement(By.xpath(".//a[@id = '" + rec + "']")).click();
                driver.findElement(By.xpath(".//li[starts-with(@title,'" + rec + "')]/a")).click();
                driver.findElement(By.id("add_file_split1")).click();

            }
            driver.findElement(By.xpath("(.//a[contains(text(),'Save')])[1]")).click();
            Thread.sleep(2000);
            //driver.findElement(By.xpath(".//a[text() = '" + recType + "']")).click();
        }

        driver.switchTo().defaultContent();
    }

    @Step("Select Move Statement Record Types = \"{0}\"")
    public void selectRecTypes(String recType) throws InterruptedException
    {
        int i = 1;
        String dynImage = "(.//*[@id='0']/img)[" + i + "]";
        driver.findElement(By.xpath(dynImage)).click();
        driver.switchTo().frame(0);
        driver.findElement(By.xpath("//li[@title='" + recType + "']/a")).click();
        // driver.findElement(By.xpath("//a[contains(text(),'" + recType + "')]")).click();
        driver.findElement(By.id("add_opMoveRecType")).click();
        driver.findElement(By.xpath("(//a[contains(text(),'Save')])[1]")).click();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
    }

    @Step("Select the Data To Output field = \"{0}\"")
    public void selectDatatoOutput(String dataOP, int i) throws InterruptedException
    {
        Thread.sleep(1000);
        driver.findElement(By.xpath("(.//*[@id='" + i + "']/img)[2]")).click();
        driver.switchTo().frame("sb-player");
        String[] dataToOuptut = dataOP.split(",");
        if ("Blank Fill".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("enterBlank")).click();
        } else if ("Enter Literal".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("literalValue")).clear();
            driver.findElement(By.id("literalValue")).sendKeys(dataToOuptut[1]);
        } else if ("Select Field".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("selectField")).click();
            driver.findElement(By.xpath(".//*[@title='" + dataToOuptut[1] + "']")).click();
            driver.findElement(By.id("add_opMoveDataOp")).click();
        }
        driver.findElement(By.xpath(".//*[@id='outputMoveForm']/div[2]/a[2]")).click();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
    }

    @Step("Select the Data To Output field = \"{0}\"")
    public void selectDatatoOutput(String dataOP) throws InterruptedException
    {
        Thread.sleep(1000);
        driver.findElement(By.xpath("(.//*[@id='0']/img)[2]")).click();

        String[] dataToOuptut = dataOP.split(",");
        driver.switchTo().frame("sb-player");

        if ("Blank Fill".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("enterBlank")).click();
        } else if ("Enter Literal".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("literalValue")).clear();
            driver.findElement(By.id("literalValue")).sendKeys(dataToOuptut[1]);
        } else if ("Select Field".equalsIgnoreCase(dataToOuptut[0]))
        {
            driver.findElement(By.id("selectField")).click();
            driver.findElement(By.xpath(".//*[@title='" + dataToOuptut[1] + "']")).click();
            driver.findElement(By.id("add_opMoveDataOp")).click();
        }
        driver.findElement(By.xpath(".//*[@id='outputMoveForm']/div[2]/a[2]")).click();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
        Thread.sleep(1000);
    }

    public boolean isReSequenceDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            String aa = driver.findElement(By.xpath(".//a[contains(text(),'RE_SEQUENCE_NUM')]")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Provide Output Move Statement values")
    public void opMoveStatements(String layoutField, String recType, String datatoOP)
    {
        String delims1 = ":";
        String delims2 = ";";
        String splitString1 = layoutField;
        String recSplitString1 = recType;
        StringTokenizer stMain = new StringTokenizer(splitString1, delims1);
        StringTokenizer NCPstMain = new StringTokenizer(recSplitString1, delims2);

        int i = 1;
        if ("NA".equalsIgnoreCase(layoutField))
        {
            System.out.println("Not required to provide any information, navigate to next screen");

        } else
        {
            while (stMain.hasMoreElements())
            {

                String splitString2 = stMain.nextToken();
                StringTokenizer stchild = new StringTokenizer(splitString2, delims2);
                String dynamicDropDown = ".//*[@id='outputMoveTable']/tbody/tr[" + i + "]/td[2]/span/a";
                String dynamicLayoutField = ".//a[contains(text(),'" + layoutField + "')]";
                String dynamicImage = "(.//*[@id='0']/img)[" + i + "]";
                // String dynamicRecType =

                while (stchild.hasMoreElements())
                {
                    clickAddButton();
                }
            }
        }
    }

    public String getErrorMsgOnRecordTypeChange()
    {
        return driver.findElement(By.xpath("//div[@class='error']/li")).getText();

    }

    public String getMoveStatementlabelWhenNoRows()
    {
        String flag = driver.findElement(By.xpath("//table[@id='outputMoveTable']/tbody/tr[1]/td[1]")).getText();
        return flag;
    }

    public boolean isopSplitScreen()
    {
        boolean flag = false;
        try
        {
            if (isElementPresent(By.xpath("//h3[contains(text(),'Output File Splitting')]")))
            {
                flag = true;
            }
        } catch (Exception e)
        {
        }
        return flag;
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public String getFirstOPLayoutField()
    {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[1]")).getText();
    }

    public String getSecondOPLayoutField()
    {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[2]")).getText();
    }

    public String getFirstRecordTypes()
    {
        return driver.findElement(By.xpath(".//*[@id='recordTypeSpan_0']")).getText();
    }

    public String getSecondRecordTypes()
    {
        return driver.findElement(By.xpath(".//*[@id='recordTypeSpan_1']")).getText();
    }

    public String getFirstDataToOutput()
    {
        String[] dataToOP = driver.findElement(By.xpath(".//*[@id='dataOutputSpan_0']")).getText().split(":");
        return dataToOP[1].trim();
    }

    public String getSecondDataToOutput()
    {
        String[] dataToOP = driver.findElement(By.xpath(".//*[@id='dataOutputSpan_1']")).getText().split(":");
        return dataToOP[1].trim();
    }
    public String isMoveStatementReq()
    {
        String isMoveStatementReq="Y";
        if(driver.findElement(By.xpath("//*[contains(text(),'No data available in table')]")).isDisplayed()==true)
        {
            isMoveStatementReq="N";
        }
        return isMoveStatementReq;
    }
    public void deleteTheSelectedRow() throws InterruptedException
    {
        //String isMoveStatementReq="Y";
        driver.findElement(By.xpath("//img[@class='deleteRow']//parent::a")).click();
        Thread.sleep(1500);

    }

}

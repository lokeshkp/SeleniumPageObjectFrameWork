package com.equifax.cms.fusion.test.json;

import java.util.HashMap;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({ "key", "value", "reference", "refersTo", "hidden", "description", "removeCommaAtEnd",
		"childStatItems" })
public class StatItem {

	@JsonProperty("key")
	private String key;
	@JsonProperty("value")
	private String value;
	@JsonProperty("reference")
	private Boolean reference;
	@JsonProperty("refersTo")
	private Object refersTo;
	@JsonProperty("hidden")
	private Boolean hidden;
	@JsonProperty("description")
	private String description;
	@JsonProperty("removeCommaAtEnd")
	private Boolean removeCommaAtEnd;
	@JsonProperty("childStatItems")
	private Object childStatItems;
	@JsonIgnore
	private Map<String, Object> additionalProperties = new HashMap<String, Object>();

	/**
	 * 
	 * @return The key
	 */
	@JsonProperty("key")
	public String getKey() {
		return key;
	}

	/**
	 * 
	 * @param key
	 *            The key
	 */
	@JsonProperty("key")
	public void setKey(String key) {
		this.key = key;
	}

	/**
	 * 
	 * @return The value
	 */
	@JsonProperty("value")
	public String getValue() {
		return value;
	}

	/**
	 * 
	 * @param value
	 *            The value
	 */
	@JsonProperty("value")
	public void setValue(String value) {
		this.value = value;
	}

	/**
	 * 
	 * @return The reference
	 */
	@JsonProperty("reference")
	public Boolean getReference() {
		return reference;
	}

	/**
	 * 
	 * @param reference
	 *            The reference
	 */
	@JsonProperty("reference")
	public void setReference(Boolean reference) {
		this.reference = reference;
	}

	/**
	 * 
	 * @return The refersTo
	 */
	@JsonProperty("refersTo")
	public Object getRefersTo() {
		return refersTo;
	}

	/**
	 * 
	 * @param refersTo
	 *            The refersTo
	 */
	@JsonProperty("refersTo")
	public void setRefersTo(Object refersTo) {
		this.refersTo = refersTo;
	}

	/**
	 * 
	 * @return The hidden
	 */
	@JsonProperty("hidden")
	public Boolean getHidden() {
		return hidden;
	}

	/**
	 * 
	 * @param hidden
	 *            The hidden
	 */
	@JsonProperty("hidden")
	public void setHidden(Boolean hidden) {
		this.hidden = hidden;
	}

	/**
	 * 
	 * @return The description
	 */
	@JsonProperty("description")
	public String getDescription() {
		return description;
	}

	/**
	 * 
	 * @param description
	 *            The description
	 */
	@JsonProperty("description")
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * 
	 * @return The removeCommaAtEnd
	 */
	@JsonProperty("removeCommaAtEnd")
	public Boolean getRemoveCommaAtEnd() {
		return removeCommaAtEnd;
	}

	/**
	 * 
	 * @param removeCommaAtEnd
	 *            The removeCommaAtEnd
	 */
	@JsonProperty("removeCommaAtEnd")
	public void setRemoveCommaAtEnd(Boolean removeCommaAtEnd) {
		this.removeCommaAtEnd = removeCommaAtEnd;
	}

	/**
	 * 
	 * @return The childStatItems
	 */
	@JsonProperty("childStatItems")
	public Object getChildStatItems() {
		return childStatItems;
	}

	/**
	 * 
	 * @param childStatItems
	 *            The childStatItems
	 */
	@JsonProperty("childStatItems")
	public void setChildStatItems(Object childStatItems) {
		this.childStatItems = childStatItems;
	}

	@JsonAnyGetter
	public Map<String, Object> getAdditionalProperties() {
		return this.additionalProperties;
	}

	@JsonAnySetter
	public void setAdditionalProperty(String name, Object value) {
		this.additionalProperties.put(name, value);
	}

}
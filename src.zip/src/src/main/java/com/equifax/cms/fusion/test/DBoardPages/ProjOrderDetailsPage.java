package com.equifax.cms.fusion.test.DBoardPages;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ProjOrderDetailsPage {
	
	WebDriver driver;
	Select sel;
	
	public ProjOrderDetailsPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
	}
	
	@FindBy(id = "team")
	public WebElement TeamFld;
	
	@FindBy(id = "parentSubmit")
	WebElement ContinueBtn;
	
	@FindBy(id = "fulfillmentAnalyst")
	WebElement Analyst;
	
	@FindBy(id = "primaryProgrammer")
	WebElement PrimaryProgrammer;
	
	@FindBy(id = "checkerProgrammer")
	WebElement CheckerProgrammer;
	
	@FindBy(xpath = "(//img[@class='ui-datepicker-trigger'])[1]")
	WebElement FinalDate;
	
	@FindBy(xpath = "(//img[@class='ui-datepicker-trigger'])[2]")
	WebElement AuditDate;
	
	@FindBy(id = "status")
	WebElement Status;
	
	@FindBy(id = "purgedays")
	public WebElement PurgeDays;
	
	@FindBy(id = "executionSite")
	public WebElement ExecuteSite;
	
	@FindBy(id = "datapumpSer")
	public WebElement DataPumpSeries;
	
	@Step("Selected the DataPump Series value = \"{0}\"")
	public void selDataPumpSer(String value){
		sel = new Select(DataPumpSeries);
		if("1".equalsIgnoreCase(value)){
			sel.selectByVisibleText("1.0");
		} else if("2".equalsIgnoreCase(value)){
			sel.selectByVisibleText("2.0");
		}
	}
	
	@Step("Clicked Continue button")
	public void clickContinueBtn(){
		ContinueBtn.click();
	}
	
	@Step("Selected the Analyst fields = \"{0}\"")
	public void selAnalyst(String analyst){
		sel = new Select(Analyst);
		sel.selectByVisibleText(analyst);
	}
	
	@Step("Selected the Primary Programmer = \"{0}\"")
	public void selPriProgrammer(String primPrmer){
		sel = new Select(PrimaryProgrammer);
		sel.selectByVisibleText(primPrmer);
	}
	
	@Step("Selected the Checker Programmer = \"{0}\"")
	public void selCheckerProgrammer(String chckerPrmer){
		sel = new Select(CheckerProgrammer);
		sel.selectByVisibleText(chckerPrmer);
	}
	
	@Step("Select the Shipped Date = \"{0}\" \"{1}\" \"{2}\"")
    public void selectDate() throws InterruptedException
    {
		FinalDate.click();
        String day = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
        System.out.println("day : " + day);
        int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        if (day.startsWith("0"))
        {
            driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();

        } else
        {
            driver.findElement(By.xpath("(//a[contains(text(), '" + day + "')])[1]")).click();
        }
    }
	
	@Step("Selected the Audit Date = \"{0}\" \"{1}\" \"{2}\"")
	public void selAuditDate() 
	{
		AuditDate.click();
        String day = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
        System.out.println("day : " + day);
        int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        if (day.startsWith("0"))
        {
            driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();

        } else
        {
            driver.findElement(By.xpath("(//a[contains(text(), '" + day + "')])[1]")).click();
        }
	}
	
	@Step("Analyst Name is = \"{0}\"")
	public boolean analystNames(String analyst){
		try{
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        sel = new Select(Analyst);
	        sel.selectByVisibleText(analyst);
	        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	        return true;
	    } catch (org.openqa.selenium.NoSuchElementException e){
	        return false;
	    }
	}
	
	@Step("Active Field is = \"{0}\"")
	public boolean activeFlds(String status){
		try{
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        sel = new Select(Status);
	        sel.selectByVisibleText(status);
	        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	        return true;
	    } catch (org.openqa.selenium.NoSuchElementException e){
	        return false;
	    }
	}
}

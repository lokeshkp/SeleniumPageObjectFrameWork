package com.equifax.cms.fusion.test.MJpages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class MatchJoinConfigPage
{

    WebDriver driver;
    public Select selType;

    public MatchJoinConfigPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "add")
    WebElement addMaster_Btn;

    @FindBy(id = "remove")
    WebElement removeMaster_Btn;

    @FindBy(id = "addAll")
    WebElement addAllMaster_Btn;

    @FindBy(id = "removeAll")
    WebElement removeAllMaster_Btn;

    @FindBy(id = "add2")
    WebElement addMatch_Btn;

    @FindBy(id = "remove2")
    WebElement removeMatch_Btn;

    @FindBy(id = "addAll2")
    WebElement addAllMatch_Btn;

    @FindBy(id = "removeAll2")
    WebElement removeAllMatch_Btn;

    @FindBy(id = "add3")
    WebElement addAppend_Btn;

    @FindBy(id = "remove3")
    WebElement removeAppend_Btn;

    @FindBy(id = "addAll3")
    WebElement addAllAppend_Btn;

    @FindBy(id = "removeAll3")
    WebElement removeAllAppend_Btn;

    @FindBy(xpath = "(.//input[@name='submitButton'])[1]")
    WebElement saveButton;

    @FindBy(xpath = "(.//input[@name='submitButton'])[2]")
    WebElement continueButton;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement backButton;

    public boolean isMasterFieldSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='selectedContent1']/div")).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isMatchFieldSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='selectedContent2']/div")).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isAppendedFieldSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='appendedFields']/div[2]/div/ul")).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Clicked Back Button")
    public void clickBackButton()
    {
        backButton.click();
    }

    @Step("Clicked Save Button")
    public void clickSaveButton()
    {
        saveButton.click();
    }

    @Step("Clicked Continue Button")
    public void clickContinueButton()
    {
        continueButton.click();
    }

    @Step("Clicked Add Master Button")
    public void clickAddMasterButton() throws InterruptedException
    {
        addMaster_Btn.click();
    }

    @Step("Clicked Remove Master Button")
    public void clickRemoveMasterButton()
    {
        removeMaster_Btn.click();
    }

    @Step("Clicked Add All Master Button")
    public void clickAdd_AllMasterButton()
    {
        addAllMaster_Btn.click();
    }

    @Step("Clicked Remove All Master Button")
    public void clickRemove_AllMasterButton()
    {
        removeAllMaster_Btn.click();
    }

    @Step("Clicked Add Match Button")
    public void clickAddMatchButton()
    {
        addMatch_Btn.click();
    }

    @Step("Clicked Remove Match Button")
    public void clickRemoveMatchButton()
    {
        removeMatch_Btn.click();
    }

    @Step("Clicked Add All Match Button")
    public void clickAdd_AllMatchButton()
    {
        addAllMatch_Btn.click();
    }

    @Step("Clicked Remove All Match Button")
    public void clickRemove_AllMatchButton()
    {
        removeAllMatch_Btn.click();
    }

    @Step("Clicked Add Append Button")
    public void clickAddAppendButton()
    {
        addAppend_Btn.click();
    }

    @Step("Clicked Remove Append Button")
    public void clickRemoveAppendButton()
    {
        removeAppend_Btn.click();
    }

    @Step("Clicked Add All Append Button")
    public void clickAdd_AllAppendButton()
    {
        addAllAppend_Btn.click();
    }

    @Step("Clicked Remove All Append Button")
    public void clickRemove_AllAppendButton()
    {
        removeAllAppend_Btn.click();
    }

    @Step("Get Page Title")
    public String getPageTitle()
    {
        return driver.findElement(By.xpath(".//*[@class='fusion-h3Title']")).getText();
    }

    @Step("Get The Error Msg")
    public String getErrorMessage()
    {
        return driver.findElement(By.xpath(".//div[@class='errMsg']/span")).getText();
    }
    public void selectMasterFieldFromSelected(int index)
    {
        driver.findElement(By.xpath(".//*[@id='selectedContent1']/div[" + index + "]")).click();
    }

    public void selectMatchFieldFromSelected(int index)
    {
        driver.findElement(By.xpath(".//*[@id='selectedContent2']/div[" + index + "]")).click();
    }

    public void selectMasterField(String table, String field)
    {
        WebElement element = driver
                .findElement(By.xpath("(.//*[contains(text(),'" + table + "')]/following-sibling::ul/li/a[@title='" + field + "'])[1]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
    }

    public void selectAppendField(String table, String field)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            WebElement element = driver
                    .findElement(By.xpath("(.//*[contains(text(),'" + table + "')]/following-sibling::ul/li/a[@title='" + field + "'])[2]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            WebElement element = driver
                    .findElement(By.xpath("(.//*[contains(text(),'" + table + "')]/following-sibling::ul/li/a[@title='" + field + "'])[1]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
        }
    }

    public void selectMatchField(String table, String field)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            WebElement element = driver
                    .findElement(By.xpath("(.//*[contains(text(),'" + table + "')]/following-sibling::ul/li/a[@title='" + field + "'])[2]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        } catch (Exception e)
        {
            WebElement element = driver
                    .findElement(By.xpath("(.//*[contains(text(),'" + table + "')]/following-sibling::ul/li/a[@title='" + field + "'])[1]"));
            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
        }
    }

    public void selectAppendedFieldFromSelected(int index)
    {
        driver.findElement(By.xpath(".//*[@id='appendedFields']/div[2]/div[" + index + "]")).click();
    }

    @Step("Selected the Master Fields = \"{0}\" \"{1}\" \"{2}\"")
    public void selectMasterFields(String masterF1, String masterF2, String masterF3) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(masterF1))
        {
            String[] mas1F = masterF1.split(",");
            selectMasterField(mas1F[0], mas1F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
        if (!"NA".equalsIgnoreCase(masterF2))
        {
            String[] mas2F = masterF2.split(",");
            selectMasterField(mas2F[0], mas2F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
        if (!"NA".equalsIgnoreCase(masterF3))
        {
            String[] mas3F = masterF3.split(",");
            selectMasterField(mas3F[0], mas3F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
    }

    @Step("Selected the Match Fields = \"{0}\" \"{1}\" \"{2}\"")
    public void selectMatchFields(String matchF1, String matchF2, String matchF3) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(matchF1))
        {
            String[] mat1F = matchF1.split(",");
            selectMatchField(mat1F[0], mat1F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
        if (!"NA".equalsIgnoreCase(matchF2))
        {
            String[] mat2F = matchF2.split(",");
            selectMatchField(mat2F[0], mat2F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
        if (!"NA".equalsIgnoreCase(matchF3))
        {
            String[] mat3F = matchF3.split(",");
            selectMatchField(mat3F[0], mat3F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
    }
    @Step("Selected the Master Fields = \"{0}\" \"{1}\" \"{2}\"")
    public void selectMoreThanThreeMasterFields(String masterF1, String masterF2, String masterF3,String masterF4) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(masterF1))
        {
            String[] mas1F = masterF1.split(",");
            selectMasterField(mas1F[0], mas1F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
        if (!"NA".equalsIgnoreCase(masterF2))
        {
            String[] mas2F = masterF2.split(",");
            selectMasterField(mas2F[0], mas2F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
        if (!"NA".equalsIgnoreCase(masterF3))
        {
            String[] mas3F = masterF3.split(",");
            selectMasterField(mas3F[0], mas3F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
        if (!"NA".equalsIgnoreCase(masterF4))
        {
            String[] mas4F = masterF4.split(",");
            selectMasterField(mas4F[0], mas4F[1]);
            // Thread.sleep(2500);
            clickAddMasterButton();
        }
    }

    @Step("Selected the Match Fields = \"{0}\" \"{1}\" \"{2}\"{3}\"")
    public void selectMoreThanThreeMatchFields(String matchF1, String matchF2, String matchF3,String matchF4) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(matchF1))
        {
            String[] mat1F = matchF1.split(",");
            selectMatchField(mat1F[0], mat1F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
        if (!"NA".equalsIgnoreCase(matchF2))
        {
            String[] mat2F = matchF2.split(",");
            selectMatchField(mat2F[0], mat2F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
        if (!"NA".equalsIgnoreCase(matchF3))
        {
            String[] mat3F = matchF3.split(",");
            selectMatchField(mat3F[0], mat3F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
        if (!"NA".equalsIgnoreCase(matchF4))
        {
            String[] mat4F = matchF4.split(",");
            selectMatchField(mat4F[0], mat4F[1]);
            // Thread.sleep(2500);
            clickAddMatchButton();
        }
    }

    public void selectAppendedFields(String appendedF1, String appendedF2, String appendedF3)
    {
        if (!"NA".equalsIgnoreCase(appendedF1))
        {
            String[] app1F = appendedF1.split(",");
            selectAppendField(app1F[0], app1F[1]);
            clickAddAppendButton();
        }
        if (!"NA".equalsIgnoreCase(appendedF2))
        {
            String[] app2F = appendedF2.split(",");
            selectAppendField(app2F[0], app2F[1]);
            clickAddAppendButton();
        }
        if (!"NA".equalsIgnoreCase(appendedF3))
        {
            String[] app3F = appendedF3.split(",");
            selectAppendField(app3F[0], app3F[1]);
            clickAddAppendButton();
        }
    }
    @Step ("Fetch The Count Of Selected Left Fields")
    public Integer getTheCountSelectedLeftFields() throws InterruptedException
    {

        List<WebElement> selectedLeftFieldList= driver.findElements(By.xpath("//div[@id='selectedContent1']"));
        int countOfSelectedRightField=selectedLeftFieldList.size();

        return countOfSelectedRightField;
    }
    @Step ("Fetch The Count Of Selected Right Fields")
    public Integer getTheCountSelectedRightFields() throws InterruptedException
    {

        List<WebElement> selectedRightFieldList= driver.findElements(By.xpath("//div[@id='selectedContent2']"));
        int countOfSelectedRightField=selectedRightFieldList.size();
        return countOfSelectedRightField;
    }
    @Step ("Fetch The Count Of Selected Appended Fields")
    public Integer getTheCountSelectedAppendedFields() throws InterruptedException
    {

        List<WebElement> selectedAppendedFieldList= driver.findElements(By.xpath("//div[@iclass='contentappendedFields']"));
        int countOfSelectedAppendedField=selectedAppendedFieldList.size();
        return countOfSelectedAppendedField;
    }//div[@class='contentappendedFields']/div/ul
    @Step ("Fetch The Selected Appended Fields")
    public List<String> getSelectedAppendedFields() throws InterruptedException
    {


        List<String> selectedAppendedfields=new ArrayList<String>();

        List<WebElement> eleList= driver.findElements(By.xpath("//div[@class='contentappendedFields']//ul"));

        for(WebElement ele:eleList)
        {
            selectedAppendedfields.add(ele.getAttribute("title"));
        }

        return selectedAppendedfields;


    }
    @Step ("Select the appended Fields")
    public void selectAppendedField(String fields) throws InterruptedException
    {
        String[] fieldArr=fields.split(",");
        List<String> appFieldList=Arrays.asList(fieldArr);
        for(String appField:appFieldList)
        {
            String[] arr=appField.split(";");
            /* String[] arr=appField.split(";");
            String dynPath = "//div[@class='content2']//a[contains(text(),'"+arr[0]+"')]//following::a[contains(text(),'"+arr[1]+"')][1]";
            driver.findElement(By.xpath(dynPath)).click();
            Thread.sleep(5000);
            driver.findElement(By.xpath(dynPath)).click();
            Thread.sleep(5000);
            driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);
            clickAddAppendButton();
            driver.manage().timeouts().implicitlyWait(4000, TimeUnit.SECONDS);*/
            try
            {
                driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                WebElement element = driver
                        .findElement(By.xpath("//div[@class='content2']//a[contains(text(),'"+arr[0]+"')]//following::a[contains(text(),'"+arr[1]+"')]"));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", element);
                driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            } catch (Exception e)
            {
                // TODO Auto-generated catch block
                WebElement element = driver
                        .findElement(By.xpath("//div[@class='content2']//a[contains(text(),'"+arr[0]+"')]//following::a[contains(text(),'"+arr[1]+"')]"));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", element);
            }
            clickAddAppendButton();

        }

    }

    public List<String> fetchProvidedAppendedField(String fields)
    {
        String[] fieldArr=fields.split(",");
        List<String> appFieldList=Arrays.asList(fieldArr);
        List<String> newList=new ArrayList<String>();
        for(int j=0; j < appFieldList.size(); j++)
        {
            String[] newArr=  appFieldList.get(j).split(";");
            newList.add(newArr[1]);

        }
        return newList;
    }


}
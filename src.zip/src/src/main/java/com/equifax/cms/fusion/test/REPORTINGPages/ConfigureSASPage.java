package com.equifax.cms.fusion.test.REPORTINGPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class ConfigureSASPage
{
    WebDriver driver;

    public ConfigureSASPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(id = "name")
    public WebElement processName_Field;

    @FindBy(id = "sasProgram")
    WebElement sasProgramFile_Field;

    @FindBy(xpath = "//input[@name='submitButton']")
    WebElement continue_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @Step("Provided the Process Name = \"{0}\"")
    public void inputProcessName(String name)
    {
        processName_Field.sendKeys(name);
    }

    @Step("Provided the SAS program File = \"{0}\"")
    public void inputSASProgramFile(String location)
    {
        sasProgramFile_Field.sendKeys(location);
    }

    @Step("Click Continue Button")
    public void clickContinueBtn()
    {
        continue_Btn.click();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.xpath("//div[@class='errMsg copyErrMsg']/span")).getText();
    }

    public String getErrorDivStyle()
    {
        return driver.findElement(By.xpath("//div[@class='errMsg copyErrMsg']")).getAttribute("style");
    }
}

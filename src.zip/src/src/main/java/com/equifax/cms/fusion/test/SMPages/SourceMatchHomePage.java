package com.equifax.cms.fusion.test.SMPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class SourceMatchHomePage {

    WebDriver driver;

    public SourceMatchHomePage(WebDriver driver){

        this.driver = driver;
        PageFactory.initElements(driver, this);
        driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);

    }

    @FindBy(linkText = "New Source Match")
    WebElement SourceMatchButton;

    @Step("Click Source Match Button")
    public void ClickSourceMatchButton(){
        SourceMatchButton.click();
    }

    @Step("Get Status of the Source Match Process")
    public String GetStatusSM(String procId)
    {
        String status = driver.findElement(By.xpath("//div[contains(text(),'"+procId+"')]//following::div[2]")).getText();
        return status;
    }

    public String getStatusIP_1()
    {
        String status = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[4]")).getText();
        return status;
    }

    public void duplicateProcess()
    {
        driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle"))) {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath("//div[@id='sb-wrapper-inner']/div[1]/div[1]/div[1]/div[2]/a[1]")).click();
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Get SM Process ID ")
    public String getSMprocessId(String procName)
    {
        String[] pName = driver.findElement(By.xpath("(//td[contains(text(),'"+procName+"')])[1]")).getText().split(":");
        System.out.println("Generated Process ID :"+pName[0].trim());
        return pName[0].trim();
    }
    public String getTheFilePathOfInput()
    {
        String filePath= driver.findElement(By.xpath("//label[starts-with(text(),'File Name:')]/following::span[1]")).getText();
        return filePath;
    }

}

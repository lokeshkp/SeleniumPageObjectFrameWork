package com.equifax.cms.fusion.test.DNSPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class DNSSummaryPage
{
    WebDriver driver;

    public DNSSummaryPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement backButton;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement submitButton;

    @FindBy(xpath = ".//*[@id='dnsForm']/label[2]")
    WebElement recordTypeDetails;

    @FindBy(xpath = ".//*[@id='smDataTable']/tbody/tr/td[3]/table")
    WebElement dnsSummFitlerGroup;

    @Step("Checked are Fitler Groups displayed in Summary")
    public boolean isSummFilterGrpVisible()
    {
        return dnsSummFitlerGroup.isDisplayed();
    }

    @Step("Checked Record Types Selected for Processing displayed in Summary")
    public String getRecordTypeElementText()
    {
        return recordTypeDetails.getText();
    }

    @Step("Clicked Back Button")
    public void clickBackButton()
    {
        backButton.click();
    }

    @Step("Clicked Submit Button")
    public void clickSubmitButton()
    {
        submitButton.click();
    }

    @Step("Fetched Process Name Displayed on Summary Screen")
    public String getProcessNameDsiplayed()
    {
        return driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[1]")).getText();
    }

    @Step("Fetched Data Displayed on Summary Screen")
    public String getDataDsiplayed()
    {
        return driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[3]")).getText();
    }

    @Step("Fetched Output Table Name Displayed on Summary Screen")
    public String getOutputTableNameDisplayed()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Output Table Name')]/following::table/tbody/tr/td[2]")).getText();
    }

    @Step("Fetched Records type to Process Displayed on Summary Screen")
    public String getRecTypeToInclude()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Records Types to include')]/following-sibling::text())[1]")).getText();
    }
}

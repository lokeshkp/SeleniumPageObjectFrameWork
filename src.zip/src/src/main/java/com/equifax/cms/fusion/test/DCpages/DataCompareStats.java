package com.equifax.cms.fusion.test.DCpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

public class DataCompareStats
{
    WebDriver driver;
    public Select selType;

    public DataCompareStats(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    public boolean isPARAM_FILE_Displayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
            driver.findElement(By.linkText("PARAM_FILE")).getText();
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public void clickPARAM()
    {
        driver.findElement(By.linkText("PARAM_FILE")).click();
    }

    public void clickAdvanceDataCompareReport()
    {
        driver.findElement(By.linkText("Advanced Data Compare Report")).click();
    }

    public String getPARAMText()
    {
        return driver.findElement(By.xpath(".//*[@class='cmsContent']/pre/div")).getText();
    }

    public String getDCReportContent()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Data Compare Report Content')]")).getText();
    }

    public String getAdvDCCompRptPresent()
    {
        return driver.findElement(By.linkText("Advanced Data Compare Report")).getText();
    }

    public String getADCRHeader()
    {
        return driver.findElement(By.xpath("(.//*[@class='c systemtitle'])[1]")).getText();
    }

    public String getCompareProText()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'The COMPARE Procedure')])[1]")).getText();
    }

    public boolean isCompResforObsPresent()
    {
        return !driver.findElements(By.xpath(".//*[contains(text(),'Comparison Results for Observations')]")).isEmpty();
    }

    public boolean isVariablesSummDisplayed()
    {
        return !driver.findElements(By.xpath(".//*[contains(text(),'Variables Summary')]")).isEmpty();
    }

    public String getObservationSummary()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Observation Summary')])[1]")).getText();
    }

    public String getCompareProcedure()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'The COMPARE Procedure')])[1]")).getText();
    }

    public String getListingVariables()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Diff Greenplum Compare TEST')]/following::div[3])[1]/div/table/tbody/tr/td/pre"))
                .getText();
    }

    public String getObeservationSummary1()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Observation Summary')]")).getText();
    }
}

package com.equifax.cms.fusion.test.STPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class StackingPage
{
    WebDriver driver;

    public StackingPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Stack")
    WebElement jobStackingButton;

    @FindBy(xpath = ".//*[@id='contentArea']/div[4]/ul/li/div[2]/a")
    WebElement newStackProcess_Btn;

    public void clickNewStackProcess_Btn()
    {
        newStackProcess_Btn.click();

    }

    @Step("Clicked Job Stacking Button")
    public void clickJobStackingButton()
    {
        jobStackingButton.click();

    }

    public String getStackId()
    {
        String id = driver.findElement(By.xpath("//label[@class='fieldTitle']")).getText();
        return id.split(" ")[2];

    }
}
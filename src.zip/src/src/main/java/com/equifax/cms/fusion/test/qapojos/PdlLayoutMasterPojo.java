package com.equifax.cms.fusion.test.qapojos;

public class PdlLayoutMasterPojo
{
    private String pdlPurpose;

    private Integer ordinalPosition;
    private String fieldName;
    private String fieldType;
    private Integer startPos;
    private Integer endPos;
    private String stepFlag;
    private Integer fieldPosition;
    private Integer length;

    public enum PDL_PURPOSE
    {
        HEADER, RF_HHD_DROP, RF_HHD_SPLIT, CDP_OMF_ACCEL, INQUIRY_POSTING, AUDIT_SAMPLE_INDEX, CDP_BOA_HOUSEHOLD_TAG, RF_DEDUPCUST, MASTER_JOIN, RF_SUPP_ROLLING, DNS_FILTER, RANDOM_NTH, RF_NHHD, RLS_ROLLING_LIST, CDP_TEST, INQUIRYPOST, PRESELECT, CDP_ECM_PAYMENT, CDP_OMF, RF_DEDUPCID, SOURCEAPPEND, MODEL, RF_SUPP_CID, RF_SUPP_SSN, SCORE, DM_STEP_FLAG, FILTER, RF_CE, CDP_ECM_NRA, RF_HHD_CUSTOM_CITI, FACTACT, REFORMATINI, RF_DEDUPSSN, RF_SUPP_CUST
    }

    public String getPdlPurpose()
    {
        return pdlPurpose;
    }

    public void setPdlPurpose(String pdlPurpose)
    {
        this.pdlPurpose = pdlPurpose;
    }

    public Integer getOrdinalPosition()
    {
        return ordinalPosition;
    }

    public void setOrdinalPosition(Integer ordinalPosition)
    {
        this.ordinalPosition = ordinalPosition;
    }

    public String getFieldName()
    {
        return fieldName;
    }

    public void setFieldName(String fieldName)
    {
        this.fieldName = fieldName;
    }

    public String getFieldType()
    {
        return fieldType;
    }

    public void setFieldType(String fieldType)
    {
        this.fieldType = fieldType;
    }

    public Integer getStartPos()
    {
        return startPos;
    }

    public void setStartPos(Integer startPos)
    {
        this.startPos = startPos;
    }

    public Integer getEndPos()
    {
        return endPos;
    }

    public void setEndPos(Integer endPos)
    {
        this.endPos = endPos;
    }

    public String getStepFlag()
    {
        return stepFlag;
    }

    public void setStepFlag(String stepFlag)
    {
        this.stepFlag = stepFlag;
    }

    public Integer getFieldPosition()
    {
        return fieldPosition;
    }

    public void setFieldPosition(Integer fieldPosition)
    {
        this.fieldPosition = fieldPosition;
    }

    public Integer getLength()
    {
        return length;
    }

    public void setLength(Integer length)
    {
        this.length = length;
    }

}

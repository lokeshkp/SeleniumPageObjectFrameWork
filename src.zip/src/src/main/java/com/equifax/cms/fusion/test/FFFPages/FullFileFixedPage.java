package com.equifax.cms.fusion.test.FFFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class FullFileFixedPage
{
    WebDriver driver;

    public FullFileFixedPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "name")
    public WebElement fffProcessName_Field;

    @FindBy(id = "creditInput")
    WebElement creditInput_DD;

    @FindBy(id = "fromProcessId")
    WebElement process_DD;

    @FindBy(id = "itemTableId")
    WebElement data_DD;

    @FindBy(id = "configFilePath")
    public WebElement configFileLocatn_Field;

    @FindBy(id = "allRecordsAccRej")
    public WebElement AllRecRegardlessOfType_CB;

    @FindBy(id = "acceptCodeChkbx_0")
    WebElement Ele_Accepts;

    @FindBy(xpath = ".//*[@id='fffForm']/div/div[7]/a")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@id='fffForm']/div/div[7]/input[1]")
    WebElement save_Btn;

    @FindBy(xpath = ".//*[@id='fffForm']/div/div[7]/input[2]")
    WebElement submit_Btn;

    @FindBy(id = "textMsg")
    WebElement errorMsg;

    @FindBy(xpath = ".//*[@id='contentArea']/h2")
    WebElement fffPageHeader;

    @FindBy(xpath = "(.//*[@selected='selected'])[1]")
    public WebElement creditInputSelected;

    @FindBy(id = "jobId")
    WebElement jobId;

    public String isConfigFileLocPresent()
    {
        return configFileLocatn_Field.getAttribute("type");
    }

    @Step("Fetched The JobId From FFF Configuration Page")
    public String jobIdForTheSelectedProcess()
    {
        String jobId = driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText();
        return jobId;
    }

    @Step("Fetched Process Name From FFF Summary")
    public String processName()
    {
        String ProcessName = driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[1]")).getText();
        return ProcessName;
    }

    @Step("Fetched Job Number From FFF Summary")
    public String jobNumber()
    {
        String jobNumber = driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[2]")).getText();
        return jobNumber;
    }

    @Step("Fetched Data From FFF Summary")
    public String data()
    {
        String data = driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[3]")).getText();
        return data;
    }

    @Step("Fetched RecordCount From FFF Summary")
    public String Count()
    {
        // String count = driver.findElement(By.xpath(".//*[@id='smDataTable']/tbody/tr/td[4]")).getText();
        String count = driver.findElement(By.xpath("//div[contains(text(),'The count of FFF records')]/following::div[1]")).getText();
        return count;
    }

    @Step("Fetched RecordCount From Process stats which is selected as Input to FFF")
    // here fetching total no of records DM Header table from the DM stats.
    public String getTheRecordCountOfTheProcessAsInputToFFF(String data)
    {
        String recordcount = driver.findElement(By.xpath("//div[contains(text(),'" + data + "')]/parent::div/following::div[3]")).getText();// this
                                                                                                                                            // works
                                                                                                                                            // only
                                                                                                                                            // for
                                                                                                                                            // datamenu
                                                                                                                                            // stats
        return recordcount;
    }

    @Step("Fetched CreditInput From FFF Summary")
    public String fetchCreditInputFromSummaryOfFFFProcess()
    {

        String fetchedCreditInput = driver.findElement(By.xpath("//label[contains(text(),'Credit Input')]//following::td[1]")).getText();
        System.out.println(fetchedCreditInput);

        return fetchedCreditInput;
    }

    @Step("Fetched ConfigFilePath From FFF Summary")
    public String fetchConfigFilePathFromSummaryOfFFFProcess()
    {

        String fetchedConfigFilePath = driver.findElement(By.xpath("//label[contains(text(),'Config File Path')]//following::td[1]")).getText();
        System.out.println(fetchedConfigFilePath);

        return fetchedConfigFilePath;
    }

    @Step("Fetched RecordTypes From FFF Summary")
    public String getRecordTypes(String allRecords)
    {
        String recordTypesInCaseOfAllRecords = null;
        if ("ON".equalsIgnoreCase(allRecords))
        {
            recordTypesInCaseOfAllRecords = driver.findElement(By.xpath("//label[contains(text(),'Records Types to include')]//following::td[1]/li"))
                    .getText();
            System.out.println(recordTypesInCaseOfAllRecords);
        }
        return recordTypesInCaseOfAllRecords;
    }

    @Step("Fetched Page Header")
    public String getFFFPageHeader()
    {
        return fffPageHeader.getText();
    }
    @Step("Generated Final Process Name")
    public String getFinalProcessName()
    {
        String[] pName = driver.findElement(By.xpath("//form[@id='fffForm']//label[1]")).getText().split(":");
        System.out.println("Generated Process ID :" + pName[1].trim());
        return pName[1].trim();
    }


    @Step("Provided FFF Process Name as : {0}")
    public void inputProcessName(String processName)
    {
        fffProcessName_Field.clear();
        fffProcessName_Field.sendKeys(processName);
    }

    @Step("Selected Credit Input DataSet as : {0}")
    public void selectCreditInput(String creditInput)
    {
        Select select = new Select(creditInput_DD);
        select.selectByVisibleText(creditInput);
    }

    @Step("Selected Input Process as : {0}")
    public void selectProcess(String process)
    {
        Select select = new Select(process_DD);
        select.selectByVisibleText(process);
    }

    @Step("Select Data as : {0}")
    public void selectData(String data) throws InterruptedException
    {
        Thread.sleep(10000);
        Select select = new Select(data_DD);
        select.selectByVisibleText(data);
    }

    @Step("Cleared Configuration Field")
    public void clearConfigLoctn()
    {
        configFileLocatn_Field.clear();
    }

    @Step("Provided Configuration Field as : {0}")
    public void inputConfigLoctn(String configLoc)
    {
        configFileLocatn_Field.clear();
        configFileLocatn_Field.sendKeys(configLoc);
    }

    @Step("Check all Records checkbox")
    public void checkAllRecordsCheckBox()
    {
        if (!AllRecRegardlessOfType_CB.isSelected())
        {
            AllRecRegardlessOfType_CB.click();
        }
    }

    @Step("Uncheck all Records checkbox")
    public void unCheckAllRecordsCheckBox()
    {
        if (AllRecRegardlessOfType_CB.isSelected())
        {
            AllRecRegardlessOfType_CB.click();
        }
    }

    @Step("Check Accepts checkbox")
    public void checkAcceptsCheckBox()
    {
        if (!Ele_Accepts.isSelected())
        {
            Ele_Accepts.click();
        }
    }

    @Step("Uncheck Accepts checkbox")
    public void unCheckAcceptsCheckBox()
    {
        if (Ele_Accepts.isSelected())
        {
            Ele_Accepts.click();
        }
    }

    @Step("Clicked Back Button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Clicked Save Button")
    public void clickSaveButton()
    {
        save_Btn.click();
    }

    @Step("Clicked Submit Button")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    @Step("Fetched Error Message")
    public String getErrorMessage()
    {
        return errorMsg.getText();
    }

    @Step("Selected all Records checkbox")
    public void selectAllRecordsCheckBox()
    {
        AllRecRegardlessOfType_CB.click();
    }

    @Step("Selected Accepts checkbox")
    public void selectAcceptsCheckBox()
    {
        Ele_Accepts.click();
    }

    public String getJobId()
    {
        return jobId.getText();
    }

    public void selectRecordTypes(String process, String allRecords, String accepts, String rejects)
    {

        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");

        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                selectAllRecordsCheckBox();

            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                    selectAcceptsCheckBox();

                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    selectRecordsReject(rejects);

                }
            }
        }
    }

    public void selectRecordsReject(String chItems)
    {
        if ("ALL".equalsIgnoreCase(chItems))
        {

            driver.findElement(By.id("checkAll")).click();
        } else
        {
            String delimiter = ",";
            StringTokenizer eachChkBoxText = new StringTokenizer(chItems, delimiter);
            while (eachChkBoxText.hasMoreTokens())
            {
                String dynamicId = getRecTypeChckBoxId(eachChkBoxText.nextToken());
                System.out.println("DYNAMIC_ID : " + dynamicId);
                WebElement checkBox = driver.findElement(By.id(dynamicId));
                if (!checkBox.isSelected())
                {
                    checkBox.click();
                }
            }
        }
    }

    private enum RECORDREJECT
    {
        NH, nh, FR, fr, NP, np, PS, ps, RJ, rj, RP, rp, ID, id, IP, ip, CE, ce, RD, rd, DP, dp, HS, hs, ND, nd, DB, db, CT, ct, DD, dd, SR, sr, NA, na, SN, sn, NX, nx, RS, rs, DS, ds, DN, dn
    }

    public static String getRecTypeChckBoxId(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "rejectCodeChkbx_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "rejectCodeChkbx_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "rejectCodeChkbx_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "rejectCodeChkbx_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "rejectCodeChkbx_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "rejectCodeChkbx_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "rejectCodeChkbx_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "rejectCodeChkbx_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "rejectCodeChkbx_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "rejectCodeChkbx_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "rejectCodeChkbx_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "rejectCodeChkbx_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "rejectCodeChkbx_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "rejectCodeChkbx_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "rejectCodeChkbx_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "rejectCodeChkbx_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "rejectCodeChkbx_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "rejectCodeChkbx_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "rejectCodeChkbx_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "rejectCodeChkbx_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "rejectCodeChkbx_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "rejectCodeChkbx_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "rejectCodeChkbx_22";
            break;

        }
        return dynamicCheckBoxId;
    }

    @Step("Validate whether groups are present or not")
    // Fetching for single file
    public String isGroupPresent()
    {

        String is_groups_present = driver.findElement(By.xpath(".//*[@id='groupsDiv']")).getCssValue("display");

        return is_groups_present;
    }

    @Step("Validating whether job field has value or not for ready state process as input")
    // Fetching for single file
    public String isJobfieldHasValue()
    {

        String jobfieldValue = driver.findElement(By.xpath("//span[@id='jobId']/label")).getText();

        return jobfieldValue;
    }

    @Step("Validating whether three types of groups displayed or not")
    // Fetching for single file
    public List<String> isGroupDisplayed(String groups)
    {
        List<String> groupNameList = new ArrayList<String>();
        String comma = ",";
        StringTokenizer stMain = new StringTokenizer(groups, comma);
        while (stMain.hasMoreElements())
        {
            String getGroupName = driver.findElement(
                    By.xpath("(//div[@class='groupNamesDiv']/input[@value='" + stMain.nextToken() + "']/preceding::input[1])[2]")).getAttribute(
                    "value");
            groupNameList.add(getGroupName);
        }

        return groupNameList;
    }

    @Step("Fetch the Error Message")
    // Fetching for single file
    public String FetchErrorMessage()
    {
        String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
        return errMsg;
    }

}
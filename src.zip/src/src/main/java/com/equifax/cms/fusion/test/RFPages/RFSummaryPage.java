package com.equifax.cms.fusion.test.RFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class RFSummaryPage
{

    public WebDriver driver;

    public RFSummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@name='submitButton']")
    WebElement SubmitButton;

    @FindBy(xpath = "//a[contains(text(),'Household')]")
    WebElement HouseHoldLink;

    @FindBy(xpath = "//a[contains(text(),'Customer Elimination')]")
    WebElement CElink;

    @FindBy(xpath = "//a[contains(text(),'Suppression')]")
    WebElement SuppLink;

    @Step("Clicked Submit button in Refinement Summary Page")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }

    @Step("Clicked on Household link")
    public void clickHouseHoldLink()
    {
        HouseHoldLink.click();
    }

    @Step("Clicked on Customer Elimination link")
    public void clickCElink()
    {
        CElink.click();
    }

    @Step("Clicked on Suppression link")
    public void clickSuppLink()
    {
        SuppLink.click();
    }

    @Step("Fetch Process Name From the Summary")
    public String fetchProcessNameFromSummary()
    {

        String processName = driver.findElement(By.xpath("//table[@id='inputSummaryTableSplit']/tbody/tr[1]/td[1]")).getText();
        return processName;
    }

    @Step("Fetch Job From the Summary")
    public String fetchJobFromSummary()
    {

        String job = driver.findElement(By.xpath("//table[@id='inputSummaryTableSplit']/tbody/tr[1]/td[2]")).getText();
        return job;
    }

    @Step("Fetch Data From the Summary")
    public String fetchDataFromSummary()
    {

        String data = driver.findElement(By.xpath("//table[@id='inputSummaryTableSplit']/tbody/tr[1]/td[3]")).getText();
        return data;
    }



    //*******Fetching the Details From The Summary When Negative Household Drop Is selected**********//

    @Step("Fetch Selected Key Configuration From the Summary For Negative Household Drop ")
    public String fetchSelectedKeyConfigurationFromRFNSummaryForNHHDOption()
    {
        return driver.findElement(By.xpath("//a[contains(text(),'Household')]//following::label[1]")).getText();
    }

    @Step("Fetch Selected Key Field From the Summary For Negative Household Drop ")
    public String fetchSelectedKeyFieldFromRFNSummaryForNHHDOption()
    {
        return driver.findElement(By.xpath("//a[contains(text(),'Household')]//following::table[@id='procSummaryTable']/tbody//ul/span")).getText();
    }
    @Step("Fetch Selected Priority Field From the Summary For Negative Household Drop ")
    public String fetchSelectedPriorityFieldFromRFNSummaryForNHHDOption()
    {
        String priorityField=driver.findElement(By.xpath("//a[contains(text(),'Household')]//following::table[@id='procSummaryTable'][2]//td")).getText();
        String[] strArr=priorityField.split(":");
        return strArr[0]+":"+strArr[1]+"."+strArr[2];
    }

    @Step("Fetch Selected Priority Field From the Summary For Negative Household Drop ")
    public String fetchSelectedPriorityFromRFNSummaryForNHHDOption()
    {
        String priorityField= driver.findElement(By.xpath(" //a[contains(text(),'Household')]//following::div/li")).getText();
        String lastWord = priorityField.substring(priorityField.lastIndexOf(" ")+1);
        return lastWord.toUpperCase();
    }
    @Step("Fetch Records Types to include From the Summary For Negative Household Drop ")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForNHHDOption()
    {
        String recordTypesToInclude = null;
        boolean nhhdOptionVisible = driver.findElement(By.xpath("//label[text()='Negative Household Drop']")).isDisplayed();
        if (nhhdOptionVisible)
        {
            recordTypesToInclude = driver
                    .findElement(
                            By.xpath("//label[text()='Negative Household Drop'][1]/ancestor::tr/following-sibling::tr//label[starts-with(text(),'Records Types to include')]/following::li[1]"))
                            .getText();
        }
        return recordTypesToInclude;
    }
    @Step("Fetch Records Status From the Summary For Negative Household Drop")
    public String fetchRecordStatusFromRFNSummaryForNHHDOption()
    {
        String recordStatus = null;
        boolean nhhdOptionVisible = driver.findElement(By.xpath("//label[text()='Negative Household Drop']")).isDisplayed();
        if (nhhdOptionVisible)
        {

            recordStatus = driver
                    .findElement(
                            By.xpath("//label[text()='Negative Household Drop']/ancestor::tr/following-sibling::tr//label[starts-with(text(),'Reject Status')]/following::td[1]"))
                            .getText();
        }
        return recordStatus;
    }
    @Step("Fetch NHHD Options From the Summary For Negative Household Drop")
    public List<String> fetchNHHDOptionsFromRFNSummaryForNHHDOption()
    {
        List<String> nhhdOptions = new ArrayList<String>();

        List<WebElement> list = driver.findElements(By
                .xpath("//label[text()='Negative Household Drop']/ancestor::tr/following-sibling::tr//table[@id='newLayoutTable']/tbody/tr/td"));
        for (int i = 0; i < list.size(); i++)
        {
            String fetchDetails = list.get(i).getText();
            nhhdOptions.add(fetchDetails);
        }
        return nhhdOptions;
    }

    //*******Fetching the Details From The Summary When Household Split Is selected*******//
    @Step("Fetch Records Types to include From the Summary For Household Split")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForHHSOption()
    {
        String recordTypesToInclude = null;
        boolean hhsOptionVisible = driver.findElement(By.xpath("//label[text()='Household Split']")).isDisplayed();
        if (hhsOptionVisible)
        {
            recordTypesToInclude = driver
                    .findElement(
                            By.xpath("//label[text()='Household Split'][1]/parent::td/parent::tr/following-sibling::tr//label[starts-with(text(),'Records Types to include')]/following::li[1]"))
                            .getText();
        }
        return recordTypesToInclude;
    }

    public String fetchRecordStatusFromRFNSummaryForHHSOption()
    {
        String recordStatus = null;
        boolean hhsOptionVisible = driver.findElement(By.xpath("//label[text()='Household Split']")).isDisplayed();
        if (hhsOptionVisible)
        {

            recordStatus = driver
                    .findElement(
                            By.xpath("//label[text()='Household Split']/ancestor::tr/following-sibling::tr//label[starts-with(text(),'Reject Status')]/following::td[1]"))
                            .getText();
        }
        return recordStatus;
    }
    //*******Fetching the Details From The Summary When Customer Elimination Is selected*********//
    @Step("Fetch Input From the Summary For Customer Elimination")
    public String fetchInputFromRFNSummaryForCEOption()
    {



        String input = driver.findElement(
                By.xpath("//a[contains(text(),'Customer Elimination')]/following::label[text()='Input:'][1]/following::td[1]"))
                .getText();


        return input;
    }

    @Step("Fetch Records Types to include From the Summary For Customer Elimination")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForCEOption()
    {



        String recordTypesToInclude  = driver
                .findElement(
                        By.xpath("//a[contains(text(),'Customer Elimination')]/following::label[text()='Records Types to include:'][1]/following::li[1]")).getText();

        return recordTypesToInclude;
    }
    @Step("Fetch Records Status From the Summary For Customer Elimination")
    public String fetchRecordStatusFromRFNSummaryForCEOption()
    {


        String recordStatus =driver.findElement(
                By.xpath("//a[contains(text(),'Customer Elimination')]/following::label[text()='Reject Status:'][1]/following::td[1]"))
                .getText();

        return recordStatus;
    }
    //In the below two method fetching the processName and data from the CE data table from the refinement summary
    public String fetchProcessNameFromCEDataRFNSummary()
    {
        String processNameFromCEData = driver.findElement(
                By.xpath("//a[contains(text(),'Customer Elimination')]//following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[1]"))
                .getText();


        String procNameForCE = processNameFromCEData.replaceAll("\\s+","");



        return procNameForCE;
    }

    public String fetchDataFromCEDataRFNSummary()
    {

        String dataFromCEData = driver.findElement(
                By.xpath("//a[contains(text(),'Customer Elimination')]//following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[3]"))
                .getText();

        return dataFromCEData;
    }
    //*******Fetching the Details From The Summary When Suppression Is selected*********//
    //div[contains(text(),'Suppression')]/parent::div//label[contains(text(),'Input')]
    @Step("Fetch Input From the Summary For Suppression")
    public String fetchInputFromRFNSummaryForSuppressionOption()
    {
        String input = null;

        input = driver.findElement(
                By.xpath("//a[contains(text(),'Suppression')]/following::label[text()='Input:'][1]/following::td[1]"))
                .getText();


        return input;
    }
    @Step("Fetch Type From the Summary For Suppression")
    public String fetchSuppressionTypeFromRFNSummaryForSuppressionOption()
    {
        String type= driver.findElement(By.xpath("//a[contains(text(),'Suppression')]/following::label[text()='Type:'][1]/following::td[1]")).getText();

        return type;
    }
    @Step("Fetch Records Types to include From the Summary For Suppression")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForSuppressionOption()
    {
        String recordTypesToInclude = null;

        recordTypesToInclude = driver
                .findElement(
                        By.xpath("//a[contains(text(),'Suppression')]/following::label[text()='Records Types to include:'][1]/following::li[1]"))
                        .getText();

        return recordTypesToInclude;
    }
    @Step("Fetch Records Status From the Summary For Suppression")
    public String fetchRecordStatusFromRFNSummaryForSuppressionOption()
    {


        String recordStatus = driver.findElement(By.xpath("//a[contains(text(),'Suppression')]/following::label[text()='Reject Status:'][1]/following::td[1]"))
                .getText();

        return recordStatus;
    }
    public String fetchProcessNameFromSuppressionDataRFNSummary()
    {
        String processNameFromSuppData = driver.findElement(
                By.xpath("//a[contains(text(),'Suppression')]/following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[1]"))
                .getText();
        /*String processNameFromSuppData = driver.findElement(
                By.xpath("//div[contains(text(),'Suppression')]/following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[1]"))
                .getText();*/
        String procNameForSuppFile=processNameFromSuppData.replaceAll("\\s+","");
        return procNameForSuppFile;
    }

    public String fetchDataFromSuppressionDataRFNSummary()
    {

        String dataFromSuppData = driver.findElement(
                By.xpath("//a[contains(text(),'Suppression')]/following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[3]"))
                .getText();

        /*        String dataFromSuppData = driver.findElement(
                By.xpath("//div[contains(text(),'Suppression')]/following::table[@id='inputSummaryTableSplit'][1]/tbody/tr[1]/td[3]"))
                .getText();*/
        return dataFromSuppData;
    }
    //*******Fetching the Details From The Summary When Rolling Suppression Type Selected In Suppression Screen*********//

    @Step("Fetch Supp Type From the Summary")
    public String fetchSuppFromRFNSummaryForRollingSuppOption()
    {

        String type = driver.findElement(By.xpath("//label[text()='Type:']/following::td[1]")).getText();
        return type;
    }
    @Step("Fetch Records Types to include From the Summary For Rolling Suppression")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForRollingSuppOption()
    {

        String recordTypesToInclude = driver.findElement(By.xpath("//label[text()='Records Types to include:']/following::td/li[1]")).getText();
        return recordTypesToInclude;
    }
    @Step("Fetch Records Status From the Summary For Suppression")
    public String fetchRecordStatusFromRFNSummaryForRollingSuppOption()
    {


        String recordStatus = driver.findElement(By.xpath("//label[text()='Reject Status:']/following::td[1]")).getText();

        return recordStatus;
    }
    @Step("Fetch Selected Rolling Supp Process From the Summary")
    public String fetchRollSuppProcessFromRFNSummaryForRollingSuppOption()
    {

        String rollSuppProcess = driver.findElement(By.xpath("//label[text()='Suppression Table:']/parent::td/parent::tr/following::tr[1]//tbody/tr[1]/td[1]")).getText();
        return rollSuppProcess;
    }
    @Step("Fetch Suppression Days From the Summary For Rolling Suppression")
    public String fetchSuppDaysFromRFNSummaryForRollingSuppOption()
    {

        String suppDays = driver.findElement(By.xpath("//label[contains(text(),'Suppression Days')]/following::td[1]")).getText();
        return suppDays;
    }

    //*******Fetching the Details From The Summary When Dedupe Is selected*********//

    @Step("Fetch Input From the Summary For Dedupe")
    public String fetchInputFromRFNSummaryForDedupeOption()
    {

        String input = driver.findElement(By.xpath("//a[contains(text(),'Dedupe')]/following::label[text()='Input:'][1]/following::td[1]")).getText();
        /*    input = driver.findElement(By.xpath("//a[contains(text(),'Dedupe')]/following::label[text()='Type:'][1]/following::td[1]")).getText();*/

        return input;
    }
    @Step("Fetch Type From the Summary For Dedupe")
    public String fetchDedupeTypeFromRFNSummaryForDedupeOption()
    {

        String type  = driver.findElement(
                By.xpath("//a[contains(text(),'Dedupe')]/following::label[text()='Type:'][1]/following::td[1]"))
                .getText();
        /*type = driver.findElement(
                    By.xpath("//div[contains(text(),'Dedupe')]/following::label[text()='Type:'][1]/following::td[1]"))
                    .getText();*/

        return type;
    }
    @Step("Fetch Records Types to include From the Summary For Dedupe")
    public String fetchRecordsTypeToIncludeFromRFNSummaryForDedupeOption()
    {
        String recordTypesToInclude = driver
                .findElement(
                        By.xpath("//a[contains(text(),'Dedupe')]/following::label[text()='Records Types to include:'][1]/following::li[1]")).getText();


        return recordTypesToInclude;
    }
    @Step("Fetch Records Status From the Summary For Dedupe")
    public String fetchRecordStatusFromRFNSummaryForDedupeOption()
    {


        String recordStatus = driver.findElement(By.xpath("//a[contains(text(),'Dedupe')]/following::label[text()='Reject Status:'][1]/following::td[1]")).getText();

        return recordStatus;
    }
    //a[contains(text(),'Suppression')]/ancestor::div//label[contains(text(),'Layout')]/following::a[1].click();
    @Step("Fetch Input Layout Fields By Clicking On The Layout HyperLink From The Ref Summary ")
    public List<String> fetchLayoutFields()
    {
        //get all the TR elements from the table
        List<String> fetchedRowsData=new ArrayList<String>();
      List<WebElement> allRows = driver.findElements(By.xpath("//table[@id='fieldTable']/tbody[1]/tr/td[1]"));

                for (WebElement row : allRows)
        {
            /*String fetchedRowDataFromTheLayout=row.getAttribute("innerHTML");*/
            String fetchedRowDataFromTheLayout=row.getText();
            fetchedRowsData.add(fetchedRowDataFromTheLayout.trim());
        }
        return fetchedRowsData;
    }@Step("Fetch Layout HyperLink From The Ref Summary ")
    public void clickOnTheInputLayoutLinkForSuppression()
    {
        driver.findElement(By.xpath("//a[text()='beta']")).click();
    }
    @Step("Get Error Message")
    public String getErrorMessage()
    {
        String errorMessage = driver.findElement(By.xpath("//div[@class='errMsg copyErrMsg']/span")).getText();
        return errorMessage;
    }

    @Step("Click close button")
    public void clickCloseButton()
    {
        driver.findElement(By.xpath("//div[@id='layoutTitle']/div[2]/div")).click();
    }


}

package com.equifax.cms.fusion.test.DMPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class CriteriaRejectsPage {

		WebDriver driver;
		
	public CriteriaRejectsPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[1]/div/div[2]/input[1]")
	WebElement Ele_drop;
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[1]/div/div[2]/input[2]")
	WebElement Ele_tag;
	
	@FindBy(xpath = ".//*[@id='input-datacheck-form']/div[1]/div/div[2]/input[3]")
	WebElement Ele_reject;
	
	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement Ele_BackBtn;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement ContinueButton;

	@Step("Select Drop")
	public void clickDropRadiobutton(){
		Ele_drop.click();
	}

	@Step("Select Tag")
	public void clickTagRadiobutton(){
		Ele_tag.click();
	}

	@Step("Select Reject")
	public void clickRejectRadiobutton(){
		Ele_reject.click();
	}
	
	@Step("Clicked on Back button")
	public void clickBackBtn(){
		Ele_BackBtn.click();
	}
	
	@Step("Click Continue Button on Criteria Rejects Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}

	@Step("Select Criteria Rejects")
	public void selectCriteriaRejects(String CritRejects){
		if(!"NA".equalsIgnoreCase(CritRejects)){
			String colon = ":";
			String comma = ",";
			StringTokenizer apMod = new StringTokenizer(CritRejects, colon);
			while(apMod.hasMoreTokens()){
				String[] apModRejectArray = apMod.nextToken().split(comma);
				String apModule = apModRejectArray[0];
				String Reject = apModRejectArray[1];
				String apModule_drop = apModule.concat("_drop");
				if(Reject.equalsIgnoreCase("Drop")){
//					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@name='"+apModule_drop+"'][1]")).click();
					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@value='0']")).click();
				}

				if(Reject.equalsIgnoreCase("Tag")){
//					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@name='"+apModule_drop+"'][2]")).click();
					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@value='1']")).click();
				}

				if(Reject.equalsIgnoreCase("Reject")){
//					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@name='"+apModule_drop+"'][3]")).click();
					driver.findElement(By.xpath(".//div[contains(text(),'"+apModule+"')]/following::input[@value='2']")).click();
				}
			}
	
	}
	}
}

package com.equifax.cms.fusion.test.MJpages;

import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class MatchJoinSetupPage
{

    WebDriver driver;
    public Select selType;

    public MatchJoinSetupPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "allRecordsAccRej")
    public WebElement masAllRecCB;

    @FindBy(xpath = "(.//*[@selected='selected'])[2]")
    public WebElement masTableSelected;

    @FindBy(xpath = "(.//*[@selected='selected'])[4]")
    public WebElement matTableSelected;

    @FindBy(xpath = ".//*[@id='jobId']/label")
    WebElement masJobNo;

    @FindBy(xpath = ".//*[@id='jobIdMatch']/label")
    WebElement matJobNo;

    @FindBy(id = "textMsg")
    WebElement secondTextMsg;

    @FindBy(xpath = ".//*[@id='textMsg']/ul/li[1]")
    WebElement firstTextMsg;

    @FindBy(id = "mjProcessName")
    public WebElement Ele_MasterProcessName;

    @FindBy(id = "fromProcessId")
    WebElement Ele_MasterProcess;

    @FindBy(id = "itemTableId")
    public WebElement Ele_MasterData;

    @FindBy(id = "projectNumberMatch")
    WebElement Ele_ProjectNumber;

    @FindBy(id = "searchButton")
    WebElement searchButton;

    @FindBy(id = "fromProcessIdmatch")
    WebElement Ele_MatchProcessName;

    @FindBy(id = "itemTableIdmatch")
    WebElement Ele_MatchData;

    @FindBy(id = "listVirtualArtifacts0.userProvidedName")
    public WebElement Ele_MatchedMasterFile;

    @FindBy(id = "listVirtualArtifacts1.userProvidedName")
    public WebElement Ele_UnMatchedMasterFile;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = "(.//input[@name='submitButton'])[1]")
    WebElement saveButton;

    @FindBy(xpath = "(.//input[@name='submitButton'])[2]")
    WebElement continueButton;


    @FindBy(id = "allRecordsAccRejForMatch")
    public WebElement allRegrdlsOfTypeMatch_CB;

    @FindBy(xpath = ".//*[@id='acceptCodeChkbx_0']")
    WebElement allAccepts_CB;

    public boolean isSurplusSelected()
    {
        return driver.findElement(By.xpath("(.//*[@value='_fl_surplus'])[1]//preceding::input[1]")).isSelected();
    }

    public boolean isG1Selected()
    {
        return driver.findElement(By.xpath("(.//*[@value='G1'])[1]//preceding::input[1]")).isSelected();
    }

    public boolean isOtherSelected()
    {
        return driver.findElement(By.xpath("(.//*[@value='_fl_other'])[1]//preceding::input[1]")).isSelected();
    }

    public String getMasJobId()
    {
        return masJobNo.getText();
    }

    public String getMatJobId()
    {
        return matJobNo.getText();
    }

    @Step("Get Error Message")
    public String getErrorMessage2()
    {
        return secondTextMsg.getText();
    }

    @Step("Get Error Message")
    public String getErrorMessage()
    {
        return firstTextMsg.getText();
    }

    @Step("Selected Accepts checkbox")
    public void selectAcceptsCheckBoxMatch()
    {
        allAccepts_CB.click();
    }

    @Step("Selected all Records checkbox")
    public void selectAllRecordsCheckBoxMatch()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", allRegrdlsOfTypeMatch_CB);


    }
    @Step("Selected all Records checkbox")
    public void selectAllRecordsCheckBoxMaster()
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", masAllRecCB);

    }

    @Step("Provided Master File Process Name as: {0}")
    public void inputProcessName(String procName)
    {
        Ele_MasterProcessName.sendKeys(procName);
    }

    @Step("Provided Master Process Field as: {0}")
    public void selectMasterProcess(String proc)
    {
        selType = new Select(Ele_MasterProcess);
        selType.selectByVisibleText(proc);
    }

    @Step("Provided Master Data Field as: {0}")
    public void selectMasterData(String data)
    {
        selType = new Select(Ele_MasterData);
        selType.selectByVisibleText(data);
    }

    @Step("Provided Match Process Field as: {0}")
    public void selectMatchProcess(String proc)
    {
        selType = new Select(Ele_MatchProcessName);
        selType.selectByVisibleText(proc);
    }

    @Step("Provided Match Data Field as: {0}")
    public void selectMatchData(String data)
    {
        selType = new Select(Ele_MatchData);
        selType.selectByVisibleText(data);
    }

    @Step("Provided Matched Master Output Table Name as : {0}")
    public void inputMatchedMasterOutputTableName(String masterName)
    {

        Ele_MatchedMasterFile.clear();
        Ele_MatchedMasterFile.sendKeys(masterName);

    }

    @Step("Provided UnMatched Master Output Table Name as : {0}")
    public void inputUnMatchedMasterOutputTableName(String unMasterName)
    {

        Ele_UnMatchedMasterFile.clear();
        Ele_UnMatchedMasterFile.sendKeys(unMasterName);

    }

    @Step("Provided Project No. as : {0}")
    public void inputProjectNumber(String projectNo)
    {
        Ele_ProjectNumber.clear();
        Ele_ProjectNumber.sendKeys(projectNo);
    }

    @Step("Clicked Search Button")
    public void clickSearchButton()
    {
        searchButton.click();
    }

    @Step("Clicked Save Button")
    public void clickSaveButton()
    {
        saveButton.click();
    }

    @Step("Clicked Continue Button")
    public void clickContinueButton()
    {
        continueButton.click();
    }

    @Step("Clicked Back Button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    public void searchProcessFromAnotherProject(String projectNo) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(projectNo))
        {
            inputProjectNumber(projectNo);
            clickSearchButton();
            Thread.sleep(3000);
        }
    }

    public void selectRecordsRejectMatch(String chItems)
    {
        if ("ALL".equalsIgnoreCase(chItems))
        {

            driver.findElement(By.id("checkAll")).click();
        } else
        {
            String delimiter = ",";
            StringTokenizer eachChkBoxText = new StringTokenizer(chItems, delimiter);
            while (eachChkBoxText.hasMoreTokens())
            {
                String dynamicId = getRecTypeChckBoxId(eachChkBoxText.nextToken());
                System.out.println("DYNAMIC_ID : " + dynamicId);
                WebElement checkBox = driver.findElement(By.id(dynamicId));
                if (!checkBox.isSelected())
                {
                    checkBox.click();
                }
            }
        }
    }
    public void selectRejectRecordTypesForMaster(String chItems)
    {
        if ("ALL".equalsIgnoreCase(chItems))
        {

            driver.findElement(By.id("allRecordsAccRej")).click();
        } else
        {
            String[] rejectRecordsArr=chItems.split(",");
            List<String> rejectRecordList=Arrays.asList(rejectRecordsArr);
            for(String reject:rejectRecordList)
            {
                String dynamicId = getRecTypeChckBoxId(reject);
                WebElement checkBox = driver.findElement(By.id(dynamicId));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", checkBox);

            }

        }
    }
    public void selectRejectRecordsForMatch(String chItems)
    {
        if ("ALL".equalsIgnoreCase(chItems))
        {

            driver.findElement(By.id("checkAllForMatch")).click();
        } else
        {
            String[] rejectRecordsArr=chItems.split(",");
            List<String> rejectRecordList=Arrays.asList(rejectRecordsArr);
            for(String reject:rejectRecordList)
            {
                String dynamicId = getRecTypeChckBoxId(reject);
                WebElement checkBox = driver.findElement(By.id(dynamicId));
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("arguments[0].click();", checkBox);

            }
        }
    }

    private enum RECORDREJECT
    {
        NH, nh, FR, fr, NP, np, PS, ps, RJ, rj, RP, rp, ID, id, IP, ip, CE, ce, RD, rd, DP, dp, HS, hs, ND, nd, DB, db, CT, ct, DD, dd, SR, sr, NA, na, SN, sn, NX, nx, RS, rs, DS, ds, DN, dn
    }

    public static String getRecTypeChckBoxId(String recReject)
    {
        RECORDREJECT RR = RECORDREJECT.valueOf(recReject);
        String dynamicCheckBoxId = null;
        switch (RR)
        {

        case NH:
        case nh:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_0";
            break;

        case FR:
        case fr:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_1";
            break;

        case NP:
        case np:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_2";
            break;

        case PS:
        case ps:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_3";
            break;

        case RJ:
        case rj:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_4";
            break;

        case RP:
        case rp:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_5";
            break;

        case ID:
        case id:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_6";
            break;

        case IP:
        case ip:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_7";
            break;

        case CE:
        case ce:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_8";
            break;

        case RD:
        case rd:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_9";
            break;

        case DP:
        case dp:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_10";
            break;

        case HS:
        case hs:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_11";
            break;

        case ND:
        case nd:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_12";
            break;

        case DB:
        case db:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_13";
            break;

        case CT:
        case ct:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_14";
            break;

        case DD:
        case dd:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_15";
            break;

        case SR:
        case sr:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_16";
            break;

        case NA:
        case na:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_17";
            break;

        case SN:
        case sn:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_18";
            break;

        case NX:
        case nx:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_19";
            break;

        case RS:
        case rs:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_20";
            break;

        case DN:
        case dn:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_21";
            break;

        case DS:
        case ds:
            dynamicCheckBoxId = "rejectCodeChkbxForMatch_22";
            break;

        }
        return dynamicCheckBoxId;
    }

    public void selectRecordTypesMatch(String process, String allRecords, String accepts, String rejects) throws InterruptedException
    {
        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");
        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                Thread.sleep(5000);
                selectAllRecordsCheckBoxMatch();
            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                	Thread.sleep(3000);
                	selectAcceptsCheckBoxMatch();
                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    Thread.sleep(5000);
                    selectRecordsRejectMatch(rejects);
                }
            }
        }
    }
    public void selectRecordTypesMaster(String process, String allRecords, String accepts, String rejects) throws InterruptedException
    {
        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");
        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                Thread.sleep(3000);
                selectAllRecordsCheckBoxMaster();
            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                    Thread.sleep(3000);
                    selectAcceptsCheckBoxMatch();
                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    Thread.sleep(3000);
                    selectRecordsRejectMatch(rejects);
                }
            }
        }
    }

    public void selectRecordTypesForMaster(String process, String allRecords, String accepts, String rejects) throws InterruptedException
    {
        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");
        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                Thread.sleep(3000);
                selectAllRecordsCheckBoxMaster();
            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                    Thread.sleep(3000);
                    selectAcceptsCheckBoxMatch();
                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    Thread.sleep(3000);
                    selectRejectRecordTypesForMaster(rejects);
                }
            }
        }
    }
    public void selectRecordTypesForMatch(String process, String allRecords, String accepts, String rejects) throws InterruptedException
    {
        if (process.startsWith("IP"))
        {
            System.out.println("Record Types are auto selected and disabled");
        } else
        {
            if (allRecords.equalsIgnoreCase("ON"))
            {
                Thread.sleep(5000);
                selectAllRecordsCheckBoxMatch();
            } else
            {
                if (accepts.equalsIgnoreCase("ON"))
                {
                    Thread.sleep(5000);
                    selectAcceptsCheckBoxMatch();
                }
                if (!rejects.equalsIgnoreCase("OFF"))
                {
                    Thread.sleep(5000);
                    selectRejectRecordsForMatch(rejects);
                }
            }
        }
    }
}

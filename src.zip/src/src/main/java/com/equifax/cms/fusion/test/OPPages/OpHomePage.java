package com.equifax.cms.fusion.test.OPPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

public class OpHomePage
{

    WebDriver driver;

    public OpHomePage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
    }

    @FindBy(linkText = "Output New File")
    WebElement OutputNewFile;

    @Step("Click Output New File button")
    public void clickOutputButton()
    {
        OutputNewFile.click();
    }

    @Step("Click Output Tab")
    public void clickOutputTab()
    {
        driver.findElement(By.xpath("//li[@id='output']")).click();
    }

    public String getLatestProcessID()
    {
        String[] processID = driver.findElement(By.xpath("(.//*[@id='OUTPUT'])[1]")).getText().split(":");
        return processID[0];
    }

    @Attachment("")
    public String GetStatusOP()
    {
        String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
        return status;
    }

    public void selectDuplicateOP()
    {
    	 driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();
         for (int second = 0;; second++)
         {
             if (second >= 20)
             {
                 fail("timeout");
             }
             try
             {
                 if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")))
                 {
                	 //Temporary Fix
                	 Thread.sleep(2000);
                     break;
                 }
             } catch (Exception e)
             {
             }
             try
             {
                 Thread.sleep(2000);
             } catch (InterruptedException e)
             {
                 // TODO Auto-generated catch block
                 e.printStackTrace();
             }
         }

         driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")).click();

         for (int second = 0;; second++)
         {
             if (second >= 20)
             {
                 fail("timeout");
             }
             try
             {
                 if (isElementPresent(By.id("jqxDuplicateWindow")))
                 {
                     break;
                 }
             } catch (Exception e)
             {
                 System.out.println(e);
             }
             try
             {
                 Thread.sleep(2000);
             } catch (InterruptedException e)
             {
                 // TODO Auto-generated catch block
                 e.printStackTrace();
             }
         }
         try
         {
             Thread.sleep(2000);
         } catch (InterruptedException e)
         {
             // TODO Auto-generated catch block
             e.printStackTrace();
         }
         /*
          * driver.switchTo().frame("sb-player"); Thread.sleep(2000);
          */
         driver.findElement(By.xpath(".//*[@id='dup-row']")).click();
         try
         {
             Thread.sleep(2000);
         } catch (InterruptedException e)
         {
             // TODO Auto-generated catch block
             e.printStackTrace();
         }

    }

    @Step("Edit the READY state process")
    public void selectEditOP()
    {

        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        
        for (int second = 0;; second++)
        {
            if (second >= 30)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                	Thread.sleep(2000);
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
    }

    public void selectSummaryOP()
    {
    	driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(10000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'View Summary')]")));
        element.click();
      //  driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();

    }

    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

    // added--sxs654
    public void selectDuplicateOPFromAssignedId(String AssignedId)
    {
    
       // driver.findElement(By.xpath("//*[@id='outputTable']//td[contains(text(),'" + AssignedId + "')]/parent::tr/td[1]/img")).click();
//    	driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']//div[contains(text(),'" + AssignedId + "')]//parent::div[1]/parent::div//img")).click();
//    	driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
//        for (int second = 0;; second++)
//        {
//            if (second >= 20)
//            {
//                fail("timeout");
//            }
//            try
//            {
//                if (isElementPresent(By.id("Duplicate")))
//                {
//                    break;
//                }
//            } catch (Exception e)
//            {
//            }
//            try
//            {
//                Thread.sleep(3000);
//            } catch (InterruptedException e)
//            {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }
//        }
//
//        driver.findElement(By.id("Duplicate")).click();
//        for (int second = 0;; second++)
//        {
//            if (second >= 20)
//            {
//                fail("timeout");
//            }
//            try
//            {
//                if (isElementPresent(By.id("popupTitle")))
//                {
//                    break;
//                }
//            } catch (Exception e)
//            {
//                System.out.println(e);
//            }
//            try
//            {
//                Thread.sleep(3000);
//            } catch (InterruptedException e)
//            {
//                // TODO Auto-generated catch block
//                e.printStackTrace();
//            }
//        }
//        try
//        {
//            Thread.sleep(3000);
//        } catch (InterruptedException e)
//        {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
//        driver.findElement(By.id("dup-row")).click();
//        try
//        {
//            Thread.sleep(3000);
//        } catch (InterruptedException e)
//        {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//        }
        //new
    	driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']//div[contains(text(),'" + AssignedId + "')]//parent::div[1]/parent::div//img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        /*
         * driver.switchTo().frame("sb-player"); Thread.sleep(2000);
         */
        driver.findElement(By.xpath(".//*[@id='dup-row']")).click();
        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }


    

    public String FetchTheProcessNameFromOPHomePage()// method fetches the "Process Name" from the OP home page but fetches for the first row from the
                                                     // grid
    {
        String fullProcessName = driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']//div/div[2]/div[1]")).getText();
        return fullProcessName;
    }
    
    

}

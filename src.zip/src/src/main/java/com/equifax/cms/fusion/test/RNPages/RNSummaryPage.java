package com.equifax.cms.fusion.test.RNPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class RNSummaryPage {

		WebDriver driver;
		
	public RNSummaryPage(WebDriver driver){
		
		this.driver = driver;
		
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = ".//*[@id='rnDetails']/div[2]/input")
	WebElement SubmitButton;

	@Step("Click Submit button")
	public void clickSubmitButton(){
		SubmitButton.click();
	}
	
	@Step("Process Name in Summary = \"{0}\"")
	public String procNameOnSum(String sumProcName){
		String path = driver.findElement(By.xpath("//span[contains(text(),'"+sumProcName+"')]")).getText();
		String[] a = path.split(":");
		return a[1].trim();
	}
}

package com.equifax.cms.fusion.test.OPPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class OpSetupPage
{

    WebDriver driver;

    public OpSetupPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "outputName")
    public WebElement Ele_ProcessName;

    @FindBy(id = "outputId")
    WebElement Ele_ProcId;

    @FindBy(id = "fromProcessId")
    WebElement Ele_Process;

    @FindBy(id = "itemTableId")
    WebElement Ele_Data;

    @FindBy(id = "purpose")
    WebElement Ele_FilePurpose;

    @FindBy(id = "existingLayoutRadio")
    public WebElement ExistingLayout_Rbtn;

    @FindBy(id = "layoutSearchButton")
    public WebElement MainLayoutSearch_btn;

    @FindBy(id = "projnum")
    public WebElement LayOutSrchProjNum;

    @FindBy(id = "search")
    public WebElement LayoutSrch_Btn;

    @FindBy(xpath = "//input[@type='submit']")
    WebElement LayoutContinue_Btn;

    @FindBy(id = "backButton")
    public WebElement LayoutCancel_Btn;

    @FindBy(id = "listVirtualArtifacts0.userProvidedName")
    public WebElement Ele_OPTableName;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(id = "continue")
    WebElement ContinueButton;

    public String getErrorMessage()
    {
        return driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']//label")).getText();
    }

    public void selectOutputSetupOptions(String processName, String process, String data, String groups, String purpose, String outputTableName)
            throws InterruptedException
            {
        inputprocessName(processName);
        selectProcessField(process);
        selectDataField(data);

        selectFilePurpose(purpose);
        inputOutputTableName(outputTableName);
        selectTheGroups(groups);

            }

    @Step("Select the Group Name = \"{0}\"")
    public void selectTheGroups(String groups) throws InterruptedException
    {
        Thread.sleep(3000);
        if (!groups.equalsIgnoreCase("NA"))
        {
            WebElement grp = driver.findElement(By.xpath("//label[contains(text(),'Group(s)')]"));
            if (grp.isDisplayed())
            {
                Thread.sleep(2500);
                if ("All Records".equalsIgnoreCase(groups))
                {
                    Thread.sleep(2500);
                    driver.findElement(By.xpath(".//label[contains(text(),'All Records')]//preceding::input[1]")).click();
                } else
                {
                    String comma = ",";
                    StringTokenizer stMain = new StringTokenizer(groups, comma);
                    while (stMain.hasMoreElements())
                    {
                        driver.findElement(By.xpath("//div[@class='groupNamesDiv']/input[@value='" + stMain.nextToken() + "']/preceding::input[1][1]")).click();
                    }
                }
            }
        }
    }

    public void clickLayoutSearchButton()
    {
        MainLayoutSearch_btn.click();
    }

    public void clickBackBtnLayoutSearch()
    {
        driver.findElement(By.id("backButton")).click();
    }

    public boolean isOutputTableNameFieldPresent()
    {
        try
        {
            Ele_OPTableName.sendKeys("TEST");
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Get the Process Id for the process")
    public String getProcessID()
    {
        String procId = Ele_ProcId.getAttribute("value");
        return procId;
    }

    @Step("Get the Process Name with ID = \"{0}\"")
    public String getProcessNameWithID(String procName)
    {
        String procId = Ele_ProcId.getText().trim();
        String processName = procId + ":" + procName;
        return processName;
    }

    @Step("Provided the Process Name field = \"{0}\"")
    public void inputprocessName(String processName)
    {
        if (!"NA".equalsIgnoreCase(processName))
        {
            Ele_ProcessName.sendKeys(processName);
        }
    }

    public void clearProcessNameField()
    {
        Ele_ProcessName.clear();
    }

    public boolean  isProcessNameEditable()
    {
        return  Ele_ProcessName.isEnabled();
    }
    @Step("Selected the process field = \"{0}\"")
    public void selectProcessField(String Process)
    {
        if (!"NA".equalsIgnoreCase(Process))
        {
            Select selType = new Select(Ele_Process);
            selType.selectByVisibleText(Process);
        }
    }

    @Step("Selected the Data field = \"{0}\"")
    public void selectDataField(String Data)
    {
        if (!"NA".equalsIgnoreCase(Data))
        {
            Select selpor = new Select(Ele_Data);
            selpor.selectByVisibleText(Data);
        }
    }

    @Step("Selected the File porpuse = \"{0}\"")
    public void selectFilePurpose(String purpose)
    {
        if (!"NA".equalsIgnoreCase(purpose))
        {
            Select selpor = new Select(Ele_FilePurpose);
            if ("Shipping File".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("SHIPPING_FILE");
            } else if ("Audit".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("AUDIT");
            } else if ("Internal Use".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("INTERNAL_USE");
            } else if ("Data Append".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("DATA_APPEND");
            } else if ("Apply Capping".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("APPLY_CAPPING");
            } else if ("Other".equalsIgnoreCase(purpose))
            {
                selpor.selectByValue("OTHER");
            }
        }
    }

    @Step("Selected the existing Layout in Output Setup screen ")
    public void selectLayout(String layout, String projExisLay, String layName)
    {
        if (!"NA".equalsIgnoreCase(layout))
        {
            if ("Create".equalsIgnoreCase(layout))
            {
                // DO NOTHING
            } else if ("ExistingAnotherProject".equalsIgnoreCase(layout))
            {
                ExistingLayout_Rbtn.click();
                MainLayoutSearch_btn.click();
                LayOutSrchProjNum.clear();
                LayOutSrchProjNum.sendKeys(projExisLay);
                LayoutSrch_Btn.click();
                driver.findElement(By.xpath("//label[contains(text(),'" + layName + "')]//preceding::input[1]")).click();
                LayoutContinue_Btn.click();
            }else if ("Existing".equalsIgnoreCase(layout)) {
                driver.findElement(By.xpath("//*[contains(text(),'"+layName+"')]/preceding::td[1]/input")).click();
            }
        }
    }
    @Step("Selected the existing Layout in Output Setup screen ")
    public String selectLayoutAndGetTitle(String layout)
    {
        String title=null;
        if (!"NA".equalsIgnoreCase(layout))
        {
            if ("ExistingAnotherProject".equalsIgnoreCase(layout))
            {
                ExistingLayout_Rbtn.click();
                MainLayoutSearch_btn.click();
                LayoutCancel_Btn.click();
                title= driver.findElement(By.xpath("//*[@class='cmsContent']//*[@class='fusion-h3Title']")).getText();

            }
        }
        return title;
    }



    @Step("Fetch The Provided Table Name")
    public String fetchTheProvidedtableName()
    {

        return  driver.findElement(By.xpath("//label[text()='Output Table Name:']//following::input[3]")).getAttribute("value");
    }

    @Step("Provide Output Table Name = \"{0}\"")
    public void inputOutputTableName(String TableName)
    {
        if (!"NA".equalsIgnoreCase(TableName))
        {
            Ele_OPTableName.clear();
            Ele_OPTableName.sendKeys(TableName);
        }
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public String getJobId()
    {
        return driver.findElement(By.xpath(".//*[@id='jobId']")).getText();
    }

    public String getDataSelected()
    {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[3]")).getText();
    }

    public String getFilePurposeSelected()
    {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[5]")).getText();
    }

    public void ifPopPresentClickOk()
    {
        try
        {
            driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
        } catch (org.openqa.selenium.NoSuchElementException e)
        {

        }
    }

    public String getDataSelectedNoInput()
    {
        return driver.findElement(By.xpath(".//*[@id='itemTableId']/option")).getText();
    }
  
    public String getProcessSelected()
    {
        return driver.findElement(By.xpath(".//*[@id='fromProcessId']/option")).getText();
    }
    public void handleConfirmWindow()
    {
        driver.findElement(By.xpath("//div[@id='jqxConfirmWindow']//following::input[@id='continueAnyWay']")).click();
    }


}

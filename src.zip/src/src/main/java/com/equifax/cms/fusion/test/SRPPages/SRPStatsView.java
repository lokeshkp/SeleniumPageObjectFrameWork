package com.equifax.cms.fusion.test.SRPPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class SRPStatsView
{
    WebDriver driver;
    public Select selType;

    public SRPStatsView(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }
    
    public String getSRP_Path() 
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Report Location')]/following::div[1]")).getText();
    }
    
    @Step("Validates that COUNTERS file is generated as output of JET workitem")
    public boolean checkCounterFileFormedOrNot(String path)
    {

        File f = null;
        File[] fileList;
        boolean isCountersFileFormed = false;
        try
        {
            // create new file
            /*
             * String path1="c:"+path+"/jobrun1"; String str1 = path1.replace("\\", "/");
             */
            String updatedPath = path + "/jobrun1";
            f = new File(updatedPath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        if (file.getName().endsWith(".counters"))
                        {
                            isCountersFileFormed = true;
                        }

                    }

                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }

        return isCountersFileFormed;
    }
    
    public Integer readAndCompareTheDataOfFileWithGreenPlumData(String path, HashMap<String, String> columnsData)
    {
        File f = null;
        int countOfRecordsMatched = 0;
        try
        {
            f = new File(path);
            if (f.exists() && !f.isDirectory())
            {
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {
                    String sCurrentLine;

                    while ((sCurrentLine = br.readLine()) != null)
                    {
                        String[] currentLineArr = sCurrentLine.split("\\|");
                        for (Map.Entry<String, String> entry : columnsData.entrySet())
                        {
                            if (currentLineArr[0].equalsIgnoreCase(entry.getKey()) && currentLineArr[1].equalsIgnoreCase(entry.getValue()) || currentLineArr[0].equalsIgnoreCase(entry.getValue()) && currentLineArr[1].equalsIgnoreCase(entry.getKey()))
                            {
                                countOfRecordsMatched++;
                            }
                        }

                    }
                } catch (IOException e)
                {
                    e.printStackTrace();
                }

            } else
            {

                System.out.println("file not found !!!!");

            }
        }

        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return countOfRecordsMatched;

    }


}

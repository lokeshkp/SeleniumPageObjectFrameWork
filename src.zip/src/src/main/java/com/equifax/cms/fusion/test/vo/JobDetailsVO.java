package com.equifax.cms.fusion.test.vo;

import java.io.Serializable;

import com.equifax.cms.fusion.test.json.JobStats;

public class JobDetailsVO implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long jobId;
	private Long jobNumber;
	private Long jobStepId;
	private String jobStatus;
	private String workItemStatus;
	private String statContent;
	private String itemName;
	private JobStats stats;
	
	public Long getJobId() {
		return jobId;
	}
	public void setJobId(Long jobId) {
		this.jobId = jobId;
	}
	public Long getJobNumber() {
		return jobNumber;
	}
	public void setJobNumber(Long jobNumber) {
		this.jobNumber = jobNumber;
	}
	public Long getJobStepId() {
		return jobStepId;
	}
	public void setJobStepId(Long jobStepId) {
		this.jobStepId = jobStepId;
	}
	public String getJobStatus() {
		return jobStatus;
	}
	public void setJobStatus(String jobStatus) {
		this.jobStatus = jobStatus;
	}
	public String getWorkItemStatus() {
		return workItemStatus;
	}
	public void setWorkItemStatus(String workItemStatus) {
		this.workItemStatus = workItemStatus;
	}
	public String getStatContent() {
		return statContent;
	}
	public void setStatContent(String statContent) {
		this.statContent = statContent;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public JobStats getStats() {
		return stats;
	}
	public void setStats(JobStats stats) {
		this.stats = stats;
	}
	
	

}

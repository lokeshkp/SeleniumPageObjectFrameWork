package com.equifax.cms.fusion.test.FICOpages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class CreateFICOreportsPage
{

    WebDriver driver;
    public Select selType;

    public CreateFICOreportsPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(id = "name")
    WebElement ProcNameFld;

    @FindBy(id = "fromProcessId")
    public WebElement ProcessFld;

    @FindBy(id = "jobNumbersMap")
    WebElement jobNoMap;

    @FindBy(xpath = ".//*[@id='jobId']/label")
    public WebElement JobNum;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement SaveBtn;

    @FindBy(xpath = "//input[@value='Submit']")
    WebElement SubmitBtn;

    public String getJobNo() throws InterruptedException
    {
        Thread.sleep(10000);
        return driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText();
    }

    public String getProcessSelected()
    {
        return driver.findElement(By.xpath(".//*[@selected='selected']")).getText();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
    }

    public String getErrorMessage1()
    {
        return driver.findElement(By.id("textMsg")).getText();
    }

    @Step("Provided the Process Name Field = \"{0}\"")
    public void processNameFld(String procName)
    {
        ProcNameFld.sendKeys(procName);
    }

    @Step("Selec the Process Field = \"{0}\"")
    public void selectProcFld(String procFld)
    {
        selType = new Select(ProcessFld);
        selType.selectByVisibleText(procFld);
    }

    public void selectJobNo(String jobNo)
    {
        if (!"NA".equalsIgnoreCase(jobNo))
        {
            selType = new Select(jobNoMap);
            selType.selectByVisibleText(jobNo);
        }
    }

    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        BackBtn.click();
    }

    @Step("Clicked Save button")
    public void clickSaveBtn()
    {
        SaveBtn.click();
    }

    @Step("Click Submit button")
    public void clickSubmitBtn()
    {
        SubmitBtn.click();
    }

    public void submitFicoReport()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement element = driver.findElement(By.xpath("//div[@class='refineParam']/div[@class='buttons']/input[2]"));
        js.executeScript("arguments[0].click();", element);

    }

    public String listFilesForFolder(File folder)
    {
        String fileName = null;
        for (final File fileEntry : folder.listFiles())
        {
            if (fileEntry.isDirectory())
            {
                listFilesForFolder(fileEntry);
            } else
            {
                fileName = fileEntry.getName();
            }
        }
        return fileName;
    }

}

package com.equifax.cms.fusion.test.RFPages;

import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class HholdCustomPage {

		WebDriver driver;
		
	public HholdCustomPage(WebDriver driver){		
		this.driver = driver;
		
	}
	
	@FindBy(xpath = ".//input[@value='Save']")
	WebElement SaveButton;
	
	@FindBy(xpath = "(.//*[@name='submitButton'])[2]")
	WebElement ContinueButton;
	
	@Step ("Saved the process")
	public void clickSaveButton(){
		SaveButton.click();
	}
	
	@Step ("Continue the process")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	}


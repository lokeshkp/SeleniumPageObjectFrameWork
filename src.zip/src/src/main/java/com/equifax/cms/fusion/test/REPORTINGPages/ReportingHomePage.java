package com.equifax.cms.fusion.test.REPORTINGPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class ReportingHomePage
{
    WebDriver driver;

    public ReportingHomePage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//a[contains(text(),'Reporting')]")
    WebElement ReportingTab;

    @FindBy(xpath = "//h2[contains(text(),'Reporting')]/following::div/ul[2]/li/ul/li/div[2]/a")
    WebElement quickFrequency_Btn;

    @FindBy(xpath = "(//a[@class='bg-img'])[1]")
    WebElement ExecuteSASBtn;

    @FindBy(xpath = "//h2[contains(text(),'Reporting')]/following::div/ul[6]/li/ul/li/div[2]/a")
    WebElement FICOReportsBtn;

    @FindBy(xpath = "//h2[contains(text(),'Reporting')]/following::div/ul[3]/li/ul/li/div[2]/a")
    WebElement StandardReportsBtn;

    public String getLatestFicoProcessID()
    {
        return driver.findElement(By.xpath("(.//*[@id='FI'])[1]")).getText().substring(0, 3);
    }

    public String getProcessStatus()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[3]/div")).getText().trim();
    }

    @Step("Clicked Reporting Tab")
    public void clickReportingTab()
    {
        ReportingTab.click();
    }

    @Step("Get Process Id ")
    public String getProcessId()
    {
        String[] procId = driver.findElement(By.xpath("(//td[@id='SRP'])[1]")).getText().split(":");
        return procId[0].trim();
    }

    @Step("Clicked Quick Frequency Button")
    public void clickQuickFrequency_Btn()
    {
        quickFrequency_Btn.click();
    }

    @Step("Clicked on Execute SAS Button")
    public void clickSASbtn()
    {
        ExecuteSASBtn.click();
    }

    @Step("Clicked on FICO Reports Button")
    public void clickFICObtn()
    {
        FICOReportsBtn.click();
    }

    @Step("Clicked on Standard Reports Button")
    public void clickStandardReportbtn()
    {
        StandardReportsBtn.click();
    }

    @Step("Clicked Duplicate Process")
    public void selectDuplicate()
    {
        driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr/td[1]/img)[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//*[@id='dup-row']")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Step("Clicked Summary Process")
    public void selectSummary()
    {

        driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr/td[1]/img)[1]")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Summary")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Summary")).click();

    }

    @Step("Clicked Edit Process")
    public void selectEdit()
    {

        driver.findElement(By.xpath("(.//*[@id='DataTables_Table_0']/tbody/tr/td[1]/img)[1]")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Edit")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Edit")).click();

    }

    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

    public String getProcessStatusByID(String process)
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'" + process + "')]/following::div/div")).getText().trim();
    }

}

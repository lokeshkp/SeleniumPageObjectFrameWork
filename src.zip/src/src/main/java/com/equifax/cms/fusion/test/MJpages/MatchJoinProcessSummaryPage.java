package com.equifax.cms.fusion.test.MJpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class MatchJoinProcessSummaryPage
{
    WebDriver driver;

    public MatchJoinProcessSummaryPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement submit_Btn;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[1]/tbody/tr/td[1]")
    WebElement masterProcess;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[1]/tbody/tr/td[2]")
    public WebElement masterJob;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[1]/tbody/tr/td[3]")
    WebElement masterData;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[2]/tbody/tr/td[1]")
    WebElement matchProcess;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[2]/tbody/tr/td[2]")
    public WebElement matchJob;

    @FindBy(xpath = "(.//*[@id='inputSummaryTableSplit'])[2]/tbody/tr/td[3]")
    WebElement matchData;

    @FindBy(id = "erMsg")
    WebElement errorMsg;

    public String getErrorMessage()
    {
        return errorMsg.getText();
    }

    public String getUnmatchedMasterOutputTableName()
    {
        return driver.findElement(By.xpath(".//*[@value='Unmatched Master']//following::input[2]")).getAttribute("value");
    }

    public String getMatchedMasterOutputTableName()
    {
        return driver.findElement(By.xpath(".//*[@value='Matched Master']//following::input[2]")).getAttribute("value");
    }

    public String getMasterFieldKey1()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[2]/span")).getText();
    }

    public String getMasterFieldKey2()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[5]/span")).getText();
    }

    public String getMasterFieldKey3()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[8]/span")).getText();
    }

    public String getMatchFieldKey1()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[3]/span")).getText();
    }

    public String getMatchFieldKey2()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[6]/span")).getText();
    }

    public String getMatchFieldKey3()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Master Fields')]//following::td[9]/span")).getText();
    }

    public String getAppendedField1()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Fields')])[4]//following::td[2]/span")).getText();
    }

    public String getAppendedField2()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Fields')])[4]//following::td[4]/span")).getText();
    }

    public String getAppendedField3()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'Fields')])[4]//following::td[6]/span")).getText();
    }

    public String getMasterProcessName()
    {
        return masterProcess.getText();
    }

    public String getMasterJobNo()
    {
        return masterJob.getText();
    }

    public String getMasterData()
    {
        return masterData.getText();
    }

    public String getMatchProcessName()
    {
        return matchProcess.getText();
    }

    public String getMatchJobNo()
    {
        return matchJob.getText();
    }

    public String getMatchData()
    {
        return matchData.getText();
    }

    public boolean isAppendedFieldDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            String a = driver.findElement(By.xpath("(.//*[@id='procSummaryTable'])[2]")).getAttribute("id");
            System.out.println(a);
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Clicked Back Button on Summary Screen")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Clicked Submit Button on Summary Screen")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    public String getTheMasterProcessNameFromTheSummary()
    {
        return driver.findElement(By.xpath("//div[starts-with(text(),'Input')]//following::td[text()='Master'][1]//following::tbody[1]/tr/td[1]")).getText();
    }

}

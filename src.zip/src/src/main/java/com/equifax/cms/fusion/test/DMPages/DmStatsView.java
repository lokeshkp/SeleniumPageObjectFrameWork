package com.equifax.cms.fusion.test.DMPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Step;

public class DmStatsView
{
    WebDriver driver;
    ProjectDashBoardPage ProjDashBoardPage;
    CommonMethods commMethods;

    public DmStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//a[contains(text(),'JET_JOB_XML')]")
    WebElement JetJobXML;

    @FindBy(xpath = "//a[contains(text(),'COUNTERS')]")
    WebElement counters;

    public String getSrcFileLocation()
    {
        String srcFileLoc = driver.findElement(By.xpath("//div[contains(text(),'Source file location')]")).getText();
        String[] b = srcFileLoc.split(":");
        return b[1];
    }

    @Step("Clicked JET JOB XML in the DM stats")
    public void clickJetJobXml()
    {
        JetJobXML.click();
    }

    @Step("Job XML title in stats")
    public String jobXmlTitle()
    {
        String xmlTitle = driver.findElement(By.xpath("//h3[contains(text(),'JET JOB XML')]")).getText();
        return xmlTitle;
    }

    @Step("Clicked COUNTERS in the DM stats")
    public void clickCounters()
    {
        counters.click();
    }

    @Step("Fetched Counter contents")
    public String getCounterContentStatsDM()
    {
        String counterContent = driver.findElement(By.xpath("html/body/div/div[1]/pre/div")).getText();
        return counterContent;
    }

    @Step("Fetched Job XML contents")
    public String getJobXMLContentStatsDM()
    {
        String xmlContent = driver.findElement(By.xpath("html/body/div/div[1]/pre/div")).getText();
        return xmlContent;
    }

    @Step("Fetched DM JET Job Directory")
    public String getJobDirectoryJETDM()
    {
        String path = driver.findElement(By.xpath("//div[contains(text(), 'Job Directory')]/following-sibling::div")).getText();
        return path;
    }

    @Step("Fetched DM Header Table Name")
    public String getHeaderTableNameDM()
    {
        String DMHeaderTableName = driver.findElement(By.xpath("//div[contains(text(), 'Datamenu HEADER Table')]/following-sibling::div")).getText();
        return DMHeaderTableName;
    }

    @Step("Fetched Agecrit Table Name from DM stats")
    public String getAGECRITtbleNameDM()
    {
        String dmAgeCritTbleName = driver.findElement(By.xpath("//div[contains(text(), '_DM_GPLOAD_AGECRIT_MAP001')]")).getText();
        return dmAgeCritTbleName;
    }

    @Step("Fetched DM 2st LCR Table Name")
    public String get2stLCRTableNameDM()
    {
        String DM2ndLCRTableName = driver.findElement(By.xpath("(//div[contains(text(), 'Datamenu LCR Table')]/following-sibling::div)[2]"))
                .getText();
        return DM2ndLCRTableName;
    }

    @Step("Fetched DM STEP FLAG Table Name")
    public String getStepFlagTableNameDM()
    {
        String DMStepFlagTableName = driver.findElement(By.xpath("//div[contains(text(), 'Datamenu STEP_FLAG Table')]/following-sibling::div"))
                .getText();
        return DMStepFlagTableName;
    }

    @Step("Fetched Score Model table 5213 name")
    public String getScModelTbleName5213DM()
    {
        String scModelTbleName5213 = driver.findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_MODEL_5213')]")).getText();
        return scModelTbleName5213;
    }

    @Step("Fetched Score Model table 5213 count")
    public Long getScModel5213Count()
    {
        String scModelTbleName5213count = driver.findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_MODEL_5213')]/following::div[1]/div[2]"))
                .getText();
        return Long.parseLong(removeComma(scModelTbleName5213count));
    }

    @Step("Fetched DM Sample Index Table Name")
    public String getSampleIndexTableNameDM()
    {
        String DMSampleIndexTableName = driver
                .findElement(By.xpath("//div[contains(text(), 'Datamenu AUDIT_SAMPLE_INDEX Table')]/following-sibling::div")).getText();
        return DMSampleIndexTableName;
    }

    @Step("Fetched DM Inquiry Post Table Name")
    public String getInqPostTableNameDM()
    {
        String DMInqPostTableName = driver.findElement(By.xpath("//div[contains(text(), 'Datamenu INQUIRYPOST Table')]/following-sibling::div"))
                .getText();
        return DMInqPostTableName;
    }

    @Step("Fetched Header Table Count for DM From Stats")
    public Long getHeaderTableCountDM()
    {
        String DMHeaderTableCount = driver.findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_HEADER')]/following::div[1]/div[2]")).getText();
        return Long.parseLong(removeComma(DMHeaderTableCount));
    }

    @Step("Fetched LCR-Kontable Table Count for DM From Stats")
    public Long getKontableTableCountDM()
    {
        String DMKontableTableCount = driver
                .findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_JXH_TEST_KONTABLE_MAP001')]/following::div[1]/div[2]")).getText();
        return Long.parseLong(removeComma(DMKontableTableCount));
    }

    @Step("Fetched LCR-Kontable-IDscan Table Count for DM From Stats")
    public Long getKontableIdScanTableCountDM()
    {
        String DMKontableIdScanTableCount = driver
                .findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_JXH_TEST_KONTABLE_IDSCAN')]/following::div[1]/div[2]")).getText();
        return Long.parseLong(removeComma(DMKontableIdScanTableCount));
    }

    @Step("Fetched Step Flag Table Count for DM From Stats")
    public Long getStepFlagTableCountDM()
    {
        String DMStepFlagTableCount = driver.findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_STEP_FLAG_TBL')]/following::div[1]/div[2]"))
                .getText();
        return Long.parseLong(removeComma(DMStepFlagTableCount));
    }

    @Step("Fetched Sample Index Table Count for DM From Stats")
    public Long getSampleIndexTableCountDM()
    {
        String DMSmpleIndexTableCount = driver
                .findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_AUDIT_SAMPLE_INDEX')]/following::div[1]/div[2]")).getText();
        return Long.parseLong(removeComma(DMSmpleIndexTableCount));
    }

    @Step("Fetched Inq. Post Table Count for DM From Stats")
    public Long getInqPostTableCountDM()
    {
        String DMInqPostTableCount = driver.findElement(By.xpath(".//div[contains(text(), '_DM_GPLOAD_INQUIRYPOSTTBL')]/following::div[1]/div[2]"))
                .getText();
        return Long.parseLong(removeComma(DMInqPostTableCount));
    }

    @Step("Fetched Criteria Reject table count for DM from Stats")
    public Long getCritRejCountDM()
    {
        String critRejCountDM = driver.findElement(By.xpath("//div[contains(text(),'RJ-Criteria Reject')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(critRejCountDM));
    }

    @Step("Fetched Double Check Reject table count for DM from Stats")
    public Long getDbCheckCountDM()
    {
        String dbchkCountDM = driver.findElement(By.xpath("//div[contains(text(),'DB-Double Check Reject')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(dbchkCountDM));
    }

    @Step("Fetched PointScore Drop table count for DM from Stats")
    public Long getPointScoreCountDM()
    {
        String pointScoreCountDM = driver.findElement(By.xpath("//div[contains(text(),'PS-PointScore Drop')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(pointScoreCountDM));
    }

    @Step("Fetched ID Scan table count for DM from Stats")
    public Long getIDScanCountDM()
    {
        String idScanCountDM = driver.findElement(By.xpath("//div[contains(text(),'ID-Id Scan')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(idScanCountDM));
    }

    @Step("Verified the Creteria Rejects is displayed or not")
    public boolean isCretRejDisplayed()
    {
        try
        {
            WebElement critRejCountDM = driver.findElement(By.xpath("//div[contains(text(),'RJ-Criteria Reject')]//following::div[1]"));
            critRejCountDM.isDisplayed();
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return true;
        }
    }

    @Step("Fetched LCR table name for DM from Stats")
    public String getP463A6L0tbleName()
    {
        String lcrP463A6L0tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_P463A6L0_OUTREC')]")).getText().trim();
        return lcrP463A6L0tble;
    }

    @Step("Fetched LCR table name for DM from Stats")
    public String getP4536DF0tbleName()
    {
        String lcrP4536DF0tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_P4536DF0_LCRREC')]")).getText().trim();
        return lcrP4536DF0tble;
    }

    @Step("Fetched FUSION_FRIENDLY_MOD LCR table")
    public String getFusionFrndlyModname()
    {
        String lcrFusionFrndlyModName = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_FUSION_FRIENDLY_MOD_MAP001')]")).getText()
                .trim();
        return lcrFusionFrndlyModName;
    }

    @Step("Fetched FUSION_FRIENDLY_MOD LCR table count")
    public Long getFusionFrndlyModTbleCount()
    {
        String lcrFusionFrndlyModCount = driver
                .findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_FUSION_FRIENDLY_MOD_MAP001')]//following::div[3]")).getText().trim();
        return Long.parseLong(removeComma(lcrFusionFrndlyModCount));
    }

    @Step("Fetched Fact Act table from Stats")
    public String getFactActTble()
    {
        String factActTble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_Fact_Act')]")).getText().trim();
        return factActTble;
    }

    @Step("Fetched Total Records from Fact Act table from Stats")
    public String getFactActTbleNoOfRecords()
    {
        String factActTbleRecords = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_Fact_Act')]//following::div[3]")).getText().trim();
        return factActTbleRecords;
    }

    @Step("Fetched 1070 score model table")
    public String get1070Tble()
    {
        String get1070Tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_MODEL_1070')]")).getText();
        return get1070Tble;
    }

    @Step("Fetched 1070 score model table Count")
    public Long get1070TbleCount()
    {
        String get1070TbleCount = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_MODEL_1174')]//following::div[3]")).getText();
        return Long.parseLong(removeComma(get1070TbleCount));
    }

    @Step("Fetched 1174 score model table")
    public String get1174Tble()
    {
        String get1174Tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_MODEL_1174')]")).getText();
        return get1174Tble;
    }

    @Step("Fetched 1174 score model table Count")
    public Long get1174TbleCount()
    {
        String get1174TbleCount = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_MODEL_1174')]//following::div[3]")).getText();
        return Long.parseLong(removeComma(get1174TbleCount));
    }

    @Step("Fetched P463A6L0 module table Count")
    public Long getP463A6L0TbleCount()
    {
        String getP463A6L0Tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_P463A6L0_OUTREC')]//following::div[3]")).getText();
        return Long.parseLong(removeComma(getP463A6L0Tble));
    }

    @Step("Fetched P4536DF0 module table")
    public Long getP4536DF0TbleCount()
    {
        String getP4536DF0Tble = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_P4536DF0_LCRREC')]//following::div[3]")).getText();
        return Long.parseLong(removeComma(getP4536DF0Tble));
    }

    @Step("Fetched Input File Path")
    public String getInputFilePath()
    {
        String path = driver.findElement(By.xpath("//div[contains(text(),'Input file path')]//following-sibling::div")).getText();
        return path;
    }

    @Step("Fetched Accept Code Count")
    public String getCountOfAcceptsDM(String valueDiv)
    {
        String count = driver.findElement(By.xpath("//div[contains(text(), 'Record Type Distribution')]/following::div[" + valueDiv + "]")).getText();
        return count;
    }

    public void kontableTableStats(String APModule) throws SQLException
    {
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        if (APModule.equalsIgnoreCase("JXH_TEST_KONTABLE"))
        {

            String FirstLCRTableNameDM = getAGECRITtbleNameDM();
            String SecondLCRTableNameDM = get2stLCRTableNameDM();

            Long KontableTableCountDMUI = getKontableTableCountDM();
            Long KontableIdScanTableCountDMUI = getKontableIdScanTableCountDM();

            Long KontableTableCountDMGP = ProjDashBoardPage.getRecordsFromGP(FirstLCRTableNameDM);
            Long KontableIdScanTableCountDMGP = ProjDashBoardPage.getRecordsFromGP(SecondLCRTableNameDM);

            commMethods.verifyLong(KontableTableCountDMUI, KontableTableCountDMGP);
            commMethods.verifyLong(KontableIdScanTableCountDMUI, KontableIdScanTableCountDMGP);
        }
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching Record count From Green Plum for DM Table = \"{0}\"")
    public long getRecordsFromGP(String table, String columnName, String value) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where " + columnName + " = '" + value + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record count From Green Plum for DM Table = \"{0}\" \"{1}\"")
    public long getRecordsFromGP2(String table, String columnName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(" + columnName + ") from fusion_stage." + table + "";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching similar dp_sequence number for different tables = \"{0}\"")
    public long getDp_Seq_NumForTbles(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select dp_sequence_num from fusion_stage." + table + " order by cid limit 1";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Fail Code & Rej Code count match with  = \"{0}\"")
    public long getFailCodeRejCodeTbleCount(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + "where fail_code = 'RJ' and rej_code = '1'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Greenplum failcode  count with  = \"{0}\"")
    public long getFailCodeCounts(String failCode, String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where fail_code = '" + failCode + "'";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Greenplum dblchck reject count match with  = \"{0}\"")
    public long getDbCodeRejectCounts(String table, String recordStatus) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where record_status = '" + recordStatus + "'";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Greenplum dblchck reject count match with  = \"{0}\"")
    public long getDbCodeOptionCounts(String table, String dbck_code) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where dbck_code = '" + dbck_code + "'";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }
    
    @Step("Fetching Greenplum dblchck count where its not blank with  = \"{0}\"")
    public long getDbCodeOptionNotBlankCounts(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where dbck_code != '' ";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Greenplum table count match with  = \"{0}\"")
    public long getGpTbleCount(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + "";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Column Names From Green Plum for Table = \"{0}\"")
    public List<String> getColumnNamesFromGP(String tableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> columnNames = new ArrayList<>();

        query1 = "select column_name from information_schema.columns where table_schema = 'fusion_stage' and upper(table_name) = upper('" + tableName
                + "')";
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            columnNames.add(rs.getString(1));
        }
        conn.close();
        return columnNames;
    }

    @Step("Fetching Id Scan Code column From Green Plum for DM Table = \"{0}\"")
    public List<String> getIdScanCodeColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> idScanValues = new ArrayList<>();
        query1 = "select id_scan_code from fusion_stage." + table + " where id_scan_code != '' ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            idScanValues.add(rs.getString(1));
        }
        conn.close();
        return idScanValues;
    }
    
    @Step("Fetching Fraud Victim Flag column From Green Plum for DM Table = \"{0}\"")
    public List<String> getFraudVictimColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> fraudVictimValues = new ArrayList<>();
        query1 = "select fraud_victim_flg from fusion_stage." + table +" where fraud_victim_flg != '' ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            fraudVictimValues.add(rs.getString(1));
        }
        conn.close();
        return fraudVictimValues;
    }

    @Step("Fetching Id Scan Code column From Green Plum for DM Table = \"{0}\"")
    public List<String> getDblChkCodeColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> dbchkValues = new ArrayList<>();
        query1 = "select dbck_code from fusion_stage." + table + " where dbck_code != '' ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            dbchkValues.add(rs.getString(1));
        }
        conn.close();
        return dbchkValues;
    }

    @Step("Fetching Fail Code column From Green Plum for DM Table = \"{0}\"")
    public List<String> getFailCodeColumnValuesFromGP(String table, String stateList) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> failCodeValues = new ArrayList<>();
        query1 = "select fail_code from fusion_stage." + table + " where state != '' ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            failCodeValues.add(rs.getString(1));
        }

        String query2;
        List<String> stateValues = new ArrayList<>();
        query2 = "select state from fusion_stage." + table + " where state != '' ";

        PreparedStatement ps1 = conn.prepareStatement(query2);

        ResultSet rs1 = ps1.executeQuery();
        while (rs1.next())
        {
            stateValues.add(rs1.getString(1));
        }

        conn.close();

        String[] stateSplit = stateList.split(",");
        int k = 0;

        while (k < stateSplit.length)
        {
            if (stateValues.contains(stateSplit[k]))
            {
                Assert.assertEquals("State is there", "State should not be there");
            }
            k++;
        }

        return failCodeValues;
    }

    @Step("Fetching dp_seq and idscan column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqIdScanColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,id_scan_code from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }

    @Step("Fetching dp_seq and failcode column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqFailCodeColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,fail_code from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }

    @Step("Fetching dp_seq and record status column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqRecordStatusColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,record_status from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }

    @Step("Fetching dp sequence num and acceptcodes column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqAcceptCodesColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,acc_code from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }
    
    @Step("Fetching dp sequence num and doublecheck column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqDblchkCodesColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,dbck_code from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }

    @Step("Fetching dp sequence num and rejectcodes column From Green Plum for DM Table = \"{0}\"")
    public Map<String, String> getDpSeqRejectCodesColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;

        Map<String, String> values = new HashMap<>();
        query1 = "select dp_sequence_num,rej_code from fusion_stage." + table + " order by dp_sequence_num ";

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            values.put(rs.getString(1), rs.getString(2));
        }
        conn.close();
        return values;
    }

    @Step("Fetching Id Scan Code and Fail Code column From Green Plum for DM Table = \"{0}\"")
    public boolean checkBlankIdScanFailCodeColumnValuesFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        List<String> idScanValues = new ArrayList<>();
        List<String> failCodeValues = new ArrayList<>();
        query1 = "select id_scan_code, fail_code from fusion_stage." + table;

        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        while (rs.next())
        {
            idScanValues.add(rs.getString(1));
            failCodeValues.add(rs.getString(2));
        }
        conn.close();

        int i = 0;
        boolean flag = false;
        while (i < idScanValues.size())
        {
            if (idScanValues.get(i) != null)
                flag = true;
            i++;
        }
        i = 0;
        while (i < failCodeValues.size())
        {
            if (failCodeValues.get(i) != null)
                flag = true;
            i++;
        }

        return flag;
    }
    
    public String removeComma(String a)
    {
        String a2="";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2=a2+element;
        }
        return a2;
    }
}

package com.equifax.cms.fusion.test.DMEpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DMEsummaryPage
{

    // private static WebElement element = null;
    WebDriver driver;
    public Select selType;

    public DMEsummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//input[@name='submitButton']")
    WebElement SubmitButton;

    @Step("Click Submit Button ")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }

    @Step("Click Submit Button ")
    public void clickViewXml()
    {
        driver.findElement(By.xpath("//a[contains(text(),'View XML')]")).click();
    }

    public void dmeJobName()
    {
        String path = driver.findElement(By.xpath(".//*[@id='process']/div[1]/span")).getText();
        System.out.println(path);
        String[] strOut = path.split(":");
        System.out.println(strOut[0]);
        driver.findElement(By.xpath("//td[contains(text(),'" + strOut + "')]"));
    }

    @Step("Get XML contents ")
    public String getJobXmlContents()
    {
        String xmlText = driver.findElement(By.xpath(".//*[@id='xmlArea']/pre")).getText();
        return xmlText;
    }

    public boolean isScoreModelTablePredictedSumm(String processID)
    {
        int count = driver.findElements(By.xpath(".//*[contains(text(),'" + processID + ".MODEL_')]")).size();
        if (count == 13)
        {
            return true;
        } else
        {
            return false;
        }
    }

    public String getProductDisplayed()
    {
        return driver.findElement(By.xpath(".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[2]/td[2]")).getText().trim();
    }

}

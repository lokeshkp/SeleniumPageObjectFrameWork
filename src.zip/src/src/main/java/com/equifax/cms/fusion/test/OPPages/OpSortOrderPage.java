package com.equifax.cms.fusion.test.OPPages;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class OpSortOrderPage
{

    WebDriver driver;

    public OpSortOrderPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "sortRequiredCheck")
    public WebElement Ele_SortRequired;

    @FindBy(id = "add_sortOrder")
    WebElement ForwardButton;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;
    public String isSortRequired()
    {
        String sortReq="Y";
        if(Ele_SortRequired.getAttribute("value").equals(""))
        {
            sortReq="N";
        }
        return sortReq;
    }
    public String getLayoutNameDisplayedSort()
    {
        String[] layname = driver.findElement(By.xpath("(.//*[@class='sortOrderFileSummary'])[1]/tbody/tr[3]/td")).getText().split(":");
        return layname[1].trim();
    }

    @Step("Select Sort Required field")
    public void clickSortRequired(String sortReq, String purpose)
    {
        //if (!"Apply Capping".equalsIgnoreCase(purpose))
        //{
            if ("Y".equalsIgnoreCase(sortReq))
            		if( !Ele_SortRequired.isSelected())
							Ele_SortRequired.click();

        //}
    }
    @Step("Get field selected for sorting")
    public String fetchFieldSelectedForSorting()
    {
        String[] sortField= driver.findElement(By.xpath("//div[@class='output-table_sortOrder odd']//following::span[1]")).getText().split("\\.");
        return sortField[0].trim();
    }

    @Step("Select Forward button")
    public void clickForwardButton()
    {
        ForwardButton.click();
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton(String purpose)
    {
        if (!"Apply Capping".equalsIgnoreCase(purpose))
        {
            ContinueButton.click();
        }
    }

    public boolean isReSequenceDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            String aa = driver.findElement(By.xpath("(.//*[contains(text(),'.RE_SEQUENCE_NUM')])")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public void selectSortField(String sortFields, String sortReq, String purpose)
    {
        if ("Y".equalsIgnoreCase(sortReq))
        {
            if (!"Apply Capping".equalsIgnoreCase(purpose))
            {
                String delimiter = ",";
                StringTokenizer fieldText = new StringTokenizer(sortFields, delimiter);
                while (fieldText.hasMoreTokens())
                {
                    if (!"NA".equalsIgnoreCase(sortFields))
                    {
                        String dynamicField = ".//a[contains(text(),'" + fieldText.nextToken() + "')]";
                        driver.findElement(By.xpath(dynamicField)).click();
                        clickForwardButton();
                    }
                }

            }
        }
    }

    public List<String> getPredictedFieldsList()
    {
        List<WebElement> allElements = driver.findElements(By.xpath("//div[@id='predefined']/ul/li/ul/li"));
        List<String> eleIds = new ArrayList<>();

        for (WebElement ele : allElements)
        {
            String id = ele.getAttribute("id");
            eleIds.add(id);
        }

        List<String> fieldNames = new ArrayList<>();
        for (String id : eleIds)
        {
            String name = driver.findElement(By.xpath("//li[@id='" + id + "']/a")).getText();
            String nameSplit[] = name.split(" ");
            fieldNames.add(nameSplit[0].toLowerCase());
        }

        return fieldNames;
    }
    public boolean  isFieldPresentAsDefinedInConfigPage(String selectedFields)
    {
        boolean isFieldPresent=false;
        List<String> selectedFieldList=Arrays.asList(selectedFields.split(","));
        List<WebElement> allElements = driver.findElements(By.xpath("//div[@id='custom']//li"));
        if(allElements.size()==selectedFieldList.size())
        {
            for(WebElement ele:allElements)
            {
                String id=ele.getAttribute("id");
                String[] textArr= driver.findElement(By.xpath("//li[@id="+id+"]//a")).getText().split("\\.");
                for(String field:selectedFieldList)
                {
                    if(field.equalsIgnoreCase(textArr[0]))
                    {
                        isFieldPresent=true;
                    }
                }

            }
            //li[@id=2]//a
        }
        return  isFieldPresent;
    }

}

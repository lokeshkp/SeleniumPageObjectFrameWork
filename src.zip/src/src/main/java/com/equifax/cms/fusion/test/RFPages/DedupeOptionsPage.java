package com.equifax.cms.fusion.test.RFPages;

import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class DedupeOptionsPage {

    WebDriver driver;

    public DedupeOptionsPage(WebDriver driver){
        this.driver = driver;
    }

    @FindBy(id = "cidDedupe")
    WebElement Ele_DedupeCID;

    @FindBy(id = "ssnDedupe")
    WebElement Ele_DedupeSSN;

    @FindBy(id = "customDedupe")
    WebElement Ele_DedupeCustom;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/h3")
    WebElement ScreenTitle;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;

    @Step ("Screen Title:")
    public String getTitle(){
        return ScreenTitle.getText();
    }

    @Step("Error message is ")
    public String getErrMsg(){
        return ErrorMessage.getText();
    }

    @Step ("Select Dedupe CID")
    public void clickDedupeCIDChckBox(){
        Ele_DedupeCID.click();
    }

    @Step ("Select Dedupe SSN")
    public void clickDedupeSSNChckBox(){
        Ele_DedupeSSN.click();
    }

    @Step ("Select Custom Dedupe")
    public void clickCustomDedupeChckBox(){
        Ele_DedupeCustom.click();
    }

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }

    @Step("Clicked on Back Button in Dedupe screen")
    public void clickBackBtn(){
        BackBtn.click();
    }

    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }

    @Step ("Select the Dedupe Options = \"{0}\"")
    public void selectDedupeOptions(String option){
        String delimiter = ",";
        StringTokenizer field = new StringTokenizer(option, delimiter);

        while(field.hasMoreTokens()){
            String dynPath =field.nextToken()+"Dedupe";
            driver.findElement(By.id(dynPath)).click();
        }
    }
    @Step ("Select the Dedupe Options = \"{0}\"")
    public void selectDedupeType(String option){


        if("CID".equalsIgnoreCase(option))
        {
            clickDedupeCIDChckBox();

        } else if ("SSN".equalsIgnoreCase(option)){
            clickDedupeSSNChckBox();

        } else if ("Custom".equalsIgnoreCase(option)){
            clickDedupeSSNChckBox();

        }else {
            System.out.println("Wrong information has provided in the input Data sheet !!!");
        }
    }
}

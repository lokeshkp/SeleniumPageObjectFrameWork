package com.equifax.cms.fusion.test.IZpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class SummaryIZpage
{
    WebDriver driver;

    public SummaryIZpage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@id='zipStatsForm']/div/div/div[3]/table[2]/tbody/tr[3]/td[2]")
    public WebElement zipCodeEntries;

    @FindBy(xpath = ".//*[@id='zipStatsForm']/div/div/div[3]/table[2]/tbody/tr[5]/td[2]")
    public WebElement DupliEntries;

    @FindBy(xpath = ".//*[@id='zipStatsForm']/div/div/div[3]/table[2]/tbody/tr[9]/td[2]")
    public WebElement RadEntries;

    @FindBy(xpath = ".//*[@id='zipStatsForm']/div/div/div[3]/table[2]/tbody/tr[7]/td[2]")
    public WebElement RangeEntries;

    @FindBy(id = "submit")
    WebElement SubmitBtn;

    @Step("Clicked Submit button")
    public void clickSubmitBtn()
    {
        SubmitBtn.click();
    }

    public String initialEntriesSum(String value)
    {
        if (!value.equals("0"))
        {
            return "PASS";
        } else
        {
            return "FAIL";
        }
    }
}

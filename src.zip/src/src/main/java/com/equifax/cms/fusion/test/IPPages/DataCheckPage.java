package com.equifax.cms.fusion.test.IPPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataCheckPage
{

    WebDriver driver;
    public Select sel;

    public DataCheckPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "isDataCheck")
    public WebElement Ele_DataCheckCheckBox;

    @FindBy(id = "fileIdentifier")
    public WebElement FileIdentifierFld_Ddwn;

    @FindBy(id = "maxNoOfBlankFields")
    WebElement MaxNoBlankFlds;

    @FindBy(id = "maxNoOfSingleFields")
    WebElement MaxNoSingleFlds;

    @FindBy(id = "maxNoOfUnknownFields")
    WebElement MaxNoUnKnownFlds;

    @FindBy(id = "runtimeB")
    WebElement RunTimeBFld_Ddwn;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement SaveBtn;

    @FindBy(id = "submitButton")
    WebElement ContinueButton;

    @FindBy(xpath = "(//input[@name='submitButton'])[2]")
    WebElement OPContinue_btn;

    @Step("Click DataCheck check box")
    public void clickDataCheckCheckbox(String check) throws InterruptedException
    {
        if ("CHECK".equalsIgnoreCase(check))
        {
            Thread.sleep(1500);
            JavascriptExecutor js = (JavascriptExecutor) driver;
            Thread.sleep(3000);
            js.executeScript("arguments[0].click();", Ele_DataCheckCheckBox);

            // Ele_DataCheckCheckBox.click();
        }
    }

    @Step("Select the File Identifier = \"{0}\"")
    public void selectFileIdentifier(String fileIden)
    {
        sel = new Select(FileIdentifierFld_Ddwn);
        sel.selectByVisibleText(fileIden);
    }

    @Step("Provide Max Number of Blank Fields = \"{0}\"")
    public void maxNoBlankFlds(String maxNoBlank)
    {
        if (!"NA".equalsIgnoreCase(maxNoBlank))
        {
            MaxNoBlankFlds.sendKeys(maxNoBlank);
        }
    }

    @Step("Provide Max Number of Single Field values = \"{0}\"")
    public void maxNoSingleFlds(String maxNoSingle)
    {
        if (!"NA".equalsIgnoreCase(maxNoSingle))
        {
            MaxNoSingleFlds.sendKeys(maxNoSingle);
        }
    }

    @Step("Provide Max Number of Unknown Field values = \"{0}\"")
    public void maxNoUnknwonFlds(String maxNoUnknown)
    {
        if (!"NA".equalsIgnoreCase(maxNoUnknown))
        {
            MaxNoUnKnownFlds.sendKeys(maxNoUnknown);
        }
    }

    @Step("Select the Run Time B Field value = \"{0}\"")
    public void selectRunTimeB(String runTimeB)
    {
        sel = new Select(RunTimeBFld_Ddwn);
        sel.selectByValue(runTimeB);
    }

    @Step("Clicked the Save button")
    public void clickSaveBtn()
    {
        SaveBtn.click();
    }

    @Step("Click Continue button on Data Check Page")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    @Step("Click Continue button on Data Check Page")
    public void clickContinueBtnOP()
    {
        OPContinue_btn.click();
    }
}

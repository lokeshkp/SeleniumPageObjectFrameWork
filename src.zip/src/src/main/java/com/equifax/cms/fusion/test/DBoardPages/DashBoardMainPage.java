package com.equifax.cms.fusion.test.DBoardPages;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DashBoardMainPage {
	WebDriver driver;
	public Select selType;

	public DashBoardMainPage(WebDriver driver) {
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@FindBy(id = "cms_home")
	WebElement DashBoard_Tab;

	@FindBy(id = "projectNumber")
	WebElement ProjNum_Fld;

	@FindBy(xpath = "//input[@value='Import']")
	WebElement Import_Btn;

	@FindBy(id = "wRole")
	WebElement WorkingAs;

	@Step("Selected the Working As = \"{0}\"")
	public void selWorkingAs(String workingAs) {
		selType = new Select(WorkingAs);
		selType.selectByVisibleText(workingAs);
	}

	@Step("List of fields in the Working As drop down")
	public void listWorkingAs(String a) {
		String[] b = a.split(",");
		selType = new Select(WorkingAs);
		List<WebElement> dataFlds = selType.getOptions();
		boolean flag = false;
		for (int i = 0; i < b.length; i++) {
			System.out.println(b[i]);
			for (WebElement flds : dataFlds) {
				if (b[i].contains(flds.getText())) {
					flag = true;
				} else {
					flag = false;
				}
			}
		}
	}

	@Step("Clicked Dashboard Tab")
	public void clickDashBoardTab() {
		DashBoard_Tab.click();
	}

	@Step("Provided the Project Number Field = \"{0}\"")
	public void ProjNumFld(String projNum) {
		ProjNum_Fld.sendKeys(projNum);
	}

	@Step("Clicked on Import button")
	public void clickImportBtn() {
		Import_Btn.click();
	}
}

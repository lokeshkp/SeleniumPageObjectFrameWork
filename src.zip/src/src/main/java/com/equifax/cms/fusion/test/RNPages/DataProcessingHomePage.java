package com.equifax.cms.fusion.test.RNPages;

import static org.junit.Assert.fail;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class DataProcessingHomePage {

    WebDriver driver;

    public DataProcessingHomePage(WebDriver driver){

        this.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(linkText = "Random Nth")
    WebElement RandomNth_Btn;

    @Step ("Clicked Random Nth button")
    public void clickRandomNthButton(){
        RandomNth_Btn.click();
    }

    @Step("Fetched Process Status for Random Nth Process")
    public String GetProcessStatus()
    {
        String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
        return status;
    }

    @Step("Selected Duplicate for Random Nth Process")
    public void selectDuplicateRNTH()
    {
        driver.findElement(By.xpath("(//img[@alt='gearbox'])[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Duplicate')]"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        //driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Duplicate')]")));
        element.click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle"))) {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//a[@id='dup-row']")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }

    @Step("Selected Edit for Random Nth Process")
    public void clickOnEditRTH(){
        driver.findElement(By.xpath("(//img[@alt='gearbox'])[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Edit')]"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Edit')]")));
        element.click();
       // driver.findElement(By.xpath("//li[contains(text(),'Edit')]")).click();
    }

    @Step("Selected Summary For Random Nth Process")
    public void selectSummaryRNTH()
    {
        driver.findElement(By.xpath("(//img[@alt='gearbox'])[1]")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Summary')]"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Summary')]")));
        element.click();
        //driver.findElement(By.xpath("//li[contains(text(),'Summary')]")).click();

    }
    @Step("Selected Duplicate for DataProcessing Process")
    public void selectDuplicate()
    {
        driver.findElement(By.xpath(".//table[@id='dnsTable']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle"))) {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath(".//a[@id='dup-row']")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }

    @Step("Selected Edit for DataProcessing Process")
    public void clickOnEdit(){
        driver.findElement(By.xpath(".//table[@id='dnsTable']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Edit"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        driver.findElement(By.id("Edit")).click();
    }

    @Step("Selected Summary for DataProcessing Process")
    public void selectSummary()
    {

        driver.findElement(By.xpath(".//table[@id='dnsTable']/tbody/tr[1]/td[1]/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Summary"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Summary")).click();

    }
    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }
}

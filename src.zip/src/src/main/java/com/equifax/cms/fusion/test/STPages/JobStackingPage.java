package com.equifax.cms.fusion.test.STPages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class JobStackingPage
{
    WebDriver driver;

    public JobStackingPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//label[@class='fieldTitle']")
    public WebElement stack_procName_ele;

    @FindBy(id = "btnSave")
    WebElement stack_save_ele;

    @FindBy(id = "btnSubmit")
    WebElement stack_submit_ele;

    @FindBy(id = "processName")
    WebElement processName_field;

    @FindBy(id = "btnShowFlowchart")
    WebElement click_Open_Flow_Chart;

    public String getAssignedId()
    {
        String id=stack_procName_ele.getText();
        String[] assignedIdArr=id.split(":");

        return assignedIdArr[1].trim();
    }


    public void inputStackName(String name)
    {
        processName_field.clear();
        processName_field.sendKeys(name);
    }

    public void selectProcessCheckBox(String processName)
    {
        driver.findElement(By.xpath(".//*[contains(text(),'" + processName + "')]//preceding::input[1]")).click();

    }


    @Step("Fetching the Error Msg ")
    // Fetches the errMsg when submitting process with shipping without QC approval or submitting shipping whose input does not exist
    public String getTheErrorMessageFromTheJobStackingScreen()
    {
        String errMsg = driver.findElement(By.xpath("//div[@class='errMsg']//span[@id='textMsg']")).getText();
        return errMsg;

    }

    @Step("Validating whether process is present or not in JobStacking screen")
    public boolean isProcessPresent(String processName)
    {
        boolean isProcessPresent = driver.findElement(By.xpath(".//*[contains(text(),'" + processName + "')]")).isDisplayed();
        return isProcessPresent;

    }
    public void selectProcessFromDropdown(String processName) throws InterruptedException
    {
        String[] procArr=processName.split(":");
        String updatedProcName=procArr[0]+" "+"-"+" "+procArr[1];
        Thread.sleep(3500);
        driver.findElement(By.xpath("//li[contains(text(),'" + updatedProcName + "')]")).click();
    }



    //Job Stacking Changes As Per The New Functionality
    //Following are the steps to be followed to select Process and submit process/processes In Jobstacking
    //1."clickProcessDropDown"--To open the Process drop down.
    //2."clickOpenFlowChart"--To open the Process drop down.
    //3."selectTheProcessFromTheFlowChart"--Selects the process/processes from the flow chart. Takes list of process which needs to be selected as parameter.
    //4."clickJobStackingSubmitButton"--Submits the stack with selected process
    @Step("Click On The Process Drop Down Button")
    public void clickProcessDropDown() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[contains(text(),'Select one or more flows')]")).click();
        Thread.sleep(3000);

    }

    @Step("Click On The Open Flow Chart Button")
    public void clickOpenFlowChart() throws InterruptedException
    {

        click_Open_Flow_Chart.click();
        Thread.sleep(2500);;
    }
    @Step("Selecting Processes From The Flow Chart")
    public void selectTheProcessFromTheFlowChart(List<String> processName,int timeout) throws InterruptedException

    {
    	Thread.sleep(1500);
    	waitForLoad(timeout);
    	Thread.sleep(2500);
        for(String process:processName)
        {
            //String updatedProcName=process.replaceAll(":","-");
            String[] updatedProcName=process.split(":");
            driver.findElement(By.xpath("//div[starts-with(text(),'"+updatedProcName[0]+"')]/parent::div")).click();
        }
        Thread.sleep(2000);
        stack_save_ele.click();
        Thread.sleep(3500);
        waitForLoad(timeout);
        Thread.sleep(2000);
        System.out.println("Stacking process successfully saved");

    }
    @Step("Clicked Job Stacking Submit Button")
    public void clickJobStackingSubmitButton() throws InterruptedException
    {
        stack_submit_ele.click();
        Thread.sleep(2000);
        //waitForLoad(30);
        
        System.out.println("Process submitted successfully");
        //Thread.sleep(2000);


    }
    public void waitForLoad(int timeout)
    {
    	
    	  while (driver.findElement(By.xpath("//div[@id='jqxLoader']"))
                  .getCssValue("display").equalsIgnoreCase("block")) 
    	  {
              timeout = timeout + 30;
              driver.manage().timeouts()
              .implicitlyWait(timeout, TimeUnit.SECONDS);
          }

    }
}

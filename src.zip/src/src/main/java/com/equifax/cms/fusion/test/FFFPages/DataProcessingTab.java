package com.equifax.cms.fusion.test.FFFPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataProcessingTab {
    WebDriver driver;
    public Select selType;

    public DataProcessingTab(WebDriver driver){

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@id='dataprocessing']/a")
    WebElement DataProcessingHomeTab;

   

    @FindBy(linkText = "Full File Fixed")
    WebElement FFF_Button;
    
    @Step("Clicked Data Processing Tab")
    public void clickDataProcessingTab(){
        DataProcessingHomeTab.click();
    }

    @Step("Fetched Process Status for DNS Process")
    public String getProcessStatus()
    {
        String status = driver.findElement(By.xpath("//table[@id='dnsTable']/tbody/tr[1]/td[3]")).getText();
        return status;
    }
    @Step("Fetched Process Status for DNS Process")
    public String getProcessStatusNew()
    {
        String status = driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div/div[3]/div[1]")).getText();
        return status;
    }


    @Step("Clicked FFF Button")
    public void clickFFFButton(){
        FFF_Button.click();
    }
    @Step("Clicked On FFF Button")
    public void clickOnFFFButton(){
        FFF_Button.click();
    }
    @Step("Clicked Duplicate for FFF Process")
    public void selectDuplicateFFF()
    {
        driver.findElement(By.xpath(".//table[@id='dnsTable']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate"))) {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle"))) {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath("//a[contains(text(),'OK')]")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }


    }

    @Step("Clicked Summary For FFF Process")
    public void selectSummaryFFF()
    {

    	driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div[1]/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(10000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
    }
    @Step("Clicked Edit For FFF Process")
    public void selectEditFFF() throws InterruptedException
    {

    	driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']//parent::div/div[1]//img[1]")).click();
    	Thread.sleep(2500);
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                   	Thread.sleep(2500);
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
    }
    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }
}

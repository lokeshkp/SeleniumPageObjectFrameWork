package com.equifax.cms.fusion.test.REPORTINGPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SASStats
{
    WebDriver driver;

    public SASStats(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    public void clickParamFileLink()
    {
        driver.findElement(By.xpath("//a[contains(text(),'PARAM_FILE')]")).click();
    }

    public String getContent()
    {
        return driver.findElement(By.xpath("//body/div/div/pre/div")).getText();

    }
}

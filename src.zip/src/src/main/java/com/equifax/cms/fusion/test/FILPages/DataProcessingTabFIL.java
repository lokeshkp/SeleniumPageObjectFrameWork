package com.equifax.cms.fusion.test.FILPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class DataProcessingTabFIL {
	WebDriver driver;
	public Select selType;
	
	public DataProcessingTabFIL(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		PageFactory.initElements(driver, this);
	}
	
	@FindBy(xpath = ".//*[@id='dataprocessing']/a")
	WebElement DataProcessingHomeTab;
	
	@FindBy(linkText = "Filtering")
	WebElement FILButton;
	
	@Step("Clicked Data Processing Tab")
	public void clickDataProcessingTab(){
		DataProcessingHomeTab.click();
	}
	
	@Step("Clicked Filtering Button")
	public void clickFilteringButton(){
		FILButton.click();
	}
	
	@Step("Fetched Filtering Process Status")
	public String getProcessStatus()
    {
        String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
        return status;
    }
	
	@Step("Selected Duplicate for Filtering Process")
	public void selectDuplicateFIL()
    {
        driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
				fail("timeout");
			}
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Duplicate')]"))) {
					break;
				}
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        //driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Duplicate')]")));
        element.click();
    
        for (int second = 0;; second++)
        {
            if (second >= 20) {
				fail("timeout");
			}
            try
            {
                if (isElementPresent(By.id("popupTitle"))) {
					break;
				}
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.id("dup-row")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    
		
    }
	
	@Step("Selected Summary for Filtering Process")
	public void selectSummaryFIL()
    {

        driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20) {
				fail("timeout");
			}
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]"))) {
					break;
				}
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        //driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'View Summary')]")));
        element.click();
    
    }
	
	@Step("Selected Edit for Filtering Process")
	public void selectEditFIL()
    {
        driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20) {
				fail("timeout");
			}
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Edit')]"))) {
					break;
				}
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        //driver.findElement(By.xpath("//li[contains(text(),'Edit')]")).click();
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Edit')]")));
        element.click();
    
    }
	
	
	private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    
    }
}

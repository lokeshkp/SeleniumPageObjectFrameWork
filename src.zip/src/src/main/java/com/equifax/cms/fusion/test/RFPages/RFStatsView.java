package com.equifax.cms.fusion.test.RFPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.RNPages.RnStatsView;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class RFStatsView
{
    WebDriver driver;
    ProjectDashBoardPage ProjDashBoardPage;

    public RFStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

    }

    @Step("Fetched Header Table Name")
    public String getHdrTbleNameRF()
    {
        String rfHDRtbleName = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_HEADER')]")).getText();
        return removeColon(rfHDRtbleName);
    }

    @Step("Fetched Header Table Count")
    public Long getHDRtbleCountRF()
    {
        String rfHDRtbleCount = driver.findElement(By.xpath("//div[contains(text(),'_DM_GPLOAD_HEADER')]//following::div[1]")).getText();
        return Long.parseLong(rfHDRtbleCount);
    }

    // NHHD
    @Step("Fetched Negative Household Drop Input Table Name")
    public String getNHHDInputTableNameRF()
    {
        String RfNHHDInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'Negative Household Drop')])[1]/following::div[6]"))
                .getText();
        return removeColon(RfNHHDInputTableName);
    }

    @Step("Fetched Negative Household Drop Input Table Count")
    public Long getNHHDInputTableCountRF()
    {
        String RfNHHDInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'Negative Household Drop')])[1]/following::div[7]"))
                .getText();
        return Long.parseLong(removeComma(RfNHHDInputTableCount));
    }

    @Step("Fetched NHHD Total Accept records Count")
    public Long getNHHDtotalAccCountRF()
    {
        String RfNHHDtotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPNHHD_RFNHHDTBL')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfNHHDtotalAccCount));
    }

    @Step("Fetched NHHD Total Reject records Count")
    public Long getNHHDtotalRejCountRF()
    {
        String RfNHHDtotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPNHHD_RFNHHDTBL')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfNHHDtotalRejCount));
    }

    @Step("Fetched NHHD Total Bypass records Count")
    public Long getNHHDtotalBypassCountRF()
    {
        String RfNHHDtotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPNHHD_RFNHHDTBL')])[1]/preceding::div[7]"))
                .getText();
        return Long.parseLong(removeComma(RfNHHDtotalBypassCount));
    }

    @Step("Fetched NHHD Total Output records Count")
    public Long getNHHDtotalOutputCountRF()
    {
        String RfNHHDtotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPNHHD_RFNHHDTBL')])[1]/preceding::div[4]"))
                .getText();
        return Long.parseLong(removeComma(RfNHHDtotalOutputCount));
    }

    // Regular Household Drop
    @Step("Fetched Regular Household Drop Input Table Name")
    public String getRegHHDInputTableNameRF()
    {
        String RfRegHHDInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'Regular Household Drop')])[1]/following::div[6]"))
                .getText();
        return removeColon(RfRegHHDInputTableName);
    }

    @Step("Fetched Regular Household Drop Input Table Count")
    public Long getRegHHDInputTableCountRF()
    {
        String RfRegHHDInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'Regular Household Drop')])[1]/following::div[7]"))
                .getText();
        return Long.parseLong(removeComma(RfRegHHDInputTableCount));
    }

    @Step("Fetched Regular HHD Total Accept records Count")
    public Long getRegHHDtotalAccCountRF()
    {
        String RfRegHHDtotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDDROP')])[1]/preceding::div[16]")).getText();
        return Long.parseLong(removeComma(RfRegHHDtotalAccCount));
    }

    @Step("Fetched Regular HHD Total Reject records Count")
    public Long getRegHHDtotalRejCountRF()
    {
        String RfRegHHDtotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDDROP')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfRegHHDtotalRejCount));
    }

    @Step("Fetched Regular HHD Total Bypass records Count")
    public Long getRegHHDtotalBypassCountRF()
    {
        String RfRegHHDtotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDDROP')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfRegHHDtotalBypassCount));
    }

    @Step("Fetched Regular HHD Total Output records Count")
    public Long getRegHHDtotalOutputCountRF()
    {
        String RfRegHHDtotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDDROP')])[1]/preceding::div[7]")).getText();
        return Long.parseLong(removeComma(RfRegHHDtotalOutputCount));
    }

    // Household Split
    @Step("Fetched Household Split Input Table Name")
    public String getHHsplitInputTableNameRF()
    {
        String RfHHsplitInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'Household Split')])[1]/following::div[6]")).getText();
        return removeColon(RfHHsplitInputTableName);
    }

    @Step("Fetched Household Split Input Table Count")
    public Long getHHsplitInputTableCountRF()
    {
        String RfHHsplitInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'Household Split')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfHHsplitInputTableCount));
    }

    @Step("Fetched HH Split Total Accept records Count")
    public Long getHHsplitTotalAccCountRF()
    {
        String RfHHsplitTotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDSPLIT')])[1]/preceding::div[16]")).getText();
        return Long.parseLong(removeComma(RfHHsplitTotalAccCount));
    }

    @Step("Fetched HH Split Total Reject records Count")
    public Long getHHsplitTotalRejCountRF()
    {
        String RfHHsplitTotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDSPLIT')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfHHsplitTotalRejCount));
    }

    @Step("Fetched HH Split Total Bypass records Count")
    public Long getHHsplitTotalBypassCountRF()
    {
        String RfHHsplitTotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDSPLIT')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfHHsplitTotalBypassCount));
    }

    @Step("Fetched HH Split Total Output records Count")
    public Long getHHsplitTotalOutputCountRF()
    {
        String RfHHsplitTotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPHHDSPLIT')])[1]/preceding::div[7]")).getText();
        return Long.parseLong(removeComma(RfHHsplitTotalOutputCount));
    }

    // HH Customer Elimination
    @Step("Fetched CE Input Table Name")
    public String getCEInputTableNameRF()
    {
        String RfRegCEInputTableName = driver
                .findElement(By.xpath("(.//div[contains(text(),'HouseHold Customer Elimination')])[1]/following::div[6]")).getText();
        return removeColon(RfRegCEInputTableName);
    }

    @Step("Fetched CE Input Table Count")
    public Long getCEInputTableCountRF()
    {
        String RfRegCEInputTableCount = driver
                .findElement(By.xpath("(.//div[contains(text(),'HouseHold Customer Elimination')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfRegCEInputTableCount));
    }

    @Step("Fetched CE Total Accept records Count")
    public Long getCEtotalAccCountRF()
    {
        String RfCEtotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCEHHD_RFCEHHDTBL')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfCEtotalAccCount));
    }

    @Step("Fetched CE Total Reject records Count")
    public Long getCEtotalRejCountRF()
    {
        String RfCEtotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCEHHD_RFCEHHDTBL')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfCEtotalRejCount));
    }

    @Step("Fetched CE Total Bypass records Count")
    public Long getCEtotalBypassCountRF()
    {
        String RfCEtotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCEHHD_RFCEHHDTBL')])[1]/preceding::div[7]"))
                .getText();
        return Long.parseLong(removeComma(RfCEtotalBypassCount));
    }

    @Step("Fetched CE Total Output records Count")
    public Long getCEtotalOutputCountRF()
    {
        String RfCEtotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCEHHD_RFCEHHDTBL')])[1]/preceding::div[4]"))
                .getText();
        return Long.parseLong(removeComma(RfCEtotalOutputCount));
    }

    // CID Suppression
    @Step("Fetched CID Suppression Input Table Name")
    public String getCIDSupInputTableNameRF()
    {
        String RfCIDsupInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'CID Suppression')])[1]/following::div[6]")).getText();
        return removeColon(RfCIDsupInputTableName);
    }

    @Step("Fetched CID Suppression Input Table Count")
    public Long getCIDSupInputTableCountRF()
    {
        String RfCIDsupInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'CID Suppression')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfCIDsupInputTableCount));
    }

    @Step("Fetched CID Suppression Total Accept records Count")
    public Long getCIDsupTotalAccCountRF()
    {
        String RfCIDsupTotalAccCount;
        try
        {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            RfCIDsupTotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[1]/preceding::div[13]"))
                    .getText();
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        } catch (Exception e)
        {
            RfCIDsupTotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[2]/preceding::div[13]"))
                    .getText();
        }
        return Long.parseLong(removeComma(RfCIDsupTotalAccCount));
    }

    @Step("Fetched CID Suppression Total Reject records Count")
    public Long getCIDsupTotalRejectCountRF()
    {
        String RfCIDsupTotalRejCount;
        try
        {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            RfCIDsupTotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[1]/preceding::div[10]"))
                    .getText();
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        } catch (Exception e)
        {
            RfCIDsupTotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[2]/preceding::div[10]"))
                    .getText();
        }
        return Long.parseLong(removeComma(RfCIDsupTotalRejCount));
    }

    @Step("Fetched CID Suppression Total Bypass records Count")
    public Long getCIDsupTotalBypassCountRF()
    {
        String RfCIDsupTotalBypassCount;
        try
        {
            RfCIDsupTotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[1]/preceding::div[7]"))
                    .getText();
        } catch (Exception e)
        {
            RfCIDsupTotalBypassCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[2]/preceding::div[7]"))
                    .getText();

        }
        return Long.parseLong(removeComma(RfCIDsupTotalBypassCount));
    }

    @Step("Fetched CID Suppression Total Output records Count")
    public Long getCIDsupTotalOutputCountRF()
    {
        String RfCIDsupTotalOutputCount;
        try
        {
            RfCIDsupTotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[1]/preceding::div[4]"))
                    .getText();
        } catch (Exception e)
        {
            RfCIDsupTotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPCIDSUPP_RFCIDSUPPTBL')])[2]/preceding::div[4]"))
                    .getText();
        }
        return Long.parseLong(removeComma(RfCIDsupTotalOutputCount));
    }

    // SSN Suppression Table Name: SSN Suppression & Name value: 6, Count value: 7
    // SSN Suppression table Name: "_RF_GPSSNSUPP2_RFSSNSUPPTBL" & value Acc:13, Rej:10, Bypass:7, Output:4
    @Step("Fetched SSN Suppression Input Table Name")
    public String getSSNSupInputTableNameRF()
    {
        String RfSSNsupInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'SSN Suppression')])[1]/following::div[6]")).getText();
        return removeColon(RfSSNsupInputTableName);
    }

    @Step("Fetched SSN Suppression Input Table Count")
    public Long getSSNSupInputTableCountRF()
    {
        String RfSSNsupInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'SSN Suppression')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfSSNsupInputTableCount));
    }

    @Step("Fetched SSN Suppression Total Accept records Count")
    public Long getSSNsupTotalAccCountRF()
    {
        String RfSSNsupTotalAccCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPSSNSUPP2_RFSSNSUPPTBL')])[1]/preceding::div[13]"))
                .getText();
        return Long.parseLong(removeComma(RfSSNsupTotalAccCount));
    }

    @Step("Fetched SSN Suppression Total Reject records Count")
    public Long getSSNsupTotalRejCountRF()
    {
        String RfSSNsupTotalRejCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPSSNSUPP2_RFSSNSUPPTBL')])[1]/preceding::div[10]"))
                .getText();
        return Long.parseLong(removeComma(RfSSNsupTotalRejCount));
    }

    @Step("Fetched SSN Suppression Total Bypass records Count")
    public Long getSSNsupTotalBypasCountRF()
    {
        String RfSSNsupTotalBypasCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPSSNSUPP2_RFSSNSUPPTBL')])[1]/preceding::div[7]"))
                .getText();
        return Long.parseLong(removeComma(RfSSNsupTotalBypasCount));
    }

    @Step("Fetched SSN Suppression Total Bypass records Count")
    public Long getSSNsupTotalOutputCountRF()
    {
        String RfSSNsupTotalOutputCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPSSNSUPP2_RFSSNSUPPTBL')])[1]/preceding::div[4]"))
                .getText();
        return Long.parseLong(removeComma(RfSSNsupTotalOutputCount));
    }

    /* String nameArr = driver.findElement(By.xpath("//div[starts-with(text(),'Total Records Output')]/following::div[1]")).getText(); */
    @Step("Fetched The Output Table Name For The SSN Suppression")
    public String getSSNSuppOutputTableName()
    {
        String[] nameArr = driver.findElement(By.xpath("//div[starts-with(text(),'Output Table')]")).getText().split(":");
        String outputTableName = nameArr[1];
        return outputTableName;

    }

    @Step("Fetched The Total Records Suppressed For The SSN Suppression")
    public String getSuppressedRecords()
    {
        String suppRecords = driver.findElement(By.xpath("//div[starts-with(text(),'Total Suppressed Records')]/following::div[1]")).getText();

        return suppRecords;

    }

    @Step("Fetched The Input Table Name For The SSN Suppression")
    public String getSSNSuppInputTableName()
    {
        String inputTableName = driver.findElement(By.xpath("//div[starts-with(text(),'Input Table')]/parent::div/following::div[1]/div[1]"))
                .getText();

        return inputTableName;

    }

    @Step("Fetched SSN Suppression Total Record Count")
    public Long getSSNSupTotalOutputRecordCountRF()
    {
        String RfSSNsupTotalOutputRecordCount = driver.findElement(By.xpath("//div[starts-with(text(),'Total Records Output')]/following::div[1]"))
                .getText();
        return Long.parseLong(removeComma(RfSSNsupTotalOutputRecordCount));
    }

    // CID Dedupe Table Name: CID Dedupe & Name value: 6, Count value: 7
    @Step("Fetched CID Dedupe Input Table Name")
    public String getCIDdedupeInputTableNameRF()
    {
        String RfCIDdedupeInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'CID Dedupe')])[1]/following::div[6]")).getText();
        return removeColon(RfCIDdedupeInputTableName);
    }

    @Step("Fetched CID Dedupe Input Table Count")
    public Long getCIDdedupeInputTableCountRF()
    {
        String RfCIDdedupeInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'CID Dedupe')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfCIDdedupeInputTableCount));
    }

    @Step("Fetched CID Dedupe Total Accept records Count")
    public Long getCIDdedupeTotalAccCountRF()
    {
        String RfCIDdedupeTotalAccCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPCID_RFDEDUPCIDTBL')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfCIDdedupeTotalAccCount));
    }

    @Step("Fetched CID Dedupe Total Reject records Count")
    public Long getCIDdedupeTotalRejCountRF()
    {
        String RfCIDdedupeTotalRejCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPCID_RFDEDUPCIDTBL')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfCIDdedupeTotalRejCount));
    }

    @Step("Fetched CID Dedupe Total Bypass records Count")
    public Long getCIDdedupeTotalBypasCountRF()
    {
        String RfCIDdedupeTotalBypasCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPCID_RFDEDUPCIDTBL')])[1]/preceding::div[7]")).getText();
        return Long.parseLong(removeComma(RfCIDdedupeTotalBypasCount));
    }

    @Step("Fetched CID Dedupe Total Output records Count")
    public Long getCIDdedupeTotalOutputCountRF()
    {
        String RfCIDdedupeTotalOutputCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPCID_RFDEDUPCIDTBL')])[1]/preceding::div[4]")).getText();
        return Long.parseLong(removeComma(RfCIDdedupeTotalOutputCount));
    }

    @Step("Fetched the Custom Dedupe Output table name")
    public String getCustomDedupeTbleName()
    {
        String rfCustDedupTbleName = driver.findElement(By.xpath("//div[contains(text(),'_RF_GPDEDUPCUST_RFDEDUPCUSTTBL')]")).getText();
        return removeColon1(rfCustDedupTbleName);
    }

    @Step("Fetched the Custom Dedupe Output table count")
    public Long getCustomDedupeTbleCount()
    {
        String rfCustDedupTbleCount = driver.findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPCUST_RFDEDUPCUSTTBL')])[1]/preceding::div[13]"))
                .getText();
        return Long.parseLong(removeComma(rfCustDedupTbleCount));
    }

    // SSN Dedupe Table Name: SSN Dedupe & Name: 6, value: 7
    @Step("Fetched SSN Dedupe Input Table Name")
    public String getSSNdedupeInputTableNameRF()
    {
        String RfSSNdedupeInputTableName = driver.findElement(By.xpath("(.//div[contains(text(),'SSN Dedupe')])[1]/following::div[6]")).getText();
        return removeColon(RfSSNdedupeInputTableName);
    }

    @Step("Fetched SSN Dedupe Input Table Count")
    public Long getSSNdedupeInputTableCountRF()
    {
        String RfSSNdedupeInputTableCount = driver.findElement(By.xpath("(.//div[contains(text(),'SSN Dedupe')])[1]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RfSSNdedupeInputTableCount));
    }

    @Step("Fetched SSN Dedupe Total Accept records Count")
    public Long getSSNdedupeTotalAccCountRF()
    {
        String RfSSNdedupeTotalAccCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPSSN_RFDEDUPSSNTBL')])[1]/preceding::div[13]")).getText();
        return Long.parseLong(removeComma(RfSSNdedupeTotalAccCount));
    }

    @Step("Fetched SSN Dedupe Total Reject records Count")
    public Long getSSNdedupeTotalRejCountRF()
    {
        String RfSSNdedupeTotalRejCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPSSN_RFDEDUPSSNTBL')])[1]/preceding::div[10]")).getText();
        return Long.parseLong(removeComma(RfSSNdedupeTotalRejCount));
    }

    @Step("Fetched SSN Dedupe Total Bypass records Count")
    public Long getSSNdedupeTotalBypasCountRF()
    {
        String RfSSNdedupeTotalBypasCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPSSN_RFDEDUPSSNTBL')])[1]/preceding::div[7]")).getText();
        return Long.parseLong(removeComma(RfSSNdedupeTotalBypasCount));
    }

    @Step("Fetched SSN Dedupe Total Output records Count")
    public Long getSSNdedupeTotalOutputCountRF()
    {
        String RfSSNdedupeTotalOutputCount = driver
                .findElement(By.xpath("(.//*[contains(text(),'_RF_GPDEDUPSSN_RFDEDUPSSNTBL')])[1]/preceding::div[4]")).getText();
        return Long.parseLong(removeComma(RfSSNdedupeTotalOutputCount));
    }

    @Step("Fetched Total Accept records for custom dedupe")
    public Long getAccRecCustDedCount()
    {
        String getAccRecforCustDedCount = driver.findElement(By.xpath("//div[contains(text(),'Total Accept Records')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(getAccRecforCustDedCount));
    }

    @Step("Fetched Total Reject Records for custom dedupe")
    public Long getRejRecCustDedCount()
    {
        String getRejRecforCustDedCount = driver.findElement(By.xpath("//div[contains(text(),'Total Reject Records Kept')]//following::div[1]"))
                .getText();
        return Long.parseLong(removeComma(getRejRecforCustDedCount));
    }

    public static String removeColon(String a)
    {
        String[] a1 = a.split(":");
        return a1[0].trim();
    }

    public static String removeColon1(String a)
    {
        String[] a1 = a.split(":");
        return a1[1].trim();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching Total Reject Records Dropped From Green Plum for Table = \"{0}\"")
    public long getRejRecDroppedFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + query + "where nhhd_flag = 'D'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Accept & Reject Records From Green Plum for Table = \"{0}\"")
    public long getAccRejRecFromGP(String table, String fldName, String falg) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where " + fldName + " = '" + falg + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of SSN Matched Records From GreenPlum")
    public long getCountOfSSNMatchedRecordsFromGP(String inputTableName, String suppInputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + inputTableName + " dmHeader,fusion_stage." + suppInputTableName
                + " ip where dmHeader.mdb_ssn=ip.ssn and  dmHeader.fail_code is null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of CID Matched Records From GreenPlum")
    public long getCountOfCIDMatchedRecordsFromGP(String inputTableName, String suppInputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + inputTableName + " dmHeader,fusion_stage." + suppInputTableName
                + " ip where dmHeader.cid=ip.cid1 and  dmHeader.fail_code is null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of CID Matched Records From GreenPlum")
    public long getCountOfCustMatchedRecordsFromGP(String inputTableName, String suppInputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + inputTableName + " dmHeader where dmHeader.state in(select ip.state from fusion_stage."
                + suppInputTableName + " ip) and fail_code is null ";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForTagOrRejectsAsRecordStatusForSSNOptionForAcceptRecordType(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='R' and fail_code is null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForTagOrRejectsAsRecordStatusForCIDOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cid_supp_flag='R'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForTagOrRejectsAsRecordStatusForCustSuppOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cust_supp_flag='R'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForDropAsRecordStatusForSSNOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='D'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForDropAsRecordStatusForCIDOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cid_supp_flag='D'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForRefinmentTableWhenSSNSelected(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag is not null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForRefinmentTableWhenCIDSelected(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cid_supp_flag is not null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForRefinmentTableWhenCustomSelected(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cust_supp_flag is not null";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPInputTable(String inputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + inputTableName + "";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPOutputTable(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + "";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsFromTheGPForSSNMatch(String outputTableName, String inputTableName, String suppTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + suppTableName + " ip where ip.ssn in(select dm.mdb_ssn from fusion_stage." + inputTableName
                + " dm,fusion_stage." + outputTableName
                + " Rfn where Rfn.dp_sequence_num=dm.dp_sequence_num and rfn.ssn_supp_flag is not null and dm.fail_code is null)and ip.ssn is not null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }



    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsFromTheGPForCIDMatch(String outputTableName, String inputTableName, String suppTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + suppTableName + " ip where ip.cid1 in(select dm.cid from fusion_stage." + inputTableName
                + " dm,fusion_stage." + outputTableName
                + " Rfn where Rfn.dp_sequence_num=dm.dp_sequence_num and rfn.cid_supp_flag is not null and dm.fail_code is null)and ip.cid1 is not null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhoseFailCodeIsNotNull(String inputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + inputTableName + " where fail_code is not null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhoseSSNSuppFlagIsNull(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag is null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhoseCIDSuppFlagIsNull(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + outputTableName + " where cid_supp_flag is null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhichAreNotSuppressedForSSNOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='A'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhichAreNotSuppressedForCIDOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + outputTableName + " where cid_supp_flag='A'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsFromInputTableWhoseFailCodeIsNull(String inputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  count(*) from fusion_stage." + inputTableName + " where Fail_code is null";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsNotSuppressedForSSNOption(String inputTableName, String suppTableName) throws SQLException
    {
        Long recordCntFrmInputTable = getCountOfRecordsFromInputTableWhoseFailCodeIsNull(inputTableName);
        Long SSNMatchedCount = getCountOfSSNMatchedRecordsFromGP(inputTableName, suppTableName);
        Long recordNtSuppressed = recordCntFrmInputTable - SSNMatchedCount;

        return recordNtSuppressed;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsNotSuppressedForCIDOption(String inputTableName, String suppTableName) throws SQLException
    {
        Long recordCntFrmInputTable = getCountOfRecordsFromInputTableWhoseFailCodeIsNull(inputTableName);
        Long CIDMatchedCount = getCountOfCIDMatchedRecordsFromGP(inputTableName, suppTableName);
        Long recordNtSuppressed = recordCntFrmInputTable - CIDMatchedCount;

        return recordNtSuppressed;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForSSNOption(String inputTableName, String suppTableName,String rejects) throws SQLException
    {
        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";
        Connection conn = gpConnect();
        String query1;
        query1 = " select count(*) from fusion_stage." + inputTableName + " dmHeader,fusion_stage." + suppTableName
                + " ip where dmHeader.mdb_ssn=ip.ssn and  dmHeader.fail_code in " + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForCIDOption(String inputTableName, String suppTableName,String rejects) throws SQLException
    {
        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";
        Connection conn = gpConnect();
        String query1;
        query1 = " select count(*) from fusion_stage." + inputTableName + " dmHeader,fusion_stage." + suppTableName
                + " ip where dmHeader.cid=ip.cid1 and  dmHeader.fail_code in " + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsSuppressedWhenFailCodeIsNotNullForSSNOption(String outputTableName,String rejects) throws SQLException
    {
        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";
        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='R' and fail_code in" + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsSuppressedWhenFailCodeIsNotNullForCIDOption(String outputTableName,String rejects) throws SQLException
    {

        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";

        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where cid_supp_flag='R' and fail_code in" + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForRejectAsRecordStatusAndFailCodeIsNotNullForSSNSupp(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where fail_code='RS' and ssn_supp_flag='R'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForRejectAsRecordStatusAndFailCodeIsNotNullForCIDSupp(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where fail_code='RS' and cid_supp_flag='R'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForDropAsRecordStatusAndFailCodeIsNotNullForSSNOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='D' and fail_code='RS'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForDropAsRecordStatusAndFailCodeIsNotNullForCIDOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + outputTableName + " where cid_supp_flag='D' and fail_code='RS'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsSuppressedWhenDropSelectedWithRejectAsRecordTypesForSSNOption(String outputTableName,String rejects) throws SQLException
    {
        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";
        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where ssn_supp_flag='D' and fail_code in " + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsSuppressedWhenDropSelectedWithRejectAsRecordTypesForCIDOption(String outputTableName,String rejects) throws SQLException
    {
        String arr[] = rejects.split(",");

        String join = "'" + StringUtils.join(arr, "','") + "'";
        Connection conn = gpConnect();
        String query1;
        query1 = "select  COUNT(*) from fusion_stage." + outputTableName + " where cid_supp_flag='D' and fail_code in" + "" + "(" + join + ")";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }
    // div[text()='Output Table:']/parent::div/following::div[1]/div[1]

    @Step("Get The Table Name for Supp file Process")
    public String getTheTableNameForSuppFileProcess()
    {
        return driver.findElement(By.xpath("//div[text()='Output Table:']/parent::div/following::div[1]/div[1]")).getText();
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getCountOfRecordsWhichIsToBeSuppressed(String inputTableName, String suppTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "SELECT count(*) FROM  fusion_stage." + inputTableName + " where dp_sequence_num in(select dp_sequence_num from fusion_stage."
                + suppTableName + "where group_name='RegAuto_Grp1'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }

    @Step("Fetching Total Count of Records From Green Plum for Table = \"{0}\"")
    public long getRecordCountFromGPForTagOrRejectsAsRecordStatusForSSNOption(String outputTableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "SELECT count(*) FROM  fusion_stage." + outputTableName + "where ssn_supp_flag='R'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }

        conn.close();
        return records;
    }
    @Step("Fetched Refinement Table Name For SSN Suppression")
    public String getRefinementTableName(String processName,String suppType) throws InterruptedException
    {
        String[] inputProcNameArr=processName.split(":");
        String processNameForStats=inputProcNameArr[0]+"_"+inputProcNameArr[1];
        String procNameColon=inputProcNameArr[0]+":"+inputProcNameArr[1];
        String tableName = null;
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
        Thread.sleep(1500);
       driver.findElement(By.xpath("//span[contains(text(),'" + procNameColon + "')]/preceding::span[1]")).click();
       Thread.sleep(1500);
       
        if("SSN Suppression".equalsIgnoreCase(suppType))
        {
            String jobid = driver.findElement(By.xpath("//span[contains(text(),'GPSSNSUPP')]/parent::td/following::td[1]")).getText();
            tableName = "I" + jobid + "_RF_GPSSNSUPP2_RFSSNSUPPTBL";
        }
        else if("CID Suppression".equalsIgnoreCase(suppType))
        {
            String jobid = driver.findElement(By.xpath("//span[contains(text(),'GPCIDSUPP')]/parent::td/following::td[1]")).getText();
            tableName = "I" + jobid + "_RF_GPCIDSUPP_RFCIDSUPPTBL";
        }
        else if("Custom Suppression".equalsIgnoreCase(suppType))
        {
            String jobid = driver.findElement(By.xpath("//span[contains(text(),'GPCUSTSUPP')]/parent::td/following::td[1]")).getText();
            tableName = "I" + jobid + "_RF_GPCUSTSUPP_RFCUSTSUPPTBL";
        }

        return tableName;
    }
    
    public static String removeComma(String a)
    {
        String a2="";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2=a2+element;
        }
        return a2;
    }
    @Step("Fetching the Output Table Name ForIP")
    public String getTheOutputTableNameForIP(String processNameForStats,String processNameWithColon) throws InterruptedException
    { 
    	String[] processName=processNameWithColon.split(":");
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName[0]);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
   Thread.sleep(1000);
    driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
   driver.findElement(By.xpath("//span[contains(text(),'" + processNameWithColon + "')]/preceding::span[1]")).click();
   String itemNo=driver.findElement(By.xpath("//span[contains(text(),'IN_GPLOAD')]/parent::td/parent::tr//td[3]")).getText().trim();
    
   String tableName = "I" + itemNo + "_IN_GPLOAD_INPUT";;
return tableName;
    	
    }
}

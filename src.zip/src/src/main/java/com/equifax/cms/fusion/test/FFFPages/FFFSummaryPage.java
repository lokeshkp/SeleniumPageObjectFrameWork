package com.equifax.cms.fusion.test.FFFPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class FFFSummaryPage {

	WebDriver driver;
	
	public FFFSummaryPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "submitButton")
	WebElement submitButton;

	@Step ("Click Submit button")
	public void clickSubmitButton(){
		submitButton.click();
	}
	
}


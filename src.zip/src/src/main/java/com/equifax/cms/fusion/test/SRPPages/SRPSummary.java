package com.equifax.cms.fusion.test.SRPPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

public class SRPSummary
{
    WebDriver driver;

    public SRPSummary(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @Step("Select Process Name")
    public String getProcessName()
    {
        return driver.findElement(By.xpath("//table[@id='smDataTable']/tbody/tr/td[1]")).getText();
    }

    @Step("Select Job Value")
    public String getJobNumber()
    {
        return driver.findElement(By.xpath("table[@id='smDataTable']/tbody/tr/td[2]")).getText();
    }

    @Step("Select Data Value")
    public String getData()
    {
        return driver.findElement(By.xpath("//table[@id='smDataTable']/tbody/tr/td[3]")).getText();
    }
    
    public void clickSubmitBtn() {
        driver.findElement(By.id("Submit")).click();
    }

}

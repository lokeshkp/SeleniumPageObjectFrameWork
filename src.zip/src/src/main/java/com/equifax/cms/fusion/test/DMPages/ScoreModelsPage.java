package com.equifax.cms.fusion.test.DMPages;

import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class ScoreModelsPage
{

    private static WebElement element = null;
    public static List<WebElement> scoreModelElem;

    WebDriver driver;

    public ScoreModelsPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    @FindBy(id = "addScoreModule")
    WebElement AddScoreModelButton;

    @FindBy(id = "scoureModules1")
    public WebElement Ele_ScoreModule;

    @FindBy(id = "scoureModules0")
    public WebElement scoreModuleFirst;

    @FindBy(xpath = "//select[@name='paramVal[1][0]']")
    WebElement FormNoInd1078Mod;

    @FindBy(xpath = "//input[@name='paramVal[1][1]']")
    WebElement ActFornNo1078Mod;

    @FindBy(xpath = "//select[@name='paramVal[1][2]']")
    WebElement SrcStPos1078Mod;

    @FindBy(xpath = "//input[@name='paramVal[1][3]']")
    WebElement RiskStPos1078Mod;

    @FindBy(xpath = "//select[@name='paramVal[3][0]']")
    WebElement ModPara5152a;

    @FindBy(xpath = "//select[@name='paramVal[3][1]']")
    WebElement ModPara5152b;

    @FindBy(xpath = ".//input[@type='submit']")
    WebElement ContinueButton;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;

    @FindBy(xpath = ".//*[@class='deleteProjectBlock']")
    WebElement RemoveScoreModel;

    @Step("Remove Score Model")
    public void removeScoreModel()
    {
        RemoveScoreModel.click();
    }

    @Step("Get Error Message")
    public String getErrorMessage()
    {
        return ErrorMessage.getText();
    }

    @Step("Click ADD Score Model Button")
    public void clickAddScoreModelButton()
    {
        AddScoreModelButton.click();
    }

    @Step("Select Score Model No. :  \"{0}\" ")
    public WebElement selectScoreModelField(String ModelNum)
    {
        Select selType = new Select(Ele_ScoreModule);
        selType.selectByValue(ModelNum);
        return Ele_ScoreModule;
    }

    @Step("Select Score Model No. :  \"{0}\" ")
    public void selectScoreModelFieldById(String ModelNum, int id)
    {
        new Select(driver.findElement(By.xpath(".//*[@id='scoureModules" + (id + 1) + "']"))).selectByValue(ModelNum);
    }

    @Step("Select First Score Model No. :  \"{0}\" ")
    public WebElement selectFirstScoreModelField(String ModelNum)
    {
        Select selType = new Select(scoreModuleFirst);
        selType.selectByValue(ModelNum);
        return scoreModuleFirst;
    }

    @Step("Selected FORM NUMBER INDICATOR in Score Model page = \"{0}\"")
    public void selectFormNoInd1078Mod(String value)
    {
        Select sel = new Select(FormNoInd1078Mod);
        sel.selectByVisibleText(value);
    }

    @Step("Provided the ACTUAL FORM NUMBER in Score Model Page = \"{0}\"")
    public void inputActFormNo1078Mod(String value)
    {
        ActFornNo1078Mod.sendKeys(value);
    }

    @Step("Selected the Model Paramaters = \"{0}\"")
    public void selModParam(String value)
    {
        Select sel = new Select(ActFornNo1078Mod);
        sel.selectByVisibleText(value);
    }

    @Step("Selected SOURCE STATE POS in Score Model Page = \"{0}\"")
    public void selectSrcStPos1078Mod(String value)
    {
        Select sel = new Select(SrcStPos1078Mod);
        sel.selectByVisibleText(value);
    }

    @Step("Provided RISK STATE POS in Score Model Page = \"{0}\"")
    public void inputRiskStPos1078Mod(String value)
    {
        RiskStPos1078Mod.sendKeys(value);
    }

    @Step("Select ModPara5152 value = \"{0}\"")
    public void selectModPara5152a(String value)
    {
        driver.findElement(By.xpath("(.//*[@id='scoreParamDiv3']//following::tr)[1]/td[2]/select//*[@value='" + value + "']")).click();
        // Select sel = new Select(ModPara5152a);
        // sel.selectByVisibleText(value);
    }

    @Step("Select ModPara5152 value = \"{0}\"")
    public void selectModPara5152b(String value)
    {
        Select sel = new Select(ModPara5152b);
        sel.selectByVisibleText(value);
    }

    @Step("Select Score Params = \"{0}\"")
    public void selectScoreParameters(String value)
    {
        String[] valueSplit = value.split(",");
        for (int i = 0; i < valueSplit.length; i++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='scoreParamDiv1']/table/tbody/tr[" + (i + 2) + "]/td[2]/select")))
                    .selectByVisibleText(valueSplit[i]);
        }
    }

    @Step("Select Rejects for first score model value = \"{0}\"")
    public void selectRejectScoreModel()
    {
        driver.findElement(By.xpath(".//*[@id='dataMenuScoreModelForm']/div[1]/div/div/div/input[3]")).click();
    }

    @Step("Click Continue Button on Score Models Page")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public boolean isPopUpPresent()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a"));
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Click OK on Changing Score Models will cause all Model ordering to be reset ")
    public void acceptPopUp()
    {
        driver.findElement(By.xpath("(//a[contains(text(),'OK')])[2]")).click();
    }

    @Step("Select Score Model : \"{0}\" ")
    public void selectScoreModels(String ScoreMod, String ScoreModNCP, String tempAPMod) throws InterruptedException
    {
        String delims1 = ":";
        String delims2 = ",";
        String splitString1 = ScoreMod;
        String NCPsplitString1 = ScoreModNCP;
        StringTokenizer stMain = new StringTokenizer(splitString1, delims1);
        StringTokenizer NCPstMain = new StringTokenizer(NCPsplitString1, delims1);

        int i = 1;
        if (splitString1.equalsIgnoreCase("none") || splitString1.equalsIgnoreCase("na"))
        {
            // DataMenuPage.ScoreModels.btn_Continue(TheMain.driver).click();
            // clickContinueButton();
        } else
        {
            if (tempAPMod.equalsIgnoreCase("JXH_TEST_KONTABLE"))
                i = 1;
            System.out.println("Token Count : " + stMain.countTokens());
            while (stMain.hasMoreElements())
            {
                String splitString2 = stMain.nextToken();
                StringTokenizer stchild = new StringTokenizer(splitString2, delims2);
                String dynamicID = "scoureModules" + i;
                String dynamicRadioName = "scoreDrop" + i;
                String dynamicChkBoxName = "chkRunBefore" + i;
                if (stchild.countTokens() == 3)
                {
                    while (stchild.hasMoreElements())
                    {
                        // DataMenuPage.ScoreModels.btn_AddScoreModule(TheMain.driver).click();
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                        WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                        selVisibleText(selectElement, stchild.nextToken(), driver);
                        Thread.sleep(5000);
                        ScoreModels.rad_ProcessedRecords(driver, stchild.nextToken(), dynamicRadioName).click();
                        if (stchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();

                        }
                    }
                } else if (stchild.countTokens() == 5)
                {
                    while (stchild.hasMoreElements())
                    {
                        // DataMenuPage.ScoreModels.btn_AddScoreModule(TheMain.driver).click();
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                        WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                        selVisibleText(selectElement, stchild.nextToken(), driver);
                        ScoreModels.rad_ProcessedRecords(driver, stchild.nextToken(), dynamicRadioName).click();
                        if (stchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                        }
                        driver.findElement(By.xpath(".//*[@name='includedScore[" + i + "][0]']")).sendKeys(stchild.nextToken());
                        driver.findElement(By.xpath(".//*[@name='includedScore[" + i + "][1]']")).sendKeys(stchild.nextToken());
                    }

                }
                i++;
            }
        }

        if (NCPsplitString1.equalsIgnoreCase("none") || NCPsplitString1.equalsIgnoreCase("na"))
        {
            // DataMenuPage.ScoreModels.btn_Continue(TheMain.driver).click();
            // clickContinueButton();
        } else
        {
            while (NCPstMain.hasMoreElements())
            {
                String NCPsplitString2 = NCPstMain.nextToken();
                StringTokenizer NCPstchild = new StringTokenizer(NCPsplitString2, delims2);
                String[] array = NCPsplitString2.split(",");
                String firstSM = array[0];
                String dynamicID = "scoureModules" + i;
                String dynamicRadioName = "scoreDrop" + i;
                String dynamicChkBoxName = "chkRunBefore" + i;
                if (!firstSM.startsWith("P"))
                {
                    while (NCPstchild.hasMoreElements())
                    {
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                        WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                        selVisibleText(selectElement, NCPstchild.nextToken(), driver);
                        Thread.sleep(5000);
                        ScoreModels.rad_ProcessedRecords(driver, NCPstchild.nextToken(), dynamicRadioName).click();
                        if (NCPstchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();

                        }

                    }
                } else if (firstSM.startsWith("P"))
                {
                    while (NCPstchild.hasMoreElements())
                    {
                        Thread.sleep(3000);
                        NCPstchild.nextToken();
                        ScoreModels.rad_ProcessedRecords(driver, NCPstchild.nextToken(), dynamicRadioName).click();
                        if (NCPstchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();

                        }

                    }
                }
                i++;
            }
        }

    }

    public void selectAdditionalScModels(String scoreMod) throws InterruptedException
    {
        String delim1 = ":";
        String delim2 = ",";
        StringTokenizer st = new StringTokenizer(scoreMod, delim1);
        int i = 3;
        while (st.hasMoreElements())
        {
            String str2 = st.nextToken();
            StringTokenizer stChild = new StringTokenizer(str2, delim2);
            String dynamicID = "scoureModules" + i;
            String dynamicRadioName = "scoreDrop" + i;
            String dynamicChkBoxName = "chkRunBefore" + i;
            if (stChild.countTokens() == 3)
            {
                while (stChild.hasMoreElements())
                {
                    clickAddScoreModelButton();
                    Thread.sleep(3000);
                    (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                    WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                    selVisibleText(selectElement, stChild.nextToken(), driver);
                    Thread.sleep(5000);
                    ScoreModels.rad_ProcessedRecords(driver, stChild.nextToken(), dynamicRadioName).click();
                    if (stChild.nextToken().equalsIgnoreCase("check"))
                    {
                        ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                    }
                }
            }
            i++;
        }
    }

    public static class ScoreModels
    {
        public static WebElement btn_AddScoreModule(WebDriver driver)
        {
            element = driver.findElement(By.id("addScoreModule"));
            return element;
        }

        public static WebElement dd_Select(WebDriver driver, String selectId)
        {
            element = driver.findElement(By.id(selectId));
            return element;
        }

        public static WebElement rad_ProcessedRecords(WebDriver driver, String data, String dynamicName)
        {
            String name = null, xPath = null;
            if (data.equalsIgnoreCase("Drop"))
            {
                name = dynamicName;
                element = driver.findElement(By.name(name));
            } else if (data.equalsIgnoreCase("Tag"))
            {
                // xPath = "(//input[@name='" + dynamicName + "'])[2]";
                xPath = "//input[@value='1']";
                element = driver.findElement(By.xpath(xPath));
            } else if (data.equalsIgnoreCase("Reject"))
            {
                // xPath = "(//input[@name='" + dynamicName + "'])[3]";
                xPath = "//input[@value='2']";
                element = driver.findElement(By.xpath(xPath));
            }
            return element;
        }

        public static WebElement cb_RunBeforeCriMod(WebDriver driver, String dynamicChkBoxName)
        {
            element = driver.findElement(By.name(dynamicChkBoxName));
            return element;
        }

        public static WebElement btn_Continue(WebDriver driver)
        {
            element = driver.findElement(By.xpath(".//input[@value='Continue »']"));
            return element;
        }
    }

    public static void selVisibleText(WebElement elem, String s, WebDriver driver)
    {
        new Select(elem).selectByValue(s);
    }

    public boolean scoreMdlcheck()
    {
        try
        {
            scoreModuleFirst.isDisplayed();
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return true;
        }
    }

    @Step("Select Score Model :  \"{0}\"")
    public void selectSpecificScoreModel(String scModel) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(scModel))
        {
            String[] splitStr = scModel.split(",");
            int i = 0;
            while (i < splitStr.length)
            {
                clickAddScoreModelButton();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#scoureModules" + i + "').jqxComboBox('val','" + splitStr[i] + "')");
                Thread.sleep(500);
                i++;
            }
        }
    }

    @Step("Select Score Model : \"{0}\" ")
    public void selectScoreModels1(String ScoreMod, String ScoreModNCP) throws InterruptedException
    {
        String delims1 = ":";
        String delims2 = ",";
        String splitString1 = ScoreMod;
        String NCPsplitString1 = ScoreModNCP;
        StringTokenizer stMain = new StringTokenizer(splitString1, delims1);
        StringTokenizer NCPstMain = new StringTokenizer(NCPsplitString1, delims1);

        int i = 0;
        if (splitString1.equalsIgnoreCase("none") || splitString1.equalsIgnoreCase("na"))
        {
            // DataMenuPage.ScoreModels.btn_Continue(TheMain.driver).click();
            // clickContinueButton();
        } else
        {
            System.out.println("Token Count : " + stMain.countTokens());
            while (stMain.hasMoreElements())
            {
                String splitString2 = stMain.nextToken();
                StringTokenizer stchild = new StringTokenizer(splitString2, delims2);
                String dynamicID = "scoureModules" + i;
                String dynamicRadioName = "scoreDrop" + i;
                String dynamicChkBoxName = "chkRunBefore" + i;
                String preserveChPath = "//input[@name='dataMenuScoreModelDTOList[" + i + "].preserveDafaultScore']";
                if (stchild.countTokens() == 3)
                {
                    int j = 0;
                    while (stchild.hasMoreElements())
                    {
                        // DataMenuPage.ScoreModels.btn_AddScoreModule(TheMain.driver).click();
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        JavascriptExecutor js = (JavascriptExecutor) driver;
                        js.executeScript("$('#scoureModules" + j + "').jqxComboBox('val','" + stchild.nextToken() + "')");
                        Thread.sleep(3000);

                        ScoreModels.rad_ProcessedRecords(driver, stchild.nextToken(), dynamicRadioName).click();
                        /*if (stchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                        }*/
                        Thread.sleep(3000);
                        if (stchild.nextToken().equalsIgnoreCase("check"))
                        {
                            driver.findElement(By.xpath(preserveChPath)).click();
                        }
                    }
                } else if (stchild.countTokens() == 5)
                {
                    while (stchild.hasMoreElements())
                    {
                        // DataMenuPage.ScoreModels.btn_AddScoreModule(TheMain.driver).click();
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                        WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                        selVisibleText(selectElement, stchild.nextToken(), driver);
                        ScoreModels.rad_ProcessedRecords(driver, stchild.nextToken(), dynamicRadioName).click();
                        if (stchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                        }
                        driver.findElement(By.xpath(".//*[@name='includedScore[" + i + "][0]']")).sendKeys(stchild.nextToken());
                        driver.findElement(By.xpath(".//*[@name='includedScore[" + i + "][1]']")).sendKeys(stchild.nextToken());
                    }

                }
                i++;
            }
        }

        if (NCPsplitString1.equalsIgnoreCase("none") || NCPsplitString1.equalsIgnoreCase("na"))
        {
            // DataMenuPage.ScoreModels.btn_Continue(TheMain.driver).click();
            // clickContinueButton();
        } else
        {
            while (NCPstMain.hasMoreElements())
            {
                String NCPsplitString2 = NCPstMain.nextToken();
                StringTokenizer NCPstchild = new StringTokenizer(NCPsplitString2, delims2);
                String[] array = NCPsplitString2.split(",");
                String firstSM = array[0];
                String dynamicID = "scoureModules" + i;
                String dynamicRadioName = "scoreDrop" + i;
                String dynamicChkBoxName = "chkRunBefore" + i;
                if (!firstSM.startsWith("P"))
                {
                    while (NCPstchild.hasMoreElements())
                    {
                        clickAddScoreModelButton();
                        Thread.sleep(3000);
                        (new WebDriverWait(driver, 15)).until(ExpectedConditions.presenceOfElementLocated(By.id(dynamicID)));
                        WebElement selectElement = ScoreModels.dd_Select(driver, dynamicID);
                        selVisibleText(selectElement, NCPstchild.nextToken(), driver);
                        Thread.sleep(5000);
                        ScoreModels.rad_ProcessedRecords(driver, NCPstchild.nextToken(), dynamicRadioName).click();
                        if (NCPstchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                        }

                    }
                } else if (firstSM.startsWith("P"))
                {
                    while (NCPstchild.hasMoreElements())
                    {
                        Thread.sleep(3000);
                        NCPstchild.nextToken();
                        ScoreModels.rad_ProcessedRecords(driver, NCPstchild.nextToken(), dynamicRadioName).click();
                        if (NCPstchild.nextToken().equalsIgnoreCase("check"))
                        {
                            ScoreModels.cb_RunBeforeCriMod(driver, dynamicChkBoxName).click();
                        }

                    }
                }
                i++;
            }
        }

    }
    
   /* public void selectScoreModels2(String scModel) throws InterruptedException {
        Thread.sleep(5000);
        clickAddScoreModelButton();
        Thread.sleep(5000);
        driver.findElement(By.xpath(".//*[@id='dropdownlistArrowscoureModules4']/div")).click();
        Thread.sleep(5000);
        driver.findElement(By.xpath(".//*[@id='dropdownlistContentscoureModules4']/input")).sendKeys(scModel);
        Thread.sleep(5000);
        driver.findElement(By.xpath(".//*[@id='dropdownlistArrowscoureModules4']/div")).click();
        Thread.sleep(5000);
        clickContinueButton();
        Thread.sleep(5000);
        driver.findElement(By.xpath("//a[contains(text(),'Back')]")).click();
        
    }
    
    public void selRejValue(String rejects) {
        if(rejects.equalsIgnoreCase("Reject")) {
            driver.findElement(By.xpath("//input[@value='1107-FICO PERFN 5-EFX-N PRE']//following::input[@value='2']")).click();
        }
    }*/
}

package com.equifax.cms.fusion.test.qapages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class ProjectDashBoardPage
{

    public WebDriver driver;
    protected OracleDBHelper db;

    public ProjectDashBoardPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(400, TimeUnit.SECONDS);
    }

    @FindBy(id = "jqxDashboard")
    WebElement jqx_Dashboard;

    @FindBy(xpath = ".//*[@id='home']/a")
    WebElement Ele_Home_Tab;

    @FindBy(id = "projectToCopy")
    WebElement ProjNumToCopy_Fld;

    @FindBy(xpath = ".//*[@id='dashboardForm']/input[5]")
    WebElement CopySearchBtn;

    @FindBy(xpath = ".//a[contains(text(),'Input')]")
    WebElement Ele_Input_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Source Match')]")
    WebElement Ele_SourceMatch_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Data Menu')]")
    WebElement Ele_DataMenu_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Refinement')]")
    WebElement Ele_Refinement_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Data Processing')]")
    WebElement Ele_DataProcessing_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Output')]")
    WebElement Ele_Output_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Reporting')]")
    WebElement Ele_Reporting_Tab;

    @FindBy(xpath = ".//a[contains(text(),'Operations')]")
    WebElement Ele_Operations_Tab;

    @FindBy(xpath = ".//*[@id='statsHeader']/div[2]/div")
    WebElement Close_Stats;

    @FindBy(xpath = "//input[@role='textbox']")
    WebElement DashBoardSrch;

    @FindBy(xpath = "//div[@class='jqx-icon-search']")
    WebElement clickSrchBtn;
    
    @FindBy(id = "fulfillmentAnalystId")
    WebElement FullFilmentAnalyst;
    
    @FindBy(id = "editProjectDetails")
    WebElement ProjNum;
    
    @FindBy(id = "primaryProgrammer")
    WebElement PrimPrgrammer;
    
    @FindBy(id = "team")
    WebElement Team;
    
    @Step("Get Team value")
    public String getTeam(){
    	return Team.getText();
    }
    
    @Step("Get the Primmary Programmer")
    public String getPrimProgrammer(){
    	return PrimPrgrammer.getText();
    }
    
    @Step("clicked on project number")
    public void clickProjNum(){
    	ProjNum.click();
    }
    
    @Step("FulFillment Analyst Name in the Project Dashboard page")
    public String fulfilmentAnalyst(){
    	String name = FullFilmentAnalyst.getText().trim();
    	return name;
    }

    public String getJobNoByProcessID(String processID)
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'" + processID + "')]/following::td[1]")).getText();
    }

    public void clickSupportTools()
    {
        driver.findElement(By.id("cms_supportTools")).click();
    }

    public String getDateCompletedJobNo(String jobNo)
    {
        return driver.findElement(By.xpath(".//*[@id='" + jobNo + "']/td[9]")).getText();
    }

    @Step("Click on Schedule Job Tab")
    public void clickScheduleJobTab()
    {
        WebElement ele = driver.findElement(By.xpath("//div[@class='expandable']/ul/li/div[2]/a"));
        ele.click();
    }

    @Step("Click on Shipping Process Tab")
    public void clickShippingProcessTab()
    {
        WebElement ele = driver.findElement(By.xpath("//*[@id='shipping']/a"));
        ele.click();
    }

    public boolean is_WorkItem_Present(String workItem)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//span[contains(text(),'" + workItem + "')]")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public int getNoOfProcessPresentId(String proId)
    {
        return driver.findElements(By.xpath(".//*[contains(text(),'" + proId + "')]")).size();
    }

    /*
     * public boolean is_DM_JET_WorkItem_Present() { try { driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); String DM_JET =
     * driver.findElement(By.xpath(".//*[contains(text(),'DM_JET')]//following::td[2]/div")).getText(); driver.manage().timeouts().implicitlyWait(100,
     * TimeUnit.SECONDS); return true; } catch (org.openqa.selenium.NoSuchElementException e) { return false; } } public boolean
     * is_DM_GPLOAD_WorkItem_Present() { try { driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); String DM_GPLOAD =
     * driver.findElement(By.xpath(".//*[contains(text(),'DM_GPLOAD')]//following::td[2]/div")).getText();
     * driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS); return true; } catch (org.openqa.selenium.NoSuchElementException e) { return
     * false; } } public boolean is_SAMPLE_EXTRACT_WorkItem_Present() { try { driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); String
     * SAMPLE_EXTRACT = driver.findElement(By.xpath(".//*[contains(text(),'SAMPLE_EXTRACT')]//following::td[2]/div")).getText();
     * driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS); return true; } catch (org.openqa.selenium.NoSuchElementException e) { return
     * false; } } public boolean is_AUDIT_SFLOAD_WorkItem_Present() { try { driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS); String
     * AUDIT_SFLOAD = driver.findElement(By.xpath(".//*[contains(text(),'AUDIT_SFLOAD')]//following::td[2]/div")).getText();
     * driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS); return true; } catch (org.openqa.selenium.NoSuchElementException e) { return
     * false; } }
     */

    public void clickSearch()
    {
        driver.findElement(By.id("cms_search")).click();
    }

    public void inputProjectNumberClickSearch(String projNum)
    {
        driver.findElement(By.id("projectNumber")).sendKeys(projNum);
        driver.findElement(By.id("searchButton")).click();
        driver.findElement(By.linkText(projNum)).click();
    }

    public void clickViewDM_GPLOAD()
    {
        driver.findElement(By.xpath(".//*[contains(text(),'DM_GPLOAD')]//following::td[6]/div/a")).click();
    }

    public void clickJobUpperLevel(String name) throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@class='dataTables_scrollBody']//td[contains(text(), '" + name + "')]/preceding::td[1]/img")).click();
        Thread.sleep(2000);
    }

    public void clickJobLowerLevel(String name) throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@class='dataTables_scrollBody']//td[contains(text(), '" + name + "')]/following::img[1]")).click();
        Thread.sleep(2000);
    }

    public String getFFF_GP_EXPORT_Status()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'FFF_GPEXPORT')]//following::td[2]/div")).getText();
    }

    public String getFFF_JET_Status()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'FFF_JET')]//following::td[2]/div")).getText();
    }

    public String getFFF_GP_CONVERTAVRO_Status()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'FFF_CONVERTAVRO')]//following::td[2]/div")).getText();
    }

    public void clickAuditTab()
    {
        driver.findElement(By.xpath(".//a[contains(text(),'Audit')]")).click();
    }

    // @FindBy(xpath = "//a[contains(text(),'Close')]")
    @FindBy(xpath = "//div[@class='jqx-window-close-button jqx-window-close-button-classic jqx-icon-close jqx-icon-close-classic']")
    WebElement CloseBtnOnStats;

    @FindBy(xpath = ".//a[contains(text(),'Job Stacking')]")
    WebElement Ele_Stack_Tab;

    public String getDCworkitem_SAS_DCX(String process) throws InterruptedException
    {
        driver.findElement(By.xpath("(//span[contains(text(),'" + process + "')])[1]//preceding::span[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),'" + process + "')])[2]//preceding::span[1]")).click();
        Thread.sleep(2000);
        return driver.findElement(By.xpath("(//span[contains(text(),'SAS_DCXJOB')])[1]")).getText();
    }

    public String getDCworkitem_SAS_CIDEXTRACT()
    {
        return driver.findElement(By.xpath("(//*[contains(text(),'SAS_CIDEXTRACT')])[1]")).getText();
    }

    public String getDCworkitem_AUDIT_JET()
    {
        return driver.findElement(By.xpath("(//*[contains(text(),'AUDIT_JET')])[1]")).getText();
    }

    public String getDCworkitem_SAMPLE_EXTRACT()
    {
        return driver.findElement(By.xpath("(//*[contains(text(),'SAMPLE_EXTRACT')])[1]")).getText();
    }

    public String getDCworkitem_AUDIT_SFLOAD()
    {
        return driver.findElement(By.xpath("(//*[contains(text(),'AUDIT_SFLOAD')])[1]")).getText();
    }

    @FindBy(id = "copyBtn")
    WebElement CopySelected_btn;

    @Step("Provided Project Copy project Number = \"{0}\"")
    public void inputProjNum(String copyProjNum)
    {
        ProjNumToCopy_Fld.sendKeys(copyProjNum);
    }

    @Step("Clicked on Search button")
    public void clickCopyProjSrchBtn()
    {
        CopySearchBtn.click();
    }

    @Step("Clicked Job Stacking Tab")
    public void clickJobStackingTab()
    {
        Ele_Stack_Tab.click();
    }

    @Step("Get the XML window title")
    public String xmlPageTitle()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'JET Job XML')]")).getText();
    }

    @Step("Fetched Match Join Master and Match Table Names")
    public String[] getMatchJoinTableName(String processName)
    {

        String[] tableNames = new String[2];
        driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')]//preceding::span[1])[1]")).click();
        driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')]//preceding::span[1])[2]")).click();
        String jobid = driver.findElement(By.xpath("//span[contains(text(),'MJ_GPLOAD')]//following::td[1]")).getText().trim();
        tableNames[0] = "I" + jobid + "_mj_gpload_master";
        tableNames[1] = "I" + jobid + "_mj_gpload_unmatched_match";
        return tableNames;
    }

    // modified
    @Step("Fetched Match Join Master and Match Table Names")
    public String[] getMatchJoinTableNameNew(String processNamestats, String processName) throws InterruptedException
    {
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processNamestats);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        String[] tableNames = new String[2];
        driver.findElement(By.xpath("//span[contains(text(),'" + processNamestats + "')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + processName + "')]//preceding::span[1]")).click();
        String jobid = driver.findElement(By.xpath("//span[contains(text(),'MJ_GPLOAD')]//following::td[1]")).getText().trim();
        tableNames[0] = "I" + jobid + "_mj_gpload_master";
        tableNames[1] = "I" + jobid + "_mj_gpload_unmatched_match";
        return tableNames;
    }

    public String getErrorMessageForGPSEED()
    {
        return driver.findElement(By.xpath("//td[starts-with(text(),'ERROR')]/following::td")).getText();
    }

    @Step("Fetched Rolling Suppression Table Name")
    public String getRollingSuppTableName(String processName)
    {
        driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')])[1]//preceding::span[1]")).click();
        driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')])[2]//preceding::span[1]")).click();
        String jobId = driver.findElement(By.xpath("//span[contains(text(),'ROLL_GPSUPP')]//following::td[1]")).getText().trim();
        String tableName = "I" + jobId + "_ROLL_GPSUPP_ROLLINGLSTTBL";
        return tableName;
    }

    @Step("Get Page Title")
    public String getPageTitle()
    {
//         return driver.findElement(By.xpath(".//*[@class='fusion-h3Title']")).getText();
        return driver.findElement(By.xpath("(//*[@class='fusion-h3Title'])[3]")).getText();
    }

    @Step("Clicked Home Tab")
    public void clickHomeTab()
    {
        new WebDriverWait(driver, 50).until(ExpectedConditions.presenceOfElementLocated(By.id("home")));
        Ele_Home_Tab.click();
    }

    @Step("Clicked Input Tab")
    public void clickInputTab()
    {
        Ele_Input_Tab.click();
    }

    @Step("Clicked Source Match Tab")
    public void clickSourceMatchTab() throws InterruptedException
    {
        Thread.sleep(1500);
        Ele_SourceMatch_Tab.click();
    }

    @Step("Clicked Data Menu Tab")
    public void clickDataMenuTab()
    {
        Ele_DataMenu_Tab.click();
    }

    @Step("Clicked Refinement Tab")
    public void clickRFTab()
    {
        Ele_Refinement_Tab.click();
    }

    @Step("Clicked Data Processing Tab")
    public void clickDataProcessingTab()
    {
        Ele_DataProcessing_Tab.click();
    }

    @Step("Clicked Output Tab")
    public void clickOutputTab()
    {
        Ele_Output_Tab.click();
    }

    public void clickCloseButtonADCR()
    {
        driver.findElement(By.xpath(".//*[@id='sb-nav-close']")).click();
    }

    @Step("Clicked reporting Tab")
    public void clickReportingTab()
    {
        Ele_Reporting_Tab.click();
    }

    @Step("Clicked operations Tab")
    public void clickOperationsTab()
    {
        Ele_Operations_Tab.click();
    }

    @Step("Clicked Close Button Stats")
    public void clickCloseButtonStats() throws InterruptedException
    {
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE).build().perform();
        Thread.sleep(1000);
    }

    @Step("Clicked close button on stats")
    public void clickCloseBtnOnStats()
    {
        driver.findElement(By.xpath("//*[@id='statsHeader']/div[2]/div")).click();
    }

    @Step("Clicked close button on Stats")
    public void clickCloseButtonStats1()
    {
        CloseBtnOnStats.click();
    }

    @Step("Fetched Job Name")
    public String jobName()
    {
        // String JobName = driver.findElement(By.xpath("//div[@id='contenttablejob-grid']/div[1]/div[4]/div")).getText();
        String JobName = driver.findElement(By.xpath("//table[@id='tablejob-tree']/tbody/tr[1]/td/span[2]")).getText();
        return JobName;
    }

    public String jobNameWithId(String procId)
    {
        String jobName = driver.findElement(By.xpath("//table[@id='tablejob-tree']/tbody/tr/td/span[contains(text(),'" + procId + "')]")).getText();
        return jobName;

    }

    public String getJobName()
    {
        String JobName = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[4]")).getText();
        return JobName;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        if (query.contains("DNS_GPFILTER_DNS"))
        {
            query1 = "select count(*) from fusion_stage." + query + " where dns_tag = 'A' or dns_tag is null";
        } else
        {
            query1 = "select count(*) from fusion_stage." + query;
        }
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching HIT Record count From Green Plum for Table = \"{0}\"")
    public long getHITrecordsFromGP(String query, String code) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + query + " where hit_code_f1_f2 = '" + code + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching HIT count with CID From Green Plum for Table = \"{0}\"")
    public long getHITwithCIDFromGP(String query, String code) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + query + " where cid is null and hit_code_f1_f2 = '" + code + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching City Column From GreenPlum for Table = \"{0}\"")
    public boolean getCityColumnFromGP(String TableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select city from fusion_stage." + TableName;
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        boolean flag = true;
        while (rs.next())
        {
            if (!rs.getString(1).equalsIgnoreCase(""))
            {
                flag = false;
            }
        }
        return flag;

    }

    @Step("Fetching City Column with blank spaces processed From GreenPlum for Table = \"{0}\"")
    public long getColumnCountFromGP(String TableName, String colName, String colValue) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + TableName + " where " + colName + " =" + "'" + colValue + "'";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;

    }

    @Step("Fetch the Input Table Name From The Stats")
    public String getInputTableName() throws SQLException
    {
        String inputTableName = driver.findElement(By.xpath("//div[text()='Input Table:']/parent::div/following-sibling::div[1]/div[1]")).getText();
        return inputTableName;

    }

    @Step("Fetch the Count Of Records Processed From The Stats")
    public Long getCountOfRecordsProcessedFromTheStats() throws SQLException
    {
        String recordsProcessed = driver
                .findElement(By.xpath("//div[starts-with(text(),'Input Records Selected For Processing')]/following::div[2]")).getText();
        String updatedRecordsProcessed = recordsProcessed.replace(",", "");// added this to remove comma between the characters of strings as it was
        // giving number format exception.
        return Long.parseLong(updatedRecordsProcessed);

    }

    @Step("Fetching the records processed For Green Plum")
    public Long getTheProcessedRecordCountFromGP(String TableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + TableName + " Where MATCH_FLAG = 'A' OR MATCH_FLAG IS NULL";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;

    }

    @Step("Fetching the records with match flag from GP")
    public long getTheRecordsWithMatchFlagAsBlankFromGP(String TableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + TableName + " where MATCH_FLAG IS NULL";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;

    }

    public Long getRecordCountFromInputTableWithCond(String table, String fieldName, String cond) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + table + "Where " + fieldName + "= '" + cond + "'";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;

    }

    @Step("Fetching the records with match flag as blank from GP")
    public long getTheRecordsWithMatchFlagFromGP(String TableName) throws SQLException
    {
        Connection conn = gpConnect();
        String query = "select count(*) from fusion_stage." + TableName + " where MATCH_FLAG='R'";
        PreparedStatement ps = conn.prepareStatement(query);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();

        return records;

    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetched Job Number")
    public long getJobNumber()
    {
        String JobNumber = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[4]")).getText();
        Long Long1 = Long.parseLong(JobNumber);
        return Long1;
    }

    @Step("Fetched Job Status")
    public String jobStatus()
    {
        String JobStatus = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[5]")).getText();
        return JobStatus;
    }

    @Step("Clicked Stats View")
    public void clickStatsView(String procName) throws InterruptedException
    {
        driver.findElement(
                By.xpath("//div[@class='dataTables_scrollBody']//td[contains(text(), '" + procName
                        + "')]/following-sibling::td/a[contains(text(), 'View')]")).click();
        Thread.sleep(2000);
    }

    public void viewStats(String procName) throws InterruptedException
    {
        Thread.sleep(3000);
        Actions action = new Actions(driver);
        WebElement element = driver.findElement(By.xpath("//span[contains(text(),'" + procName + "')]/following::td[6]/div/a"));
        element.click();

    }

    public void clickTreeV2statsView(String procName)
    {
        driver.findElement(By.xpath("//span[contains(text(),'" + procName + "')]//following::td[6]/div/a[1]")).click();
    }

    public void clickTreeV2statsViewForChrome(String procName)
    {
        WebElement elem = driver.findElement(By.xpath("//span[contains(text(),'" + procName + "')]//following::td[6]/div"));
        new Actions(driver).moveToElement(elem).click().perform();
        elem.click();

    }

    public Long recWithoutComma(Long a)
    {
        String value = a.toString();
        String b = value.replaceAll(",", "");
        return Long.parseLong(b);
    }

    @Step("Verify Process Status for Process = \"{0}\"")
    public String verifyProcess(String completeProcessName) throws InterruptedException
    {
        try
        {
            Thread.sleep(15000);
            clickHomeTab();
            Thread.sleep(15000);

            refresh: while (true)
            {
                try
                {

                    handleAlert();
                    String statusXpath = "//span[contains(text(),'" + completeProcessName + "')]//following::td[2]/div[1]";
                    String status = driver.findElement(By.xpath(statusXpath)).getText();
                    System.out.println("status: " + status);
                    if (status.equalsIgnoreCase("FAILED"))
                    {
                        System.out.println(completeProcessName + " Process failed \n Terminated the process!!!");
                        return "FAIL";
                    } else if (status.equalsIgnoreCase("COMPLETED"))
                    {
                        System.out.println(completeProcessName + "Process got completed !!!");
                        break;
                    } else
                    {
                        Thread.sleep(15000);
                        driver.navigate().refresh();
                        continue refresh;
                    }

                } catch (Exception e)
                {
                    Thread.sleep(15000);
                    driver.navigate().refresh();
                    continue refresh;
                }
            }
            return "PASS";

        } catch (Exception e)
        {
            e.printStackTrace();
            return "FAIL";
        }
    }

    // For Source Match Process

    @Step("Fetched Output Table Name SM")
    public String getOutputTableNameSM()
    {
    	//String SourceMatchOPName = driver.findElement(By.xpath("//div[contains(text(), 'SOURCEMATCH Table')]/following-sibling::div")).getText()
        String SourceMatchOPName = driver.findElement(By.xpath("//div[contains(text(), 'Source Table')]/following-sibling::div")).getText()
                .trim();
        return SourceMatchOPName;
    }

    @Step("Fetched Total Output Count for SM From Stats")
    public Long getTotalRecordSM()
    {
        String SMTotalRecords = driver.findElement(By.xpath("//div[contains(text(), 'Total number of records')]/following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMTotalRecords));
    }

    @Step("Fetched Total Hits Count for SM From Stats")
    public Long getTotalHitsSM()
    {
        String SMTotalHits = driver.findElement(By.xpath("//div[contains(text(), 'HT')]/following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMTotalHits));
    }

    @Step("Fetched Total No Hits Count for SM From Stats")
    public Long getTotalNoHitsSM()
    {
        String SMTotalNoHits = driver.findElement(By.xpath("//div[contains(text(), 'NH')]/following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMTotalNoHits));
    }

    @Step("Fetched Addr Disc Ind Blanks Count for SM From Stats")
    public Long getAddrDiscrIndcblanks()
    {
        String SMAddrDisIndBlanks = driver.findElement(By.xpath("//div[contains(text(), '()blank')]/following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMAddrDisIndBlanks));
    }

    @Step("Fetched Addr Disc Ind N Count for SM From Stats")
    public Long getAddrDiscrIndcN()
    {
        String SMAddrDisIndN = driver.findElement(
                By.xpath("//div[contains(text(), '()blank')]//following::div[contains(text(),'N')]//following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMAddrDisIndN));
    }

    @Step("Fetched Addr Disc Ind Y Count for SM From Stats")
    public Long getAddrDiscrIndcY()
    {
        String SMAddrDisIndY = driver.findElement(
                By.xpath("//div[contains(text(), '()blank')]//following::div[contains(text(),'Y')]//following-sibling::div")).getText();
        return Long.parseLong(removeComma(SMAddrDisIndY));
    }

    @Step("Fetched Input Table Name for SM From Stats")
    public String getInputTableNameSM()
    {
        String SMInputTableName = driver.findElement(By.xpath("//div[contains(text(),'Source Table:')]")).getText();
        String[] temp1 = SMInputTableName.split(":");
        SMInputTableName = temp1[1].trim();
        return SMInputTableName;
    }

    @Step("Fetched Input Table Count for SM From Stats")
    public Long getInputTableCountSM()
    {
        String SMInputTableCount = driver.findElement(By.xpath("//div[contains(text(),'Source Table:')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(SMInputTableCount));
    }

    @Step("Fetched HIT record Count for SM From Stats")
    public Long getHITcountSM()
    {
        String smHITCount = driver.findElement(
                By.xpath("//div[contains(text(),'HIT CODE COUNT(S)')]//following::div[contains(text(),'HT')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(smHITCount));
    }

    @Step("Fetched NO HIT record Count for SM From Stats")
    public Long getNHcountSM()
    {
        String smNHCount = driver.findElement(
                By.xpath("//div[contains(text(),'HIT CODE COUNT(S)')]//following::div[contains(text(),'NH')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(smNHCount));
    }

    @Step("Fetched Hit Record for SM From GP = \"{0}\"")
    public Long getHitRecordsSMGP(String OutputTableName) throws SQLException
    {
        Long HitRecGP = getRecordsFromGP(OutputTableName + " where  hit_code_f1_f2='HT'");
        return HitRecGP;
    }

    @Step("Fetched No Hit Record for SM From GP = \"{0}\"")
    public Long getNoHitRecordsSMGP(String OutputTableName) throws SQLException
    {
        Long HitRecGP = getRecordsFromGP(OutputTableName + " where  hit_code_f1_f2='NH'");
        return HitRecGP;
    }

    @Step("Fetched AddrIndRecBlanks for SM From GP = \"{0}\"")
    public Long getAddrIndRecBlanksSMGP(String OutputTableName) throws SQLException
    {
        Long HitRecGP = getRecordsFromGP(OutputTableName + " where address_disc_ind_yn = ''");
        return HitRecGP;
    }

    @Step("Fetched AddrIndRecN for SM From GP = \"{0}\"")
    public Long getAddrIndRecNSMGP(String OutputTableName) throws SQLException
    {
        Long HitRecGP = getRecordsFromGP(OutputTableName + " where address_disc_ind_yn = 'N'");
        return HitRecGP;
    }

    @Step("Fetched AddrIndRecY for SM From GP = \"{0}\"")
    public Long getAddrIndRecYSMGP(String OutputTableName) throws SQLException
    {
        Long HitRecGP = getRecordsFromGP(OutputTableName + " where address_disc_ind_yn = 'Y'");
        return HitRecGP;
    }

    @Step("Clicked the IP process IN_GPLOAD work item stats")
    public void clickIN_GPLOADstats(String jobId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//td[contains(text(),'" + jobId
                        + "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'IN_GPLOAD')]//following::td[5]/a")).click();
    }

    @Step("IP process work item is")
    public String getIPworkItemIN_PREPARE(String jobId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        String in_prepare = driver
                .findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'IN_PREPARE')]"))
                .getText().trim();
        return in_prepare;
    }

    @Step("IP process work item is")
    public String getIPworkItemIN_GPLOAD(String jobId)
    {
        String in_gpload = driver
                .findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'IN_GPLOAD')]"))
                .getText().trim();
        return in_gpload;
    }

    @Attachment
    public byte[] makeScreenshot()
    {
        return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
    }

    // Source Match Process Completed

    public void waitForElement(String Path) throws InterruptedException
    {
        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                Assert.fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath(Path)))
                {
                    break;
                }
            } catch (Exception e)
            {

            }
            Thread.sleep(1000);
        }
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    String status = "PROCESSING";

    public String waitAndCheckProcessStatus_qa(Long jobId) throws SQLException
    {
        while (status.equalsIgnoreCase("PROCESSING"))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // int count = 0;
                // try for three times
                /*
                 * if (count > 3) { // status = "FAILED"; break; }
                 */
                // count++;
            } catch (InterruptedException e)
            {
                // LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }
        return status;
    }

    @Step("Selected the Previous Project Process Name = \"{0}\"")
    public void selectCopyPrevProjProcName(String copyProcId)
    {
        String delim = ",";
        StringTokenizer proc = new StringTokenizer(copyProcId, delim);
        while (proc.hasMoreTokens())
        {
            driver.findElement(By.xpath("//a[starts-with(text(),'" + proc.nextToken() + "')]//preceding::td[2]/input")).click();
        }
    }

    // added
    @Step("Selected the Previous Project Process Name = \"{0}\"")
    public void selectCopyPrevProjProcessName(String copyProcId)
    {
        String delim = ",";
        StringTokenizer proc = new StringTokenizer(copyProcId, delim);

        while (proc.hasMoreTokens())
        {
            // driver.findElement(By.xpath("//td[starts-with(text(),'" + proc.nextToken() + "')]//preceding::td[2]/input")).click();
            driver.findElement(By.xpath("//a[starts-with(text(),'" + proc.nextToken() + "')][1]/parent::td/parent::tr/td[1]/input")).click();
        }
    }

    public String getNameOfProcCopied(String procName)
    {
        String[] a = procName.split(",");
        return a[0];
    }

    @Step("Selected the Previous Project Process Name = \"{0}\"")
    public void clickInputDependancyPopupOk()
    {
        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
    }

    @Step("Updated Copy Previous Project Processes status = \"{0}\"")
    public String getStatusCopyprocess(String copyProcId)
    {
        String status = driver.findElement(By.xpath("//td[contains(text(),'" + copyProcId + "')]//following::td[1]")).getText();
        return status.trim();
    }

    @Step("Clicked Copy Selected button")
    public void clickCopySelectBtn()
    {
        CopySelected_btn.click();
        acceptIfPopUpDisplayed();
    }

    public void clickCloseButtonShadowBox()
    {
        driver.findElement(By.xpath(".//*[@id='sb-nav-close']")).click();
    }

    public void acceptIfPopUpDisplayed()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        } catch (org.openqa.selenium.NoSuchElementException e)
        {

        }
    }

    // added to get the job no for the process
    @Step("Fetch the JobNo from the Process")
    public String getTheJobNoForTheProcess(String assignedId)
    {
        String JobNo = driver.findElement(
                By.xpath("//table[@id='tablejob-tree']/tbody/tr/td/span[contains(text(),'" + assignedId + "')]/following::td[1]")).getText();
        return JobNo;
    }

    @Step("Verify Process Status for Process = \"{0}\"")
    public String verifyProcessCancelStatus(String processName) throws InterruptedException
    {
        try
        {
            Thread.sleep(3000);
            clickHomeTab();
            Thread.sleep(2000);
            // assertEquals("Jobs", driver.findElement(By.cssSelector("div.cmsContent > h4")).getText());

            refresh: while (true)
            {

                String currentProcessXpath = "//div[contains(text(),'" + processName + "')]";
                String statusXpath = currentProcessXpath + "/following::div[4]";
                String status = driver.findElement(By.xpath(statusXpath)).getText();
                System.out.println("status: " + status);
                if (status.equalsIgnoreCase("FAILED"))
                {
                    System.out.println(processName + " Process failed \n Terminated the process!!!");
                    // result = "verImpNewFileRes_FAIL";
                    // ExcelWriter.writeFail(ExcelReader.creImpNewFile_Sheet, tempInt, result);
                    // driver.quit();
                    return "FAIL";
                    // System.exit(0);
                } else if (status.equalsIgnoreCase("CANCELLED"))
                {
                    System.out.println(processName + " Process got CANCELLED !!!");
                    break;
                } else
                {
                    driver.navigate().refresh();
                    continue refresh;
                }
            }
            return "CANCELLED";
        } catch (Exception e)
        {
            // result = "verImpNewFileRes";
            // ExcelWriter.writeFail(ExcelReader.creImpNewFile_Sheet, tempInt, result);
            e.printStackTrace();
            driver.quit();
            return "FAIL";
        }
    }

    @Step("Expand gear box for process in processing state")
    public void openProcessGearBox(String procName)
    {
        // driver.findElement(By.xpath("//div[contains(text(),'" + procName + "')]/preceding::div[2]/img")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + procName + "')]/following::td[5]/div/img")).click();
    }

    @Step("Is Retry option available for cancelled process")
    public boolean isRetryOptionVisible()
    {
        // return driver.findElement(By.xpath(".//*[@id='Retry']")).isDisplayed();
        return driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Retry')]")).isDisplayed();
    }

    @Step("Click Retry option")
    public void clickRetryOption()
    {

        driver.findElement(By.xpath("//ul[1][@id='ContextItems']/li[contains(text(),'Retry')]")).click();
    }

    @Step("click gear box cancel option")
    public void clickGearBoxCancel()
    {
        WebElement ele = driver.findElement(By.xpath("//input[@id='confirmRetryCancel']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", ele);

    }

    @Step("click confimation ok to cancel")
    public void clickConfirmationOK()
    {
        WebElement ele = driver.findElement(By.xpath("//input[@id='confirmRetryOk']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", ele);

    }

    public boolean isRetryOptionAvailable()
    {
        return driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Retry')]")).isDisplayed();
    }

    public void expandProcessOnDashboard(String procName)
    {

        String processName = procName.replace(':', '_');
        driver.findElement(By.xpath(".//*[contains(text(),' " + processName + " ')]/preceding::div[4]")).click();
    }

    public void expandProcessToViewWorkItem(String procName)
    {
        driver.findElement(By.xpath(".//*[contains(text(),' " + procName + " ')]/preceding::div[2]")).click();
    }

    public boolean getWorkItemSF_LOAD(String procId)
    {
        try
        {
            String sf_load = driver.findElement(By.xpath("//span[contains(text(),'AUDIT_SFLOAD')]")).getText();
            Assert.assertEquals(sf_load, "AUDIT_SFLOAD");
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return true;
        }
    }

    public String getErrorWarningMessage()
    {
        String s = driver.findElement(By.xpath("//div[@id='jqxWarnings']/div/div/table/tbody/tr[2]/td[3]")).getText();
        return s;
    }

    @Step("Close the stats window")
    public void clickCloseStats()
    {
        driver.findElement(By.xpath("//div[@id='statsHeader']/div[2]/div")).click();
    }

    @Step("Closed the Stats window")
    public void closeStatsWindow()
    {
        Close_Stats.click();
    }

    public void expandProcess(String process)
    {
        WebElement ele = driver.findElement(By.xpath("//span[contains(text(),'" + process + "')]/preceding::span[1]"));
        // JavascriptExecutor js = (JavascriptExecutor) driver;
        // js.executeScript("arguments[0].click();", ele);
        ele.click();
    }

    public void expandProcessToViewWorkItems(String process)
    {
        WebElement ele = driver.findElement(By.xpath("//span[contains(text(),'" + process + "')]/preceding::span[1]"));
        // JavascriptExecutor js = (JavascriptExecutor) driver;
        // js.executeScript("arguments[0].click();", ele);
        ele.click();
    }

    public boolean SAMPLE_EXTRACTworkItem(String procId) throws InterruptedException
    {
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')])[1]")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')])[2]")).click();
        Thread.sleep(2000);
        try
        {
            driver.findElement(By.xpath("//span[contains(text(),'SAMPLE_EXTRACT')]")).getText();
            driver.findElement(By.xpath("//span[contains(text(),'AUDIT_SFLOAD')]")).getText();
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return true;
        }
    }

    public void searchDashBoard(String jobName)
    {
        DashBoardSrch.clear();
        DashBoardSrch.sendKeys(jobName);
        clickSrchBtn.click();
    }

    public static String removeComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }

    public void changeHomeGridViewSelectionToDefault()
    {
        Select selType;
        selType = new Select(jqx_Dashboard);
        selType.selectByVisibleText("Default");
    }

    public void handleAlert()
    {
        if (isAlertPresent())
        {
            Alert alert = driver.switchTo().alert();

            System.out.println(alert.getText());
            alert.accept();
            driver.switchTo().defaultContent();
        }
    }

    public boolean isAlertPresent()
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException ex)
        {
            return false;
        }
    }

    public void changeHomeGridUserSelectionToAll()
    {
        driver.findElement(By.xpath("//div[@class='jqx-icon-arrow-down jqx-icon jqx-icon-arrow-down-selected']")).click();
        driver.findElement(By.xpath("//div[@id='listitem1innerListBoxfusion-role']/span")).click();
    }

    public List<String> getAnalyzeFieldCount()
    {
        List<String> count = new ArrayList<>();
        List<WebElement> eleList = driver.findElements(By.xpath("//table[1]/caption/following-sibling::tbody/tr"));

        int i = 2;
        while (i <= eleList.size())
        {
            WebElement tdData = driver.findElement(By.xpath("//table[1]/caption/following-sibling::tbody/tr[" + i + "]/td[2]"));
            count.add(tdData.getText());
            i++;
        }

        return count;
    }

    public Long addAllListValues(List<String> count)
    {
        Long sum = 0l;
        for (int i = 0; i < count.size(); i++)
        {
            sum = sum + Long.valueOf(count.get(i));

        }
        return sum;

    }
}

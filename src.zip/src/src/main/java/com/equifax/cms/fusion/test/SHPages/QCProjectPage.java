package com.equifax.cms.fusion.test.SHPages;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;
import com.equifax.cms.fusion.test.qapages.CommonMethods;

public class QCProjectPage
{
    WebDriver driver;

    public QCProjectPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(1, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@id='qc']/a")
    WebElement QC_Tab;

    @FindBy(xpath = "//div[@id='submitBtn']/input")
    WebElement Save_Btn;

    @Step("Approve the Shipping process in QC tab")
    public void approvesTheShippinginQC() throws InterruptedException
    {
        QC_Tab.click();
        Thread.sleep(1000);
        Thread.sleep(1000);
        int i = 1;
        String status = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[1]/div[1]/span[3]/span[1]")).getText();
        WebElement status1 = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[1]/div[1]/span[3]/span[1]"));
        CommonMethods com =new CommonMethods(driver);
        com.waitForLoad(driver);
        try
        {
            while (status != null || status1.isEnabled())
            {
                status = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[1]/span[3]/span[1]"))
                        .getText();
                if (status.equalsIgnoreCase("Pending"))
                {
                    driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[1]/span[3]/span[1]"))
                    .click();
                    driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[2]/ul/li[2]/span")).click();

                } else if (status.equalsIgnoreCase("Approved") && status1.isEnabled())
                {
                    System.out.println("The process is already in Approved state !!!");
                } else if (!status1.isEnabled())
                {
                    System.out.println("The process is disabled !!!");
                }
                Thread.sleep(2000);
                i++;
            }
        } catch (ElementNotVisibleException e)
        {
            Save_Btn.click();
        }

        catch (NoSuchElementException e)
        {
            Save_Btn.click();
        }
    }

    public void approvesTheShippinginQC2() throws InterruptedException
    {
        QC_Tab.click();
        Thread.sleep(1000);
        Thread.sleep(1000);
        int i = 0;
        WebElement status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[4]/div/span"));
        String status1 = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[4]/div/span")).getText();
        try
        {
            while (status1.equalsIgnoreCase("Pending"))
            {
                status1 = driver.findElement(By.xpath(".//*[@id='row"+ i +"jqxgridJobListing']/div[4]/div/span")).getText();
                status = driver.findElement(By.xpath(".//*[@id='row"+ i +"jqxgridJobListing']/div[4]/div/span"));
                try
                {
                    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                    Actions action = new Actions(driver);
                    WebElement ele = driver
                            .findElement(By.xpath(".//*[@id='row" + i + "jqxgridJobListing']/div[4]/div/span"));
                    action.doubleClick(ele).build().perform();
                    driver.findElement(By.xpath(".//*[@id='dropdownlistArrowdropdownlisteditorjqxgridJobListingqcItemStatus']/div")).click();
                    driver.findElement(By.xpath("(//span[contains(text(),'Approved')])[2]")).click();
                    Thread.sleep(2000);
                } catch (Exception e)
                {
                    System.out.println("In catch");
                }
                i++;
            }
        } catch (Exception e)
        {
            Save_Btn.click();
        }
    }

    @Step("Approve the Shipping process in QC tab")
    public void approvesTheShippinginQC1() throws InterruptedException
    {
        QC_Tab.click();
        System.out.println("click qc");
        int i = 1;
        waitUntilPageStopsLoading(30);
        String status = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[1]/div[1]/span[3]/span[1]")).getText();
        WebElement status1 = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[1]/div[1]/span[3]/span[1]"));
        try
        {
            while (status.equalsIgnoreCase("Pending") || status.equalsIgnoreCase("Approved") || status.equalsIgnoreCase("Rejected"))
            {
                System.out.println("in while");
                status = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[1]/span[3]/span[1]"))
                        .getText();
                status1 = driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[1]/span[3]/span[1]"));
                try
                {
                    System.out.println("in try");
                    driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
                    driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[1]/span[3]/span[1]"))
                    .click();
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("(//table[@id='DataTables_Table_0']/tbody/tr/td[4]/div[3])[" + i + "]/div[2]/ul/li[2]/span")).click();
                    Thread.sleep(2000);
                } catch (Exception e)
                {
                    System.out.println("in catch");
                }
                i++;
                System.out.println("iplusplus");
            }
        } catch (Exception e)
        {
            Save_Btn.click();
        }
    }

    public void approveRequiredQcItemsForShipping(List<String> approveRequiredProcesses) throws InterruptedException
    {
    	//waitForLoad(driver);
         waitUntilPageStopsLoading(30);
    
        for (String process : approveRequiredProcesses)
        {
            // here getting the class name so as to identify whether the process in QC is "Disabled" or "Enabled"
            String className = driver.findElement(By.xpath("//div[contains(text(),'" + process + "')]/following::div[3]/div")).getAttribute("class");
            if (!className.equalsIgnoreCase("disableQcItem"))
            {
                Thread.sleep(2000);
                driver.findElement(By.xpath("//div[contains(text(),'" + process + "')]/following::div[3]/div/span")).click();
                Thread.sleep(2000);

                driver.findElement(By.xpath("//div[@id='dropdownlistWrapperdropdownlisteditorjqxgridJobListingqcItemStatus']/div")).click();
                Thread.sleep(2000);
                // driver.findElement(By.xpath("//div[@id='listBoxContentinnerListBoxdropdownlisteditorjqxgridJobListingqcItemStatus']/div/div/span")).click();

                driver.findElement(
                        By.xpath("//div[@id='listBoxContentinnerListBoxdropdownlisteditorjqxgridJobListingqcItemStatus']//div[2]/span/div/span"))
                        .click();
                Thread.sleep(2000);
            }
        }
        Thread.sleep(6500);
        Save_Btn.click();
        Thread.sleep(6500);
    }

    public void waitForLoad(WebDriver driver)
    {
        ExpectedCondition<Boolean> pageLoadCondition = new ExpectedCondition<Boolean>()
                {
            @Override
            public Boolean apply(WebDriver driver)
            {
                return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
            }
                };
                WebDriverWait wait = new WebDriverWait(driver, 8000);
                wait.until(pageLoadCondition);
    }
    private void waitUntilPageStopsLoading(int timeout) {

        while (driver.findElement(By.xpath("//div[@class='jqx-rc-all']"))
                .getCssValue("display").equalsIgnoreCase("block")) {
            timeout = timeout + 30;
            driver.manage().timeouts()
            .implicitlyWait(timeout, TimeUnit.SECONDS);
        }

    }

    public void pendingToApprovedStatus() throws InterruptedException {
        QC_Tab.click();
        try {
            int i = 0;
            String status = driver.findElement(By.xpath(".//*[@id='row" + i + "jqxgridJobListing']/div[4]/div"))
                    .getText();
            String status2 = driver.findElement(By.xpath(".//*[@id='row" + i + "jqxgridJobListing']/div[4]/div")).getAttribute("class");
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            while (status != null && !status2.equalsIgnoreCase("disableQcItem")) {
                status = driver.findElement(By.xpath(".//*[@id='row" + i + "jqxgridJobListing']/div[4]/div"))
                        .getText();
                if (status.equalsIgnoreCase("Pending")) {
                    Thread.sleep(3000);
                    Actions action = new Actions(driver);
                    WebElement ele = driver
                            .findElement(By.xpath(".//*[@id='row" + i + "jqxgridJobListing']/div[4]/div/span"));
                    action.doubleClick(ele).build().perform();
                    Thread.sleep(3000);
                    driver.findElement(By.xpath(".//*[@id='dropdownlistArrowdropdownlisteditorjqxgridJobListingqcItemStatus']/div")).click();
                    Thread.sleep(3000);
                    driver.findElement(By.xpath(".//*[@id='listitem1innerListBoxdropdownlisteditorjqxgridJobListingqcItemStatus']/span/div/span")).click();
                    Thread.sleep(2000);
                }
                i++;
            }

        } catch (org.openqa.selenium.NoSuchElementException e) {
            Save_Btn.click();
        }
    }
}

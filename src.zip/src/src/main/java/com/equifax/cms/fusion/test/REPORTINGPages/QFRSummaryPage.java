package com.equifax.cms.fusion.test.REPORTINGPages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class QFRSummaryPage
{

    WebDriver driver;

    public QFRSummaryPage(WebDriver driver)
    {

        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement submit_Btn;

    @Step("Click Submit button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Click Submit button")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    // Validation only for one group selection
    @Step("check if groups displayed on summary")
    public boolean isGroupSelectionDisplayed(String groupName)
    {
        return driver.findElement(
                By.xpath(".//table[@id='DataTables_Table_0']/tbody/tr/td[3]/table/tbody/tr/td[contains(text(),'" + groupName + "')]")).isDisplayed();
    }

    @Step("Get Process Name from Summary")
    public String getInputProcessFromSummary()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td[1]")).getText();
    }

    @Step("Get Process Name from Summary")
    public String getInputDataFromSummary()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[3]")).getText();
    }

    // table[@id='DataTables_Table_0']/tbody/tr/td[3]/table/tbody/tr/td
    @Step("Get Selected table from Summary")
    public String getSelectedTableFromSummary()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td[3]")).getText();
    }

    @Step("Get Selected Field from Summary")
    public String getSelectedFieldFromSummary()
    {
        return driver.findElement(By.xpath("//div[@id='contentsummary-report']/div[2]/div/div/div[2]/div/div/div/table/tbody/tr[2]/td[2]")).getText();
    }

    @Step("Get Selected Ranges from Summary")
    public String getSelectedRangesFromSummary()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Ranges')]/following::td[1]")).getText();
    }

    @Step("Get Selected Zero Count Ranges from Summary")
    public String getSelectedZeroCountRangesFromSummary()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Show Zero-count ranges')]/following::td[1]")).getText();
    }

    @Step("Get Selected Starting Values from Summary")
    public String getSelectedStartingValueFromSummary()
    {
        return driver.findElement(By.xpath("//td[contains(text(),'Start')]/following::td[1]")).getText();
    }

    @Step("Get Selected Ending Values from Summary")
    public String getSelectedEndingValueFromSummary()
    {
        return driver.findElement(By.xpath("//td[contains(text(),'End')]/following::td[1]")).getText();
    }

    @Step("Get Selected Increment from Summary")
    public String getSelectedIncrementFromSummary()
    {
        return driver.findElement(By.xpath("//td[contains(text(),'Increment')]/following::td[1]")).getText();
    }

    @Step("Get Selected Values to Isolate from Summary")
    public String getSelectedValuesToIsolateFromSummary()
    {
        return driver.findElement(By.xpath("//td[contains(text(),'Isolate')]/following::td[1]")).getText();
    }

    @Step("click save edit details")
    public void saveEditReportDetails()
    {
        driver.findElement(By.xpath("//div[@id='layout-section']/div[7]/input[1]")).click();
    }

}

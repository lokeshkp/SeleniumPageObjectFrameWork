package com.equifax.cms.fusion.test.RLSPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class RLSSummaryPage
{

    WebDriver driver;

    public RLSSummaryPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@name='submitButton']")
    WebElement SubmitButton;

    @Step("Click Submit button")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }
    
    public String getProcessDisplayed() 
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[1]")).getText().trim();
    }
    
    public String getJobNoDisplayed() 
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[2]")).getText().trim();
    }
    
    public String getDataDisplayed() 
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[3]")).getText().trim();
    }
    
    public String getGroupSelected() {
        return driver.findElement(By.xpath(".//*[contains(text(),'Filter group')]/following::tbody[1]/tr/td")).getText();
    }


}

package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class SourceInputPage {

	WebDriver driver;
	public Select selType;

	public SourceInputPage(WebDriver driver){

		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}

	@FindBy(id = "fromProcessId")
	public WebElement Ele_Process;

	@FindBy(id = "itemTableId")
	public WebElement Ele_Data;
	
	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement Back_Btn;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement ContinueButton;

	@Step("Select Process Field :  \"{0}\" ")
	public void selectProcessField(String FieldType){
		selType = new Select(Ele_Process);
		selType.selectByVisibleText(FieldType);
	}
	
	public boolean isSMprocDisplayed(String proc){
	    try{
	        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	        selType = new Select(Ele_Process);
	        selType.selectByVisibleText(proc);
	        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	        return true;
	    } catch (org.openqa.selenium.NoSuchElementException e){
	        return false;
	    }
	}

	@Step("Select Data Field :  \"{0}\" ")
	public void selectDataField(String FieldType){
		selType = new Select(Ele_Data);
		selType.selectByVisibleText(FieldType);
	}

	public boolean getJobNodisplayed(){
		String jobNo = driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText();
		if(jobNo.equalsIgnoreCase("")){
			return false;
		} else {
			return true;
		}
	}
	
	@Step("Clicked on Back button")
	public void clickBackBtn(){
		Back_Btn.click();
	}
	
	@Step("Click Continue Button on Source Input Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}

	}

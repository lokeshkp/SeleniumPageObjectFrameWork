package com.equifax.cms.fusion.test.RFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class CustomSuppPage {

    WebDriver driver;

    public CustomSuppPage(WebDriver driver){

        this.driver = driver;

        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "add1")
    WebElement LeftToRightForwardButton;

    @FindBy(id = "add2")
    WebElement RightToLeftForwardButton;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }
    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;


    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }
    @Step ("click the back button")
    public void clickBackButton(){
        BackBtn.click();
    }
    @Step ("Select the Left Custom Suppression Options = \"{0}\"")
    public void selectLeftFields(String option){
        String delimiter = ",";
        StringTokenizer field = new StringTokenizer(option, delimiter);
        while(field.hasMoreTokens()){
            String dynPath = "(.//a[contains(text(),'"+field.nextToken()+"')])[1]";
            driver.findElement(By.xpath(dynPath)).click();
            LeftToRightForwardButton.click();
        }
    }

    @Step ("Select the Right Custom Suppression Options = \"{0}\"")
    public void selectRightFields(String option){
        String delimiter = ",";
        StringTokenizer field = new StringTokenizer(option, delimiter);
        while(field.hasMoreTokens()){
            String dynPath = "(.//a[contains(text(),'"+field.nextToken()+"')])[2]";
            driver.findElement(By.xpath(dynPath)).click();
            RightToLeftForwardButton.click();
        }
    }
    @Step ("Select the Left Custom Suppression Options = \"{0}\"")
    public void selectLeftField(String field) throws InterruptedException{
        String delimiter = ",";
        StringTokenizer option = new StringTokenizer(field, delimiter);
        while(option.hasMoreTokens()){
            String dynPath = "//div[@class='content1 customcontent1']//a[contains(text(),'"+option.nextToken()+"')]";
            Thread.sleep(2000);
            driver.findElement(By.xpath(dynPath)).click();

            driver.findElement(By.xpath(dynPath)).click();
            LeftToRightForwardButton.click();
        }
    }
    @Step ("Select the Right Custom Suppression Options = \"{0}\"")
    public void selectRightField(String field) throws InterruptedException
    {
        String delimiter = ",";
        StringTokenizer option = new StringTokenizer(field, delimiter);
        while(option.hasMoreTokens()){
            String dynPath = "//div[@class='content2 customcontent2']//a[contains(text(),'"+option.nextToken()+"')]";
            Thread.sleep(2000);
            driver.findElement(By.xpath(dynPath)).click();
            driver.findElement(By.xpath(dynPath)).click();
            RightToLeftForwardButton.click();
        }
    }

    @Step ("Fetch The Selected Left Fields When Custom Suppression Is Selected")
    public List<String> getTheSelectedLeftFields() throws InterruptedException
    {
        List<String> selectedLeftfields=new ArrayList<String>();
        List<WebElement> noOfLeftFieldsSelected= driver.findElements(By.xpath("//div[@id='selectedContent1']/div"));
        for(int i=1;i<=noOfLeftFieldsSelected.size();i++)
        {
            String selectedField= driver.findElement(By.xpath("//div[@id='selectedContent1']/div[" + i + "]/ul/li[2]/span")).getText();
            selectedLeftfields.add(selectedField);
        }
        return selectedLeftfields;
    }
    @Step ("Fetch The Selected Right Fields When Custom Suppression Is Selected")
    public List<String> getTheSelectedRightFields() throws InterruptedException
    {
        List<String> selectedRightfields=new ArrayList<String>();
        List<WebElement> noOfRightFieldsSelected= driver.findElements(By.xpath("//div[@id='selectedContent2']/div"));
        for(int i=1;i<=noOfRightFieldsSelected.size();i++)
        {
            String selectedField= driver.findElement(By.xpath("//div[@id='selectedContent2']/div[" + i + "]/ul/li[2]/span")).getText();
            selectedRightfields.add(selectedField);
        }
        return selectedRightfields;
    }

    /* (//li[contains(@id, 'HEADER')]/a[contains(text(),'HEADER.CITY')])[2]
     */}

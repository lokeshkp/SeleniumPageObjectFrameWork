//

package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class DMSummaryPage
{

    WebDriver driver;

    public DMSummaryPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[1]/td[2]")
    public WebElement DataOrigin;

    @FindBy(xpath = ".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[2]/td[2]")
    public WebElement Product;

    @FindBy(xpath = ".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[3]/td[2]/div/span")
    public WebElement CreditInput;

    @FindBy(xpath = ".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[3]/td[2]/div")
    public WebElement dimensionInput;

    @FindBy(xpath = ".//*[@id='dataMenuSummaryForm']/div[3]/table/tbody/tr[4]/td[2]")
    public WebElement UniqueCIDindex;

    @FindBy(xpath = "//td[contains(text(),'Score Model')]//preceding::tr[1]/td[2]/a")
    public WebElement ScoreModel;

    @FindBy(xpath = "//td[contains(text(),'FUSION_FRIENDLY_MOD')]")
    public WebElement FUSION_FRIENDLY_MOD;

    @FindBy(xpath = "//label[contains(text(),'Number per Accept Code:')]//following::td[1]")
    public WebElement NoPerAccCode;

    @FindBy(xpath = "//label[contains(text(),'Number per Reject Code:')]//following::td[1]")
    public WebElement NoPerRejCode;

    @FindBy(xpath = "//label[contains(text(),'Hold for additional data append via Move Statements:')]//following::td[1]")
    public WebElement HoldAddMoveSt;

    @FindBy(xpath = "//a[contains(text(),'View XML')]")
    WebElement ViewXMLBtn;

    @FindBy(xpath = "//span[contains(text(),'JOB XML')]")
    WebElement JobXMLhdr;

    @FindBy(xpath = "//label[contains(text(),'DNS Drop:')]//following::td[1]")
    public WebElement DNSDrop;

    @FindBy(xpath = "//label[contains(text(),'Invalid/Blank')]//following::td[1]")
    public WebElement InvAgeDrop;

    @FindBy(xpath = "//span[contains(text(),'Invalid Street Address:')]//following::td[1]")
    public WebElement InvStreetAddress;

    @FindBy(xpath = "//span[contains(text(),'Create 540 File:')]//following::td[1]")
    public WebElement Create540File;

    @FindBy(xpath = ".//*[@id='wrapper']/div[4]/a[2]")
    public WebElement saveToFile;

    @FindBy(xpath = ".//input[@type='submit']")
    WebElement SubmitButton;

    @Step("Clicked on XML button in summary")
    public void clickViewXMLbtn()
    {
        ViewXMLBtn.click();
    }

    @Step("Get the Job XML Header")
    public String getJobXMLhdr()
    {
        String hdr = JobXMLhdr.getText();
        return hdr;
    }

    @Step("Click Submit button")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }

    public String splitScoreModelNo(String modNo)
    {
        String[] a = modNo.split(",");
        return "CMDL" + a[0];
    }

    @Step("Get XML contents ")
    public String getJobXmlContents()
    {
        String xmlText = driver.findElement(By.xpath(".//*[@id='xmlArea']/pre")).getText();
        return xmlText;
    }

    @Step("Get Save to File")
    public String getSaveToFile()
    {
        String text = saveToFile.getText();
        return text;
    }

    @Step("Get Source Match table details")
    public String getSMTableDetails(String index)
    {
        String str = driver.findElement(By.xpath(".//*[@id='newLayoutTable']/tbody/tr/td[" + index + "]")).getText();
        return str;
    }

    // fetches the input process name in case of list source DM from summary
    public String getInputProcessNameFromSummary()
    {
        String ProcName = driver.findElement(By.xpath("//div[starts-with(text(),'Input')]/parent::div/table/tbody/tr/td[1]")).getText();
        String[] procNameArr = ProcName.split(":");
        return procNameArr[0]+":"+procNameArr[1];
    }

    @Step("Check if error is present")
    public String checkIfErrorIsPresent(String apModule)
    {
        String errMsg = driver.findElement(By.xpath(".//*[@class='optionsErrMsg']")).getText();
        return errMsg;
    }

    @Step("Audit Sample File in DM Summary")
    public boolean isAuditInSum()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            driver.findElement(By.xpath("//div[contains(text(),'Audit Sample Files')]")).getText();
            driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
            return false;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return true;
        }
    }
}

package com.equifax.cms.fusion.test.SFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

public class SfStatsView
{
    WebDriver driver;

    public SfStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @Step("Fetched Input Table Name")
    public String getInputTableNameSF()
    {
        String sfInputTableName = driver.findElement(By.xpath("//div[contains(text(), 'Input table name')]/following-sibling::div")).getText();
        return sfInputTableName;
    }

    @Step("Fetched Input Table record Count")
    public String getInputTableCountSF()
    {
        String sfInputTableCount = driver.findElement(By.xpath("//div[contains(text(), 'Input table record count')]/following-sibling::div"))
                .getText();
        return sfInputTableCount;
    }

    @Step("Fetched Header Table Name")
    public String getHeaderTableNameSF()
    {
        String sfHeaderTableName = driver.findElement(By.xpath("//div[contains(text(), 'Header table name')]/following-sibling::div")).getText();
        return sfHeaderTableName;
    }

    @Step("Fetched Header Table record Count")
    public String getHeaderTableCountSF()
    {
        String sfHeaderTableCount = driver.findElement(By.xpath("//div[contains(text(), 'Header table record count')]/following-sibling::div"))
                .getText();
        return sfHeaderTableCount;
    }

    @Step("Fetched Sample Index Table Name")
    public String getSampleIndexTableNameSF()
    {
        String sfSampleIndexTableName = driver.findElement(By.xpath("//div[contains(text(), 'AUDIT_SAMPLE_INDEX Table')]/following-sibling::div"))
                .getText();
        return sfSampleIndexTableName;
    }

    @Step("Fetched Sample Index Table Count")
    public String getSampleIndexTableCountSF()
    {
        String sfSampleIndexTableCount = driver.findElement(By.xpath("//div[contains(text(), 'AUDIT_SAMPLE_INDEX Table')]/following::div[4]"))
                .getText();
        return sfSampleIndexTableCount;
    }

    @Step("Get sample extract location")
    public String getAuditExtractLocation()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Audit XMLs Extracted to location')]/following::div[1]")).getText();
    }

    @Step("Get total sample extract records")
    public String getAuditExtractRecCount()
    {
        return driver.findElement(By.xpath("//div[contains(text(),'Total number of records')]/following::div[1]")).getText();
    }

    @Step("Fetched Audit Table with list of CIDs used for export")
    public String getAuditTableCIDSF()
    {
        String sfSampleIndexTableName = driver.findElement(
                By.xpath("//div[contains(text(), 'Audit table with list of CIDs used for export')]/following-sibling::div")).getText();
        return sfSampleIndexTableName;
    }

    @Step("Fetched Audit Tables from which data exported")
    public String getTablesExportedSF()
    {
        String sfTablesDataExported = driver.findElement(
                By.xpath("//div[contains(text(), 'Tables from which data exported')]/following-sibling::div")).getText();
        return sfTablesDataExported;
    }

    @Step("Fetch the Row Ids")
    public List<String> getWorkItems()
    {
        List<String> rowId_List = new ArrayList<String>();
        String tr_Id_1 = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[3]")).getAttribute("id");
        rowId_List.add(tr_Id_1);
        String tr_Id_2 = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[4]")).getAttribute("id");
        rowId_List.add(tr_Id_2);
        String tr_Id_3 = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[5]")).getAttribute("id");
        rowId_List.add(tr_Id_3);
        return rowId_List;
    }

    public List<String> verifyIfJetExecuted(List<String> workItemAssocIds)
    {
        List<String> artifacts = new ArrayList<>();
        for (String id : workItemAssocIds)
        {
            String artifactName = driver.findElement(By.xpath("//tr[@id='" + id + "']/td[3]")).getText();
            artifacts.add(artifactName);
        }
        return artifacts;
    }
}

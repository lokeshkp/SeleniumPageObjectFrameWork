package com.equifax.cms.fusion.test.FICOpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import ru.yandex.qatools.allure.annotations.Step;

public class FICOsummaryPage {
	WebDriver driver;
	
	public FICOsummaryPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "submitButton")
	WebElement SubmitBtn;
	
	@Step("Clicked on Submit Button")
	public void clickSubmitBtn(){
		SubmitBtn.click();
	}
	
	public String procInSum(String proc){
		String procSum = driver.findElement(By.xpath("//td[contains(text(),'"+proc+"')]")).getText();
		String[] a = procSum.split(":");
		System.out.println(" "+a[1]);
		return " "+a[1];
	}
}

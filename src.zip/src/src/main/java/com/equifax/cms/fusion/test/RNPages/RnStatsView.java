package com.equifax.cms.fusion.test.RNPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class RnStatsView {
    WebDriver driver;

    public RnStatsView(WebDriver driver){
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }



    @Step("Fetched Input Table Name")
    public String getInputTableNameRN(){
        String InputTableName = driver.findElement(By.xpath("//div[text()='INPUT']//parent::div/parent::div/following::div[1]//div[1]")).getText();
        return removeColon(InputTableName);
    }

    @Step("Fetched Input Table Count for Random Nth From Stats")
    public Long getInputTableCountRN(){
        String RNInputTableCount =  driver.findElement(By.xpath("(.//*[@id='left-child-row'])[1]/following-sibling::div")).getText();
        return Long.parseLong(removeComma(RNInputTableCount));
    }

    @Step("Fetched Input Records selected for processing from Stats")
    public Long getRecordsProcessedCountRN(){
        String rnRecordsProcessedCount =  driver.findElement(By.xpath("//div[contains(text(),'Input Records Selected For Processing')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(rnRecordsProcessedCount));
    }

    @Step("Fetched Output Random Nth Table Name")
    public String getOutputTableNameRN(){
        String RNOutputTableName = driver.findElement(By.xpath("//div[contains(text(),'_RANDOMNTH_GPFILTER_RNOPTBL')]")).getText();
        return removeColon(RNOutputTableName);
    }

    @Step("Fetched Output Table Count for Random Nth From Stats")
    public Long getOutputTableCountRN(){
        String RNOutputTableCount =  driver.findElement(By.xpath("//div[contains(text(),'_RANDOMNTH_GPFILTER_RNOPTBL')]/following::div[10]")).getText();
        return Long.parseLong(removeComma(RNOutputTableCount));
    }

    @Step("Fetched Surplus record Count for Random Nth From Stats")
    public Long getSurplusCountRN(){
        String RNSurplusCount =  driver.findElement(By.xpath("//div[contains(text(),'_RANDOMNTH_GPFILTER_RNOPTBL')]/following::div[7]")).getText();
        return Long.parseLong(removeComma(RNSurplusCount));
    }

    /*@Step("Fetched SR-Nth Drop Count for Random Nth From Stats")
	public Long getSRNthDropCountRN(){
		String SRNthDropCount =  driver.findElement(By.xpath(".//div[contains(text(),'SR-Nth Drop')]/following::div[1]")).getText();
		return Long.parseLong(SRNthDropCount);
	}*/

    @Step("Fetched SR Nth Drop solution")
    public Long getSRNthFlagCountRN(){
        String srNthFlagCount = driver.findElement(By.xpath("//div[contains(text(),'SR-Nth Drop')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(srNthFlagCount));
    }


    public static String removeComma(String a)
    {
        String a2="";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2=a2+element;
        }
        return a2;
    }

    public static String removeColon(String a)
    {
        String[] a1 = a.split(":");
        return a1[0].trim();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"),PropertiesUtils.getProperty("gp.user"),PropertiesUtils.getProperty("gp.password"));
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsProcessCountFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+table+"";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public long getRecordsProcGrpCountFromGP(String query,String groupName) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+query+" where group_name = '"+groupName+"'";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Bypass record count for Table = \"{0}\"")
    public long getBypassRecCountFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+query+" where nth_flag IS NULL";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching Bypass record count for Table = \"{0}\"")
    public long getNthFlagCountFromGP(String query) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+query+" where nth_flag = 'A'";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

    @Step("Fetching SR-Nth Drop count for table = \"{0}\" \"{1}\"")
    public long getSRNthDropCountFromGP(String table, String hdrTble) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+table+" where nth_flag = 'R' and fail_code = 'SR' and dp_sequence_num in(select dp_sequence_num from fusion_stage."+hdrTble+")";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Count of Records Whose Failcode Is Null")
    public long getCountOfAcceptedRecordsFromInputTable(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+table+" where fail_code is null";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Count Of Bypassed Records From The Table")
    public long getCountOfBypassedRecordsFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+table+" where nth_flag is null";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }
    
    
    @Step("Fetching Count Of Records Processed")
    public long getCountOfProcessedRecordsFromGP(String table) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage."+table+" where nth_flag is not null";
        System.out.println("GP Query : "+query1);
        PreparedStatement ps = conn.prepareStatement(query1);
        ResultSet rs = ps.executeQuery();
        long records = 0;
        while(rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }

}





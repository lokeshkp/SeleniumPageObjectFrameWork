package com.equifax.cms.fusion.test.DMPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class PointScoreDropsPage
{

    WebDriver driver;

    public PointScoreDropsPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    @FindBy(id = "psDropRuleStatus1")
    WebElement DoNotRejectRecord;

    @FindBy(id = "psDropRuleStatus2")
    WebElement RejectIfAnySelectedFails;

    @FindBy(id = "psDropRuleStatus3")
    WebElement RejectIfALLSelectedFails;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement Back_Btn;

    @FindBy(xpath = ".//*[@class='orange-btn'][2]")
    WebElement Continue_Btn;

    public void selectPointScoreDrop(String option)
    {
        String psdRule[] = option.split(":");
        if (psdRule[0].equalsIgnoreCase("DoNotReject"))
        {
            DoNotRejectRecord.click();
        } else if (psdRule[0].equalsIgnoreCase("RejectIfAnyFails"))
        {
            RejectIfAnySelectedFails.click();
        } else if (psdRule[0].equalsIgnoreCase("RejectIfAllFails"))
        {
            RejectIfALLSelectedFails.click();
        }
    }

    public void selectModelSelections_CB(String option)
    {
        if (option.contains(":"))
        {
            String modelSelection[] = option.split(":");
            StringTokenizer stMain = new StringTokenizer(modelSelection[1], ";");
            int i = 0;
            while (stMain.hasMoreElements())
            {
                String scmodel[] = stMain.nextToken().split(",");
                if (scmodel[1].equalsIgnoreCase("check"))
                {
                    driver.findElement(By.xpath(".//*[@value='" + scmodel[0].trim() + "']//preceding::input[6]")).click();
                }
                i++;
            }
        }
    }

    @Step("Clicked on Back button")
    public void clickBack_Btn()
    {
        Back_Btn.click();
    }

    @Step("Clicked on Continue button")
    public void clickContinue_Btn()
    {
        Continue_Btn.click();
    }
}
package com.equifax.cms.fusion.test.FILPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class FilteringPage
{
    public static int i = 1;
    WebDriver driver;
    public Select selType;

    public FilteringPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    @FindBy(name = "groups[1].conditions[1].filters[0].value")
    public WebElement valueG2C2;

    @FindBy(name = "groups[1].conditions[0].filters[0].value")
    public WebElement valueG2C1;

    @FindBy(name = "groups[0].conditions[1].filters[0].value")
    public WebElement valueG1C2;

    @FindBy(id = "desiredOutput")
    public WebElement G1DOC;

    @FindBy(xpath = "(.//*[@id='condnNameDefault'])[1]")
    public WebElement conditionNameG1C1;

    @FindBy(xpath = "(.//*[@id='condnNameDefault'])[2]")
    public WebElement conditionNameG1C2;

    @FindBy(xpath = "(.//*[@id='condnNameDefault'])[3]")
    public WebElement conditionNameG2C1;

    @FindBy(xpath = "(.//*[@id='condnNameDefault'])[4]")
    public WebElement conditionNameG2C2;

    @FindBy(xpath = ".//*[@value='Duplicate Condition']")
    WebElement DuplcicateConditionButtonG1C1;

    @FindBy(name = "groups[0].conditions[0].filters[0].value")
    public WebElement gc1ValueTextBox;

    @FindBy(xpath = ".//*[@id='Group0_Condition0']/div[1]/a/img")
    WebElement g1c1RemoveButton;

    @FindBy(xpath = "//*[@name='groups[0].conditions[0].filters[0].filterType']/option[@selected='']")
    public WebElement g1c1RangeOrValue;

    @FindBy(name = "groups[0].conditions[0].filters[0].rangeFrom")
    public WebElement g1c1RangeFrom;

    @FindBy(name = "groups[0].conditions[0].filters[0].rangeTo")
    public WebElement g1c1RangeTo;

    @FindBy(id = "allRecordsGroups")
    WebElement AllRecsGrp;

    @FindBy(xpath = ".//*[@id='groupNames0'][1]")
    WebElement Grp1;

    @FindBy(xpath = ".//*[@name='groupNames[1].isSelected']")
    WebElement Grp2;

    @FindBy(xpath = ".//*[@name='groupNames[2].isSelected']")
    WebElement Grp3;

    @FindBy(id = "processName")
    public WebElement processName_Field;

    @FindBy(id = "fromProcessId")
    WebElement process_DD;

    @FindBy(id = "itemTableId")
    WebElement data_DD;

    @FindBy(xpath = ".//*[@id='duplicateGroupDiv']/select")
    WebElement groupCountToDuplicate;

    @FindBy(id = "jobId")
    WebElement jobId;

    @FindBy(xpath = ".//*[@id='resolveFields']")
    WebElement ResolveFields_Button;

    @FindBy(xpath = "(.//*[@selected='selected'])[1]")
    public WebElement processSelected;

    @FindBy(xpath = "(.//*[@selected='selected'])[2]")
    public WebElement dataSelected;

    @FindBy(id = "listVirtualArtifacts0.userProvidedName")
    public WebElement outputTableName_Field;

    @FindBy(id = "resolveFields")
    WebElement resolveFields_Btn;

    @FindBy(id = "performCuts")
    public WebElement performCuts_CB;

    @FindBy(xpath = "//input[@value='Add New Group']")
    public WebElement addNewGroup_Btn;

    @FindBy(id = "searchBox")
    WebElement searchBox_Field;

    @FindBy(xpath = ".//*[@class='orange-btn']")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@value='Save']")
    WebElement save_Btn;

    @FindBy(xpath = ".//*[@name='submitButton'][2]")
    WebElement continue_Btn;

    @FindBy(id = "groupname")
    public WebElement firstGroupName_Field;

    @FindBy(xpath = "(.//*[@id='groupname'])[2]")
    public WebElement secondGroupName_Field;

    @FindBy(id = "filterType")
    WebElement filterType_DD;

    @FindBy(id = "textMsg")
    WebElement textMsg;

    @FindBy(id = "popup_message")
    WebElement popupMessage;

    @FindBy(id = "popup_ok")
    WebElement popupOK;

    @FindBy(id = "erMsg")
    WebElement errorMsg2;

    @FindBy(id = "errMsg")
    WebElement errorMsg;

    @FindBy(id = "group0")
    WebElement G1;

    @FindBy(id = "group1")
    WebElement G2;

    @FindBy(xpath = ".//*[@id='group1']/div[2]")
    WebElement groupExandedData;

    @FindBy(xpath = ".//*[id('popup_ok')]")
    WebElement clickPopupOk;

    @FindBy(xpath = ".//*[@id='Group1_Condition0']/div[1]/a/img")
    WebElement removeGtwo;

    @FindBy(xpath = ".//*[@class='ConditionExpandedIcon']")
    WebElement conditionExpandedIcon;

    @FindBy(xpath = ".//*[@class='ConditionCollapsedIcon']")
    WebElement conditionCollapsedIcon;

    @FindBy(id = "duplicateGrp_ok")
    WebElement duplicateGrpOK;

    @FindBy(xpath = ".//*[@id='textMsgdataTypeValidation']/span")
    WebElement ValuefieldTypeErrorMessage;

    @FindBy(xpath = ".//*[@id='textMsgdataTypeValidation']/span[1]")
    WebElement FieldTypeErrorMessage1;

    @FindBy(xpath = ".//*[@id='textMsgdataTypeValidation']/span[2]")
    WebElement FieldTypeErrorMessage2;

    @FindBy(xpath = ".//*[@id='group1']/div[1]/span[1]/img[1]")
    WebElement collapseGroup2;

    @FindBy(xpath = ".//*[@id='group1']/div[1]/span[1]/img[2]")
    WebElement expandGroup2;

    @FindBy(xpath = ".//*[@id='content-item-0']/a/span")
    WebElement expandField;

    @FindBy(xpath = "//div[@class='content']//a[contains(text(),'HEADER')]/span")
    WebElement selectedHeaderTableClass;

    @FindBy(xpath = "//div[@class='available-fields']/div[2]/ul/li/a[contains(text(),'AUDIT_SAMPLE_INDEX')]/span")
    WebElement auditTable;

    @FindBy(xpath = "//div[@class='available-fields']/div[2]/ul/li/a[contains(text(),'INQUIRYPOSTTBL')]/span")
    WebElement inquiryPostTable;

    @FindBy(xpath = "//div[@class='available-fields']/div[2]/ul/li/a[contains(text(),'AGECRIT')]/span")
    WebElement agercritTable;

    @FindBy(xpath = "//div[@class='available-fields']/div[2]/ul/li/a[contains(text(),'STEP_FLAG')]/span")
    WebElement stepFlagTable;

    @FindBy(xpath = ".//*[@id='add']")
    WebElement addOnResolveFieldWindow;

    @FindBy(xpath = ".//*[@id='jobNumbersMap']")
    WebElement mapJobNumber;

    public void inputGroupName1(int grpNumber, String name)
    {
        driver.findElement(By.xpath("(.//*[@id='groupname'])[" + grpNumber + "]")).clear();
        driver.findElement(By.xpath("(.//*[@id='groupname'])[" + grpNumber + "]")).sendKeys(name);
    }

    public void clickFieldExpand()
    {
        expandField.click();
    }

    public void clickDupliCondiG1C1()
    {
        DuplcicateConditionButtonG1C1.click();
    }

    public String getValueFieldTypeErrorMessage()
    {
        return ValuefieldTypeErrorMessage.getText();
    }

    public String getRangeFieldTypeErrorMessage1()
    {
        return FieldTypeErrorMessage1.getText();
    }

    public String getRangeFieldTypeErrorMessage2()
    {
        return FieldTypeErrorMessage2.getText();
    }

    public boolean isGroupConditionTextBoxDisplayed(int g, int c, int f)
    {
        return driver.findElement(By.name("groups[" + (g - 1) + "].conditions[" + (c - 1) + "].filters[" + (f - 1) + "].value")).isEnabled();
    }

    public boolean isGroup1Displayed()
    {
        try
        {
            G1.click();
            return true;
        } catch (Exception e)
        {
            return false;
        }

    }

    // click ok when error pops up
    @Step("click ok on validation popup")
    public void clickValidationPopup()
    {
        popupOK.click();
    }

    @Step("condition expand icon click")
    public void conditionExpandedIcon(int grpNo, int condNo)
    {

        driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "_Condition" + condNo + "']/div[1]/span[1]/img[1]")).click();

    }

    @Step("get display label for desired count per group")
    public void desiredCountlabel(int grpNo)
    {

        driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "']/div[1]/span[1]/img[1]")).click();

    }

    @Step("Get Selected Table class")
    public String selectedTableClassValue()
    {
        return selectedHeaderTableClass.getAttribute("class");
    }

    @Step("condition field name")
    public String getConditionFieldName(int grpNo, int condNo, int filter)
    {

        // return driver.findElement(By.xpath(".//*[@id='fieldName']")).getAttribute("value");
        return driver.findElement(By.name("groups[" + grpNo + "].conditions[" + condNo + "].filters[" + filter + "].fieldName"))
                .getAttribute("value");
    }

    @Step("condition field Range/Value")
    public String getConditionRangeValue(int grpNo, int condNo, int rowNo)
    {
        String s = driver.findElement(By.xpath(".//*[@id='filterType']")).getAttribute("value");
        return s;
    }

    @Step("condition field operator")
    public String getConditionFieldOperator(int grpNo, int condNo, int filter)
    {
        Select filtertype = new Select(driver.findElement(By
                .name("groups[" + grpNo + "].conditions[" + condNo + "].filters[" + filter + "].operator")));
        return filtertype.getFirstSelectedOption().getAttribute("value");

    }

    @Step("condition field value")
    public String getConditionFieldValueText(int grpNo, int condNo, int filter)
    {

        return driver.findElement(By.name("groups[" + grpNo + "].conditions[" + condNo + "].filters[" + filter + "].value")).getAttribute("value");

    }

    @Step("condition name")
    public String getConditionName(int grpNo, int condNo)
    {

        return driver.findElement(By.name("groups[" + grpNo + "].conditions[" + condNo + "].tag")).getAttribute("value");

    }

    @Step("condition collapse icon click")
    public void conditionCollapsedIcon(int grpNo, int condNo)
    {
        driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "_Condition" + condNo + "']/div[1]/span[1]/img[2]")).click();
    }

    @Step("{method}")
    public void clickRemoveG1C1()
    {
        g1c1RemoveButton.click();
        driver.switchTo().alert().accept();
    }

    @Step("{method}")
    public boolean isAllRecordsSelectedGrp()
    {
        return AllRecsGrp.isSelected();
    }

    @Step("{method}")
    public boolean isGrp1Selected()
    {
        return Grp1.isSelected();
    }

    @Step("{method}")
    public boolean isGrp2Selected()
    {
        return Grp2.isSelected();
    }

    @Step("{method}")
    public boolean isGrp3Selected()
    {
        return Grp3.isSelected();
    }

    @Step("{method}")
    public boolean isPerformCutsSelected()
    {
        return performCuts_CB.isSelected();
    }

    @Step("{method}")
    public String getJobId()
    {
        return jobId.getText();
    }

    @Step("{method}")
    public void selectPerformCuts_CB(String option)
    {
        if ("Y".equalsIgnoreCase(option))
        {
            if (!performCuts_CB.isSelected())
            {
                performCuts_CB.click();
            }
        } else if ("N".equalsIgnoreCase(option))
        {
            if (performCuts_CB.isSelected())
            {
                performCuts_CB.click();
            }
        }
    }

    public boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            Thread.sleep(2000);
            driver.findElement(By.id("popup_ok"));
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Clicked Duplicate Group Button")
    public void clickDupliGrpOk()
    {
        duplicateGrpOK.click();
    }

    @Step("Selected Groups to Duplicate as = {0}")
    public void selectGroupsToDuplicate(String count)
    {
        selType = new Select(driver.findElement(By.xpath(".//*[@id='duplicateGroupDiv']/select")));
        selType.selectByVisibleText(count);
    }

    @Step("Clicked Remove Group Two")
    public void removeGroupTwo()
    {
        removeGtwo.click();
        driver.switchTo().alert().accept();
    }

    @Step("Checked is Group Present for Group = {0}")
    public boolean isGroupPresent(int group)
    {
        try
        {
            driver.findElement(By.id("group" + (group - 1))).click();
            return true;
        } catch (Exception e)
        {
            return false;
        }
    }

    @Step("Provided Output Table Name for Filtering Process as {0}")
    public void inputOutputTableName(String name)
    {
        outputTableName_Field.clear();
        if (!"NA".equalsIgnoreCase(name))
        {
            outputTableName_Field.sendKeys(name);
        }
    }

    @Step("Fetched Error Message for Filtering Process")
    public String getErrorMessage2()
    {
        return errorMsg2.getText();
    }

    @Step("Fetched Error Message for Filtering Process")
    public String getErrorMessage()
    {
        return errorMsg.getText();
    }

    @Step("Clicked OK on Pop Up")
    public void clickPopUpOk()
    {
        popupOK.click();
    }

    @Step("Fetched Pop Up text displyed")
    public String getpopUpText()
    {
        return popupMessage.getText();
    }

    @Step("Click ok on Pop Up text displyed")
    public void clickpopUpText()
    {
        popupMessage.click();
    }

    @Step("Fetched Text Message")
    public String gettextMessage()
    {
        return textMsg.getText();
    }

    @Step("Fetched Page Header")
    public String getPageHeader()
    {
        return driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText();
    }

    @Step("Clicked Save Button")
    public void clickSaveButton()
    {
        save_Btn.click();
    }

    @Step("Clicked Continue Button")
    public void clickContinueButton()
    {
        continue_Btn.click();
    }

    @Step("Clicked Back Button")
    public void clickBackButton()
    {
        back_Btn.click();
    }

    @Step("Provided Filtering Process Name as {0}")
    public void inputProcessName(String processName)
    {
        processName_Field.clear();
        processName_Field.sendKeys(processName);
    }

    @Step("Selected Input Process as {0}")
    public void selectProcess(String process)
    {
        selType = new Select(process_DD);
        selType.selectByVisibleText(process);
    }

    @Step("Selected Data for Input Process as {0}")
    public void selectData(String data) throws InterruptedException
    {
        Thread.sleep(5000);
        selType = new Select(data_DD);
        selType.selectByVisibleText(data);
        Thread.sleep(10000);
    }

    @Step("Select Group count to duplicate")
    public void selectGroupCount(String data) throws InterruptedException
    {
        Thread.sleep(2000);
        selType = new Select(groupCountToDuplicate);
        selType.selectByVisibleText(data);
        Thread.sleep(10000);
    }

    @Step("Clicked Add New Group Button")
    public void clickAddNewGroupBtn()
    {
        addNewGroup_Btn.click();
    }

    @Step("groups collapse when the user clicks on the downward sign (V)")
    public void collapseGroups()
    {
        collapseGroup2.click();
    }

    @Step("groups expands when the user clicks on the downward sign (>)")
    public void expandGroups()
    {
        expandGroup2.click();
    }

    @Step("Provided Group Name as {1} for Group No. {0}")
    public void inputGroupName(int groupno, String groupName)
    {
        if (groupno == 1)
        {
            firstGroupName_Field.clear();
            firstGroupName_Field.sendKeys(groupName);
        } else
        {
            driver.findElement(By.xpath(".//*[@id='group" + (groupno - 1) + "']/div[1]/input[1]")).clear();
            driver.findElement(By.xpath(".//*[@id='group" + (groupno - 1) + "']/div[1]/input[1]")).sendKeys(groupName);
        }
    }

    @Step("Provided Desired Output Count for Group No. {0} as {1}")
    public void inputDesiredOutputCount(int groupno, String count)
    {
        if (!"NA".equalsIgnoreCase(count))
        {
            if (groupno == 1)
            {
                driver.findElement(By.xpath(".//*[@id='group0']/div[1]/input[2]")).clear();
                driver.findElement(By.xpath(".//*[@id='group0']/div[1]/input[2]")).sendKeys(count);
            } else
            {
                driver.findElement(By.xpath("(.//*[@id='desiredOutput'])[" + (groupno - 1) + "]")).clear();
                driver.findElement(By.xpath("(.//*[@id='desiredOutput'])[" + (groupno - 1) + "]")).sendKeys(count);
            }
        }
    }

    @Step("Clicked Duplicate Group Button for Group No. {0}")
    public void clickDupliGrpButton(int groupno)
    {
        driver.findElement(By.id("duplicateGroup" + (groupno - 1))).click();
    }

    @Step("Clicked Insert Condition Button for Group No. {0}")
    public void clickInsrtCondiButton(int groupno)
    {
        driver.findElement(By.id("insertCondition" + (groupno - 1))).click();
    }

    @Step("Clicked Add Selected Field for Group No. {0} and Condition No. 1")
    public void clickAddConditonBtn_firstcondi(int group)
    {
        driver.findElement(By.xpath(".//*[@id='Group" + (group - 1) + "_Condition0']/div/div[@class='action-blk']")).click();
    }

    @Step("Clicked Add Selected Field for Group No. {0} and Condition No. 2")
    public void clickAddConditonBtn_secondcondi(int group)
    {
        driver.findElement(By.xpath(".//*[@id='Group" + (group - 1) + "_Condition1']/div[2]/div[1]/img")).click();
    }

    @Step("Provided Condition Name as {2} for Group No. {0} and Condition No. {1}")
    public void inputConditionName(int group, int conditn, String condiname)
    {
        if (!"NA".equalsIgnoreCase(condiname))
        {
            if (group == 1 && conditn == 1)
            {
                driver.findElement(By.xpath("(.//*[@id='condnNameDefault'])[1]")).sendKeys(condiname);
            } else if (group == 1 && conditn == 2)
            {
                driver.findElement(By.xpath(".//*[@id='condnNameDefault1conditionName']")).sendKeys(condiname);
                // id('Group0_Condition0_Row1')/x:ul/x:li[1]
            } else if (group == 2 && conditn == 1)
            {
                driver.findElement(By.xpath(".//*[@id='condnNameDefault1_Condition0']")).sendKeys(condiname);
            } else if (group == 2 && conditn == 2)
            {
                driver.findElement(By.xpath(".//*[@id='condnNameDefault2conditionName']")).sendKeys(condiname);
            }
        }
    }

    @Step("Selected Field For Filtering From Available Fields as {1} from Table {0}")
    public void selectFieldForFiltering(String table, String field)
    {
        try
        {
            Thread.sleep(5000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table + "')]")));
        element.click();
        try
        {
            Thread.sleep(5000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        //driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table + "')]")).click();
        WebElement element1 = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table+ "')]/following-sibling::ul/li/a[contains(text(),'" + field + "')]")));
       // driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table+ "')]/following-sibling::ul/li/a[contains(text(),'" + field + "')]")).click();
        element1.click();
    }

    @Step("Closed the Table From available Fields {0}")
    public void closeTablefromAvailableFields(String table)
    {
        driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table + "')]")).click();
    }

    @Step("Selected Filter Type as {3} for the Group No. {0} and Condition No. {1}")
    public void selectFilterTypeValue(int group, int condi, int filter, String type)
    {
        Select filtertype = new Select(driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters["
                + (filter - 1) + "].filterType")));
        if (type.equalsIgnoreCase("Values"))
        {
            filtertype.selectByVisibleText("Value");
        } else if (type.equalsIgnoreCase("Range"))
        {
            filtertype.selectByVisibleText("Range");
        }
    }

    @Step("Provided Input Range From as {3} in Group No. {0} and Condition No. {1}")
    public void inputRangeFrom(int group, int condi, int filter, String from)
    {
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeFrom")).clear();
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeFrom")).sendKeys(
                from);
    }

    @Step("Provided Input Range From as {3} in Group No. {0} and Condition No. {1}")
    public void inputRangeFrom_Float(int group, int condi, int filter, Float from)
    {
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeFrom")).clear();
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeFrom")).sendKeys(
                Float.toString(from));
    }

    @Step("Provided Input Range To as {3} in Group No. {0} and Condition No. {1}")
    public void inputRangeTo(int group, int condi, int filter, String to)
    {
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeTo")).clear();
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeTo")).sendKeys(to);
    }

    @Step("Provided Input Range To as {3} in Group No. {0} and Condition No. {1}")
    public void inputRangeTo_Float(int group, int condi, int filter, Float to)
    {
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeTo")).clear();
        driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].rangeTo")).sendKeys(
                Float.toString(to));
    }

    @Step("Input Range in Group No. {0} and Condition No. {1} as {3}")
    public void inputRangeFromTo_Float(int group, int condi, int filter, String fromTo)
    {
        String[] fromTo_arr = fromTo.split(",");
        Float fromTo_arr_From = Float.valueOf(fromTo_arr[0]);
        Float fromTo_arr_To = Float.valueOf(fromTo_arr[1]);
        inputRangeFrom_Float(group, condi, filter, fromTo_arr_From);
        inputRangeTo_Float(group, condi, filter, fromTo_arr_To);
    }

    @Step("Input Range in Group No. {0} and Condition No. {1} as {3}")
    public void inputRangeFromTo(int group, int condi, int filter, String fromTo)
    {
        String[] fromTo_arr = fromTo.split(",");
        inputRangeFrom(group, condi, filter, fromTo_arr[0]);
        inputRangeTo(group, condi, filter, fromTo_arr[1]);
    }

    public void clearRangeFromTo(int group, int condi, int filter)
    {
        inputRangeFrom(group, condi, filter, "");
        inputRangeTo(group, condi, filter, "");
    }

    @Step("Checked in Value Field Enabled For Group No. {0} and Condition No. {1}")
    public boolean isValueFieldEnabled(int group, int condi, int filter)
    {
        return driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].value"))
                .isEnabled();
    }

    @Step("Provided Value as {3} in Group No. {0} and Condition No. {1}")
    public void inputValue(int group, int condi, int filter, String value)
    {

        if (!"NA".equalsIgnoreCase(value))
        {
            driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].value")).clear();
            driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters[" + (filter - 1) + "].value")).sendKeys(
                    value);
        }
    }

    public String countCaratSymbolOccurence(String testString)
    {

        int counter = 0;
        for (int i = 0; i < testString.length(); i++)
        {
            if (testString.charAt(i) == '^')
            {
                counter++;
            }
        }
        return String.valueOf(counter);
    }

    public String getSpanValueOnCollapse(String table)
    {
        // driver.findElement(
        // By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table
        // + "')]/following-sibling::ul/li/a/span[contains(text(),'" + text + "')]")).click();

        // driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table
        // + "')]/following-sibling::ul/li/a/span").;

        // WebElement ele = driver.findElement(By.xpath(".//*[contains(@class,'on')]"));
        // System.out.println("gyedgy" + ele);
        return "";
    }

    public String getConditionValue(int group, int condi, int filter)
    {
        String s = driver.findElement(By.xpath(".//*[@name='groups[" + group + "].conditions[" + condi + "].filters[" + filter + "].value']"))
                .getAttribute("value");
        return s;
    }

    @Step("Selected Value Option Sign as {3} in Group No. {0} and Condition No. {1}")
    public void selectValueOptionSign(int group, int condi, int filter, String value)
    {

        if (!"NA".equalsIgnoreCase(value))
        {
            Select filtertype = new Select(driver.findElement(By.name("groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters["
                    + (filter - 1) + "].operator")));
            if (value.equalsIgnoreCase("equal"))
            {
                // filtertype.selectByVisibleText("= EQ");
            } else if (value.equalsIgnoreCase("notEqual"))
            {
                filtertype.selectByValue("notEqual");
            } else if (value.equalsIgnoreCase("greater"))
            {
                filtertype.selectByValue("greater");
            } else if (value.equalsIgnoreCase("less"))
            {
                filtertype.selectByValue("less");
            } else if (value.equalsIgnoreCase("greaterEqual"))
            {
                filtertype.selectByValue("greaterEqual");
            } else if (value.equalsIgnoreCase("lessEqual"))
            {
                filtertype.selectByValue("lessEqual");
            } else if (value.equalsIgnoreCase("isNull"))
            {
                filtertype.selectByValue("isNull");
            } else if (value.equalsIgnoreCase("isNotNull"))
            {
                filtertype.selectByValue("isNotNull");
            }
        }
    }

    @Step("Selected Table and Field as {1} for Group No. {0} in Condition No. 1")
    public void inputTableAndFieldC1(int group, String tableField)
    {
        String[] tabfield = tableField.split(",");
        selectFieldForFiltering(tabfield[0], tabfield[1]);
        clickAddConditonBtn_firstcondi(group);
        closeTablefromAvailableFields(tabfield[0]);
    }

    @Step("Click to expand table fields")
    public void expandTablesOnClick(String tableField)
    {
        String[] tabfield = tableField.split(",");
        closeTablefromAvailableFields(tabfield[0]);
    }

    @Step("Selected Table and Field as {1} for Group No. {0} in Condition No. 2")
    public void inputTableAndFieldC2(int group, String tableField)
    {
        String[] tabfield = tableField.split(",");
        selectFieldForFiltering(tabfield[0], tabfield[1]);
        clickAddConditonBtn_secondcondi(group);
        closeTablefromAvailableFields(tabfield[0]);
    }

    @Step("Selected Range or Value as {3} in Group No. {0} and Condition No. {1}")
    public void selectRangeOrValue(int group, int condi, int filter, String rangeValue)
    {
        selType = new Select(driver.findElement(By.xpath(".//*[@name='groups[" + (group - 1) + "].conditions[" + (condi - 1) + "].filters["
                + (filter - 1) + "].filterType']")));
        if ("Value".equalsIgnoreCase(rangeValue))
        {
            selType.selectByValue("VALUE");
        }
    }

    @Step
    public String testDesiredOutputCountlabel()
    {
        String s = driver.findElement(By.xpath("//span[@class='desiredOutput']")).getText();
        return s;
    }

    public void selectRangeValue(int group, String rangval, String fromto, String valsign, String valuevalue)
    {
        String[] arrayRV = rangval.split(":");
        String[] arrayFT = fromto.split(",");
        for (int i = 0; i < arrayRV.length; i++)
        {
            if (arrayRV[i].equalsIgnoreCase("Range"))
            {
                inputRangeFrom(group, i + 1, 1, arrayFT[0]);
                inputRangeTo(group, i + 1, 1, arrayFT[1]);
            } else if (arrayRV[i].equalsIgnoreCase("Values"))
            {
                selectFilterTypeValue(group, i + 1, 1, arrayRV[i]);
                selectValueOptionSign(group, i + 1, 1, valsign);
                inputValue(group, i + 1, 1, valuevalue);
            }
        }
    }

    public String validateGroupCollapse()
    {
        return collapseGroup2.getAttribute("style");
    }

    public String validateGroupExpand()
    {
        return expandGroup2.getAttribute("style");
    }

    public String groupExandedData(int grpNo)
    {

        String s = driver.findElement(By.xpath(".//*[@id='group" + grpNo + "']/div[2]")).getAttribute("style");
        return s;
        // return groupExandedData.getAttribute("style");
    }

    public String conditionStyleWhenCollapsed(int grpNo, int condNo)
    {
        return driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "_Condition" + condNo + "']/div[1]/span[1]/img[1]")).getAttribute("style");

    }

    public String conditionStyleWhenExpanded(int grpNo, int condNo)
    {
        return driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "_Condition" + condNo + "']/div[1]/span[1]/img[2]")).getAttribute("style");

    }

    public String conditionExpandedDataStyle(int grpNo, int condNo)
    {
        return driver.findElement(By.xpath(".//*[@id='Group" + grpNo + "_Condition" + condNo + "']/div[2]")).getAttribute("style");

    }

    @Step("Condition adds to  a particular group")
    public boolean validateConditionAddsToAppropriateGroup(int grpNo)
    {
        // WebElement ele = driver.findElement(By.xpath(".//*[@id='group" + grpNo + "']/div[2]/div[3][contains(text(),'inserGrid1')]"));
        // driver.findElement(By.xpath(".//*[@id='group" + grpNo + "']/div[2]/div[3]/div[1]"));
        boolean present;
        try
        {
            driver.findElement(By.xpath(".//*[@id='group" + grpNo + "']/div[2]/div[3]/div[1]"));
            present = true;
        } catch (NoSuchElementException e)
        {
            present = false;
        }
        // ele.
        // [contains(text(),'" + table + "')]
        return present;
    }

    @Step("Click select Header Table")
    public void clickHeaderTable()
    {
        driver.findElement(By.xpath("//div[@class='available-fields']/div[2]/ul/li/a[contains(text(),'HEADER')]")).click();
    }

    @Step("Check Audit Table collapse on Default")
    public String auditTableDefaultCollapseStatus()
    {

        return auditTable.getAttribute("class");

    }

    /*
     * @Step("Check Model Table collapse on Default") public String modelTableDefaultCollapseStatus() { return modelTable.getAttribute("class"); }
     */
    @Step("Check Inquiry Table collapse on Default")
    public String inqTableDefaultCollapseStatus()
    {

        return inquiryPostTable.getAttribute("class");

    }

    public String getGroupNameValue()
    {
        return firstGroupName_Field.getAttribute("value");
    }

    @Step("Check Agecrit Table collapse on Default")
    public String agecritTableDefaultCollapseStatus()
    {

        return agercritTable.getAttribute("class");

    }

    @Step("Check StepFlag Table collapse on Default")
    public String stepFlagTableDefaultCollapseStatus()
    {

        return stepFlagTable.getAttribute("class");

    }

    @Step("Expand first table")
    public String verifyTableExpansion()
    {
        return driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li[@id='content-item-0']/a/span"))
                .getAttribute("class");
    }

    public boolean clickOnGearBoxForEditFilterProcess()
    {
        driver.findElement(By.xpath("//div[@id='contentjqxgridJobListing']/div[2]/div[1]/div[1]/div/div/img[1]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//div[@id='ContextMenu']/ul/li[contains(text(),'Edit')]")))
                {
                    return true;

                }
            } catch (Exception e)
            {
                return false;
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

    }

    public boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

    @Step("Fetched Input Table Name FL")
    public String getInputTableNameFL()
    {
        String filterInputTable = driver.findElement(By.xpath("//div[contains(text(), 'Input Table')]/following::div[3]/div[1]")).getText();
        return filterInputTable;
    }

    @Step("Fetched Column count from stats")
    public String getColumnCountFromStats(String field)
    {
        String filterCount = driver.findElement(By.xpath("//div[contains(text(),'" + field + "')]/following-sibling::div[1]")).getText();
        return filterCount;
    }

    public String checkIfMovedToSummaryPageWithTile()
    {
        String pageTile = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText();
        return pageTile;
    }

    @Step("Click on Resolve Fields button on input change")
    public void clickResolveFields()
    {
        ResolveFields_Button.click();
    }

    @Step("Click to select field on Resolve Fields window")
    public void selectFieldOnResolveFieldsWindow(String processName, String field)
    {
        driver.findElement(By.xpath("//a[contains(text(),'" + processName + "')]/following::li/a[contains(text(),'" + field + "')]")).click();
    }

    @Step("Click to select field on Resolve Fields window")
    public void clickFieldOnResolveFieldsWindow()
    {
        driver.findElement(By.xpath("//*[@id='selectedContent1']/div/ul")).click();
    }

    @Step("Click to add field  on Resolve Fields window")
    public void addFieldOnResolveFieldsWindow()
    {
        addOnResolveFieldWindow.click();
    }

    @Step("get tool tip text over fields")
    public String getTooltipText()
    {
        WebElement element = driver.findElement(By.xpath(".//*[@id='selectedContent1']/div/ul"));
        Actions toolAct = new Actions(driver);
        toolAct.moveToElement(element).build().perform();
        WebElement toolTipElement = driver.findElement(By.xpath("//div[@class='ui-tooltip-content']"));
        String toolTipText = toolTipElement.getText();
        return toolTipText;
    }

    @Step("select job number")
    public void selectJobNumberWhenMulArchive(String jobNum)
    {

        Select sl1 = new Select(mapJobNumber);
        String text = driver.findElement(By.xpath("//option[contains(text(),'" + jobNum + "')]")).getText();
        sl1.selectByVisibleText(text);
    }

    public boolean isTableDisplayed(String name)
    {
        try
        {
            String procName = driver.findElement(By.xpath(".//*[contains(text(),'" + name + "')]")).getText();
            System.out.println(procName);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }

    }

    public String getErrorMessage1()
    {
        return driver.findElement(By.xpath(".//*[@id='textMsgdataTypeValidation']/span")).getText();
    }

}

package com.equifax.cms.fusion.test.EXTPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ImportExternalFilePage
{
    WebDriver driver;
    public Select selType;
    public ImportExternalFilePage(WebDriver driver){

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }
    
    @FindBy(id = "filePath")
    public WebElement filePathLoc_Field;
    
    @FindBy(id = "fileName")
    public WebElement fileName_Field;
    
    @FindBy(id = "format")
    WebElement format_DD;
    
    @FindBy(id = "keyPosition")
    public WebElement keyPosi_Field;
    
    @FindBy(id = "keyLength")
    public WebElement keyLength_Field;
    
    @FindBy(id = "recLength")
    public WebElement recLength_Field;
    
    @FindBy(id = "projectNo")
    public WebElement projNo_Field;
    
    @FindBy(id = "e2")
    WebElement custName_DD;
    
    @FindBy(id = "customTag")
    public WebElement custTag_Field;
    
    
    @Step("Provided File Location as : {0}")
    public void inputNetAppFileLoc(String fileLoc)
    {
        if(!"NA".equalsIgnoreCase(fileLoc))
        {
        filePathLoc_Field.clear();
        filePathLoc_Field.sendKeys(fileLoc);
        }
    }
    
    @Step("Provided File Name as : {0}")
    public void inputFileName(String fileName)
    {
        if(!"NA".equalsIgnoreCase(fileName))
        {
        fileName_Field.clear();
        fileName_Field.sendKeys(fileName);
        }
    }
    
    @Step("Selected File Format as : {0}")
    public void selectFormat(String format)
    {
        if(!"NA".equalsIgnoreCase(format))
        {
        Select select = new Select(format_DD);
        select.selectByVisibleText(format);
        }
    }
    
    @Step("Provided Key Position as : {0}")
    public void inputKeyPosition(String keyPosition)
    {
        if(!"NA".equalsIgnoreCase(keyPosition))
        {
        keyPosi_Field.clear();
        keyPosi_Field.sendKeys(keyPosition);
        }
    }
    
    @Step("Provided Key Length as : {0}")
    public void inputKeyLength(String keyLength)
    {
        if(!"NA".equalsIgnoreCase(keyLength))
        {
        keyLength_Field.clear();
        keyLength_Field.sendKeys(keyLength);
        }
    }
    
    @Step("Provided Record Lenght as : {0}")
    public void inputRecLength(String recLength)
    {
        if(!"NA".equalsIgnoreCase(recLength))
        {
        recLength_Field.clear();
        recLength_Field.sendKeys(recLength);
        }
    }
    
    @Step("Provided Project No. as : {0}")
    public void inputProjectNo(String projNo)
    {
        if(!"NA".equalsIgnoreCase(projNo))
        {
        projNo_Field.clear();
        projNo_Field.sendKeys(projNo);
        }
    }
    
    @Step("Selected Customer Name as : {0}")
    public void selectCustomerName(String custName)
    {
        if(!"NA".equalsIgnoreCase(custName))
        {
        Select select = new Select(custName_DD);
        select.selectByVisibleText(custName);
        }
    }
    
    @Step("Provided Customer Tag as : {0}")
    public void inputCustomTag(String custTag)
    {
        if(!"NA".equalsIgnoreCase(custTag))
        {
        custTag_Field.clear();
        custTag_Field.sendKeys(custTag);
        }
    }
    
    @Step("Clicked Back Button")
    public void clickBackButton() 
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[1]")).click();
    }
    
    @Step("Clicked Save Button")
    public void clickSaveButton() 
    {
        driver.findElement(By.xpath("(.//*[@class='orange-btn'])[2]")).click();
    }
    
    public String getErrorMessage() 
    {
        return driver.findElement(By.xpath(".//*[@class='errMsg']")).getText();
    }
    
    public String getFileNotFoundErrMsg() 
    {
        return driver.findElement(By.xpath(".//*[@class='errMsgSrcMatch']")).getText();
    }

    
    
    

}

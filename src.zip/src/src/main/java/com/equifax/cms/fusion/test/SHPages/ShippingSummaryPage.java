package com.equifax.cms.fusion.test.SHPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ShippingSummaryPage {
	WebDriver driver;
	
	public ShippingSummaryPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50,TimeUnit.SECONDS);
	}
    @FindBy(xpath = "//input[@name='submitButton']")
	WebElement Submit_Btn;
	
    @FindBy(id = "btnOk")
    WebElement Warning_Alert;
    
    @Step("Clicked on Alert message")
    public void clickOnAlert(){
    	Warning_Alert.click();
    }
	
	@Step("Submit the Process")
	public void clickSubmitButton() {
		Submit_Btn.click();
	}

}

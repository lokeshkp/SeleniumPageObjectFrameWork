package com.equifax.cms.fusion.test.RLSPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class DataProcessingTabRS
{
    WebDriver driver;
    public Select selType;

    public DataProcessingTabRS(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//*[@id='dataprocessing']/a")
    WebElement DataProcessingHomeTab;

    @FindBy(linkText = "Rolling Suppression")
    WebElement RollingSupp_Btn;

    @Step("Clicked Data Processing Tab")
    public void clickDataProcessingTab()
    {
        DataProcessingHomeTab.click();
    }

    @Step("Clicked Rolling Suppression button")
    public void clickRollingSuppBtn()
    {
        RollingSupp_Btn.click();
    }

    @Step("Fetched Process Status")
    public String getProcessStatus()
    {
        String status = driver.findElement(By.xpath("//table[@id='dnsTable']/tbody/tr[1]/td[3]")).getText();
        return status;
    }

    @Step("Edit Ready Process")
    public void viewProcessSummaryForDataProcessingProcesses(String inputProcessAssignedId)
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + inputProcessAssignedId + "')]/preceding-sibling::td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Summary")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Summary")).click();
    }

    @Step("Clicked Duplicate for Rolling Suppression Process")
    public void selectDuplicateRS()
    {
        driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'Duplicate')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'Duplicate')]")));
        element.click();
       // driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.id("dup-row")).click();
        try
        {
            Thread.sleep(3000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    @Step("Clicked Summary for Rolling Suppression Process")
    public void selectSummaryRS()
    {
        driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(3000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        WebElement element = (new WebDriverWait(driver, 10)).until(ExpectedConditions.elementToBeClickable(By.xpath("//li[contains(text(),'View Summary')]")));
        element.click();
        //driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();

    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }
}

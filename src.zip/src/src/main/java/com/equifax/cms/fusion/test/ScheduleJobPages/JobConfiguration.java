package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class JobConfiguration
{

    WebDriver driver;

    public JobConfiguration(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//*[@id='inputDataTable']/tbody/tr[1]/td[1]/img[1]")
    WebElement click_EditOptions;

    @FindBy(xpath = ".//*[@value='Save']")
    WebElement save_Btn;

    @FindBy(xpath = "//div[@id='sb-player']/div/form/div[2]/input")
    WebElement saveFileToSpecifiedPath;

    @Step("Check For Parameter DELAY")
    public void checkParameterOnTop()
    {
        driver.findElement(By.xpath("//tbody[@id='listOfSelectedParamaters']/tr[1]/td[1]/span[1]/input[1]")).click();

    }

    @Step("Check For Parameter DELAY")
    public void checkSecondParameter()
    {
        driver.findElement(By.xpath("//tbody[@id='listOfSelectedParamaters']/tr[2]/td[1]/span[1]/input[1]")).click();

    }

    @Step("Check For Parameter with DM")
    public void checkParameterHavingDM()
    {
        driver.findElement(By.xpath("//span[contains(text(),'DM')]/preceding::td[1]/img")).click();
    }

    @Step("Set Parameter Name")
    public void setFirstParamName(String paramName)
    {
        driver.findElement(By.xpath("//tbody[@id='listOfSelectedParamaters']/tr[1]/td[1]/span[1]/input[1]//following::td[2]/input")).sendKeys(
                paramName);
    }

    @Step("Set Second Parameter Name")
    public void setSecondParamName(String paramName)
    {
        driver.findElement(By.xpath("//tbody[@id='listOfSelectedParamaters']/tr[2]/td[1]/span[1]/input[1]//following::td[2]/input")).sendKeys(
                paramName);
    }

    @Step("Set Parameter Value")
    public void setFirstParamVal(String paramVal)
    {
        driver.findElement(By.xpath("//tbody[@id='listOfSelectedParamaters']/tr[1]/td[1]/span[1]/input[1]//following::td[3]/input")).sendKeys(
                paramVal);
    }

    @Step("Check For Parameter HOST")
    public void checkParameterHOST()
    {
        driver.findElement(By.xpath("//*[contains(text(),'HOST')]/preceding::span[1]/input[1]")).click();
    }

    @Step("Click Edit parameter Details")
    public void clickConfigureDetailsSave()
    {
        save_Btn.click();
    }

    @Step("Click Edit parameter Details")
    public void clickEditParameters()
    {
        click_EditOptions.click();
    }

    @Step("Check For Parameter SCHID")
    public void checkParameterSCHID()
    {
        driver.findElement(By.xpath("//*[contains(text(),'SCHID')]/preceding::span[1]/input[1]")).click();
    }

    @Step("Click Save Parameter Details")
    public void clickSaveParameterDetails()
    {
        driver.findElement(By.xpath("//a[contains(text(),'Save')]")).click();
    }

    @Step("Click Cancel Parameter Details")
    public void clickCancelOnParameterDetails()
    {
        driver.findElement(By.xpath("//div[@id='columnsModal']/div[4]/table/tbody/tr[1]/td[]/a[3]")).click();
    }

    @Step("Click generate Parameter Details")
    public void generateParameterDetails()
    {
        driver.findElement(By.xpath("//a[@id='generate-param']")).click();
    }

    @Step("Parameter template")
    public boolean isParameterTemplateDisplayed()
    {
        return driver.findElement(By.xpath("//span[contains(text(),'Parameter Template')]")).isDisplayed();
    }

    @Step("Parameter template Details")
    public String getParameterTemplateDetails()
    {
        return driver.findElement(By.xpath("//div[@id='xmlArea']/pre")).getText();
    }

    @Step("Click Save to File")
    public void clickSaveToFile()
    {
        driver.findElement(By.xpath("//a[contains(text(),'Save to File')]")).click();
    }

    @Step("Click Save File In specified Path")
    public void clickSaveOnPopUp()
    {
        saveFileToSpecifiedPath.click();
    }

    @Step("Get Unix File Path")
    public String getFileSavingPath()
    {
        String text = driver.findElement(By.xpath("//div[@id='sb-player']/div[1]/form/div[1]/br")).getText();
        return text;
    }

    public String getErrorMsg()
    {
        String errMsg = driver.findElement(By.xpath("//div[@id='contentArea']//span[@id='textMsg'][1]")).getText();
        return errMsg;
    }
}

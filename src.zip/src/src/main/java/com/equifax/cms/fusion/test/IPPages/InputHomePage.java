package com.equifax.cms.fusion.test.IPPages;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class InputHomePage
{
    WebDriver driver;

    public InputHomePage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(linkText = "Import New File")
    WebElement ImportNewFileButton;

    @FindBy(linkText = "Input Zip Codes")
    WebElement InputZipCodesBtn;

    @Step("Click Import New File Process Button")
    public void ClickImportNewFile()
    {
        ImportNewFileButton.click();
    }

    @Step("Clicked Input Zip Code Process Button")
    public void clickInputZipCodesBtn()
    {
        InputZipCodesBtn.click();
    }

    @Step("Get Status of Import New File Process")
    public String getStatusIP_1()
    {
        String status = driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div[1]/div[4]/div")).getText();
        return status;
    }

    @Step("Duplicate Input Process")
    public void duplicateProcess()
    {
        driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[1]/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("Duplicate")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("popupTitle")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(1000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        driver.findElement(By.xpath("//div[@id='sb-wrapper-inner']/div[1]/div[1]/div[1]/div[2]/a[1]")).click();
        try
        {
            Thread.sleep(1000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

}

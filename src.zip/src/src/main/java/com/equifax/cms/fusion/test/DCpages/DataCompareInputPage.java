package com.equifax.cms.fusion.test.DCpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DataCompareInputPage {
	
	WebDriver driver;
	public Select selType;
	
	public DataCompareInputPage(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
	}
	
	@FindBy(id = "dcProcessName")
	public WebElement ProcessName_Fld;
	
	@FindBy(id = "fromProcessId")
	WebElement LeftInputProc_Ddwn;
	
	@FindBy(id = "itemTableId")
	WebElement LeftInputData_Ddwn;
	
	@FindBy(id = "projectNumberMatch")
	public WebElement ProjNum_Fld;
	
	@FindBy(id = "searchButton")
	WebElement Search_Btn;
	
	@FindBy(id = "fromProcessIdmatch")
	WebElement RightInputProc_Ddwn;
	
	@FindBy(id = "itemTableIdmatch")
	WebElement RightInputData_Ddwn;
	
	@FindBy(xpath = "(//input[@name='submitButton'])[2]")
	WebElement Continue_Btn;
	
	@Step("Provided Process Name field = \"{0}\"")
	public void inputProcessName(String procName){
		ProcessName_Fld.sendKeys(procName);
	}
	
	@Step("Select the Left Input Process = \"{0}\"")
	public void selectLeftInputProc(String leftProc){
		selType = new Select(LeftInputProc_Ddwn);
		selType.selectByVisibleText(leftProc);
	}
	
	@Step("Select the Left Input Data = \"{0}\"")
	public void selectLeftInputData(String leftData){
		selType = new Select(LeftInputData_Ddwn);
		selType.selectByVisibleText(leftData);
	}
	
	@Step("Provided the Project Number = \"{0}\"")
	public void inputProjectNumAndClickSearch(String projNum){
		if(!"NA".equalsIgnoreCase(projNum)) {
		ProjNum_Fld.clear();
		ProjNum_Fld.sendKeys(projNum);
		clickSearchBtn();}
	}
	
	@Step("Click on Search button")
	public void clickSearchBtn(){
		Search_Btn.click();
	}
	
	@Step("Select the Right Input Process = \"{0}\"")
	public void selectRightInputProc(String rightProc){
		selType = new Select(RightInputProc_Ddwn);
		selType.selectByVisibleText(rightProc);
	}
	
	@Step("Select the Right Input Data = \"{0}\"")
	public void selectRightInputData(String rightData){
		selType = new Select(RightInputData_Ddwn);
		selType.selectByVisibleText(rightData);
	}
	
	@Step("Click on Continue button")
	public void clickContinueBtn(){
		Continue_Btn.click();
	}
	
	public void clickSaveButton() {
		driver.findElement(By.xpath("(.//*[@class='orange-btn'])[2]")).click();
	}
	
	public String getErrorMessage() {
		return driver.findElement(By.xpath(".//*[@class='errMsg']")).getText();
	}
	
	public String getTableSelected1() {
	    return driver.findElement(By.xpath("(.//*[@selected='selected'])[2]")).getAttribute("value");
	}
	
	public String getTableSelected2() {
        return driver.findElement(By.xpath("(.//*[@selected='selected'])[4]")).getAttribute("value");
    }
}

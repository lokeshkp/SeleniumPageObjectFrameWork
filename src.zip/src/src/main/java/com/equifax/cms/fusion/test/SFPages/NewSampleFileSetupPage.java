package com.equifax.cms.fusion.test.SFPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.NoSuchElementException;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class NewSampleFileSetupPage
{
    WebDriver driver;
    public Select selType;

    public NewSampleFileSetupPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "acceptRecordTypes")
    public WebElement acceptLevels_Field;

    @FindBy(id = "rejectRecordTypes")
    public WebElement rejectCodes_Field;

    @FindBy(id = "name")
    WebElement ProcessName_Fld;

    @FindBy(id = "fromProcessId")
    WebElement Process_Fld;

    @FindBy(id = "itemTableId")
    WebElement Data_Fld;

    @FindBy(id = "useDmSampleFile")
    public WebElement UseSFcreatedDM_ChckBox;

    @FindBy(id = "allRecords")
    WebElement AllRecords_SS_RB;

    @FindBy(id = "auditCriteriaLevel")
    WebElement AuditCriteria_SS_RB;

    @FindBy(id = "byAcceptReject")
    WebElement ByAccRej_SS_RB;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement Save_Btn;

    @FindBy(xpath = "//input[@onclick='changeForm()']")
    WebElement Continue_Btn;

    @FindBy(id = "noOfAcceptRecs")
    public WebElement noOfAccept_Recs;

    @FindBy(id = "noOfRejectRecs")
    public WebElement noOfReject_Recs;

    @FindBy(id = "sendToAudit")
    WebElement SendToAudit_CB;

    @FindBy(id = "sendToPdf")
    WebElement SendToPDF_CB;

    // Added to select the sample type
    @FindBy(id = "sampleType1")
    WebElement credit_File_RadioBtn;

    @FindBy(id = "sampleType2")
    WebElement table_Ditto_RadioBtn;

    @Step("Select The Sample Type")
    public void selectSampleType(String sampleType)
    {
        if (sampleType.equalsIgnoreCase("tableDitto"))
        {
            table_Ditto_RadioBtn.click();
        } else if (sampleType.equalsIgnoreCase("creditFiles"))
        {
            if (!credit_File_RadioBtn.isSelected())
            {
                credit_File_RadioBtn.click();
            }
        }
    }

    public void selectOutputLocation(String outputLocation)
    {
        if ("Audit".equalsIgnoreCase(outputLocation))
        {
            if (!SendToAudit_CB.isSelected())
            {
                SendToAudit_CB.click();
            }
            if (SendToPDF_CB.isSelected())
            {
                SendToPDF_CB.click();
            }

        } else if ("PDF File".equalsIgnoreCase(outputLocation))
        {
            if (SendToAudit_CB.isSelected())
            {
                SendToAudit_CB.click();
            }
            if (!SendToPDF_CB.isSelected())
            {
                SendToPDF_CB.click();
            }

        } else if ("Audit-PDF".equalsIgnoreCase(outputLocation))
        {
            if (!SendToAudit_CB.isSelected())
            {
                SendToAudit_CB.click();
            }
            if (!SendToPDF_CB.isSelected())
            {
                SendToPDF_CB.click();
            }

        }
    }

    public void selectSampleSet(String selectSampleSet)
    {
        if (!"NA".equalsIgnoreCase(selectSampleSet))
        {
            if ("All-Records".equalsIgnoreCase(selectSampleSet))
            {
                AllRecords_SS_RB.click();
            } else if ("Accept-Reject".equalsIgnoreCase(selectSampleSet))
            {
                ByAccRej_SS_RB.click();
            } else if ("Audit-Criteria".equalsIgnoreCase(selectSampleSet))
            {
                AuditCriteria_SS_RB.click();
            }
        }
    }

    @Step("Click on Audit Tab = \"{0}\"")
    public void inputProcessName(String procName)
    {
        if (!"NA".equalsIgnoreCase(procName))
        {
            ProcessName_Fld.sendKeys(procName);
        }
    }

    @Step("Click on Audit Tab = \"{0}\"")
    public void clearInputProcessName()
    {

        ProcessName_Fld.clear();

    }

    @Step("Select Process Field = \"{0}\"")
    public void selectProcess(String process)
    {
        if (!"NA".equalsIgnoreCase(process))
        {
            selType = new Select(Process_Fld);
            selType.selectByVisibleText(process);
        }
    }

    @Step("Select Data Field = \"{0}\"")
    public void selectData(String data)
    {
        if (!"NA".equalsIgnoreCase(data))
        {
            selType = new Select(Data_Fld);
            selType.selectByVisibleText(data);
        }
    }

    @Step("Selected the Use Sample Files Created in Data Menu")
    public void checkUseSFcreatedDM()
    {
        UseSFcreatedDM_ChckBox.click();
    }

    @Step("Selected the Use Sample Files Created in Data Menu")
    public void UseSampFilesCreatedinDM(String useDmSamples) throws InterruptedException
    {
        Thread.sleep(3000);
        if ("Y".equalsIgnoreCase(useDmSamples))
        {
            UseSFcreatedDM_ChckBox.click();
        } else if ("N".equalsIgnoreCase(useDmSamples))
        {

        }

    }

    /*
     * @Step("Get the Process Id for the process") public String getProcessID() { String procId = Ele_ProcId.getAttribute("value"); return procId; }
     */

    @Step("Click All Records Check Box")
    public void clickAllRecords()
    {
        AllRecords_SS_RB.click();
    }

    @Step("Clicked Audit Criteria Radio Button")
    public void clickAuditCriteria()
    {
        AuditCriteria_SS_RB.click();
    }

    @FindBy(id = "useDmSampleFile")
    WebElement use_DmSamples;

    @Step("Use Sample Files Created in Data Menu: No JET workItem")
    public String validateArtifactsWhenUsedSamplesFromDM()
    {
        String s = "";
        try
        {
            WebElement ele = driver.findElement(By.xpath("//td[contains(text(),'JET')]"));

        } catch (NoSuchElementException e)
        {
            return "NoSuchElementException";
        }

        return s;

        // return getStyle;
    }

    @Step("Click save button")
    public void clickSave()
    {

        driver.findElement(By.xpath(".//*[@class='buttons']/input[1]")).click();
    }

    @Step("Use Sample Files Created in Data Menu Checkbox Style")
    public String validateDivStyleOfUseSamplefromDM()
    {
        String viewStyle = driver.findElement(By.xpath("//div[@class='isDmWithSampleFile']")).getAttribute("style");
        return viewStyle;

    }

    @Step("Provide Records per Accept Level & Records per Reject Code values = \"{0}\"")
    public void inputAccRegRecs(String records)
    {
        if ("NA".equalsIgnoreCase(records))
        {
            System.out.println("Default values are already present in the fields...");
        } else
        {
            String delimiter = ",";
            int i = 1;
            StringTokenizer fieldText = new StringTokenizer(records, delimiter);
            while (fieldText.hasMoreTokens())
            {
                acceptLevels_Field.clear();
                acceptLevels_Field.sendKeys(fieldText.nextToken());
                // driver.findElement(By.xpath("//html/body/div[1]/div[3]/div[3]/div[2]/form/div[3]/div[10]/fieldset[" + i + "]/input[1]")).clear();
                // driver.findElement(By.xpath("//html/body/div[1]/div[3]/div[3]/div[2]/form/div[3]/div[10]/fieldset[" + i + "]/input[1]")).sendKeys(
                // fieldText.nextToken());
                i++;
            }
        }
    }

    @Step("Provide Records per Accept Level & Records per Reject Code values = \"{0}\"")
    public void inputRecsPerAcceptLevelandRejectLevel(String records)
    {
        if ("NA".equalsIgnoreCase(records))
        {
            System.out.println("Default values are already present in the fields...");
        } else
        {
            String[] arrRecords = records.split(",");
            noOfAccept_Recs.clear();
            noOfAccept_Recs.sendKeys(arrRecords[0]);
            noOfReject_Recs.clear();
            noOfReject_Recs.sendKeys(arrRecords[1]);
        }
    }

    @Step("Provide Records per Accept Level & Records per Reject Code values = \"{0}\"")
    public void inputAcceptLevelsandRejectCodesToCreate(String records)
    {
        if ("NA".equalsIgnoreCase(records))
        {
            System.out.println("Default values are already present in the fields...");
        } else
        {
            String[] arrRecords = records.split(";");
            acceptLevels_Field.clear();
            acceptLevels_Field.sendKeys(arrRecords[0]);
            rejectCodes_Field.clear();
            rejectCodes_Field.sendKeys(arrRecords[1]);
        }
    }

    @Step("Provide Accepts Levels to create & Reject Codes to create = \"{0}\"")
    public void inputAccRejCreate(String levelsCodes)
    {
        String delimiter = ";";
        int i = 1;
        StringTokenizer fieldText = new StringTokenizer(levelsCodes, delimiter);
        if (!levelsCodes.equalsIgnoreCase("NA"))
        {
            while (fieldText.hasMoreTokens())
            {
                rejectCodes_Field.sendKeys(fieldText.nextToken());
                // driver.findElement(By.xpath("//html/body/div[1]/div[3]/div[3]/div[2]/form/div[3]/div[10]/fieldset[" + i + "]/input[2]")).sendKeys(
                // fieldText.nextToken());
                i++;
            }
        } else
        {
            System.out.println("It continues to the next step without Level Codes...");
        }
    }

    @Step("Provide Records per Accept Level & Records per Reject Code values = \"{0}\"")
    public void inputAccRegRecsnew(String records) throws InterruptedException
    {
        if ("All".equalsIgnoreCase(records))
        {
            AllRecords_SS_RB.click();
        } else if ("NA".equalsIgnoreCase(records))
        {
            System.out.println("Default values are already present in the fields...");
        } else
        {
            clickByAcceptRejectCode();

            String[] split = records.split(",");
            noOfAccept_Recs.clear();
            noOfAccept_Recs.sendKeys(split[0]);
            noOfReject_Recs.clear();
            noOfReject_Recs.sendKeys(split[1]);
            /*
             * String delimiter = ","; int i = 1; StringTokenizer fieldText = new StringTokenizer(records, delimiter); while
             * (fieldText.hasMoreTokens()) { String str = fieldText.tokenNumber(
             * driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div[2]/form/div[3]/div[6]/fieldset[" + i + "]/input[1]")).clear();
             * driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div[2]/form/div[3]/div[6]/fieldset[" + i + "]/input[1]")).sendKeys(
             * fieldText.nextToken()); i++; }
             */
        }
    }

    @Step("Click continue button")
    public void clickContinueBtn() throws InterruptedException
    {
        Thread.sleep(3000);
        // Continue_Btn.click();

        WebElement ele = driver.findElement(By.xpath("//div[@class='buttons']/input[2]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", ele);
    }

    @Step("Check use samples from DM")
    public void checkUseDmSamples()
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", use_DmSamples);
        // use_DmSamples.click();
    }

    @Step("Check use samples from DM")
    public boolean verifyStyleForAllRecDiv()
    {
        WebElement ele = driver.findElement(By.xpath(".//*[@id='ppCodeDiv']"));
        boolean display = ele.isDisplayed();
        return display;
    }

    public boolean checkBoxStatus()
    {
        WebElement ele = driver.findElement(By.xpath(".//*[@id='useDmSampleFile']")); // boolean status = ele.;
        boolean status = ele.isSelected();
        return status;
    }

    @Step("check by Accept or Reject Code")
    public void clickByAcceptRejectCode() throws InterruptedException
    {

        Thread.sleep(10000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", ByAccRej_SS_RB);
        // ByAccRej_SS_RB.click();
    }

    public boolean validateMoveStmntTables(String table)
    {
        WebElement ele = driver.findElement(By.xpath(".//*[@id='DataTables_Table_1']/tbody/tr/td/span[contains(text(),'" + table + "')]"));
        boolean display = ele.isDisplayed();
        return display;
    }

    public String getJobId()
    {
        return driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText().trim();
    }

    public String getAcceptRecsError()
    {
        return driver.findElement(By.xpath(".//*[@for='noOfAcceptRecs']")).getText().trim();
    }

    public String getRejectRecsError()
    {
        return driver.findElement(By.xpath(".//*[@for='noOfRejectRecs']")).getText().trim();
    }

    public String getAccRejectRecsError()
    {
        return driver.findElement(By.id("textMsg")).getText().trim();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.id("textMsg")).getText().trim();
    }

    public boolean isProcessSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            String a = driver.findElement(By.xpath("(.//*[@selected='selected'])[1]")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            System.out.println(a);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public boolean isDataSelected()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
            String a = driver.findElement(By.xpath("(.//*[@selected='selected'])[2]")).getText();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            System.out.println(a);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public String getJobNo()
    {
        return driver.findElement(By.id("jobId")).getText();
    }

    public boolean isAllRecordsDisplayed() throws InterruptedException
    {

        Thread.sleep(10000);
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        String a = driver.findElement(By.id("ppCodeDiv")).getAttribute("style");
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        boolean flag = false;
        if ("display: block;".equalsIgnoreCase(a))
        {
            flag = true;
        } else if ("display: none;".equalsIgnoreCase(a))
        {
            flag = false;
        }
        return flag;
    }

    public String getTheTitle()
    {
        String title = driver.findElement(By.xpath("//h3[@class='fusion-h3Title']")).getText();
        return title;
    }

    // h3[@class='fusion-h3Title']

    @Step("Fetch The Count Of Record Written To File")
    public Long getTheCountOfRecordsWrittenToFile()
    {
        String record = driver.findElement(By.xpath("//div[starts-with(text(),'Records Written')]//parent::div//div[2]")).getText()
                .replaceAll(",", "").trim();
        return Long.valueOf(record);
    }

    public boolean isRecordCountWithinLimit(Long record)
    {
        boolean isRecordCountWithinLimit = false;
        if (record == 50 || record < 50)
        {
            isRecordCountWithinLimit = true;
        }
        return isRecordCountWithinLimit;
    }

    public String fetchTheFilePath()
    {

        String str = driver.findElement(By.xpath("//div[starts-with(text(),'Records Written')]")).getText();
        String[] splited = str.split("\\s+");
        String path = splited[3];
        System.out.println("path--->" + path);
        return path.trim();
    }

    public boolean isRecordsWrittenToPresent()
    {
        return driver.findElement(By.xpath("//div[starts-with(text(),'Records Written To')]")).isDisplayed();

    }

    public boolean isFileContainData(String path)
    {
        File f = null;

        try
        {
            f = new File(path);
            if (f.exists() && !f.isDirectory())
            {
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {
                    String sCurrentLine;
                    int counter = 0;
                    while ((sCurrentLine = br.readLine()) != null && !(sCurrentLine = br.readLine()).trim().isEmpty())
                    {

                        return true;

                    }
                } catch (IOException e)
                {
                    e.printStackTrace();
                }

            } else
            {

                System.out.println("file not found !!!!");

            }
        }

        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return false;

    }

    public String fetchTheItemNoForSampleGPExportWorkItem(String procStatId, String processName)
    {
        driver.findElement(By.xpath("//span[starts-with(text(),'" + procStatId + "')]//preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[starts-with(text(),'" + processName + "')]//preceding::span[1]")).click();
        String itemNo = driver.findElement(By.xpath("//span[starts-with(text(),'SAMPLE_GPEXPORT')]//parent::td//following::td[1]")).getText();

        return itemNo;
    }

    public List<String> fetchTheDataDisplayedOnStatsForSampleGPExportTableDittoSampleType()
    {
        List<String> statsHeaderData = new ArrayList<String>();
        driver.findElement(By.xpath("//a[starts-with(text(),'SAMPLE_DATA_FILE')]")).click();

        int i = 0;
        while (i < 2)
        {
            List<WebElement> elements = driver.findElements(By.xpath("//div[@id='row" + i + "csvContent']//div/div"));
            for (WebElement ele : elements)
            {
                String data = ele.getText();
                if (!data.equalsIgnoreCase(""))
                {
                    statsHeaderData.add(data);
                }
            }
            i++;
        }

        return statsHeaderData;
    }

    public boolean isDataDisplayedInStatsOnOpeningTheLink()
    {
        driver.findElement(By.xpath("//a[starts-with(text(),'SAMPLE_DATA_FILE')]")).click();
        return driver.findElement(By.xpath("//div[@id='popupContent']//div[@id='csvContent']//following::div[@id='contentcsvContent']"))
                .isDisplayed();
    }

    public String fetchTheTableName()
    {
        String[] tableArr = driver.findElement(By.xpath("//div[starts-with(text(),'I')]")).getText().split(":");
        return tableArr[0].trim();
    }

    public boolean isFileContainDroppedRecords(String path, List<String> droppedRecordList)
    {
        File f = null;
        boolean isDroppedRecordPresent = false;
        try
        {
            f = new File(path);
            if (f.exists() && !f.isDirectory())
            {
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {
                    String sCurrentLine;
                    int counter = 0;
                    while ((sCurrentLine = br.readLine()) != null)
                    {
                        String recordArr[] = sCurrentLine.split("\\|");
                        if (droppedRecordList.contains(recordArr[0]))
                        {
                            isDroppedRecordPresent = true;
                        }

                    }
                } catch (IOException e)
                {
                    e.printStackTrace();
                }

            } else
            {

                System.out.println("file not found !!!!");

            }
        }

        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return isDroppedRecordPresent;

    }

    public long fetchTheInputTableRecordCountFromStats() throws NumberFormatException, ParseException
    {

        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String sourceTableCount = driver.findElement(By.xpath("//div[starts-with(text(),'I')]/following-sibling::div[1]")).getText()
                .replaceAll(",", "").replaceAll("\\s+", "");
        return Long.valueOf(numberFormat.parse(sourceTableCount).toString());
    }

}

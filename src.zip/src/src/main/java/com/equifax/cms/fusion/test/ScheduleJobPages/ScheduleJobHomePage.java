package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class ScheduleJobHomePage
{
    @FindBy(linkText = "Schedule Job")
    WebElement scheduleJob_tab;

    @Step("Click on Schedule Job Tab")
    public void clickScheduleJobTab()
    {
        scheduleJob_tab.click();
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

}

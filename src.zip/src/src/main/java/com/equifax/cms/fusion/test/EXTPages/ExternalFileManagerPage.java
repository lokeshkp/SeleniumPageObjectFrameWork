package com.equifax.cms.fusion.test.EXTPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ExternalFileManagerPage
{
    WebDriver driver;
    public Select selType;

    public ExternalFileManagerPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[@id='contentArea']/div[2]/a")
    WebElement ImportExtFile_Btn;

    public void clickImportExternalFile()
    {
        ImportExtFile_Btn.click();
        
    }

    public void clickExternalFileLink(String name)
    {
        driver.findElement(By.linkText(name)).click();
    }

    public String getEFMHeader()
    {
        return driver.findElement(By.xpath(".//*[@id='contentArea']/div[2]/h3")).getText();
    }

    public boolean isLinkTextPresent(String text)
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            System.out.println(driver.findElement(By.linkText(text)).getText());
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }
    
    public void clickRemoveButton(String fileName) 
    {
        driver.findElement(By.xpath(".//*[contains(text(),'"+fileName+"')]/following::a[1]")).click();
    }
    
    public String getPopupBtn_1() {
        return driver.findElement(By.xpath("(.//*[@class='buttons']/a[1])[2]")).getText();
    }
    
    public String getPopupBtn_2() {
        return driver.findElement(By.xpath("(.//*[@class='buttons']/a[2])[2]")).getText();
    }
    
    public void clickYRemovePopUp() {
        driver.findElement(By.xpath("(.//*[@class='buttons']/a[1])[2]")).click();
    }
    
    public void clickNRemovePopUp() throws InterruptedException {
        driver.findElement(By.xpath("(.//*[@class='buttons']/a[2])[2]")).click();
        Thread.sleep(2000);
    }

}

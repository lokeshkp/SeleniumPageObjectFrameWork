package com.equifax.cms.fusion.test.IZpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ImportNewFilePage {
		WebDriver driver;
		private Select selType;
	public ImportNewFilePage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "processName")
	WebElement Ele_ProcessName;
	
	@FindBy(id = "fileTypeSelect")
	WebElement FileType_Fld;
	
	@FindBy(id = "filePurpose")
	WebElement FilePurpose_Fld;
	
	@FindBy(id = "zipFilePath")
	WebElement InputZipFile_Fld;
	
	@FindBy(id = "listVirtualArtifacts0.userProvidedName")
	WebElement OutputTableName_Fld;
	
	@FindBy(xpath = "(//input[@name='submitButton'])[2]")
	WebElement ContinueButton;
	
	
	@Step("Provided Process Name Field = \"{0}\"")
	public void processNameField(String procName){
		Ele_ProcessName.sendKeys(procName);
	}
	
	@Step("Select File Type Field : \"{0}\"")
	public void fileTypeFld(String fileType){
		selType = new Select(FileType_Fld);
		selType.selectByVisibleText(fileType);
	}
}

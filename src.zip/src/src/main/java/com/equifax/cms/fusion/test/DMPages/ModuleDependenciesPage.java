package com.equifax.cms.fusion.test.DMPages;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import junit.framework.Assert;
import ru.yandex.qatools.allure.annotations.Step;

public class ModuleDependenciesPage
{

    WebDriver driver;

    public ModuleDependenciesPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = ".//*[@id='P4536DF0_PROJECT#']")
    WebElement PROJECT;

    @FindBy(xpath = ".//*[@id='F043BBL0_PROJECT#']")
    WebElement F043BBL0_PROJECT;

    @FindBy(xpath = "//select[@name='P463A6L0_CHSBANK']")
    WebElement CHSBANK;

    @FindBy(xpath = "//select[@name='P463A6L0_MEM04']")
    WebElement MEM04;

    @FindBy(xpath = "//select[@name='JXH_MULTILEVEL_TRDMEM']")
    WebElement JXH_MultLevel;

    @FindBy(xpath = "//input[@type='submit']")
    WebElement ContinueButton;

    @Step("Provided a Project Value")
    public void inputProjectValue(String proj)
    {
        if (!"NA".equalsIgnoreCase(proj))
        {
            PROJECT.sendKeys(proj);
        }
    }

    @Step("Selected the Module Dependencies = \"{0}\"")
    public void selectModDep(String values)
    {
        if (!"NA".equalsIgnoreCase(values))
        {
            String delim = ",";
            StringTokenizer dep = new StringTokenizer(values, delim);
            int i = 2;
            while (dep.hasMoreTokens())
            {
                String dynPath = ".//*[@id='input-datacheck-form']/div[1]/div[2]/div[" + i + "]/select";
                Select sel = new Select(driver.findElement(By.xpath(dynPath)));
                sel.selectByVisibleText(dep.nextToken());
                i++;
            }
        }
    }

    @Step("Check options for the Module Dependencies = \"{0}\"")
    public void checkOptionsModuleDependencies(String values)
    {
        Select select = new Select(driver.findElement(By.xpath(".//*[@id='input-datacheck-form']/div[1]/div[1]/div[2]/select")));
        boolean found = false;
        String[] valueSplit = values.split(",");
        List<WebElement> allOptions = select.getOptions();
        List<String> allOptionsText = new ArrayList<>();

        int i = 0;
        while (i < allOptions.size())
        {
            allOptionsText.add(allOptions.get(i).getText());
            i++;
        }
        for (i = 0; i < valueSplit.length; i++)
        {
            found = false;
            if (allOptionsText.contains(valueSplit[i]))
            {
                found = true;
            }
            Assert.assertEquals(true, found);
        }
    }

    @Step("Get all options for the Module Dependencies = \"{0}\"")
    public List<String> getOptionsModuleDependencies()
    {
        Select select = new Select(driver.findElement(By.xpath(".//*[@id='input-datacheck-form']/div[1]/div[1]/div[2]/select")));
        List<WebElement> allOptions = select.getOptions();
        List<String> allOptionsText = new ArrayList<>();

        int i = 0;
        while (i < allOptions.size())
        {
            allOptionsText.add(allOptions.get(i).getText());
            i++;
        }

        return allOptionsText;

    }

    @Step("Provided the User Parameters for the AP Module F043BBL0 = \"{0}\"")
    public void inputF043BBL0paraValues(String paraValues)
    {
        String delim = ",";
        StringTokenizer para = new StringTokenizer(paraValues, delim);
        int i = 1;
        while (para.hasMoreTokens())
        {
            String dynPath = ".//*[@id='F043BBL0_DATE_" + i + "']";
            driver.findElement(By.xpath(dynPath)).sendKeys(para.nextToken());
            i++;
        }
    }

    @Step("Provided a F043BBL0_PROJECT value = \"{0}\"")
    public void inputProjectF043BBL0(String proj)
    {
        F043BBL0_PROJECT.sendKeys(proj);
    }

    @Step("Selected the JXH_Multilevel dependent file = \"{0}\"")
    public void selModDepJxh_MultLevel(String depFile)
    {
        Select sel = new Select(JXH_MultLevel);
        sel.selectByVisibleText(depFile);
    }

    @Step("Click Continue Button on Module Dependencies Screen")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    @Step("Check if error is present")
    public String checkIfErrorIsPresent(String apModule)
    {
        String errMsg = driver.findElement(By.xpath(".//*[@class='optionsErrMsg']")).getText();
        return errMsg;
    }

}

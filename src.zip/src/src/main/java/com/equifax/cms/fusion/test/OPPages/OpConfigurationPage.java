package com.equifax.cms.fusion.test.OPPages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.thoughtworks.selenium.webdriven.commands.IsElementPresent;

public class OpConfigurationPage
{

    WebDriver driver;
    CommonMethods commonMethods;

    public OpConfigurationPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(name = "outputSeed")
    public WebElement Ele_PerformSeeding;

    @FindBy(id = "layoutName")
    WebElement Ele_OPLayoutName;

    @FindBy(id = "format1")
    public WebElement Ele_ASCIIFixed;

    @FindBy(id = "format2")
    public WebElement Ele_EBCDICFixed;

    @FindBy(id = "format3")
    WebElement Ele_ASCIIDelimited;

    @FindBy(id = "delimiter")
    public WebElement Ele_Delimiter;

    @FindBy(id = "eol1")
    public WebElement Ele_LineFeed;

    @FindBy(id = "eol2")
    WebElement Ele_CRLF;

    @FindBy(id = "eol3")
    WebElement Ele_None;

    @FindBy(id = "layoutFile")
    public WebElement Ele_CSV_LayoutFile;

    @FindBy(xpath = ".//button[contains(text(),'Preview')]")
    WebElement PreviewButton;

    @FindBy(xpath = ".//input[@value='Load']")
    WebElement LoadButton;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(id = "headerOption1")
    public WebElement AddHeaderRecord_CB;

    @FindBy(id = "reSequenceOption1")
    public WebElement reSequenceReq_CB;

    @FindBy(id = "startingNumber")
    public WebElement startNum_Field;

    @FindBy(xpath = "//div[@class='jqx-icon-add-mdb']")
    WebElement mdbAddButton;
    @FindBy(xpath = "//div[@class='jqx-icon-resequence-fusion']")
    WebElement resequenceButton;

    public static List<String> layoutFields = Arrays.asList("DP_SEQUENCE_NUM", "CID", "HH_KEY", "CNX_KEY", "L90_KEY", "F_NAME", "M_I", "L_NAME",
            "CITY", "STATE");

    public void selectResequenceReq_CB(String res, String reSeqNum)
    {
        if ("Y".equalsIgnoreCase(res))
        {
            driver.findElement(By.id("reSequenceOption1")).click();
            driver.findElement(By.id("startingNumber")).clear();
            driver.findElement(By.id("startingNumber")).sendKeys(reSeqNum);
        } else if ("N".equalsIgnoreCase(res))
        {
            if (driver.findElement(By.id("reSequenceOption1")).isSelected())
            {
                driver.findElement(By.id("reSequenceOption1")).click();
            }
        }
    }

    public void clearResequenceNo()
    {
        driver.findElement(By.id("startingNumber")).clear();
    }

    public String isResequenceCheckBoxSelected()
    {
        String isReseqRequired="N";
        if( reSequenceReq_CB.isSelected()==true)
        {
            isReseqRequired="Y";
        }
        return isReseqRequired;
    }

    public String getFirstErrorMessage()
    {
        //return driver.findElement(By.xpath("(.//*[@class='error'])[1]")).getText();
    	return driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
    }

    public String getReseqError()
    {
        return driver.findElement(
                By.xpath("//h3[contains(text(),'Output Configuration')]/following::div[@class='copyErrMsg errMsgExt'][1]/span[@id='textMsg']"))
                .getText();
    }

    public String getSecondErrorMessage()
    {
        //return driver.findElement(By.xpath("(.//*[@class='error'])[2]/li[1]")).getText();
    	return driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
    }

    public String getThirdErrorMessage()
    {
        //return driver.findElement(By.xpath("(.//*[@class='error'])[2]/b[1]")).getText();
    	return driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
    }

    public String getTheErrorMessage()
    {
        String s= driver.findElement(By.xpath(" //div[@class='copyErrMsg errMsgExt']/span")).getText();
        System.out.println("Test--->>"+s);
        return s;
    }


    @FindBy(xpath = "(.//*[contains(text(),'Available Fields')]//following::div)[1]/ul/li")
    public WebElement availableFields_XPATH;

    @Step("Select Perform Seeding")
    public void selectPerformSeeding()
    {
        Ele_PerformSeeding.click();
    }

    @Step("Deselect Perform Seeding")
    public void deselectPerformSeeding()
    {
        Ele_PerformSeeding.click();
    }

    @Step("Provide Output Layout Name = \"{0}\"")
    public void outputLayoutNameField(String name)
    {
        Ele_OPLayoutName.clear();
        Ele_OPLayoutName.sendKeys(name);
    }

    @Step("Clear Output Layout Name")
    public void clearOpLayoutNameField()
    {
        Ele_OPLayoutName.clear();
    }

    @Step("Select ASCII Fixed")
    public void clickASCIIFixed()
    {
        Ele_ASCIIFixed.click();
    }

    @Step("Select EBCDIC Fixed")
    public void clickEBCDICFixed()
    {
        Ele_EBCDICFixed.click();
    }

    @Step("Select ASCII Delimited")
    public void clickASCIIDelimited()
    {
        Ele_ASCIIDelimited.click();
    }

    @Step("Select Delimter field = \"{0}\"")
    public void selectDelimiterField(String delimiter)
    {
        Select sl = new Select(Ele_Delimiter);
        sl.selectByVisibleText(delimiter);
    }

    @Step("Select Line Feed")
    public void clickLineFeed()
    {
        Ele_LineFeed.click();
    }

    @Step("Select Carriage Return/Line Feed Feed")
    public void clickCRLF()
    {
        Ele_CRLF.click();
    }

    @Step("Select None field")
    public void clickNone()
    {
        Ele_None.click();
    }

    @Step("Provide CSV Layout file = \"{0}\"")
    public void inputLayoutLocAndLoad(String Layout)
    {
        if (!"NA".equalsIgnoreCase(Layout))
        {
            Ele_CSV_LayoutFile.clear();
            Ele_CSV_LayoutFile.sendKeys(Layout);
            clickLoadButton();
        }
    }

    @Step("Fetched The Selected File Format")
    public String fetchTheSelectedFileFormat()
    {
        return driver.findElement(By.xpath("//*[(@checked='checked')]")).getAttribute("value");
    }

    @Step("Click Load button")
    public void clickLoadButton()
    {
        LoadButton.click();
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public void clickBackBtn()
    {
        driver.findElement(By.xpath(".//*[@class='orange-btn slowLink']")).click();
    }

    public void aliasName(String dataTable, String AliasName)
    {
        String dynPath = ".//span[contains(text(),'" + dataTable + "')]/following::input[4]";
        driver.findElement(By.xpath(dynPath)).sendKeys(AliasName);

    }

    public void seeding(String process, String seedingChck, String purpose)
    {
        if (!"Apply Capping".equalsIgnoreCase(purpose))
        {
            if (!process.startsWith("IP"))
            {
                if (!"NA".equalsIgnoreCase(seedingChck))
                {

                    if (seedingChck.equalsIgnoreCase("N"))
                    {
                        if (Ele_PerformSeeding.isSelected())
                        {
                            selectPerformSeeding();

                        } else
                        {
                            System.out.println("Perform seeding is already deselected");
                        }
                    } else
                    {
                        if (Ele_PerformSeeding.isSelected())
                        {
                            System.out.println("Perform seeding is already deselected");
                        } else
                        {
                            selectPerformSeeding();
                        }
                    }
                }
            }
        }
    }

    public void selectFileFormat(String fileFormat)
    {
        if ("ASCII_Fixed".equalsIgnoreCase(fileFormat))
        {
            clickASCIIFixed();

        } else if ("EBCDIC_Fixed".equalsIgnoreCase(fileFormat))
        {
            clickEBCDICFixed();

        } else if ("ASCII_Delimited".equalsIgnoreCase(fileFormat))
        {
            clickASCIIDelimited();
        }
    }

    public void selectCRLFOptions(String option)
    {
        if ("LF".equalsIgnoreCase(option))
        {
            clickLineFeed();

        } else if ("CRLF".equalsIgnoreCase(option))
        {
            clickCRLF();

        } else
        {
            clickNone();

        }
    }

    public String getErrorPresentOnConfigpage()
    {
        String errMsg = driver.findElement(By.xpath(".//*[@class='error']/li")).getText();
        return errMsg;
    }

    public String fetchTheErrorMessage()
    {
        String errMsg = driver.findElement(By.xpath("//div[@class='cmsContent']//div[@class='copyErrMsg errMsgExt']//span")).getText();
        return errMsg;
        //return driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
    }

    public String getDefaultPaddingForCharField()
    {
        return driver.findElement(By.xpath(".//td[2][contains(text(),'HH_KEY')]/following-sibling::td[6]")).getText();
    }

    public String getDefaultPaddingForNumField()
    {
        return driver.findElement(By.xpath(".//td[2][contains(text(),'CNX_KEY')]/following-sibling::td[6]")).getText();
    }

    public String gettMaskStartPos()
    {
        return driver.findElement(By.xpath(".//td[2][contains(text(),'CNX_KEY')]/following-sibling::td[11]")).getText();
    }

    public String gettMaskString()
    {
        return driver.findElement(By.xpath(".//td[2][contains(text(),'CNX_KEY')]/following-sibling::td[13]")).getText();
    }

    public String gettMaskLength()
    {
        return driver.findElement(By.xpath(".//td[2][contains(text(),'CNX_KEY')]/following-sibling::td[12]")).getText();
    }

    public String getLayoutLoadSuccessMessage()
    {
        return driver.findElement(By.xpath("//body/div/div[3]/div[3]//div[2]")).getText();
    }

    public void checkRead(String path)
    {
        try
        {
            String verify, putData;
            File file = new File(path);

            FileWriter fw = new FileWriter(file);
            BufferedWriter bw = new BufferedWriter(fw);
            FileReader fr = new FileReader(file);
            BufferedReader br = new BufferedReader(fr);

            while ((verify = br.readLine()) != null)
            {
                if (verify.contains("CID"))
                {
                    String linesplit[] = verify.split(",");
                    int value = Integer.valueOf(linesplit[6]);
                    value = value + 2;
                    putData = verify.replace(linesplit[6], String.valueOf(value));
                    bw.write(putData);
                }
            }
            br.close();
            bw.close();

        } catch (IOException e)
        {
            e.printStackTrace();
        }
    }

    public void replaceFile(String path)
    {
        String actualFile = null;
        String oldFileName[] = path.split("\\\\");
        for (String s : oldFileName)
        {
            if (s.contains(".csv") || s.contains(".txt") || s.contains(".fixed"))
            {
                actualFile = s;
            }
        }
        String tmpFileName = "tmp_try.dat";

        BufferedReader br = null;
        BufferedWriter bw = null;
        try
        {
            br = new BufferedReader(new FileReader(actualFile));
            bw = new BufferedWriter(new FileWriter(tmpFileName));
            String line;
            while ((line = br.readLine()) != null)
            {
                if (line.contains("1313131"))
                {
                    line = line.replace("1313131", "" + System.currentTimeMillis());
                }
                bw.write(line + "\n");
            }
        } catch (Exception e)
        {
            return;
        } finally
        {
            try
            {
                if (br != null)
                {
                    br.close();
                }
            } catch (IOException e)
            {
                //
            }
            try
            {
                if (bw != null)
                {
                    bw.close();
                }
            } catch (IOException e)
            {
                //
            }
        }
        // Once everything is complete, delete old file..
        File oldFile = new File(actualFile);
        oldFile.delete();

        // And rename tmp file's name to old file name
        File newFile = new File(tmpFileName);
        newFile.renameTo(oldFile);

    }

    public void readFileReplaceCIDLength(String fileName) throws IOException
    {

        File f = new File(fileName);
        List<String> newLines = new ArrayList<>();

        int i = 0;
        for (String line : Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8))
        {
            // String line32 = Files.readAllLines(Paths.get("file.txt").get(32), StandardCharsets.UTF_8);

            if (line.contains("CID"))
            {
                String line2 = FileUtils.readLines(f).get(i);
                String arrayLine2[] = line2.split(",");
                newLines.add(line.replace(arrayLine2[6], String.valueOf(Integer.valueOf(arrayLine2[6]) + 2)));
            } else
            {
                newLines.add(line);
            }

            i++;
        }
        Files.write(Paths.get(fileName), newLines, StandardCharsets.UTF_8);
    }

    @Step("Get Error Message when default decimal for num is provided")
    public boolean getErrorLabelWhenInvalidDefaultVal()
    {
        boolean flag = false;

        List<WebElement> elements = driver.findElements(By.xpath("//div[@style='margin-left: 20px; height: 100px; overflow-y: scroll;']/li"));

        for (int i = 0; i < elements.size(); i++)
        {
            WebElement temp = elements.get(i);
            System.out.println("VAlue --->>" + temp.getText());
            if (temp.getText().contains("Error: Default value ") && temp.getText().contains("is not correct for Data Type NUM."))
            {
                flag = true;
            }
        }

        return flag;
    }

    public boolean isMoveStatementScreen()
    {
        boolean flag = false;
        try
        {
            if (isElementPresent(By.xpath("//h3[contains(text(),'Output Move Statements')]")))
            {
                flag = true;
            }
        } catch (Exception e)
        {
        }
        return flag;
    }

    public void clickFileFormatLink()
    {
        driver.findElement(By.xpath("//*[@id='outputLayoutForm']/div[4]/a[1]/span")).click();
    }

    public void validateCorrectLayoutStructure()
    {
        String alias = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Table Alias')]/following::td[1]"))
                .getText();
        String fieldName = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Field Name')]/following::td[1]"))
                .getText();
        String customField = driver.findElement(
                By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Customer Field Name')]/following::td[1]")).getText();
        String dataType = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Data Type')]/following::td[1]"))
                .getText();
        String dataTypes = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Data Type')]/following::td[2]"))
                .getText();

        String length = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Length')]/following::td[1]")).getText();
        String startPos = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Start Pos')]/following::td[1]"))
                .getText();
        String endPos = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'End Pos')]/following::td[1]")).getText();
        String padding = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Padding')]/following::td[1]"))
                .getText();
        String paddingVal = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Padding')]/following::td[2]"))
                .getText();
        String just = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Justification')]/following::td[1]"))
                .getText();
        String justAlign = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Justification')]/following::td[2]"))
                .getText();
        String formatMask = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Format Mask')]/following::td[1]"))
                .getText();
        String desc = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Description')]/following::td[1]"))
                .getText();
        String defVal = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Default Value')]/following::td[1]"))
                .getText();
        String maskStart = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Mask Start')]/following::td[1]"))
                .getText();
        String maskLength = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Mask Length')]/following::td[1]"))
                .getText();
        String maskString = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Mask String')]/following::td[1]"))
                .getText();
        String testData = driver.findElement(By.xpath("//*[@id='sb-player']/table/tbody/tr/td[contains(text(),'Test Data')]/following::td[1]"))
                .getText();

        commonMethods.verifyString(alias, "Optional");
        commonMethods.verifyString(fieldName, "Required");
        commonMethods.verifyString(customField, "Optional");

        commonMethods.verifyString(dataType, "Required");
        commonMethods.verifyString(dataTypes, "NUM,CHAR,PACKED,PACKED UNSIGNED,HEX,RAW");
        commonMethods.verifyString(length, "Required");
        commonMethods.verifyString(startPos, "Required");
        commonMethods.verifyString(endPos, "Required");
        commonMethods.verifyString(padding, "Optional");
        commonMethods.verifyString(paddingVal, "Blank,Zero,Hex Zero");

        commonMethods.verifyString(just, "Optional");
        commonMethods.verifyString(justAlign, "Left,Right");

        commonMethods.verifyString(formatMask, "Optional");
        commonMethods.verifyString(desc, "Optional");
        commonMethods.verifyString(defVal, "Optional");
        commonMethods.verifyString(maskStart, "Optional");
        commonMethods.verifyString(maskLength, "Optional");

        commonMethods.verifyString(maskString, "Optional");
        commonMethods.verifyString(testData, "Optional");
        commonMethods.verifyString(alias, "Optional");

        commonMethods.verifyString(alias, "Optional");
        commonMethods.verifyString(alias, "Optional");
        commonMethods.verifyString(alias, "Optional");

        commonMethods.verifyString(alias, "Optional");
        commonMethods.verifyString(alias, "Optional");

    }

    public boolean isPredictedFieldPresentWithinLayout(List<String> fieldNames, String path) throws NumberFormatException, IOException
    {
        boolean result = false;
        // File f = new File(path);

        List<String> listItem = new ArrayList<>();
        for (String field : fieldNames)
        {

            for (String line : Files.readAllLines(Paths.get(path), StandardCharsets.UTF_8))
            {
                // String line32 = Files.readAllLines(Paths.get("file.txt").get(32), StandardCharsets.UTF_8);

                if (line.contains(field))
                {
                    listItem.add("true");
                }
            }
        }
        for (String s : listItem)
        {
            if (s.equalsIgnoreCase("true"))
            {
                result = true;
            }
        }
        return result;
    }

    public boolean isPredictedFieldPresentWithinLayout(List<String> fieldNames, List<String> actualLayoutField)
    {
        boolean result = false;
        if (fieldNames.containsAll(actualLayoutField))
        {
            result = true;
        }
        return result;
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    // Works with one alias table selected
    public void selectFields(String layoutTableName, String layoutFields) throws InterruptedException
    {
        List<WebElement> elements = driver.findElements(By.xpath(".//*[@class='jqx-grid-group-cell jqx-draggable']/div/parent::div/parent::div"));
        int i = 0;
        while (i < elements.size())
        {
            String mainStr = elements.get(i).getText();
            String mainId = elements.get(i).getAttribute("id");
            String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
            String[] layoutFieldsSplit = layoutFields.split(",");
            if (tableName.equalsIgnoreCase(layoutTableName))
            {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                int groupNo = Integer.parseInt(mainId.substring(3, 4));
                int j = 0; // Get group info
                ArrayList rowsInfo = (ArrayList) js
                        .executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup','" + groupNo + "').subrows");
                String rowId = null;
                int k = 0;
                // If you want to select all elements then provide ALL in datasheet otherwise specify the fields in comma separated format
                if (!layoutFields.equals("ALL"))
                {
                    while (k < layoutFieldsSplit.length)
                    {
                        j = 0;
                        while (j < rowsInfo.size())
                        {
                            String row = rowsInfo.get(j).toString();
                            if (row.contains("columnName=" + layoutFieldsSplit[k]))
                            {
                                rowId = getUid(row);
                                js.executeScript("$('#dual-list-data-table-1').jqxGrid('selectrow', " + rowId + ")");
                                break;
                            }
                            j++;
                        }
                        k++;
                    }
                }
                WebElement destinationElement = driver.findElement(By
                        .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                Thread.sleep(2000);
                new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[@id='row0dual-list-data-table-1']")), destinationElement)
                .perform();
            }
            Thread.sleep(5000);
            i++;
        }
    }

    public void expandTableFields(String tableName)
    {
        String path = "//div[contains(text(),'" + tableName + "')]/preceding::div[1]";
        driver.findElement(By.xpath(path)).click();

    }

    public void selectLayoutFields()
    {
        for (String field : layoutFields)
        {
            try
            {
                driver.findElement(By.xpath("//div[contains(@title,'" + field + "')]"));
                WebElement destinationElement = driver.findElement(By
                        .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[contains(@title,'" + field + "')]")), destinationElement)
                .perform();

            } catch (NoSuchElementException e)
            {
                Actions dragger = new Actions(driver);
                int numberOfPixelsToDragTheScrollbarDown = 200;
                dragger.moveToElement(driver.findElement(By.xpath("//div[@id='verticalScrollBardual-list-data-table-1']/div[1]/div[1]/div[3]")))
                .clickAndHold().moveByOffset(0, numberOfPixelsToDragTheScrollbarDown).release().perform();
                driver.findElement(By.xpath("//div[contains(@title,'" + field + "')]"));
                WebElement destinationElement = driver.findElement(By
                        .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[contains(@title,'" + field + "')]")), destinationElement)
                .perform();

            }

        }

    }

    public void updateFieldValuesPerField(String layoutFieldsChange,String layout)
    {
        if(layout.equalsIgnoreCase("CREATE")){
            String[] fieldsSplit = layoutFieldsChange.split(",");
            int i = 0;
            JavascriptExecutor js = (JavascriptExecutor) driver;
            // get rows information
            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");

            while (i < fieldsSplit.length)
            {
                String[] fieldDetails = fieldsSplit[i].split("\\.");
                int j = 0;
                String rowId = null;
                while (j < rowsInfo.size())
                {
                    String row = rowsInfo.get(j).toString();
                    if (row.contains(fieldDetails[0])) // compare fieldname
                    {
                        // get rowid based on fieldname like dp_sequence_num
                        rowId = getUid(row);
                        break;
                    }
                    j++;
                }

                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + fieldDetails[1] + "', '" + fieldDetails[2]
                        + "')");
                i++;
            }
        }
    }
    public void updateFieldValuesPerFieldForResequenceReq(String layoutFieldsChange,String reseqReq)
    {
        if(reseqReq.equalsIgnoreCase("Y")){
            String[] fieldsSplit = layoutFieldsChange.split(",");
            int i = 0;
            JavascriptExecutor js = (JavascriptExecutor) driver;
            // get rows information
            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");

            while (i < fieldsSplit.length)
            {
                String[] fieldDetails = fieldsSplit[i].split("\\.");
                int j = 0;
                String rowId = null;
                while (j < rowsInfo.size())
                {
                    String row = rowsInfo.get(j).toString();
                    if (row.contains(fieldDetails[0])) // compare fieldname
                    {
                        // get rowid based on fieldname like dp_sequence_num
                        rowId = getUid(row);
                        break;
                    }
                    j++;
                }

                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + fieldDetails[1] + "', '" + fieldDetails[2]
                        + "')");
                i++;
            }
        }
    }
    private String getUid(String row)
    {
        String uidVal=null;
        String[] strSplit = row.split(",");
        List<String> list=Arrays.asList(strSplit);
        for(String str:list)
        {
        	if(str.trim().startsWith("uid"))
        	{
        		uidVal=str.split("=")[1];
        	}
        }
       /* uidVal = strSplit[0].substring(strSplit[0].indexOf("uid") + 4).trim();
        System.out.println("uidVal" + uidVal + ":Rowinfo:" + row);*/
        return uidVal;
    }

    private String getDataType(String row)
    {
        String dataType;
        String[] strSplit = row.split(",");
        dataType = strSplit[0].substring(strSplit[0].indexOf("dataType") + 9).trim();
        System.out.println("dataType" + dataType + ":Rowinfo:" + row);
        return dataType;
    }

    private String getVisibleIndex(String row)
    {
        String indexVal;
        String[] strSplit = row.split(",");
        indexVal = strSplit[0].substring(strSplit[14].indexOf("visibleindex") + 13).trim();
        return indexVal;
    }

    // added

    // div[@class='jqx-icon-add-mdb']

    @Step("Validate Add MDB Date Is Present ")
    public boolean checkMDBDateIsPresentInToolBar()
    {
        WebElement MDBDateIcon = driver.findElement(By.xpath("//div[@class='jqx-icon-add-mdb']"));
        boolean isPresent = MDBDateIcon.isDisplayed();
        return isPresent;
    }

    @Step("Validate Add MDB Date Is Enabled Or Not ")
    public boolean checkMDBDateIsEnabled() throws InterruptedException
    {
        boolean isMDBDateButtonEnabled = false;

        // selecting first row and then clicking on addMDB date button
        driver.findElement(
                By.xpath("//div[@id='contenttabledual-list-data-table-2']//div[1]//div[2]//div[contains(text(),'DP_SEQUENCE_NUM')]/parent::div"))
                .click();

        mdbAddButton.click();
        Thread.sleep(1500);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");


        int j = 0;
        String rowId = null;
        while (j < rowsInfo.size())
        {
            String row = rowsInfo.get(j).toString();
            if (row.contains("MDB_DATE"))// compare fieldname
            {
                // get rowid based on fieldname like dp_sequence_num
                isMDBDateButtonEnabled = true;
                break;
            }
            j++;
        }


        return isMDBDateButtonEnabled;
    }

    @Step("Fetch The Message From The Alert")
    public String fetchTheAlertMessage() throws InterruptedException
    {
        String message = driver.findElement(By.xpath("//div[@id='popup_message']")).getText();
        return message;

    }

    @Step("Close Alert")
    public void closeAlert() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@id='popup_panel']/input "));

    }

    @Step("Click MDBAdd Button")
    public void clickMDBAddButton() throws InterruptedException
    {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-250)", "");
        mdbAddButton.click();
        Thread.sleep(3500);

    }

    @Step("Click Resequence Button")
    public void clickResequenceAddButton(String isReseqRequired) throws InterruptedException
    {

        if(isReseqRequired.equalsIgnoreCase("Y"))
        {
            resequenceButton.click();
        }
        Thread.sleep(3500);

    }

    @Step("Click MDBAdd Button and Check The Grid")
    public String clickMDBAddButtonAndCheckTheGrid() throws InterruptedException
    {

        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-250)", "");
        mdbAddButton.click();
        Thread.sleep(3500);
        String addField = driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']//div[1]//div[2]//div")).getText();
        return addField;
    }

    @Step("Select The Field and click MDBAddButton")
    public void selectTheFieldAndClickMDBAddButton() throws InterruptedException
    {
        driver.findElement(
                By.xpath("//div[@id='contenttabledual-list-data-table-2']//div[1]//div[2]//div[contains(text(),'DP_SEQUENCE_NUM')]/parent::div"))
                .click();
        JavascriptExecutor jse = (JavascriptExecutor) driver;
        jse.executeScript("window.scrollBy(0,-250)", "");
        mdbAddButton.click();
        Thread.sleep(3500);
    }

    @Step("Fetch The Name and customer Name of Field Added In the Grid")
    public String[] getTheNameAndCustomerNameOfTheFieldAddedInTheGrid()
    {
        String[] fetchedName = new String[2];
        String fieldName = driver.findElement(
                By.xpath("//div[@id='contenttabledual-list-data-table-2']//div[contains(@id,'row1dual-list')]//div[2]/div")).getText();
        String customerName = driver.findElement(
                By.xpath("//div[@id='contenttabledual-list-data-table-2']//div[contains(@id,'row1dual-list')]//following::div[3]/div")).getText();
        fetchedName[0] = fieldName;
        fetchedName[1] = customerName;
        return fetchedName;

    }
  
    public void dragAndDropSelectedFieldForFirefox(String layoutTableName, String layoutFields,String layout ) throws InterruptedException
    {
        if(layout.equalsIgnoreCase("Create")){
            List<WebElement> elements = driver.findElements(By.xpath(".//*[@class='jqx-grid-group-cell jqx-draggable']/div/parent::div/parent::div"));
            int i = 0;
            while (i < elements.size())
            {
                String mainStr = elements.get(i).getText();
                String mainId = elements.get(i).getAttribute("id");
                String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
                String[] layoutFieldsSplit = layoutFields.split(",");
                if (tableName.equalsIgnoreCase(layoutTableName))
                {
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                    int groupNo = Integer.parseInt(mainId.substring(3, 4));
                    int j = 0; // Get group info
                    
                 Object obj= js.executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup',0)");
                //tring level= obj.level
                   // ArrayList rowsInfo = (ArrayList) js
                           // .executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup',0).subrows");
                    ArrayList rowsInfo = (ArrayList) js
                            .executeScript("return $('#dual-list-data-table-1').jqxGrid('getrows')");
                   // $('#dual-list-data-table-1').jqxGrid('getgroup',0 ) 
                    String rowId = null;
                    String columnName = null;
                    int k = 0;
                    // If you want to select all elements then provide ALL in datasheet otherwise specify the fields in comma separated format
                    if (!layoutFields.equals("ALL"))
                    {
                        while (k < layoutFieldsSplit.length)
                        {
                            j = 0;
                            while (j < rowsInfo.size())
                            {
                                String row = rowsInfo.get(j).toString();
                                if (row.contains("columnName=" + layoutFieldsSplit[k]))
                                {
                                    rowId = getUid(row);
                                    columnName = getFieldName(row);
                                    // uId = getUid(row);

                                    String str = "$('#dual-list-data-table-1').jqxGrid('getrowvisibleindex', " + rowId + ")";
                                    Long rowVisibleIndex = (Long) js.executeScript("return " + str + "");

                                    js.executeScript("$('#dual-list-data-table-1').jqxGrid('ensurerowvisible', " + rowVisibleIndex + "); ");
                                    Thread.sleep(3000);
                                    // js.executeScript("$('#dual-list-data-table-1').jqxGrid('selectrow', " + rowId + ")");
                                    WebElement ele = driver.findElement(By.xpath("//div[text()='" + columnName + "']/parent::div"));
                                    Actions action = new Actions(driver);
                                    action.click(ele);
                                    Thread.sleep(3000);

                                    WebElement destinationElement = driver.findElement(By
                                            .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                                    Thread.sleep(2000);
                                    new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[text()='" + columnName + "']/parent::div")),
                                            destinationElement).perform();

                                }
                                j++;
                            }
                            k++;
                        }
                    }

                }
                Thread.sleep(5000);
                i++;
            }
        }
    }
    
    public void dragAndDropSelectedField(String layoutTableName, String layoutFields,String layout ) throws InterruptedException
    {
        if(layout.equalsIgnoreCase("Create")){
            List<WebElement> elements = driver.findElements(By.xpath(".//*[@class='jqx-grid-group-cell jqx-draggable']/div/parent::div/parent::div"));
            int i = 0;
            while (i < elements.size())
            {
                String mainStr = elements.get(i).getText();
                String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
                String[] layoutFieldsSplit = layoutFields.split(",");
                if (tableName.equalsIgnoreCase(layoutTableName))
                {
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                    int k = 0;
                    // If you want to select all elements then provide ALL in datasheet otherwise specify the fields in comma separated format
                    if (!layoutFields.equals("ALL"))
                    {
                        while (k < layoutFieldsSplit.length)
                        {
                            WebElement destinationElement = driver.findElement(By
                                    .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                            Thread.sleep(2000);
                            new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[text()='" + layoutFieldsSplit[k] + "']/parent::div")),
                                    destinationElement).perform();
                            Thread.sleep(2500);
                            k++;
                        }
                    }
/*                    else{
                        WebElement destinationElement = driver.findElement(By
                                .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                        Thread.sleep(2000);
                        new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[text()='" + layoutFieldsSplit[k] + "']/parent::div")),
                                destinationElement).perform();
                    }*/

                }
                Thread.sleep(2000);
                i++;
            }
        }
    }

    private String getFieldName(String row)
    {
        String fieldName;
        String[] strSplit = row.split(",");
        fieldName = strSplit[7].substring(strSplit[7].indexOf("columnName") + 11).trim();
        System.out.println("fieldName" + fieldName + ":Rowinfo:" + row);
        return fieldName;
    }

    public void selectFields1(String tblName, String fields) throws InterruptedException
    {
        if (!driver.findElement(By.xpath("(//span[contains(text(),'Available Fields')])[2]")).isDisplayed())
        {
            try
            {
                driver.navigate().refresh();
                driver.switchTo().alert().accept();
                driver.switchTo().alert().accept();

            } catch (org.openqa.selenium.NoSuchElementException e)
            {

            }
        } else
        {
            driver.findElement(By.xpath("(//div[contains(text(),'" + tblName + "')]/preceding::div[1])[1]")).click();
            Thread.sleep(3000);
            StringTokenizer st = new StringTokenizer(fields, ",");
            while (st.hasMoreTokens())
            {
                String fld = st.nextToken();
                driver.findElement(By.xpath("//div[@title='" + fld + "']")).click();
                Thread.sleep(3000);
                WebElement destinationElement = driver.findElement(By
                        .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                Thread.sleep(3000);
                new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[@title='" + fld + "']")), destinationElement).perform();
            }
        }
    }

    public void layoutFldLengths(String fldName) throws InterruptedException
    {
        Actions action = new Actions(driver);
        String[] a = fldName.split(";");

        for (int i = 0; i < a.length; i++)
        {
            String z = a[i];
            String[] d = z.split(",");
            WebElement ele = driver.findElement(By.xpath("//div[contains(text(),'" + d[i] + "')]//following::div[8]"));
            action.doubleClick(ele).build().perform();
            Thread.sleep(5000);
            ele.sendKeys(d[i] + 1);
        }
    }

    public Map<String, String> fetchTheRowDetails()
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList<String> rowsInfo = new ArrayList<String>();
        rowsInfo = (ArrayList<String>)js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')[0];");
        Map<String, String> rowDetails = null;
        int j = 0;
        String requiredString = "MDB_DATE";
        while (j < rowsInfo.size())
        {
            String row = rowsInfo.get(j).toString();
            if (row.contains("customerFieldName=" + requiredString))
            {
                rowDetails = getRowDetails(row);
                break;
            }
            j++;
        }
        return rowDetails;
    }

    public String[] fetchThePositionDetails() throws InterruptedException
    {

        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows');");
        String[] positionDetails = null;
        int j = 0;
        String requiredString = "MDB_DATE";
        while (j < rowsInfo.size())
        {
            String row = rowsInfo.get(j).toString();
            if (row.contains("customerFieldName=" + requiredString))
            {

                positionDetails = fetchTheStartEndPosition(row);
                break;
            }
            j++;
        }
        return positionDetails;
    }

    private Map<String, String> getRowDetails(String row)
    {
        Map<String, String> rowDetailsMap = new HashMap<String, String>();

        String dataType = null;
        String padding = null;
        String justification;
        String length = null;
        String[] strSplit = row.split(",");
        dataType = strSplit[1].substring(strSplit[1].indexOf("dataType") + 9).trim();
        System.out.println("datatype" + dataType + ":Rowinfo:" + row);
        rowDetailsMap.put("dataType", dataType);

        length = dataType = strSplit[5].substring(strSplit[5].indexOf("fieldLength") + 12).trim();
        System.out.println("length" + dataType + ":Rowinfo:" + row);
        rowDetailsMap.put("fieldLength", length);
        padding = strSplit[8].substring(strSplit[8].indexOf("padding") + 8).trim();
        System.out.println("Padding" + dataType + ":Rowinfo:" + row);
        rowDetailsMap.put("padding", padding);
        justification = strSplit[7].substring(strSplit[7].indexOf("justification") + 14).trim();
        System.out.println("justification" + justification + ":Rowinfo:" + row);
        rowDetailsMap.put("justification", justification);
        return rowDetailsMap;
    }

    public String checkIsDisabled()
    {
        // first it will make default Value Column visible
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#dual-list-data-table-2').jqxGrid('hidecolumn', 'fieldName'); ");

        String value = null;
        boolean isEnabled = driver.findElement(By.xpath("//div[contains(text(),'MDB_DATE')]//parent::div//parent::div//div[14]")).isEnabled();
        if (isEnabled == true)
        {
            value = driver.findElement(By.xpath("//div[contains(text(),'MDB_DATE')]//parent::div//parent::div//div[14]/div")).getText();
        }
        return value;
    }

    @Step("click On Calculate Start/End Position")
    public void clickToCalculateStartEndPosition() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@class='jqx-icon-refresh-fusion']/parent::div")).click();
        Thread.sleep(1500);
    }

    @Step("Fetch The Start/End Position")
    public String[] fetchTheStartEndPosition(String row) throws InterruptedException
    {
        String[] positionArr = new String[2];
        String startPosition = null;
        String endPosition = null;
        String[] strSplit = row.split(",");
        startPosition = strSplit[5].substring(strSplit[5].indexOf("startPos") + 9).trim();
        System.out.println("startPosition" + startPosition + ":Rowinfo:" + row);
        endPosition = strSplit[5].substring(strSplit[5].indexOf("endPos") + 7).trim();
        System.out.println("endPosition" + endPosition + ":Rowinfo:" + row);
        positionArr[0] = startPosition;
        positionArr[1] = endPosition;
        return positionArr;
    }

    // div[starts-with(text(),'Output Folder')]/parent::div/div[2]
    // first it will make default Value Column visible
    /*
     * public String checkIsDisabled() { JavascriptExecutor js = (JavascriptExecutor) driver;
     * js.executeScript("$('#dual-list-data-table-2').jqxGrid('hidecolumn', 'fieldName'); ");
     */
    @Step("update The Row With Mask Or Scramble values")
    public void updateTheRowForMaskOrScrambleOrFormatMaskOption(String maskValues,String requiredField) throws InterruptedException
    {
        if (!maskValues.equalsIgnoreCase("NA"))
        {


            JavascriptExecutor js = (JavascriptExecutor) driver;
            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows');");
            int j = 0;
            String[] requiredStringArr = requiredField.split(",");
            List<String> reqFieldList=Arrays.asList(requiredStringArr);
            String rowId = null;
            while (j < rowsInfo.size())
            {
                String row = rowsInfo.get(j).toString();
                int k=0;
                while(k <reqFieldList.size())
                {
                    if (row.contains("customerFieldName=" + reqFieldList.get(k)))
                    {
                        rowId = getUid(row);

                        String rowBound = "$('#dual-list-data-table-2').jqxGrid('getrowvisibleindex',' " + rowId + "')";
                        Long rowBoundIndex = (Long) js.executeScript("return " + rowBound + "");
                        String[] maskArr = maskValues.split(";");
                        int i = 0;
                        while (i < maskArr.length)
                        {


                            String[] maskAq=maskArr[i].split("\\.");
                            if(maskAq[0].equalsIgnoreCase(reqFieldList.get(k)))
                            {


                                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowBoundIndex + ", '" + maskAq[1] + "','"
                                        + maskAq[2] + "');");

                            }
                            i++;
                        }

                    }
                    k++;
                }
                j++;
            }
        }
    }
    @Step("update The Row With Mask Or Scramble values")
    public void updateTheRowForFormatMaskOption(String maskValues,String requiredField) throws InterruptedException
    {
        if (!maskValues.equalsIgnoreCase("NA"))
        {


            JavascriptExecutor js = (JavascriptExecutor) driver;
            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows');");
            int j = 0;
            String[] requiredStringArr = requiredField.split(",");
            List<String> reqFieldList=Arrays.asList(requiredStringArr);
            String rowId = null;
            while (j < rowsInfo.size())
            {
                String row = rowsInfo.get(j).toString();
                int k=0;
                while(k <reqFieldList.size())
                {
                    if (row.contains("customerFieldName=" + reqFieldList.get(k)))
                    {
                        rowId = getUid(row);

                        String rowBound = "$('#dual-list-data-table-2').jqxGrid('getrowvisibleindex',' " + rowId + "')";
                        Long rowBoundIndex = (Long) js.executeScript("return " + rowBound + "");
                        String[] maskArr = maskValues.split(";");
                        int i = 0;
                        while (i < maskArr.length)
                        {


                            String[] maskAq=maskArr[i].split("-");
                            if(maskAq[0].equalsIgnoreCase(reqFieldList.get(k)))
                            {


                                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowBoundIndex + ", '" + maskAq[1] + "','"
                                        + maskAq[2] + "');");

                            }
                            i++;
                        }

                    }
                    k++;
                }
                j++;
            }
        }
    }
    @Step("Fetch The Count Of Fields In The Table")
    public Integer fetchThecountOfFieldsInTheTable(String layoutTableName) throws InterruptedException
    {
        List<WebElement> elements = driver.findElements(By.xpath(".//*[@class='jqx-grid-group-cell jqx-draggable']/div/parent::div/parent::div"));
        
        Integer noOfFields=0;
        int i = 0;
        while (i < elements.size())
        {
            String mainStr = elements.get(i).getText();
            String mainId = elements.get(i).getAttribute("id");
            String tableName = mainStr.substring(mainStr.indexOf(':') + 1);

            if (tableName.equalsIgnoreCase(layoutTableName))
            {
                JavascriptExecutor js = (JavascriptExecutor) driver;
                js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                int groupNo = Integer.parseInt(mainId.substring(3, 4));
                int j = 0; // Get group info
                ArrayList rowsInfo = (ArrayList) js
                        .executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup','" + groupNo + "').subrows");
                noOfFields  =rowsInfo.size();
            }
            i++;
        }
        return noOfFields;
    }

    public boolean isTablePresentInAvaliableFields(String tableName)
    {
        boolean isTablePresent=false;
        List<WebElement> elements = driver.findElements(By.xpath("//div[contains(text(),'Available Fields')]//following::div[@class='content']/ul/li/a"));
        for(WebElement element:elements)
        {
            if(element.getText().contains(tableName))

            {
                isTablePresent=true;
            }
        }
        return isTablePresent;
    }
    public void dragAndDropSelectedFieldUsingSearchBox(String layoutTableName, String layoutFields,String layout ) throws InterruptedException
    {
        if(layout.equalsIgnoreCase("Create"))
        {
        	 
            List<WebElement> elements = driver.findElements(By.xpath(".//*[@class='jqx-grid-group-cell jqx-draggable']/div/parent::div/parent::div"));
            int i = 0;
            while (i < elements.size())
            {
                String mainStr = elements.get(i).getText();
                String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
              
                String[] layoutFieldsSplit = layoutFields.split(",");
           	    int l=0;
           	 while (l< layoutFieldsSplit.length)
           	 {
           	  
                if (tableName.equalsIgnoreCase(layoutTableName))
                {
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                    WebElement ele=  driver.findElement(By.xpath("//span[(text()='Available Fields')]/following::div[38]/div/div/div/input[1]"));
                    
                    ele.clear();
                   
                    ele.sendKeys(layoutFieldsSplit[l]);
                   
                       WebElement destinationElement = driver.findElement(By
                                    .xpath("//div[@id='layoutFieldsGrid']/div/div/div/div[4]/div[2]/div/div[1]/div[1]"));
                            Thread.sleep(2000);
                            js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                            new Actions(driver).dragAndDrop(driver.findElement(By.xpath("//div[text()='" + layoutFieldsSplit[l] + "']/parent::div")),
                                    destinationElement).perform();
                            Thread.sleep(2500);
                            js.executeScript("$('#dual-list-data-table-1').jqxGrid('collapsegroup', '" + i + "')");
                             Thread.sleep(4500);
                       
                        
                    }
                l++;

                }
            i++;
           
            Thread.sleep(2000);
               
            }
        }
    }

    public void handleTheDialogBoxAndClickContinue()
    {
    	if (isElementPresent(By.xpath("//*[@id='layoutWarningJqWindow']")))
    		driver.findElement(By.xpath("//*[@id='layoutWarningJqWindow']//input[@id='continueOnWarning']")).click();
    }
    
    
public String fetchTheErrorMsgFromTheDialogBox()
{
	return driver.findElement(By.xpath("//*[@id='layoutWarningJqWindow']//div[@id='layoutWarningMsgs']//td[2]")).getText();
}
}
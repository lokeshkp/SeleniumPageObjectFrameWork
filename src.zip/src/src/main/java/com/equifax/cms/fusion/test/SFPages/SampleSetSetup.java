package com.equifax.cms.fusion.test.SFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class SampleSetSetup
{
    WebDriver driver;
    public Select selType;

    public SampleSetSetup(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "noOfAcceptRecs")
    WebElement noOfAcceptRecs;

    @FindBy(id = "noOfRejectRecs")
    WebElement noOfRejectRecs;

    @FindBy(id = "resolveFields")
    WebElement resolveFields;

    @FindBy(id = "auditCriteriaLevel")
    WebElement auditCriteriaLevel;

    @FindBy(xpath = "//div[@class='buttons']/input[@value='Save']")
    WebElement Save_Btn;

    @FindBy(xpath = "//div[@class='buttons']/input[@onclick='changeForm()']")
    WebElement Continue_Btn;

    @Step("Click continue button")
    public void clickContinueBtn() throws InterruptedException
    {
        Thread.sleep(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", Continue_Btn);
        // Continue_Btn.click();
        // .click();
    }

    @Step("Click save button")
    public void clickSaveBtn() throws InterruptedException
    {
        Thread.sleep(3000);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", Save_Btn);
        // Save_Btn.click();
    }

    @Step("Edit Audit Criteria Selections")
    public void addCellValuesForAuditCriteria1(String pId, String table, String fields, String levels, String operators, String lowValues,
            String highValues, String counts) throws InterruptedException
    {
        Thread.sleep(5000);
        Actions action = new Actions(driver);

        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement levelCol = driver.findElement(By.xpath("//div[@id='row0dual-list-data-table-2']/div[6]"));
        action.doubleClick(levelCol).perform();
        Thread.sleep(500);
        WebElement dropDownExpand = driver.findElement(By
                .xpath("//div[@id='dropdownlistArrowcomboboxeditordual-list-data-table-2criteriaLevel']/div"));
        dropDownExpand.click();

        js.executeScript("$('#comboboxeditordual-list-data-table-2criteriaLevel').jqxComboBox('selectItem','" + levels + "')");

        WebElement operatorCol = driver.findElement(By.xpath("// div[@id='row0dual-list-data-table-2']/div[7]"));
        operatorCol.click();
        action.doubleClick(operatorCol).perform();
        WebElement ddlExpand = driver.findElement(By.xpath("//div[@id='dropdownlistArrowcomboboxeditordual-list-data-table-2operator']/div"));
        ddlExpand.click();
        Thread.sleep(500);
        driver.findElement(By.xpath("//span[contains(text(),'RANGE')]")).click();
        WebElement countDdl = driver.findElement(By.xpath("// div[@id='row0dual-list-data-table-2']/div[10]"));
        countDdl.click();
        // js.executeScript("$('#comboboxeditordual-list-data-table-2criteriaLevel').jqxComboBox('selectItem','" + operators + "')");
        //
        // ddlExpand.click();
        //
        // js.executeScript("$('#comboboxeditordual-list-data-table-2criteriaLevel').jqxComboBox('selectItem','" + operators + "')");

        if (!"= NULL".equalsIgnoreCase(operators) && !"<> NULL".equalsIgnoreCase(operators))
        {
            // WebElement lowval = driver.findElement(By.xpath("// div[@id='row0dual-list-data-table-2']/div[8]"));
            // action.doubleClick(lowval).perform();
            js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue',0, 'lowValue','" + lowValues + "');");
            if ("Range".equalsIgnoreCase(operators))

            {
                // WebElement rangeDdl = driver.findElement(By.xpath("// div[@id='row0dual-list-data-table-2']/div[9]"));
                // action.doubleClick(rangeDdl).perform();
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue',0, 'highValue','" + highValues + "');");
            }
        }

        // action.doubleClick(countDdl).perform();
        js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue',0, 'count','" + counts + "');");

    }

    // @Step("Edit Audit Criteria Selections")
    // public void addCellValuesForAuditCriteria(String pId, String table, String fields, String levels, String operators, String lowValues,
    // String highValues, String counts) throws InterruptedException
    // {
    // String[] fieldsArray = fields.split(",");
    // String[] levelsArray = levels.split(",");
    // String[] operatorsArray = operators.split(",");
    // String[] lowValuesArray = lowValues.split(",");
    // String[] highValuesArray = highValues.split(",");
    // String[] countsArray = counts.split(",");
    //
    // int i = 0;
    // JavascriptExecutor js = (JavascriptExecutor) driver;
    // ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
    // String rowId = null;
    //
    // while (i < rowsInfo.size())
    // {
    // // String[] field = fieldsArray[i].split("\\.");
    // String row = rowsInfo.get(i).toString();
    // if (row.contains("columnName=" + pId + ":" + table + "." + fieldsArray[i]))
    // {
    // rowId = getUid(row);
    // int j = 0;
    //
    // String[] criteriaLevel = levelsArray[i].split("\\.");
    // String[] operator = operatorsArray[i].split("\\.");
    // String[] lowValue = lowValuesArray[i].split("\\.");
    // String[] highValue = highValuesArray[i].split("\\.");
    // String[] count = countsArray[i].split("\\.");
    //
    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + criteriaLevel[0] + "','" + criteriaLevel[1]
    // + "');");
    // // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + criteriaLevel[0] + "','" +
    // // criteriaLevel[1]
    // // + "');");
    // Thread.sleep(3000);
    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + operator[0] + "','" + operator[1] + "');");
    // // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + operator[0] + "','" + operator[1] +
    // // "');");
    // Thread.sleep(3000);
    // if (!"= NULL".equalsIgnoreCase(operator[0]) && !"<> NULL".equalsIgnoreCase(operator[0])
    // && org.apache.commons.lang3.StringUtils.isNotBlank(lowValue[1])
    // && org.apache.commons.lang3.StringUtils.isNotEmpty(lowValue[1])
    // && org.apache.commons.lang3.StringUtils.isNotBlank(highValue[1])
    // && org.apache.commons.lang3.StringUtils.isNotEmpty(highValue[1]))
    // {
    //
    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + lowValue[0] + "','" + lowValue[1]
    // + "');");
    // if ("Range".equalsIgnoreCase(operator[0]))
    // {
    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + highValue[0] + "','" + highValue[1]
    // + "');");
    // }
    // }
    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue'," + rowId + ", '" + count[0] + "','" + count[1] + "');");
    //
    // }
    // i++;
    // }
    //
    // }

    @Step("Cool Samp Jqx Grid")
    public void saveAuditCriteriaSelections(String table, String fields) throws InterruptedException
    {
        WebElement searchBox = driver.findElement(By.xpath("//div[@id='row00dual-list-data-table-1']/div/div/input"));
        // WebElement clickSearch = driver.findElement(By.xpath("//div[@id='row00dual-list-data-table-1']/div/div/div/div/div/div[2]/div"));
        Thread.sleep(2000);
        // List<WebElement> elements = driver.findElements(By
        // .xpath("//div[@id='dual-list-data-table-1']/div/div/div[4]/div[2]/div/div/div[@class='jqx-grid-group-cell jqx-draggable']/div"));

        List<WebElement> elements = driver.findElements(By.xpath("//div[@id='dual-list-data-table-1']/div/div/div[4]/div[2]/div/div"));

        int i = 0;
        String[] layoutFieldsSplit = fields.split(",");
        int fieldsSize = layoutFieldsSplit.length;
        while (i < elements.size() && fieldsSize > 0)
        {
            String mainStr = elements.get(i).getText();
            String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
            String mainId = driver.findElement(By.xpath("//div[contains(text(),'" + mainStr + "')]/parent::div/parent::div[1]")).getAttribute("id");
            // row1dual-list-data-table-1
            int groupNo = Integer.parseInt(mainId.substring(3, 4));

            if (tableName.equalsIgnoreCase(table))
            {
                int j = 0;
                for (String sel : layoutFieldsSplit)
                {
                    searchBox.clear();
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
                    Thread.sleep(1000);

                    searchBox.clear();
                    searchBox.sendKeys(layoutFieldsSplit[j]);
                    Thread.sleep(2000);
                    int k = 0;
                    ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-1').jqxGrid('getrows')");
                    String rowId = null;
                    while (k < rowsInfo.size())
                    {
                        String row = rowsInfo.get(k).toString();
                        if (row.contains("tableName=" + mainStr))
                        {
                            rowId = getUid(row);
                            js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', " + k + ")");

                        }
                        k++;
                    }

                    WebElement selectedField = driver.findElement(By.xpath("// div[contains(text(),'" + mainStr
                            + "')]/parent::div/parent::div/following::div[1]/div[2]/div"));
                    selectedField.click();
                    String id = "row" + j + "dual-list-data-table-2";

                    Actions action = new Actions(driver);
                    action.click(selectedField);

                    WebElement destinationElement = driver.findElement(By
                            .xpath("//div[@id='dual-list-data-table-2']/div/div/div[4]/div[2]/div/div[@id='" + id + "']/div[1]"));
                    Thread.sleep(2000);
                    if (sel.equalsIgnoreCase(layoutFieldsSplit[0]))
                    {
                        new Actions(driver).dragAndDrop(selectedField, destinationElement).perform();
                        Thread.sleep(2000);
                        // new Actions(driver).dragAndDrop(selectedField, destinationElement).perform();
                    } else
                    {
                        new Actions(driver).dragAndDrop(selectedField, destinationElement).perform();
                    }

                    j++;
                    fieldsSize--;
                }
            }

            i++;

        }
    }

    //
    // @Step("Cool Samp Jqx Grid")
    // public void saveAuditCriteriaSelections(String table, String fields) throws InterruptedException
    // {
    //
    // List<WebElement> elements = driver.findElements(By
    // .xpath("//div[@id='dual-list-data-table-1']/div/div/div[4]/div[2]/div/div/div[@class='jqx-grid-group-cell jqx-draggable']/div"));
    // int i = 0;
    // while (i < elements.size())
    // {
    // String mainStr = elements.get(i).getText();
    // String mainId = driver.findElement(By.xpath("//div[contains(text(),'" + mainStr + "')]/parent::div/parent::div[1]")).getAttribute("id");
    // // String mainId = elements.get(i).getAttribute("id");
    // String tableName = mainStr.substring(mainStr.indexOf(':') + 1);
    // String[] layoutFieldsSplit = fields.split(",");
    // if (tableName.equalsIgnoreCase(table))
    // {
    // JavascriptExecutor js = (JavascriptExecutor) driver;
    // js.executeScript("$('#dual-list-data-table-1').jqxGrid('expandgroup', '" + i + "')");
    // int groupNo = Integer.parseInt(mainId.substring(3, 4));
    // int j = 0; // Get group info
    // ArrayList rowsInfo = (ArrayList) js
    // .executeScript("return $('#dual-list-data-table-1').jqxGrid('getgroup','" + groupNo + "').subrows");
    // String rowId = null;
    // String columnName = null;
    // int k = 0;
    // // If you want to select all elements then provide ALL in datasheet otherwise specify the fields in comma separated format
    //
    // while (k < layoutFieldsSplit.length)
    // {
    // j = 0;
    // while (j < rowsInfo.size())
    // {
    // String row = rowsInfo.get(j).toString();
    // if (row.contains("columnName=" + layoutFieldsSplit[k]))
    // {
    // rowId = getUid(row);
    // columnName = getFieldName(row);
    //
    // String str = "$('#dual-list-data-table-1').jqxGrid('getrowvisibleindex'," + rowId + ")";
    // // String str = "$('#dual-list-data-table-1').jqxGrid('getrowboundindex',27)";
    // Long rowVisibleIndex = (Long) js.executeScript("return " + str + "");
    //
    // js.executeScript("$('#dual-list-data-table-1').jqxGrid('ensurerowvisible', " + rowVisibleIndex + "); ");
    // Thread.sleep(3000);
    //
    // WebElement ele = driver.findElement(By.xpath("//div[text()='" + columnName + "']/parent::div"));
    // Thread.sleep(3000);
    // Actions action = new Actions(driver);
    // action.click(ele);
    // Thread.sleep(3000);
    // ele.click();
    //
    // String id = "row" + k + "dual-list-data-table-2";
    //
    // WebElement destinationElement = driver.findElement(By
    // .xpath("//div[@id='dual-list-data-table-2']/div/div/div[4]/div[2]/div/div[@id='" + id + "']/div[1]"));
    //
    // // WebElement destinationElement1 = driver.findElement(By
    // // .xpath("//div[@id='dual-list-data-table-2']/div/div/div[4]/div[2]/div/div/div[1]/div"));
    // Thread.sleep(2000);
    // new Actions(driver).dragAndDrop(ele, destinationElement).perform();
    //
    // // new Actions(driver).dragAndDrop(ele, destinationElement).perform();
    //
    // }
    // j++;
    // }
    // k++;
    // }
    //
    // }
    // Thread.sleep(5000);
    // i++;
    // }
    // }

    private String getFieldName(String row)
    {
        String fieldName;
        String[] strSplit = row.split(",");
        String s7 = strSplit[4];
        fieldName = strSplit[4].substring(strSplit[4].indexOf("columnName") + 11).trim();
        int len = fieldName.length();
        String newString = fieldName.substring(0, len - 1);
        System.out.println("fieldName1" + fieldName + ":Rowinfo:" + row);
        return newString;
    }

    private String getUid(String row)
    {
        String uidVal;
        String[] strSplit = row.split(",");
        int index = strSplit[0].indexOf("uid");
        uidVal = strSplit[0].substring(strSplit[0].indexOf("uid") + 4).trim();
        // uidVal = strSplit[0].substring(strSplit[0].indexOf("uid") + 4).trim();
        return uidVal;
    }

    public void clickResolveFields()
    {
        String errorContent = driver.findElement(By.xpath("//div[@class='optionsErrMsg resolveFields']")).getText();
        if (errorContent.contains("Please select the Resolve fields option to resolve the fields as you have changed the input."))
        {
            resolveFields.click();
        }
    }

    public By auditCriteriaRadio()
    {
        return By.id("auditCriteriaLevel");
    }

    public void clickAuditCriteria()
    {
        auditCriteriaLevel.click();
    }

    public String getOptionsErrorMsg()
    {
        return driver.findElement(By.xpath("//div[@class='optionsErrMsg']")).getText();
    }

    public String getRowNumber()
    {
        return driver.findElement(By.xpath("//div[@id='row0dual-list-data-table-2']/div[1]/div")).getText();
    }

    public String getTagNumber()
    {

        return driver.findElement(By.xpath("//div[@id='row0dual-list-data-table-2']/div[8]/div")).getText();

    }

    public void selectAddedField(String pId, String table, String fields)
    {

        String str = pId + ":" + table + "." + fields;
        driver.findElement(By.xpath("//div[contains(text(),'" + str + "')]")).click();
    }

    public void clickDeleteRow()
    {
        driver.findElement(By.xpath("//div[@id='toolbardual-list-data-table-2']/div/div[5]/div")).click();

    }

    public String getPageTitle()
    {
        return driver.findElement(By.xpath("//div[@class='cmsContent']/div[2]/h3")).getText();
    }

    public boolean getAvailableOpertors() throws InterruptedException
    {
        Actions action = new Actions(driver);
        JavascriptExecutor js = (JavascriptExecutor) driver;
        WebElement operatorCol = driver.findElement(By.xpath("// div[@id='row0dual-list-data-table-2']/div[7]"));
        action.doubleClick(operatorCol).perform();
        WebElement ddlExpand = driver.findElement(By.xpath("//div[@id='dropdownlistArrowcomboboxeditordual-list-data-table-2operator']/div"));
        ddlExpand.click();
        Thread.sleep(2000);
        WebElement op1 = driver.findElement(By.xpath("//span[contains(text(),'=  EQ')]"));
        WebElement op2 = driver.findElement(By.xpath("//span[contains(text(),'<>  NE')]"));
        WebElement op3 = driver.findElement(By.xpath("//span[contains(text(),'>  GT')]"));
        WebElement op4 = driver.findElement(By.xpath("//span[contains(text(),'<  LT')]"));
        WebElement op5 = driver.findElement(By.xpath("//span[contains(text(),'>=  GE')]"));
        WebElement op6 = driver.findElement(By.xpath("//span[contains(text(),'<=  LE')]"));
        WebElement op7 = driver.findElement(By.xpath("//span[contains(text(),'= Null')]"));
        WebElement op8 = driver.findElement(By.xpath("//span[contains(text(),'<> Null')]"));
        WebElement op9 = driver.findElement(By.xpath("//span[contains(text(),'RANGE')]"));
        List<WebElement> eleList = new ArrayList<>();
        eleList.add(op1);
        eleList.add(op2);
        eleList.add(op3);
        eleList.add(op4);
        eleList.add(op5);
        eleList.add(op6);
        eleList.add(op7);
        eleList.add(op8);
        eleList.add(op9);

        boolean flag = false;
        for (WebElement ele : eleList)
        {
            if (ele.isDisplayed() == true)
            {
                flag = true;
            } else
            {
                return false;
            }
        }
        return flag;
    }

    public boolean isElementPresent()
    {
        try
        {
            driver.findElement(By.id("auditCriteriaLevel"));
            System.out.println("try");
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public void clearNoOfRejectRecs()
    {
        noOfRejectRecs.clear();
    }

    public void clearNoOfAcceptRecs()
    {
        noOfAcceptRecs.clear();
    }

    public void clickConfirmDelete()
    {
        driver.findElement(By.xpath("//div[@id='confirmDel']/div[2]/center/input[@id='confirmDelOk']")).click();
    }
}

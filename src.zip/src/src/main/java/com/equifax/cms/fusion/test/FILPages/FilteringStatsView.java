package com.equifax.cms.fusion.test.FILPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class FilteringStatsView
{
    WebDriver driver;
    public Select selType;

    public FilteringStatsView(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    public String getInputRecordsSelectedForProcessing()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Input records selected for processing')]//following::div[2]")).getText();
    }

    public long getInputRecordsSelectedForProcessing_Long()
    {
        return Long.parseLong(RemoveComma(driver.findElement(
                By.xpath(".//*[contains(text(),'Input records selected for processing')]//following::div[2]")).getText()));
    }

    @Step("Fetched the Output Table Count For Group = {0}")
    public Long getOutputTableCountForGroup(String group)
    {
        return Long.parseLong(RemoveComma(driver.findElement(
                By.xpath(".//*[contains(text(),'Total Output:" + group + "')]/following-sibling::div[2]")).getText()));
    }

    @Step("Fetched Input Table Name for Filtering Process")
    public String getInputTableName()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Input Table')]/following::div[3]/div[1]")).getText();
    }

    @Step("Fetched Input Table Count for Filtering Process")
    public Long getInputTableCount()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath(".//*[contains(text(),'Input Table')]/following::div[3]/div[3]")).getText()));
    }

    @Step("Fetched Output Table Name for Filtering Process")
    public String getOutputTableName()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'_FILTER_GPFILTER_FILTERTBL')]")).getText();
    }
    
    @Step("Fetched Output Table Name for Filtering Process")
    public String getOutputTableNameWithFLAsInput()
    {
        return driver.findElement(By.xpath("(.//*[contains(text(),'_FILTER_GPFILTER_FILTERTBL')])[2]")).getText();
    }

    @Step("Fetched Output Table Count for Fitlering Process")
    public Long getOutputTableCount()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath(".//*[contains(text(),'_FILTER_GPFILTER_FILTERTBL')]/following::div[2]"))
                .getText()));
    }

    @Step("Fetched Surplus Record Count for Fitlering Process")
    public Long getSurplusCountUI()
    {
        return Long
                .parseLong(RemoveComma(driver.findElement(By.xpath(".//*[contains(text(),'Total excess records')]//following::div[2]")).getText()));
    }

    @Step("Fetched Total Accepted Record For Group 1")
    public Long getTotalAcceptedGrp1()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Total Accepted')])[1]//following::div[1]")).getText()));
    }

    @Step("Fetched Total Accepted Record For Group 2")
    public Long getTotalAcceptedGrp2()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Total Accepted')])[2]//following::div[1]")).getText()));
    }

    @Step("Fetched Total Output Record For Group 1")
    public Long getTotalOutputGrp1()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath(".//*[contains(text(),'Total Output:G1')]//following::div[2]")).getText()));
    }

    @Step("Fetched Total Output Record For Group 2")
    public Long getTotalOutputGrp2()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath(".//*[contains(text(),'Total Output:G2')]//following::div[2]")).getText()));
    }

    @Step("Fetched Input Count For Group 2")
    public Long getInputCountGrp1()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Input Count')])[1]/following::div[2]")).getText()));
    }

    @Step("Fetched Input Count For Group 2")
    public Long getInputCountGrp2()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Input Count')])[2]/following::div[2]")).getText()));
    }

    @Step("Fetched Output of Group 1 Condition 1")
    public Long getOutputG1C1()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Groups:')])//following::div[13]")).getText()));
    }

    @Step("Fetched Output of Group 1 Condition 2")
    public Long getOutputG1C2()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Groups:')])//following::div[17]")).getText()));
    }

    @Step("Fetched Output of Group 2 Condition 1")
    public Long getOutputG2C1()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Groups:')])//following::div[45]")).getText()));
    }

    @Step("Fetched Output of Group 2 Condition 2")
    public Long getOutputG2C2()
    {
        return Long.parseLong(RemoveComma(driver.findElement(By.xpath("(.//*[contains(text(),'Groups:')])//following::div[49]")).getText()));
    }

    @Step("Fetched Output of Other Records")
    public Long getOtherCountUI()
    {
        return Long.parseLong(RemoveComma(driver.findElement(
                By.xpath(".//*[contains(text(),'Total records not matched in any groups/conditions')]//following::div[2]")).getText()));
    }

    public boolean isRecordTypeDisplayed()
    {
        try
        {
            String a = driver.findElement(By.xpath(".//*[contains(text(),'Record Type Distribution')]")).getText();
            System.out.println(a);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public static String RemoveComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (int i = 0; i < a1.length; i++)
        {
            a2 = a2 + a1[i];
        }
        return a2;
    }

}

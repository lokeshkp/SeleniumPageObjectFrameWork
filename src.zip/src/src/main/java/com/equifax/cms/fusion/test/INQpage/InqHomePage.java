package com.equifax.cms.fusion.test.INQpage;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class InqHomePage {

		WebDriver driver;
		
	public InqHomePage(WebDriver driver){
		this.driver = driver;
		
	}
	
	@FindBy(xpath = "//a[contains(text(),'Inquiry Posting')]")
	WebElement InqPostTab;
	
	@FindBy(xpath = "//span[contains(text(),'Post Inquiry')]")
	WebElement PostInquiry_Btn;
	
	@Step("Clicked Inquiry  Posting Tab")
	public void clickInqPostingTab(){
		InqPostTab.click();
	}
	
	@Step("Clicked Inquiry  Setup button")
	public void clickPostInqButton(){
		PostInquiry_Btn.click();
	}
	
	@Step("Status of the Inquiry Posting process")
	public String getStatusInqPost()
    {
        String status = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[3]")).getText();
        return status;
    }
	
}

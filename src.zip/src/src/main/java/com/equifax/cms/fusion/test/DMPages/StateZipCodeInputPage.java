package com.equifax.cms.fusion.test.DMPages;

import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import ru.yandex.qatools.allure.annotations.Step;

public class StateZipCodeInputPage {

	WebDriver driver;
	public Select selType;

	public StateZipCodeInputPage(WebDriver driver){

		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	}

	@FindBy(id = "zipCodeInput")
	public WebElement Ele_zipCodeInput;

	@FindBy(id = "selectStateOptions")
	public WebElement Ele_SelectStates;

	@FindBy(id = "stDropKeep1")
	public WebElement Ele_drop;

	@FindBy(id = "stDropKeep2")
	public WebElement Ele_tag;

	@FindBy(id = "stDropKeep3")
	public WebElement Ele_reject;

	@FindBy(xpath = ".//input[@type='submit']")
	public WebElement ContinueButton;

	@FindBy(id = "zipFileView")
	WebElement ZipFileViewButton;
	
	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement Back_Btn;
	
	@FindBy(xpath = "//input[@value='Beta']")
	WebElement Beta_Btn;
	
	@Step("Clicked on Beta button")
	public void clickBetaBtn(){
		Beta_Btn.click();
	}

	@Step("Click Back Button on State/Zip Code Input Page")
	public void clickBackBtn() {
		Back_Btn.click();
	}
	
	@Step("Select Zip Code = \"{0}\"")
	public void selectZipCodeInputField(String fieldType){
		if(!"NA".equalsIgnoreCase(fieldType)){
			selType = new Select(Ele_zipCodeInput);
//			selType.selectByVisibleText(fieldType);
			selType.selectByValue(fieldType);
		}
	}

	@Step("Select Input States = \"{0}\"")
	public void selectStatesDropDwn(String states){
		if("NA".equalsIgnoreCase(states)){
			System.out.println("Please select the individual states..");
		} else {
			selType = new Select(Ele_SelectStates);
			selType.selectByVisibleText(states);
//			selType.selectByValue(states);
		}
	}

	@Step("Select Drop")
	public void clickDropRadiobutton(){
		Ele_drop.click();
	}

	@Step("Select Tag")
	public void clickTagRadiobutton(){
		Ele_tag.click();
	}

	@Step("Select Reject")
	public void clickRejectRadiobutton(){
		Ele_reject.click();
	}

	@Step("Select Input States List = \"{0}\"")
	public void selectStatesList(String stateList){
		String comma = ",";
		StringTokenizer stMain = new StringTokenizer(stateList, comma);
		while (stMain.hasMoreElements()) 
		{
			driver.findElement(By.xpath("//input[@id='"+stMain.nextToken()+"']")).click();
		}
	}
	
	public void elementsInStatesDdown(){
	    String[] exp = {"Select","Do Not Reject Stats", "All U.S. states and Territories","All except Vermont","US States Only",
	            "US States Only except Vermont","Territories Only (AS, FM, GU, MH, MP, PR, PW, UM, and VI)",
	            "Military APO/FPO/DPO Only(AA, AE, & AP)","Selected Areas (any other custom selection)"};
	    selType = new Select(Ele_SelectStates);
	    List<WebElement> options = selType.getOptions();
	    for(WebElement we:options){
	        boolean match = false;
	        for(int i=0;i<exp.length;i++){
	            if(we.getText().equals(exp[i])){
	                match = true;
	            }
	        }
	        Assert.assertTrue(match, we.getText());
	    }	    
	}
	
	

	@Step("Click Continue on State Zip Input Page")
	public void clickContinueButton() {
		ContinueButton.click();
	}

}

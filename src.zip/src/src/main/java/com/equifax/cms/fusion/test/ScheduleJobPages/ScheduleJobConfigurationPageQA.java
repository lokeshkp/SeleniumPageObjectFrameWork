package com.equifax.cms.fusion.test.ScheduleJobPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

public class ScheduleJobConfigurationPageQA
{
    WebDriver driver;
    public Select selType;
    public ScheduleJobConfigurationPageQA(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    
    @FindBy(xpath = ".//*[@name='submitButton']")
    WebElement SaveButton;
    
    @FindBy(xpath = "(.//*[@class='orange-btn'])[1]")
    WebElement BackButton;
    
    @FindBy(id = "generate-param")
    WebElement GenerateParamTemplate;
    
    public void clickGenerateParamTemplate() 
    {
        GenerateParamTemplate.click();
    }
    
    public void clickBackButton() 
    {
        BackButton.click();
    }
    
    public void clickSaveButton()
    {
        SaveButton.click();
    }
    
    
    
    public boolean isGenerateParamButtonDisplayed() 
    {
        try 
        {
            driver.findElement(By.id("generate-param")).click();
            return true;
        }catch(org.openqa.selenium.NoSuchElementException e) 
        {
            return false;
        }
    }
    
    public void clickFirstEdit()
    {
        driver.findElement(By.xpath("(.//*[@alt='edit'])[1]")).click();
    }
}

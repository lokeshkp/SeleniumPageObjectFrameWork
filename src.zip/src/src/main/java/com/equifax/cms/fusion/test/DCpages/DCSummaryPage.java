package com.equifax.cms.fusion.test.DCpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DCSummaryPage
{

    WebDriver driver;
    public Select selType;

    public DCSummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "//a[contains(text(),'Submit')]")
    WebElement Submit_Btn;

    @Step("Clicked Submit Button")
    public void clickSubmitButton()
    {
        Submit_Btn.click();
    }

    public String getWarningMessage()
    {
        return driver.findElement(By.id("warningMsg")).getText();
    }

    public boolean isProcessJobDataDisplayedL()
    {
        return !driver.findElements(By.xpath("(.//*[@id='inputSummaryTableSplit'])[1]/thead/tr/th")).isEmpty();
    }

    public boolean isProcessJobDataDisplayedR()
    {
        return !driver.findElements(By.xpath("(.//*[@id='inputSummaryTableSplit'])[2]/thead/tr/th")).isEmpty();
    }

    public String getRightProcessName()
    {
        String proName = driver.findElement(By.xpath("(.//*[@id='inputSummaryTableSplit'])[2]/tbody/tr/td[1]")).getText();
        String[] proNameArr = proName.split(":");
        return proNameArr[0].trim() + ":" + proNameArr[1].trim();
    }

    public String getRightTable()
    {
        return driver.findElement(By.xpath("(.//*[@id='inputSummaryTableSplit'])[2]/tbody/tr/td[3]")).getText();
    }

    public String getErrorMessage()
    {
        return driver.findElement(By.id("erMsg")).getText();
    }

}

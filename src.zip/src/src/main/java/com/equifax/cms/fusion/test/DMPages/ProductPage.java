package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ProductPage {

		WebDriver driver;
		
	public ProductPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
		//PageFactory.initElements(driver, this);
	}
	
	@FindBy(id = "product")
	public WebElement Ele_product;
	
	@FindBy(id = "productId")
	WebElement Ele_ProductId;
	
	@FindBy(id = "memberNumber")
	WebElement Ele_MemberNumber;
	
	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement Back_Btn;
	
	@FindBy(xpath = ".//input[@type='submit']")
	WebElement ContinueButton;
	
	
	@Step("Select Product Field :  \"{0}\" ")
	public void selectProductField(String FieldType){
		Select selType = new Select(Ele_product);
		selType.selectByVisibleText(FieldType);
	}
	
	@Step("Input Product ID :  \"{0}\" ")
	public void productIdField(String productId){
		Ele_ProductId.sendKeys(productId);
	}
	
	@Step("Input Member Number Field :  \"{0}\" ")
	public void memberNumberField(String MemNum){
		Ele_MemberNumber.sendKeys(MemNum);
	}
	
	@Step("Clicked on Back button")
	public void clickBackBtn(){
		Back_Btn.click();
	}
	
	@Step("Click Continue Button on Product Page")
	public void clickContinueButton(){
		ContinueButton.click();
	}
	
}

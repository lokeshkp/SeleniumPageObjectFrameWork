package com.equifax.cms.fusion.test.FFFPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

public class FFFStatsView
{
    Long noOfAvroFiles = (long) 0;
    WebDriver driver;

    public FFFStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//*[contains(text(),'COUNTERS')]")
    WebElement counters;

    @FindBy(xpath = ".//*[@id='countersDialog']/div")
    /* @FindBy(xpath="//*[@class='cmsContent']/pre") */
    WebElement getCountersContent;

    @FindBy(xpath = ".//*[@id='countersDialog']/div")
    WebElement getJetJobContent;

    @FindBy(xpath = ".//*[contains(text(),'JET_JOB_XML')]")
    WebElement jetJobXML;

    // for closing the stats popup
    @FindBy(xpath = "//a[contains(text(),'Close')]")
    WebElement CloseBtnOnStats;

    @Attachment(value = "{method}", type = "text/plain")
    public String getCountersContent()
    {
        return getCountersContent.getText();
    }

    @Step("Clicked close button on Stats")
    public void clickCloseButtonStats1()
    {
        CloseBtnOnStats.click();
    }

    @Step("{method}")
    public void clickJetJobXml()
    {
        jetJobXML.click();
    }

    @Step("{method}")
    public void closePopUp() throws InterruptedException
    {
        Actions action = new Actions(driver);
        action.sendKeys(Keys.ESCAPE).build().perform();
        Thread.sleep(1000);
    }

    @Step("{method}")
    public void clickCounters()
    {
        counters.click();
    }

    @Step("{method}")
    public String getInputTableName()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Input table name')]/following-sibling::div")).getText();
    }

    @Step("{method}")
    public Long getInputTableCount()
    {
        return Long.parseLong(driver.findElement(By.xpath(".//*[contains(text(),'Input table record count')]/following-sibling::div")).getText());
    }

    @Step("{method}")
    public String getHeaderTableName()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'Header table name')]/following-sibling::div")).getText();
    }

    @Step("{method}")
    public Long getHeaderTableCount()
    {
        return Long.parseLong(driver.findElement(By.xpath(".//*[contains(text(),'Header table record count')]/following-sibling::div")).getText());
    }

    @Step("{method}")
    public Long getNoOfAVROFilesUI()
    {
        noOfAvroFiles = Long.parseLong(driver.findElement(By.xpath(".//*[contains(text(),'# of AVRO files')]/following-sibling::div")).getText());
        return noOfAvroFiles;
    }

    @Step("{method}")
    public Long getCountOfFFFRecordsUI()
    {
        return Long.parseLong(driver.findElement(By.xpath(".//*[contains(text(),'The count of FFF records')]/following-sibling::div")).getText());
    }

    @Step("{method}")
    public Long getSumofCountofAVROCreditFiles()
    {
        long sum = 0;
        noOfAvroFiles = Long.parseLong(driver.findElement(By.xpath(".//*[contains(text(),'# of AVRO files')]/following-sibling::div")).getText());
        for (int i = 1; i <= noOfAvroFiles; i++)
        {
            Long avro = Long.parseLong(driver.findElement(By.xpath("(.//*[contains(text(),'AvroCredit')])[" + i + "]/following-sibling::div"))
                    .getText());
            sum = avro + sum;
        }
        return sum;
    }

    // added to get the job directory path for jet of FFF process
    @Step("{method}")
    public String getJobDirectoryPathForJetForFFF()
    {
        String jobDirectoryPath = driver.findElement(By.xpath("//div[contains(text(),'Job Directory')]//following::div[1]")).getText();
        return jobDirectoryPath;
    }

    // added to get the output file path for FFF process for FFF_CONVERTAVRO work item.
    @Step("{method}")
    public String getOutputFilePathForFFF_CONVERTAVRO()
    {
        String FullOutPutFilePath = driver.findElement(By.xpath("//div[contains(text(),'The path of the FFF file')]//following::div[1]")).getText();

        return FullOutPutFilePath;
    }

    @Step("{method}")
    public String getOutputFilePathForFFF_GPEXPORT()
    {
        String FullOutPutFilePath = driver.findElement(By.xpath("//div[contains(text(),'Output file path')]//following::div[1]")).getText();

        return FullOutPutFilePath;
    }

    // added to chck whether counters files are formed in the jet job directory path or not
    @Step("Validates that COUNTERS file is generated as output of JET workitem")
    public boolean checkCounterFileFormedOrNot(String path)
    {

        File f = null;
        File[] fileList;
        boolean isCountersFileFormed = false;
        try
        {
            // create new file
            /*
             * String path1="c:"+path+"/jobrun1"; String str1 = path1.replace("\\", "/");
             */
            String updatedPath = path + "/jobrun1";
            f = new File(updatedPath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        if (file.getName().endsWith(".counters"))
                        {
                            isCountersFileFormed = true;
                        }

                    }

                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }

        return isCountersFileFormed;
    }

    // added to chck whether avro files are formed in the jet job directory path or not
    @Step("Validates that AVRO files are formed in JET JOB directory")
    public boolean listAvroFiles(String path)
    {

        File f = null;
        File[] fileList;
        boolean isAvroFilesFormedInTheDirectory = false;
        try
        {
            // create new file
            /*
             * String path1="c:"+path+"/jobrun1"+"/avro"; String str1 = path1.replace("\\", "/");
             */
            String updatedPath = path + "/jobrun1" + "/avro";
            f = new File(updatedPath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        if (file.getName().endsWith(".avro"))
                        {
                            isAvroFilesFormedInTheDirectory = true;
                        }

                    }

                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }

        return isAvroFilesFormedInTheDirectory;
    }

    // --to check output file name fetched from the directory matches with file name in stats in that taking the file path and reading the stats for
    // ConvertAvro workitem of FFF

    @Step("Validates that Output FFF file and the necessary stats  should be created in the ConvertAvro folder in the workspace directory")
    public boolean readOutputFileForFFF(String path)
    {

        ArrayList<String> outputFile = new ArrayList<String>();
        File f = null;
        File[] fileList;
        boolean isOutputFFFFileFormed = false;

        // get the file name fetched from the stats
        String opFileName = FilenameUtils.getBaseName(path) + "." + FilenameUtils.getExtension(path);

        try
        {
            // create new file
            String outputFilePath = FilenameUtils.getPath(path);
            String updatedOPFilePath = "/" + outputFilePath;
            if (updatedOPFilePath.endsWith("/"))
            {
                updatedOPFilePath = updatedOPFilePath.substring(0, updatedOPFilePath.length() - 1);
            }
            /*
             * String path1="c:"+new1; String str1 = path1.replace("\\", "/");
             */
            f = new File(updatedOPFilePath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        outputFile.add(file.toString());
                        if (outputFile != null && outputFile.size() > 0)
                        {
                            for (String fetchedName : outputFile)
                            {
                                if (fetchedName.endsWith(opFileName))
                                {
                                    isOutputFFFFileFormed = true;
                                    break;
                                }
                            }
                        }
                    }

                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return isOutputFFFFileFormed;

    }

    // added--to check output file name fetched from the diorectory matches with file name in stats in dat taking the file path and reding the stats
    // for ConvertAvro workitem of FFF
    public List<String> checkNecessaryStatsForOutputFileOfConvertAvroWrkItemOfFF(String path)
    {

        File f = null;
        File[] fileList;

        List<String> newList = new ArrayList<String>();

        try
        {
            // create new file

            String outputFilePath = FilenameUtils.getPath(path);
            String updatedFilePath = "/" + outputFilePath;
            if (updatedFilePath.endsWith("/"))
            {
                updatedFilePath = updatedFilePath.substring(0, updatedFilePath.length() - 1);
            }
            /*
             * String path1="c:"+new1; String str1 = path1.replace("\\", "/");
             */
            f = new File(updatedFilePath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        if (file.getName().equalsIgnoreCase("output.stat"))
                        {
                            try (BufferedReader br = new BufferedReader(new FileReader(file)))
                            {

                                String sCurrentLine;

                                while ((sCurrentLine = br.readLine()) != null)
                                {
                                    System.out.println(sCurrentLine);
                                    if (sCurrentLine.contains("TOTAL INPUT RECORDS"))
                                    {
                                        newList.add(sCurrentLine);
                                    } else if (sCurrentLine.contains("TOTAL FFF SEGMENT RECORDS CREATED"))
                                    {
                                        newList.add(sCurrentLine);
                                    }
                                }

                            } catch (IOException e)
                            {
                                e.printStackTrace();
                            }

                        }

                    }

                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return newList;

    }

    public Integer readAndCompareTheDataOfFileWithGreenPlumData(String path, HashMap<String, String> columnsData)
    {
        File f = null;
        int countOfRecordsMatched = 0;
        try
        {
            f = new File(path);
            if (f.exists() && !f.isDirectory())
            {
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {
                    String sCurrentLine;

                    while ((sCurrentLine = br.readLine()) != null)
                    {
                        String[] currentLineArr = sCurrentLine.split("\\|");
                        for (Map.Entry<String, String> entry : columnsData.entrySet())
                        {
                            if (currentLineArr[0].equalsIgnoreCase(entry.getKey()) && currentLineArr[1].equalsIgnoreCase(entry.getValue()) || currentLineArr[0].equalsIgnoreCase(entry.getValue()) && currentLineArr[1].equalsIgnoreCase(entry.getKey()))
                            {
                                countOfRecordsMatched++;
                            }
                        }

                    }
                } catch (IOException e)
                {
                    e.printStackTrace();
                }

            } else
            {

                System.out.println("file not found !!!!");

            }
        }

        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return countOfRecordsMatched;

    }

    @Step("Clicked the FFF Process FFF_GPEXPORT work item stats")
    public void clickFFF_GPEXPORTstats(String jobId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//td[contains(text(),'" + jobId
                        + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'FFF_GPEXPORT')]//following::td[5]/a")).click();
    }

    @Step("Clicked the FFF Process FFF_JET work item stats")
    public void clickFFF_JETstats(String jobId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'FFF_JET')]//following::td[5]/a"))
                .click();
    }

    @Step("Clicked the FFF Process FFF_CONVERTAVRO work item stats")
    public void clickFFF_CONVERTAVROstats(String jobId) throws InterruptedException
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr/td[2]/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//td[contains(text(),'" + jobId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
        Thread.sleep(2000);
        driver.findElement(
                By.xpath("//td[contains(text(),'" + jobId
                        + "')]//parent::tr[1]//following::tr[4]/td[contains(text(),'FFF_CONVERTAVRO')]//following::td[5]/a")).click();
    }

    /*
     * @Step("Clicked the Stack Process For Getting The Status Of The First Process First WorkItem") public String
     * getStatusOfFirstProcessInStack(String jobId) throws InterruptedException{
     * driver.findElement(By.xpath("//td[contains(text(),'"+jobId+"')]//parent::tr/td[2]/img")).click(); Thread.sleep(2000);
     * driver.findElement(By.xpath("//td[contains(text(),'"+jobId+"')]//parent::tr[1]//following::tr[1]/td[3]/img")).click(); Thread.sleep(2000);
     * //for getting the state of the process first work item String
     * first_process_name=driver.findElement(By.xpath("//td[contains(text(),'ST04')]//parent::tr[1]//following::tr[1]/td[3]/div[1]")).getText();
     * String second_process_name=driver.findElement(By.xpath("//td[contains(text(),'ST04')]//parent::tr[1]//following::tr[2]/td[3]/div")).getText();
     * return first_process_name; }
     */
    /*
     * @Step("Clicked the Stack Process For Getting The Status Of The Second Process First WorkItem") public String
     * getStatusOfSecondProcessInStack(String jobId) throws InterruptedException{
     * driver.findElement(By.xpath("//td[contains(text(),'"+jobId+"')]//parent::tr/td[2]/img")).click(); Thread.sleep(2000);
     * driver.findElement(By.xpath("//td[contains(text(),'"+jobId+"')]//parent::tr[1]//following::tr[3]/td[3]/img")).click(); Thread.sleep(2000);
     * //for getting the state of the process first work item String
     * second_process_name=driver.findElement(By.xpath("//td[contains(text(),'ST04')]//parent::tr[1]//following::tr[2]/td[3]/div")).getText(); return
     * second_process_name; }
     */
    public String findText()
    {
        String link = null;
        /* WebElement rxBtn = driver.findElement(By.xpath(".//*[contains(text(),'COUNTERS')]")); */
        if (isElementPresent(By.xpath(".//*[contains(text(),'COUNTERS')]")))
        {
            link = "COUNTERS";

        } else
        {
            link = "notPresent";
        }
        /* return rxBtn; */
        return link;
    }

    private boolean isElementPresent(By by)
    {

        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }

    }

    @Step("click the view hyperlink for viewing jobstats of process in dashboard cntroller")
    public void clickViewStatsForJobLevel(String assignedId)
    {

        driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr/td[8]/a")).click();

    }

    public void clickToViewWorkItems(String assignedId)
    {
        driver.findElement(By.xpath("//td[contains(text(),'" + assignedId + "')]//parent::tr/td[2]/img")).click();

    }

    @Step("check whether the process are executed together in Dashboard Controller Screen If submitted via Stack")
    public boolean isProcessPresent(String completeStackName,List<String> assignedIdList)
    {
        boolean isProcessPresent = false;
        if (CollectionUtils.isNotEmpty(assignedIdList))
        {
            for (String assignedId : assignedIdList)
            {
                isProcessPresent = driver.findElement(By.xpath("//span[contains(text(),'"+completeStackName+"')]/parent::td/parent::tr/following::tr//span[contains(text(),'"+assignedId+"')]")).isDisplayed();
            }
        }
        return isProcessPresent;
    }
    @Step("Fetching the Record Type Distribution From the Stats")
    public List<String> fetchTheRecordTypeDistributionFromTheStats()
    {
        List<String> fetchedRecordDistribution=new ArrayList<String>();
        List<WebElement> elements = driver.findElements(By.xpath("//*[@id='css3table'][1]//div[contains(text(),'Record Type Distribution')]/parent::div/following-sibling::div/div[1]"));
        for(int i = 0; i < elements.size(); ++i)
        {
           // String fetchedRecord = elements.get(i).findElement(By.xpath("./div[1]")).getText();
        	 String fetchedRecord = elements.get(i).getText();
            String[] fetchedRecordArr=fetchedRecord.split(":");
if(!fetchedRecordArr[0].isEmpty()){
            String record=fetchedRecordArr[0].replaceAll("\\s+","");
           
            fetchedRecordDistribution.add(record);
}
           
        }
        return fetchedRecordDistribution;



    }
    @Step("Fetching The Count Of Records Selected For Processing")
    public String fetchTheCountOfRecordProcessed()
    {

        String countOfRecords = driver.findElement(By.xpath("//div[contains(text(),'Input Records Selected For Processing')]/following::div[1]")).getText();

        return countOfRecords;

    }

    //div[starts-with(text(),'Input records selected for processing')]/following::div[1]
    public String getAssignedIdForStack()
    {
        String fullProcessName = driver.findElement(By.xpath("//label[@class='fieldTitle']")).getText();
        String[] nameArr = fullProcessName.split(":");
        return nameArr[1].trim();
    }

    public boolean isSorted(List<String> list)
    {
        boolean sorted = true;        
        for (int i = 1; i < list.size(); i++) {
            if (list.get(i-1).compareTo(list.get(i)) > 0) sorted = false;
        }

        return sorted;
    }
}

package com.equifax.cms.fusion.test.IPPages;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DefineLayoutPage
{

    WebDriver driver;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    public DefineLayoutPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "layoutName")
    public WebElement Ele_LayoutName;

    @FindBy(xpath = "//input[@onclick='addInputFieldForConst()']")
    WebElement AddBtn;

    @FindBy(id = "constValue0")
    WebElement ConstValue;

    @FindBy(id = "cleanse1")
    WebElement TransInvCharBlanks_ChckBox;

    @FindBy(id = "headerLines")
    WebElement HeaderRows_drpDwn;

    @FindBy(xpath = "//input[@value='Continue Anyway']")
    WebElement ContinueOnAlert;

    @FindBy(id = "save")
    WebElement Save_Btn;

    @FindBy(xpath = ".//*[@id='submitButton']")
    WebElement ContinueButton;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @FindBy(xpath = ".//*[@id='fieldTable']/tbody/tr[1]/td[1]/select")
    WebElement FirstFieldType_DD;

    @FindBy(xpath = ".//*[@id='start0']")
    WebElement firstStartPosition;

    @FindBy(xpath = ".//*[@id='end0']")
    WebElement firstEndPosition;

    @FindBy(xpath = ".//*[@id='clickSelect']")
    WebElement selectPosition;

    @FindBy(xpath = ".//*[@id='apply']")
    WebElement generateFieldsButton;

    @FindBy(xpath = "//*[@id='previewDelimitedFiles']")
    WebElement previewDelimitedFilesTable;

    @FindBy(xpath = ".//*[@id='preview']")
    WebElement previewButton;

    @FindBy(xpath = ".//*[@id='GenPDF']")
    WebElement generatePDFButton;

    @FindBy(xpath = ".//*[@id='addField']")
    WebElement addFieldBtn;

    @FindBy(id = "addConstantField")
    WebElement AddColumn_Btn;

    @FindBy(id = "clear")
    WebElement ClearBtn;

    @FindBy(id = "preview")
    WebElement PreviewBtn;

    @FindBy(id = "btnClose")
    public WebElement PreviewCloseBtn;

    @Step("Clicked clear button")
    public void clickClearBtn()
    {
        ClearBtn.click();
    }

    @Step("cleared the fields in the grid")
    public String fldsClear()
    {
        clickClearBtn();
        String msg = driver.findElement(By.xpath("//span[contains(text(),'No data to display')]")).getText();
        return msg;
    }

    @Step("Verify preview title")
    public String previewTitle()
    {
        PreviewBtn.click();
        driver.findElement(By.id("gapFoundAccept")).click();
        String previewHdr = driver.findElement(By.xpath("//div[contains(text(),'Preview')]")).getText();
        return previewHdr;
    }

    @Step("Table in preview window")
    public boolean dataInPreview()
    {
        WebElement table = driver.findElement(By.xpath("//table[@class='dataTable']"));
        if (table.isDisplayed())
        {
            return true;
        } else
        {
            return false;
        }
    }

    public void inputLayoutNameField(String layout)
    {
        Ele_LayoutName.clear();
        Ele_LayoutName.sendKeys(layout);
    }

    @Step("Click Add button for the Constant field")
    public void constantField(String addConst, String constField, String constValue)
    {
        String constants[] = constField.split(",");
        String constantValue[] = constValue.split(",");
        if ("ADD".equalsIgnoreCase(addConst))
        {
            for (int k = 0; k < constants.length; k++)
            {
                AddColumn_Btn.click();
            }

            JavascriptExecutor js = (JavascriptExecutor) driver;
            int i = 0;
            int j = 0;
            boolean flagForConstantName = false;
            ArrayList rows = (ArrayList) js.executeScript("return $('#constant_grid').jqxGrid('getrows')"); // 3
            Actions action = new Actions(driver);
            while (i < rows.size())
            {

                if (!flagForConstantName)
                {
                    int l = 0;
                    while (l < constants.length)
                    {
                        js.executeScript("$('#constant_grid').jqxGrid('setcellvalue','" + l + "', 'constant_" + l + "', '" + constants[l] + "')");
                        WebElement ele1 = driver.findElement(By.xpath("//div[contains(text(),'EBCDIC')]"));
                        action.doubleClick(ele1).perform();
                        l++;
                    }

                    // js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + i + "', 'constant_" + j + 1 + "', '"
                    // + constants[i + 1] + "')");
                    flagForConstantName = true;

                } else
                {
                    int l = 0;
                    while (l < constants.length)
                    {
                        {
                            js.executeScript("$('#constant_grid').jqxGrid('setcellvalue','" + i + "', 'constant_" + l + "', '" + constantValue[l]
                                    + "')");
                            WebElement ele2 = driver.findElement(By.xpath("//div[contains(text(),'File Name')]"));
                            action.doubleClick(ele2).perform();
                            l++;
                            ele2.click();
                        }

                    }

                }
                i++;

            }
            // clickContinueButton();
            // String alertMsg = driver.switchTo().alert().getText();
            // if(alertMsg.equalsIgnoreCase("Error: Layout Base_Fixed is
            // currently used with existing process. Please rename and save it
            // again.")){
            // driver.switchTo().alert().accept();
            // Ele_LayoutName.clear();
            // Date date = new Date();
            // Ele_LayoutName.sendKeys(dateFormat.format(date));
            // } else if("NA".equalsIgnoreCase(addConst)){
            // System.out.println("Not required to add the constant field..Move
            // to next screen !!!");
            // }
        }
    }

    @Step("Provided a value in the User Defined Name of Contant field = \"{0}\"")
    public void inputContUserDefName(String name)
    {
        driver.findElement(By.xpath(".//*[@id='constName0']")).clear();
        driver.findElement(By.xpath(".//*[@id='constName0']")).sendKeys(name);
    }

    @Step("Select the Translate Invalid Characters to Blanks = \"{0}\"")
    public void selectInvalidCharBlanks(String invCharBlanks)
    {
        if ("CHECK".equalsIgnoreCase(invCharBlanks))
        {
            TransInvCharBlanks_ChckBox.click();
        }
    }

    @Step("Provided constant field value = \"{0}\"")
    public void provideConstValue(String constValue)
    {
        ConstValue.sendKeys(constValue);
    }

    @Step("Selected the Header Rows = \"{0}\"")
    public void selHeaderRows(String hdrRow)
    {
        Select sel = new Select(HeaderRows_drpDwn);
        sel.selectByVisibleText(hdrRow);
    }

    @Step("Clicked continue anyway on Alert")
    public void clickContinueOnAlert()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            if (ContinueOnAlert.isDisplayed())
            {
                ContinueOnAlert.click();
                driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            }
        } catch (org.openqa.selenium.NoSuchElementException e)
        {

        }
    }

    @Step("Clicked on Save button")
    public void clickSaveBtn()
    {
        Save_Btn.click();
    }

    @Step("Click Continue Button on Define Layout Page")
    public void clickContinueButton() throws InterruptedException
    {
        // String dataTypesPerField = "Number,Number,Number";
        // selDataType(dataTypesPerField);
        ContinueButton.click();
        /*
         * Thread.sleep(2000); try { driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
         * driver.findElement(By.id("gapFoundAccept")).click(); driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS); }catch(Exception e)
         * { }
         */
    }

    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        BackBtn.click();
    }

    @Step("Select a field for fixed format for first field")
    public void selectFieldFixed(String fieldName, String fieldType)
    {
        new Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[1]/td[1]/select"))).selectByVisibleText("Customize...");
        if (!driver.findElement(By.id(fieldName)).isSelected())
        {
            driver.findElement(By.id(fieldName)).click();
        }
        driver.findElement(By.xpath("(.//*[contains(text(),'Save')])[2]")).click();
        new Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[1]/td[1]/select"))).selectByVisibleText(fieldType);
    }

    public void selectAllFields()
    {
        new Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[1]/td[1]/select"))).selectByVisibleText("Customize...");
        if (!driver.findElement(By.id("SUFFIX")).isSelected())
        {
            driver.findElement(By.id("SUFFIX")).click();
        }
        if (!driver.findElement(By.id("STREET_NAME")).isSelected())
        {
            driver.findElement(By.id("STREET_NAME")).click();
        }
        if (!driver.findElement(By.id("BIRTH_YEAR")).isSelected())
        {
            driver.findElement(By.id("BIRTH_YEAR")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_5th")).click();
        }
        if (!driver.findElement(By.id("INQUIRY_TYPE")).isSelected())
        {
            driver.findElement(By.id("INQUIRY_TYPE")).click();
        }
        if (!driver.findElement(By.id("NAME_FREE_FORM_LSFM")).isSelected())
        {
            driver.findElement(By.id("NAME_FREE_FORM_LSFM")).click();
        }
        if (!driver.findElement(By.id("STREET_TYPE")).isSelected())
        {
            driver.findElement(By.id("STREET_TYPE")).click();
        }
        if (!driver.findElement(By.id("AGE")).isSelected())
        {
            driver.findElement(By.id("AGE")).click();
        }
        if (!driver.findElement(By.id("BIRTH_CENTURY")).isSelected())
        {
            driver.findElement(By.id("BIRTH_CENTURY")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_DAY")).isSelected())
        {
            driver.findElement(By.id("DATE_DAY")).click();
        }
        if (!driver.findElement(By.id("PROJECT_NUMBER")).isSelected())
        {
            driver.findElement(By.id("PROJECT_NUMBER")).click();
        }
        if (!driver.findElement(By.id("STREET_POST_DIRECTION")).isSelected())
        {
            driver.findElement(By.id("STREET_POST_DIRECTION")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_MONTH")).isSelected())
        {
            driver.findElement(By.id("DATE_MONTH")).click();
        }
        if (!driver.findElement(By.id("CID")).isSelected())
        {
            driver.findElement(By.id("CID")).click();
        }
        if (!driver.findElement(By.id("MIDDLE_NAME")).isSelected())
        {
            driver.findElement(By.id("MIDDLE_NAME")).click();
        }
        if (!driver.findElement(By.id("STREET_NUMBER")).isSelected())
        {
            driver.findElement(By.id("STREET_NUMBER")).click();
        }
        if (!driver.findElement(By.id("CSZ_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CSZ_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP_WPLUS_4")).isSelected())
        {
            driver.findElement(By.id("ZIP_WPLUS_4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_5th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_YEAR")).isSelected())
        {
            driver.findElement(By.id("DATE_YEAR")).click();
        }
        if (!driver.findElement(By.id("CONNEXUS_KEY")).isSelected())
        {
            driver.findElement(By.id("CONNEXUS_KEY")).click();
        }
        if (!driver.findElement(By.id("STREET_PRE_Direction")).isSelected())
        {
            driver.findElement(By.id("STREET_PRE_Direction")).click();
        }
        if (!driver.findElement(By.id("CITY_STATE_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CITY_STATE_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP4")).isSelected())
        {
            driver.findElement(By.id("ZIP4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_DAY_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_DAY_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_5th")).click();
        }
        if (!driver.findElement(By.id("MEMBER_NUMBER")).isSelected())
        {
            driver.findElement(By.id("MEMBER_NUMBER")).click();
        }
        if (!driver.findElement(By.id("DATE_CENTURY")).isSelected())
        {
            driver.findElement(By.id("DATE_CENTURY")).click();
        }
        if (!driver.findElement(By.id("DOB_SIGNED")).isSelected())
        {
            driver.findElement(By.id("DOB_SIGNED")).click();
        }
        if (!driver.findElement(By.id("MLA_TRANSACTION_ID")).isSelected())
        {
            driver.findElement(By.id("MLA_TRANSACTION_ID")).click();
        }
        driver.findElement(By.xpath("(.//*[contains(text(),'Save')])[2]")).click();
    }

    public void selectAllFields_Delim()
    {

        new Select(driver.findElement(By.xpath(".//*[@id='fieldType1']"))).selectByVisibleText("Customize...");

        if (!driver.findElement(By.id("SUFFIX")).isSelected())
        {
            driver.findElement(By.id("SUFFIX")).click();
        }
        if (!driver.findElement(By.id("STREET_NAME")).isSelected())
        {
            driver.findElement(By.id("STREET_NAME")).click();
        }
        if (!driver.findElement(By.id("BIRTH_YEAR")).isSelected())
        {
            driver.findElement(By.id("BIRTH_YEAR")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_5th")).click();
        }
        if (!driver.findElement(By.id("INQUIRY_TYPE")).isSelected())
        {
            driver.findElement(By.id("INQUIRY_TYPE")).click();
        }
        if (!driver.findElement(By.id("NAME_FREE_FORM_LSFM")).isSelected())
        {
            driver.findElement(By.id("NAME_FREE_FORM_LSFM")).click();
        }
        if (!driver.findElement(By.id("STREET_TYPE")).isSelected())
        {
            driver.findElement(By.id("STREET_TYPE")).click();
        }
        if (!driver.findElement(By.id("AGE")).isSelected())
        {
            driver.findElement(By.id("AGE")).click();
        }
        if (!driver.findElement(By.id("BIRTH_CENTURY")).isSelected())
        {
            driver.findElement(By.id("BIRTH_CENTURY")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_DAY")).isSelected())
        {
            driver.findElement(By.id("DATE_DAY")).click();
        }
        if (!driver.findElement(By.id("PROJECT_NUMBER")).isSelected())
        {
            driver.findElement(By.id("PROJECT_NUMBER")).click();
        }
        if (!driver.findElement(By.id("STREET_POST_DIRECTION")).isSelected())
        {
            driver.findElement(By.id("STREET_POST_DIRECTION")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_MONTH")).isSelected())
        {
            driver.findElement(By.id("DATE_MONTH")).click();
        }
        if (!driver.findElement(By.id("CID")).isSelected())
        {
            driver.findElement(By.id("CID")).click();
        }
        if (!driver.findElement(By.id("MIDDLE_NAME")).isSelected())
        {
            driver.findElement(By.id("MIDDLE_NAME")).click();
        }
        if (!driver.findElement(By.id("STREET_NUMBER")).isSelected())
        {
            driver.findElement(By.id("STREET_NUMBER")).click();
        }
        if (!driver.findElement(By.id("CSZ_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CSZ_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP_WPLUS_4")).isSelected())
        {
            driver.findElement(By.id("ZIP_WPLUS_4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_5th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_YEAR")).isSelected())
        {
            driver.findElement(By.id("DATE_YEAR")).click();
        }
        if (!driver.findElement(By.id("CONNEXUS_KEY")).isSelected())
        {
            driver.findElement(By.id("CONNEXUS_KEY")).click();
        }
        if (!driver.findElement(By.id("STREET_PRE_Direction")).isSelected())
        {
            driver.findElement(By.id("STREET_PRE_Direction")).click();
        }
        if (!driver.findElement(By.id("CITY_STATE_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CITY_STATE_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP4")).isSelected())
        {
            driver.findElement(By.id("ZIP4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_DAY_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_DAY_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_5th")).click();
        }
        if (!driver.findElement(By.id("MEMBER_NUMBER")).isSelected())
        {
            driver.findElement(By.id("MEMBER_NUMBER")).click();
        }
        if (!driver.findElement(By.id("DATE_CENTURY")).isSelected())
        {
            driver.findElement(By.id("DATE_CENTURY")).click();
        }
        if (!driver.findElement(By.id("DOB_SIGNED")).isSelected())
        {
            driver.findElement(By.id("DOB_SIGNED")).click();
        }
        if (!driver.findElement(By.id("MLA_TRANSACTION_ID")).isSelected())
        {
            driver.findElement(By.id("MLA_TRANSACTION_ID")).click();
        }
        driver.findElement(By.xpath("(.//*[contains(text(),'Save')])[2]")).click();
    }

    public void selectAllFields_FixedOrDelimByColumnNo(int colNo)
    {

        new Select(driver.findElement(By.xpath("//*[@id='fieldType" + colNo + "']"))).selectByVisibleText("Customize...");

        if (!driver.findElement(By.id("SUFFIX")).isSelected())
        {
            driver.findElement(By.id("SUFFIX")).click();
        }
        if (!driver.findElement(By.id("STREET_NAME")).isSelected())
        {
            driver.findElement(By.id("STREET_NAME")).click();
        }
        if (!driver.findElement(By.id("BIRTH_YEAR")).isSelected())
        {
            driver.findElement(By.id("BIRTH_YEAR")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_5th")).click();
        }
        if (!driver.findElement(By.id("INQUIRY_TYPE")).isSelected())
        {
            driver.findElement(By.id("INQUIRY_TYPE")).click();
        }
        if (!driver.findElement(By.id("NAME_FREE_FORM_LSFM")).isSelected())
        {
            driver.findElement(By.id("NAME_FREE_FORM_LSFM")).click();
        }
        if (!driver.findElement(By.id("STREET_TYPE")).isSelected())
        {
            driver.findElement(By.id("STREET_TYPE")).click();
        }
        if (!driver.findElement(By.id("AGE")).isSelected())
        {
            driver.findElement(By.id("AGE")).click();
        }
        if (!driver.findElement(By.id("BIRTH_CENTURY")).isSelected())
        {
            driver.findElement(By.id("BIRTH_CENTURY")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_DAY")).isSelected())
        {
            driver.findElement(By.id("DATE_DAY")).click();
        }
        if (!driver.findElement(By.id("PROJECT_NUMBER")).isSelected())
        {
            driver.findElement(By.id("PROJECT_NUMBER")).click();
        }
        if (!driver.findElement(By.id("STREET_POST_DIRECTION")).isSelected())
        {
            driver.findElement(By.id("STREET_POST_DIRECTION")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("SCORE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_MONTH")).isSelected())
        {
            driver.findElement(By.id("DATE_MONTH")).click();
        }
        if (!driver.findElement(By.id("CID")).isSelected())
        {
            driver.findElement(By.id("CID")).click();
        }
        if (!driver.findElement(By.id("MIDDLE_NAME")).isSelected())
        {
            driver.findElement(By.id("MIDDLE_NAME")).click();
        }
        if (!driver.findElement(By.id("STREET_NUMBER")).isSelected())
        {
            driver.findElement(By.id("STREET_NUMBER")).click();
        }
        if (!driver.findElement(By.id("CSZ_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CSZ_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP_WPLUS_4")).isSelected())
        {
            driver.findElement(By.id("ZIP_WPLUS_4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_1_5th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_YEAR")).isSelected())
        {
            driver.findElement(By.id("DATE_YEAR")).click();
        }
        if (!driver.findElement(By.id("CONNEXUS_KEY")).isSelected())
        {
            driver.findElement(By.id("CONNEXUS_KEY")).click();
        }
        if (!driver.findElement(By.id("STREET_PRE_Direction")).isSelected())
        {
            driver.findElement(By.id("STREET_PRE_Direction")).click();
        }
        if (!driver.findElement(By.id("CITY_STATE_FREEFORM")).isSelected())
        {
            driver.findElement(By.id("CITY_STATE_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP4")).isSelected())
        {
            driver.findElement(By.id("ZIP4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_DAY_MONTH")).isSelected())
        {
            driver.findElement(By.id("BIRTH_DAY_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).isSelected())
        {
            driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_ZIP_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_3rd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_STATE_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_4th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_CITY_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_5th")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_LINE_2_5th")).click();
        }
        if (!driver.findElement(By.id("MEMBER_NUMBER")).isSelected())
        {
            driver.findElement(By.id("MEMBER_NUMBER")).click();
        }
        if (!driver.findElement(By.id("DATE_CENTURY")).isSelected())
        {
            driver.findElement(By.id("DATE_CENTURY")).click();
        }
        if (!driver.findElement(By.id("DOB_SIGNED")).isSelected())
        {
            driver.findElement(By.id("DOB_SIGNED")).click();
        }
        if (!driver.findElement(By.id("MLA_TRANSACTION_ID")).isSelected())
        {
            driver.findElement(By.id("MLA_TRANSACTION_ID")).click();
        }
        driver.findElement(By.xpath("(.//*[contains(text(),'Save')])[2]")).click();
    }

    public void selectFieldType(String fieldLayout)
    {
        StringTokenizer stMain = new StringTokenizer(fieldLayout, ",");
        int i = 1;
        while (stMain.hasMoreElements())
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[" + i + "]/td[1]/select"))).selectByVisibleText(stMain
                    .nextToken());
            i++;
        }

    }

    public void selectFieldType_Delim(String fieldLayout)
    {
        StringTokenizer stMain = new StringTokenizer(fieldLayout, ",");
        int i = 1;
        while (stMain.hasMoreElements())
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldType" + i + "']"))).selectByVisibleText(stMain.nextToken());
            i++;
        }
    }

    public void selectFieldTypeFromFieldLayout(String fieldLayout)
    {
        String[] fieldLayoutSplit = fieldLayout.split(",");
        int i = 1;
        selectAllFields_FixedOrDelimByColumnNo(i);
        for (int j = 0; j < fieldLayoutSplit.length; j++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[" + i + "]/td[1]/select")))
                    .selectByVisibleText(fieldLayoutSplit[j]);
            i++;
        }
    }

    public void selectFieldTypeFromFieldLayout_FixedOrDelim(String fieldLayout)
    {
        String[] fieldLayoutSplit = fieldLayout.split(",");
        int i = 1;
        selectAllFields_FixedOrDelimByColumnNo(i);
        for (int j = 0; j < fieldLayoutSplit.length; j++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldType" + i + "']"))).selectByVisibleText(fieldLayoutSplit[j]);
            i++;
        }
    }

    public void selectFieldTypesFromFieldLayoutMultipleRows(String fieldLayout)
    {
        String[] fieldLayoutSplit = fieldLayout.split(",");
        int i = 0;
        selectAllFields_FixedOrDelimByColumnNo(i);
        for (int j = 0; j < fieldLayoutSplit.length; j++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldType" + i + "']"))).selectByVisibleText(fieldLayoutSplit[j]);
            addFieldBtn.click();
            // after fieldType0, next id created is fieldType2
            if (i == 0)
            {
                i++;
            }
            i++;
        }
    }

    public void selectFieldTypeFromFieldLayout_FixedOrDelimByPos(String fieldLayout, int i)
    {
        String[] fieldLayoutSplit = fieldLayout.split(",");
        selectAllFields_FixedOrDelimByColumnNo(i);
        for (int j = 0; j < fieldLayoutSplit.length; j++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='fieldType" + i + "']"))).selectByVisibleText(fieldLayoutSplit[j]);
            i++;
        }
    }

    public void provideFieldName_FixedOrDelim(String fieldLayout, String[] values)
    {
        String[] fieldLayoutSplit = fieldLayout.split(",");
        int i = 1;
        for (int j = 0; j < fieldLayoutSplit.length; j++)
        {
            driver.findElement(By.xpath(".//*[@id='name" + i + "']")).clear();
            driver.findElement(By.xpath(".//*[@id='name" + i + "']")).sendKeys(values[j]);
            driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();
            i++;
        }
    }

    public void selectSequentialColStartPos(String startPos)
    {
        String[] startPosSplit = null;
        // String[] endPosSplit = null;
        if (null != startPos)
        {
            startPosSplit = startPos.split(":");
        }
        new Select(driver.findElement(By.xpath(".//*[@id='clickSelect']"))).selectByVisibleText("Start");

        for (int k = 0; k < startPosSplit.length; k++)
        {
            selectStartOrEndLine(startPosSplit[k]);
        }

    }

    public void selectSequentialColEndPos(String endPos)
    {
        String[] endPosSplit = null;
        // String[] endPosSplit = null;
        if (null != endPos)
        {
            endPosSplit = endPos.split(":");
        }
        new Select(driver.findElement(By.xpath(".//*[@id='clickSelect']"))).selectByVisibleText("End");

        for (int k = 0; k < endPosSplit.length; k++)
        {
            selectStartOrEndLine(endPosSplit[k]);
        }

    }

    public void selectSelectsPosAndSelectFromFbTable(String str, String startPos, String endPos)
    {
        String[] strSplit = str.split(",");
        String[] startPosSplit = null;
        String[] endPosSplit = null;

        if (null != startPos)
        {
            startPosSplit = startPos.split(",");
        }

        if (null != endPos)
        {
            endPosSplit = endPos.split(",");
        }

        for (int j = 0; j < strSplit.length; j++)
        {
            new Select(driver.findElement(By.xpath(".//*[@id='clickSelect']"))).selectByVisibleText(strSplit[j]);
            if (strSplit[j].equals("Start"))
            {
                for (int k = 0; k < startPosSplit.length; k++)
                {
                    selectStartOrEndLine(startPosSplit[k]);
                }
            }
            if (strSplit[j].equals("End"))
            {
                for (int k = 0; k < endPosSplit.length; k++)
                {
                    selectStartOrEndLine(endPosSplit[k]);
                }
            }
        }
    }

    @Step("Clicked on Click Selects Position button")
    public void selectSelectPosition(String position)
    {
        Select selpor = new Select(selectPosition);
        selpor.selectByVisibleText(position);
    }

    @Step("Selects position in fbLines table")
    public void selectStartOrEndLine(String position)
    {
        driver.findElement(By.xpath(".//*[@id='fbLines']/tbody/tr[1]/td[" + position + "]")).click();

    }

    @Step("Selects data type for ebcdic field")
    public void selectDataTypeForEbdcic(String position)
    {
        driver.findElement(By.xpath(".//*[@id='dataType" + position + "'])"));

    }

    @Step("Get classname for position in fbLines table")
    public String getClassNameForColumnInGrid(String position)
    {
        String className = driver.findElement(By.xpath("//*[@id='fbLines']/tbody/tr[1]/td[" + position + "]")).getAttribute("class");
        return className;
    }

    @Step("Clicked on Generate Fields button")
    public void clickGenerateFieldsBtn()
    {
        // generateFieldsButton.click();

        driver.findElement(By.xpath("//*[@id='layoutFieldsGrid']/div/div/div/div[2]/div/div/div")).click();
    }

    @Step("Get Start pos for First row")
    public String getStartPosFromGrid()
    {
        String value = driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']/div/div[4]/div")).getText();
        return value;
    }

    @Step("Get End pos for First row")
    public String getEndPosFromGrid()
    {
        String value = driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']/div/div[5]/div")).getText();
        return value;
    }

    @Step("Get value for start textbox")
    public String getValueStartPosTextBox(String idNo)
    {
        String value = driver.findElement(By.xpath("//*[@id='start" + idNo + "']")).getAttribute("value");
        return value;
    }

    @Step("Get value for end textbox")
    public String getValueEndPosTextBox(String idNo)
    {
        String value = driver.findElement(By.xpath("//*[@id='end" + idNo + "']")).getAttribute("value");
        return value;
    }

    @Step("Set value for start textbox")
    public void setValueStartPosTextBox(int idNo, String startPos)
    {
        driver.findElement(By.xpath("//*[@id='start" + idNo + "']")).sendKeys(startPos);
    }

    @Step("Set value for end textbox")
    public void setValueEndPosTextBox(int idNo, String endPos)
    {
        driver.findElement(By.xpath("//*[@id='end" + idNo + "']")).sendKeys(endPos);
    }

    @Step("Get value for length textbox")
    public String getValueLengthTextBox(String idNo)
    {
        String value = driver.findElement(By.xpath("//*[@id='len" + idNo + "']")).getAttribute("value");
        return value;
    }

    @Step("Get value for user defined name textbox")
    public String getValueUserDefinedNameTextBox(String idNo)
    {
        String value = driver.findElement(By.xpath("//*[@id='name" + idNo + "']")).getAttribute("value");
        return value;
    }

    // @Step("Get css value for property for preview delimited files table")
    // public String getCssValueForPreviewDelimTable(String propertyName)
    // {
    // String value = previewDelimitedFilesTable.getCssValue(propertyName);
    // return value;
    // }

    @Step("Get css value for property for preview delimited files table")
    public String checkScrollPresent()
    {
        String style = driver.findElement(By.xpath("//div[@id='horizontalScrollBarlayoutgrid']")).getAttribute("style");
        return style;
    }

    @Step("Get fieldType for a particular id")
    public WebElement getFieldTypeById(int idNo)
    {
        return driver.findElement(By.xpath("//*[@id='fieldType" + idNo + "']"));
    }

    @Step("Provide Start Position \"{0}\"")
    public void inputStartPosition0(String startPosition)
    {
        firstStartPosition.sendKeys(startPosition);
    }

    @Step("Provide End Position \"{0}\"")
    public void inputEndPosition0(String endPosition)
    {
        firstEndPosition.sendKeys(endPosition);
    }

    @Step("Clicked on Preview button")
    public void clickPreviewBtn()
    {
        previewButton.click();
    }

    @Step("Clicked on Close for Preview button")
    public void clickClosePreviewBtn()
    {
        // driver.findElement(By.xpath("html/body/div[5]/div[1]/button")).click();
        driver.findElement(By.xpath("//div[@id='previewFixedJqxWindowContent']/center/input")).click();

    }

    @Step("Clicked Generate Pdf button")
    public void clickGeneratePdfBtn()
    {
        generatePDFButton.click();
    }

    @Step("Check text in preview table")
    public String getTextFromHeadingPreview()
    {
        // return
        // driver.findElement(By.xpath(".//*[@id='testTable']/table/thead/tr/th")).getText();
        String str = driver.findElement(By.xpath("//div[@id='previewFixedJqxWindowContent']/table/thead/tr/th[66]")).getText();
        return str;
    }

    @Step("Check text in preview table")
    public String getTextFromHeadingPreview(int idNo)
    {
        return driver.findElement(By.xpath(".//*[@id='previewFixedJqxWindowContent']/table/thead/tr/th[" + idNo + "]")).getText();
    }

    @Step("Get text for row in preview table")
    public String getTextForRowPreview(int idNo)
    {
        return driver.findElement(By.xpath(".//*[@id='previewFixedJqxWindowContent']/table/tbody/tr[" + idNo + "]")).getText();
    }

    @Step("Get text for row in preview table")
    public String getTextForColumnsInRowsPreview(int rowNo, int colNo)
    {
        return driver.findElement(By.xpath(".//*[@id='previewFixedJqxWindowContent']/table/tbody/tr[" + rowNo + "]/td[" + colNo + "]")).getText();
    }

    @Step("Select datatype for ebcdic format")
    public void selectDatatypeEbcdicFixed(String dataType, String idNo)
    {
        new Select(driver.findElement(By.xpath(".//*[@id='dataType" + idNo + "']"))).selectByVisibleText(dataType);
    }

    public boolean isAlertPopUpVisible()
    {
        return driver
                .findElement(
                        By.xpath("//div[@id='jqxGapFound']/div/div[2][contains(text(),'The layout does not account for all bytes in the record. Data will be omitted.')]"))
                .isDisplayed();
    }

    public void clickContinueAnyway()
    {
        driver.findElement(By.xpath("//div[@id='jqxGapFound']/div/div[2]/div/input[1]")).click();
    }

    public boolean isLengthCorrectionPopUpVisible()
    {
        return driver.findElement(
                By.xpath("//div[@class='jqx-resize jqx-rc-all']/div[2][contains(text(),'The Length entered is incorrect according')]")).isDisplayed();
    }

    public void clickAutoCorrect()
    {
        driver.findElement(By.xpath("//div[@class='jqx-resize jqx-rc-all']/div[2]/div/input[1]")).click();
    }

    public String getErrorText()
    {
        return driver.findElement(By.xpath("//div[@class='errMsg']/span")).getText();
    }

    public List<String> getDataTypeDisplayedInGrid()
    {
        int i = 0;
        List<String> dataTypeList = new ArrayList<>();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        // get rows information
        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");

        while (i < rowsInfo.size())
        {
            String rowId = null;
            String row = rowsInfo.get(i).toString();
            rowId = getUid(row);
            String str = (String) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue', " + rowId + ", 'dataTypeDisplay');");
            dataTypeList.add(str);
            i++;
        }
        return dataTypeList;
    }

    public void updateFieldValuesPerField(String layoutFieldType, String name, String startPos, String endPos, String fieldLength)
    {
        String[] layoutFieldTypeTotal = layoutFieldType.split(";");
        String[] nameTotal = name.split(";");
        String[] startPosTotal = startPos.split(";");
        String[] endPosTotal = endPos.split(";");
        String[] fieldLengthTotal = fieldLength.split(";");

        int i = 0;
        JavascriptExecutor js = (JavascriptExecutor) driver;
        // get rows information
        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
        String[] fieldsSplit = null;
        String[] nameSplit = null;
        String[] startPosSplit = null;
        String[] endPosSplit = null;
        String[] fieldLengthSplit = null;
        while (i < rowsInfo.size())
        {
            if (!"NA".equalsIgnoreCase(layoutFieldType))
            {
                fieldsSplit = layoutFieldTypeTotal[i].split("\\.");
            }
            if (!"NA".equalsIgnoreCase(name))
            {
                nameSplit = nameTotal[i].split("\\.");
            }
            if (!"NA".equalsIgnoreCase(startPos))
            {
                startPosSplit = startPosTotal[i].split("\\.");
            }
            if (!"NA".equalsIgnoreCase(endPos))
            {
                endPosSplit = endPosTotal[i].split("\\.");
            }
            if (!"NA".equalsIgnoreCase(fieldLength))
            {
                fieldLengthSplit = fieldLengthTotal[i].split("\\.");
            }

            String rowId = null;
            String row = rowsInfo.get(i).toString();
            rowId = getUid(row);

            if (!"NA".equalsIgnoreCase(layoutFieldType))
            {
                String str = "$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + fieldsSplit[0] + "', '" + fieldsSplit[1]
                        + "');";
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + fieldsSplit[0] + "', '" + fieldsSplit[1]
                        + "')");
            }
            if (!"NA".equalsIgnoreCase(name))
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + nameSplit[0] + "', '" + nameSplit[1]
                        + "')");
            }
            if (!"NA".equalsIgnoreCase(startPos))
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + startPosSplit[0] + "', '"
                        + startPosSplit[1] + "')");

            }
            if (!"NA".equalsIgnoreCase(endPos))
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + endPosSplit[0] + "', '" + endPosSplit[1]
                        + "')");
            }
            if (!"NA".equalsIgnoreCase(fieldLength))
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', '" + fieldLengthSplit[0] + "', '"
                        + fieldLengthSplit[1] + "')");
            }

            i++;
        }

    }

    private String getUid(String row)
    {
        String uidVal;
        String[] strSplit = row.split(",");
        uidVal = strSplit[0].substring(strSplit[0].indexOf("uid") + 4).trim();
        System.out.println("uidVal" + uidVal + ":Rowinfo:" + row);
        return uidVal;
    }

    private String getVisibleIndex(String row)
    {
        String indexVal;
        String[] strSplit = row.split(",");
        indexVal = strSplit[0].substring(strSplit[14].indexOf("visibleindex") + 13).trim();
        return indexVal;
    }

    public void updateFieldsForDelimitedFormat(String fieldsInLayout) throws InterruptedException
    {
        String[] arr = fieldsInLayout.split(",");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String rowId = null;

        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#layoutgrid').jqxGrid('getrows')");

        String row = rowsInfo.get(0).toString();
        rowId = getUid(row);
        int count = 1;
        int j = 0;
        int i = 1;

        Pattern p = Pattern.compile("field");
        Matcher m = p.matcher(row);
        while (m.find())
        {
            count++;
        }

        while (j < arr.length && i < count)
        {
            String str = "$('#layoutgrid').jqxGrid('setcellvalue','" + rowId + "', 'field" + i + "', '" + arr[j] + "')";
            System.out.println("string ---->" + str);

            js.executeScript("$('#layoutgrid').jqxGrid('setcellvalue','" + rowId + "', 'field" + i + "', '" + arr[j] + "')");
            driver.findElement(By.xpath("//*[@id='row1layoutgrid']/div/div")).click();
            Thread.sleep(2000);
            i++;
            j++;
        }
    }

    public void updateFieldsForASCIIFormat(String fieldsInLayout) throws InterruptedException
    {
        String[] arr = fieldsInLayout.split(",");
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String rowId = null;

        ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");

        String row = rowsInfo.get(0).toString();
        rowId = getUid(row);
        int count = 1;
        int j = 0;
        int i = 1;

        Pattern p = Pattern.compile("field");
        Matcher m = p.matcher(row);
        while (m.find())
        {
            count++;
        }

        while (j < arr.length && i < count)
        {
            String str = "$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', 'field" + i + "', '" + arr[j] + "')";
            System.out.println("string ---->" + str);

            js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', 'field" + i + "', '" + arr[j] + "')");
            driver.findElement(By.xpath("//*[@id='row1layoutgrid']/div/div")).click();
            Thread.sleep(2000);
            i++;
            j++;
        }
    }

    public void updateParticularField(String fieldsInLayout, int pos)
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        String str = "$('#layoutgrid').jqxGrid('setcellvalue','0', 'field" + pos + "', '" + fieldsInLayout + "')";
        System.out.println("string ---->" + str);

        js.executeScript("$('#layoutgrid').jqxGrid('setcellvalue','0', 'field" + pos + "', '" + fieldsInLayout + "')");
        driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();

    }

    public String getDataFieldValue(int pos)
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;

        String str = (String) js.executeScript("$('#layoutgrid').jqxGrid('getcellvalue','0', 'field" + pos + "')");
        // driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();
        return str;

    }

    public void updateUserDefinedNameForDelimitedFormat(String userDefnames)
    {
        if (!"NA".equalsIgnoreCase(userDefnames))
        {
            String[] arr = userDefnames.split(",");
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String rowId = null;

            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#layoutgrid').jqxGrid('getrows')");

            String row = rowsInfo.get(0).toString();
            rowId = getUid(row);
            int count = 1;
            int j = 0;
            int i = 1;

            while (j < arr.length)
            {
                String str = "$('#layoutgrid').jqxGrid('setcellvalue','1', 'field" + i + "', '" + arr[j] + "')";
                System.out.println("string ---->" + str);

                js.executeScript("$('#layoutgrid').jqxGrid('setcellvalue','1', 'field" + i + "', '" + arr[j] + "')");
                i++;
                j++;
            }
        }
    }

    public void updateDataTypeForDelimitedFormat(String dataType)
    {
        if (!"NA".equalsIgnoreCase(dataType))
        {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String rowId = null;

            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#layoutgrid').jqxGrid('getrows')");

            String row = rowsInfo.get(2).toString();
            rowId = getUid(row);
            int count = 1;
            int j = 0;
            int i = 1;

            Pattern p = Pattern.compile("field");
            Matcher m = p.matcher(row);
            while (m.find())
            {
                count++;
            }
            String dataTypesArr[] = dataType.split(",");

            while (j < dataTypesArr.length && i < count)
            {
                String str = "$('#layoutgrid').jqxGrid('setcellvalue','2', 'field" + i + "', '" + dataTypesArr[j] + "')";
                System.out.println("string ---->" + str);

                js.executeScript("$('#layoutgrid').jqxGrid('setcellvalue','2', 'field" + i + "', '" + dataTypesArr[j] + "')");
                i++;
                j++;
            }
        }
    }

    public void delimitedLayoutFieldsUpdateWithJqx(String fieldsInLayout)
    {
        if (!"NA".equalsIgnoreCase(fieldsInLayout))
        {
            String[] arr = fieldsInLayout.split(",");
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String rowId = null;

            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#layoutgrid').jqxGrid('getrows');");

            int i = 0;

            while (i < rowsInfo.size())
            {
                js.executeScript("$('#layoutgrid').jqxGrid('setcellvalue','0', 'field" + i + "', '" + arr[i] + "')");
                i++;

            }
        }
    }

    public void updateFieldsForEbcdicAndAsciiImportLayout(String fieldsInLayout)
    {
        if (!"NA".equalsIgnoreCase(fieldsInLayout))
        {
            String[] arr = fieldsInLayout.split(",");
            JavascriptExecutor js = (JavascriptExecutor) driver;
            String rowId = null;

            ArrayList rowsInfo = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");

            int i = 0;
            int j = 0;

            while (i < arr.length && j < rowsInfo.size())
            {
                rowId = getUid(rowsInfo.get(j).toString());
                String str = "  $('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', 'fieldType', '" + arr[i] + "')";
                System.out.println("str" + str);
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + rowId + "', 'fieldTypeDisplay', '" + arr[i] + "')");
                driver.findElement(By.xpath("//div[contains(text(),'Character')]")).click();
                j++;
                i++;
            }
        }
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selFieldType(String fldNames) throws InterruptedException
    {
        Actions action = new Actions(driver);
        int i = 0;
        
        String delim = ",";
        StringTokenizer st = new StringTokenizer(fldNames, delim);
        while (st.hasMoreTokens())
        {
            String flds = st.nextToken();
            Thread.sleep(2000);
         	WebElement ele = driver.findElement(By.xpath(".//*[@id='row" + i + "dual-list-data-table-2']/div[2]/div"));
            action.doubleClick(ele).perform();
            Thread.sleep(2000);

            JavascriptExecutor js = (JavascriptExecutor) driver;
        	js.executeScript("$('#comboboxeditordual-list-data-table-2fieldType').jqxComboBox('val','" + flds + "')");
            	Thread.sleep(2000);
                i++;
	    }

      
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selFieldTypesForDelimitedSelection(String fldNames) throws InterruptedException
    {
        Actions action = new Actions(driver);
        int i = 1;
        String delim = ",";
        StringTokenizer st = new StringTokenizer(fldNames, delim);
        while (st.hasMoreTokens())
        {
            String flds = st.nextToken();
            Thread.sleep(2000);
            WebElement ele = driver.findElement(By.xpath(".//*[@id='row0layoutgrid']/div[" + i + "]"));
            action.doubleClick(ele).perform();

            JavascriptExecutor js = (JavascriptExecutor) driver;
            js.executeScript("$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + flds + "')");

            Thread.sleep(2000);

            driver.findElement(By.xpath("//div[@id='row2layoutgrid']/div")).click();
            // ele.click();
            i++;
        }
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selectDataType(String dataTypesPerField) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(dataTypesPerField))
        {
            Actions action = new Actions(driver);
            int i = 0;
            String delim = ",";
            StringTokenizer st = new StringTokenizer(dataTypesPerField, delim);
            String arr[] = dataTypesPerField.split(",");
            while (st.hasMoreTokens())
            {
                String flds = st.nextToken();
                Thread.sleep(2000);
                WebElement ele = driver.findElement(By.xpath(".//*[@id='row" + i + "dual-list-data-table-2']/div[7]/div"));
                action.doubleClick(ele).perform();
                Thread.sleep(2000);
                // driver.findElement(By.xpath("//input[@type='textarea']")).clear();
                driver.findElement(By.xpath(".//*[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div")).click();
                // driver.findElement(By.xpath("//input[@type='textarea']")).sendKeys(flds);
                Thread.sleep(2000);
                // driver.findElement(By.xpath("//b[contains(text(),'"+flds+"')]")).click();
                driver.findElement(
                        By.xpath("//div[@id='listBoxContentinnerListBoxdropdownlisteditordual-list-data-table-2dataType']/div/div/span[contains(text(),'"
                                + arr[i] + "')]")).click();
                i++;
            }
        }
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selUserDefinedName(String userDef) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(userDef))
        {
            String[] userDefName = userDef.split(",");

            JavascriptExecutor js = (JavascriptExecutor) driver;
            int i = 0;
            ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
            while (i < rows.size())
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + i + "', 'name', '" + userDefName[i] + "')");
                i++;
            }
        }
        // *[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selDataType(String dataTypesPerField) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(dataTypesPerField))
        {
            String[] dataTypes = dataTypesPerField.split(",");

            JavascriptExecutor js = (JavascriptExecutor) driver;
            int i = 0;
            ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
            while (i < rows.size())
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + i + "', 'dataTypeDisplay', '" + dataTypes[i] + "')");
                i++;
            }
        }
        // *[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selFieldTypeNew(String fieldsInLayout) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(fieldsInLayout))
        {
            String[] fieldTypes = fieldsInLayout.split(",");

            JavascriptExecutor js = (JavascriptExecutor) driver;
            int i = 0;
            ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
            while (i < rows.size())
            {
                js.executeScript("$('#dual-list-data-table-2').jqxGrid('setcellvalue','" + i + "', 'fieldTypeDisplay', '" + fieldTypes[i] + "')");
                i++;
                driver.findElement(By.xpath("//div[contains(text(),'OTHER_0')]")).click();
            }
        }
        // *[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selFieldTypeForDelimiter(String fldNames) throws InterruptedException
    {
        Actions action = new Actions(driver);
        int i = 1;
        int j = 1;
        int k = 1;
        int l = 1;
        int m = 1;
        String delim = ",";
        StringTokenizer st = new StringTokenizer(fldNames, delim);
        while (st.hasMoreTokens())
        {
            Thread.sleep(2000);
            WebElement ele = driver.findElement(By.xpath("(//div[@role='gridcell'])[" + i + "]"));
            action.doubleClick(ele).perform();
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id='dropdownlistContentcustomeditorlayoutgridfield" + j + "_0']/input")).clear();
            driver.findElement(By.xpath(".//*[@id='dropdownlistArrowcustomeditorlayoutgridfield" + k + "_0']/div")).click();
            driver.findElement(By.xpath(".//*[@id='dropdownlistContentcustomeditorlayoutgridfield" + l + "_0']/input")).sendKeys(st.nextToken());
            Thread.sleep(2000);
            driver.findElement(By.xpath(".//*[@id='dropdownlistArrowcustomeditorlayoutgridfield" + m + "_0']/div")).click();
            i++;
            j++;
            k++;
            l++;
            m++;
        }
    }

    public void updateDataTypeForDelimitedLayout()
    {
        List<WebElement> ele = driver.findElements(By.xpath("//div[@id='row2layoutgrid']/div"));
        int i = 1;
        while (i <= ele.size())
        {
            WebElement element = driver.findElement(By.xpath("//div[@id='row2layoutgrid']/div[" + i + "]/div"));
            element.click();
            element.click();
            element.sendKeys("Character");
            // Select sel = new Select(element);
            //
            // sel.selectByVisibleText("Character");
            i++;
        }

    }

    public List<String> getDataTypesDisplayed()
    {
        List<String> dataTypes = new ArrayList<>();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int i = 0;
        ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
        while (i < rows.size())
        {
            String str = (String) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue'," + i + ",'dataTypeDisplay')");
            dataTypes.add(str);
            i++;
        }
        return dataTypes;

    }

    public void updateLengthForAgeField() throws InterruptedException
    {
        Actions action = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//div[contains(text(),'Age')]/following::div[5]"));
        action.doubleClick(ele).perform();
        Thread.sleep(2000);

        driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']/div/input")).clear();
        driver.findElement(By.xpath("//div[@id='contenttabledual-list-data-table-2']/div/input")).sendKeys("10");
        driver.findElement(By.xpath("//div[contains(text(),'Age')]")).click();
    }

    public void updateDatatTypeToHexForAgeField() throws InterruptedException
    {
        Actions action = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//div[contains(text(),'Age')]/following::div[7]/div"));
        action.doubleClick(ele).perform();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div")).click();
        driver.findElement(By.xpath("//div[@id='listBoxContentinnerListBoxdropdownlisteditordual-list-data-table-2dataType']/div/div[5]/span"))
                .click();
        driver.findElement(By.xpath("//div[contains(text(),'Age')]")).click();

    }

    public void updateDatatTypeToHexForFirstNameField() throws InterruptedException
    {
        Actions action = new Actions(driver);
        WebElement ele = driver.findElement(By.xpath("//div[contains(text(),'First Name')]/following::div[9]"));
        action.doubleClick(ele).perform();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@id='listBoxContentinnerListBoxdropdownlisteditordual-list-data-table-2dataType']/div/div[3]/span"))
                .click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[contains(text(),'First Name')]")).click();

    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void selectFieldTypeForDelimiter(String fldNames) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(fldNames))
        {
            Actions action = new Actions(driver);
            int i = 1;

            String[] fldNamesArr = fldNames.split(",");

            while (i < fldNamesArr.length || i == fldNamesArr.length)
            {
                Thread.sleep(2000);
                String xpath = "//div[@id='row0layoutgrid']//div[@role='gridcell'][" + i + "]";
                WebElement ele = driver.findElement(By.xpath("//div[@id='row0layoutgrid']//div[@role='gridcell'][" + i + "]"));

                ele.click();
                ele.click();
                action.doubleClick(ele).build().perform();

                List<WebElement> ele1 = driver.findElements(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']"));
                if (ele1.size() > 0)
                {
                    driver.findElement(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']")).click();
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    String str1 = "$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNamesArr[i - 1] + "');";

                    js.executeScript("$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNamesArr[i - 1] + "'); ");
                } else
                {
                    action.doubleClick(ele).build().perform();
                    driver.findElement(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']")).click();
                    JavascriptExecutor js = (JavascriptExecutor) driver;
                    String str = "$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNamesArr[i - 1] + "');";
                    js.executeScript("$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNamesArr[i - 1] + "'); ");
                }
                i++;

            }
        }
    }

    public List<String> getUseDefSelections()
    {
        List<String> userDefList = new ArrayList<>();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int i = 1;

        ArrayList rows = (ArrayList) js.executeScript("return $('#layoutgrid').jqxGrid('getrows')");
        while (i <= 5)
        {
            String str = (String) js.executeScript("return $('#layoutgrid').jqxGrid('getcellvalue',1,'field" + i + "')");
            userDefList.add(str);
            i++;
        }
        return userDefList;
    }

    @Step("Selected the Field Type values in the grid = \"{0}\"")
    public void updateFieldTypeForDelimiter(String fldNames, int i) throws InterruptedException
    {
        if (!"NA".equalsIgnoreCase(fldNames))
        {
            Actions action = new Actions(driver);

            // String[] fldNamesArr = fldNames.split(",");

            // while (i <= fldNamesArr.length)
            // {
            Thread.sleep(2000);
            String xpath = "//div[@id='row0layoutgrid']//div[@role='gridcell'][" + i + "]";
            WebElement ele = driver.findElement(By.xpath("//div[@id='row0layoutgrid']//div[@role='gridcell'][" + i + "]"));

            ele.click();
            ele.click();
            action.doubleClick(ele).build().perform();

            List<WebElement> ele1 = driver.findElements(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']"));
            if (ele1.size() > 0)
            {
                driver.findElement(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']")).click();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                String str1 = "$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNames + "');";

                js.executeScript("$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNames + "'); ");
            } else
            {
                action.doubleClick(ele).build().perform();
                driver.findElement(By.xpath("//div[@id='dropdownlistArrowcustomeditorlayoutgridfield" + i + "_0']")).click();
                JavascriptExecutor js = (JavascriptExecutor) driver;
                String str = "$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNames + "');";
                js.executeScript("$('#customeditorlayoutgridfield" + i + "_0').jqxComboBox('selectItem','" + fldNames + "'); ");
            }
            // i++;
            //
            // }

        }

    }

    public List<Long> getStartPosPerRowFromGrid(int rowId)
    {
        List<Long> startEndValues = new ArrayList<>();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
        if (null != rows)
        {

            Long startPos = (Long) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue', " + rowId + ", 'startPos');");
            Long endPos = (Long) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue', " + rowId + ", 'endPos');");

            if (null != startPos && null != endPos)
            {
                startEndValues.add(startPos);
                startEndValues.add(endPos);
            }
        }
        return startEndValues;
    }

    public List<String> getUserDefNamesFromGrid()
    {
        List<String> nameValues = new ArrayList<>();

        JavascriptExecutor js = (JavascriptExecutor) driver;
        ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
        int i = 0;
        while (i < rows.size())
        {

            String name = (String) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue', " + i + ", 'name');");

            if (StringUtils.isNotEmpty(name))
            {
                nameValues.add(name);

            }
            i++;
        }
        return nameValues;
    }

    @Step("Get Default Fields value from the grid = \"{0}\"")
    public List<String> getDefaultFieldsValues() throws InterruptedException
    {

        List<String> fieldNames = new ArrayList<>();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        int i = 0;
        ArrayList rows = (ArrayList) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getrows')");
        while (i < rows.size())
        {
            String val = (String) js.executeScript("return $('#dual-list-data-table-2').jqxGrid('getcellvalue','" + i + "','fieldTypeDisplay')");
            fieldNames.add(val);
            i++;
        }
        return fieldNames;

        // *[@id='dropdownlistArrowdropdownlisteditordual-list-data-table-2dataType']/div
    }

    public void moveScrollbarHorizontaly()
    {
        WebElement scroll = driver.findElement(By.xpath("//div[@id='previewFixedJqxWindowContent']"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollBy(7250,0)", scroll);

    }
}

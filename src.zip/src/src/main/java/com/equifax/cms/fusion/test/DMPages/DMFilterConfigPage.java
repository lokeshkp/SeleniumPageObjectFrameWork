package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DMFilterConfigPage
{

    WebDriver driver;
    public Select selType;

    public DMFilterConfigPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "(.//*[@id='rejectAddressVarianceCode1'])[2]")
    public WebElement CB_Reject_Address_Variance_Code;

    @FindBy(xpath = "(.//*[@id='file5401'])[2]")
    public WebElement CB_Create_540_file;

    @FindBy(xpath = "(.//*[@class='fusion-h3Title'])[6]")
    public WebElement Title;

    @FindBy(xpath = ".//a[contains(text(),'All U.S. States/Territories')]")
    WebElement AllUSstatesTeri;

    @FindBy(xpath = "//input[@name='dnsDrop']")
    public WebElement CB_DNSdrop;

    @FindBy(id = "invalidAgeDrop")
    public WebElement CB_InvalidBlankAgeDrop;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[4]/input")
    public WebElement CB_Fact_Act;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[5]/input")
    public WebElement CB_Invalid_Drop;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[4]/a/img")
    WebElement Edit_FactAct_Img;

    @FindBy(xpath = "(.//*[@id='rejectFraudCode1'])[2]")
    public WebElement CB_Fact_Act_Reject_Fraud_Code;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[5]/a/img")
    WebElement Edit_InvalidDrop_Img;

    @FindBy(xpath = "(//input[@class='check-all'])[2]")
    WebElement ConfigInvalidDropAllChckBox;

    @FindBy(xpath = "(//form[@id='invalidDropForm'])[2]//*[@value='Save']")
    public WebElement SaveInvalidDropWindow;

    @FindBy(id = "testFileDrop")
    public WebElement CB_TestFileDrop;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[7]/input")
    public WebElement CB_ID_Scan;

    @FindBy(xpath = "(.//*[@id='rejectAfs1'])[2]")
    public WebElement CB_Fact_Act_Reject_AFS_Alert_Data_BFMN;

    @FindBy(xpath = "(.//*[@id='factActForm']/div[2]/input[2])[2]")
    public WebElement Save_Fact_Act;

    @FindBy(xpath = "(.//*[@id='invalidDropForm']/div[1]/ul/li[1]/input)[2]")
    public WebElement CB_Conf_Inv_Drop_ALL;

    @FindBy(xpath = "(.//*[@id='invalidNameAddress'])[2]")
    public WebElement CB_Conf_Inv_Drop_Invalid_Name_Address;

    @FindBy(xpath = "(.//*[@id='invalidStreetAddress1'])[2]")
    public WebElement CB_Conf_Inv_Street_Address;

    @FindBy(xpath = "(.//*[@id='missingCityStateZip1'])[2]")
    public WebElement CB_Conf_Missing_CityStateZip;

    @FindBy(xpath = "(.//*[@id='invalidSubName1'])[2]")
    public WebElement CB_Inv_SubName;

    @FindBy(xpath = ".//*[@id='summaryForm']/div[7]/a/img")
    WebElement Edit_ID_SCAN;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/div[7]/input[2]")
    WebElement Save_But_Fil_Config;

    @FindBy(xpath = "(.//*[@class='fusion-h3Title'])[1]")
    public WebElement DMFC_Title;

    @FindBy(xpath = "//input[@value='Save']")
    WebElement Save_Btn;

    @FindBy(xpath = "//input[@onclick='showCreditInputPage()']")
    public WebElement ContinueButton;

    @FindBy(xpath = "//a[contains(text(),'PSPS')]//following::div[2]")
    public WebElement ScModRejStatusInGrid;

    @FindBy(id = "mlaStatus")
    public WebElement mlaStatusCB;
    
    @FindBy(xpath = ".//a[contains(text(),'IDSCAN')]//parent::div/parent::li")
    public WebElement idScanDiv;
    
    @FindBy(xpath = ".//a[contains(text(),'DE STD')]//parent::div/parent::li")
    public WebElement deStdDiv;

    @Step("Click Save on Filter Configuration Screen")
    public void click_Save_Fil_Config_Screen()
    {
        Save_But_Fil_Config.click();
    }

    @Step("Click Edit ID Scan")
    public void click_Edit_ID_Scan()
    {
        Edit_ID_SCAN.click();
    }

    @Step("Click Invalid Name/Address Check Box on Configure Invalid Drop Pop up")
    public void click_Conf_Inv_Drop_Invalid_Name_Address()
    {
        CB_Conf_Inv_Drop_Invalid_Name_Address.click();
    }

    @Step("Click ALL Check Box on Configure Invalid Drop Pop up")
    public void click_Conf_Inv_Drop_ALL()
    {
        CB_Conf_Inv_Drop_ALL.click();
    }

    @Step("Click Edit Invalid Drop")
    public void click_Edit_Invalid_Drop()
    {
        Edit_InvalidDrop_Img.click();
    }

    @Step("Click Save Button Fact Act Pop up")
    public void click_Save_button_Fact_Act()
    {
        Save_Fact_Act.click();
    }

    @Step("Click Edit Fact Act")
    public void clickFactActEdit()
    {
        Edit_FactAct_Img.click();
    }

    public void clickALL_US_States()
    {
        AllUSstatesTeri.click();
    }

    @Step("Click DNS Drop")
    public void clickDNSdropChckBox()
    {
        CB_DNSdrop.click();
    }

    @Step("Click Invalid/Blank Age Drop")
    public void clickInvalidBlankAgeChckBox()
    {
        CB_InvalidBlankAgeDrop.click();
    }

    @Step("Selected the Fact Act options")
    public void selectFactAct(String factActOpt)
    {
        Edit_FactAct_Img.click();
        if (factActOpt.equalsIgnoreCase("RAVC"))
        {
            if (CB_Reject_Address_Variance_Code.isSelected())
            {
                System.out.println("Not required to select the option...");
                if (CB_Fact_Act_Reject_Fraud_Code.isSelected() && CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.isSelected()
                        && CB_Create_540_file.isSelected())
                {
                    CB_Fact_Act_Reject_Fraud_Code.click();
                    CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
                    CB_Create_540_file.click();
                }
            } else
            {
                CB_Reject_Address_Variance_Code.click();
            }
        } else if (factActOpt.equalsIgnoreCase("RFC"))
        {
            if (CB_Fact_Act_Reject_Fraud_Code.isSelected())
            {
                System.out.println("Not required to select the option...");
                if (CB_Reject_Address_Variance_Code.isSelected() && CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.isSelected()
                        && CB_Create_540_file.isSelected())
                {
                    CB_Reject_Address_Variance_Code.click();
                    CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
                    CB_Create_540_file.click();
                }
            } else
            {
                CB_Fact_Act_Reject_Fraud_Code.click();
            }
        } else if (factActOpt.equalsIgnoreCase("RAD"))
        {
            if (CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.isSelected())
            {
                System.out.println("Not required to select the option...");
                if (CB_Reject_Address_Variance_Code.isSelected() && CB_Fact_Act_Reject_Fraud_Code.isSelected() && CB_Create_540_file.isSelected())
                {
                    CB_Reject_Address_Variance_Code.click();
                    CB_Fact_Act_Reject_Fraud_Code.click();
                    CB_Create_540_file.click();
                }
            } else
            {
                CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            }
        } else if (factActOpt.equalsIgnoreCase("C540"))
        {
            if (CB_Create_540_file.isSelected())
            {
                System.out.println("Not required to select the option...");
                if (CB_Reject_Address_Variance_Code.isSelected() && CB_Fact_Act_Reject_Fraud_Code.isSelected()
                        && CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.isSelected())
                {
                    CB_Reject_Address_Variance_Code.click();
                    CB_Fact_Act_Reject_Fraud_Code.click();
                    CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
                }
            } else
            {
                CB_Create_540_file.click();
            }
        } else if (factActOpt.equalsIgnoreCase("OFF"))
        {
            CB_Fact_Act_Reject_Fraud_Code.click();
            CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
        }
        Save_Fact_Act.click();
    }

    @Step("Click Test File Drop ")
    public void clickTestFileDropChckBox()
    {
        CB_TestFileDrop.click();
    }

    @Step("Clicked on Save button")
    public void clickedSaveBtn()
    {
        Save_Btn.click();
    }

    @Step("Click Continue Button on Filter Configuration Screen")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    @Step("Select DNS Drop")
    public void selectDNSdrop(String dnsDrop)
    {
        if (dnsDrop.equalsIgnoreCase("ON"))
        {
            System.out.println("DNS drop already selected");

        } else if (dnsDrop.equalsIgnoreCase("OFF"))
        {
            clickDNSdropChckBox();
        }
    }

    @Step("Select Invalid Age Drop")
    public void selectInvalidAgedrop(String ageDrop)
    {
        if (ageDrop.equalsIgnoreCase("ON"))
        {
            System.out.println("Invalid Age drop already selected");

        } else
        {
            clickInvalidBlankAgeChckBox();

        }
    }

    @Step("Select Invalid Drop")
    public void selectInvalidDrop(String invalidDrop) throws InterruptedException
    {
        if (invalidDrop.equalsIgnoreCase("ON"))
        {
            System.out.println("Invalid drop already selected");

        } else
        {
            Edit_InvalidDrop_Img.click();
            // driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
            for (int second = 0;; second++)
            {
                if (second >= 60)
                    Assert.fail("timeout");
                try
                {
                    if (isElementPresent(By.xpath("(//input[@class='check-all'])[2]")))
                        break;
                } catch (Exception e)
                {
                }
                Thread.sleep(1000);
            }

            ConfigInvalidDropAllChckBox.click();
            driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
            SaveInvalidDropWindow.click();
            driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
            System.out.println("Invalid Drop unselected");

        }
    }

    @Step("Select Test File Drop")
    public void selectTestFileDrop(String testFileDrop)
    {
        if (testFileDrop.equalsIgnoreCase("ON"))
        {
            System.out.println("Test File drop already selected");

        } else
        {
            clickTestFileDropChckBox();
        }
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("Clicked the Create 540 file option")
    public void click540file()
    {
        CB_Create_540_file.click();
    }

    @Step("Click MLA status checkbox")
    public void clickMLAStatusCB()
    {
        mlaStatusCB.click();
    }

    @Step("Click MLA status checkbox")
    public void clickMLAStatusCB1(String mla)
    {
        if ("CHECK".equalsIgnoreCase(mla))
        {
            mlaStatusCB.click();
        }
    }
    
    public void clickElementInConfigTable(String element){
        driver.findElement(By.xpath("//a[contains(text(),'"+element+"')]")).click();
    }

}

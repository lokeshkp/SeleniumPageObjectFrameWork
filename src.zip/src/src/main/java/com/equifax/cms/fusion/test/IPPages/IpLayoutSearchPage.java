package com.equifax.cms.fusion.test.IPPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class IpLayoutSearchPage {
	WebDriver driver;
	
	public IpLayoutSearchPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
	}
	
	@FindBy(id = "projnum")
	WebElement ProjNumFld;
	
	@FindBy(id = "search")
	WebElement SearchBtn;
	
	@FindBy(id = "backButton")
	WebElement CancelBtn;
	
	@FindBy(xpath = "//input[@type='submit']")
	WebElement ContinueBtn;
	
	@Step("Provided the Project Number field ")
	public void inputProjNum(String srchProjNum){
		ProjNumFld.clear();
		ProjNumFld.sendKeys(srchProjNum);
	}
	
	@Step("Search the Project Number = \"{0}\"")
	public void clickSearchBtn(){
		SearchBtn.click();	
	}
	
	@Step("Select the search Layout file in the grid = \"{0}\"")
	public void selectSrchLayout(String srchLayoutName){
		driver.findElement(By.xpath("(//label[contains(text(),'"+srchLayoutName+"')])[1]//preceding::input[1]")).click();
	}
	
	@Step("Clicked on Cancel button")
	public void clickCancelBtn(){
		CancelBtn.click();
	}
	
	@Step("Clicked on Continue button")
	public void clickContinueBtn(){
		ContinueBtn.click();
	}
}

package com.equifax.cms.fusion.test.utils;

import org.openqa.selenium.Proxy;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class FusionFirefoxDriver {

	/***
	 * when Firefox started on Jenkins , It is always loading a profile with out proxy setting
	 * NOT loading default profile . to override that we are adding the PAC script in driver itself
	 * @return {@link FirefoxDriver}
	 */
	public static FirefoxDriver getDriver() {
		Proxy proxy = new Proxy();
		proxy.setProxyType(Proxy.ProxyType.PAC);
//		proxy.setSocksUsername("akp8");
//		proxy.setSocksPassword("Oct@2017");
		proxy.setProxyAutoconfigUrl("http://proxy-user.wip.us.equifax.com/proxy.js");
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability(CapabilityType.PROXY, proxy);
		
		return new FirefoxDriver(capabilities);
	}
}

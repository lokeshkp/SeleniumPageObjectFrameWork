package com.equifax.cms.fusion.test.OPPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class OpAliasPage
{

    WebDriver driver;

    public OpAliasPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//a[contains(text(),'HEADER')]")
    WebElement Ele_HeaderTable;

    @FindBy(id = "add_SampleFile")
    WebElement ForwardButton;

    @FindBy(id = "remove_SampleFile")
    WebElement removeButton;

    @FindBy(id = "aliasId")
    WebElement AliasName;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    public void clickOkPopUp()
    {
        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[2]")).click();
    }

    public void clickFullForwardBtn()
    {
        driver.findElement(By.id("addAll_SampleFile")).click();
    }

    public void clickFullBackwardBtn()
    {
        driver.findElement(By.id("removeAll_SampleFile")).click();
    }

    public void clickTableRemoveButton()
    {
        driver.findElement(By.xpath(".//*[@id='remove_SampleFile']")).click();
    }

    public void clickSecondSelectedTable()
    {
        driver.findElement(By.xpath(".//*[@id='1']/li")).click();
    }

    public String getAliasTableSelected()
    {
        return driver.findElement(By.xpath(".//*[@id='selectedArtifacts']/ul/div/ul/li/span")).getAttribute("class");
    }

    public String getAliasChangeMessageText()
    {
        String text = driver.findElement(By.xpath("//div[@id='sb-player']/div[1]/h1[1]")).getText();
        return text;

    }

    public void clickConfirmationOK()
    {
        driver.findElement(By.xpath("//div[@id='sb-player']/div/div/a[2]")).click();
    }

    public String getAliasProvided()
    {
        return driver.findElement(By.id("selectedTablesList0.alias")).getAttribute("value");
    }

    @Step("Click Forward button")
    public void clickForwardButton()
    {
        ForwardButton.click();
    }

    @Step("Click backward button")
    public void clickBackwardButton()
    {
        removeButton.click();
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Continue the process")
    public void clickContinueButton() throws InterruptedException
    {
        ContinueButton.click();
        Thread.sleep(15000);
    }

    @Step("Clear alias Name")
    public void clearAliasName()
    {
        AliasName.clear();
    }

    @Step("Provide alias Name = \"{0}\"")
    public void inputAliasName(String name)
    {
        AliasName.sendKeys(name);
    }

    @Step("select the Alias Tables = \"{0}\"")
    public void inputAliasTables(String tableName)
    {
        String delims1 = ";";
        String comma = ",";
        StringTokenizer stMain = new StringTokenizer(tableName, delims1);
        while (stMain.hasMoreElements())
        {
            String[] splitString = stMain.nextToken().split(comma);
            String dynPath = ".//a[contains(text(),'" + splitString[0] + "')]";
          driver.findElement(By.xpath(dynPath)).click();
          clickForwardButton();
           
          driver.findElement(By.xpath("//span[contains(text(),'" + splitString[0] + "')]//parent::li/input[4]")).clear();
            driver.findElement(By.xpath("//span[contains(text(),'" + splitString[0] + "')]//parent::li/input[4]")).sendKeys(splitString[1]);
           
            
        }
    }
    @Step("Change The Alias Name")
    public void changeAliasName(String aliasName)
    {
        
       // String comma = ";";
        
           // String[] splitString = aliasName.split(comma);

          driver.findElement(By.xpath("//*[@id='selectedTablesList0.alias']")).clear();;
            driver.findElement(By.xpath("//*[@id='selectedTablesList0.alias']")).sendKeys(aliasName);
           
            
        }
    @Step("Remove the Alias Tables = \"{0}\"")
    public void removeAliasTables(String tableName)
    {
        String delims1 = ";";
        String comma = ",";
        StringTokenizer stMain = new StringTokenizer(tableName, delims1);
        while (stMain.hasMoreElements())
        {
            String[] splitString = stMain.nextToken().split(comma);

            String dynPath = ".//span[contains(text(),'" + splitString[0] + "')]/parent::li[1]";
            driver.findElement(By.xpath(dynPath)).click();
            clickBackwardButton();

        }
    }

    public String getSelectedAliasTable()
    {
        return driver.findElement(By.xpath(".//*[@class='FieldName']/span")).getAttribute("class");

    }

    public boolean isPopupPresent()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[2]")).click();
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }
    
    public boolean is_STEP_FLAG_TABLE_Present() 
    {
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            System.out.println(driver.findElement(By.xpath(".//*[contains(text(),'STEP_FLAG_TBL')]")).getText());
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        }catch(org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
    
    public boolean is_INQUIRYPOSTTBL_Present() 
    {
        try {
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            System.out.println(driver.findElement(By.xpath(".//*[contains(text(),'INQUIRYPOSTTBL')]")).getText());
            driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
            return true;
        }catch(org.openqa.selenium.NoSuchElementException e) {
            return false;
        }
    }
}

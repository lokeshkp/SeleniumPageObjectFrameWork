package com.equifax.cms.fusion.test.RFPages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class HholdSplitPage {

    WebDriver driver;

    public HholdSplitPage(WebDriver driver){
        this.driver = driver;

    }

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/h3")
    WebElement ScreenTitle;

    @FindBy(id = "textMsg")
    WebElement ErrorMessage;

    @FindBy(id = "household1")
    WebElement Ele_HholdSplit;

    @FindBy(id = "household2")
    WebElement Ele_RegHholdDrop;

    @FindBy(id = "single")
    WebElement Ele_Single;

    @FindBy(id = "primary")
    WebElement Ele_Primary;

    @FindBy(id = "secondary")
    WebElement Ele_Secondary;

    @FindBy(id = "tertiary")
    WebElement Ele_Tertiary;

    @FindBy(id = "duplicates")
    WebElement Ele_Duplicates;

    @FindBy(xpath = ".//input[@value='Save']")
    WebElement SaveButton;

    @FindBy(xpath = "(.//*[@name='submitButton'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement BackBtn;

    @Step ("Saved the process")
    public void clickSaveButton(){
        SaveButton.click();
    }

    @Step ("Continue the process")
    public void clickContinueButton(){
        ContinueButton.click();
    }
    @Step ("Continue the process")
    public void clickBackButton(){
        BackBtn.click();
    }
    public void selectHholdSplitOptions(String hHoldSplitReg){
        if("HHS".equalsIgnoreCase(hHoldSplitReg)){
            Ele_HholdSplit.click();

        } else if("RHHD".equalsIgnoreCase(hHoldSplitReg)){
            Ele_RegHholdDrop.click();

        } else {
            System.out.println("Provide proper information in the input excel sheet !!!");
        }
    }

    @Step ("Screen Title:")
    public String getTitle(){
        return ScreenTitle.getText();
    }

    @Step("Error message is ")
    public String getErrMsg(){
        return ErrorMessage.getText();
    }
}


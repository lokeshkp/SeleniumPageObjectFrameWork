package com.equifax.cms.fusion.test.vo;

public class InputLayoutVO {

	private String layoutName;
	private String fieldType;
	private String fieldName;
	private String startPos;
	private String endPos;
    private String constName;
    private String constValue;
    private String purpose;
    private String fileType;
    private String headerRows;
    private String checkCleanse;
    private String checkSingle;
    private String checkMulti;
    private String inputLayout;

	public String getLayoutName() {
		return layoutName;
	}

	public void setLayoutName(String layoutName) {
		this.layoutName = layoutName;
	}

	public String getFieldType() {
		return fieldType;
	}

	public void setFieldType(String fieldType) {
		this.fieldType = fieldType;
	}

	public String getFieldName() {
		return fieldName;
	}

	public void setFieldName(String fieldName) {
		this.fieldName = fieldName;
	}

	public String getStartPos() {
		return startPos;
	}

	public void setStartPos(String startPos) {
		this.startPos = startPos;
	}

	public String getEndPos() {
		return endPos;
	}

	public void setEndPos(String endPos) {
		this.endPos = endPos;
	}

    public String getConstName()
    {
        return constName;
    }

    public void setConstName(String constName)
    {
        this.constName = constName;
    }

    public String getConstValue()
    {
        return constValue;
    }

    public void setConstValue(String constValue)
    {
        this.constValue = constValue;
    }

    public String getPurpose()
    {
        return purpose;
    }

    public void setPurpose(String purpose)
    {
        this.purpose = purpose;
    }

    public String getFileType()
    {
        return fileType;
    }

    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    public String getHeaderRows()
    {
        return headerRows;
    }

    public void setHeaderRows(String headerRows)
    {
        this.headerRows = headerRows;
    }

    public String getCheckCleanse()
    {
        return checkCleanse;
    }

    public void setCheckCleanse(String checkCleanse)
    {
        this.checkCleanse = checkCleanse;
    }

    public String getCheckSingle()
    {
        return checkSingle;
    }

    public void setCheckSingle(String checkSingle)
    {
        this.checkSingle = checkSingle;
    }

    public String getCheckMulti()
    {
        return checkMulti;
    }

    public void setCheckMulti(String checkMulti)
    {
        this.checkMulti = checkMulti;
    }

    public String getInputLayout()
    {
        return inputLayout;
    }

    public void setInputLayout(String inputLayout)
    {
        this.inputLayout = inputLayout;
    }

    @Override
	public String toString() {
		StringBuilder sb = new StringBuilder()
				.append("layout name - ")
				.append(layoutName)
				.append(" field name - ")
				.append(fieldName)
				.append(" fieldType - ")
				.append(fieldType)
				.append("Start pos - ")
				.append(startPos)
				.append("end pos - ")
				.append(endPos);
		return sb.toString();
	}
}

package com.equifax.cms.fusion.test.DNSPages;

import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.equifax.cms.fusion.test.qapages.CommonMethods;

import ru.yandex.qatools.allure.annotations.Step;

public class DNSStatsView {
	WebDriver driver;
	public Select selType;
	String dnsOutputTableName;
	String dnsInputTableName;
	CommonMethods commMethods;
	
	public DNSStatsView(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
	}
	
	@Step("{method}")
	public String getDNSTablePopulationNameUI(){
		return driver.findElement(By.xpath("//div[contains(text(), 'DNS Table Population')]/following-sibling::div")).getText();
	}
	
	@Step("{method}")
	public Long getDNSTablePopuCountUI(){
		String value = driver.findElement(By.xpath(".//div[contains(text(), 'dns.dns')]/following::div[1]/div[2]")).getText();
		return Long.parseLong(RemoveComma(value));
	}
	
	@Step("{method}")
	public String getInputTableNameUI(){
		return driver.findElement(By.xpath("//div[contains(text(), 'Input Table Population')]/following-sibling::div")).getText();
	}
	
	@Step("{method}")
	public Long getInputTableCountUI(){
		String value = driver.findElement(By.xpath(".//div[contains(text(), 'Input Table Population')]/following::div[4]")).getText();
		return Long.parseLong(RemoveComma(value));
	}
	
	@Step("{method}")
	public String getDNSOPTableNameUI(){
		return driver.findElement(By.xpath("(//div[contains(text(), 'DNS Output Table Population')]/following-sibling::div)")).getText();
	}
	
	@Step("{method}")
	public Long getDNSOPTableCountUI(){
		String value = driver.findElement(By.xpath(".//div[contains(text(), '_DNS_GPFILTER_DNS')]/following::div[1]/div[2]")).getText();
		return Long.parseLong(RemoveComma(value));
	}
	
	@Step("{method}")
	public Long getRefreshedDNSCountUI(){
		return Long.parseLong(driver.findElement(By.xpath("(//div[contains(text(), 'Number of Refreshed DNS')]/following-sibling::div)")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_A_CountUI(){
		return Long.parseLong(driver.findElement(By.xpath(".//div[contains(text(), 'Record Type Distribution')]/following::div/div"
				+ "[contains(text(),'A')]/following::div[1]")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_A_CountGP() throws SQLException{
		
		return commMethods.getRecordsFromGP(getDNSOPTableNameUI()+" where dp_sequence_num in(select dp_sequence_num from fusion_stage."+getInputTableNameUI()+
				" where acc_code ='A' )and dns_tag='A')");
	}
	
	@Step("{method}")
	public Long getRecordType_B_CountUI(){
		return Long.parseLong(driver.findElement(By.xpath(".//div[contains(text(), 'Record Type Distribution')]/following::div/div"
				+ "[contains(text(),'B')]/following::div[1]")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_B_CountGP() throws SQLException{
		return commMethods.getRecordsFromGP(getDNSOPTableNameUI()+" where dp_sequence_num in(select dp_sequence_num from fusion_stage."+getInputTableNameUI()+
				" where acc_code ='B' )and dns_tag='A')");
	}
	
	@Step("{method}")
	public Long getRecordType_C_CountUI(){
		return Long.parseLong(driver.findElement(By.xpath(".//div[contains(text(), 'Record Type Distribution')]/following::div/div"
				+ "[contains(text(),'C')]/following::div[1]")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_C_CountGP() throws SQLException{
		return commMethods.getRecordsFromGP(getDNSOPTableNameUI()+" where dp_sequence_num in(select dp_sequence_num from fusion_stage."+getInputTableNameUI()+
				" where acc_code ='C' )and dns_tag='A')");
	}
	
	@Step("{method}")
	public Long getRecordType_DN_CountUI(){
		return Long.parseLong(driver.findElement(By.xpath(".//div[contains(text(), 'Record Type Distribution')]/following::div/div"
				+ "[contains(text(),'DN-Do Not Solicit')]/following::div[1]")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_DN_CountGP() throws SQLException{
		return commMethods.getRecordsFromGP(getDNSOPTableNameUI()+" where dns_tag ='D'");
	}
	
	@Step("{method}")
	public Long getRecordType_Other_CountUI(){
		return Long.parseLong(driver.findElement(By.xpath(".//div[contains(text(), 'Record Type Distribution')]/following::div/div"
				+ "[contains(text(),'Other')]/following::div[1]")).getText());
	}
	
	@Step("{method}")
	public Long getRecordType_Other_CountGP() throws SQLException{
		return commMethods.getRecordsFromGP(getDNSOPTableNameUI()+" where dp_sequence_num in(select dp_sequence_num from fusion_stage."+getInputTableNameUI()+
				" where acc_code is NULL )and dns_tag='A')");
	}
	
	@Step("{method}")
	public static String RemoveComma(String a)
	{
		String a2="";
		String[] a1 = a.split(",");
		for(int i=0;i<a1.length;i++)
		{
			 a2=a2+a1[i];
		}
		return a2;
	}
	
	
}

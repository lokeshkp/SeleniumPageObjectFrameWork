package com.equifax.cms.fusion.test.qapages;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ExcelRead
{

    public static final Logger LOGGER = LoggerFactory.getLogger(ExcelRead.class);

    private static XSSFSheet ExcelWSheet;
    private static XSSFWorkbook ExcelWBook;
    private static XSSFCell Cell;
    private static XSSFRow Row;

    public static Object[][] getTableArrayforSheet(String FilePath, String SheetName, String option) throws Exception
    {
        String[][] tabArray_Y = null;
        try
        {
            FileInputStream ExcelFile = new FileInputStream(FilePath);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(SheetName);
            int startRow = 1;
            int startCol = 1;
            int Y = 0;
            int ci, cj;
            int totalRows = ExcelWSheet.getLastRowNum();
            // you can write a function as well to get Column count
            int totalCols = ExcelWSheet.getRow(0).getLastCellNum() - 1;
            for (int i = startRow; i <= totalRows; i++)
            {
                if (getCellData(i, 1).equalsIgnoreCase(option))
                {
                    Y++;
                }
            }
            // System.out.println(Y);
            tabArray_Y = new String[Y][totalCols];
            ci = 0;
            for (int i = startRow; i <= totalRows; i++)
            {
                if (getCellData(i, 1).equalsIgnoreCase(option))
                {
                    cj = 0;
                    for (int j = startCol; j <= totalCols; j++, cj++)
                    {
                        tabArray_Y[ci][cj] = getCellData(i, j);
                        System.out.println("Row : " + ci + " " + "Column : " + cj + "= " + tabArray_Y[ci][cj]);
                    }
                    ci++;
                }
            }
        } catch (FileNotFoundException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        } catch (IOException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        }
        return (tabArray_Y);
    }

    public static Object[][] getTableArrayforSheet_Reg(String FilePath, String SheetName, String option) throws Exception
    {
        String[][] tabArray_Y = null;
        try
        {
            FileInputStream ExcelFile = new FileInputStream(FilePath);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(SheetName);
            int startRow = 1;
            int startCol = 0;
            int Y = 0;
            int ci, cj;
            int totalRows = ExcelWSheet.getLastRowNum();
            // you can write a function as well to get Column count
            int totalCols = ExcelWSheet.getRow(0).getLastCellNum();
            for (int i = startRow; i <= totalRows; i++)
            {
                if (getCellData(i, 1).equalsIgnoreCase(option))
                {
                    Y++;
                }
            }
            System.out.println(Y);
            tabArray_Y = new String[Y][totalCols];            
            ci = 0;
            for (int i = startRow; i <= totalRows; i++)
            {
                if (getCellData(i, 1).equalsIgnoreCase(option))
                {
                    cj = 0;
                    for (int j = startCol; j < totalCols; j++, cj++)
                    {
                        tabArray_Y[ci][cj] = getCellData(i, j);
                        System.out.println("Row : " + ci + " " + "Column : " + cj + "= " + tabArray_Y[ci][cj]);
                    }
                    ci++;
                }
            }
        } catch (FileNotFoundException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        } catch (IOException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        }
        //System.out.println( tabArray_Y);
        return (tabArray_Y);
    }

    public static String getCellData(int RowNum, int ColNum) throws Exception
    {

        try
        {
            Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
            System.out.println("for row : " + RowNum + ", column : " + ColNum);
            int dataType = Cell.getCellType();
            String CellData = "";
            switch (Cell.getCellType())
            {
            case XSSFCell.CELL_TYPE_NUMERIC:
                CellData = Cell.getRawValue();
                break;

            case XSSFCell.CELL_TYPE_STRING:
                CellData = Cell.getStringCellValue();
                break;
            }
            return CellData;
        } catch (Exception e)
        {
            System.out.println(e.getMessage());
            throw (e);
        }
    }

    /*
     * This method update the excel with updated value
     */
    public static void updateRunStatus(final String filePath, final String sheetName, final String testCaseId)
    {
        try
        {
            FileInputStream excelFile = new FileInputStream(filePath);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(excelFile);
            ExcelWSheet = ExcelWBook.getSheet(sheetName);

            int totalRows = ExcelWSheet.getLastRowNum();
            // you can write a function as well to get Column count
            int totalCols = ExcelWSheet.getRow(0).getLastCellNum();
            LOGGER.info("total cells :{} ", totalCols);
            for (int i = 1; i <= totalRows; i++)
            {
                String value = getCellData(i, 0);
                LOGGER.info("value --  {}", value);
                if (testCaseId.equalsIgnoreCase(value))
                {
                    XSSFCell runStatus = ExcelWSheet.getRow(i).getCell(totalCols - 1);
                    runStatus.setCellValue("Y");

                }

            }

            FileOutputStream fos = new FileOutputStream(filePath);
            ExcelWBook.write(fos);
            fos.close();

            excelFile.close();
        } catch (Exception e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    // TODO : Refactor following code
    // this code duplication !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

    public static Object[][] getTableArrayforSheetWithRunStatus(String FilePath, String SheetName, String option) throws Exception
    {
        String[][] tabArray_Y = null;
        try
        {
            FileInputStream ExcelFile = new FileInputStream(FilePath);
            // Access the required test data sheet
            ExcelWBook = new XSSFWorkbook(ExcelFile);
            ExcelWSheet = ExcelWBook.getSheet(SheetName);
            int startRow = 1;
            int startCol = 0;
            int Y = 0;
            int ci, cj;
            int totalRows = ExcelWSheet.getLastRowNum();
            // you can write a function as well to get Column count
            int totalCols = ExcelWSheet.getRow(0).getLastCellNum();

            // Check run status column available
            int lastColNum = totalCols - 1;
            String lastColumnName = getCellData(0, lastColNum);
            LOGGER.info("Last Column Name : {} ", lastColumnName);

            for (int i = startRow; i <= totalRows; i++)
            {
                if (getCellData(i, 1).equalsIgnoreCase(option) && getCellData(i, lastColNum).equalsIgnoreCase("N"))
                {
                    Y++;
                }
            }
            // System.out.println(Y);
            tabArray_Y = new String[Y][totalCols];
            ci = 0;
            for (int i = startRow; i <= totalRows; i++)
            {
                // Check Run Status also
                if (getCellData(i, 1).equalsIgnoreCase(option) && getCellData(i, lastColNum).equalsIgnoreCase("N"))
                {
                    cj = 0;
                    for (int j = startCol; j < totalCols; j++, cj++)
                    {
                        tabArray_Y[ci][cj] = getCellData(i, j);
                        System.out.println("Row : " + ci + " " + "Column : " + cj + "= " + tabArray_Y[ci][cj]);
                    }
                    ci++;
                }
            }
        } catch (FileNotFoundException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        } catch (IOException e)
        {
            System.out.println("Could not read the Excel sheet");
            e.printStackTrace();
        }
        return (tabArray_Y);
    }

}
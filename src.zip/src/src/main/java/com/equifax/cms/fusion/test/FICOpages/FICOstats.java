package com.equifax.cms.fusion.test.FICOpages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class FICOstats
{
    WebDriver driver;

    public FICOstats(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//div[contains(text(),'Current Fico Sample Count')]/following::div[1]")
    WebElement CurrentFICOsampleCount;

    @FindBy(linkText = "DISTRIBUTION_REPORT")
    WebElement DistributionRep_Link;

    @FindBy(xpath = "//div[@id='closeButton']//preceding::div[3]")
    WebElement Report_Location;

    @Step("Fetched Current FICO sample Count")
    public Long getFICOsampleCount()
    {
        String currentFICOsampleCount = CurrentFICOsampleCount.getText();
        return Long.parseLong(currentFICOsampleCount);
    }

    @FindBy(xpath = "//a[contains(text(),'COUNTERS')]")
    WebElement Counters_Link;

    @Step("Distribution Report Link in stats")
    public String distributionRep()
    {
        return DistributionRep_Link.getText();
    }

    @Step("Get report Loaction for PDF")
    public String getReportLocation()
    {
        return Report_Location.getText();

    }

    @Step("View Counters")
    public void clickCounterslink()
    {
        Counters_Link.click();
    }

    @Step("Get Counters content")
    public String getCountersContent()
    {
        String val = driver.findElement(By.xpath("//body/div[1]/div[1]/pre/div")).getText();
        return val;
    }
    
    public String getOutputFilePath() {
        return driver.findElement(By.xpath("//div[contains(text(),'Output file path')]//following::div[1]")).getText();
    }
}

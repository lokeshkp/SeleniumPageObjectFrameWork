package com.equifax.cms.fusion.test.DMEpages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class DMEsetupPage
{

    WebDriver driver;
    public Select selType;

    public DMEsetupPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(id = "name")
    WebElement Ele_ProcessName;

    @FindBy(id = "dataOrigin")
    WebElement Ele_DataOrigin;

    @FindBy(id = "fromProcessId")
    WebElement Ele_Process;

    @FindBy(id = "itemTableId")
    WebElement Ele_Data;

    @FindBy(id = "selectStateOptions")
    WebElement Ele_SelectStates;

    @FindBy(id = "fromProcessIdDmExpress")
    WebElement Ele_ProcessForCID;

    @FindBy(id = "itemTableIdDmExpress")
    WebElement Ele_DataForCID;

    @FindBy(id = "addModule")
    WebElement AddModuleButton;

    @FindBy(id = "modulePojos0")
    WebElement Ele_Module;

    @FindBy(xpath = ".//*[@id='detailsModuleDiv0']/table/tbody/tr[1]/td[1]/input[2]")
    WebElement ModuleOpTableField;

    @FindBy(id = "numberOfAccepts")
    WebElement NoPerAcc_Fld;

    @FindBy(id = "numberOfRejects")
    WebElement NoPerRej_Fld;

    @FindBy(xpath = "(.//input[@type='submit'])[2]")
    WebElement ContinueButton;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/div/label")
    WebElement errMsg;

    @FindBy(id = "textMsg")
    WebElement errMsg1;

    @Step("Clear Output Table Name")
    public void clearModuleOpTable()
    {
        ModuleOpTableField.clear();
    }

    @Step("Output Table Name = \"{0}\"")
    public void moduleOpTable(String tName)
    {
        ModuleOpTableField.sendKeys(tName);
    }

    @Step("The Error message is ")
    public String getErrorMsg()
    {
        return errMsg.getText();
    }

    @Step("The Error message is ")
    public String getErrorMsg1()
    {
        return errMsg1.getText();
    }

    @Step("Process Name Field = \"{0}\"")
    public void processNameField(String procName)
    {
        if (!"NA".equalsIgnoreCase(procName))
        {
            Ele_ProcessName.sendKeys(procName);
        }
    }

    @Step("Select Data Origin Field value = \"{0}\"")
    public void selectDataOriginField(String dataOrigin)
    {
        selType = new Select(Ele_DataOrigin);
        selType.selectByVisibleText(dataOrigin);
    }

    @Step("Select Process for List Source field = \"{0}\"")
    public void selectProcessField(String process)
    {
        selType = new Select(Ele_Process);
        selType.selectByVisibleText(process);
    }

    @Step("Select Data for List Source field = \"{0}\"")
    public void selectDataField(String data)
    {
        selType = new Select(Ele_Data);
        selType.selectByVisibleText(data);
    }

    @Step("Select Data for List Source field")
    public void selectDataForUI()
    {
        selType = new Select(Ele_Data);
        selType.selectByVisibleText("Select");
    }

    @Step("Select Process for CID List field = \"{0}\"")
    public void selectProcessForCID(String process)
    {
        selType = new Select(Ele_ProcessForCID);
        selType.selectByVisibleText(process);
    }

    @Step("Select Data for CID List field = \"{0}\"")
    public void selectDataForCID(String data)
    {
        selType = new Select(Ele_DataForCID);
        selType.selectByVisibleText(data);
    }

    @Step("Add the multiple Modules = \"{0}\"")
    public void selectModules(String mod) throws InterruptedException
    {
        String delimiter = ",";
        String str[] = StringUtils.split(mod, delimiter);
        selType = new Select(driver.findElement(By.id("modulePojos0")));
        selType.selectByVisibleText(str[0]);
        Thread.sleep(5000);
        for (int j = 1; j < str.length; j++)
        {
            AddModuleButton.click();
            selType = new Select(driver.findElement(By.id("modulePojos" + j)));
            selType.selectByVisibleText(str[j]);
            Thread.sleep(5000);
        }
    }

    @Step("Select Input States = \"{0}\"")
    public void selectStatesDropDwn(String states)
    {
        if ("NA".equalsIgnoreCase(states))
        {
            System.out.println("Please select the individual states..");
        } else
        {
            WebElement mySelectElement = driver.findElement(By.id("selectStateOptions"));
            Select dropdown= new Select(mySelectElement);
            dropdown.selectByVisibleText(states);
        }
    }

    @Step("Select Input States List = \"{0}\"")
    public void selectStatesList(String stateList)
    {
        if (!"NA".equalsIgnoreCase(stateList))
        {
            String comma = ",";
            StringTokenizer stMain = new StringTokenizer(stateList, comma);
            while (stMain.hasMoreElements())
            {
                driver.findElement(By.xpath("//input[@id='" + stMain.nextToken() + "']")).click();
            }
        }
    }

    public void UnselectOutputs(String tableNames)
    {
        if (!"NA".equalsIgnoreCase(tableNames))
        {
            String delim = ",";
            StringTokenizer strTok = new StringTokenizer(tableNames, delim);
            while (strTok.hasMoreTokens())
            {
                driver.findElement(By.xpath("(.//*[@value='" + strTok.nextToken() + "'])[1]//preceding::input[1]")).click();
            }
        }
    }

    @Step("Get required plugins = \"{0}\"")
    public String getRequiredPluginsById(int i)
    {
        String plugin = driver.findElement(By.xpath(".//*[@id='detailsModuleDiv0']/table/tbody/tr[1]/td[2]/label[" + i + "]")).getText();
        return plugin;
    }

    @Step("Get Model Version = \"{0}\"")
    public String getModelVersion()
    {
        String version = driver.findElement(By.xpath(".//*[@id='versionDiv0']/label")).getText();
        return version;
    }

    @Step("Provided the Number per Accept Code = \"{0}\"")
    public void inputNoPerAcc(String accValue)
    {
        if (!"NA".equalsIgnoreCase(accValue))
        {
            NoPerAcc_Fld.clear();
            NoPerAcc_Fld.sendKeys(accValue);
        }
    }

    @Step("Provided the Number per Reject Code = \"{0}\"")
    public void inputNoPerRej(String rejValue)
    {
        if (!"NA".equalsIgnoreCase(rejValue))
        {
            NoPerRej_Fld.clear();
            NoPerRej_Fld.sendKeys(rejValue);
        }
    }

    @Step("Click Continue Button ")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    @Step("Click Save Button ")
    public void clickSaveButton()
    {
        driver.findElement(By.xpath("(.//*[@type='submit'])[1]")).click();
    }

    public String getVersionNumberAPModule()
    {
        try
        {
            String vermod = driver.findElement(By.xpath("(.//*[contains(text(),'Version')])[1]")).getText();
            String[] verModArr = vermod.split(":");
            return verModArr[1].trim();
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return "";
        }

    }

    public void selectLoadPointScoreData(String loadPointScoreData)
    {

        if ("N".equalsIgnoreCase(loadPointScoreData))
        {
            // Do Nothing
        } else if ("Y".equalsIgnoreCase(loadPointScoreData))
        {
            driver.findElement(By.id("pointScore")).click();
        }

    }

    public boolean isLoadPointScoreDataSelected()
    {
        return driver.findElement(By.id("pointScore")).isSelected();

    }

    public boolean isProcessDisplayed()
    {
        int count = driver.findElements(By.xpath(".//*[@id='fromProcessIdDmExpress']/option")).size();
        if (count > 1)
        {
            return true;
        } else
        {
            return false;
        }
    }

}

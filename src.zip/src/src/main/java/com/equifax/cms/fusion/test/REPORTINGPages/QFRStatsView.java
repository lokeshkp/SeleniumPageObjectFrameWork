package com.equifax.cms.fusion.test.REPORTINGPages;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class QFRStatsView {
	WebDriver driver;
	
	public QFRStatsView(WebDriver driver){
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = "//div[contains(text(),'Report Location')]//following::div[1]")
	WebElement ReportLocation;
	
	@FindBy(xpath = "//div[contains(text(),'Report Path')]//following::div[1]/a")
	WebElement ReportPath;
	
	@Step("Clicked Report Path")
	public void clickReportPath(){
		ReportPath.click();
	}
	
	@Step("Checked the file size")
	public void getFileSize(){
		File file = new File(ReportLocation.getText());
		if(file.exists()){
			double bytes = file.length();
			double kilobytes = (bytes / 1024);
			
			System.out.println("bytes: " + bytes);
			System.out.println("kilobytes: " + kilobytes);
		} else {
			System.out.println("File does not exists !!!");
		}
	}
}

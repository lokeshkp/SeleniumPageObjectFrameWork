package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import ru.yandex.qatools.allure.annotations.Step;

public class DoubleCheckPage
{

    WebDriver driver;
    public Select selType;

    public DoubleCheckPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(id = "checkallInModel1")
    public WebElement CB_CritCodes_All;

    @FindBy(id = "A")
    public WebElement CB_CC_A;

    @FindBy(id = "B")
    public WebElement CB_CC_B;

    @FindBy(id = "C")
    public WebElement CB_CC_C;

    @FindBy(id = "D")
    public WebElement CB_CC_D;

    @FindBy(id = "E")
    public WebElement CB_CC_E;

    @FindBy(id = "F")
    public WebElement CB_CC_F;

    @FindBy(id = "G")
    public WebElement CB_CC_G;

    @FindBy(id = "H")
    public WebElement CB_CC_H;

    @FindBy(id = "I")
    public WebElement CB_CC_I;

    @FindBy(id = "J")
    public WebElement CB_CC_J;

    @FindBy(id = "K")
    public WebElement CB_CC_K;

    @FindBy(id = "L")
    public WebElement CB_CC_L;

    @FindBy(id = "M")
    public WebElement CB_CC_M;

    @FindBy(id = "N")
    public WebElement CB_CC_N;

    @FindBy(id = "O")
    public WebElement CB_CC_O;

    @FindBy(id = "P")
    public WebElement CB_CC_P;

    @FindBy(id = "Q")
    public WebElement CB_CC_Q;

    @FindBy(id = "R")
    public WebElement CB_CC_R;

    @FindBy(id = "S")
    public WebElement CB_CC_S;

    @FindBy(id = "T")
    public WebElement CB_CC_T;

    @FindBy(id = "U")
    public WebElement CB_CC_U;

    @FindBy(id = "V")
    public WebElement CB_CC_V;

    @FindBy(id = "W")
    public WebElement CB_CC_W;

    @FindBy(id = "X")
    public WebElement CB_CC_X;

    @FindBy(id = "Y")
    public WebElement CB_CC_Y;

    @FindBy(id = "Z")
    public WebElement CB_CC_Z;

    @FindBy(id = "checkallInModel2")
    public WebElement CB_Options_ALL;

    @FindBy(id = "a")
    public WebElement A_PHASE_SSN_DBCK;

    @FindBy(id = "b")
    public WebElement B_ANB_BNKCRD_SSN_DBCK;

    @FindBy(id = "c")
    public WebElement C_ANB_BNKCRD_ADR_DBCK;

    @FindBy(id = "d")
    public WebElement D_ANB_PRV_LAB_SSN_DBCK;

    @FindBy(id = "e")
    public WebElement E_ANB_PRV_LAB_ADR_DBCK;

    @FindBy(id = "f")
    public WebElement F_AGENT_BANK_SSN_ADR;

    @FindBy(id = "g")
    public WebElement G_ANB_PL96_LVL_A;

    @FindBy(id = "h")
    public WebElement H_ANB_PL96_LVL_B_to_E;

    @FindBy(id = "i")
    public WebElement I_USA_SSN_ADR_DBCK;

    @FindBy(id = "j")
    public WebElement J_OLD_PHASE_SSN_DBCK;

    @FindBy(id = "ssnDropKeep1")
    WebElement Rad_SSN_Drop;

    @FindBy(id = "ssnDropKeep2")
    WebElement Rad_SSN_Tag;

    @FindBy(id = "ssnDropKeep3")
    WebElement Rad_SSN_Reject;

    @FindBy(id = "addrDropKeep1")
    WebElement Rad_Addr_Drop;

    @FindBy(id = "addrDropKeep2")
    WebElement Rad_Addr_Tag;

    @FindBy(id = "addrDropKeep3")
    WebElement Rad_Addr_Reject;

    @FindBy(id = "runDblCheck1")
    WebElement Ele_RunDoubleCheck;

    @FindBy(id = "dblCheckSelect")
    WebElement Ele_DoubleCheckType;

    @FindBy(xpath = ".//img[@alt='edit']")
    WebElement EditImage;

    @FindBy(xpath = ".//img[@alt='Edit']")
    public WebElement EditImage1;

    @FindBy(id = "A")
    WebElement Ele_CritCode_A;

    @FindBy(id = "a")
    WebElement Ele_Option_A;

    @FindBy(xpath = "//a[contains(text(),'Save')]")
    WebElement Save_EditCriteriaCodesWindow;

    @FindBy(id = "addnewrow")
    WebElement AddOptionsButton;

    @FindBy(xpath = ".//input[@type='submit']")
    WebElement ContinueButton;

    @FindBy(xpath = ".//*[@id='contentArea']/div[3]/div/div[2]")
    WebElement ErrorMessage;

    @FindBy(xpath = ".//*[@id='tbldiv']/tr/td[5]/a/img")
    WebElement RemoveDB;

    @FindBy(xpath = ".//*[@name='options[0].scrubType']")
    WebElement ScrubType1;

    @FindBy(xpath = ".//h3[@class='fusion-h3Title']")
    WebElement Title_Edit_Crit_Code;

    @FindBy(xpath = "html/body/div[1]/div[2]/a[2]")
    WebElement EditCritSave;

    @Step("Click Save on Edit Criteria Pop up")
    public void click_Save_Edit_Crit() throws InterruptedException
    {
        EditCritSave.click();
        Thread.sleep(1000);
    }

    @Step("Get Title on Edit Criteria Code Pop up")
    public String get_Title_Edit_CC_code()
    {
        (new WebDriverWait(driver, 30)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(".//h3[@class='fusion-h3Title']")));
        return Title_Edit_Crit_Code.getText();
    }

    @Step("Select Double Check Options")
    public void sel_Element(WebElement Element)
    {
        Element.click();
    }

    @Step("Select SSN Drop")
    public void sel_SSN_Drop()
    {
        Rad_SSN_Drop.click();
    }

    @Step("Select SSN Tag")
    public void sel_SSN_Tag()
    {
        Rad_SSN_Tag.click();
    }

    @Step("Select SSN Reject")
    public void sel_SSN_Reject()
    {
        Rad_SSN_Reject.click();
    }

    @Step("Select Address Drop")
    public void sel_Addr_Drop()
    {
        Rad_Addr_Drop.click();
    }

    @Step("Select Address Tag")
    public void sel_Addr_Tag()
    {
        Rad_Addr_Tag.click();
    }

    @Step("Select Address Reject")
    public void sel_Addr_Reject()
    {
        Rad_Addr_Reject.click();
    }

    @Step("Select Scrub Type :  {0} ")
    public void selScrubType1(String Value)
    {
        Select sl = new Select(ScrubType1);
        sl.selectByValue(Value);
    }

    @Step("Remove Double Check")
    public void RemoveDBChck()
    {
        RemoveDB.click();
    }

    @Step("Get Error Message")
    public String getErrorMessage()
    {
        return ErrorMessage.getText();
    }

    @Step("Click Run Double Check")
    public void clickRunDoubleChckBox()
    {
        Ele_RunDoubleCheck.click();
    }

    @Step("Select Double Check : {0} ")
    public void selectDoubleChckType(String type)
    {
        Select sl = new Select(Ele_DoubleCheckType);
        sl.selectByVisibleText(type);

    }

    @Step("Click Edit Double Check")
    public void clickEditImage() throws InterruptedException
    {
        EditImage.click();
        Thread.sleep(2000);
        driver.switchTo().frame("sb-player");
    }

    @Step("Click ADD Button")
    public void clickAddOptionsButton()
    {
        AddOptionsButton.click();
    }

    @Step("Saved the Edit Criteria Codes/Options window")
    public void saveEditCritCodeWindow()
    {
        Save_EditCriteriaCodesWindow.click();
    }

    @Step("Click Continue Button on Double Check Page")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    public void selectDoubleCheckOptions() throws InterruptedException
    {
        Ele_CritCode_A.click();
        Ele_Option_A.click();
    }
}

package com.equifax.cms.fusion.test.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.NumberFormat;
import java.text.ParseException;
import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.PropertiesUtils;

/**
 * Database Utils obtain database connection and have helper methods to execute SQL Queries
 * 
 * @author sxr236
 * 
 */
public class GreenPlumDBHelper
{

    private static final Logger LOGGER = LoggerFactory.getLogger(GreenPlumDBHelper.class);

    private Connection connection;

    // get oracle database connection
    private Connection initConnection()
    {

        Connection connection = null;

        try
        {
            Class.forName("org.postgresql.Driver");
            String host = PropertiesUtils.getProperty("gp.host");
            String user = PropertiesUtils.getProperty("gp.user");
            String password = PropertiesUtils.getProperty("gp.password");
            connection = DriverManager.getConnection(host, user, password);
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {0}\n Trace {1}\n ", e.getMessage(), e);
        }
        return connection;
    }

    // return single connection at any point of time
    // no "double-check" since there is no multithreading
    public synchronized Connection getConnection()
    {
        if (null == connection)
        {
            LOGGER.debug("Init database .... ");
            connection = initConnection();
        }
        return connection;
    }

    /**
     * return record count for given table
     * 
     * @return Long - record count , will be null on error
     * @throws ParseException
     * @throws NumberFormatException
     */

    public Long getGPCount(String tableName) throws NumberFormatException, ParseException
    {
        NumberFormat numberFormat = NumberFormat.getInstance(Locale.US);
        String sql = "SELECT COUNT(*) CNT FROM fusion_stage." + tableName;
        PreparedStatement statement = null;
        String count = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            rs.next();
            count = rs.getString("CNT");
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given table name Message {}\n ", se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return Long.valueOf(numberFormat.parse(count).toString());
    }

}

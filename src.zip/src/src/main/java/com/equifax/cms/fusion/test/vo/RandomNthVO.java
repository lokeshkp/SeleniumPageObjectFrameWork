package com.equifax.cms.fusion.test.vo;

public class RandomNthVO extends AbsctractVO {

	private String inputProcess;
	private String numOfOutput;
	private String data;
	private String recordType;

	public String getNumOfOutput() {
		return numOfOutput;
	}

	public void setNumOfOutput(String numOfOutput) {
		this.numOfOutput = numOfOutput;
	}

	public String getInputProcess() {
		return inputProcess;
	}

	public void setInputProcess(String inputProcess) {
		this.inputProcess = inputProcess;
	}

	public String getData() {
		return data;
	}

	public void setData(String data) {
		this.data = data;
	}

	public String getRecordType() {
		return recordType;
	}

	public void setRecordType(String recordType) {
		this.recordType = recordType;
	}
}

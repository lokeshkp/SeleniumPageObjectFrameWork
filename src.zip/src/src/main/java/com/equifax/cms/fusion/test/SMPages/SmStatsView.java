package com.equifax.cms.fusion.test.SMPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FilenameUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapojos.PdlLayoutMasterPojo;
import com.equifax.cms.fusion.test.qapojos.PdlLayoutMasterPojo.PDL_PURPOSE;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class SmStatsView {
    WebDriver driver;

    private OracleDBHelper oracleDB;
    public SmStatsView(WebDriver driver){
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @Step("Fetched the ADDRESS DISCREPANCY INDICATOR count from SM table = \"{0}\"")
    public Long getAddDiscrCountfromSMtableUI(String indicator){
        String getYrecCountfromSMtable = driver.findElement(By.xpath("//div[contains(text(),'ADDRESS DISCREPANCY INDICATOR COUNT(S)')]//following::div[contains(text(),'"+indicator+"')]//following::div[1]")).getText();
        return Long.parseLong(removeComma(getYrecCountfromSMtable));
    }

    @Step("Creating a Green Plum Connection")
    public static Connection gpConnect()
    {
        Connection conn = null;
        try
        {
            Class.forName("org.postgresql.Driver");
            conn = DriverManager.getConnection(PropertiesUtils.getProperty("gp.host"), PropertiesUtils.getProperty("gp.user"),
                    PropertiesUtils.getProperty("gp.password"));
        } catch (SQLException e)
        {
            e.printStackTrace();
        } catch (ClassNotFoundException e)
        {
            e.printStackTrace();
        }
        return conn;
    }

    @Step("Fetching ADDRESS DISCREPANCY INDICATOR From Green Plum for Table = \"{0}\" \"{1}\"")
    public long getAddrDiscrCountFromGP(String table, String indicator) throws SQLException
    {
        Connection conn = gpConnect();
        String query1;
        query1 = "select count(*) from fusion_stage." + table + " where address_disc_ind_yn = '" + indicator + "'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        long records = 0;
        while (rs.next())
        {
            records = rs.getLong(1);
        }
        conn.close();
        return records;
    }


    @Step("Fetch The Output File Path")
    public String getTheOutputFilePath()
    {
        String path = driver.findElement(By.xpath("//div[text()='SM_GPEXPORT']/following::div[contains(text(),'Records Written To')]")).getText();
        String[] updatedFilePath=path.split("To");
        String[] filePath=updatedFilePath[1].split(":");
        filePath[0] = filePath[0].replaceAll("\\s+","");
        return filePath[0];
    }

    public String readFileAndFetchTheResult(String path,String field,String sequenceNum,String tableName,String tc_id) throws SQLException
    {oracleDB = new OracleDBHelper();
    oracleDB.getConnection();

    PdlLayoutMasterPojo pdlPojo=oracleDB.getStartEndPosFromPdlPurpose(PDL_PURPOSE.REFORMATINI.name(),field);


    String result=null;

    File f = null;
    String recordFromTable = null;
    try
    {
        f = new File(path);
        if (f.exists() && !f.isDirectory())
        {
            try (BufferedReader br = new BufferedReader(new FileReader(f)))
            {
                String sCurrentLine;
                int i=0;
                while ((sCurrentLine = br.readLine()) != null && i<6)
                {
                    System.out.println(sCurrentLine);
                    int spaceCount=0;
                    int startPosForField1=pdlPojo.getStartPos();
                    int lengthForField1=pdlPojo.getEndPos();
                    int endPosForField1=startPosForField1+lengthForField1;
                    String fetchedDataForField1 = sCurrentLine.substring(startPosForField1-1,endPosForField1-1);
                    System.out.println("Record whose Field Name is SSN--"+fetchedDataForField1);
                    if("SM_ID_028".equalsIgnoreCase(tc_id))
                    {
                        for (char c : fetchedDataForField1.toCharArray()) {
                            if (c == ' ')
                            {

                                spaceCount++;



                            }
                        }
                        result= Integer.toString(spaceCount);
                    }
                    else
                    {
                        PdlLayoutMasterPojo pdlPojoforSeqNum=oracleDB.getStartEndPosFromPdlPurpose(PDL_PURPOSE.REFORMATINI.name(), sequenceNum);
                        int startPosForSeqNum=pdlPojoforSeqNum.getStartPos();
                        int lengthForSeqNum=pdlPojoforSeqNum.getEndPos();
                        int endPosForFieldSeqNum=startPosForSeqNum+lengthForSeqNum;
                        String fetchedDataForSeqNum = sCurrentLine.substring(startPosForSeqNum-1,endPosForFieldSeqNum-1);
                        System.out.println("Record whose Field Name is SeqNumS--"+fetchedDataForField1);
                        recordFromTable=getSSNFromTheTableForGivenSeqNum(tableName,fetchedDataForSeqNum);
                        if(fetchedDataForField1.trim().equalsIgnoreCase(recordFromTable.trim()) && fetchedDataForField1.length()==9 )
                        {
                            result="Matched";
                        }
                    }
                    i++;

                }
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

        } else
        {

            System.out.println("file not found !!!!");

        }
    }
    catch (Exception e)
    {
        // if any error occurs
        e.printStackTrace();
    }
    return result;

    }

    public boolean chkFileExist(String path,String[] fileNames)
    {
        boolean result=false;

        File f = null;
        File[] fileList;



        try
        {
            // create new file

            String outputFilePath = FilenameUtils.getPath(path);
            String updatedOPFilePath = "/" + outputFilePath;

            if (updatedOPFilePath.endsWith("/"))
            {
                updatedOPFilePath = updatedOPFilePath.substring(0, updatedOPFilePath.length() - 1);
            }
            /*
             * String path1="c:"+new1; String str1 = path1.replace("\\", "/");
             */
            f = new File(updatedOPFilePath);
            if (f.exists() && f.isDirectory())
            {
                // returns pathnames for files and director

                if (f.list().length > 0)
                {

                    System.out.println("Directory is not empty!");
                    fileList = f.listFiles();
                    for (File file : fileList)
                    {
                        // prints file and directory paths
                        System.out.println(file);
                        if (file.getName().equalsIgnoreCase(fileNames[0]))
                        {
                            result=true;
                        }
                        if(file.getName().equalsIgnoreCase(fileNames[1]))
                        {
                            result=true;
                        }
                    }


                } else
                {

                    System.out.println("Directory is empty!");

                }

            }
        } catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return result;

    }
    public String readFile(String path,String[] field,String sequenceNum,String tableName,String tc_id) throws SQLException
    {
        oracleDB = new OracleDBHelper();
        oracleDB.getConnection();

        List<PdlLayoutMasterPojo> pdlPojoList=oracleDB.fetchPdlLayoutMasterPojoList(PDL_PURPOSE.REFORMATINI.name(),field);


        File f = null;
        String result=null;

        try
        {
           f = new File(path);
            //if (f.exists() && !f.isDirectory())
            //{
                try (BufferedReader br = new BufferedReader(new FileReader(f)))
                {
                    String sCurrentLine;
                    int i = 0;
                    while ((sCurrentLine = br.readLine()) != null && i<6)
                    {

                        System.out.println(sCurrentLine);
                        for(PdlLayoutMasterPojo pdlPojo:pdlPojoList)
                        {

                            String recordFromTable=null;
                            if(pdlPojo.getFieldName().equalsIgnoreCase("FMLS"))
                            {

                                int startPosForField1=pdlPojo.getStartPos();
                                int lengthForField1=pdlPojo.getEndPos();
                                int endPosForField1=startPosForField1+lengthForField1;
                                String fetchedDataForField1 = sCurrentLine.substring(startPosForField1-1,endPosForField1-1);
                                System.out.println("Record whose Field Name is FMLS--"+fetchedDataForField1);
                                PdlLayoutMasterPojo pdlPojoforSeqNum=oracleDB.getStartEndPosFromPdlPurpose(PDL_PURPOSE.REFORMATINI.name(), sequenceNum);
                                int startPosForSeqNum=pdlPojoforSeqNum.getStartPos();
                                int lengthForSeqNum=pdlPojoforSeqNum.getEndPos();
                                int endPosForFieldSeqNum=startPosForSeqNum+lengthForSeqNum;
                                String fetchedDataForSeqNum = sCurrentLine.substring(startPosForSeqNum-1,endPosForFieldSeqNum-1);
                                System.out.println("Record whose Field Name is SeqNumS--"+fetchedDataForField1);
                                if("SM_ID_025".equalsIgnoreCase(tc_id))
                                {
                                    recordFromTable=getNameFromGivenDpSeqNum(tableName,fetchedDataForSeqNum);
                                }
                                if("SM_ID_023".equalsIgnoreCase(tc_id))
                                {
                                    recordFromTable=getFMLSFromGivenDpSeqNum(tableName,fetchedDataForSeqNum);
                                }
                                if(recordFromTable!=null)
                                {

                                    if(fetchedDataForField1.trim().equalsIgnoreCase(recordFromTable.trim()))
                                    {
                                        result="Matched";
                                    }
                                    else
                                    {
                                        result="Not Matched";
                                        break;
                                    }
                                }


                            }
                            if(pdlPojo.getFieldName().equalsIgnoreCase("MAILING_ADDRESS"))
                            {
                                int startPosForField2=pdlPojo.getStartPos();
                                int lengthForField2=pdlPojo.getEndPos();
                                int endPosForField2=startPosForField2+lengthForField2;
                                String fetchedDataForField2 = sCurrentLine.substring(startPosForField2-1,endPosForField2);
                                System.out.println("Record whose Field Name is MAILING_ADDRESS--"+fetchedDataForField2);
                                PdlLayoutMasterPojo pdlPojoforSeqNum=oracleDB.getStartEndPosFromPdlPurpose(PDL_PURPOSE.REFORMATINI.name(), sequenceNum);
                                int startPosForSeqNum=pdlPojoforSeqNum.getStartPos();
                                int lengthForSeqNum=pdlPojoforSeqNum.getEndPos();
                                int endPosForFieldSeqNum=startPosForSeqNum+lengthForSeqNum;
                                String fetchedDataForSeqNum = sCurrentLine.substring(startPosForSeqNum-1,endPosForFieldSeqNum-1);
                                String updatedFetchedDataForSeqNum = fetchedDataForSeqNum.replaceAll("\\s+"," ");
                                System.out.println("Record whose Field Name is SeqNumS--"+updatedFetchedDataForSeqNum);
                                if("SM_ID_027".equalsIgnoreCase(tc_id))
                                {
                                    recordFromTable=getStreetNameStreetNumFromGivenDpSeqNum(tableName,updatedFetchedDataForSeqNum);
                                }
                                if("SM_ID_023".equalsIgnoreCase(tc_id))
                                {
                                    recordFromTable=getStreetAddressFromGivenDpSeqNum(tableName,updatedFetchedDataForSeqNum);
                                }
                                if(recordFromTable!=null)
                                {
                                    if(fetchedDataForField2.trim().equalsIgnoreCase(recordFromTable.trim()))
                                    {
                                        result="Matched";
                                    }
                                    else
                                    {
                                        result="Not Matched";
                                        break;
                                    }
                                }


                            }
                            if(pdlPojo.getFieldName().equalsIgnoreCase("CITY_STATE_ZIP"))
                            {
                                int startPosForField3=pdlPojo.getStartPos();
                                int lengthForField3=pdlPojo.getEndPos();
                                int endPosForField3=startPosForField3+lengthForField3;
                                String fetchedDataForField3 = sCurrentLine.substring(startPosForField3-1,endPosForField3-1);
                                System.out.println("Record whose Field Name is MAILING_ADDRESS--"+fetchedDataForField3);
                                PdlLayoutMasterPojo pdlPojoforSeqNum=oracleDB.getStartEndPosFromPdlPurpose(PDL_PURPOSE.REFORMATINI.name(), sequenceNum);
                                int startPosForSeqNum=pdlPojoforSeqNum.getStartPos();
                                int lengthForSeqNum=pdlPojoforSeqNum.getEndPos();
                                int endPosForFieldSeqNum=startPosForSeqNum+lengthForSeqNum;
                                String fetchedDataForSeqNum = sCurrentLine.substring(startPosForSeqNum-1,endPosForFieldSeqNum-1);
                                System.out.println("Record whose Field Name is SeqNumS--"+fetchedDataForField3);
                                recordFromTable=getStateAndZipFromGivenDpSeqNum(tableName,fetchedDataForSeqNum);
                                if(recordFromTable!=null)
                                {

                                    if(fetchedDataForField3.trim().equalsIgnoreCase(recordFromTable.trim()))
                                    {
                                        result="Matched";
                                    }
                                    else
                                    {
                                        result="Not Matched";
                                        break;
                                    }
                                }


                            }
                        }
                        i++;
                    }
                }
                catch (IOException e)
                {
                    e.printStackTrace();
                }

//            } else
//            {
//
//                System.out.println("file not found !!!!");
//
//            }
        }
        catch (Exception e)
        {
            // if any error occurs
            e.printStackTrace();
        }
        return result;

    }




    public boolean chkSSNHasNullValues(List<String> ssnList)
    {
        boolean result=true;

        if(CollectionUtils.isNotEmpty(ssnList))
        {
            for(String ssn:ssnList)
            {
                if(ssn==null)
                {
                    result=false;
                }
            }
        }
        return result;
    }
    @Step("Fetched Item Number Of SM GPExport WorkItem")
    public String[] getTheWorkItemNumOfSMGPExport(String processNameForStats,String procNameColon) throws InterruptedException
    {
    	
    	 
        String[] fileNames=new String[2];
        Thread.sleep(2000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
        Thread.sleep(1500);
       driver.findElement(By.xpath("//span[contains(text(),'" + procNameColon + "')]/preceding::span[1]")).click();
       Thread.sleep(1500);
       String itemNo=driver.findElement(By.xpath("//span[contains(text(),'SM_GPEXPORT')]/parent::td/parent::tr//td[3]")).getText().trim();
        

        fileNames[0]= "I" + itemNo + "_SM_GPEXPORT.fixed";
        fileNames[1]="I"+itemNo+"_SM_GPEXPORT.sql";
        return fileNames;
    }
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getStreetNameStreetNumFromGivenDpSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select  rpad (ltrim(btrim(coalesce(street_number,'')) || ' ' || btrim(coalesce(street_name,''))),50, ' ') from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getFMLSFromGivenDpSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select  rpad( btrim(coalesce(name_free_form_fmls, '')) , 60, ' ' ) as FMLS from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getNameFromGivenDpSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select  rpad(ltrim( btrim(coalesce(first_name, ''))  || ' ' || btrim(coalesce(middle_name, ''))  || ' ' || btrim(coalesce(last_name, '')) ),60, ' ')  from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getStateAndZipFromGivenDpSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select rpad(ltrim( btrim(coalesce(city, ''))  || ' ' || btrim(coalesce(state, ''))  || ' ' || btrim(coalesce(zip, '')) ),60, ' ') || rpad('', 9, ' ') AS STATE_ZIP from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";
        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getStreetAddressFromGivenDpSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select  rpad( btrim(coalesce(street_address_1, '')) , 50, ' ' ) || rpad('',50, ' ') AS MAILING_ADDRESS from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }
    //this query fetches without dash containing ssn from input gp load table when file to be input in Import file has ssn with dashes
    @Step("Fetching Record From Green Plum for Table = \"{0}\"")
    public String getSSNFromTheTableForGivenSeqNum(String tableName,String dpSeqNum) throws SQLException
    {
        Connection conn = gpConnect();
        String query1 = "select  replace(ssn,'-','') from fusion_stage."+tableName+" where dp_sequence_num='"+dpSeqNum+"'";

        System.out.println("GP Query : " + query1);
        PreparedStatement ps = conn.prepareStatement(query1);

        ResultSet rs = ps.executeQuery();
        String records =null;
        while (rs.next())
        {
            records = rs.getString(1);
        }
        conn.close();
        return records;
    }

    public static String removeComma(String a)
    {
        String a2="";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2=a2+element;
        }
        return a2;
    }
}






package com.equifax.cms.fusion.test.IPPages;

import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ImportNewFilePage
{

    WebDriver driver;
    public static String InputExistLayout_1 = null;
    public static String InputExistLayout_2 = null;

    public ImportNewFilePage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    // Input ASCII Fixed Radio Button
    By ASCII_fxd_Rad_Btn = By.id("format1");

    // Input EBCDIC Fixed Radio Button
    By EBCDIC_fxd_Rad_Btn = By.id("format2");

    // Input ASCII Delimited Radio Button
    By ASCII_delim_Rad_Btn = By.id("format3");

    @FindBy(xpath = "//label[contains(text(), 'Process Name:')]")
    WebElement Ele_ProcessID;

    @FindBy(id = "processName")
    WebElement Ele_ProcessName;

    @FindBy(id = "fileType")
    public WebElement Ele_FileType;

    @FindBy(id = "purpose")
    WebElement Ele_Purpose;

    @FindBy(id = "addnewrow")
    WebElement Ele_AddFileBtn;

    @FindBy(id = "filePath")
    WebElement Ele_FilePath;

    @FindBy(xpath = ".//input[@title='ASCII Fixed']")
    WebElement Ele_ASCIIFixed;

    @FindBy(xpath = ".//input[@title='EBCDIC Fixed']")
    WebElement Ele_EBCDIC;

    @FindBy(xpath = ".//input[@title='ASCII Delimited']")
    WebElement Ele_Delimited;

    @FindBy(id = "delimiter")
    WebElement Ele_Delimiter;

    @FindBy(id = "recLen")
    public WebElement Ele_RecLength;

    @FindBy(id = "gpSeqNumStartFrom")
    public WebElement Ele_StrtSeqNum;

    @FindBy(id = "listVirtualArtifacts0.userProvidedName")
    public WebElement OutputTblName;

    @FindBy(id = "newLayoutRadio")
    WebElement Ele_CreateNewLayout;

    @FindBy(id = "importLayoutRadio")
    WebElement Ele_ImportLayout;

    @FindBy(xpath = ".//input[@title='Existing Layout']")
    WebElement Ele_ExistingLayout;

    @FindBy(id = "layoutId1")
    WebElement FixedLayoutRbutton;

    @FindBy(id = "layoutId2")
    WebElement DelLayoutRbutton;

    @FindBy(id = "layoutSearchButton")
    WebElement SearchBtn;

    @FindBy(xpath = ".//button[contains(text(),'Continue')]")
    WebElement ContinueButton;

    @FindBy(id = "addnewrow")
    WebElement addNewrow;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement Back_Btn;

    @FindBy(xpath = "//button[contains(text(),'Save')]")
    WebElement Save_Btn;

    @Step("Get the Process Id")
    public String getProcId()
    {
        String[] a = Ele_ProcessID.getText().split(":");
        System.out.println("Process Id: " + a[1]);
        String value = a[1].trim();
        return value;
    }

    @Step("Clicked back button")
    public void clickBackBtn()
    {
        Back_Btn.click();
    }

    @Step("Clicked Save button")
    public void clickSaveBtn()
    {
        Save_Btn.click();
    }

    @Step("Provided Process Name = \"{0}\"")
    public void processNameField(String procName)
    {
        Ele_ProcessName.sendKeys(procName);
    }

    @Step("Select Type Field : \"{0}\"")
    public void typeField(String FieldType)
    {
        Select selType = new Select(Ele_FileType);
        selType.selectByVisibleText(FieldType);
    }

    @Step("Select Purpose Field : \"{0}\"")
    public void purposeField(String FieldPurpose)
    {
        Select selpor = new Select(Ele_Purpose);
        selpor.selectByVisibleText(FieldPurpose);
    }

    public WebElement filePathField()
    {
        return Ele_FilePath;
    }

    public WebElement aSCIIFixedRbutton()
    {
        return Ele_ASCIIFixed;
    }

    @Step("Provided the file Paths")
    public void filePaths(String path)
    {
        String st[] = StringUtils.split(path, ",");
        driver.findElement(By.xpath(".//*[@id='filePaths0']")).sendKeys(st[0]);
        for (int i = 1; i < st.length; i++)
        {
            Ele_AddFileBtn.click();
            driver.findElement(By.xpath(".//*[@id='filePaths" + i + "']")).sendKeys(st[i]);
        }
    }

    public WebElement eBCDICRbutton()
    {
        return Ele_EBCDIC;
    }

    public WebElement delimitedRbutton()
    {
        return Ele_Delimited;
    }

    public WebElement startSeqNumField()
    {
        return Ele_StrtSeqNum;
    }

    @Step("Provided Output Table Name = \"{0}\"")
    public void inputOutputTblName(String opTblName)
    {
        OutputTblName.clear();
        OutputTblName.sendKeys(opTblName);
    }

    @Step("Click Create New Layout Button")
    public void clickCreateNewLayoutRButton()
    {
        Ele_CreateNewLayout.click();
    }

    public void selectImportLayoutRbutton()
    {
        Ele_ImportLayout.click();
    }

    @Step("Selected the")
    public void existingLayoutRbutton()
    {
        Ele_ExistingLayout.click();
    }

    public WebElement continueButton()
    {
        return ContinueButton;
    }

    @Step("Select File Format Radio Button = \"{0}\"")
    public void SelectFileFormat_Rad_But(String Format)
    {

        if (Format.equalsIgnoreCase("ASCII Fixed"))
        {
            driver.findElement(ASCII_fxd_Rad_Btn).click();
            InputExistLayout_1 = "//div[@id='ASCII_FIXED']//td[contains(text(), '";
            InputExistLayout_2 = "')]/preceding-sibling::td/input";
        } else if (Format.equalsIgnoreCase("EBCDIC Fixed"))
        {
            driver.findElement(EBCDIC_fxd_Rad_Btn).click();
            // div[@id='EBCDIC_FIXED']//td[contains(text(), 'A')]/preceding-sibling::td/input
            InputExistLayout_1 = "//div[@id='EBCDIC_FIXED']//td[contains(text(), '";
            InputExistLayout_2 = "')]/preceding-sibling::td/input";
        } else if (Format.equalsIgnoreCase("ASCII Delimited"))
        {
            driver.findElement(ASCII_delim_Rad_Btn).click();
            // div[@id='ASCII_DELIMITED']//td[contains(text(), 'aasa')]/preceding-sibling::td/input
            InputExistLayout_1 = "//div[@id='ASCII_DELIMITED']//td[contains(text(), '";
            InputExistLayout_2 = "')]/preceding-sibling::td/input";
        }

    }

    @Step("Select Existing Layout Radio Button \"{0}\"")
    public void SelectExisLay_Rad_But(String Exis_Layout_Name)
    {
        // driver.findElement(By.xpath(InputExistLayout_1 + Exis_Layout_Name + InputExistLayout_2)).click();
        driver.findElement(By.xpath("//td[contains(text(),'" + Exis_Layout_Name + "')]/preceding::td[1]/input")).click();
    }

    @Step("Select Delimiter \"{0}\"")
    public void delimiterField(String delimitertype)
    {
        Select selType = new Select(Ele_Delimiter);
        selType.selectByVisibleText(delimitertype);
    }

    @Step("Provide Record Length \"{0}\"")
    public void RecLengthField(String RecLength)
    {

        if (Ele_ASCIIFixed.isSelected())
        {

            Ele_RecLength.sendKeys(RecLength);

        } else if (Ele_EBCDIC.isSelected())
        {

            Ele_RecLength.sendKeys(RecLength);
        } else
        {

            System.out.println("Not required to provide a Record Lenght for ASCII Delimited file");
        }
    }

    @Step("Clear Record Length Field")
    public void clearRecLenghtField()
    {
        Ele_RecLength.clear();
    }

    @Step("Click Existing Layout Radio Button")
    public void clickExistingLayout()
    {

        if (Ele_ASCIIFixed.isSelected())
        {

            FixedLayoutRbutton.click();

        } else if (Ele_Delimited.isSelected())
        {

            DelLayoutRbutton.click();
        }
    }

    @Step("Clicked Search button")
    public void clickSearchBtn()
    {
        // SearchBtn.click();
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", SearchBtn);
    }

    public String getErrMsg()
    {
        String errMsg = driver.findElement(By.xpath("html/body/div[1]/span[1]")).getText().trim();
        if (errMsg.startsWith("Oh no, possible errors in user input:"))
        {
            System.out.println("PASS");
            return "PASS";
        } else
        {
            return "FAIL";
        }
    }

    @Step("Click add new File")
    public void addNewFile()
    {
        addNewrow.click();
    }

    public void selectFileLocation(String location)
    {
        String filePaths[] = location.split(",");
        int j = 1;
        for (int i = 0; i < location.split(",").length; i++)
        {
            String pathLink = "//table[@id='filelocation']/tbody/tr[" + j + "]/td/input";
            driver.findElement(By.xpath(pathLink)).sendKeys(filePaths[i]);
            addNewFile();
            j++;
        }
    }
}

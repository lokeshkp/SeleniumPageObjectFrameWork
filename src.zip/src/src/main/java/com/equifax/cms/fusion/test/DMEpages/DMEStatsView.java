package com.equifax.cms.fusion.test.DMEpages;

import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;

import ru.yandex.qatools.allure.annotations.Step;

public class DMEStatsView
{
    WebDriver driver;

    public DMEStatsView(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);

    }

    @Step("Fetched Process Source Input Table Name")
    public String getInputTableNameDME()
    {
        String dmeInputTableName = driver.findElement(By.xpath(".//div[contains(text(),'Process source input:')]")).getText();
        return removeColon(dmeInputTableName);
    }

    @Step("Fetched Process Source Input Table Count")
    public Long getInputTableCountDME()
    {
        String dmeInputTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Process source input:')]/following::div[1]")).getText();
        return Long.parseLong(dmeInputTableCount);
    }

    @Step("Fetched Source Match data Table Name")
    public String getSourceMatchTableNameDME()
    {
        String dmeSourceMatchTableName = driver.findElement(By.xpath(".//div[contains(text(),'Source match data')]")).getText();
        return removeColon(dmeSourceMatchTableName);
    }

    @Step("Fetched Source Match data Table Count")
    public Long getSourceMatchTableCountDME()
    {
        String dmeSourceMatchTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Source match data')]/following::div[1]")).getText();
        return Long.parseLong(dmeSourceMatchTableCount);
    }

    @Step("Record count written into the csv file is: ")
    public Long getRecordCountcsvFileDME()
    {
        String dmeRecCountcsvFile = driver.findElement(By.xpath(".//div[contains(text(),'Records Written To')]/following::div[1]")).getText();
        return Long.parseLong(dmeRecCountcsvFile);
    }

    @Step("Fetched Data Menu STEP_FLAG table name")
    public String getStepFlagTableNameDME()
    {
        String dmeStepFlagTableName = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu STEP_FLAG Table')]/following::div[1]")).getText();
        return (dmeStepFlagTableName);
    }

    @Step("Fetched Data Menu STEP_FLAG table count")
    public Long getStepFlagTableCountDME()
    {
        String dmeStepFlagTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu STEP_FLAG Table')]/following::div[4]"))
                .getText();
        return Long.parseLong(dmeStepFlagTableCount);
    }

    @Step("Fetched Data Menu Header table name")
    public String getHeaderTableNameDME()
    {
        String dmeHeaderTableName = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu HEADER Table')]/following::div[1]")).getText();
        return (dmeHeaderTableName);
    }

    @Step("Fetched Data Menu Header table count")
    public Long getHeaderTableCountDME()
    {
        String dmeHeaderTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu HEADER Table')]/following::div[4]")).getText();
        return Long.parseLong(removeComma(dmeHeaderTableCount));
    }

    @Step("Fetched Data Menu INQUIRY POST table name")
    public String getInqPostTableNameDME()
    {
        String dmeHeaderTableName = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu INQUIRYPOST Table')]/following::div[1]")).getText();
        return (dmeHeaderTableName);
    }

    @Step("Fetched Data Menu Header INQUIRY POST table count")
    public Long getInqPostTableCountDME()
    {
        String dmeHeaderTableCount = driver.findElement(By.xpath(".//div[contains(text(),'Datamenu INQUIRYPOST Table')]/following::div[4]"))
                .getText();
        return Long.parseLong(removeComma(dmeHeaderTableCount));
    }

    @Step("Get LCR Table Name for JXH_P3A48EL0COPY")
    public String getLCRTableName()
    {
        return driver.findElement(By.xpath(".//*[contains(text(),'_DM_GPLOAD_JXH_P3A48EL0COPY_LCRREC')]")).getText();
    }

    @Step("Get LCR Table Count for JXH_P3A48EL0COPY")
    public Long getLCRTableCountDisplayed()
    {
        return Long.parseLong(removeComma(
                driver.findElement(By.xpath(".//*[contains(text(),'_DM_GPLOAD_JXH_P3A48EL0COPY_LCRREC')]/following::div[1]/div[2]")).getText()));
    }

    @Step("Get xml contents")
    public String getXMLContentsDME()
    {
        String xmlContent = driver.findElement(By.xpath(".//*[@id='popupContent']/div/div")).getText();
        return xmlContent;
    }

    public static String removeColon(String a)
    {
        String[] a1 = a.split(":");
        return a1[0].trim();
    }

    @Step("Check if  Score Model Table Created")
    public boolean isScoreModelTableCreated()
    {
        try
        {
            driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
            String scoreModel = driver.findElement(By.xpath(".//*[contains(text(),'_DM_GPLOAD_MODEL_')]")).getText();
            driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
            return true;
        } catch (org.openqa.selenium.NoSuchElementException e)
        {
            return false;
        }
    }

    public void click_JET_JOB_XML()
    {
        driver.findElement(By.linkText("JET_JOB_XML")).click();
    }

    public String getJET_JOB_XML_Content()
    {
        return driver.findElement(By.xpath(".//div[@class='cmsContent']/pre/div")).getText();
    }

    public String removeComma(String a)
    {
        String a2 = "";
        String[] a1 = a.split(",");
        for (String element : a1)
        {
            a2 = a2 + element;
        }
        return a2;
    }

}

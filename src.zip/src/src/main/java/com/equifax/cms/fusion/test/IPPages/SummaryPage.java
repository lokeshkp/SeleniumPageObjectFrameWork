package com.equifax.cms.fusion.test.IPPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class SummaryPage
{

    WebDriver driver;

    public SummaryPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
    }

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/span[1]")
    WebElement ProcName;

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/table[1]/tbody/tr[1]/td/span")
    WebElement FileName;

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/table[3]/tbody/tr[1]/td[2]")
    WebElement FileType;

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/table[3]/tbody/tr[2]/td[2]")
    WebElement FilePurpose;

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/table[3]/tbody/tr[3]/td[2]")
    WebElement FileFormat;

    @FindBy(xpath = "html/body/div[1]/div[3]/div[3]/div/form/table[3]/tbody/tr[6]/td[2]")
    WebElement RecLength;

    @FindBy(xpath = "//a[text()='File1']")
    WebElement inputFileRef;

    @FindBy(id = "submitButton")
    WebElement SubmitButton;

    @Step("Process Name in the Summary is ")
    public String procNameSumry()
    {
        String[] procName = ProcName.getText().trim().split(":");
        return procName[3];
    }

    @Step("File Name in the Summary is ")
    public String fileNameSummary()
    {
        String fileName = FileName.getText().trim();
        return fileName;
    }

    @Step("File Type in the Summary is ")
    public String fileTypeSummary()
    {
        String fileType = FileType.getText().trim();
        return fileType;
    }

    @Step("File Purpose in the Summary is ")
    public String filePurposeSummary()
    {
        String filePurpose = FilePurpose.getText().trim();
        return filePurpose;
    }

    @Step("File Format in the Summary is ")
    public String fileFormatSumry()
    {
        String fileFormat = FileFormat.getText().trim();
        return fileFormat;
    }

    @Step("File Format in the Summary is ")
    public String recLengthSumry()
    {
        String recLength = RecLength.getText().trim();
        return recLength;
    }

    @Step("Click Submit button on Summary Screen")
    public void clickSubmitButton()
    {
        SubmitButton.click();
    }

    @Step("Click Input File Reference on Summary Screen")
    public void clickSInputFileRef()
    {
        inputFileRef.click();
    }

    @Step("Get text for datatable")
    public String getTextFromTableForLayoutPreview()
    {
        String value = driver.findElement(By.xpath(".//*[@id='testDialog']/table[2]/thead/tr/th")).getText();
        return value;
    }

    @Step("Get fieldTypes in summary table")
    public boolean getFieldTypesFromSummaryTable(int idNo)
    {
        boolean flag = false;
        WebElement ele = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[" + idNo + "]/td[1]"));
        // try
        // {
        // WebElement ele = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[" + idNo + "]/td[1]"));
        // if (isElementPresent(By.xpath("//table[@id='fieldTable']/tbody/tr[" + idNo + "]/td[1][contains(text(),'Other')]")))
        // {
        // flag = true;
        // }
        // } catch (NoSuchElementException e)
        // {
        // return false;
        // }
        return flag;

    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public List<String> getSummaryFields()
    {
        driver.switchTo().frame(0);
        List<String> values = new ArrayList<>();
        int i = 1;
        List<WebElement> ele = driver.findElements(By
                .xpath("//div[@id='model-box1']/div/div[3]/div[@class='defineLayout']/table[@id='fieldTable']/tbody/tr"));
        while (i <= ele.size())
        {
            String textField = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[" + i + "]/td")).getText();
            values.add(textField);
            i++;
        }
        return values;
    }

    public List<String> splitField(List<String> values)
    {
        List<String> newVal = new ArrayList<>();

        String val = "";
        for (int i = 0; i < values.size(); i++)
        {
            val = values.get(i).toUpperCase();
            val = val.replace(" ", "_");
            newVal.add(val);
            // values.get(i).replace(" ", "_");
            // String split[] = arrFields[i].split("_");

        }
        return newVal;
    }
}

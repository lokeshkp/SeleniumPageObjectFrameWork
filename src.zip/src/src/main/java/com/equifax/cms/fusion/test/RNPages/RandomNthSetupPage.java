package com.equifax.cms.fusion.test.RNPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.internal.WebElementToJsonConverter;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import ru.yandex.qatools.allure.annotations.Step;

public class RandomNthSetupPage {

	WebDriver driver;
		
	public RandomNthSetupPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	}
	
	@FindBy(xpath = "//label[contains(text(), 'Process Name:')]/span")
	WebElement Ele_ProcessID;
	
	@FindBy(id = "name")
	public WebElement Ele_ProcessName;
	
	@FindBy(id = "fromProcessId")
	WebElement Ele_Process;
	
	@FindBy(id = "itemTableId")
	WebElement Ele_Data;
	
	@FindBy(id = "listVirtualArtifacts0.userProvidedName")
	public WebElement Ele_OutputTableName;
	
	@FindBy(id = "numberOutput")
	public WebElement Ele_NumbertoOutput;
	
	@FindBy(xpath = ".//input[@value='Save']")
	WebElement SaveButton;
	
	@FindBy(xpath = ".//*[@id='rnForm']/div/div[7]/input[2]")
	WebElement SubmitButton;
	
	@FindBy(id = "textMsg")
	WebElement txtMessage;
	
	@FindBy(id = "erMsg")
	WebElement errorMessage;
	
	@FindBy(xpath = ".//*[@id='contentArea']/h2")
	WebElement pageHeader;
	
	@Step("Fetched Page Header For Random Nth Process")
	public String getPageHeader() {
		return pageHeader.getText();
	}
	
	@Step("Fetched Error Message for FFF Process")
	public String getErrorMessage() {
		return errorMessage.getText();
	}
	
	@Step("Fetched Error Message for FFF Process")
	public String getTextMessage() {
		return txtMessage.getText();
	}
	
	public WebElement ProcessID(){
		return Ele_ProcessID;
	}
	
	@Step ("Provided the Process Name field = \"{0}\"")
	public void processNameField(String processName){
		Ele_ProcessName.sendKeys(processName);
	}
	
	@Step ("Selected the process field = \"{0}\"")
	public void selectProcessField(String process) throws InterruptedException{
		Select selType = new Select(Ele_Process);
		selType.selectByVisibleText(process);
		Thread.sleep(2000);
	}
	
	@Step ("Selected the Data field = \"{0}\"")
	public void selectDataField(String Data){
		Select selpor = new Select(Ele_Data);
		selpor.selectByVisibleText(Data);
	}
	
	@Step ("Output Table Name field = \"{0}\"")
	public void OutputTableNameField(String opTblName){
		Ele_OutputTableName.clear();
		Ele_OutputTableName.sendKeys(opTblName);
	}
	
	@Step ("Provided the Number to Output field value = \"{0}\"")
	public void numberToOutputField(String NotoOutput){
		Ele_NumbertoOutput.clear();
		Ele_NumbertoOutput.sendKeys(NotoOutput);
	}
	
	@Step ("Clicked Save Button")
	public void clickSaveButton(){
		SaveButton.click();
	}
	
	@Step ("Clicked Submit Button")
	public void clickSubmitButton(){
		SubmitButton.click();
	}
	
	@Step("IP process as Input")
	public boolean ipAsinput(){
		return driver.findElement(By.xpath("//input[@disabled='disabled']")).isEnabled();
	}
}

package com.equifax.cms.fusion.test.DMPages;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.poi.poifs.filesystem.OfficeXmlFileException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
//import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
//import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class APmodulePage {

	private static WebElement element = null;
	WebDriver driver;
	public Select selType;

	public APmodulePage(WebDriver driver) {

		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
	}

	@FindBy(id = "mode")
	public WebElement Ele_useProdAPmodulesOnly;

	@FindBy(id = "apModuleList1")
	WebElement Ele_apModules;

	@FindBy(xpath = "//img[@title='Remove']")
	WebElement APmoduleRemoveButton;

	@FindBy(id = "addModule")
	WebElement AddModuleButton;

	@FindBy(xpath = "(.//a[contains(text(),'OK')])[2]")
	WebElement Alert_ChangeApMod;

	@FindBy(xpath = "(//img[@title='Remove'])[2]")
	WebElement Remove_Img_2;

	@FindBy(xpath = "//a[contains(text(),'Back')]")
	WebElement BackBtn;

	@FindBy(xpath = "(//input[@name='submitButton'])[2]")
	WebElement ContinueButton;

	@FindBy(xpath = ".//*[@id='parentSelectBlock0']/table/tbody/tr[1]/td[2]/img")
	WebElement deleteFirstModule;

	@FindBy(id = "addButton")
	WebElement AddAP_Mod_Btn;

	@FindBy(id = "dropKeep_0")
	WebElement Drop_Opt;

	@FindBy(id = "dropKeep_1")
	WebElement Tag_Opt;

	@FindBy(id = "dropKeep_2")
	WebElement Rej_Opt;

	@FindBy(id = "mode")
	WebElement ProdModOnly_ChckBox;

	@FindBy(id = "btnApLoadDetail")
	WebElement LoadApMod;

	@FindBy(id = "saveButton")
	WebElement SaveApMod_Btn;

	@FindBy(id = "removeButton")
	WebElement AddScore_Btn;

	@FindBy(id = "scoreSaveButton")
	WebElement scMdlSaveBtn;

	@FindBy(id = "numberOfAccepts")
	WebElement NumPerAccCode;

	@FindBy(id = "numberOfRejects")
	WebElement NumPerRejCode;

	@FindBy(id = "holdForMove")
	WebElement HoldMoveStment;

	@Step("Clicked Load button to load AP Module")
	public void clickLoadApMod() {
		LoadApMod.click();
	}

	@Step("Provided the number per accept code value = \"{0}\"")
	public void numPerAccValue(String noPerAcc) {
		if (!"NA".equalsIgnoreCase(noPerAcc)) {
			NumPerAccCode.sendKeys(noPerAcc);
		}
	}

	@Step("Provided the number per reject code value = \"{0}\"")
	public void numPerRejValue(String noPerRej) {
		if (!"NA".equalsIgnoreCase(noPerRej)) {
			NumPerRejCode.sendKeys(noPerRej);
		}
	}

	@Step("Checked the Hold for additional data append via Move Statement = \"{0}\"")
	public void checkHoldMvSt(String movSt) {
		if ("ON".equalsIgnoreCase(movSt)) {
			HoldMoveStment.click();
		}
	}

	@Step("Clicked AP Module button")
	public void clickApModBtn() {
		AddAP_Mod_Btn.click();
	}

	@Step("Check the Production module only field")
	public void checkProdModOnly() {
		ProdModOnly_ChckBox.click();
	}

	@Step("Clicked Score Model Button")
	public void clickScoreMdlBtn() {
		AddScore_Btn.click();
	}

	@Step("Clicked Score Model Save button")
	public void clickScMdlSaveBtn() {
		scMdlSaveBtn.click();
	}

	@Step("Select the Score Models in AP Module screen = \"{0}\"")
	public void selScoreModel(String scoreMdl) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(scoreMdl)) {
			StringTokenizer st1 = new StringTokenizer(scoreMdl, ";");
			while (st1.hasMoreElements()) {
				String a = st1.nextToken();
				StringTokenizer st2 = new StringTokenizer(a, ",");
				if (st2.countTokens() == 2) {
					while (st2.hasMoreElements()) {
						Thread.sleep(2000);
						clickScoreMdlBtn();
						driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForScoreModule']/div")).click();
						Thread.sleep(2000);
						JavascriptExecutor js = (JavascriptExecutor) driver;
						js.executeScript(
								"$('#jqxComboForScoreModule').jqxComboBox('selectItem','" + st2.nextToken() + "')");
						Thread.sleep(2000);
						driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForScoreModule']/div")).click();
						Thread.sleep(3000);
						clickLoadApMod();
						Thread.sleep(2000);
						selRejOptions(st2.nextToken());
						clickScMdlSaveBtn();
					}
				}
			}
		}
	}

	@Step("Clicked Save button on Edit AP Module")
	public void clickSaveBtn() {
		SaveApMod_Btn.click();
	}

	@Step("Selected the Reject Options along with AP Module = \"{0}\"")
	public void selRejOptions(String rejOpt) 	{
		if ("Drop".equalsIgnoreCase(rejOpt)) {
			Drop_Opt.click();
		} else if ("Tag".equalsIgnoreCase(rejOpt)) {
			Tag_Opt.click();
		} else if ("Reject".equalsIgnoreCase(rejOpt)) {
			Rej_Opt.click();
		}
	}

	@Step("Selected AP Modules and loaded = \"{0}\"")
	public void selAPmodWithCritRej(String apMod) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(apMod)) {
			StringTokenizer st = new StringTokenizer(apMod, ";");
			while (st.hasMoreElements()) {
				String a = st.nextToken();
				StringTokenizer st2 = new StringTokenizer(a, ",");
				// AGECRIT, JXH_MULTILEVEL
				if (st2.countTokens() == 2 || st2.countTokens() == 3) {
					while (st2.hasMoreElements()) {
						Thread.sleep(2000);
						clickApModBtn();
						Thread.sleep(2000);
						JavascriptExecutor js = (JavascriptExecutor) driver;
						// js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('val','"
						// + st2.nextToken() + "')");
						driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
						Thread.sleep(2000);
						js.executeScript(
								"$('#jqxComboForAutopilot').jqxComboBox('selectItem','" + st2.nextToken() + "'); ");
						// js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('val','"
						// + st2.nextToken() + "'); ");
						Thread.sleep(2000);
						driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
						Thread.sleep(4000);
						clickLoadApMod();
						Thread.sleep(2000);
						selRejOptions(st2.nextToken());
						try {
							driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
							if (driver.findElement(By.xpath(".//*[@id='moduleDependencies']")).isDisplayed()) {
								driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForExtFile0']"))
										.click();
								Thread.sleep(2000);
								JavascriptExecutor js1 = (JavascriptExecutor) driver;
								js1.executeScript("$('#jqxComboForExtFile0').jqxComboBox('selectItem','"
										+ st2.nextToken() + "'); ");
								Thread.sleep(2000);
								driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForExtFile0']"))
										.click();
								Thread.sleep(2000);
								clickSaveBtn();
							}
						} catch (org.openqa.selenium.NoSuchElementException e) {
							clickSaveBtn();
						}
					}
				} else if (st2.countTokens() == 4) {
					while (st2.hasMoreElements()) {
						Thread.sleep(2000);
						clickApModBtn();
						Thread.sleep(2000);
						JavascriptExecutor js = (JavascriptExecutor) driver;
						driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
						Thread.sleep(2000);
						js.executeScript(
								"$('#jqxComboForAutopilot').jqxComboBox('selectItem','" + st2.nextToken() + "'); ");
						Thread.sleep(2000);
						driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
						Thread.sleep(4000);
						clickLoadApMod();
						Thread.sleep(2000);
						for (int i = 0; i < 3; i++) {
							driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForExtFile" + i + "']/div"))
									.click();
							Thread.sleep(2000);
							js.executeScript("$('#jqxComboForExtFile" + i + "').jqxComboBox('selectItem','"
									+ st2.nextToken() + "'); ");
							Thread.sleep(2000);
							driver.findElement(By.xpath(".//*[@id='dropdownlistArrowjqxComboForExtFile" + i + "']/div"))
									.click();
							Thread.sleep(2000);
						}
						clickSaveBtn();
					}
				}
			}
		}
	}

	@Step("Selected the Non Criteria AP Module = \"{0}\"")
	public void selApModNonCriteria(String apMod) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(apMod)) {
			StringTokenizer st = new StringTokenizer(apMod, ",");
			while (st.hasMoreTokens()) {
				Thread.sleep(3000);
				clickApModBtn();
				Thread.sleep(2000);
				JavascriptExecutor js = (JavascriptExecutor) driver;
				// js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('val','"
				// + st2.nextToken() + "')");
				driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
				Thread.sleep(2000);
				js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('selectItem','" + st.nextToken() + "'); ");
				// js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('val','"
				// + st2.nextToken() + "'); ");
				Thread.sleep(2000);
				driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
				Thread.sleep(5000);
				clickLoadApMod();
				Thread.sleep(2000);
				clickSaveBtn();
			}
		}
	}
	
	   @Step("Selected the Non Criteria AP Module = \"{0}\"")
	    public void selApModulesNonCriteria(String apMod,String externalTables,String outputs,String userParams) throws InterruptedException {
	        if (!"NA".equalsIgnoreCase(apMod)) {
	            StringTokenizer st = new StringTokenizer(apMod, ",");
	            while (st.hasMoreTokens()) {
	                Thread.sleep(3000);
	                clickApModBtn();
	                Thread.sleep(2000);
	                JavascriptExecutor js = (JavascriptExecutor) driver;
	                // js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('val','"
	                // + st2.nextToken() + "')");
	                driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
	                Thread.sleep(1000);
	                js.executeScript("$('#jqxComboForAutopilot').jqxComboBox('selectItem','" + st.nextToken() + "'); ");
	                Thread.sleep(1000);
	                driver.findElement(By.xpath("//div[@id='dropdownlistArrowjqxComboForAutopilot']")).click();
	                Thread.sleep(2000);
	                clickLoadApMod();
	                Thread.sleep(2000);
	                
	                if(!"NA".equalsIgnoreCase(externalTables)){
	                    String[] st1 = externalTables.split(",");
	                    int i=0;
	                    while (i < st1.length) {
	                        //driver.findElement(By.xpath("//div[@id='dropdownlistContentjqxComboForExtFile" + i + "']"));
	                    	 driver.findElement(By.xpath("//div[@id='dropdownlistContentjqxComboForExtFile" + i + "']")).click();
	                       
	                        Thread.sleep(1000);
	                        //Hardcoded the value as space is not working for jqwidgets selection
	                        //js.executeScript("$('#jqxComboForExtFile"+i+"').jqxComboBox('selectItem','FOR_AUTOMATION_ONLY'); ");
	                        js.executeScript("$('#jqxComboForExtFile"+i+"').jqxComboBox('selectItem','"+st1[i]+"');");
	                        driver.findElement(By.xpath("//div[@id='dropdownlistContentjqxComboForExtFile" + i + "']")).click();
	                        Thread.sleep(1000);
	                        i++;
	                    }
	                }
	                
 	                if (!"NA".equalsIgnoreCase(outputs))
	                {
 	                    String[] st1 = outputs.split(",");
	                    int i=0;
                        while (i < st1.length)
	                    {
	                        driver.findElement(By.xpath(".//*[@id='userProvidedName"+i+"']")).clear();
	                        driver.findElement(By.xpath(".//*[@id='userProvidedName"+i+"']")).sendKeys(st1[i]);
	                        i++;
	                    }
	                }
	                
	                if (!"NA".equalsIgnoreCase(userParams))
	                {
	                    String delim = ",";
	                    StringTokenizer dep = new StringTokenizer(userParams, delim);
	                    int i = 7;
	                    while (dep.hasMoreTokens())
	                    {
	                        driver.findElement(By.xpath(".//*[@id='depValue"+i+"']")).clear();
                            driver.findElement(By.xpath(".//*[@id='depValue"+i+"']")).sendKeys(dep.nextToken().trim());
	                        i++;
	                    }
	                }
	                
	                clickSaveBtn();
	            }
	        }
	    }

	@Step("Click Use PROD Only AP Module Check Box")
	public void clickUseProdAPmoduleOnly(String prod) {
		if ("UNSELECT".equalsIgnoreCase(prod)) {
			Ele_useProdAPmodulesOnly.click();
		} else if ("SELECT".equalsIgnoreCase(prod)) {
			System.out.println("Its already selected....");
		} else {
			System.out.println("Provide proper input in input excel sheet..");
		}
	}

	@Step("Click Auto Pilot Remove Button")
	public void clickAPmodRemoveButton() {
		APmoduleRemoveButton.click();
	}

	@Step("Click Add Auto Pilot Module Button")
	public void clickAddAPmodButton() {
		AddModuleButton.click();
	}

	@Step("Removed the second AP module")
	public void remove2ndAPmod() {
		Remove_Img_2.click();
	}

	@Step("Clicked on Back button")
	public void clickBackBtn() {
		BackBtn.click();
	}

	@Step("Click Continue Button on AP Module Screen")
	public void clickContinueButton() {
		ContinueButton.click();
	}

	/*
	 * @Step("Select Auto Pilot Module :  \"{0}\"")
	 * 
	 * @Deprecated public void selectAPModuleNonCriteria(String splitString)
	 * throws InterruptedException { if (!"NA".equalsIgnoreCase(splitString)) {
	 * String delims = ","; StringTokenizer st = new
	 * StringTokenizer(splitString, delims); int i = 0; while
	 * (st.hasMoreElements()) { final String dynamicXPath =
	 * ".//*[@id='dropdownlistContentselectBlock" + i + "']/input";
	 * System.out.println("dynamicID : " + dynamicXPath); if (i == 0 &&
	 * st.countTokens() == 1) { selVisibleText(dd_APModules(dynamicXPath),
	 * st.nextToken()); break; } else if (i == 0) {
	 * selVisibleText(dd_APModules(dynamicXPath), st.nextToken()); } else {
	 * clickAddAPmodButton(); Thread.sleep(3000); (new WebDriverWait(driver,
	 * 10)).until(ExpectedConditions.presenceOfElementLocated(By.xpath(
	 * dynamicXPath))); Wait<WebDriver> wait = new FluentWait<WebDriver>(driver)
	 * .withTimeout(10, TimeUnit.SECONDS) .pollingEvery(5, TimeUnit.SECONDS)
	 * .ignoring(NoSuchElementException.class); wait.until(new
	 * Function<WebDriver, WebElement>() {
	 * 
	 * @Override public WebElement apply(WebDriver driver) { return
	 * driver.findElement(By.xpath(dynamicXPath)); } }); String valueToSelect =
	 * st.nextToken(); WebElement elem = dd_APModules(dynamicXPath);
	 * selVisibleText(elem, valueToSelect.trim()); } i++; } } }
	 */

	@Step("Select Auto Pilot Module :  \"{0}\"")
	public void selectAPModuleNonCriteria(String apModule) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(apModule)) {
			String[] splitStr = apModule.split(",");
			int i = 0;
			while (i < splitStr.length) {
				if (i >= 1) {
					clickAddAPmodButton();
				}
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("$('#selectBlock" + i + "').jqxComboBox('val','" + splitStr[i] + "')");
				Thread.sleep(500);
				i++;
			}
		}
	}

	@Step("Select Auto Pilot Module :  \"{0}\"")
	public void selectAPModuleNonCriteriaAfterDelete(String apModule) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(apModule)) {
			String[] splitStr = apModule.split(",");
			int i = 1;
			while (i <= splitStr.length) {
				if (i >= 2) {
					clickAddAPmodButton();
				}
				JavascriptExecutor js = (JavascriptExecutor) driver;
				js.executeScript("$('#selectBlock" + i + "').jqxComboBox('val','" + splitStr[i - 1] + "')");
				Thread.sleep(500);
				i++;
			}
		}
	}

	@Step("Select Auto Pilot Module :  \"{0}\"")
	public void selectAPModuleNonCriteria1(String splitString) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(splitString)) {
			String delims = ",";
			StringTokenizer st = new StringTokenizer(splitString, delims);
			int i = 0;
			while (st.hasMoreElements()) {
				final String dynamicXPath = ".//*[@id='dropdownlistArrowselectBlock" + i + "']/div";
				System.out.println("dynamicID : " + dynamicXPath);
				String value = st.nextToken();
				if (i == 0 && st.countTokens() == 1) {
					driver.findElement(By.xpath(dynamicXPath)).click();
					driver.findElement(By.xpath(".//*[@id='dropdownlistContentselectBlock" + i + "']/input"))
							.sendKeys(value);
					// driver.findElement(By.xpath("(//b[contains(text(),'"+value+"')])[1]")).click();
					driver.findElement(By.xpath(dynamicXPath)).click();
					break;
				} else if (i == 0) {
					driver.findElement(By.xpath(dynamicXPath)).click();
					driver.findElement(By.xpath(".//*[@id='dropdownlistContentselectBlock" + i + "']/input"))
							.sendKeys(value);
					// driver.findElement(By.xpath("(//b[contains(text(),'"+value+"')])[1]")).click();
					driver.findElement(By.xpath(dynamicXPath)).click();
				} else {
					Thread.sleep(5000);
					clickAddAPmodButton();
					driver.findElement(By.xpath(dynamicXPath)).click();
					driver.findElement(By.xpath(".//*[@id='dropdownlistContentselectBlock" + i + "']/input"))
							.sendKeys(value);
					// driver.findElement(By.xpath("(//b[contains(text(),'"+value+"')])[1]")).click();
					driver.findElement(By.xpath(dynamicXPath)).click();
				}
				i++;
			}
		}
	}

	@Step("Select Auto Pilot Module :  \"{0}\"")
	public void selectAPModuleNonCriteria2(String apModule) throws InterruptedException {
		if (!"NA".equalsIgnoreCase(apModule)) {
			JavascriptExecutor js = (JavascriptExecutor) driver;
			js.executeScript("$('#selectBlock0').jqxComboBox('val','" + apModule + "')");
			Thread.sleep(500);
		}
	}

	@Step("Select Visible Text  \"{0}\"")
	public static void selVisibleText(WebElement elem, String s) {
		new Select(elem).selectByVisibleText(s);
	}

	@Step("Select AP Module")
	public WebElement dd_APModules(String dynamicXPath) {
		element = driver.findElement(By.xpath(dynamicXPath));
		return element;
	}

	@Step("Click the Alert message")
	public void clickAlert() {
		Alert_ChangeApMod.click();
	}

	@Step("Delete the first AP Module")
	public void deleteFirstModule() {
		deleteFirstModule.click();
	}

	@Step("Status updated from Error to Ready in the grid")
	public void errorToReadyInGrid() throws InterruptedException {
		try{
			int i = 0;
			String path = driver.findElement(By.xpath(".//*[@id='row" + i + "ap-score-grid']/div[6]/div/span")).getText();
			driver.manage().timeouts().implicitlyWait(0, TimeUnit.SECONDS);
			while (path != null) {
				path = driver.findElement(By.xpath(".//*[@id='row" + i + "ap-score-grid']/div[6]/div/span")).getText(); 	
				if (path.equalsIgnoreCase("ERROR")) {
					Thread.sleep(3000);
					driver.findElement(
							By.xpath(".//*[@id='row" + i + "ap-score-grid']/div[6]/following::div[1]/input[@id='btnEdit']"))
							.click();
					Thread.sleep(3000);
					clickScMdlSaveBtn();
				}
				i++;
			}
		} catch (org.openqa.selenium.NoSuchElementException e){
			
		}
	}
}

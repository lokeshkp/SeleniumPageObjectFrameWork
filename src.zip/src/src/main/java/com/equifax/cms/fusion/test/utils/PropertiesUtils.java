package com.equifax.cms.fusion.test.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Properties;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class PropertiesUtils {

	private static final String ENVIRONMENT = "env";
	private static Properties properties = new Properties();
	private static String testEnvironment;

	private static final Logger LOGGER = LoggerFactory.getLogger(PropertiesUtils.class);

	static {
		try {
			ClassLoader classLoader = PropertiesUtils.class.getClassLoader();
			File file = new File(classLoader.getResource("config.properties").getFile());
			InputStream input = new FileInputStream(file);
			properties.load(input);
		} catch (Exception e) {
			System.out.printf(">> Unable to load property file [ %s ]\n" , e.getMessage());
		}
	}

	public static String getProperty(final String key) {

		String env = getEnvironment();
		return properties.getProperty(env + "." + key);
	}
	
	public static void setProperty(String key,String value){
		String env = getEnvironment();
		properties.setProperty(env + "." + key, value);
		FileOutputStream out;
		ClassLoader classLoader = PropertiesUtils.class.getClassLoader();
		try {
			out = new FileOutputStream(new File(classLoader.getResource("config.properties").getFile()));
			properties.store(out, null);
			out.close();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}
	
	public static String getEnvOnly() {
		return properties.getProperty(ENVIRONMENT);	
	}

	public static String getEnvironment() {

		if (null == testEnvironment) {
			testEnvironment = System.getenv(ENVIRONMENT);
			LOGGER.debug("Testing environment loaded from System - {}", testEnvironment);

			if (null == testEnvironment) {
				testEnvironment = properties.getProperty(ENVIRONMENT);
				LOGGER.debug("Testing environment loaded from property file. - {}", testEnvironment);
			}
		}
		return testEnvironment;
	}
}

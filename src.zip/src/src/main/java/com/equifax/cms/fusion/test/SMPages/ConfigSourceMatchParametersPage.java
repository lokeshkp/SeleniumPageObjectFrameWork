package com.equifax.cms.fusion.test.SMPages;

import static org.junit.Assert.assertThat;

import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;

public class ConfigSourceMatchParametersPage
{

    WebDriver driver;

    public ConfigSourceMatchParametersPage(WebDriver driver)
    {

        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        PageFactory.initElements(driver, this);

        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
    }

    @FindBy(id = "smName")
    WebElement Ele_ProcessName;

    @FindBy(id = "fromProcessId")
    WebElement Ele_Process;

    @FindBy(xpath = ".//*[@id='jobId']/label")
    WebElement Ele_Job;

    @FindBy(id = "jobNumbersMap")
    WebElement Ele_JobNo;

    @FindBy(id = "itemTableId")
    WebElement Ele_Data;

    @FindBy(id = "addButton")
    WebElement AddButton;

    //@FindBy(id = "listVirtualArtifacts0.userProvidedName")
    @FindBy(id = "listVirtualArtifacts0.userProvidedName")    
    public WebElement Ele_OutputTableName;

   @FindBy(xpath = ".//*[@id='smForm']/div[8]/input[1]")
   WebElement SaveButton;

    @FindBy(id = "submitButton")
    WebElement SubmitButton;

    @FindBy(id = "textMsg")
    WebElement textMsg;

    public String getErrorMessage()
    {
        return textMsg.getText();
    }

    public String getSMprocId(String procName)
    {
        String assignedName = driver.findElement(By.xpath("//form[@id='smForm']//input[@id='assignedId']")).getAttribute("value");
        String completeProcessName = assignedName + "_" + procName;
        return completeProcessName;
    }

    public String getSMprocIdColon(String procName)
    {
        String assignedName = driver.findElement(By.xpath("//form[@id='smForm']//input[@id='assignedId']")).getAttribute("value");
        String completeProcessName = assignedName + ":" + procName;
        return completeProcessName;
    }
    @Step("Generated Final Process Name")
    public String getFinalProcessNameColon_SpaceForSM(String procName)
    {
        String assignedName = driver.findElement(By.xpath("//form[@id='smForm']//input[@id='assignedId']")).getAttribute("value");
        System.out.println("Generated Process Name :" + assignedName.trim() + ": " + procName);
        String completeProcessName = assignedName + ":" + procName;
        return completeProcessName;
    }
    public String getFinalProcessNameForInput(String procName)
    {
        String[] processNameArr=procName.split(":");

        String completeProcessName = processNameArr[0] + "_" + processNameArr[1];
        return completeProcessName;
    }


    @Step("Provided Process Name = \"{0}\"")
    public void processNameField(String procName)
    {
        Ele_ProcessName.sendKeys(procName);
    }

    @Step("Select Process : \"{0}\"")
    public void SelectProcessField(String processName)
    {
        Select selType = new Select(Ele_Process);
        selType.selectByVisibleText(processName);
    }

    @Step("Check the Job No = \"{0}\"")
    public String getJobNo()
    {
        return Ele_Job.getText();
    }

    @Step("Selected the Job No = \"{0}\"")
    public void selJobNo(String jobNo)
    {
        if (!"NA".equalsIgnoreCase(jobNo))
        {
            Select sel = new Select(Ele_JobNo);
            sel.selectByVisibleText(jobNo);
        }
    }

    @Step("Select Data : \"{0}\"")
    public void SelectDataField(String data) throws InterruptedException
    {
        Select selpor = new Select(Ele_Data);
        Thread.sleep(7000);
        selpor.selectByVisibleText(data);
        Thread.sleep(7000);
    }

    @Step("Clear Output Table Name")
    public void ClearOutputTableName()
    {
        Ele_OutputTableName.clear();
    }

    @Step("Provide Output Table Name : \"{0}\"")
    public void InputOutputTableName(String tableName)
    {
        Ele_OutputTableName.clear();
        Ele_OutputTableName.sendKeys(tableName);
    }

    @Step("Default Output Table Name ")
    public String getDefaultTableName()
    {
        return Ele_OutputTableName.getAttribute("value");
    }

    @Step("Click ADD Button")
    public void ClickAddButton() throws InterruptedException
    {
        AddButton.click();
        Thread.sleep(5000);
    }

    @Step("Click SAVE Button")
    public void ClickSaveButton()
    {
        SaveButton.click();
    }

    @Step("Click SUBMIT Button")
    public void ClickSubmitButton()
    {
        SubmitButton.click();
    }

    public String firstProc(String proc){
        String[] a = proc.split(",");
        return a[0];
    }
    
    @Step("Select Process : \"{0}\" and Select Data : \"{1}\"")
    public void selectTokenizeProcessNamefromInput(String InputProcess, String TableName, String grps) throws InterruptedException
    {
        StringTokenizer ST_Process = new StringTokenizer(InputProcess, ",");
        StringTokenizer ST_Table = new StringTokenizer(TableName, ",");
        while (ST_Process.hasMoreTokens())
        {
            Select Process = new Select(Ele_Process);
            Process.selectByVisibleText(ST_Process.nextToken());
            Thread.sleep(10000);
            Select Data = new Select(Ele_Data);
            Data.selectByVisibleText(ST_Table.nextToken());
            //CommonMethods comMethods = new CommonMethods(driver);
            //if (!"NA".equalsIgnoreCase(grps))
            //{
            //    comMethods.selectTheGroups(grps);
            //}
            ClickAddButton();
            //String errMsg = driver.findElement(By.xpath(".//*[@id='errMsgList']")).getText();
            //assertThat(errMsg,null);
            Thread.sleep(3000);
        }
    }

    public String selectFirstIp(String process)
    {
        String[] a = process.split(",");
        return a[0];
    }

    public String selectSecIp(String process)
    {
        String[] a = process.split(",");
        return a[1];
    }
    

 @Step("Fetched Output Table Name IP")
 public String  getOutputTableNameIPForSM(String processNameForStats,String processNameWithColon) throws InterruptedException
 {
	         driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
	        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processNameForStats);
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
	        Thread.sleep(1000);
	        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
	       driver.findElement(By.xpath("//span[contains(text(),'" + processNameWithColon + "')]/preceding::span[1]")).click();
	       //String itemNo=driver.findElement(By.xpath("//span[contains(text(),'IN_GPLOAD')]/parent::td/parent::tr//td[3]")).getText().trim();
	       String itemNo=driver.findElement(By.xpath("//span[contains(text(),'GPLOAD')]/parent::td/parent::tr//td[3]")).getText().trim(); 
	       String tableName = "I" + itemNo + "_IN_GPLOAD_INPUT";;
		return tableName;
	    
}


}

package com.equifax.cms.fusion.test.utils;

public enum ProcessOperationEnum {
	SAVE, EDIT, DUPLICATE, SUBMIT, VALIDATE;
}
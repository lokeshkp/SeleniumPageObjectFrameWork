package com.equifax.cms.fusion.test.SHPages;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.google.common.collect.Ordering;

public class ShippingPage
{
    private ShippingHomePage shHomePage;
    private CommonMethods commMethods;
    WebDriver driver;
    public Select selType;
    private static final boolean IS_UNIX = "/".equals(File.separator);

    public ShippingPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(id = "processName")
    WebElement processName_Field;

    @FindBy(id = "shippingPurpose1")
    WebElement deliverFilPostShipmnt_RB;

    @FindBy(id = "shippingPurpose2")
    public WebElement deliverFilesOnly_RB;

    @FindBy(id = "shippingPurpose3")
    WebElement postShipmntOnly_RB;

    @FindBy(xpath = "(//input[@id='isPredicted'])[1]")
    WebElement UsePredInput_Rbtn;

    @FindBy(xpath = "(//input[@id='isPredicted'])[2]")
    WebElement UseInputCompleteJob_Rbtn;

    @FindBy(id = "reportOnly")
    WebElement reportOnly_CB;

    @FindBy(id = "fromProcessId")
    WebElement process_DD;

    @FindBy(id = "jobId")
    WebElement job_DD;

    @FindBy(id = "rawNameCnt2")
    public WebElement rawNamesCount_Field;

    @FindBy(id = "addButton")
    WebElement addButton;

    // ADDED TO ADD DETAILS TO GRID FOR Post Shipment to Project Tracking only
    @FindBy(id = "addProjTack")
    WebElement addProjTrack;

    @FindBy(xpath = "(.//*[@id='divShipDate']/table/tbody/tr/td/div/img)[1]")
    WebElement calender_Btn;

    @FindBy(xpath = "//input[@id='dateShipped']/img")
    WebElement calender_New_Btn;

    @FindBy(xpath = "(//img[@class='removeRowIcon'])[1]")
    WebElement Remove_Icon;

    @FindBy(xpath = ".//*[@class='orange-btn'][1]")
    WebElement back_Btn;

    @FindBy(xpath = ".//*[@value='Save']")
    WebElement save_Btn;

    @FindBy(xpath = ".//*[@type='submit'][2]")
    WebElement submit_Btn;

    @FindBy(id = "deliveryType")
    WebElement deliveryType_POPUP_DD;

    @FindBy(id = "host")
    WebElement Host_onPopup;

    @FindBy(id = "ftpHost")
    WebElement FTP_host;

    @FindBy(id = "ftpSchid")
    WebElement ftp_Schid;

    @FindBy(id = "schid")
    WebElement SCHID_onPopup;

    @FindBy(id = "scirptFilePath")
    WebElement ScriptFile_Path;

    @FindBy(id = "notificationEmails")
    WebElement RecEmailAddr;

    @FindBy(id = "emailSubject")
    WebElement EmailSub;

    @FindBy(id = "emailBody")
    WebElement EmailBody;

    @FindBy(id = "custFileName1")
    WebElement deliveryFileName;

    @FindBy(id = "rawNameCnt1")
    WebElement RawNamesCntForReportOnly_Fld;

    @FindBy(xpath = "//div[@id='btnDiv']//tbody//td[2]/a[1]")
    WebElement save_POPUP_Btn;

    @FindBy(xpath = ".//*[@class='grey-button cancelDetails']")
    WebElement cancel_POPUP_Btn;
    @FindBy(xpath = "//div[@class='buttons']/input[2]")
    WebElement new_submit_Btn;

    // added to select the run type
    @FindBy(id = "isTestOnly1")
    WebElement live_Production_Run_Radio;

    @FindBy(id = "testOnlyOn")
    WebElement test_Automation_Radio;

    @Step("Get process Id")
    public String getProcessId()
    {
        String processId = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/table/tbody/tr/td[1]/label/span")).getText();
        return processId;
    }

    @Step("Provide Process Name = \"{0}\"")
    public void inputProcessName(String processName)
    {
        processName_Field.clear();
        processName_Field.sendKeys(processName);
    }

    @Step("Select Process = \"{0}\"")
    public void selectProcess(String process)
    {
        Select sel = new Select(process_DD);
        sel.selectByVisibleText(process);
    }

    public void firstProc(String process)
    {
        Select sel = new Select(process_DD);
        String[] a = process.split(",");
        sel.selectByVisibleText(a[0]);
    }

    public void secondProc(String process)
    {
        Select sel = new Select(process_DD);
        String[] a = process.split(",");
        sel.selectByVisibleText(a[1]);
    }

    @Step("Select Job = \"{0}\"")
    public void selectJob(String job)
    {
        if (!"NA".equalsIgnoreCase(job))
        {
            Select sel = new Select(job_DD);
            sel.selectByVisibleText(job);
        }
    }

    @Step("Select the purpose = \"{0}\"")
    public void selectPurposeRB(String purpose)
    {
        if ("DF_PS".equalsIgnoreCase(purpose))
        {
            deliverFilPostShipmnt_RB.click();
        } else if ("DF_Only".equalsIgnoreCase(purpose))
        {
            deliverFilesOnly_RB.click();
        } else if ("PS_Only".equalsIgnoreCase(purpose))
        {
            postShipmntOnly_RB.click();
        }
    }

    @Step("Select the Input Type = \"{0}\"")
    public void selectInputType(String inputType)
    {
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            clickPredictInput();
        } else if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            clickCompletedJob();
        } else
        {
            System.out.println("Provide proper input in the input Data Sheet !!!");
        }
    }

    @Step("Clicked Use Predicted Input")
    public void clickPredictInput()
    {
        UsePredInput_Rbtn.click();
    }

    @Step("Clicked Input from completed job")
    public void clickCompletedJob()
    {
        UseInputCompleteJob_Rbtn.click();
    }

    @Step("Provided Raw Name Count = \"{0}\"")
    public void rawNamesCount(String value)
    {
        if (!"NA".equalsIgnoreCase(value))
        {
            rawNamesCount_Field.clear();
            rawNamesCount_Field.sendKeys(value);
        }
    }

    @Step("Click Save on Pop up window")
    public void clickSavePopUp() throws InterruptedException
    {
    	Thread.sleep(5500);
        save_POPUP_Btn.click();
    }

    @Step("Click Cancel on Pop up window")
    public void clickCancelPopUp()
    {
        cancel_POPUP_Btn.click();
    }

    @Step("Delivery File Name = \"{0}\" \"{1}\"")
    public void inputDeliveryFileNamePopUp(String fileName, String deliverFileName)
    {
        driver.findElement(By.xpath("(.//*[contains(text(),'" + fileName + "')])[2]/following-sibling::td/input")).sendKeys(deliverFileName);
    }

    @Step("Select Delivery Type = \"{0}\"")
    public void selectDeliveryType(String type)
    {
        selType = new Select(deliveryType_POPUP_DD);
        selType.selectByVisibleText(type);
    }

    @Step("Select Host = \"{0}\"")
    public void selectHost(String host)
    {
        selType = new Select(Host_onPopup);
        selType.selectByVisibleText(host);
    }

    @Step("Select Host FTP= \"{0}\"")
    public void selectFTPHost(String host)
    {
        selType = new Select(FTP_host);
        selType.selectByVisibleText(host);
    }

    @Step("Select SCHID = \"{0}\"")
    public void selectSCHID(String schId)
    {
        selType = new Select(SCHID_onPopup);
        selType.selectByVisibleText(schId);
    }

    @Step("Select SCHID FTP = \"{0}\"")
    public void selectSCHID_FTP(String schId)
    {
        selType = new Select(ftp_Schid);
        selType.selectByVisibleText(schId);
    }

    @Step("Select Script File Path = \"{0}\"")
    public void inputScriptFilePath(String filePath)
    {
        ScriptFile_Path.sendKeys(filePath);
    }

    @Step("Provided Recipients Email Address = \"{0}\"")
    public void inputRecEmailAddr(String recEmailAdd)
    {
        RecEmailAddr.clear();
        RecEmailAddr.sendKeys(recEmailAdd);
    }

    @Step("Provided Email Subject = \"{0}\"")
    public void inputEmailSubj(String emailSub)
    {
        EmailSub.sendKeys(emailSub);
    }

    @Step("Provided Email Body = \"{0}\"")
    public void inputEmailBody(String emailBody)
    {
        EmailBody.sendKeys(emailBody);
    }

    @Step("Select the Date")
    public void selectDate() throws InterruptedException
    {
        Thread.sleep(2500);
        calender_Btn.click();
        Thread.sleep(2500);
        // driver.findElement(By.xpath("(.//*[@id='ui-datepicker-div']/table/tbody/tr/td[@data-year='"+year+"'
        // AND
        // @data-month='"+month+"']/a[contains(text(),'"+date+"')])[1]")).click();
        String day = new SimpleDateFormat("dd").format(Calendar.getInstance().getTime());
        System.out.println("day : " + day);
        int[] num = { 1, 2, 3, 4, 5, 6, 7, 8, 9 };
        if (day.startsWith("0"))
        {
            driver.findElement(By.xpath("//*[text()='" + num[Integer.parseInt(String.valueOf(day.charAt(1))) - 1] + "']")).click();
            // String a =(String) day.subSequence(1,1);
            // driver.findElement(By.xpath("//a[contains(text(), '"+a+"')]")).click();
        } else
        {
            driver.findElement(By.xpath("(//a[contains(text(), '" + day + "')])[1]")).click();
        }
        Thread.sleep(1500);
    }

    @Step("Select Report Only Checkbox = \"{0}\"")
    public void selectReportOnly(String reportonly)
    {
        if ("Check".equalsIgnoreCase(reportonly))
        {
            if (!reportOnly_CB.isSelected())
            {
                reportOnly_CB.click();
            }
        } else if ("Uncheck".equalsIgnoreCase(reportonly))
        {
            if (reportOnly_CB.isSelected())
            {
                reportOnly_CB.click();
            }
        }
    }

    @Step("Provided Raw Names Count for Report Only = \"{0}\"")
    public void rawNamesCountForReportOnly(String count)
    {
        reportOnly_CB.click();
        RawNamesCntForReportOnly_Fld.sendKeys(count);
    }

    @Step("Select Shipped Files = \"{0}\"")
    public void selectShippedFiles(String shFile)
    {
        if (!"NA".equalsIgnoreCase(shFile))
        {
            String del = ",";
            StringTokenizer st = new StringTokenizer(shFile, del);
            while (st.hasMoreTokens())
            {
                driver.findElement(By.xpath(".//label[contains(text(),'" + st.nextToken() + "')]//preceding::input[1]")).click();
            }
        }
    }

    @Step("Select Shipped Files = \"{0}\"")
    public String selectShippedFiles1(String shFile)
    {
        String del = ",";
        StringTokenizer st = new StringTokenizer(shFile, del);
        while (st.hasMoreTokens())
        {
            driver.findElement(By.xpath(".//label[contains(text(),'" + st.nextToken() + "')]//preceding::input[1]")).click();
        }
        return shFile;
    }

    public void selFirstSplitShFiles(String shFiles)
    {
        String[] a = shFiles.split(";");
        // String fileName = selectShippedFiles1(a[0]);
        driver.findElement(By.xpath(".//label[contains(text(),'" + a[0] + "')]//preceding::input[1]")).click();
    }

    public void selSecSplitShFiles(String shFiles)
    {
        String[] a = shFiles.split(";");
        // String fileName = selectShippedFiles1(a[1]);
        driver.findElement(By.xpath(".//label[contains(text(),'" + a[1] + "')]//preceding::input[1]")).click();
    }

    @Step("Click Add button")
    public void clickAddButton()
    {
        addButton.click();
    }

    @Step("Click Add button For Post Shipment to Project Tracking only ")
    public void clickAddButtonForPostShipmentToProjectTrackingOnly()
    {
        addProjTrack.click();
    }

    @Step("Provide Delivery File Names = \"{0}\"")
    public void provideDelFileNames(String fileName)
    {
        String del = ",";
        StringTokenizer dl = new StringTokenizer(fileName, del);
        int i = 1;
        while (dl.hasMoreTokens())
        {
            driver.findElement(By.xpath("//input[@id='custFileName" + i + "']")).sendKeys(dl.nextToken());
            i++;
        }
    }

    @Step("Selected Shipping Files Delivery Details = \"{0}\" \"{1}\" \"{2}\" \"{3}\"")
    public void shipFilesDeliveryDetls(String delType, String hostORfilePath, String schId, String delFileName, String recEmailAdd, String emailSub,
            String emailBody) throws InterruptedException
    {
        if ("SFTP".equalsIgnoreCase(delType))
        {
            selectDeliveryType(delType);
//        	if (!"NA".equalsIgnoreCase(recEmailAdd))
//    		inputRecEmailAddr(recEmailAdd);
            selectHost(hostORfilePath);
            selectSCHID(schId);
            provideDelFileNames(delFileName);
            Thread.sleep(2500);
            clickSavePopUp();
        } else if ("FTP".equalsIgnoreCase(delType))
        {
            selectDeliveryType(delType);
//        	if (!"NA".equalsIgnoreCase(recEmailAdd))
//    		inputRecEmailAddr(recEmailAdd);
            selectFTPHost(hostORfilePath);
            selectSCHID_FTP(schId);
            provideDelFileNames(delFileName);
            Thread.sleep(2500);
            clickSavePopUp();
        } else if ("Connect Direct".equalsIgnoreCase(delType))
        {
            selectDeliveryType(delType);
//        	if (!"NA".equalsIgnoreCase(recEmailAdd))
//    		inputRecEmailAddr(recEmailAdd);
            inputScriptFilePath(hostORfilePath);
            // provideDelFileNames(delFileName);
            Thread.sleep(2500);
            clickSavePopUp();
        } else if ("Email".equalsIgnoreCase(delType))
        {
            selectDeliveryType(delType);
            provideDelFileNames(delFileName);
            inputRecEmailAddr(recEmailAdd);
            inputEmailSubj(emailSub);
            inputEmailBody(emailBody);
            Thread.sleep(2500);
            clickSavePopUp();
        } else if ("Other".equalsIgnoreCase(delType))
        {
            selectDeliveryType(delType);
            provideDelFileNames(delFileName);
            Thread.sleep(2500);
            clickSavePopUp();
        } else
        {
            System.out.println("Provide proper input in the Input sheet !!!");
        }
    }

    @Step("Fetching the type and name for the Predicted type Or CompletedJob type input selected")
    public List<String> getTheTypeOfInputSelected(String inputType)
    {
        List<String> inputList = new ArrayList<String>();
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            String NameOfTheButton = driver.findElement(By.xpath("//label[contains(text(),'Select Input Type')]/parent::div/table/tbody/tr[1]/td"))
                    .getText();
            inputList.add(NameOfTheButton);
            String TypeOfTheButton = driver.findElement(
                    By.xpath("//label[contains(text(),'Select Input Type')]/parent::div/table/tbody/tr[1]/td/input")).getAttribute("type");
            inputList.add(TypeOfTheButton);
        } else if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            String NameOfTheButton = driver.findElement(By.xpath("//label[contains(text(),'Select Input Type')]/parent::div/table/tbody/tr[2]/td"))
                    .getText();
            inputList.add(NameOfTheButton);
            String TypeOfTheButton = driver.findElement(
                    By.xpath("//label[contains(text(),'Select Input Type')]/parent::div/table/tbody/tr[2]/td/input")).getAttribute("type");
            inputList.add(TypeOfTheButton);
        }
        return inputList;

    }

    @Step("Fetching the css values for JobId")
    public String getTheCssValueForJobId()
    {
        String css_Value_for_Job_Id = driver.findElement(By.id("jobId")).getCssValue("display");
        return css_Value_for_Job_Id;

    }

    @Step("Fetching the css values for RawNameCount")
    public String getTheCssValueForRawNameCount()
    {
        String css_Value_for_raw_count = driver.findElement(By.id("rawNameCnt2")).getCssValue("display");
        return css_Value_for_raw_count;

    }

    @Step("Fetching the error message from the lightbox when input type changes")
    public String getTheErrorMsgOnChangeOfInputType()
    {
        String errMsg = driver.findElement(By.xpath("//div[@id='sb-player']/div/h1")).getText();
        return errMsg;

    }

    @Step("Click 'Yes' Button On lightbox when input type changes")
    public void clickButtonOfLightBoxWhenInputTypeChanges()
    {
        driver.findElement(By.xpath("//div[@id='sb-player']/div/div/a[1]")).click();

    }

    @Step("Fetching the processName/JobId from the shipping grid")
    // method fetches processName/JobId for FirstRow only
    public String getTheProcessNameAndJobIdFromTheShippingGrid(String delType)
    {
        String processName_JobId = driver.findElement(By.xpath("//span[contains(text(),'" + delType + "')]//parent::td//following::td[2]/span"))
                .getText();
        return processName_JobId;

    }

    @Step("Fetching the Recordcount from the shipping grid")
    // method fetches Recordcount for FirstRow only
    public String getTheRecordcountFromTheShippingGrid(String delType, String inputType) throws InterruptedException
    {
        Thread.sleep(1500);
        String record_count = null;
        if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            // record_count =
            // driver.findElement(By.xpath("//span[contains(text(),'" + delType
            // + "')]//parent::td//following::td[4]/input"))
            // .getAttribute("value");
            record_count = driver.findElement(By.xpath("//span[contains(text(),'" + delType + "')]//parent::td//following::td[4]/input"))
                    .getAttribute("value");

        }
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            record_count = driver.findElement(By.xpath("//span[contains(text(),'" + delType + "')]//parent::td//following::td[4]")).getText();
        }
        return record_count;

    }

    @Step("Fetching the Delivery File Name from the shipping grid")
    // method fetches delivery file name for FirstRow only
    public String getTheDeliveryFileNameFromTheShippingGrid(String delType)
    {

        String deliveryFileName = driver.findElement(By.xpath("//span[contains(text(),'" + delType + "')]//parent::td//following::td[3]/span"))
                .getText();

        return deliveryFileName;

    }

    @Step("Fetching the ErrorMsg When trying Submit Shipping With MultiDataSet Process")
    public String getTheErrorMessageForMultiDataSetInput()
    {
        String errorMessage = driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']//span[@id='manTextMsg']")).getText();
        return errorMessage;

    }

    @Step("Fetching the ErrorMsg")
    public String fetchTheErrorMessage()
    {
        String errorMessage = driver.findElement(By.xpath(" //div[@class='errMsg errMsgExt']//span[@id='manTextMsg']//li//label")).getText();
        return errorMessage;

    }
    @Step("Fetching the ErrorMsg When trying Submit Shipping With Ready State Process")
    public String getTheErrorMessage()
    {


        String   errorMessage = driver.findElement(By.xpath("//div[@class='copyErrMsg errMsgExt']//span[@id='textMsg']")).getText();

        return errorMessage;

    }

    // added to click the collapse button for shipping process
    @Step("click the collapse button for Job and then click to expand its workitems for shipping process in dashboard cntroller")
    public void clickTheCollapseButton(String processNameForStats, String processNameWithColon) throws InterruptedException
    {
        String[] processName = processNameWithColon.split(":");
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName[0]);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameWithColon + "')]/preceding::span[1]")).click();

    }

    @Step("click the view hyperlink for viewing jobstats of shipping process in dashboard cntroller")
    public void clickViewStatsForJobLevel(String assignedId) throws InterruptedException
    {

        driver.findElement(By.xpath("//span[contains(text(),'" + assignedId + "')]//parent::td//parent::tr/td[8]/div/a")).click();
        Thread.sleep(1000);
        // td[starts-with(@title,'DM185')]
    }

    @Step("Fetch the no of records for each file from OP stats")
    // Fetching for single file
    public String getTheRecordCountOfFileFromOPStats(String shFileName)
    {
        /*
         * String record_count_frm_stats = driver.findElement(By.xpath( "//div[contains(text(),'Number of Records shipped')]/div" )).getText();
         */
        String record_count_frm_stats = driver.findElement(By.xpath("//div[contains(text(),'" + shFileName + "')]/parent::div/div[2]")).getText();

        return record_count_frm_stats;
    }

    @Step("Fetch the no of records for each file from Shipping stats")
    // Fetching for single file
    public String getTheRecordCountOfFileFromSHStats(String shFileName)
    {
        /*
         * String record_count_frm_stats = driver.findElement(By.xpath( "//div[contains(text(),'Number of Records shipped')]/div" )).getText();
         */
        String record_count_frm_stats = driver.findElement(
                By.xpath("//div[starts-with(text(),'" + shFileName
                        + "')]/following::div[contains(text(),'Number of Records shipped')][1]/following-sibling::div")).getText();

        return record_count_frm_stats;
    }

    @Step("Fetch the no of records for each file from Stack stats")
    // Fetching for single file from the stats of stack....
    public String getTheRecordCountOfFileFromStackStats(String shFileName)
    {
        /*
         * String record_count_frm_stats = driver.findElement(By.xpath( "//div[contains(text(),'Number of Records shipped')]/div" )).getText();
         */
        String record_count_frm_StackStats = driver.findElement(
                By.xpath("//div[starts-with(text(),'" + shFileName
                        + "')]/following::div[contains(text(),'Number of Records shipped')][1]/following-sibling::div")).getText();

        return record_count_frm_StackStats;
    }

    @Step("Fetch the no of records for each file from Shipping stats")
    // Fetching for single file
    public String getTheRecordsShippedFromSHStats()
    {
        String recordsShipped = driver.findElement(By.xpath("//div[contains(text(),'Number of Records shipped')]/following-sibling::div")).getText();

        return recordsShipped;
    }

    @Step("Checking whether the  process has only one workitem formed or not")
    public String isOneWorkItemHasFormed()
    {

        String workItemName = null;

        List<WebElement> elements = driver.findElements(By.xpath("//table[@id='tablejob-tree']//tr"));
        if (elements.size() == 3)
        {

            String mainEleToCheck = elements.get(2).getAttribute("data-key");
            workItemName = driver.findElement(By.xpath("//tr[@data-key='" + mainEleToCheck + "']//td[2]//span[5]")).getText();
            System.out.println("Shipping process has following datakey --->" + workItemName);

        }
        return workItemName;
    }

    @Step("Fetch the Shipped Files")
    public List<WebElement> getListOfShippedFiles()
    {
        List<WebElement> shippedFilelist = driver.findElements(By.xpath("//div[@id='divShippedFiles']/label"));
        return shippedFilelist;

    }

    // ********added to get the count from the table in shipping
    // process*******//
    @Step("Fetch the Recount Count From DeliveryType")
    public List<String> getRecountCountFromDeliveryType(String deliveryType, String inputType)
    {
        ArrayList<String> recordCountList = new ArrayList<String>();
        if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            // getting the first file record count assuming delivery type
            // similar
            String first_count = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[4]/input"))
                    .getAttribute("value");
            recordCountList.add(first_count);
            // getting the second file record count assuming delivery type
            // similar
            String second_count = driver.findElement(
                    By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//parent::tr//following::tr[1]/td[4]/input")).getAttribute(
                            "value");
            recordCountList.add(second_count);
        }
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            // getting the first file record count assuming delivery type
            // similar
            String first_count = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[4]"))
                    .getText();
            recordCountList.add(first_count);
            // getting the second file record count assuming delivery type
            // similar
            String second_count = driver.findElement(
                    By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//parent::tr//following::tr[1]/td[4]")).getText();
            recordCountList.add(second_count);
        }
        return recordCountList;
    }

    // *******TO Check whether the record count text box in Grid in Shipping
    // process is editable or not******//
    @Step("checking whether record count column in the shipping grid is editable or not")
    public boolean IsEditable(String deliveryType)
    {
        boolean state = false;
        // getting the status of record count textbox for first and second file
        // whether two textboxes are editable or not//
        if (driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[4]/input")).isEnabled())
        {
            state = true;
        }
        return state;
    }

    @Step("Edit the record count column of the shipping grid")
    public void editRecordCountColumnOfShippingGrid(String deliveryType, String updatedRecordCount)
    {

        // getting the status of record count textbox for first and second file
        // whether two textboxes are editable or not//
        WebElement element = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[4]/input"));
        element.clear();
        element.sendKeys(updatedRecordCount);

    }

    // ********added to get the file name from the table in shipping
    // process*******//
//    @Step("Fetch the File Name From DeliveryType")
//    public List<String> getFileNameFromDeliveryType(String deliveryType)
//    {
//        ArrayList<String> fileNameList = new ArrayList<String>();
//        // getting the first file record count assuming delivery type similar
//        String first_file_name = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[3]/span"))
//                .getText();
//        fileNameList.add(first_file_name);
//        // getting the second file record count assuming delivery type similar
//        String second_file_name = driver.findElement(
//                By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//parent::tr//following::tr[1]/td[3]/span")).getText();
//        fileNameList.add(second_file_name);
//        return fileNameList;
//    }

    @Step("Fetch the File Name From DeliveryType")
    public String getFileNameFromDeliveryType(String deliveryType)
    {
        
        // getting the first file record count assuming delivery type similar
        String first_file_name = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]//parent::td//following::td[3]/span")).getText();
                
        
        return first_file_name;
    }

    
    // ********added to get the delivery type from the table in shipping
    // process*******//
    @Step("Fetch the DeliveryType")
    public String getDeliveryTypeOfTableFromDeliveryType(String deliveryType)
    {

        // getting the first file record count assuming delivery type similar
        String delivery_name = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryType + "')]")).getText();
        return delivery_name;

    }

    // ********added to get the row id for For File having same delivery type
    // shipping process*******//
    @Step("Fetch the RowId FromFileName")
    public String getRowIdOnFromFileName(String deliveryFileName)
    {

        // getting the first file record count assuming delivery type similar
        String RowIdForFirstFile = driver.findElement(By.xpath("//span[contains(text(),'" + deliveryFileName + "')]/parent::td/parent::tr"))
                .getAttribute("id");
        return RowIdForFirstFile;

    }

    // ********added to get the class name for the font of add popup in shipping
    // process*******//
    @Step("Fetch the ClassName Of Font Of PopUp")
    public String getClassNameOfFontOfPopUp()
    {

        // getting the first file record count assuming delivery type similar
        String className = driver.findElement(By.xpath("//span[contains(text(),'Specify the delivery details of shipping files')]//parent::h3"))
                .getAttribute("class");
        return className;

    }

    // ********added to get the class name for the error message for not
    // providing process name in shipping process*******//
    @Step("Fetch the Class Name Of ErrorMessage")
    public String getClassNameOfErrorMessage()
    {

        // getting the first file record count assuming delivery type similar
        String className = driver.findElement(By.xpath("//span[contains(text(),' Please enter the Process Name')]//parent::div")).getAttribute(
                "class");
        return className;

    }

    // ***********added to check whether the light box is present or
    // not*******//
    @Step("Validating whether light box present or not on change in input type")
    public boolean isLightBoxPresent()
    {
        boolean isPresent = false;

        if (driver.findElement(By.xpath(".//*[@id='sb-player']/div")).isDisplayed())
        {

            isPresent = true;
        }
        return isPresent;

    }

    @Step("Clicked on Remove Icon")
    public void clickRemoveIcon()
    {
        Remove_Icon.click();
    }

    @Step("Saved the process")
    public void clickSaveButton()
    {
        save_Btn.click();
    }

    @Step("Submitted the process")
    public void clickSubmitButton()
    {
        submit_Btn.click();
    }

    public String splitShFile(String shFiles)
    {
        String[] a = shFiles.split(",");
        return a[0];
    }

    @Step("Selecting future date from the calendar")
    // this method selects the future date from the calendar.Format for date
    // should be "dd/mm/yyyy".
    public void selectFutureDateFromTheCalendar()
    {
        Calendar cal = Calendar.getInstance();

        int currentDate = cal.get(Calendar.DAY_OF_MONTH);

        boolean increment = false;
        int futureDate = 0;

        Integer[] dateArr1 = { 31, 30, 28 };
        if (Arrays.asList(dateArr1).contains(currentDate))
        {
            futureDate = 1;
            increment = true;
        } else
        {
            futureDate = currentDate + 1;
        }

        calender_Btn.click();
        if (increment)
        {
            driver.findElement(By.xpath(".//*[@id='ui-datepicker-div']/div/a[2]/span")).click();
        }
        // Thread.sleep(1000);

        driver.findElement(By.linkText(Integer.toString(futureDate))).click();
    }

    @Step("Fetching the ErrorMsg When trying Save Shipping With Future Date")
    public String getTheErrorMessageForFutureDate()
    {
        String errorMessage = driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']//li/label")).getText();
        return errorMessage;

    }

    @Step("Fetching the button Name from shipping summary")
    public String getTheNameOfButtonPresentOnShippingSummary()
    {
        String buttonName = driver.findElement(By.xpath("//div[@class='buttons']/a")).getText();
        return buttonName;

    }

    @Step("Fetching the Count of buttons present on shipping summary")
    public Integer getTheCountOfButtonPresentOnShippingSummary()
    {
        int buttonCount = driver.findElements(By.xpath("//div[@class='cmsContent']//div[@class='buttons']")).size();
        return buttonCount;

    }

    @Step("Clear Process Name")
    public void clearProcessName()
    {
        processName_Field.clear();

    }

    // div[@class='jqx-resize jqx-rc-all']

    @Step("Checking whether the Confirmation window is present")
    public boolean isjobRunMsgJqxConfirmWindowPresent()
    {
        boolean isPresent = false;
        if (driver.findElement(By.xpath("//div[@class='jqx-resize jqx-rc-all']")).isDisplayed())
        {
            int count = driver.findElements(By.xpath("//div[@class='jqx-resize jqx-rc-all']//div[starts-with(text(),'Submit confirmation')]")).size();
            if (count != 0)
            {
                isPresent = true;
            }

        }
        return isPresent;
    }

    @Step("Click submit button of Confirmation window")
    public void clickTheSubmitButtonOfConfirmationWindow()
    {

        driver.findElement(
                By.xpath("//div[@class='jqx-resize jqx-rc-all']//div[starts-with(text(),'Submit confirmation')]//ancestor::div[2]//div[@class='warningbtn']/input[1]"))
                .click();
    }

    // h3[contains(text(),'Error/Warnings')]
    // ul[@class=' jqx-tabs-title-container']/li/div[contains(text(),'Stats')]
    @Step("Checking for Stats Tab")
    public void isStatsTabOpen()
    {

        String getTheTitle = driver.findElement(By.xpath("//h3[@class='fusion-h3Title']")).getText();
        if (!getTheTitle.equalsIgnoreCase("Job Stats"))
        {
            driver.findElement(By.xpath("//ul[@class=' jqx-tabs-title-container']//li//div[contains(text(),'Stats')]")).click();
        }
    }

    @Step("Clear Filter Search")
    public void clearFilter()
    {

        driver.findElement(By.xpath("//div[@title='Clear Filter']")).click();
    }

    @Step("Clicked Live Production Run Type")
    public void clickLiveProduction()
    {

        if (live_Production_Run_Radio.isSelected() == false)
        {
            live_Production_Run_Radio.click();
        }
    }

    @Step("Clicked Test Automation run Type")
    public void clickTestAutomation()
    {
        if (test_Automation_Radio.isSelected() == false)
        {
            test_Automation_Radio.click();
        }
    }

    @Step("Fetching the Error Message")
    public String getTheErrorMessageForRunTypeSelection()
    {
        String message = driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']//span[@id='manTextMsg']")).getText();
        return message;
    }

    @Step("Fetching Delivery Number From The Shipping Grid")
    public String getTheDeliveryNumberFromTheGrid()
    {
        String deliveryNum = driver.findElement(By.xpath("//table[@id='shippingInputDataTable']//tbody//tr/td[2]")).getText();
        return deliveryNum;
    }

    @Step("Clicked Remove Row Icon")
    public void clickRemoveRowIcon()
    {
        driver.findElement(By.xpath("//img[@class='removeRowIcon']")).click();

    }

    @Step("Fetch The text from the stats")
    public String fetchTheTextFromStats()
    {
        String statText = driver.findElement(
                By.xpath("//div[contains(text(),'SHIPPING PROJECT ACCOUNTING')]/parent::div//parent::div//following::div[2]//div[1]")).getText();
        return statText;

    }

    @Step("Fetch The stats for shipping accounting workitem")
    public List<String> fetchTheStatsForAccountingWorkitem()
    {
        List<String> statItems = new ArrayList<String>();
        List<WebElement> list = driver.findElements(By.xpath("//div[contains(text(),'Test Automation Setup')]/parent::div/following::div/div[1]"));

        for (int i = 0; i < list.size(); i++)
        {
            String statItem = list.get(i).getText();
            String[] statArr = statItem.split(":");
            statItems.add(statArr[0].trim());
        }
        return statItems;
    }

    @Step("View Stats for Shipping Accounting Workitem")
    public void viewStatsForAccountingWorkitem(String processNameForStats, String processNameWithColon) throws InterruptedException
    {
        String[] processName = processNameWithColon.split(":");
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).clear();
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::input[1]")).sendKeys(processName[0]);
        driver.findElement(By.xpath("//a[contains(text(),'Advanced')]/preceding::div[1]")).click();
        Thread.sleep(1000);
        Thread.sleep(1000);
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameForStats + "')]/preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'" + processNameWithColon + "')]/preceding::span[1]")).click();
        driver.findElement(By.xpath("//span[contains(text(),'SHP_ACCOUNTING')]//parent::td//following::td//a[contains(text(),'View')]"));

    }

    @Step("Validate Delivery type list order")
    public boolean isFTPAvailableAfterConnectDirect()
    {
        boolean flag = false;
        List<WebElement> optionsList = driver.findElements(By.xpath("//*[@id='deliveryType']/option"));
        List<String> optionValues = new ArrayList<>();
        int i = 0;
        for (WebElement ele : optionsList)
        {
            String value = optionsList.get(i).getText();
            optionValues.add(value);
            i++;
        }
        int j = 0;
        String afterConnectDirect = null;
        String afterSFTP = null;
        for (String option : optionValues)
        {
            if ("Connect Direct".equalsIgnoreCase(optionValues.get(j)))
            {
                afterConnectDirect = optionValues.get(j + 1);

            }
            if ("SFTP".equalsIgnoreCase(optionValues.get(j)))
            {
                afterSFTP = optionValues.get(j + 1);

            }
            if (null != afterConnectDirect && null != afterSFTP)
            {
                break;
            }
            j++;
        }
        if ("FTP".equalsIgnoreCase(afterConnectDirect) && !"FTP".equalsIgnoreCase(afterSFTP))
        {
            return true;
        }
        return flag;
    }
    @Step("Checking for Option to be Disabled")
    public boolean isOptionsDisabled()
    {
        boolean isDisabled = false;
        String value=    driver.findElement(By.xpath("//*[@id='ftpHost']")).getAttribute("disabled");
        String value2=    driver.findElement(By.xpath("//*[@id='ftpSchid']")).getAttribute("disabled");

        if(value.equalsIgnoreCase("true") && value2.equalsIgnoreCase("true"))
        {
            isDisabled=true;
        }
        return isDisabled;
    }

    public boolean validateHostListPopulation(String path) throws IOException
    {
        // String path = "/nas/code/prod/etc/FTP_Tool_credentials.txt";
        // String devQaUatPath = "/nas/fusion/config/sdlc/FTP_Tool_credentials_Test.txt";
        if (IS_UNIX)
        {
            System.out.println("goes to --->>" + path);
            int len = new File(path).listFiles().length;
            File file = new File(path);

        } else
        {
            System.out.println("Test");
            System.out.println("goes to --->>" + "C:" + path.replace("/", "\\"));
            String newPath = "C:" + path.replace("/", "\\");
            File file = new File(newPath);

        }

        List<WebElement> optionsList = driver.findElements(By.xpath("//*[@id='ftpHost']/option"));
        List<String> optionValues = new ArrayList<>();
        int i = 1;
        for (WebElement ele : optionsList)
        {

            String textVal = ele.getAttribute("value");
            System.out.println("textVal ======>>" + textVal);
            if (!"".equalsIgnoreCase(textVal))
            {
                optionValues.add(textVal);
            }
            i++;
        }
        boolean flag = false;
        int j = 0;
        List<String> fileContent = readFile(path);
        for (String option : optionValues)
        {
            for (j = 0; j < fileContent.size(); j++)
            {
                if (fileContent.get(j).contains(option))
                {
                    flag = true;
                    break;
                } else
                {
                    flag = false;
                }
            }
        }
        return flag;
    }

    public boolean validateHostListOrderInFile() throws IOException
    {
        String path = "/nas/code/prod/etc/FTP_Tool_credentials.txt";
        if (IS_UNIX)
        {
            System.out.println("goes to --->>" + path);
            int len = new File(path).listFiles().length;
            File file = new File(path);

        } else
        {
            System.out.println("goes to --->>" + "C:" + path.replace("/", "\\"));
            String newPath = "C:" + path.replace("/", "\\");
            File file = new File(newPath);

        }
        List<WebElement> optionsList = driver.findElements(By.xpath("//*[@id='ftpHost']/option"));
        List<String> optionValues = new ArrayList<>();
        int i = 0;
        for (WebElement ele : optionsList)
        {
            String value = optionsList.get(i).getText();
            if (!"Select".equalsIgnoreCase(value))
            {
                optionValues.add(value);
            }
            i++;
        }
        boolean flag = false;
        List<String> fileContent = readFile(path);
        List<Integer> orderList = new ArrayList<>();
        List<Integer> tempList = new ArrayList<>();
        for (String option : optionValues)
        {
            for (int j = 0; j < fileContent.size(); j++)
            {
                if (fileContent.get(j).equalsIgnoreCase(option))
                {
                    orderList.add(j);
                    tempList.addAll(orderList);
                }
            }
        }

        Collections.sort(orderList);

        for (int k = 0; k < orderList.size(); k++)
        {
            if (orderList.get(k) == tempList.get(k))
            {
                flag = true;
            } else
            {
                return false;
            }
        }
        return flag;
    }

    public boolean validateSCIDContent()
    {
        boolean flag = false;
        List<String> listSchid = listOptionsForSCHID_FTP();
        for (String s : listSchid)
        {
            if (!s.contains(":"))
            {
                return false;
            } else
            {
                flag = true;
            }
        }
        return flag;
    }

    public boolean validateHostRecordLabelContent()
    {
        boolean flag = false;
        List<String> optionValues = new ArrayList<>();
        List<WebElement> optionsList = driver.findElements(By.xpath("//*[@id='ftpHost']/option"));
        int i = 0;
        for (WebElement ele : optionsList)
        {
            String value = optionsList.get(i).getText();
            if (!"Select".equalsIgnoreCase(value))
            {
                optionValues.add(value);
            }
            i++;
        }
        for (String val : optionValues)
        {
            if (!val.startsWith("#") || !val.startsWith("TESTING"))
            {
                flag = true;
            } else
            {

                return false;
            }
        }
        return flag;
    }

    public void getDeliveryFileName(String fileNames)
    {
        String files[] = fileNames.split(",");
        int i = 0;
        for (String s : files)
        {
            // return deliveryFileName.getAttribute("value");
            String dynamicPath = "//*[@id='custFileName" + i + "']";
            // return driver.findElement(By.xpath(dynamicPath)).getAttribute("value");
        }
    }

    public boolean isFTP_SCHIDStyleDisabled()
    {
        String val = ftp_Schid.getAttribute("disabled");
        if ("".equals(val))
        {
            return true;
        }
        return false;
    }

    public String getFTP_SCHIDSelectedOption()
    {
        Select select = new Select(ftp_Schid);

        WebElement option = select.getFirstSelectedOption();
        return option.getText();
    }

    public String getHostSelectedOption()
    {
        Select select = new Select(FTP_host);

        WebElement option = select.getFirstSelectedOption();
        return option.getText();
    }

    @Step("Get Selected Delivery Type = \"{0}\"")
    public String getDeliveryType()
    {
        selType = new Select(deliveryType_POPUP_DD);
        WebElement option = selType.getFirstSelectedOption();
        return option.getText();
    }

    @Step("Get Entered Email Address")
    public String getEmailAdress()
    {
        return RecEmailAddr.getText();
    }

    @Step("Get SCHID FTP List = \"{0}\"")
    public List<String> listOptionsForSCHID_FTP()
    {
        selType = new Select(ftp_Schid);
        List<String> optionValues = new ArrayList<>();
        List<WebElement> optionsList = driver.findElements(By.xpath("//*[@id='ftpSchid']/option"));
        int i = 0;
        for (WebElement ele : optionsList)
        {
            String value = optionsList.get(i).getText();
            if (!"Select".equalsIgnoreCase(value))
            {
                optionValues.add(value);
            }
            i++;
        }
        return optionValues;
    }

    public boolean isSCHIDFTPListSorted(List<String> optionValues)
    {
        boolean isSorted = Ordering.from(String.CASE_INSENSITIVE_ORDER).isOrdered(optionValues);
        return isSorted;
    }

    @Step("Read file and return list")
    public List<String> readFile(String newPath) throws IOException
    {
        // newPath = newPath.replace("\\", "/");
        File file = new File(newPath);
        List<String> arr = new ArrayList<>();
        FileReader fr = new FileReader(file);
        BufferedReader br = new BufferedReader(fr);
        String sCurrentLine;
        while ((sCurrentLine = br.readLine()) != null)
        {
            arr.add(sCurrentLine);
        }

        return arr;
    }

    public static String getAbsoluteInFilePath(String path)
    {
        // String bbf = "/pools/dropzone/Test/test_Import_fixed/444_records_130.fixed";

        if (path.startsWith("/nas/dropzone"))
        {
            path = path.replace("/nas/dropzone", "V:").replace("/", "\\\\");
        } else if (path.startsWith("/nas/users/mshamis/fusion"))
        {
            path = path.replace("/nas/users", "U:").replace("/", "\\\\");
        }
        if (path.startsWith("/nas/users"))
        {
            path = path.replace("/nas/users", "U:").replace("/", "\\\\");
        }

        return path;
    }

    public void clickEditDeliveryDetails()
    {
        driver.findElement(By.xpath("//*[@id='shippingInputDataTable']/tbody/tr/td/img[@class='editColumnIcon']")).click();
    }

    public boolean isHostAndSCHIDDisabledWhenTestAutomation()
    {
        boolean displayStatus = false;
        String valHost = FTP_host.getAttribute("disabled");
        String valSCHID = ftp_Schid.getAttribute("disabled");
        if ("true".equals(valHost) && "true".equals(valSCHID))
        {
            return true;
        }
        return displayStatus;
    }
    public void handleTheDialogBox()
    {
        String css_Value=   driver.findElement(By.xpath("//div[@class='jqx-window-modal jqx-window-modal-classic']")).getCssValue("display").trim();

        if(css_Value.equalsIgnoreCase("block"))
        {
            driver.findElement(By.xpath("//div[@id='ftpWarning']//div[@class='warningbtn']//input[@id='btnOk']")).click();
        }
    }
    public boolean isTextBoxReadOnly()
    {
        boolean isReadOnly=false;
        String style=   driver.findElement(By.xpath("//*[@id='notificationEmails']")).getAttribute("style");
        String[] styleArr=style.split(";");
        List<String> styleList=Arrays.asList(styleArr);
        for(String prop:styleList)
        {
            if(prop.contains("readonly"))
            {
                isReadOnly=true;
                break;
            }
        }
        return isReadOnly;

    }


}

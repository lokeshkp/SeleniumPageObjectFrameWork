package com.equifax.cms.fusion.test.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.json.JobStats;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Database Utils obtain database connection and have helper methods to execute SQL Queries
 * 
 * @author sxr236
 *
 */
public class DBHelper
{

    private static final Logger LOGGER = LoggerFactory.getLogger(DBHelper.class);

    private Connection connection;

    // get oracle database connection
    private Connection initConnection()
    {
        Connection connection = null;
        try
        {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            String host = PropertiesUtils.getProperty("ora.host");
            String user = PropertiesUtils.getProperty("ora.user");
            String password = PropertiesUtils.getProperty("ora.password");
            connection = DriverManager.getConnection(host, user, password);
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {0}\n Trace {1}\n ", e.getMessage(), e);
        }
        return connection;
    }

    // return single connection at any point of time
    // no "double-check" since there is no multithreading
    public synchronized Connection getConnection()
    {
        if (null == connection)
        {
            LOGGER.debug("Init database .... ");
            connection = initConnection();
        }
        return connection;
    }

    /**
     * return job status for given jobId, will return 'null' in case jobId not found
     * 
     * @param jobId
     * @return status - Submitted job status
     */

    public String getStatusForJob(long id)
    {
        String sql = "SELECT ID,STATUS,JOB_NUMBER FROM FULFILLMENT_JOB WHERE JOB_NUMBER = ?";
        PreparedStatement statement = null;
        String status = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                status = rs.getString("STATUS");
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return status;
    }

    public Long getLayoutIdFromProcessId(long id)
    {
        String sql = "SELECT LAYOUT_ID FROM PROCESS_ARTIFACT WHERE PROCESS_ID = ?";
        PreparedStatement statement = null;
        Long layoutId = null;
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                layoutId = rs.getLong("LAYOUT_ID");
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return layoutId;

    }

    public List<String> getInputFieldsFromLayoutId(long id)
    {
        String sql = "SELECT NAME FROM INPUT_FILE_FIELD WHERE LAYOUT_ID = ?";
        PreparedStatement statement = null;
        List<String> fields = new ArrayList<String>();
        try
        {
            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);

            // execute select SQL statement
            ResultSet rs = statement.executeQuery();
            while (rs.next())
            {
                fields.add(rs.getString("NAME"));
            }
        }

        catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());
        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return fields;

    }

    /**
     * get job status and job stat conent from DB
     * 
     * @param jobId
     * @return {@link JobDetailsVO}
     */
    public List<JobDetailsVO> getStatusDetails(long id)
    {

        String sql = "SELECT FJ.JOB_NUMBER ,  JS.JOB_ID ,WIT.ITEM_ID , JS.ID, FJ.STATUS, W.STATUS \"WORK_ITEM_STATUS\" , "
                + " WIT.STAT_CONTENT , W.ITEM_NAME FROM  WORK_ITEM_STAT_MASTER WIT, WORK_ITEM W  , "
                + " JOB_PROCESS_STEP JS  , FULFILLMENT_JOB FJ WHERE w.JOB_PROCESS_STEP_ID = JS.ID "
                + " AND WIT.ITEM_ID = W.ID AND JS.JOB_ID =  FJ.ID AND FJ.JOB_NUMBER =  ?";
        PreparedStatement statement = null;
        List<JobDetailsVO> list = new ArrayList<JobDetailsVO>();

        try
        {

            statement = getConnection().prepareStatement(sql);
            statement.setLong(1, id);
            // execute select SQL stetement
            ResultSet rs = statement.executeQuery();

            while (rs.next())
            {
                JobDetailsVO details = new JobDetailsVO();
                details.setItemName(rs.getString("ITEM_NAME"));
                details.setJobId(rs.getLong("JOB_ID"));
                details.setJobNumber(rs.getLong("JOB_NUMBER"));
                // FULFILLMENT_JOB status
                details.setJobStatus(rs.getString("STATUS"));
                // Job Process Step Id
                details.setJobStepId(rs.getLong("ID"));
                String content = rs.getString("STAT_CONTENT");
                details.setStatContent(content);
                // WORK_ITEM status
                details.setWorkItemStatus(rs.getString("WORK_ITEM_STATUS"));

                ObjectMapper mapper = new ObjectMapper();
                JobStats value = mapper.readValue(content, JobStats.class);
                details.setStats(value);
                LOGGER.info(" >> Job Stats -- %d\n", value.getStats().size());

                list.add(details);

            }
        } catch (SQLException se)
        {
            LOGGER.error(">> Unable to retrive data for given job number {}\n Message {}\n ", id, se.getMessage());

        } catch (Exception e)
        {
            LOGGER.error(">> Unable to connect to database {}\n Trace {}\n ", e.getMessage(), e);
        }
        return list;
    }

    public void closeConnection()
    {
        try
        {
            connection.close();
        } catch (Exception e)
        {

        }
    }
}

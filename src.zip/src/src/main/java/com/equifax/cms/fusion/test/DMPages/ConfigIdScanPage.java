package com.equifax.cms.fusion.test.DMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import ru.yandex.qatools.allure.annotations.Step;

public class ConfigIdScanPage
{

    WebDriver driver;
    public Select selType;

    public ConfigIdScanPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
        // PageFactory.initElements(driver, this);
    }

    @FindBy(id = "optRequired")
    WebElement ErrorMsg;

    @FindBy(id = "runIdScan1")
    public WebElement Ele_RunIdScan;

    @FindBy(id = "keepDrop1")
    WebElement Ele_Drop;

    @FindBy(id = "keepDrop2")
    WebElement Ele_Tag;

    @FindBy(id = "keepDrop3")
    WebElement Ele_Reject;

    @FindBy(id = "checkall")
    public WebElement Ele_CheckALLCB;

    @FindBy(xpath = "//a[contains(text(),'Back')]")
    WebElement Back_Btn;

    @FindBy(xpath = ".//input[@type='submit']")
    WebElement ContinueButton;

    @FindBy(id = "fraudVictim1")
    public WebElement Ele_LFraudVicCB;

    @FindBy(id = "ssnNeverIssued1")
    public WebElement Ele_ssnNeverIssuedCB;

    @FindBy(id = "addrMultiDwelling1")
    public WebElement Ele_addrMutliDwellingCB;

    @FindBy(id = "addrMisused1")
    public WebElement Ele_addressMisused;

    @Step("Get Error Message Displayed")
    public String getErrorMessage()
    {
        return ErrorMsg.getText();
    }

    @Step("Click Fraud Victim Alert Check Box")
    public void clickFraudVictimALertCB()
    {
        Ele_LFraudVicCB.click();
    }

    @Step("Click Check All Check Box")
    public void ClickCheckAllCB()
    {
        Ele_CheckALLCB.click();
    }

    @Step("Click Run ID Scan Check Box")
    public void clickRunIdScanCheckBox()
    {
        Ele_RunIdScan.click();
    }

    @Step("Select Drop Radio Button")
    public void clickDropRButton()
    {
        Ele_Drop.click();
    }

    @Step("Select Tag Radio Button")
    public void clickTagRButton()
    {
        Ele_Tag.click();
    }

    @Step("Select Reject Radio Button")
    public void clickRejectRButton()
    {
        Ele_Reject.click();
    }

    @Step("Clicked on Back button")
    public void clickBackBtn()
    {
        Back_Btn.click();
    }

    @Step("Click Continue Button on Configure ID Scan Page")
    public void clickContinueButton()
    {
        ContinueButton.click();
    }

    @Step("Click Run ID Scan Check Box = \"{0}\"")
    public void selectRunIdScanCheckBox(String idScan)
    {
        if ("ON".equalsIgnoreCase(idScan))
        {
            if (Ele_RunIdScan.isSelected())
            {
                System.out.println("Run ID scan is already been selected");
            } else
            {
                clickRunIdScanCheckBox();
            }
        } else if ("OFF".equalsIgnoreCase(idScan))
        {
            if (Ele_RunIdScan.isSelected())
            {
                clickRunIdScanCheckBox();
            } else
            {
                System.out.println("Run ID scan is already been unselected");
            }
        }
    }

    @Step("Selected the Rejects for Id Scan = \"{0}\"")
    public void selectRejectsInIdScan(String idScanRejects)
    {

        if (idScanRejects.equalsIgnoreCase("Drop"))
        {
            clickDropRButton();

        } else if (idScanRejects.equalsIgnoreCase("Tag"))
        {
            clickTagRButton();

        } else if (idScanRejects.equalsIgnoreCase("Reject"))
        {
            clickRejectRButton();

        } else if (idScanRejects.equalsIgnoreCase("NA"))
        {
            System.out.println("Not required to select the ID scan checkbox");

        } else
        {
            System.out.println("improper input data is given in the excel sheet");

        }
    }

}

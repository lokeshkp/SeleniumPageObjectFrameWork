package com.equifax.cms.fusion.test.SMPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import ru.yandex.qatools.allure.annotations.Step;

public class SMSummaryPage {

		WebDriver driver;
		
	public SMSummaryPage(WebDriver driver){
		
		this.driver = driver;
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		PageFactory.initElements(driver, this);
		
	}
	
	@FindBy(id = "submitButton")
	WebElement SubmitButton;
	
	@Step("Click Submit Button on Summary Page")
	public void ClickSubmitButton(){
		SubmitButton.click();
	}
	
	@Step("Process Name in Summary = \"{0}\"")
	public String procNameOnSum(String sumProcName){
		String path = driver.findElement(By.xpath("//span[contains(text(),'"+sumProcName+"')]")).getText();
		String[] a = path.split(":");
		return a[1].trim();
	}
}

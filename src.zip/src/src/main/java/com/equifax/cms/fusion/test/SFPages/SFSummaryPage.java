package com.equifax.cms.fusion.test.SFPages;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import ru.yandex.qatools.allure.annotations.Step;

public class SFSummaryPage
{
    WebDriver driver;

    public SFSummaryPage(WebDriver driver)
    {
        this.driver = driver;
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
    }

    @FindBy(xpath = ".//label[contains(text(),'Process Name:')]//following-sibling::span")
    WebElement sfSummaryProcessName;

    @FindBy(xpath = "//input[@name='submitButton']")
    WebElement Submit_Btn;

    @Step("Click Submit button")
    public void clickSubmitBtn()
    {
        WebElement element = driver.findElement(By.xpath("//div[@class='buttons']/input"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].click();", element);
        // Submit_Btn.click();
    }

    @Step("Get ProcessName button")
    public String getSummaryProcessName()
    {
        return sfSummaryProcessName.getText();
    }

    @Step("Get Count ")
    public String getCountFromSummaryGrid()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[4]")).getText();
    }

    @Step("Get Process ")
    public String getProcessFromSummaryGrid()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[1]")).getText();
    }

    @Step("Get Process ")
    public String getDataFromSummaryGrid()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[3]")).getText();
    }

    @Step("Get JobNumber ")
    public String getJobNumberFromSummaryGrid()
    {
        return driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td[2]")).getText();
    }

    @Step("verify sample set display")
    public String verifySampleSet()
    {
        // String result = driver.findElement(By.xpath("//div/h4[contains(text(),'Sample Set')]/following::div[1]/label")).getText();
        String completeString = driver.findElement(By.xpath("//div/h4[contains(text(),'Sample Set')]/following::div[1]")).getText();
        return completeString;
    }

    @Step("verify Records per Accept Level, Records per Reject Code, Accept levels to create , Reject Codes to create")
    public List<String> verifySampleSetInSummary()
    {
        String recPerAccLevel = driver.findElement(By.xpath(".//label[contains(text(),'Records per Accept Level')]//following::td[1]")).getText();
        String recPerRejCode = driver.findElement(By.xpath(".//label[contains(text(),'Records per Reject Level')]//following::td[1]")).getText();
        String accLevel = driver.findElement(By.xpath(".//label[contains(text(),'Accepts Levels to create')]//following::td[1]")).getText();
        String rejCode = driver.findElement(By.xpath(".//label[contains(text(),'Reject Codes to create')]//following::td[1]")).getText();

        List<String> data = new ArrayList<>();
        data.add(recPerAccLevel);
        data.add(recPerRejCode);
        data.add(accLevel);
        data.add(rejCode);
        return data;

    }

    @Step("Validate data table present on Summary")
    public boolean summaryDatatable() throws InterruptedException
    {
        String dataTableXpath = ".//*[@id='DataTables_Table_0']";
        return isElementPresent(dataTableXpath);
    }

    @Step("Validate grid structure")
    public boolean validateGridContent() throws InterruptedException
    {

        if (isElementPresent(".//b[contains(text(),'Process')]") && isElementPresent(".//b[contains(text(),'Job')]")
                && isElementPresent(".//b[contains(text(),'Data')]") && isElementPresent(".//b[contains(text(),'Count')]"))
        {
            return true;

        }
        return false;

    }

    public boolean isElementPresent(String xpath) throws InterruptedException
    {
        try
        {
            Thread.sleep(2000);
            driver.findElement(By.xpath("+xpath+"));
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    @Step("click Move Statements link")
    public void clickMoveStatementLink()
    {
        driver.findElement(By.xpath("//a[contains(text(),'Move Statements')]")).click();
    }

    @Step("Close jqx Window")
    public void closeJqxWindow()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxMoveStmtWindow').jqxWindow('close')");
        // js.executeScript("$('#comboboxeditordual-list-data-table-2fieldType').jqxComboBox('val','" + flds + "')");

    }

    @Step("Open jqx Window")
    public void openJqxWindow()
    {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("$('#jqxMoveStmtWindow').jqxWindow('open')");
        // js.executeScript("$('#comboboxeditordual-list-data-table-2fieldType').jqxComboBox('val','" + flds + "')");

    }

    @Step("close Move Statements link")
    public void closeMoveStatementLink()
    {
        // driver.findElement(By.xpath("//div[@id='closeButton']/a")).click();

        driver.findElement(By.xpath(".//*div[@class='jqx-window-close-button jqx-icon-close jqx-window-close-button-summer jqx-icon-close-summer']"))
                .click();
        // JavascriptExecutor js = (JavascriptExecutor) driver;
        // js.executeScript("arguments[0].click();", element);
    }

    @Step("Number of columns in summary")
    public String numberOfColumnsSumm()
    {
        return driver.findElement(By.xpath("//div[@class='columnsDiv']/h2")).getText();
    }

    @Step("Literal start pos in summary")
    public String literalStartPos()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr[1]/td[2]")).getText();
    }

    @Step("value start in summary")
    public String valueStartPos()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr[1]/td[2]/following::div")).getText();
    }

    @Step("Literal start and end pos in summary")
    public String fieldName()
    {
        return driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr[1]/td[6]/div[1]")).getText();
    }

    public String getRecordPerReject()
    {
        return driver.findElement(By.xpath(".//label[contains(text(),'Records per Reject Level')]//following::td[1]")).getText();

    }

    public String getNumberOfMovedColumns()
    {
        return driver.findElement(By.xpath("//h4[contains(text(),'Sample File Move Statements')]/following::div/h2")).getText();
    }

    public void clickAuditCriteriaLink()
    {
        driver.findElement(By.xpath("//a[contains(text(),'Audit Criteria')]")).click();
    }

    public List<String> getContentFromSummary()
    {
        List<WebElement> elements = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr/td"));
        List<String> conmtentList = new ArrayList<>();
        for (WebElement element : elements)
        {
            String val = element.getText();
            conmtentList.add(val);
        }
        return conmtentList;
    }
}

package com.equifax.cms.fusion.test.qareporting;

import java.io.File;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.REPORTINGPages.ConfigSASparametersPage;
import com.equifax.cms.fusion.test.REPORTINGPages.ConfigureSASPage;
import com.equifax.cms.fusion.test.REPORTINGPages.ReportingHomePage;
import com.equifax.cms.fusion.test.REPORTINGPages.SASStats;
import com.equifax.cms.fusion.test.REPORTINGPages.SASsummaryPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

//import com.equifax.cms.fusion.test.REPORTINGPages.SASStats;

public class SASprocess {
	public WebDriver driver;
	private CommonMethods commMethods;
	private ProjectDashBoardPage ProjDashBoardPage;
	private ReportingHomePage reportHomePage;
	private ConfigureSASPage configSASpage;
	private ConfigSASparametersPage configSASparaPage;
	private SASsummaryPage sasSumPage;
	private SASStats sasStats;
	private static final boolean IS_UNIX = "/".equals(File.separator);
	private static final Logger LOGGER = LoggerFactory.getLogger(SASprocess.class);

	@Title("User Login with akp8 ")
	@Step("User Login")
	@BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
	public void loginandSearchProj() throws InterruptedException {
		// driver = FusionFirefoxDriver.getDriver();
		driver = FusionChromeDriver.getDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		reportHomePage = PageFactory.initElements(driver, ReportingHomePage.class);
		configSASpage = PageFactory.initElements(driver, ConfigureSASPage.class);
		configSASparaPage = PageFactory.initElements(driver, ConfigSASparametersPage.class);
		sasSumPage = PageFactory.initElements(driver, SASsummaryPage.class);
		sasStats = PageFactory.initElements(driver, SASStats.class);
		commMethods.userLogin();
		commMethods.searchProject();
	}

	@Test(dataProvider = "reg_SAS", priority = 1, description = "TS1: SAS process Stats Verification") // QA
	public void sasProcessStats(String tc_Id, String testRun, String TC, String desc, String copyProj,
			String copyProcName, String procName, String sasProg, String process, String data, String grps,
			ITestContext testContext) throws InterruptedException {
		String status = null;
		Modules module = new Modules();
		module.initializeDriver(driver);
		testContext.setAttribute("WebDriver", driver);
		if ("SAS_ID_205".equalsIgnoreCase(tc_Id)) {
			commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
			ProjDashBoardPage.inputProjNum(copyProj);
			ProjDashBoardPage.clickCopyProjSrchBtn();
			ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
			ProjDashBoardPage.clickCopySelectBtn();
			reportHomePage.clickReportingTab();
			status = commMethods.getProcessStatus();
			commMethods.verifyStringEB(status.trim(), StatusEnum.READY.name());
			module.selectEdit();
			String pageTitle = ProjDashBoardPage.getPageTitle();
			commMethods.verifyString(pageTitle, "Configure SAS");
			String copyProcName1 = configSASpage.processName_Field.getAttribute("value");
			commMethods.verifyString(copyProcName1, procName);
			configSASpage.clickContinueBtn();
			String copyData = driver.findElement(By.xpath(".//*[@id='workItemLabel_0']")).getText();
			commMethods.verifyString(copyData, "HEADER");
		}
		if ("SAS_ID_168".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			reportHomePage.clickReportingTab();
			status = commMethods.getProcessStatus();
			commMethods.verifyStringEB(status.trim(), StatusEnum.ERROR.name());
		}
		if ("SAS_ID_003".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			configSASparaPage.clickContinueBtn();
			String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
			commMethods.verifyString(errMsg, "A data table must be selected for the GP_TABLE1 parameter");
		}
		if ("SAS_ID_004".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			configSASparaPage.clickSaveBtn();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Configure SAS Parameters");
		}
		if ("SAS_ID_016".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			String fProName = commMethods.getFinalProcessName();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			configSASparaPage.clickSaveBtn();
			configSASparaPage.clickContinueBtn();
			reportHomePage.clickReportingTab();
			status = commMethods.getProcessStatus();
			commMethods.verifyStringEB(status.trim(), StatusEnum.READY.name());
			module.selectDuplicate1();
			status = commMethods.getProcessStatus();
			commMethods.verifyString(status.trim(), StatusEnum.READY.name());
			module.selectEdit();
			String fProName_New = commMethods.getFinalProcessName();
			String pageTitle = ProjDashBoardPage.getPageTitle();
			commMethods.verifyString(pageTitle, "Configure SAS");
			ProjDashBoardPage.clickReportingTab();
			status = commMethods.getProcessStatus();
			commMethods.verifyStringEB(status.trim(), StatusEnum.READY.name());
			module.selectSummary1();
			sasSumPage.clickSubmitButton();
			status = commMethods.getProcessStatus();
			commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
			ProjDashBoardPage.clickHomeTab();
			commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName_New), "PASS");

		}
		if ("SAS_ID_024".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(10000);
			configSASparaPage.clickContinueBtn();
			sasSumPage.clickSubmitButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
			WebElement errImg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/div[1]/img"));
			commMethods.verifyboolean(errMsg.endsWith("has not executed yet"), true);
			commMethods.verifyboolean(errImg.isDisplayed(), true);
		}
		if ("SAS_ID_012".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			configSASparaPage.clickContinueBtn();
			Thread.sleep(10000);
			sasSumPage.clickSubmitButton();
			commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
			module.selectSummary1();
			String procNameSum = driver.findElement(By.xpath(".//*[@id='processLabel_0']")).getText().trim();
			String dataSum = driver.findElement(By.xpath(".//*[@id='workItemLabel_0']")).getText().trim();
			String paraNameSum = driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[1]")).getText()
					.trim();
			commMethods.verifyString(procNameSum, process);
			commMethods.verifyString(dataSum, data);
			commMethods.verifyString(paraNameSum, "GP_TABLE1");
		}
		if ("SAS_ID_023".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(10000);
			configSASparaPage.clickSaveBtn();
			configSASparaPage.clickContinueBtn();
			sasSumPage.clickSubmitButton();
			status = commMethods.getProcessStatus();
			commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
			module.selectSummary1();
			String grpNameSum = driver.findElement(By.xpath(".//*[@id='groupsLabel_0']")).getText().trim();
			commMethods.verifyString(grpNameSum, grps);
		}
		if ("SAS_ID_001".equalsIgnoreCase(tc_Id) || "SAS_ID_021".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			String fProName = commMethods.getFinalProcessName();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(5000);
			configSASparaPage.clickContinueBtn();
			sasSumPage.clickSubmitButton();
			commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
			ProjDashBoardPage.clickHomeTab();
			commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
			ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
			// driver.switchTo().frame("sb-player");
			String statsHdr = driver.findElement(By.xpath("//h3[contains(text(),'Job Stats')]")).getText();
			commMethods.verifyString(statsHdr, "Job Stats");
		}
	}

	@Test(dataProvider = "reg_SAS_CBA", priority = 2, enabled = false) // DEV
	public void sasProcessCBA(String tc_Id, String testRun, String TC, String desc, String copyProj,
			String copyProcName, String procName, String sasProg, String process, String data, String grps,
			ITestContext testContext) throws InterruptedException {
		String status = null;
		Modules module = new Modules();
		module.initializeDriver(driver);
		testContext.setAttribute("WebDriver", driver);
		if ("SAS_ID_005".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			// configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			commMethods.verifyString(configSASpage.getErrorMessage(), "Please enter the Process Name.");
			commMethods.verifyString(configSASpage.getErrorDivStyle(), "display: block;");
		}

		if ("SAS_ID_006".equalsIgnoreCase(tc_Id)) {
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			String fProName = commMethods.getFinalProcessName();

			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			if (!"NA".equalsIgnoreCase(grps)) {
				commMethods.selectTheGroups(grps);
			}
			configSASparaPage.clickProcDataSaveBtn();

			Thread.sleep(10000);
			configSASparaPage.clickContinueBtn();
			sasSumPage.clickSubmitButton();
			status = commMethods.getProcessStatus();
			commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
			ProjDashBoardPage.clickHomeTab();

			String Status = ProjDashBoardPage.verifyProcess(fProName);
			commMethods.verifyString(Status, "PASS");
			ProjDashBoardPage.viewStats(fProName);

			sasStats.clickParamFileLink();
			driver.switchTo().frame(0);
			String content = sasStats.getContent();
			String splitContent[] = content.split(" ");
			String finalSplit[] = splitContent[2].split("\"");
			String path = finalSplit[1];
			if (IS_UNIX) {
				System.out.println("goes to --->>" + path);
				int len = new File(path).listFiles().length;
				File file = new File(path);

				for (File f : file.listFiles()) {
					if (f.getName().contains(".xml")) {
						LOGGER.info(" Test status :PASS");
					}
				}

			} else {
				System.out.println("goes to --->>" + "C:" + path.replace("/", "\\"));
				String newPath = "C:" + path.replace("/", "\\");
				File file = new File(newPath);
				File f[] = file.listFiles();
				for (File tempfile : f) {
					if (tempfile.getName().contains(".xls")) {
						LOGGER.info("Test status :PASS");
					}
				}
			}

		}
	}

	@Test(dataProvider = "reg_SAS_Base") // BaseProcess
	public void sasBaseProcess(String tc_Id, String testRun, String TC, String desc, String copyProj,
			String copyProcName, String procName, String sasProg, String process, String data, String grps,
			ITestContext testContext) throws InterruptedException {
		String executionStatus = commMethods.getTheExecutionStatus(process);
		if (executionStatus.equalsIgnoreCase("COMPLETED")) {
			String status = null;
			Modules module = new Modules();
			module.initializeDriver(driver);
			testContext.setAttribute("WebDriver", driver);
			reportHomePage.clickReportingTab();
			reportHomePage.clickSASbtn();
			configSASpage.inputProcessName(procName);
			configSASpage.inputSASProgramFile(sasProg);
			configSASpage.clickContinueBtn();
			configSASparaPage.clickDataImg();
			driver.switchTo().frame("sb-player");
			configSASparaPage.selectProcessFld(process);
			configSASparaPage.selectDataFld(data);
			commMethods.selectTheGroups(grps);
			configSASparaPage.clickProcDataSaveBtn();
			driver.switchTo().defaultContent();
			Thread.sleep(10000);
			configSASparaPage.clickContinueBtn();
			sasSumPage.clickSubmitButton();
		}
	}

	@AfterMethod
	public void closeBrowser() {
		driver.quit();
	}

	@DataProvider
	public Object[][] reg_SAS() throws Exception {
		Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SASprocess", "Y");
		return testObjArray_Y;
	}

	@DataProvider
	public Object[][] reg_SAS_CBA() throws Exception {
		Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SASprocess", "CBA");
		return testObjArray_CBA;
	}

	@DataProvider
	public Object[][] reg_SAS_Base() throws Exception {
		Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SASprocess", "BAS");
		return testObjArray_CBA;
	}
}

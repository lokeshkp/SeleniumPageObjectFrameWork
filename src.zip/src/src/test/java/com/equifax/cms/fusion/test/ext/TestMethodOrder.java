package com.equifax.cms.fusion.test.ext;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.junit.Before;
import org.junit.Rule;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Stories;

@Features("Sample test execution feature 1")
@Stories("Stroy# 123")
@RunWith(Theories.class)
public class TestMethodOrder {

	int i = 0;

	private WebDriver driver;
	private String baseUrl;
	private boolean acceptNextAlert = true;
	private StringBuffer verificationErrors = new StringBuffer();

	@Before
	public void setUp() throws Exception {
		driver = FusionFirefoxDriver.getDriver();
		baseUrl = "http://afnd1lc9a001.app.c9.equifax.com:9090/";
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}

	@Rule
	public TestWatcher screenshotOnFailure = new TestWatcher() {
		@Override
		protected void failed(Throwable e, Description description) {
			makeScreenshotOnFailure();
		}

		@Attachment("Screenshot on failure")
		public byte[] makeScreenshotOnFailure() {
			return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		}
	};

	@Theory
	public void testAFirst() {
		System.out.println("firs...t");
		System.out.println("i value : " + i);
		i++;
		bSecond();
		fail("test fail");
		cNext();
    }

	@Step("Second Step execute operation B")
	public void bSecond() {
        System.out.println("second");
		System.out.println("i value : " + i);
		driver.get(baseUrl + "/cms-fusion-web/login");
		driver.findElement(By.id("j_username")).clear();
		driver.findElement(By.id("j_username")).sendKeys("sxr236");
		driver.findElement(By.id("j_password")).clear();
		driver.findElement(By.id("j_password")).sendKeys("Quest@291");
		driver.findElement(By.id("submitButton")).click();
		driver.findElement(By.id("cms_search")).click();
    }

	@Step("This should execute end")
	public void cNext() {
		System.out.println("third ...");
		createAttachment();

    }

	@Attachment("Input")
	private byte[] createAttachment() {
		String content = "attachmentContent";
		return content.getBytes();
	}
}
package com.equifax.cms.fusion.test.schedulejob;

import java.sql.SQLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.ScheduleJobPages.JobConfiguration;
import com.equifax.cms.fusion.test.ScheduleJobPages.JobExecutionDetails;
import com.equifax.cms.fusion.test.ScheduleJobPages.JobScheduleHomePage;
import com.equifax.cms.fusion.test.ScheduleJobPages.ScheduleJobConfigurationPageQA;
import com.equifax.cms.fusion.test.ScheduleJobPages.ScheduleJobPageQA;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class ScheduleJob
{
    public static WebDriver driver = null;
    private Modules module;
    private CommonMethods commMethods;
    private ProjectDashBoardPage projDashBoardPage;
    private JobConfiguration scheduleJobConfiguration;
    private JobExecutionDetails scheduleJobExecutionDetailsPage;
    // private ScheduleJobExecutionDetailsPage scheduleJobExecutionDetailsPage;
    private JobScheduleHomePage scheduleJobHomePage;
    private OracleDBHelper oracleConnect;
    private ScheduleJobPageQA scheduleJobPageQA;
    private ScheduleJobConfigurationPageQA scheduleJobConfigPageQA;

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginandSearchProj() throws InterruptedException
    {
       // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        scheduleJobExecutionDetailsPage = PageFactory.initElements(driver, JobExecutionDetails.class);
        scheduleJobConfiguration = PageFactory.initElements(driver, JobConfiguration.class);
        scheduleJobPageQA = PageFactory.initElements(driver, ScheduleJobPageQA.class);
        scheduleJobConfigPageQA = PageFactory.initElements(driver, ScheduleJobConfigurationPageQA.class);
        commMethods.userLogin();
        oracleConnect = new OracleDBHelper();
        commMethods.searchProject();
    }
    
    @AfterMethod
    public void tearDown() throws InterruptedException
    {
        driver.quit();
    }
    
    @Title("Schedule Job Verification")
    @Description("Schedule Job Verification")
    @Test(dataProvider = "ScheduleJob_Y", priority = 1)
    public void scheduleJob_QA(String tcId, String testRun, String testcase, String description, String scheduleName, String stackName,
            String state, String sefJobMail, String mail, String failureMail, String paramName, String paramValue, ITestContext testContext)
            throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", ScheduleJob.driver);
        projDashBoardPage.clickOperationsTab();
        projDashBoardPage.clickScheduleJobTab();
        if("JS_ID_006".equalsIgnoreCase(tcId)) {
            commMethods.verifyboolean(scheduleJobPageQA.isActiveRBPresent(),true);
            commMethods.verifyboolean(scheduleJobPageQA.isInActiveRBPresent(),true);
        }
        if("JS_ID_007".equalsIgnoreCase(tcId)) {
            scheduleJobPageQA.inputScheduleName(scheduleName);
            scheduleJobPageQA.selecStack(stackName);
            scheduleJobPageQA.selectState(state);
            scheduleJobPageQA.inputScheduleStartEndFailureMailId(sefJobMail);
            scheduleJobPageQA.inputScheduleAndStepStartEndFailureMailId(mail);
            scheduleJobPageQA.inputScheduleFailureMailId(failureMail);
            scheduleJobPageQA.clickContinue();
            commMethods.verifyString(scheduleJobPageQA.getErrorMessage(),"Error: 'Schedule Start/End/Failure Only' contains invalid email addresses. Only internal Equifax email addresses are permitted.");
        }
        if("JS_ID_008".equalsIgnoreCase(tcId) || "JS_ID_009".equalsIgnoreCase(tcId)
                ||"JS_ID_010".equalsIgnoreCase(tcId)) 
        {
            scheduleJobPageQA.inputScheduleName(scheduleName);
            scheduleJobPageQA.selecStack(stackName);
            scheduleJobPageQA.selectState(state);
            scheduleJobPageQA.inputScheduleStartEndFailureMailId(sefJobMail);
            scheduleJobPageQA.inputScheduleAndStepStartEndFailureMailId(mail);
            scheduleJobPageQA.inputScheduleFailureMailId(failureMail);
            scheduleJobPageQA.clickContinue();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),"Schedule Job Configuration Complete the required information and then click 'Save'");
        }
        if("JS_ID_013".equalsIgnoreCase(tcId)) 
        {
            scheduleJobPageQA.inputScheduleName(scheduleName);
            scheduleJobPageQA.selecStack(stackName);
            scheduleJobPageQA.selectState(state);
            scheduleJobPageQA.inputScheduleStartEndFailureMailId(sefJobMail);
            scheduleJobPageQA.inputScheduleAndStepStartEndFailureMailId(mail);
            scheduleJobPageQA.inputScheduleFailureMailId(failureMail);
            scheduleJobPageQA.clickContinue();
            commMethods.verifyboolean(scheduleJobConfigPageQA.isGenerateParamButtonDisplayed(),true); 
        }
        
        
       
    }

    @Title("Schedule Job Verification")
    @Description("Schedule Job Verification")
    @Test(dataProvider = "ScheduleJob_CBA", priority = 1,enabled = false)
    public void scheduleJobVerification(String tcId, String testRun, String testcase, String description, String procName, String process,
            String state, String jobMail, String allNotifyMail, String failureMail, String paramName, String paramValue, ITestContext testContext)
            throws InterruptedException, SQLException
    {
        String status = null;
        testContext.setAttribute("WebDriver", ScheduleJob.driver);
        projDashBoardPage.clickOperationsTab();
        projDashBoardPage.clickScheduleJobTab();
        scheduleJobExecutionDetailsPage.setProcessName(procName);
        scheduleJobExecutionDetailsPage.selectProcessField(process);
        // String procId = scheduleJobExecutionDetailsPage.getProcId();
        if ("ACTIVE".equalsIgnoreCase(state))
        {
            scheduleJobExecutionDetailsPage.setActiveState();
        }

        if (!"NA".equalsIgnoreCase(jobMail))
        {
            scheduleJobExecutionDetailsPage.setjobNotifyEmailId(jobMail);
        }
        if (!"NA".equalsIgnoreCase(allNotifyMail))
        {
            scheduleJobExecutionDetailsPage.setallNotifyEmailIds(allNotifyMail);
        }
        if (!"NA".equalsIgnoreCase(jobMail))
        {
            scheduleJobExecutionDetailsPage.setfailureNotifyEmailIds(failureMail);
        }
        scheduleJobExecutionDetailsPage.clickContinue();
        if ("JS_TEST_001".equalsIgnoreCase(testcase))
        {
            scheduleJobConfiguration.checkParameterHavingDM();
            scheduleJobConfiguration.checkParameterOnTop();
            scheduleJobConfiguration.checkSecondParameter();
            scheduleJobConfiguration.setFirstParamName(paramName);
            scheduleJobConfiguration.setSecondParamName(paramName);
            scheduleJobConfiguration.clickSaveParameterDetails();
            scheduleJobConfiguration.clickConfigureDetailsSave();
            String err = scheduleJobConfiguration.getErrorMsg();
            commMethods.verifyString(err, "Duplicate Parameter Names [" + paramName + "] are not allowed.");

        } else
        {
            scheduleJobConfiguration.clickEditParameters();
            scheduleJobConfiguration.checkParameterOnTop();
            scheduleJobConfiguration.setFirstParamName(paramName);
            scheduleJobConfiguration.setFirstParamVal(paramValue);
            scheduleJobConfiguration.clickSaveParameterDetails();
            scheduleJobConfiguration.clickConfigureDetailsSave();
            scheduleJobConfiguration.generateParameterDetails();
            commMethods.verifyboolean(scheduleJobConfiguration.isParameterTemplateDisplayed(), true);
            String templateDetails = scheduleJobConfiguration.getParameterTemplateDetails();
            // String jsonDetail = scheduleJobHomePage.getTemplateJson(procId);
            // commMethods.verifyString(templateDetails, jsonDetail);

            // Validate that the JSON file generated after clicking on "Generate Parameter Template" button, can be saved in an external file.
            scheduleJobConfiguration.clickSaveToFile();
            driver.switchTo().activeElement();
            String savedPath = scheduleJobConfiguration.getFileSavingPath();
            savedPath.replace("/", "\\");
            String path = " C:" + "\\" + savedPath;
            scheduleJobConfiguration.clickSaveOnPopUp();

            // getUnix File path

            commMethods.verifyboolean(path.contains(".txt"), true);
        }
    }

    @DataProvider
    public Object[][] ScheduleJob_CBA() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "JobSchedule", "CBA");
        return testObjArray_CBA;
    }
    
    @DataProvider
    public Object[][] ScheduleJob_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "JobSchedule", "Y");
        return testObjArray_Y;
    }
}

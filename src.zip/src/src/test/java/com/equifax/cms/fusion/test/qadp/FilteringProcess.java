package com.equifax.cms.fusion.test.qadp;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.FFFPages.FullFileFixedPage;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringPage;
import com.equifax.cms.fusion.test.FILPages.FilteringStatsView;
import com.equifax.cms.fusion.test.FILPages.FilteringSummaryPage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class FilteringProcess
{
    public static WebDriver driver;
    private DataProcessingTabFIL dpHomePage;
    private Modules module;
    private CommonMethods commMethods;
    private ProjectDashBoardPage projDashBoardPage;
    private FilteringPage filterPage;
    private FilteringSummaryPage filSummPage;
    private FilteringStatsView filStatsView;
    private StackingPage stackingPage;
    private ShippingPage shPage;
    private JobStackingPage jobStackPage;
    private FullFileFixedPage fffPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(FilteringProcess.class);

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj()
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        module = new Modules();
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabFIL.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        filterPage = PageFactory.initElements(driver, FilteringPage.class);
        filSummPage = PageFactory.initElements(driver, FilteringSummaryPage.class);
        filStatsView = PageFactory.initElements(driver, FilteringStatsView.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackPage = PageFactory.initElements(driver, JobStackingPage.class);
        fffPage = PageFactory.initElements(driver, FullFileFixedPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "FilteringStats_Y")    // QA
    public void filteringStats(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String process, String jobNum, String data, String inputGroups, String outputTableName,
            String performCuts, String group1Name, String group1DOC, String g1c1Name, String g1c1TableField, String g1c1RangVal, String g1c1FromTo,
            String g1c1ValueSign, String g1c1Value, String g1c2Name, String g1c2TableField, String g1c2RangVal, String g1c2FromTo,
            String g1c2ValueSign, String g1c2Value, String group2Name, String group2DOC, String g2c1Name, String g2c1TableField, String g2c1RangVal,
            String g2c1FromTo, String g2c1ValueSign, String g2c1Value, String g2c2Name, String g2c2TableField, String g2c2RangVal, String g2c2FromTo,
            String g2c2ValueSign, String g2c2Value, ITestContext testContext) throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", FilteringProcess.driver);
        if ("FL_ID_424".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditFIL();
            commMethods.verifyString(filterPage.processName_Field.getAttribute("value"), processName);
            commMethods.verifyString(filterPage.outputTableName_Field.getAttribute("value"), outputTableName);
            commMethods.verifyboolean(filterPage.performCuts_CB.isSelected(), true);
            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.selectDuplicateFIL();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditFIL();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
        } else if ("FL_ID_425".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditFIL();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
            commMethods.verifyString(filterPage.processName_Field.getAttribute("value"), processName);
            commMethods.verifyString(filterPage.getJobId(), "");
            commMethods.verifyString(filterPage.dataSelected.getAttribute("value"), data);
            commMethods.verifyString(filterPage.outputTableName_Field.getAttribute("value"), outputTableName);
            commMethods.verifyboolean(filterPage.performCuts_CB.isSelected(), true);
            commMethods.verifyString(filterPage.firstGroupName_Field.getAttribute("value"), group1Name);
            commMethods.verifyString(filterPage.G1DOC.getAttribute("value"), group1DOC);
            commMethods.verifyString(filterPage.conditionNameG1C1.getAttribute("value"), g1c1Name);
            String arr_FromTo[] = g1c1FromTo.split(",");
            commMethods.verifyString(filterPage.g1c1RangeFrom.getAttribute("value"), arr_FromTo[0]);
            commMethods.verifyString(filterPage.g1c1RangeTo.getAttribute("value"), arr_FromTo[1]);
            commMethods.verifyString(filterPage.conditionNameG1C2.getAttribute("value"), g1c2Name);
            commMethods.verifyString(filterPage.valueG1C2.getAttribute("value"), g1c2Value);
            commMethods.verifyString(filterPage.secondGroupName_Field.getAttribute("value"), group2Name);
            commMethods.verifyString(filterPage.conditionNameG2C1.getAttribute("value"), g2c1Name);
            commMethods.verifyString(filterPage.valueG2C1.getAttribute("value"), g2c1Value);
            commMethods.verifyString(filterPage.valueG2C2.getAttribute("value"), "");
            filterPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
            filterPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectDuplicateFIL();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditFIL();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
            filterPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
        } else if ("FL_ID_408".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickFilteringButton();
            commMethods.verifyString(filterPage.getPageHeader(), "Filtering");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.gettextMessage(), "Please enter the Process Name.");
            filterPage.inputProcessName(processName);
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.gettextMessage(), "Select input process");
            filterPage.selectProcess(process);
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.gettextMessage(), "Select input data");
            filterPage.selectData(data);
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Please select at least one field for filtering");
            filterPage.clickPopUpOk();
            filterPage.inputTableAndFieldC1(1, "HEADER,AGE");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Please enter the name for group 1");
            filterPage.clickPopUpOk();
            filterPage.inputGroupName(1, group1Name);
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Please enter the Range for group 1");
            filterPage.clickPopUpOk();
            filterPage.inputRangeFrom(1, 1, 1, "21");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Please enter the Range for group 1");
            filterPage.clickPopUpOk();
            filterPage.inputRangeTo(1, 1, 1, "50");
            filterPage.clickSaveButton();
            commMethods.verifyString(filterPage.getPageHeader(), "Filtering");
            filterPage.inputGroupName(1, "Test Space Test");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Only alphanumeric characters allowed");
            filterPage.clickPopUpOk();
            filterPage.inputGroupName(1, "Test#$%");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "Only alphanumeric characters allowed");
            filterPage.clickPopUpOk();
            filterPage.inputGroupName(1, "Test");
            filterPage.inputRangeTo(1, 1, 1, "20");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(), "'To' value can not be less than 'From' value for group Test");
            filterPage.clickPopUpOk();
            filterPage.inputRangeFrom(1, 1, 1, "16");
            filterPage.inputGroupName(1, "Testt");
            filterPage.clickSaveButton();
            commMethods.verifyString(filterPage.getPageHeader(), "Filtering");
            filterPage.clickInsrtCondiButton(1);
            filterPage.inputTableAndFieldC2(1, "HEADER,NUM_TRADE");
            filterPage.selectRangeOrValue(1, 2, 1, "Value");
            filterPage.selectValueOptionSign(1, 2, 1, "isNull");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), false);
            filterPage.selectValueOptionSign(1, 2, 1, "isNotNull");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), false);
            filterPage.selectValueOptionSign(1, 2, 1, "notEqual");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), true);
            filterPage.selectValueOptionSign(1, 2, 1, "isNotNull");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), false);
            filterPage.selectValueOptionSign(1, 2, 1, "less");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), true);
            filterPage.selectValueOptionSign(1, 2, 1, "isNull");
            commMethods.verifyboolean(filterPage.isValueFieldEnabled(1, 2, 1), false);
            filterPage.inputRangeFrom(1, 1, 1, "abc");
            filterPage.inputDesiredOutputCount(1, "");
            filterPage.clickContinueButton();
            commMethods
                    .verifyString(filterPage.getpopUpText(),
                            "Error: Range values must be one data type, either all numeric or all letters. Number/Alpha combinations must use the Value option for group Testt");
            filterPage.clickPopUpOk();
            filterPage.inputRangeFrom(1, 1, 1, "15");
            filterPage.inputRangeTo(1, 1, 1, "abc");
            filterPage.inputDesiredOutputCount(1, "");
            filterPage.clickContinueButton();
            commMethods
                    .verifyString(filterPage.getpopUpText(),
                            "Error: Range values must be one data type, either all numeric or all letters. Number/Alpha combinations must use the Value option for group Testt");
            filterPage.clickPopUpOk();
            filterPage.inputRangeTo(1, 1, 1, "25");
            filterPage.inputDesiredOutputCount(1, "abc");
            filterPage.inputConditionName(1, 1, "");
            commMethods.verifyString(filterPage.getpopUpText(), "Only numeric Integer characters allowed");
            filterPage.clickPopUpOk();
            filterPage.inputDesiredOutputCount(1, "!@#$");
            filterPage.inputConditionName(1, 1, "");
            commMethods.verifyString(filterPage.getpopUpText(), "Only numeric Integer characters allowed");
            filterPage.clickPopUpOk();
            filterPage.inputDesiredOutputCount(1, "10");
            filterPage.inputOutputTableName("@!)#*$()@#*");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getErrorMessage2(),
                    "Output Table name: '@!)#*$()@#*' can contain only character,number or underscore and should not start with a number.");
            filterPage.inputOutputTableName("");
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.gettextMessage(), "Please enter output table name");
            filterPage.inputOutputTableName("output");
            filterPage.clickAddNewGroupBtn();
            filterPage.inputGroupName(2, "G2");
            commMethods.verifyboolean(filterPage.isGroupPresent(2), true);
            filterPage.removeGroupTwo();
            commMethods.verifyboolean(filterPage.isGroupPresent(2), false);
            filterPage.clickDupliGrpButton(1);
            filterPage.selectGroupsToDuplicate("1");
            filterPage.clickDupliGrpOk();
            commMethods.verifyboolean(filterPage.isGroupPresent(2), true);
            filterPage.removeGroupTwo();
            filterPage.removeGroupTwo();
            filterPage.clickSaveButton();
            commMethods.verifyString(filterPage.getPageHeader(), "Filtering");
            projDashBoardPage.clickDataProcessingTab();
        } else
        {

            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickFilteringButton();
            String fProcessName = commMethods.getFinalProcessName();
            filterPage.inputProcessName(processName);
            filterPage.selectProcess(process);
            filterPage.selectData(data);
            commMethods.selectTheGroups(inputGroups);
            filterPage.inputOutputTableName(outputTableName);
            filterPage.selectPerformCuts_CB(performCuts);
            filterPage.inputGroupName(1, group1Name);

            // Group 1 Condition 1
            filterPage.inputConditionName(1, 1, g1c1Name);
            filterPage.inputTableAndFieldC1(1, g1c1TableField);
            filterPage.selectRangeOrValue(1, 1, 1, g1c1RangVal);
            if ("Range".equalsIgnoreCase(g1c1RangVal))
            {
                // if("FL_ID_479".equalsIgnoreCase(tc_ID)) {
                // filterPage.inputRangeFromTo_Float(1,1,1,g1c1FromTo);}
                // else {
                filterPage.inputRangeFromTo(1, 1, 1, g1c1FromTo);

            } else if ("Value".equalsIgnoreCase(g1c1RangVal))
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value);
            }
            filterPage.inputDesiredOutputCount(1, group1DOC);

            // TEST CASE STARTS
            if ("FL_ID_245".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickDupliGrpButton(1);
                filterPage.selectGroupsToDuplicate("10");
                filterPage.clickDupliGrpOk();
                filterPage.inputGroupName1(1, "TEST1");
                filterPage.inputGroupName1(2, "TEST2");
                filterPage.inputGroupName1(3, "TEST3");
                filterPage.inputGroupName1(4, "TEST4");
                filterPage.inputGroupName1(5, "TEST5");
                filterPage.inputGroupName1(6, "TEST6");
                filterPage.inputGroupName1(7, "TEST7");
                filterPage.inputGroupName1(8, "TEST8");
                filterPage.inputGroupName1(9, "TEST9");
                filterPage.inputGroupName1(10, "TEST10");
                filterPage.inputGroupName1(11, "TEST11");
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            } else if ("FL_ID_219".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Input_Table = filStatsView.getInputTableName();
                String Output_FL = filStatsView.getOutputTableNameWithFLAsInput();
                commMethods.verifyboolean(commMethods.is_FL_FAIL_CODE_MATCH(commMethods.getMap_FL_FC_NOT_NULL(Input_Table), Output_FL), true);
            } else if ("FL_ID_213".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Output_FL = filStatsView.getOutputTableNameWithFLAsInput();
                commMethods.verifyLong(filStatsView.getInputTableCount() - filStatsView.getInputRecordsSelectedForProcessing_Long(),
                        commMethods.gRFGP_GroupCondi_NULL(Output_FL));
            } else if ("FL_ID_211".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Output_FL = filStatsView.getOutputTableNameWithFLAsInput();
                commMethods.verifyLong(filStatsView.getInputRecordsSelectedForProcessing_Long(), commMethods.gRFGP_Group_A_R(Output_FL));
            } else if ("FL_ID_210".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Output_FL = filStatsView.getOutputTableNameWithFLAsInput();
                commMethods.verifyLong(filStatsView.getInputTableCount() - filStatsView.getInputRecordsSelectedForProcessing_Long(),
                        commMethods.getRecordsFromGP_with_Grp_Name(Output_FL, "_fl_other"));
            } else if ("FL_ID_209".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Input_TABLE = filStatsView.getInputTableName();
                commMethods.verifyLong(filStatsView.getInputRecordsSelectedForProcessing_Long(),
                        commMethods.getRecordsFromGP_with_Grp_Name(Input_TABLE, inputGroups));
            } else if ("FL_ID_191".equalsIgnoreCase(tc_ID) || "FL_ID_189".equalsIgnoreCase(tc_ID) || "FL_ID_194".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Input_HEADER = filStatsView.getInputTableName();
                String Output_FL = filStatsView.getOutputTableName();
                if ("FL_ID_191".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyboolean(
                            commMethods.if_FC_CT_for_ACC_SAME_REJ(commMethods.getMap_FL_DP_FC_GRP(Output_FL, "_fl_surplus"), Input_HEADER), true);
                } else if ("FL_ID_189".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyboolean(
                            commMethods.ifFailCodeMatchesDP_Num(commMethods.getMap_FL_DP_FC_GRP(Output_FL, group1Name), Input_HEADER), true);
                } else if ("FL_ID_194".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyboolean(
                            commMethods.if_FC_CT_for_ACC_SAME_REJ(commMethods.getMap_FL_DP_FC_GRP(Output_FL, "_fl_other"), Input_HEADER), true);

                }
            } else if ("FL_ID_198".equalsIgnoreCase(tc_ID))
            {
                String[] arrg1c1TableField = g1c1TableField.split(",");
                String[] arrg1c2TableField = g1c2TableField.split(",");
                String[] arrg1c1FromTo = g1c1FromTo.split(",");
                filterPage.inputTableAndFieldC1(1, g1c2TableField);
                filterPage.selectRangeOrValue(1, 1, 2, g1c2RangVal);
                filterPage.selectValueOptionSign(1, 1, 2, g1c2ValueSign);
                filterPage.inputValue(1, 1, 2, g1c2Value);
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProcessName);
                // driver.switchTo().frame("sb-player");
                String Input_HEADER = filStatsView.getInputTableName();
                String Output_FL = filStatsView.getOutputTableName();
                commMethods.verifyLong(commMethods.getCountofRecordsFOR_AND_CONDITION(Input_HEADER, arrg1c1TableField[1], arrg1c1FromTo[0],
                        arrg1c1FromTo[1], arrg1c2TableField[1], g1c2Value), commMethods.getRecordsFromGP_with_Grp_Name(Output_FL, group1Name));

            } else if ("FL_ID_223".equalsIgnoreCase(tc_ID))
            {
                String jobNo = filterPage.getJobId();
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                commMethods.verifyString(filSummPage.getProcessSelected(), process);
                commMethods.verifyString(filSummPage.getJobNoDisplayed(), jobNo);
                commMethods.verifyString(filSummPage.getDataSelected(), data);
                commMethods.verifyString(filSummPage.getOutputTableNameProvided(), outputTableName);
                commMethods.verifyString(filSummPage.getPerformCutsSelected(), performCuts);
                commMethods.verifyString(filSummPage.getG1NameProvided(), group1Name);
                commMethods.verifyString(filSummPage.getDesiredOutputCount(), group1DOC);
                commMethods.verifyString(filSummPage.getFieldNameSelected(), g1c1TableField.replace(",", "."));
                commMethods.verifyString(filSummPage.getRangeValuesSelected(), g1c1Value);

            } else if ("FL_ID_226".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());

            } else if ("FL_ID_555".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.gettextMessage(), "Please enter output table name");

            } else if ("FL_ID_570".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");

            } else if ("FL_ID_571".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.gc1ValueTextBox.getAttribute("value"), "^");

            } else if ("FL_ID_479".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryFIL();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                dpHomePage.selectDuplicateFIL();
                dpHomePage.selectEditFIL();
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            } else if ("FL_ID_467".equalsIgnoreCase(tc_ID))
            {
                // Validate that the name of the "Desired Output" field is changed to "Desired Output Count"
                commMethods.verifyString(filterPage.testDesiredOutputCountlabel(), "Desired Output Count :");
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            } else if ("FL_ID_491".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryFIL();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            } else if ("FL_ID_423".equalsIgnoreCase(tc_ID))
            {
                commMethods.verifyboolean(filterPage.performCuts_CB.isEnabled(), true);
            } else if ("FL_ID_418".equalsIgnoreCase(tc_ID))
            {
                filterPage.selectData("STEP_FLAG_TBL");
                commMethods.verifyboolean(filterPage.performCuts_CB.isSelected(), true);
                filterPage.clickSaveButton();
                commMethods.verifyboolean(filterPage.performCuts_CB.isSelected(), true);
            } else if ("FL_ID_417".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyString(filStatsView.getInputRecordsSelectedForProcessing(), group1DOC);
            } else if ("FL_ID_416".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.G1DOC.getAttribute("value"), group1DOC);
            } else if ("FL_ID_413".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickInsrtCondiButton(1);
                filterPage.inputConditionName(1, 2, g1c2Name);
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "Please select the condition fields for group 1");
                filterPage.clickPopUpOk();
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.getpopUpText(), "Please select the condition fields for group 1");
                filterPage.clickPopUpOk();
            } else if ("FL_ID_411".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickDupliCondiG1C1();
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.conditionNameG1C2.getAttribute("value"), g1c1Name);
            } else if ("FL_ID_410".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.gettextMessage(), "Please select at least one filter group");
            } else if ("FL_ID_404".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "Only numeric characters allowed for desired output.");
                filterPage.clickPopUpOk();
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "Only numeric Integer characters allowed");

            } else if ("FL_ID_405".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyboolean(filterPage.getErrorMessage1().startsWith("Error: The value ["), true);
            } else if ("FL_ID_343".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyboolean(filStatsView.isRecordTypeDisplayed(), true);
            } else if ("FL_ID_308".equalsIgnoreCase(tc_ID) || "FL_ID_309".equalsIgnoreCase(tc_ID) || "FL_ID_496".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods
                        .verifyString(filterPage.getpopUpText(),
                                "Error: Range values must be one data type, either all numeric or all letters. Number/Alpha combinations must use the Value option for group G1");
            } else if ("FL_ID_307".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods
                        .verifyLong(filStatsView.getTotalOutputGrp1(), commMethods.gRGP_FF_CSZ_SPACES(filStatsView.getInputTableName(), g1c1Value));

            } else if ("FL_ID_303".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                filSummPage.clickBack_Button();
                commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
                String arr_FromTO[] = g1c1FromTo.split(",");
                filterPage.inputRangeFrom(1, 1, 1, arr_FromTO[1]);
                filterPage.inputRangeTo(1, 1, 1, arr_FromTO[0]);
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "'To' value can not be less than 'From' value for group G1");

            } else if ("FL_ID_302".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                filSummPage.clickBack_Button();
                commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
                String arr_FromTO[] = g1c1FromTo.split(",");
                filterPage.inputRangeFrom(1, 1, 1, arr_FromTO[1]);
                filterPage.inputRangeTo(1, 1, 1, arr_FromTO[0]);
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "'To' value can not be less than 'From' value for group G1");
            } else if ("FL_ID_300".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods
                        .verifyString(filterPage.getpopUpText(),
                                "Error: Range values must be one data type, either all numeric or all letters. Number/Alpha combinations must use the Value option for group G1");
                filterPage.clickPopUpOk();
                filterPage.clearRangeFromTo(1, 1, 1);
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.getpopUpText(), "Please enter the Range for group 1");
            } else if ("FL_ID_298".equalsIgnoreCase(tc_ID))
            {
                String arrG1C1FromTo[] = g1c1FromTo.split(",");
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                Long Stats_UpperCase = filStatsView.getTotalOutputGrp1();
                driver.switchTo().defaultContent();
                projDashBoardPage.clickCloseButtonStats();
                projDashBoardPage.clickDataProcessingTab();
                dpHomePage.selectDuplicateFIL();
                dpHomePage.selectEditFIL();
                String fProcessName_2 = commMethods.getFinalProcessName();
                filterPage.inputRangeFrom(1, 1, 1, arrG1C1FromTo[0].toLowerCase());
                filterPage.inputRangeTo(1, 1, 1, arrG1C1FromTo[1].toLowerCase());
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName_2), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName_2);
                // driver.switchTo().frame("sb-player");
                Long Stats_LowerCase = filStatsView.getTotalOutputGrp1();
                commMethods.verifyLong(Stats_UpperCase, Stats_LowerCase);
                driver.switchTo().defaultContent();
                projDashBoardPage.clickCloseButtonStats();
            } else if ("FL_ID_297".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getOutputG1C1(), commMethods.gRGP_Char_Range_M_I(filStatsView.getInputTableName(), g1c1FromTo));
            } else if ("FL_ID_295".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods
                        .verifyboolean(
                                filterPage
                                        .getRangeFieldTypeErrorMessage1()
                                        .contains(
                                                "Error: The value [AB] entered within Condition [1] of Group [1] does not match the database field type [bigint] defined for"),
                                true);
                commMethods
                        .verifyboolean(
                                filterPage
                                        .getRangeFieldTypeErrorMessage2()
                                        .contains(
                                                "Error: The value [CD] entered within Condition [1] of Group [1] does not match the database field type [bigint] defined for"),
                                true);
            } else if ("FL_ID_294".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods
                        .verifyboolean(
                                filterPage
                                        .getValueFieldTypeErrorMessage()
                                        .contains(
                                                "Error: The value [ABCDEF] entered within Condition [1] of Group [1] does not match the database field type [bigint] defined for"),
                                true);
            } else if ("FL_ID_290".equalsIgnoreCase(tc_ID) || "FL_ID_291".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                if ("FL_ID_290".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyLong(filStatsView.getOutputG1C1(),
                            commMethods.getRecordsFromGP_M_I_NOT_EQUAL_NULL(filStatsView.getInputTableName()));
                } else
                {
                    commMethods.verifyLong(filStatsView.getOutputG1C1(),
                            commMethods.getRecordsFromGP_MLA_NOT_EQUAL_NULL(filStatsView.getInputTableName()));
                }
            } else if ("FL_ID_285".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectDuplicateFIL();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectEditFIL();
                commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 1, 1), true);
                filterPage.selectValueOptionSign(1, 1, 1, "isNull");
                commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 1, 1), false);
                filterPage.selectValueOptionSign(1, 1, 1, "greater");
                commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 1, 1), true);
                filterPage.selectValueOptionSign(1, 1, 1, "isNotNull");
                commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 1, 1), false);
            } else if ("FL_ID_270".equalsIgnoreCase(tc_ID))
            {
                commMethods.verifyboolean(filterPage.isGroup1Displayed(), true);
                filterPage.clickRemoveG1C1();
                commMethods.verifyboolean(filterPage.isGroup1Displayed(), false);
            } else if ("FL_ID_269".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.firstGroupName_Field.getAttribute("value"), group1Name);
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            } else if ("FL_ID_267".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryFIL();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getOutputG1C1(),
                        commMethods.getRecordsFromGP_M_I_NOT_EQUAL_NULL(filStatsView.getInputTableName()));
            } else if ("FL_ID_266".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryFIL();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getOutputG1C1(), commMethods.getRecordsFromGP_M_I_EQUAL_NULL(filStatsView.getInputTableName()));
            } else if ("FL_ID_259".equalsIgnoreCase(tc_ID))
            {
                String fromTO[] = g1c1FromTo.split(",");
                filterPage.clickSaveButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectDuplicateFIL();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectEditFIL();
                commMethods.verifyString(filterPage.processName_Field.getAttribute("value"), processName);
                commMethods.verifyString(filterPage.processSelected.getText(), process);
                commMethods.verifyString(filterPage.dataSelected.getAttribute("value"), data);
                commMethods.verifyString(filterPage.outputTableName_Field.getAttribute("value"), outputTableName);
                commMethods.verifyboolean(filterPage.isPerformCutsSelected(), true);
                commMethods.verifyString(filterPage.firstGroupName_Field.getAttribute("value"), group1Name);
                commMethods.verifyString(filterPage.conditionNameG1C1.getAttribute("value"), g1c1Name);
                commMethods.verifyString(filterPage.g1c1RangeOrValue.getText(), g1c1RangVal);
                commMethods.verifyString(filterPage.g1c1RangeFrom.getAttribute("value"), fromTO[0]);
                commMethods.verifyString(filterPage.g1c1RangeTo.getAttribute("value"), fromTO[1]);
            } else if ("FL_ID_246".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickSaveButton();
                projDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectDuplicateFIL();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectEditFIL();
                commMethods.verifyboolean(filterPage.isAllRecordsSelectedGrp(), true);
                commMethods.verifyboolean(filterPage.isGrp1Selected(), true);
                commMethods.verifyboolean(filterPage.isGrp2Selected(), true);
                commMethods.verifyboolean(filterPage.isGrp3Selected(), true);
            } else if ("FL_ID_244".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.gettextMessage(), "Please select atleast one filter group");
                filterPage.clickSaveButton();
                commMethods.verifyString(filterPage.gettextMessage(), "Please select at least one filter group");
            } else if ("FL_ID_242".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                filSummPage.clickBack_Button();
                commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
                filterPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
            } else if ("FL_ID_241".equalsIgnoreCase(tc_ID) || "FL_ID_306".equalsIgnoreCase(tc_ID) || "FL_ID_400".equalsIgnoreCase(tc_ID)
                    || "FL_ID_414".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            } else if ("FL_ID_238".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(), 0L);
                commMethods.verifyLong(filStatsView.getTotalOutputGrp1(), 0L);
            } else if ("FL_ID_229".equalsIgnoreCase(tc_ID))
            {
                filterPage.inputOutputTableName("");
                filterPage.clickContinueButton();
                commMethods.verifyString(filterPage.gettextMessage(), "Please enter output table name");
                filterPage.inputOutputTableName("@!)#*$()@#*");
                filterPage.clickContinueButton();
                commMethods
                        .verifyString(filterPage.getErrorMessage2(),
                                "Error: Output Table name: '@!)#*$()@#*' can contain only character,number or underscore and should not start with a number.");
            } else if ("FL_ID_225".equalsIgnoreCase(tc_ID))
            {
                commMethods.verifyString(filterPage.getJobId(), "");
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
            } else if ("FL_ID_200".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_AGE_NOT_EQUAL(filStatsView.getInputTableName(), g1c1Value));
            } else if ("FL_ID_201".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_AGE_GREATER(filStatsView.getInputTableName(), g1c1Value));
            } else if ("FL_ID_202".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_AGE_LESS(filStatsView.getInputTableName(), g1c1Value));
            } else if ("FL_ID_203".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_AGE_GREATEREQUAL(filStatsView.getInputTableName(), g1c1Value));
            } else if ("FL_ID_204".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_AGE_LESSEQUAL(filStatsView.getInputTableName(), g1c1Value));
            } else if ("FL_ID_207".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(filStatsView.getInputTableName()), filStatsView.getTotalOutputGrp1()
                        + filStatsView.getSurplusCountUI() + filStatsView.getOtherCountUI());
            } else if ("FL_ID_190".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyboolean(filStatsView.isRecordTypeDisplayed(), true);
                commMethods.verifyLong(filStatsView.getTotalOutputGrp1(), Long.parseLong(group1DOC));
                commMethods.verifyLong(filStatsView.getInputTableCount(), commMethods.getRecordsFromGP(filStatsView.getInputTableName()));
                commMethods.verifyLong(filStatsView.getOutputTableCount(), commMethods.getRecordsFromGP(filStatsView.getOutputTableName()));
                commMethods.verifyLong(filStatsView.getOutputG1C1(),
                        commMethods.getRecordsFromGP_for_FL_AGE(filStatsView.getInputTableName(), g1c1FromTo));
                commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                        commMethods.getRecordsFromGP_for_FL_AGE(filStatsView.getInputTableName(), g1c1FromTo));
                commMethods.verifyLong(filStatsView.getSurplusCountUI(), filStatsView.getTotalAcceptedGrp1() - filStatsView.getTotalOutputGrp1());
                commMethods.verifyLong(filStatsView.getOtherCountUI(), filStatsView.getInputCountGrp1() - filStatsView.getTotalOutputGrp1()
                        - filStatsView.getSurplusCountUI());
                commMethods.verifyLong(filStatsView.getInputTableCount(), filStatsView.getTotalOutputGrp1() + filStatsView.getSurplusCountUI()
                        + filStatsView.getOtherCountUI());
                commMethods.verifyLong(filStatsView.getTotalOutputGrp1(),
                        commMethods.getRecordsFromGP_with_Grp_Name(filStatsView.getOutputTableName(), group1Name));
                commMethods.verifyLong(filStatsView.getSurplusCountUI(),
                        commMethods.getRecordsFromGP_with_Grp_Name(filStatsView.getOutputTableName(), "_fl_surplus"));
                commMethods.verifyLong(filStatsView.getOtherCountUI(),
                        commMethods.getRecordsFromGP_with_Grp_Name(filStatsView.getOutputTableName(), "_fl_other"));
            } else if ("FL_ID_193".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(filStatsView.getOtherCountUI(),
                        filStatsView.getInputTableCount() - commMethods.getRecordsFromGP_for_FL_AGE(filStatsView.getInputTableName(), g1c1FromTo));
            } else if ("FL_ID_196".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
                filSummPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyboolean(filStatsView.isRecordTypeDisplayed(), false);
            } else if ("FL_ID_309".equalsIgnoreCase(tc_ID))
            {
                filterPage.clickContinueButton();
            } else
            {
                // Group 1 Condition 2
                filterPage.clickInsrtCondiButton(1);
                filterPage.inputConditionName(1, 2, g1c2Name);
                filterPage.inputTableAndFieldC2(1, g1c2TableField);
                filterPage.selectRangeOrValue(1, 2, 1, g1c2RangVal);
                if ("Range".equalsIgnoreCase(g1c2RangVal))
                {
                    filterPage.inputRangeFromTo(1, 2, 1, g1c2FromTo);
                } else if ("Value".equalsIgnoreCase(g1c2RangVal))
                {
                    filterPage.selectValueOptionSign(1, 2, 1, g1c2ValueSign);
                    filterPage.inputValue(1, 2, 1, g1c2Value);
                }
                if ("FL_ID_197".equalsIgnoreCase(tc_ID))
                {
                    filterPage.clickContinueButton();
                    filSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyboolean(filStatsView.isRecordTypeDisplayed(), true);
                    commMethods.verifyLong(filStatsView.getTotalOutputGrp1(), Long.parseLong(group1DOC));
                    commMethods.verifyLong(filStatsView.getInputTableCount(), commMethods.getRecordsFromGP(filStatsView.getInputTableName()));
                    commMethods.verifyLong(filStatsView.getOutputTableCount(), commMethods.getRecordsFromGP(filStatsView.getOutputTableName()));
                    commMethods.verifyLong(filStatsView.getOutputG1C1(),
                            commMethods.getRecordsFromGP_for_FL_AGE(filStatsView.getInputTableName(), g1c1FromTo));
                    commMethods.verifyLong(filStatsView.getOutputG1C2(),
                            commMethods.getRecordsFromGP_for_F_NAME(filStatsView.getInputTableName(), g1c2Value));
                    commMethods.verifyLong(filStatsView.getTotalAcceptedGrp1(),
                            commMethods.getRecordsFromGP_F_NAME_AND_AGE_RANGE(filStatsView.getInputTableName(), g1c1FromTo, g1c2Value));
                    commMethods.verifyLong(filStatsView.getInputTableCount(), filStatsView.getTotalOutputGrp1() + filStatsView.getSurplusCountUI()
                            + filStatsView.getOtherCountUI());
                    commMethods.verifyLong(filStatsView.getOtherCountUI(), filStatsView.getInputCountGrp1() - filStatsView.getTotalOutputGrp1()
                            - filStatsView.getSurplusCountUI());
                } else
                {
                    // Group 2 Condition 1
                    System.out.println("Result: " + filterPage.addNewGroup_Btn.getText());
                    filterPage.clickAddNewGroupBtn();
                    filterPage.inputGroupName(2, group2Name);
                    filterPage.inputDesiredOutputCount(2, group2DOC);
                    filterPage.inputConditionName(2, 1, g2c1Name);
                    filterPage.inputTableAndFieldC1(2, g2c1TableField);
                    filterPage.selectRangeOrValue(2, 1, 1, g2c1RangVal);
                    if ("Range".equalsIgnoreCase(g2c1RangVal))
                    {
                        filterPage.inputRangeFromTo(2, 1, 1, g2c1FromTo);
                    } else if ("Value".equalsIgnoreCase(g2c1RangVal))
                    {
                        filterPage.selectValueOptionSign(2, 1, 1, g2c1ValueSign);
                        filterPage.inputValue(2, 1, 1, g2c1Value);
                    }

                    // Group 2 Condition 2
                    filterPage.clickInsrtCondiButton(2);
                    filterPage.inputConditionName(2, 2, g2c2Name);
                    filterPage.inputTableAndFieldC2(2, g2c2TableField);
                    filterPage.selectRangeOrValue(2, 2, 1, g2c2RangVal);
                    if ("Range".equalsIgnoreCase(g2c2RangVal))
                    {
                        filterPage.inputRangeFromTo(2, 2, 1, g2c2FromTo);
                    } else if ("Value".equalsIgnoreCase(g2c2RangVal))
                    {
                        filterPage.selectValueOptionSign(2, 2, 1, g2c2ValueSign);
                        filterPage.inputValue(2, 2, 1, g2c2Value);
                    }

                    if ("FL_ID_568".equalsIgnoreCase(tc_ID))
                    {
                        filterPage.clickSaveButton();
                        projDashBoardPage.clickDataProcessingTab();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                        dpHomePage.selectEditFIL();
                        filterPage.clickContinueButton();
                        commMethods.verifyString(projDashBoardPage.getPageTitle(),
                                "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                        filSummPage.clickSubmitButton();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());

                    } else if ("FL_ID_422".equalsIgnoreCase(tc_ID))
                    {
                        filterPage.clickSaveButton();
                        projDashBoardPage.clickDataProcessingTab();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                        dpHomePage.selectDuplicateFIL();
                        dpHomePage.selectSummaryFIL();
                        String newProcessId = filSummPage.getProcessIDSummary();
                        filSummPage.clickSubmitButton();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                        projDashBoardPage.clickHomeTab();
                        commMethods.verifyString(projDashBoardPage.verifyProcess(newProcessId), "PASS");

                    } else if ("FL_ID_131".equalsIgnoreCase(tc_ID))
                    {
                        commMethods.verifyString(filterPage.outputTableName_Field.getAttribute("value"), "FILTERTBL");
                        filterPage.clickContinueButton();
                        filSummPage.clickSubmitButton();
                        projDashBoardPage.clickHomeTab();
                        commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    } else if ("FL_ID_208".equalsIgnoreCase(tc_ID))
                    {
                        filterPage.clickContinueButton();
                        filSummPage.clickSubmitButton();
                        projDashBoardPage.clickHomeTab();
                        commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                        projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                        // driver.switchTo().frame("sb-player");
                        commMethods.verifyLong(commMethods.getRecordsFromGP(filStatsView.getInputTableName()), filStatsView.getTotalOutputGrp1()
                                + filStatsView.getTotalOutputGrp2() + filStatsView.getOtherCountUI() + filStatsView.getSurplusCountUI());
                        driver.switchTo().defaultContent();
                        projDashBoardPage.clickCloseButtonStats();
                    } else if ("FL_ID_239".equalsIgnoreCase(tc_ID))
                    {
                        filterPage.clickContinueButton();
                        commMethods.verifyString(filterPage.getpopUpText(), "Duplicate found: G1");
                        filterPage.clickPopUpOk();
                    } else if ("FL_ID_240".equalsIgnoreCase(tc_ID))
                    {
                        filterPage.clickContinueButton();
                        filSummPage.clickSubmitButton();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                        module.initializeDriver(driver);
                        dpHomePage.selectDuplicateFIL();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                        dpHomePage.selectEditFIL();
                        commMethods.verifyString(projDashBoardPage.getPageTitle(), "Filtering");
                        filterPage.clickContinueButton();
                        commMethods.verifyString(projDashBoardPage.getPageTitle(),
                                "Summary: Filtering Review the information below, and then click 'Submit' or 'Back'.");
                        filSummPage.clickSubmitButton();
                        commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    } else if ("FL_ID_286".equalsIgnoreCase(tc_ID))
                    {
                        commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 1, 1), false);
                        commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(1, 2, 1), false);
                        commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(2, 1, 1), false);
                        commMethods.verifyboolean(filterPage.isGroupConditionTextBoxDisplayed(2, 2, 1), false);
                    }

                }

            }
        }
    }

    @Title("Filtering Condition Test")
    @Description("Create group with condditions")
    @Test(dataProvider = "FilteringStats_CBA", priority = 2)
    // DEV
    public void filteringConditionValidation(String tc_ID, String testRun, String tc, String description, String copyProj, String copyProcess,
            String processName, String process, String jobNum, String data, String inputGroups, String outputTableName,
            String performCuts, String group1Name, String group1DOC, String g1c1Name, String g1c1TableField, String g1c1RangVal, String g1c1FromTo,
            String g1c1ValueSign, String g1c1Value, String g1c2Name, String g1c2TableField, String g1c2RangVal, String g1c2FromTo,
            String g1c2ValueSign, String g1c2Value, String group2Name, String group2DOC, String g2c1Name, String g2c1TableField, String g2c1RangVal,
            String g2c1FromTo, String g2c1ValueSign, String g2c1Value, String g2c2Name, String g2c2TableField, String g2c2RangVal, String g2c2FromTo,
            String g2c2ValueSign, String g2c2Value, ITestContext testContext) throws InterruptedException, SQLException
    {

        projDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickFilteringButton();
        filterPage.processName_Field.clear();
        filterPage.processName_Field.sendKeys(processName);
        String assignedId = commMethods.getProcId();
        String processes[] = process.split(",");
        String dataSelect[] = data.split(",");
        filterPage.selectProcess(processes[0]);
        filterPage.selectData(dataSelect[0]);
        // added
        String isGroupPresent = fffPage.isGroupPresent();
        if ("block".equalsIgnoreCase(isGroupPresent))
        {
            commMethods.selectTheGroups(inputGroups);
        }
        String tableField[] = g1c1TableField.split(";");

        if (!"NA".equalsIgnoreCase(group1Name))
        {
            filterPage.inputGroupName(1, group1Name);
        }
        if (!"NA".equalsIgnoreCase(group1DOC))
        {
            filterPage.inputDesiredOutputCount(1, group1DOC);
        }
        if (!"NA".equalsIgnoreCase(g1c1Name))
        {
            filterPage.inputConditionName(1, 1, g1c1Name);
        }
        if (!"NA".equalsIgnoreCase(g1c1TableField))
        {

            filterPage.inputTableAndFieldC1(1, tableField[0]);
        }

        if (!"NA".equalsIgnoreCase(g1c1RangVal))
        {
            filterPage.selectRangeOrValue(1, 1, 1, g1c1RangVal);
        }
        if (!"NA".equalsIgnoreCase(g1c1ValueSign))
        {
            filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
        }
        if (!"NA".equalsIgnoreCase(g1c1Value))
        {
            filterPage.inputValue(1, 1, 1, g1c1Value);
            // filterPage.clickSaveButton();
        }
        if ("FL_ID_342".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickContinueButton();

            String pageTile = filterPage.checkIfMovedToSummaryPageWithTile();
            assertTrue(pageTile.contains("Summary: Filtering"));
        }

        if ("FL_ID_401".equalsIgnoreCase(tc_ID))
        {
            filterPage.selectProcess(processes[1]);
            commMethods.verifyString(filterPage.getpopUpText(),
                    "Please select the Resolve fields option to resolve the fields, as you have changed the input");
            filterPage.clickPopUpOk();
            Thread.sleep(5000);
            filterPage.selectData(dataSelect[1]);
            filterPage.clickResolveFields();

            String arg = processes[1].split(":")[0] + ":" + dataSelect[1];
            driver.switchTo().frame("sb-player");
            // String arg1 = assignedId + ":" + dataSelect[1];
            filterPage.clickFieldOnResolveFieldsWindow();
            filterPage.selectFieldOnResolveFieldsWindow(arg, tableField[1].toString());

            filterPage.addFieldOnResolveFieldsWindow();
            String toolTipText = filterPage.getTooltipText();
            System.out.println("Text----->>" + toolTipText);
            commMethods.verifyString(toolTipText, tableField[1].toString());

            LOGGER.info("Test passed" + toolTipText);

        }

        if ("FL_ID_402".equalsIgnoreCase(tc_ID))
        {

            filterPage.selectJobNumberWhenMulArchive(jobNum);
            Thread.sleep(2000);
            filterPage.clickContinueButton();
            filterPage.clickContinueButton();
            Thread.sleep(4000);
            dpHomePage.clickDataProcessingTab();
            String status = commMethods.getDPProcessStatus();
            commMethods.verifyString(status.trim(), StatusEnum.READY.name());

            projDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackPage.inputStackName(processName);

            String new_process_name = assignedId + ":" + "" + processName;
            jobStackPage.clickProcessDropDown();
            jobStackPage.selectProcessFromDropdown(new_process_name);
            jobStackPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(new_process_name);
            jobStackPage.selectTheProcessFromTheFlowChart(processList,30);
            jobStackPage.clickJobStackingSubmitButton();
            Thread.sleep(5000);
            projDashBoardPage.clickHomeTab();
            String Status = projDashBoardPage.verifyProcess(processName);
            commMethods.verifyString(Status.trim(), "PASS");
        }

        if ("FL_ID_407".equalsIgnoreCase(tc_ID))
        {
            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value);
            }
            filterPage.clickContinueButton();
            filSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String ProcessName1 = projDashBoardPage.jobName();
            String finalStatus = projDashBoardPage.verifyProcess(ProcessName1);
            String selectedField[] = g1c1TableField.split(",");
            commMethods.verifyString("PASS", finalStatus);

            projDashBoardPage.viewStats(ProcessName1);
            String field = data + "." + selectedField[1];

            String count = filterPage.getColumnCountFromStats(field);
            projDashBoardPage.gpConnect();

            long countVal = projDashBoardPage.getColumnCountFromGP(filterPage.getInputTableNameFL(), selectedField[1], g1c1Value);
            commMethods.verifyLong(Long.valueOf(count), countVal);

        }

        if ("FL_ID_253".equalsIgnoreCase(tc_ID))
        {

            filterPage.clickSaveButton();
            filterPage.selectData(dataSelect[0]);
            /*
             * commMethods.verifyString(filterPage.getpopUpText(),
             * "Please select the Resolve fields option to resolve the fields, as you have changed the input");
             */
            // filterPage.clickPopUpOk();
            // Thread.sleep(5000);

            String procId[] = process.split(":");
            String selectedField[] = g1c1TableField.split(",");
            commMethods.verifyString(group1Name, filterPage.getGroupNameValue());
            commMethods.verifyString(procId[0] + ": " + dataSelect[0] + "." + selectedField[1], filterPage.getConditionFieldName(0, 0, 0));
        }
        if ("FL_ID_254".equalsIgnoreCase(tc_ID))
        {
            // filterPage.selectProcess(process);
            filterPage.clickSaveButton();
            filterPage.selectProcess(processes[1]);
            commMethods.verifyString(filterPage.getpopUpText(),
                    "Please select the Resolve fields option to resolve the fields, as you have changed the input");
            filterPage.clickPopUpOk();
            Thread.sleep(5000);
            // filterPage.selectData("INPUT");
            String procId[] = process.split(":");
            String selectedField[] = g1c1TableField.split(",");
            commMethods.verifyString(group1Name, filterPage.getGroupNameValue());
            commMethods.verifyString(procId[0].trim() + ": " + data + "." + selectedField[1], filterPage.getConditionFieldName(0, 0, 0));
        }
        if ("FL_ID_257".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickSaveButton();
            dpHomePage.clickDataProcessingTab();
            commMethods.verifyboolean(true, filterPage.clickOnGearBoxForEditFilterProcess());
        }
        if ("FL_ID_258".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickSaveButton();
            filterPage.selectProcess(processes[1]);

            filterPage.clickPopUpOk();
            filterPage.selectData(data);
            // filterPage.clickpopUpText();
            filterPage.clickContinueButton();
            commMethods.verifyString(filterPage.getpopUpText(),
                    "Please select the Resolve fields option to resolve the fields, as you have changed the input");
        }
        if ("FL_ID_261".equalsIgnoreCase(tc_ID))
        {

            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                // filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value);
            }

            filterPage.clickContinueButton();
            filSummPage.clickSubmitButton();
            commMethods.clickHomeTab();
            Thread.sleep(5000);
            projDashBoardPage.clickHomeTab();
            String ProcessName1 = projDashBoardPage.jobName();
            String finalStatus = projDashBoardPage.verifyProcess(ProcessName1);

            commMethods.verifyString("PASS", finalStatus);

            // commMethods.verifyString(filterPage.getpopUpText(), "Please enter the value for group 1");
        }
        if ("FL_ID_260".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickContinueButton();
            Thread.sleep(3000);
            commMethods.verifyString(filterPage.getpopUpText(), "Please select at least one field for filtering");
        }

        if ("FL_ID_264".equalsIgnoreCase(tc_ID))
        {
            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value);
            }
            filterPage.clickContinueButton();
            filSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String ProcessName1 = projDashBoardPage.jobName();
            String finalStatus = projDashBoardPage.verifyProcess(ProcessName1);
            String selectedField[] = g1c1TableField.split(",");
            commMethods.verifyString("PASS", finalStatus);

            projDashBoardPage.viewStats(ProcessName1);
            String field = data + "." + selectedField[1];
            String count = filterPage.getColumnCountFromStats(field);
            projDashBoardPage.gpConnect();
            String value = g1c1Value.replace("^", " ");
            long countVal = projDashBoardPage.getColumnCountFromGP(filterPage.getInputTableNameFL(), selectedField[1], value);
            commMethods.verifyLong(Long.valueOf(count), countVal);

        }
        if ("MJ_ID_319".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickContinueButton();
            filSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String ProcessName1 = projDashBoardPage.jobName();
            String finalStatus = projDashBoardPage.verifyProcess(ProcessName1);

            commMethods.verifyString("PASS", finalStatus);
            Thread.sleep(1000);

            projDashBoardPage.viewStats(assignedId);

            String inputTableName = projDashBoardPage.getInputTableName();
            Long recordToBeProcessed = projDashBoardPage.getCountOfRecordsProcessedFromTheStats();
            String recordsProcessed = String.valueOf(recordToBeProcessed);
            Long recordProcessedGP = projDashBoardPage.getTheProcessedRecordCountFromGP(inputTableName);
            String recordsGP = String.valueOf(recordProcessedGP);
            commMethods.verifyString(recordsProcessed, recordsGP);

        }

        if ("FL_ID_262".equalsIgnoreCase(tc_ID))
        {

            "Value".equalsIgnoreCase(g1c1RangVal);
            {

                filterPage.inputValue(1, 1, 1, g1c1Value);
            }

            filterPage.clickSaveButton();
            filterPage.clickContinueButton();
            filSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String ProcessName1 = projDashBoardPage.jobName();
            String finalStatus = projDashBoardPage.verifyProcess(ProcessName1);

            commMethods.verifyString("PASS", finalStatus);
            Thread.sleep(1000);

            projDashBoardPage.viewStats(assignedId);

            String inputTableName = projDashBoardPage.getInputTableName();
            Long countPerConditionFromInputTable = projDashBoardPage.getRecordCountFromInputTableWithCond(inputTableName,
                    g1c1TableField.split(",")[1], g1c1Value);
            Long actualCount = projDashBoardPage.getCountOfRecordsProcessedFromTheStats() - countPerConditionFromInputTable;
            commMethods.verifyLong(actualCount, filStatsView.getOutputTableCount());
        }
        // Validated that if user provides space characters along with other characters for the conditions and Saves the Filtering Screen
        // Configuration, then the all the carat symbols should in the positions of space characters only.
        if ("FL_ID_263".equalsIgnoreCase(tc_ID))
        {
            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value); // "te st "
            }

            filterPage.clickSaveButton();
            String val = filterPage.getConditionValue(0, 0, 0);
            System.out.println("Value --->>" + val);

            commMethods.verifyString("^", String.valueOf(val.charAt(2)));
            commMethods.verifyString("^", String.valueOf(val.charAt(5)));

        }
        // Validate that if the space characters are provided in the Value text box for a condition on the Filtering Screen, then in this case,
        // equivalent number of carat symbols should be displayed under the �Range/Values� column on Summary Screen
        if ("FL_ID_265".equalsIgnoreCase(tc_ID))
        {

            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value); // "test "
            }
            filterPage.clickContinueButton();
            String valueContent = filSummPage.getRangeValueContent();
            String g1c1ValueCheck = g1c1Value.replaceAll(" ", "^");
            commMethods.verifyString(filterPage.countCaratSymbolOccurence(valueContent), filterPage.countCaratSymbolOccurence(g1c1ValueCheck));
        }
        // Validate that atleast one group is required to submit the filtering process in the Filtering screen

        // Validate that in "available fields" column the Fields list is collapsed by default when the user clicks the save button and the page
        // reloads
        if ("FL_ID_274".equalsIgnoreCase(tc_ID))
        {

            "Value".equalsIgnoreCase(g1c1RangVal);
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                // filterPage.inputValue(1, 1, 1, "test ");
            }

            filterPage.clickHeaderTable();

            // field expanded
            String eleClassName = filterPage.selectedTableClassValue();
            commMethods.verifyString("on", eleClassName);

            // save clicked
            filterPage.clickSaveButton();
            Thread.sleep(2000);

            String eleClassNameAfterSave = filterPage.selectedTableClassValue();

            commMethods.verifyString("", eleClassNameAfterSave);

        }

        // Validate that in "available fields" column the Fields list is collapsed by default comes back to filtering screen from summary screen
        if ("FL_ID_275".equalsIgnoreCase(tc_ID))
        {

            filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
            filterPage.expandTablesOnClick(g1c1TableField);

            String eleClassName = filterPage.selectedTableClassValue();
            commMethods.verifyString("on", eleClassName);
            LOGGER.info("ouput--->>" + eleClassName);

            filterPage.clickContinueButton();
            Thread.sleep(5000);
            filSummPage.clickBack_Button();
            Thread.sleep(7000);
            String eleClassNameWhenMovedBack = filterPage.selectedTableClassValue();
            LOGGER.info("ouput--->>" + eleClassNameWhenMovedBack);
            System.out.println("ouput111--->>" + eleClassName);
            System.out.println("ouput--->>" + eleClassNameWhenMovedBack);
            Thread.sleep(2000);
            commMethods.verifyString("", eleClassNameWhenMovedBack);

        }
        if ("FL_ID_272".equalsIgnoreCase(tc_ID))
        {
            /*
             * projDashBoardPage.clickDataProcessingTab(); dpHomePage.clickFilteringButton(); filterPage.processName_Field.clear();
             * filterPage.processName_Field.sendKeys(processName); filterPage.selectProcess(process);
             */

            // commMethods.verifyString("", filterPage.auditTableDefaultCollapseStatus());

            // commMethods.verifyString("", filterPage.modelTableDefaultCollapseStatus());

            commMethods.verifyString("", filterPage.selectedTableClassValue());

            // commMethods.verifyString("", filterPage.inqTableDefaultCollapseStatus());

            // commMethods.verifyString("", filterPage.agecritTableDefaultCollapseStatus());

            commMethods.verifyString("", filterPage.stepFlagTableDefaultCollapseStatus());

        }
        // Validate that groups collapse when the user clicks on the downward sign (V) placed beside the group name
        if ("FL_ID_276".equalsIgnoreCase(tc_ID))
        {

            filterPage.clickAddNewGroupBtn();
            // filterPage.clickValidationPopup();
            // Thread.sleep(2000);
            // filterPage.clickAddNewGroupBtn();
            Thread.sleep(2000);
            filterPage.collapseGroups();
            String verifyGroupStyleCollapsed = filterPage.validateGroupCollapse();
            String verifyExpandedDataWhenCollapse = filterPage.groupExandedData(1);
            commMethods.verifyString("display: none;", verifyExpandedDataWhenCollapse);
            commMethods.verifyString("display: none;", verifyGroupStyleCollapsed);

        }
        if ("FL_ID_277".equalsIgnoreCase(tc_ID))
        {

            filterPage.clickAddNewGroupBtn();
            Thread.sleep(1000);
            filterPage.collapseGroups();
            String verifyGroupStyleCollapsed = filterPage.validateGroupCollapse(); // none img1
            String verifyGroupStyleExpanded2 = filterPage.validateGroupExpand(); // inline img2
            commMethods.verifyString("display: none;", verifyGroupStyleCollapsed);

            Thread.sleep(2000);

            filterPage.expandGroups();

            String verifyGroupStyleExpanded1 = filterPage.validateGroupCollapse(); // inline img1
            String verifyGroupStyleExpanded = filterPage.validateGroupExpand(); // none img2
            // String verifyExpandedData1 = filterPage.groupExandedData();

            String verifyExpandedData = filterPage.groupExandedData(1);
            commMethods.verifyString("display: inline;", verifyGroupStyleExpanded1);
            commMethods.verifyString("display: none;", verifyGroupStyleExpanded);
            commMethods.verifyString("display: block;", verifyExpandedData);
            // filterPage.clickContinueButton();
        }

        if ("FL_ID_278".equalsIgnoreCase(tc_ID))
        {

            Thread.sleep(2000);
            filterPage.conditionExpandedIcon(0, 0);
            commMethods.verifyString("display: none;", filterPage.conditionStyleWhenCollapsed(0, 0));
            // commMethods.verifyString("display: none;", filterPage.conditionStyleWhenCollapsed(0, 0));
            String verifyExpandedData = filterPage.conditionExpandedDataStyle(0, 0);
            commMethods.verifyString("display: none;", verifyExpandedData);

        }

        // validate on adding two groups to collapse second condition
        if ("FL_ID_279".equalsIgnoreCase(tc_ID)) // doubts
        {

            filterPage.clickAddNewGroupBtn();
            filterPage.conditionExpandedIcon(1, 0);
            Thread.sleep(2000);
            commMethods.verifyString("display: none;", filterPage.conditionStyleWhenCollapsed(1, 0));
            // commMethods.verifyString("display: none;", filterPage.conditionStyleWhenCollapsed(0, 0));
            String verifyExpandedData = filterPage.conditionExpandedDataStyle(1, 0);
            commMethods.verifyString("display: none;", verifyExpandedData);

            // filterPage.clickContinueButton();
        }
        // Validate that fields expand on clicking + icon beside them
        if ("FL_ID_273".equalsIgnoreCase(tc_ID))
        {

            filterPage.clickFieldExpand();
            Thread.sleep(5000);

            commMethods.verifyString("", filterPage.verifyTableExpansion());

        }
        // the condition remains expanded on adding and collapse when clicked V again collapses on clicking >
        if ("FL_ID_280".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickAddNewGroupBtn();
            String pId[] = process.split(":");
            String selectedfield[] = g1c1TableField.split(",");
            commMethods.verifyString(pId[0] + ":" + data + "." + selectedfield[1], filterPage.getConditionFieldName(0, 0, 0));
            filterPage.conditionExpandedIcon(1, 0);

            Thread.sleep(2000);
            filterPage.conditionCollapsedIcon(1, 0);
            commMethods.verifyString(pId[0] + ":" + data + "." + selectedfield[1], filterPage.getConditionFieldName(0, 0, 0));
        }
        // validate when a condition is inserted into a group it gets into appropriate group
        if ("FL_ID_281".equalsIgnoreCase(tc_ID))
        {

            filterPage.clickAddNewGroupBtn();
            filterPage.clickInsrtCondiButton(1);
            commMethods.verifyboolean(true, filterPage.validateConditionAddsToAppropriateGroup(0));

        }
        if ("FL_ID_282".equalsIgnoreCase(tc_ID))
        {
            filterPage.clickInsrtCondiButton(1);
            filterPage.clickDupliGrpButton(1);
            filterPage.selectGroupCount("1");
            Thread.sleep(5000);
            filterPage.clickDupliGrpOk();
            String pId[] = process.split(":");
            String selectedfield[] = g1c1TableField.split(",");
            commMethods.verifyString(g1c1Name, filterPage.getConditionName(1, 0));
            commMethods.verifyString(pId[0] + ":" + data + "." + selectedfield[1], filterPage.getConditionFieldName(1, 0, 0));
            commMethods.verifyString(g1c1RangVal.toUpperCase(), filterPage.getConditionRangeValue(1, 0, 0));
            commMethods.verifyString(g1c1ValueSign.toLowerCase(), filterPage.getConditionFieldOperator(1, 0, 0).toLowerCase());
            commMethods.verifyString(g1c1Value, filterPage.getConditionFieldValueText(1, 0, 0));

        }

    }

    
    @Test(dataProvider = "FilterProcess_Reg_Base")
    // For creating the base process
    public void createBaseProcess(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String process, String jobNum, String data, String inputGroups, String outputTableName,
            String performCuts, String group1Name, String group1DOC, String g1c1Name, String g1c1TableField, String g1c1RangVal, String g1c1FromTo,
            String g1c1ValueSign, String g1c1Value, String g1c2Name, String g1c2TableField, String g1c2RangVal, String g1c2FromTo,
            String g1c2ValueSign, String g1c2Value, String group2Name, String group2DOC, String g2c1Name, String g2c1TableField, String g2c1RangVal,
            String g2c1FromTo, String g2c1ValueSign, String g2c1Value, String g2c2Name, String g2c2TableField, String g2c2RangVal, String g2c2FromTo,
            String g2c2ValueSign, String g2c2Value, ITestContext testContext) throws InterruptedException, SQLException
	{
		/*String executionStatus = commMethods.getTheExecutionStatus(process);
		if (executionStatus.equalsIgnoreCase("COMPLETED") || !"FL02_BASE".equalsIgnoreCase(tc_ID)) {
			LOGGER.info("Dependent Process Is Successfully Completed");*/
			projDashBoardPage.clickDataProcessingTab();
//			driver.switchTo().alert().accept();
			dpHomePage.clickFilteringButton();
            filterPage.inputProcessName(processName);
            filterPage.selectProcess(process);
            filterPage.selectData(data);
            commMethods.selectTheGroups(inputGroups);
            filterPage.inputOutputTableName(outputTableName);
            filterPage.selectPerformCuts_CB(performCuts);
            filterPage.inputGroupName(1, group1Name);

            // Group 1 Condition 1
            filterPage.inputConditionName(1, 1, g1c1Name);
            filterPage.inputTableAndFieldC1(1, g1c1TableField);
            filterPage.selectRangeOrValue(1, 1, 1, g1c1RangVal);
            if ("Range".equalsIgnoreCase(g1c1RangVal))
            {
                // if("FL_ID_479".equalsIgnoreCase(tc_ID)) {
                // filterPage.inputRangeFromTo_Float(1,1,1,g1c1FromTo);}
                // else {
                filterPage.inputRangeFromTo(1, 1, 1, g1c1FromTo);

            } else if ("Value".equalsIgnoreCase(g1c1RangVal))
            {
                filterPage.selectValueOptionSign(1, 1, 1, g1c1ValueSign);
                filterPage.inputValue(1, 1, 1, g1c1Value);
            }
            filterPage.inputDesiredOutputCount(1, group1DOC);
			filterPage.clickContinueButton();
			Thread.sleep(3000);
			if("FL02_BASE".equalsIgnoreCase(tc_ID)){
				projDashBoardPage.clickDataProcessingTab();
				module.initializeDriver(driver);
	            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
			} else {
				filSummPage.clickSubmitButton();
				Thread.sleep(3000);
				commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
			}
		} /*else {
			Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
		}*/

    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] FilteringStats_Y() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Filtering", "Y");
        return testObjArray_DRS;
    }

    @DataProvider
    public Object[][] FilteringStats_CBA() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Filtering", "CBA");
        return testObjArray_DRS;
    }
    
    
    @DataProvider
    public Object[][] FilterProcess_Reg_Base() throws Exception
    {
        Object[][] testObjArray_Base = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Filtering", "BAS");
        return testObjArray_Base;
    }

}
package com.equifax.cms.fusion.test.qaexttab;

import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.EXTPages.ExternalFileManagerPage;
import com.equifax.cms.fusion.test.EXTPages.ImportExternalFilePage;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

public class ExternalFileManager
{
    public static WebDriver driver;
    private CommonMethods commMethods;
    private ProjectDashBoardPage projDashBoardPage;
    private ImportExternalFilePage impExtFilePage;
    private ExternalFileManagerPage extFileManPage;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj()
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        impExtFilePage = PageFactory.initElements(driver, ImportExternalFilePage.class);
        extFileManPage = PageFactory.initElements(driver, ExternalFileManagerPage.class);
        commMethods.userLogin();
    }

    @Title("External File Verification")
    @Description("External File Test")
    @Test(dataProvider = "ExternalFile_Y", priority = 1)
    public void filteringStats(String tc_ID, String testRun, String tc, String description, String fileLoc, String fileName, String format,
            String keyPosition, String keyLength, String recLength, String projNo, String custName, String custTag, ITestContext testContext)
            throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", ExternalFileManager.driver);
        projDashBoardPage.clickSupportTools();
        extFileManPage.clickImportExternalFile();
        if ("EXT_ID_007".equalsIgnoreCase(tc_ID))
        {
            commMethods.verifyString(impExtFilePage.keyPosi_Field.getAttribute("value"), "1");
            commMethods.verifyString(impExtFilePage.keyPosi_Field.getAttribute("maxlength"), "6");
            commMethods.verifyString(impExtFilePage.keyLength_Field.getAttribute("value"), "0");
            commMethods.verifyString(impExtFilePage.keyLength_Field.getAttribute("maxlength"), "6");
            commMethods.verifyString(impExtFilePage.recLength_Field.getAttribute("value"), "0");
            commMethods.verifyString(impExtFilePage.recLength_Field.getAttribute("maxlength"), "6");
            commMethods.verifyString(impExtFilePage.projNo_Field.getAttribute("value"), "");
            commMethods.verifyString(impExtFilePage.projNo_Field.getAttribute("maxlength"), "7");
            commMethods.verifyString(impExtFilePage.custTag_Field.getAttribute("maxlength"), "128");
        } else
        {
            impExtFilePage.inputNetAppFileLoc(fileLoc);
            impExtFilePage.inputFileName(fileName);
            impExtFilePage.selectFormat(format);
            impExtFilePage.inputKeyPosition(keyPosition);
            impExtFilePage.inputKeyLength(keyLength);
            impExtFilePage.inputRecLength(recLength);
            impExtFilePage.inputProjectNo(projNo);
            impExtFilePage.selectCustomerName(custName);
            impExtFilePage.inputCustomTag(custTag);
            if ("EXT_ID_001".equalsIgnoreCase(tc_ID))
            {
                impExtFilePage.clickSaveButton();
                commMethods.verifyString(impExtFilePage.getErrorMessage(), "File Location is required");
                impExtFilePage.inputFileName("");
                impExtFilePage.inputNetAppFileLoc("/nas/users/jbodeddula/sourav/Automation/External_Files/CCSI_ACRO3_MEM04NUM.txt");
                impExtFilePage.clickSaveButton();
                commMethods.verifyString(impExtFilePage.getErrorMessage(), "File Name is required");
            } else if ("EXT_ID_002".equalsIgnoreCase(tc_ID))
            {
                impExtFilePage.clickSaveButton();
                commMethods.verifyString(impExtFilePage.getFileNotFoundErrMsg(), "File not found.");
                commMethods.verifyString(impExtFilePage.fileName_Field.getAttribute("maxlength"), "50");
            } else if ("EXT_ID_018".equalsIgnoreCase(tc_ID))
            {
                Date date = new Date();
                String dateInput = dateFormat.format(date);
                impExtFilePage.inputFileName(dateInput);
                impExtFilePage.clickSaveButton();
                commMethods.verifyString(extFileManPage.getEFMHeader(), "External File Manager Click the button to import an external file.");
            } else if ("EXT_ID_020".equalsIgnoreCase(tc_ID))
            {
                Date date = new Date();
                String dateInput = dateFormat.format(date);
                impExtFilePage.inputFileName(dateInput);
                impExtFilePage.clickSaveButton();
                commMethods.verifyboolean(extFileManPage.isLinkTextPresent(dateInput), true);
                extFileManPage.clickExternalFileLink(dateInput);
                commMethods.verifyString(extFileManPage.getEFMHeader(),"Import External File");
                commMethods.verifyString(impExtFilePage.filePathLoc_Field.getAttribute("value"),fileLoc);
            }else if("EXT_ID_033".equalsIgnoreCase(tc_ID)) 
            {
                Date date = new Date();
                String dateInput = dateFormat.format(date);
                impExtFilePage.inputFileName(dateInput);
                impExtFilePage.clickSaveButton();
                commMethods.verifyboolean(extFileManPage.isLinkTextPresent(dateInput), true);
                extFileManPage.clickRemoveButton(dateInput);
                commMethods.verifyString(extFileManPage.getPopupBtn_1(),"Yes");
                commMethods.verifyString(extFileManPage.getPopupBtn_2(),"No");
                extFileManPage.clickNRemovePopUp();
                commMethods.verifyboolean(extFileManPage.isLinkTextPresent(dateInput),true);
                extFileManPage.clickRemoveButton(dateInput);
                extFileManPage.clickYRemovePopUp();
                commMethods.verifyboolean(extFileManPage.isLinkTextPresent(dateInput),false);
            }
        }
    }

    

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] ExternalFile_Y() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ExternalFile", "Y");
        return testObjArray_DRS;
    }

}

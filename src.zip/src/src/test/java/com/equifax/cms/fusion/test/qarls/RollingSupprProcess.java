package com.equifax.cms.fusion.test.qarls;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DNSPages.DataProcessingTab;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringSummaryPage;
import com.equifax.cms.fusion.test.RLSPages.DataProcessingTabRS;
import com.equifax.cms.fusion.test.RLSPages.RLSSummaryPage;
import com.equifax.cms.fusion.test.RLSPages.RollingSuppSetupPage;
import com.equifax.cms.fusion.test.SHPages.ShippingHomePage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.SHPages.ShippingSummaryPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qadp.FullFileFixedProcess;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.google.common.collect.Ordering;

@Title("Rolling Suppression Process Tests")
public class RollingSupprProcess<rlsSumPage>
{

    boolean flag = false;
    public static WebDriver driver;
    public static String formattedDate1;
    private ProjectDashBoardPage ProjDashBoardPage;
    private CommonMethods commMethods;
    private DataProcessingTabRS dpHomePage;
    DataProcessingTabFIL dataProcessingFilPage;
    private DataProcessingTab dataProcessingTab;
    private RollingSuppSetupPage rollSupPage;
    private RLSSummaryPage rlsSumPage;
    private ShippingPage shPage;
    private Modules module;
    private OracleDBHelper oracleConnect;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    private JobStackingPage jobStackingPage;
    private StackingPage stackingPage;
    private FilteringSummaryPage filSummaryPage;
    private ShippingHomePage shHomePage;
    private ShippingSummaryPage shSumPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(RollingSupprProcess.class);
    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();

        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabRS.class);
        rollSupPage = PageFactory.initElements(driver, RollingSuppSetupPage.class);
        rlsSumPage = PageFactory.initElements(driver, RLSSummaryPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        dataProcessingTab = PageFactory.initElements(driver, DataProcessingTab.class);
        shHomePage = PageFactory.initElements(driver, ShippingHomePage.class);
        shSumPage = PageFactory.initElements(driver, ShippingSummaryPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
        oracleConnect = new OracleDBHelper();
    }

    // @Title("Rolling Suppression Duplicate Edit Submit Test")
    @Test(dataProvider = "rsStats_Y", priority = 1)
    public void rollingSuppressionDuplicate(String tc_Id, String testRun, String testcase, String description, String copyProject,
            String copyProcess, String procName, String suppOption, String suppTable, String projNum, String process, String data, String groups,
            String shFile, String allRecords, String accepts, String rejects, String dateType, String date, ITestContext testContext)
            throws Exception
    {
        System.out.println("data " + tc_Id + testRun + testcase + description + copyProject + copyProcess + procName + suppOption + suppTable
                + projNum + process + data + shFile + allRecords + accepts + rejects + dateType);

        ProjDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickRollingSuppBtn();
        String fProName = commMethods.getFinalProcessName();
        rollSupPage.inputProcessName(procName);
        rollSupPage.selectRLSOptionTable(suppOption, suppTable);
        if ("RLS_ID_468".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString(rollSupPage.getProcessthosehasCIDarelisted_STYLE(), "display: none;");

        } else if ("RLS_ID_353".equalsIgnoreCase(tc_Id))
        {
            rollSupPage.inputPrevProjNumClickSearch(PropertiesUtils.getProperty("project"));
            commMethods.verifyString(driver.switchTo().alert().getText(), "Current project number is not allowed.");
        } else
        {
            rollSupPage.inputPrevProjNumClickSearch(projNum);
            rollSupPage.selectProcess(process);
            rollSupPage.selectData(data);
            commMethods.selectTheGroups(groups);
            if ("RLS_ID_346".equalsIgnoreCase(tc_Id))
            {
                // Validate that groups should be displayed below the data field in case of match join/filtering/random nth process is selected.
                commMethods.verifyboolean(rollSupPage.isGroupsDisplayed(), true);
                // Validate that a line item �Number of suppression days used� should be present under "Apply Date parameters" section
                commMethods.verifyString(rollSupPage.getNoOfSuppDaysDispl(), "Number of Suppression Days Used:");

            } else if ("RLS_ID_347".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(rollSupPage.isCheckBoxDisplayedShipping(), true);

            } else if ("RLS_ID_348".equalsIgnoreCase(tc_Id))
            {
                shPage.selectShippedFiles(shFile);
                rollSupPage.clickOnSave();
                String getDateShipping = rollSupPage.dateSelected.getAttribute("value");
                String jobNoShipping = rollSupPage.getJobNoDisplayed();
                ProjDashBoardPage.clickSearch();
                ProjDashBoardPage.inputProjectNumberClickSearch(projNum);
                String dateCompleted = ProjDashBoardPage.getDateCompletedJobNo(jobNoShipping);
                dateCompleted.trim();
                String month = dateCompleted.substring(0, 3);
                String date1 = dateCompleted.substring(4, 6);
                String year = dateCompleted.substring(8, 12);
                System.out.println(month);
                System.out.println(date1);
                System.out.println(year);
                Date date2 = new SimpleDateFormat("MMM").parse(month);
                Calendar cal = Calendar.getInstance();
                cal.setTime(date2);
                String month1 = String.valueOf(cal.get(Calendar.MONTH) + 1);
                if (getDateShipping.startsWith("0"))
                {
                    getDateShipping = getDateShipping.substring(1);
                }
                commMethods.verifyString(getDateShipping, month1 + "/" + date1 + "/" + year);
            } else
            {
                shPage.selectShippedFiles(shFile);
                commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
                rollSupPage.selectDateToApply(dateType, date);
                if ("RLS_ID_350".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSave();
                    String jobNoShipping = rollSupPage.getJobNoDisplayed();
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.selectSummaryRS();
                    commMethods.verifyString(rlsSumPage.getProcessDisplayed(), process);
                    commMethods.verifyString(rlsSumPage.getJobNoDisplayed(), jobNoShipping);
                    commMethods.verifyString(rlsSumPage.getDataDisplayed(), shFile);
                } else if ("RLS_ID_351".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSave();
                    String tableName = rollSupPage.getTableName();
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.clickRollingSuppBtn();
                    rollSupPage.inputProcessName("TEST");
                    rollSupPage.clickCreateNewtSupTbl();
                    rollSupPage.inputSupTblName1(tableName);
                    rollSupPage.inputPrevProjNumClickSearch(projNum);
                    rollSupPage.selectProcess(process);
                    rollSupPage.selectData(data);
                    commMethods.selectTheGroups(groups);
                    shPage.selectShippedFiles(shFile);
                    commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
                    rollSupPage.selectDateToApply(dateType, date);
                    rollSupPage.clickOnSave();
                    Thread.sleep(10000);
                    commMethods.verifyboolean(
                            rollSupPage.getTextErrorMessage().contains(
                                    "Provide unique name for Suppression Table. Name already in use in the project"), true);
                } else if ("RLS_ID_352".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSave();
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.selectDuplicateRS();
                    commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
                } else if ("RLS_ID_355".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSubmit();
                    DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
                    Date date1 = new Date();
                    System.out.println(dateFormat.format(date1));
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                    String rollSuppTableName = ProjDashBoardPage.getRollingSuppTableName(fProName);
                    System.out.println(rollSuppTableName);
                    String dateinRLSTable = commMethods.getDateinRLSTable(rollSuppTableName);
                    System.out.println(dateinRLSTable);
                    commMethods.verifyString(dateinRLSTable, dateFormat.format(date1));
                } else if ("RLS_ID_356".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSubmit();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                    String rollSuppTableName = ProjDashBoardPage.getRollingSuppTableName(fProName);
                    List<String> columnName = commMethods.getMetaDatainRLSTable(rollSuppTableName);
                    commMethods.verifyString(columnName.get(0), "dp_sequence_num");
                    commMethods.verifyString(columnName.get(1), "cid");
                    commMethods.verifyString(columnName.get(2), "project_number");
                    commMethods.verifyString(columnName.get(3), "rolling_date");
                    commMethods.verifyString(columnName.get(4), "rolling_status");
                } else if ("RLS_ID_360".equalsIgnoreCase(tc_Id))
                {
                    String jobNoShipping = rollSupPage.getJobNoDisplayed();
                    rollSupPage.clickOnSubmit();
                    dpHomePage.selectDuplicateRS();
                    dpHomePage.selectSummaryRS();
                    commMethods.verifyString(rlsSumPage.getProcessDisplayed(), process);
                    commMethods.verifyString(rlsSumPage.getJobNoDisplayed(), jobNoShipping);
                } else if ("RLS_ID_361".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSubmit();
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.selectSummaryRS();
                    commMethods.verifyString(rlsSumPage.getGroupSelected(), groups);
                } else if ("RLS_ID_362".equalsIgnoreCase(tc_Id))
                {
                    rollSupPage.clickOnSubmit();
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.selectSummaryRS();
                    commMethods.verifyString(rlsSumPage.getDataDisplayed(), data);
                    /*
                     * Not Complete
                     */

                }
            }
        }

    }

    // @Title("Rolling Suppression Edit Submit Test")
    @Test(dataProvider = "rsStats_CBA", priority = 1, enabled = false)
    public void rollingSuppression_CBA(String testCase, String testRun, String testId, String description, String procName, String supOpt,
            String suppTableName, String existSupTbl, String projNum, String process, String data, String groups, String shFile, String allRecords,
            String accepts, String rejects, String exclusions, String acceptExclusion, String rejectExclusion, String dateType,
            ITestContext testContext) throws Exception
    {
        String status = null;

        ProjDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickRollingSuppBtn();
        Thread.sleep(3000);
        if ("RLS_ID_460".equalsIgnoreCase(testId) || "RLS_ID_461".equalsIgnoreCase(testId))
        {
            rollSupPage.inputProcessName(procName);

            if ("Existing_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickUpdateExistSupTbl();
                rollSupPage.selectExistSupTbl(existSupTbl);

            } else if ("New_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickCreateNewtSupTbl();
                rollSupPage.inputSupTblName(suppTableName);
                rollSupPage.inputPrevProjNumClickSearch(projNum);
                rollSupPage.clickSearchBtn();

            }
            Thread.sleep(3000);
            rollSupPage.selectProcess(process);
            Thread.sleep(3000);
            if (!"NA".equalsIgnoreCase(data))
            {
                rollSupPage.selectData(data);
            }
            if (!"NA".equalsIgnoreCase(shFile))
            {
                shPage.selectShippedFiles(shFile);
            }
            if (!"NA".equalsIgnoreCase(groups))
            {
                commMethods.checkAllGroups();
            }

            if (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion))

            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
                // HashMap<String, String> map = commMethods.getSelectedExlusion(acceptExclusion, rejectExclusion, rejects);
                // System.out.println("mapp" + map);
            }

            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            rollSupPage.uncheckPSFromRejects();
            rollSupPage.selectDateToApply(dateType, "");
            rollSupPage.clickOnSubmit();
            Thread.sleep(15000);
            status = commMethods.getDPProcessStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(3000);
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName), "PASS");

            if ("RLS_ID_461".equalsIgnoreCase(testId))
            {
                ProjDashBoardPage.viewStats(procName);
                Thread.sleep(2000);
                String statRecCount = rollSupPage.getInputRecordCountFromStats();
                ProjDashBoardPage.clickCloseBtnOnStats();

                Thread.sleep(2000);
                ProjDashBoardPage.clickHomeTab();
                String url = "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/project/dashboardtree?projectNumber=" + projNum;
                driver.navigate().to(url);
                // commMethods.searchSpecificProject(projNum);
                String inputProcessUsed[] = process.split(":");
                commMethods.searchProcessOnDashboardAndViewStats(inputProcessUsed[0]);
                // ProjDashBoardPage.viewStats();
                String recCount = rollSupPage.getInputRecordCountFromUsedProcess();

                commMethods.verifyString(recCount, statRecCount);
            }
        }

        if ("RLS_ID_469".equalsIgnoreCase(testId))
        {
            rollSupPage.inputProcessName(procName);
            rollSupPage.clickCreateNewtSupTbl();

            List<String> getSuppTableList = rollSupPage.getSuppTableList();
            getSuppTableList.remove(0);
            boolean sorted = Ordering.natural().isOrdered(getSuppTableList);
            commMethods.verifyboolean(sorted, true);
        }
        // Validate when the user provides a READY state Shipping for creating a Rolling suppression table all the predicted files of the Shipping
        // Process are displayed
        if ("RLS_ID_470".equalsIgnoreCase(testId) || "RLS_ID_472".equalsIgnoreCase(testId))
        {
            rollSupPage.clickCreateNewtSupTbl();

            String procAssignedId[] = process.split(":");

            rollSupPage.inputPrevProjNumClickSearch(projNum);
            rollSupPage.clickSearchBtn();
            rollSupPage.selectProcess(process);
            Thread.sleep(3000);
            // oracleConnect.getConnection();

            List<String> shippedFiles = oracleConnect.getPredictedShippedFiles(projNum, procAssignedId[0]);
            for (String shp : shippedFiles)
            {
                commMethods.verifyboolean(rollSupPage.isShippedFiledisplayed(shp), true);
            }
        }
        // Validate when the user provides a READY state process except shipping to update Rolling suppression all the predicted table should be
        // available in data dropdown.
        if ("RLS_ID_471".equalsIgnoreCase(testId))
        {
            rollSupPage.clickUpdateExistSupTbl();
            rollSupPage.selectExistSupTbl(existSupTbl);
            rollSupPage.selectProcess(process);
            Thread.sleep(5000);
            List<String> getSuppTableList = rollSupPage.getInputTableList();
            getSuppTableList.remove(0);
            String procAssignedId[] = process.split(":");
            List<String> shippedFiles = oracleConnect.getPredictedShippedFiles(projNum, procAssignedId[0]);

            commMethods.verifyboolean(getSuppTableList.containsAll(shippedFiles), true);

        }
        if ("RLS_ID_473".equalsIgnoreCase(testId) || "RLS_ID_474".equalsIgnoreCase(testId))
        {
            rollSupPage.inputProcessName(procName);
            String assignedId = commMethods.getProcId();
            if ("Existing_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickUpdateExistSupTbl();
                rollSupPage.selectExistSupTbl(existSupTbl);

            } else if ("New_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickCreateNewtSupTbl();
                rollSupPage.inputSupTblName(suppTableName);
                rollSupPage.inputPrevProjNumClickSearch(projNum);
                // rollSupPage.clickSearchBtn();

            }

            // rollSupPage.clickUpdateExistSupTbl();
            // rollSupPage.selectExistSupTbl(existSupTbl);
            Thread.sleep(4000);
            rollSupPage.selectProcess(process);
            if (!"NA".equalsIgnoreCase(data))
            {
                rollSupPage.selectData(data);
            }
            if (!"NA".equalsIgnoreCase(shFile))
            {
                shPage.selectShippedFiles(shFile);
            }
            if (!"NA".equalsIgnoreCase(groups))
            {
                commMethods.checkAllGroups();
            }

            if (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion))

            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
                // HashMap<String, String> map = commMethods.getSelectedExlusion(acceptExclusion, rejectExclusion, rejects);

            }
            if (!rollSupPage.isAllRecordsDisabled())
            {
                commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            }

            rollSupPage.selectDateToApply(dateType, "");
            rollSupPage.clickOnSave();
            Thread.sleep(15000);
            dpHomePage.clickDataProcessingTab();
            commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.READY.name().trim());
            ProjDashBoardPage.clickJobStackingTab();
            Thread.sleep(3000);
            stackingPage.clickJobStackingButton();
            // jobStackingPage.inputStackName(procNameForStack);
            jobStackingPage.inputStackName(procName);

            String new_process_name = assignedId + ":" + "" + procName;
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            Thread.sleep(2000);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(new_process_name);
            jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(5000);
            ProjDashBoardPage.clickHomeTab();
            String Status = ProjDashBoardPage.verifyProcess(procName);
            commMethods.verifyString(Status.trim(), "PASS");
        }
        if ("RLS_ID_475".equalsIgnoreCase(testId))
        {
            rollSupPage.inputProcessName(procName);
            String procId = commMethods.getProcId();
            if ("New_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickCreateNewtSupTbl();
                rollSupPage.inputSupTblName(suppTableName);
                rollSupPage.inputPrevProjNumClickSearch(projNum);
                // rollSupPage.clickSearchBtn();

            }
            Thread.sleep(4000);
            rollSupPage.selectProcess(process);
            if (!"NA".equalsIgnoreCase(data))
            {
                rollSupPage.selectData(data);
            }
            if (!"NA".equalsIgnoreCase(shFile))
            {
                shPage.selectShippedFiles(shFile);
            }
            if (!"NA".equalsIgnoreCase(groups))
            {
                commMethods.checkAllGroups();
            }

            if (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion))

            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
                // HashMap<String, String> map = commMethods.getSelectedExlusion(acceptExclusion, rejectExclusion, rejects);

            }

            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);

            rollSupPage.selectDateToApply(dateType, "");
            rollSupPage.clickOnSave();
            Thread.sleep(15000);
            ProjDashBoardPage.clickDataProcessingTab();
            Thread.sleep(2000);
            module.initializeDriver(driver);
            dataProcessingTab.selectSummaryDNS();
            Thread.sleep(5000);
            commMethods.verifyString(rollSupPage.getJobNumberFromSummary(), "Unavailable");

        }

        if ("RLS_ID_476".equalsIgnoreCase(testId))
        {
            rollSupPage.inputProcessName(procName);
            String procId = commMethods.getProcId();
            if ("New_Sup".equalsIgnoreCase(supOpt))
            {
                rollSupPage.clickCreateNewtSupTbl();
                rollSupPage.inputSupTblName(suppTableName);
                rollSupPage.inputPrevProjNumClickSearch(projNum);
                // rollSupPage.clickSearchBtn();

            }
            Thread.sleep(4000);
            rollSupPage.selectProcess(process);
            Thread.sleep(3000);
            if (!"NA".equalsIgnoreCase(data))
            {
                rollSupPage.selectData(data);
            }
            if (!"NA".equalsIgnoreCase(shFile))
            {
                shPage.selectShippedFiles(shFile);
            }
            if (!"NA".equalsIgnoreCase(groups))
            {
                commMethods.checkAllGroups();
            }

            if (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion))

            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);

            }

            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);

            rollSupPage.selectDateToApply(dateType, "");
            rollSupPage.clickOnSave();
            Thread.sleep(15000);
            driver.navigate().to("http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/project/dashboard?projectNumber=" + projNum);
            String assId[] = process.split(":");
            shHomePage.clickShippingHomeTab();
            Thread.sleep(1500);
            module.initializeDriver(driver);
            module.selectSpecificProcessSummary(assId[0]);
            Thread.sleep(3000);
            shSumPage.clickSubmitButton();
            Thread.sleep(15000);
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(3000);
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(assId[0]), "PASS");
            driver.navigate().to(
                    "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/dataprocessing/home?projectNumber="
                            + PropertiesUtils.getProperty("project"));
            // ProjDashBoardPage.clickDataProcessingTab();
            Thread.sleep(3000);
            module.editSpecificProcess(procId);
            rollSupPage.clickOnSubmit();
            ProjDashBoardPage.clickHomeTab();

            commMethods.verifyString(ProjDashBoardPage.verifyProcess(assId[0]), "PASS");
            ProjDashBoardPage.clickDataProcessingTab();
            long gpCountWithStatusA = rollSupPage.getGpTbleCountForRollingStatus("stattableName");
            commMethods.verifyString(rollSupPage.getRolledRecordCount(), String.valueOf(gpCountWithStatusA));

        }
    }

    @Test(dataProvider = "RollingSupp_Reg_Base", priority = 1, enabled = false)
    public void createBaseProcess(String testCase, String testRun, String testId, String description, String procName, String supOpt,
            String suppTableName, String existSupTbl, String projNum, String process, String data, String groups, String shFile, String allRecords,
            String accepts, String rejects, String exclusions, String acceptExclusion, String rejectExclusion, String dateType,
            ITestContext testContext) throws Exception
    {
    	  String executionStatus = commMethods.getTheExecutionStatus(process);
    	  if (executionStatus.equalsIgnoreCase("COMPLETED"))
          {
         	 LOGGER.info("Dependent Process Is Successfully Completed");
        ProjDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickRollingSuppBtn();
        Thread.sleep(3000);

        rollSupPage.inputProcessName(procName);

        if ("Existing_Sup".equalsIgnoreCase(supOpt))
        {
            rollSupPage.clickUpdateExistSupTbl();
            rollSupPage.selectExistSupTbl(existSupTbl);

        } else if ("New_Sup".equalsIgnoreCase(supOpt))
        {
            rollSupPage.clickCreateNewtSupTbl();
            rollSupPage.inputSupTblName(suppTableName);
            rollSupPage.inputPrevProjNumClickSearch(projNum);
            rollSupPage.clickSearchBtn();

        }
        Thread.sleep(3000);
        rollSupPage.selectProcess(process);
        Thread.sleep(3000);
        if (!"NA".equalsIgnoreCase(data))
        {
            rollSupPage.selectData(data);
        }
        if (!"NA".equalsIgnoreCase(shFile))
        {
            shPage.selectShippedFiles(shFile);
        }
        if (!"NA".equalsIgnoreCase(groups))
        {
            commMethods.checkAllGroups();
        }

        if (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion))

        {
            commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
            // HashMap<String, String> map = commMethods.getSelectedExlusion(acceptExclusion, rejectExclusion, rejects);
            // System.out.println("mapp" + map);
        }

        commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
        rollSupPage.uncheckPSFromRejects();
        rollSupPage.selectDateToApply(dateType, "");
        rollSupPage.clickOnSubmit();
        Thread.sleep(15000);
        String status = commMethods.getDPProcessStatus();
        commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
       // ProjDashBoardPage.clickHomeTab();
       // Thread.sleep(3000);
       // commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName), "PASS");
          }
    	  else
          {
         	 Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
          }

    }

    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] rsStats_CBA() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RLSProcess", "CBA");
        return testObjArray;
    }

    @DataProvider
    public Object[][] rsStats_Y() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RLSProcess", "Y");
        return testObjArray;
    }
    
    
    @DataProvider
    public Object[][] RollingSupp_Reg_Base() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RLSProcess", "BASE");
        return testObjArray;
    }

}
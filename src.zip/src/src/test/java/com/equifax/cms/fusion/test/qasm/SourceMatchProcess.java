package com.equifax.cms.fusion.test.qasm;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.IPPages.IpStatsView;
import com.equifax.cms.fusion.test.SMPages.ConfigSourceMatchParametersPage;
import com.equifax.cms.fusion.test.SMPages.SMSummaryPage;
import com.equifax.cms.fusion.test.SMPages.SmStatsView;
import com.equifax.cms.fusion.test.SMPages.SourceMatchHomePage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Source Match Process")
public class SourceMatchProcess extends AbstractCoreTest {

	boolean flag = false;
	// public WebDriver driver = FusionFirefoxDriver.getDriver();
	public WebDriver driver;
	private ProjectDashBoardPage ProjDashBoardPage;
	private SourceMatchHomePage SMHome;
	private ConfigSourceMatchParametersPage SMPage;
	private SMSummaryPage SMsummaryPage;
	private SmStatsView SMstatsPage;
	private CommonMethods commMethods;
	private IpStatsView ipStatsView;
	private boolean acceptNextAlert = true;
	private static final Logger LOGGER = LoggerFactory.getLogger(SourceMatchProcess.class);

	@Step("User Login")
	@BeforeMethod
	public void LoginandSearchProj() throws InterruptedException {
		// driver = FusionFirefoxDriver.getDriver();
		driver = FusionChromeDriver.getDriver();
		driver.manage().timeouts().implicitlyWait(100, TimeUnit.SECONDS);
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		SMHome = PageFactory.initElements(driver, SourceMatchHomePage.class);
		SMPage = PageFactory.initElements(driver, ConfigSourceMatchParametersPage.class);
		SMstatsPage = PageFactory.initElements(driver, SmStatsView.class);
		SMsummaryPage = PageFactory.initElements(driver, SMSummaryPage.class);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		ipStatsView = PageFactory.initElements(driver, IpStatsView.class);
		commMethods.userLogin();
		commMethods.searchProject();
	}

	@AfterMethod
	public void tearDown() {
		driver.quit();
	}

	@Test(dataProvider = "Reg_QA_Y") // QA
	public void smRegTest(String tc_Id, String testRun, String tc, String desc, String processName, String process,
			String jobNo, String data, String groups, String tblName, String fields, String seqNum,
			ITestContext testContext) throws Exception {
		ProjDashBoardPage.clickHomeTab();
		String status = null;
		Modules module = new Modules();
		testContext.setAttribute("WebDriver", driver);
		if ("SM_ID_080".equalsIgnoreCase(tc_Id)) {
			ProjDashBoardPage.clickSourceMatchTab();
			SMHome.ClickSourceMatchButton();
			SMPage.ClickSubmitButton();
			commMethods.verifyString(SMPage.getErrorMessage(), "Please enter the Process Name.");
			SMPage.processNameField(processName);
			SMPage.ClickSubmitButton();
			SMPage.ClickSubmitButton();
			Thread.sleep(2000);
			commMethods.verifyString(SMPage.getErrorMessage(), "Please add at least one process.");
			// SMPage.SelectProcessField(Process);
			SMPage.selectTokenizeProcessNamefromInput(process, data, groups);
			// commMethods.verifyString(SMPage.getErrorMessage(),"Please select
			// data which have same layout as like existing data in table");
			Thread.sleep(5000);
			SMPage.ClearOutputTableName();
			SMPage.ClickSubmitButton();
			SMPage.ClickSubmitButton();
			commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div[1]")).getText(),
					"Please add at least one process.Please enter Output Table name");
			SMPage.InputOutputTableName("!@#$%^&*()_+-={}[]|:'<>?,./");
			SMPage.ClickSubmitButton();
			SMPage.ClickSubmitButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='errMsgList']")).getText();
			commMethods.verifyString(errMsg,
					"Output Table name: '!@#$%^&*()_+-={}[]|:'<>?,./' can contain only character,number or underscore and should not start with a number.");
			SMPage.ClearOutputTableName();
			SMPage.InputOutputTableName("SOURCE_APPEND");
			SMPage.ClickSaveButton();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
					"Configure Source Match Parameters Enter in the Information below, and then click 'Save' or 'Submit'.");
		} else {
			ProjDashBoardPage.clickSourceMatchTab();
			SMHome.ClickSourceMatchButton();
			String procName1 = SMPage.getSMprocId(processName);
			String processNameColon = SMPage.getSMprocIdColon(processName);
			SMPage.processNameField(processName);
			if ("SM_ID_087".equalsIgnoreCase(tc_Id)) {
				SMPage.SelectProcessField(process);
				SMPage.selJobNo(jobNo);
				SMPage.SelectDataField(data);
				SMPage.ClickAddButton();
				SMPage.ClickSaveButton();
				ProjDashBoardPage.clickSourceMatchTab();
				module.initializeDriver(driver);
				status = SMHome.GetStatusSM(processNameColon);
				commMethods.verifyString(StatusEnum.READY.name(), status.trim());
				module.selectSummary();
				String sumJobNo = driver.findElement(By.xpath("//td[contains(text(),'" + jobNo + "')]")).getText()
						.trim();
				commMethods.verifyString(sumJobNo, jobNo);
				SMHome.ClickSourceMatchButton();
				module.selectDuplicate();
				status = SMHome.GetStatusSM(processNameColon);
				commMethods.verifyString(StatusEnum.READY.name(), status.trim());
				module.selectSummary();
				sumJobNo = driver.findElement(By.xpath("//td[contains(text(),'" + jobNo + "')]")).getText().trim();
				commMethods.verifyString(sumJobNo, jobNo);
				SMsummaryPage.ClickSubmitButton();
				status = SMHome.GetStatusSM(processNameColon);
				commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
				ProjDashBoardPage.clickHomeTab();
				String Status = ProjDashBoardPage.verifyProcess(procName1);
				commMethods.verifyString(Status, "PASS");
			} else if ("SM_ID_089".equalsIgnoreCase(tc_Id)) {
				SMPage.SelectProcessField(process);
				SMPage.SelectDataField(data);
				SMPage.ClickAddButton();
				driver.findElement(By.xpath(".//*[@id='fromProcessId']/option[2]")).click();
				driver.findElement(By.xpath(".//*[@id='itemTableId']/option[2]")).click();
				SMPage.InputOutputTableName(tblName);
				SMPage.ClickAddButton();
				SMPage.ClickSaveButton();
				String actOutputTbleName = SMPage.Ele_OutputTableName.getAttribute("value");
				commMethods.verifyString(actOutputTbleName, tblName);
			} else if ("SM_ID_014".equalsIgnoreCase(tc_Id) || "SM_ID_015".equalsIgnoreCase(tc_Id)
					|| "SM_ID_020".equalsIgnoreCase(tc_Id)) {
				SMPage.selectTokenizeProcessNamefromInput(process, data, groups);
				Thread.sleep(2000);
				String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
				commMethods.verifyString(errMsg,
						"Full Name or First Name and Last Name are mandatory for the input process layout");
			} else {
				SMPage.selectTokenizeProcessNamefromInput(process, data, groups);
				// WebElement inGrid =
				// driver.findElement(By.xpath("//td[contains(text(),'"+SMPage.firstProc(process)+"')]"));
				if (!driver.findElement(By.xpath("//td[contains(text(),'" + SMPage.firstProc(process) + "')]"))
						.isDisplayed()) {
					SMPage.selectTokenizeProcessNamefromInput(process, data, groups);
				}
				if ("SM_ID_090".equalsIgnoreCase(tc_Id)) {
					String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
					commMethods.verifyString(errMsg,
							"Please select data which have same layout as like existing data in table");
				} else if ("SM_ID_048".equalsIgnoreCase(tc_Id)) {
					String defaultTbleName = SMPage.getDefaultTableName();
					commMethods.verifyString(defaultTbleName, "SOURCE_APPEND");
				} else if ("SM_ID_049".equalsIgnoreCase(tc_Id)) {
					SMPage.InputOutputTableName("!@#$%^&*()_+:}|{<>?");
					SMPage.ClickSubmitButton();
					String errMsg = driver.findElement(By.xpath(".//*[@id='errMsgList']")).getText();
					commMethods.verifyString(errMsg,
							"Output Table name: '!@#$%^&*()_+:}|{<>?' can contain only character, number or underscore and should not start with a number.");
				} else if ("SM_ID_046".equalsIgnoreCase(tc_Id)) {
					SMPage.InputOutputTableName(tblName);
					String actTblName = SMPage.Ele_OutputTableName.getAttribute("value");
					commMethods.verifyString(actTblName, tblName);
				} else if ("SM_ID_041".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSaveButton();
					ProjDashBoardPage.clickSourceMatchTab();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.READY.name(), status.trim());
				} else if ("SM_ID_074".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSaveButton();
					ProjDashBoardPage.clickSourceMatchTab();
					System.out.println("Navigated to Source Match Home screen");
					module.initializeDriver(driver);
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.READY.name(), status.trim());
					module.selectDuplicate1();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.READY.name(), status.trim());
					module.clickOnEdit();
					ProjDashBoardPage.clickSourceMatchTab();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.READY.name(), status.trim());
					module.selectSummary1();
					String sumProcName = SMsummaryPage.procNameOnSum(processName);
					commMethods.verifyString(sumProcName, processName);
					String sumProc = driver.findElement(By.xpath("//td[contains(text(),'" + process + "')]")).getText()
							.trim();
					commMethods.verifyString(sumProc, process);
					String sumData = driver.findElement(By.xpath("//td[contains(text(),'" + data + "')]")).getText()
							.trim();
					commMethods.verifyString(sumData, data);
					SMsummaryPage.ClickSubmitButton();
					status = driver.findElement(By.xpath("(//div[@class='queued_bg'])[1]")).getText();
					commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
				} else if ("SM_ID_042".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSubmitButton();
					String msg = driver.findElement(By.xpath(".//*[@id='errMsgList']")).getText();
					commMethods.verifyboolean(msg.endsWith("do not exist."), true);
				} else if ("SM_ID_045".equalsIgnoreCase(tc_Id)) {
					String jobNo1 = SMPage.getJobNo();
					commMethods.verifyString(jobNo1, "");
				} else if ("SM_ID_064".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSaveButton();
					ProjDashBoardPage.clickSourceMatchTab();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.READY.name(), status.trim());
					module.initializeDriver(driver);
					module.clickOnEdit();
					SMPage.ClickSubmitButton();
				} else if ("SM_ID_068".equalsIgnoreCase(tc_Id) || "SM_ID_071".equalsIgnoreCase(tc_Id)) {
					driver.findElement(By.xpath("//img[@alt='Remove']")).click();
					SMPage.ClickSaveButton();
					ProjDashBoardPage.clickSourceMatchTab();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
				} else if ("SM_ID_069".equalsIgnoreCase(tc_Id)) {
					commMethods.verifyString(SMPage.getErrorMessage(),
							"Only Input processes are allowed multiple times.");
				} else if ("SM_ID_070".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSubmitButton();
					commMethods.verifyString(SMPage.getErrorMessage(),
							"Full Name or First Name and Last Name are mandatory for the input process layout");
				} else if ("DB_SM_001".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSubmitButton();
					ProjDashBoardPage.clickHomeTab();
					ProjDashBoardPage.openProcessGearBox(procName1);
					ProjDashBoardPage.clickGearBoxCancel();
					Thread.sleep(5000);
					ProjDashBoardPage.clickConfirmationOK();
					String proName = ProjDashBoardPage.jobName();
					String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
					commMethods.verifyString(finalStat, "CANCELLED");
					ProjDashBoardPage.openProcessGearBox(procName1);
					commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);
					LOGGER.info("Test execution completed successfully");
				} else if ("SM_ID_011".equalsIgnoreCase(tc_Id)) {
					SMPage.ClickSubmitButton();
					Thread.sleep(2000);
					String errMsg = driver.findElement(By.id("errMsgList")).getText().trim();
					commMethods.verifyboolean(errMsg.endsWith("do not exist."), true);
					errMsg = driver.findElement(By.id("errMsgList")).getText().trim();
					commMethods.verifyboolean(errMsg.startsWith("Error : Job run details for Input Process"), true);
				} else {
					boolean a;
					a = isAlertPresent();
					if (a) {
						try {
							Alert alert = driver.switchTo().alert();
							String alertText = alert.getText();
							if (acceptNextAlert) {
								alert.accept();
							} else {
								alert.dismiss();
							}
							System.out.println(alertText);
						} catch (Exception e) {

						} finally {
							acceptNextAlert = true;
						}
					}
					SMPage.ClickSubmitButton();
					status = SMHome.GetStatusSM(processNameColon);
					commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
					ProjDashBoardPage.clickHomeTab();
					if ("SM_ID_001".equalsIgnoreCase(tc_Id) || "SM_ID_013".equalsIgnoreCase(tc_Id)
							|| "SM_ID_019".equalsIgnoreCase(tc_Id) || "SM_ID_002".equalsIgnoreCase(tc_Id)
							|| "SM_ID_010".equalsIgnoreCase(tc_Id) || "SM_ID_066".equalsIgnoreCase(tc_Id)
							|| "SM_ID_072".equalsIgnoreCase(tc_Id) || "SM_ID_073".equalsIgnoreCase(tc_Id)) {
						String Status = ProjDashBoardPage.verifyProcess(procName1);
						commMethods.verifyString(Status, "PASS");
					} else {
						if ("SM_ID_017".equalsIgnoreCase(tc_Id) || "SM_ID_016".equalsIgnoreCase(tc_Id)
								|| "SM_ID_009".equalsIgnoreCase(tc_Id) || "SM_ID_012".equalsIgnoreCase(tc_Id)) {
							String Status = ProjDashBoardPage.verifyProcess(procName1);
							commMethods.verifyString(Status, "PASS");
							ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
							// driver.switchTo().frame("sb-player");
							String OutputTableNameSM = ProjDashBoardPage.getOutputTableNameSM();
							String InputTableNameSM = ProjDashBoardPage.getInputTableNameSM();
							Long InputTableCountSMUI = ProjDashBoardPage.getInputTableCountSM();
							Long InputTableCountSMGP = ProjDashBoardPage.getRecordsFromGP(InputTableNameSM);
							Long OutputTableCountSMUI = ProjDashBoardPage.getTotalRecordSM();
							Long OutputTableCountSMGP = ProjDashBoardPage.getRecordsFromGP(OutputTableNameSM);
							commMethods.verifyLong(InputTableCountSMUI, InputTableCountSMGP);
							commMethods.verifyLong(OutputTableCountSMUI, OutputTableCountSMGP);
						} else {
							String Status = ProjDashBoardPage.verifyProcess(procName1);
							commMethods.verifyString(Status, "PASS");
							// ProjDashBoardPage.clickStatsView(procName1);
							// ProjDashBoardPage.viewStats(procName1);
							ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
							// driver.switchTo().frame("sb-player");
							String OutputTableNameSM = ProjDashBoardPage.getOutputTableNameSM();
							if ("SM_ID_031".equalsIgnoreCase(tc_Id)) {
								Long hitCountSMUI = ProjDashBoardPage.getHITcountSM();
								Long noHitCountSMUI = ProjDashBoardPage.getNHcountSM();
								Long hitCountSMGP = ProjDashBoardPage.getHITrecordsFromGP(OutputTableNameSM, "HT");
								Long noHitCountSMGP = ProjDashBoardPage.getHITrecordsFromGP(OutputTableNameSM, "NH");
								commMethods.verifyLong(hitCountSMUI, hitCountSMGP);
								commMethods.verifyLong(noHitCountSMUI, noHitCountSMGP);
							} else if ("SM_ID_034".equalsIgnoreCase(tc_Id)) {
								Long hitCountwithCID = ProjDashBoardPage.getHITwithCIDFromGP(OutputTableNameSM, "HT");
								commMethods.verifyLong(hitCountwithCID, 0L);
							} else if ("SM_ID_036".equalsIgnoreCase(tc_Id)) {
								Long recAddrDiscrCountOfYui = SMstatsPage.getAddDiscrCountfromSMtableUI("Y");
								Long recAddrDiscrCountOfNui = SMstatsPage.getAddDiscrCountfromSMtableUI("N");
								Long recAddrDiscrCountOfYgp = SMstatsPage.getAddrDiscrCountFromGP(OutputTableNameSM,
										"Y");
								Long recAddrDiscrCountOfNgp = SMstatsPage.getAddrDiscrCountFromGP(OutputTableNameSM,
										"N");
								commMethods.verifyLong(recAddrDiscrCountOfYui, recAddrDiscrCountOfYgp);
								commMethods.verifyLong(recAddrDiscrCountOfNui, recAddrDiscrCountOfNgp);
							} else {
								String InputTableNameSM = ProjDashBoardPage.getInputTableNameSM();
								Long InputTableCountSMUI = ProjDashBoardPage.getInputTableCountSM();
								Long InputTableCountSMGP = ProjDashBoardPage.getRecordsFromGP(InputTableNameSM);
								Long OutputTableCountSMUI = ProjDashBoardPage.getTotalRecordSM();
								Long OutputTableCountSMGP = ProjDashBoardPage.getRecordsFromGP(OutputTableNameSM);
								commMethods.verifyLong(InputTableCountSMUI, InputTableCountSMGP);
								commMethods.verifyLong(OutputTableCountSMUI, OutputTableCountSMGP);
								driver.switchTo().defaultContent();
								ProjDashBoardPage.clickCloseButtonStats();
							}
						}
					}
				}
			}
		}
	}

	// @Title("SM Process Regression Test")
	@Test(dataProvider = "Reg_Dev_CBA", priority = 3, description = "Dev Regression test cases") // DEV
	public void smProcessVerification(String tc_Id, String testRun, String tc, String desc, String processName,
			String process, String jobNo, String data, String groups, String tblName, String fields, String seqNum,
			ITestContext testContext) throws Exception {
		String status = null;
		Modules module = new Modules();
		testContext.setAttribute("WebDriver", driver);
		Thread.sleep(3000);
		ProjDashBoardPage.clickSourceMatchTab();
		SMHome.ClickSourceMatchButton();
		String processNameColon = null;
		String procName1 = SMPage.getSMprocId(processName);
		processNameColon = SMPage.getFinalProcessNameColon_SpaceForSM(processName);

		String processNameForStats = processNameColon.replaceAll(":", "_");
		SMPage.processNameField(processName);
		SMPage.SelectProcessField(process);

		SMPage.SelectDataField(data);
		SMPage.ClickAddButton();
		SMPage.ClickSaveButton();
		if ("SM_ID_029".equalsIgnoreCase(tc_Id) || "SM_ID_028".equalsIgnoreCase(tc_Id)) {
			SMPage.ClickSubmitButton();
			ProjDashBoardPage.clickHomeTab();
			Thread.sleep(4000);
			status = ProjDashBoardPage.verifyProcess(procName1);
			commMethods.verifyString(status, "PASS");
			ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
			// commMethods.searchProcessOnDashboardAndViewStats(procName1);
			// ProjDashBoardPage.viewStats("SM33_RegTC_ChkSSN");
			Thread.sleep(1500);
			String outputFilePath = SMstatsPage.getTheOutputFilePath();
			ProjDashBoardPage.clickCloseButtonStats1();

			// driver.switchTo().defaultContent();
			Thread.sleep(5000);
			ProjDashBoardPage.clickHomeTab();
			Thread.sleep(2000);
			String finalProcessNameForIP = SMPage.getFinalProcessNameForInput(process);
			String ipTableName = SMPage.getOutputTableNameIPForSM(finalProcessNameForIP, process);
			String result = SMstatsPage.readFileAndFetchTheResult(outputFilePath, fields, seqNum, ipTableName, tc_Id);

			if ("SM_ID_029".equalsIgnoreCase(tc_Id)) {
				commMethods.verifyString(result, "Matched");
			} /*
				 * else if ("SM_ID_028".equalsIgnoreCase(tc_Id)) {
				 * commMethods.verifyString(result, "9"); }
				 */

		}

		if ("SM_ID_022".equalsIgnoreCase(tc_Id)) {
			SMPage.ClickSubmitButton();
			ProjDashBoardPage.clickHomeTab();
			Thread.sleep(4000);
			status = ProjDashBoardPage.verifyProcess(procName1);
			commMethods.verifyString(status, "PASS");

			Thread.sleep(2000);
			String[] fileNames = SMstatsPage.getTheWorkItemNumOfSMGPExport(processNameForStats, processNameColon);
			// String[] fileNames = SMstatsPage.getTheWorkItemNumOfSMGPExport(
			// "SM80_RegTC_ChkForFiles", "SM80:RegTC_ChkForFiles");
			LOGGER.info("Following are the files required ----->" + " " + fileNames[0]);
			LOGGER.info("Following are the files required ----->" + " " + fileNames[1]);
			Thread.sleep(1500);
			// ProjDashBoardPage.viewStats(procName1);
			ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
			Thread.sleep(1000);

			String outputFilePath = SMstatsPage.getTheOutputFilePath();
			ProjDashBoardPage.clickCloseButtonStats1();
			// driver.switchTo().defaultContent();
			// boolean result = SMstatsPage.chkFileExist(outputFilePath,
			// fileNames);
			// Assert.assertTrue(result);
			LOGGER.info(
					"Validated that after successful completion of  SM_GPEXPORT work item , the exported fixed file is created in the output directory");
		}
		if ("SM_ID_023".equalsIgnoreCase(tc_Id) || "SM_ID_025".equalsIgnoreCase(tc_Id)
				|| "SM_ID_027".equalsIgnoreCase(tc_Id)) {
			String[] fieldArr = fields.split(",");
			SMPage.ClickSubmitButton();
			ProjDashBoardPage.clickHomeTab();
			Thread.sleep(4000);
			status = ProjDashBoardPage.verifyProcess(procName1);
			commMethods.verifyString(status, "PASS");
			// /commMethods.searchProcessOnDashboardAndViewStats(procName1);
			// ProjDashBoardPage.viewStats(procName1);
			ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
			// ProjDashBoardPage.viewStats("SM33_RegTC_ChkSSN");
			Thread.sleep(1500);
			String outputFilePath = SMstatsPage.getTheOutputFilePath();
			ProjDashBoardPage.clickCloseButtonStats1();
			// driver.switchTo().defaultContent();
			Thread.sleep(5000);
			ProjDashBoardPage.clickHomeTab();
			Thread.sleep(2000);
			String finalProcessNameForIP = SMPage.getFinalProcessNameForInput(process);

			String ipTableName = SMPage.getOutputTableNameIPForSM(finalProcessNameForIP, process);
			String result = SMstatsPage.readFile(outputFilePath, fieldArr, seqNum, ipTableName, tc_Id);
			// commMethods.verifyString(result, "Matched");
		}
	}

	@Test(dataProvider = "sm_Base", priority = 1, description = "Base method for base process execution",enabled=true)
	public void smBaseProcesses(String tc_Id, String testRun, String tc, String desc, String processName,
			String process, String jobNo, String data, String groups, String tblName, String fields, String seqNum,
			ITestContext testContext) throws Exception {
		// String executionStatus = commMethods.getTheExecutionStatus(process);
		// if (executionStatus.equalsIgnoreCase("COMPLETED")) {
		String status = null;
		Modules module = new Modules();
		testContext.setAttribute("WebDriver", driver);
		Thread.sleep(3000);
		ProjDashBoardPage.clickSourceMatchTab();
		// driver.switchTo().alert().accept();
		SMHome.ClickSourceMatchButton();
		String processNameColon = null;
		String procName1 = SMPage.getSMprocId(processName);
		processNameColon = SMPage.getFinalProcessNameColon_SpaceForSM(processName);
		SMPage.processNameField(processName);
		SMPage.selectTokenizeProcessNamefromInput(process, data, groups);
		SMPage.ClickSaveButton();
		SMPage.ClickSubmitButton();
		module.initializeDriver(driver);
		status = module.getSmStatus();
		commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
	}
	// }

	@DataProvider
	public Object[][] Reg_Dev_CBA() throws Exception {
		Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SourceMatch", "CBA");
		return testObjArray_Y;
	}

	@DataProvider
	public Object[][] sm_Base() throws Exception {
		Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SourceMatch", "BAS");
		return testObjArray;
	}

	@DataProvider
	public Object[][] Reg_QA_Y() throws Exception {
		Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SourceMatch", "Y");
		return testObjArray;
	}

	private boolean isAlertPresent() throws InterruptedException {
		try {
			driver.switchTo().alert();
			return true;
		} catch (NoAlertPresentException e) {
			return false;
		}
	}

}

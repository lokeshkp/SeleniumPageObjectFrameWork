package com.equifax.cms.fusion.test.qaaudit;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.INQpage.InqStatsView;
import com.equifax.cms.fusion.test.RFPages.RFCommonMethods;
import com.equifax.cms.fusion.test.SFPages.AuditHomePage;
import com.equifax.cms.fusion.test.SFPages.EditMoveStPage;
import com.equifax.cms.fusion.test.SFPages.MoveStmntExportDataSetupPage;
import com.equifax.cms.fusion.test.SFPages.NewSampleFileSetupPage;
import com.equifax.cms.fusion.test.SFPages.SFLayoutSearchPage;
import com.equifax.cms.fusion.test.SFPages.SFSummaryPage;
import com.equifax.cms.fusion.test.SFPages.SampleSetSetup;
import com.equifax.cms.fusion.test.SFPages.SfStatsView;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Sample File Process Tests")
public class SampleFilesProcess
{

    boolean flag = false;
    public static WebDriver driver;
    public static String formattedDate1;
    private ProjectDashBoardPage ProjDashBoardPage;
    private CommonMethods commMethods;
    private ShippingPage shPage;
    private AuditHomePage auditHPage;
    private NewSampleFileSetupPage sfPage;
    private EditMoveStPage editMovStPage;
    private SFSummaryPage sumPage;
    private SfStatsView statsView;
    private SFLayoutSearchPage sfLayoutSearch;
    public Date date;
    private Modules module;
    private InqStatsView inqStats;
    private MoveStmntExportDataSetupPage movStmntExpDataSetPage;
    private SampleSetSetup sampleSetSetup;
    private RFCommonMethods rfCommonMethods;
    private DmStatsView DmStatView;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final Logger LOGGER = LoggerFactory.getLogger(SampleFilesProcess.class);
    private static final boolean IS_UNIX = "/".equals(File.separator);

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        auditHPage = PageFactory.initElements(driver, AuditHomePage.class);
        sfPage = PageFactory.initElements(driver, NewSampleFileSetupPage.class);
        editMovStPage = PageFactory.initElements(driver, EditMoveStPage.class);
        sumPage = PageFactory.initElements(driver, SFSummaryPage.class);
        statsView = PageFactory.initElements(driver, SfStatsView.class);
        movStmntExpDataSetPage = PageFactory.initElements(driver, MoveStmntExportDataSetupPage.class);
        sfLayoutSearch = PageFactory.initElements(driver, SFLayoutSearchPage.class);
        inqStats = PageFactory.initElements(driver, InqStatsView.class);
        sampleSetSetup = PageFactory.initElements(driver, SampleSetSetup.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        DmStatView = PageFactory.initElements(driver, DmStatsView.class);
        commMethods.userLogin();
        commMethods.searchProject();
        rfCommonMethods = PageFactory.initElements(driver, RFCommonMethods.class);
    }

    // public void sfProcessStats(String tc_Id, String testRun, String TC, String Description, String copyProject, String copyProcess, String
    // procName,
    // String process, String data, String groups, String sampleType, String useDmSamples, String outputLocation, String allRecords,
    // String accepts, String rejects, String selectSampleSet, String recordsPerLevel, String levelsCodes, String perfomMoveSt,
    // String prevProjMovName, String tableNames, String moveLayout, String movStName, String movFields, String colCount, String literalValue,
    // ITestContext testContext) throws Exception

    @Title("Sample Files Regression Test")
    @Test(dataProvider = "sf_Reg")
    public void sfProcessStats(String tc_Id, String testRun, String tc, String description, String copyProject, String copyProcess, String procName,
            String process, String data, String groups, String sampleType, String useDmSamples, String outputLocation, String allRecords,
            String accepts, String rejects, String acceptExclusion, String rejectExclusion, String exclusions, String selectSampleSet,
            String recordsPerLevel, String levelsCodes, String selectAuditCriteria, String tableName, String fieldSelection, String level,
            String operator, String lowValue, String highValue, String columnCount, String perfomMoveSt, String prevProjMovName, String tableNames,
            String moveLayout, String movStName, String movFields, String colCount, String literalValue, ITestContext testContext) throws Exception
    {

        if ("SF_ID_TEST".equalsIgnoreCase(tc_Id))
        {
            testContext.setAttribute("WebDriver", driver);
            auditHPage.clickAuditTab();
            auditHPage.clickSampleFileBtn();
            sfPage.inputProcessName(procName);

            sfPage.selectProcess(process);
            sfPage.selectData(data);
            commMethods.selectTheGroups(groups);
            sfPage.UseSampFilesCreatedinDM(useDmSamples);
            sfPage.selectOutputLocation(outputLocation);
            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            sfPage.selectSampleSet(selectSampleSet);
            driver.findElement(By.xpath("(.//*[contains(text(),'HEADER')])[7]//preceding::div[1]")).click();
            Thread.sleep(5000);
            // driver.findElement(By.xpath("(.//div[contains(text(),'CID')])")).click();
            Thread.sleep(5000);
            WebElement el = driver.findElement(By.xpath("(.//div[contains(text(),'CID')])"));
            Actions builder = new Actions(driver);
            Thread.sleep(5000);
            builder.dragAndDropBy(el, 1000, 100);
            Thread.sleep(5000);
            builder.perform();

        }

        else if ("SF_ID_093".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickAuditTab();
            module.initializeDriver(driver);
            commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            driver.navigate().refresh();
            Thread.sleep(3000);
            auditHPage.selectEdit();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "New Sample File Setup Complete the required information, and Click 'Save' or 'Submit'.");
            // Validate that when Sample file process is copied without dependencies the input process is not selected.
            commMethods.verifyboolean(sfPage.isProcessSelected(), false);

        } else if ("SF_ID_094".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickAuditTab();
            module.initializeDriver(driver);
            commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
            driver.navigate().refresh();
            Thread.sleep(3000);
            auditHPage.selectEdit();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "New Sample File / Data Setup Complete the required information, and Click 'Save' or 'Continue'.");
            commMethods.verifyboolean(sfPage.isProcessSelected(), true);
            // Validate that when Sample file process is copied with dependencies the input data is selected.
            commMethods.verifyboolean(sfPage.isDataSelected(), true);
            // Validate that when Sample file process is copied with dependencies the input job number is not selected.
            commMethods.verifyString(sfPage.getJobNo(), "");
            sfPage.clickContinueBtn();
            // Validate that when Sample file process is copied the move statement applied gets copied.
            // driver.switchTo().alert().accept();
            commMethods.verifyboolean(movStmntExpDataSetPage.isTableSelectedForMove(), true);
        } else if ("SF_ID_164".equalsIgnoreCase(tc_Id))
        {
            testContext.setAttribute("WebDriver", driver);
            auditHPage.clickAuditTab();
            auditHPage.clickSampleFileBtn();
            String fProName = commMethods.getFinalProcessName();
            sfPage.inputProcessName(procName);
            sfPage.selectProcess(process);
            sfPage.selectData(data);
            commMethods.selectTheGroups(groups);
            sfPage.UseSampFilesCreatedinDM(useDmSamples);
            sfPage.selectOutputLocation(outputLocation);
            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            sfPage.clickContinueBtn();
            rfCommonMethods.handleAlert();
            sfPage.selectSampleSet(selectSampleSet);
            sfPage.inputRecsPerAcceptLevelandRejectLevel(recordsPerLevel);
            String[] arrRecordsPerLevel = recordsPerLevel.split(",");
            String[] arrlevelsCodes = levelsCodes.split(";");
            sfPage.inputAcceptLevelsandRejectCodesToCreate(levelsCodes);
            sfPage.clickSave();

            Thread.sleep(3000);
            commMethods.verifyString(sfPage.noOfAccept_Recs.getAttribute("value"), arrRecordsPerLevel[0]);
            commMethods.verifyString(sfPage.noOfReject_Recs.getAttribute("value"), arrRecordsPerLevel[1]);
            commMethods.verifyString(sfPage.acceptLevels_Field.getAttribute("value"), arrlevelsCodes[0]);
            commMethods.verifyString(sfPage.rejectCodes_Field.getAttribute("value"), arrlevelsCodes[1]);
            sfPage.clickContinueBtn();
            movStmntExpDataSetPage.performMoveStatement(perfomMoveSt, tableNames, moveLayout, movStName);
            movStmntExpDataSetPage.clickContinueButton();
            editMovStPage.editMoveStatement(fProName, movFields, colCount, literalValue);
            editMovStPage.clickContinueButton();
            sumPage.clickSubmitBtn();
            Thread.sleep(3000);
            commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            driver.navigate().refresh();
            Thread.sleep(3000);
            auditHPage.selectDuplicate();

            commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
            driver.navigate().refresh();
            Thread.sleep(3000);
            auditHPage.selectEdit();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "New Sample File / Data Setup Complete the required information, and Click 'Save' or 'Continue'.");
            sfPage.clickContinueBtn();
            Thread.sleep(1500);
            commMethods.verifyString(sfPage.noOfAccept_Recs.getAttribute("value"), arrRecordsPerLevel[0]);
            commMethods.verifyString(sfPage.noOfReject_Recs.getAttribute("value"), arrRecordsPerLevel[1]);
            commMethods.verifyString(sfPage.acceptLevels_Field.getAttribute("value"), arrlevelsCodes[0]);
            commMethods.verifyString(sfPage.rejectCodes_Field.getAttribute("value"), arrlevelsCodes[1]);

        } else
        {

            testContext.setAttribute("WebDriver", driver);
            auditHPage.clickAuditTab();
            Thread.sleep(3000);
            auditHPage.clickSampleFileBtn();
            String fProName = commMethods.getFinalProcessName();

            String procId = commMethods.getProcId();
            sfPage.selectProcess(process);
            sfPage.selectData(data);
            Thread.sleep(5000);
            sfPage.inputProcessName(procName);
            //commMethods.selectTheGroups(groups);
            if (!groups.equalsIgnoreCase("NA") && commMethods.isAllGroupsSelected() == false)
            {
                commMethods.clickAllGroups();
            }
            if (sampleType.equalsIgnoreCase("tableDitto"))
            {
                if ("SF_ID_TC04".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                }
                if ("SF_ID_TC05".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    shPage.clickTheCollapseButton(fProName + "_" + procName, fProName + ":" + procName);
                    Thread.sleep(1000);
                    String result = shPage.isOneWorkItemHasFormed();
                    commMethods.verifyString(result, "SAMPLE_GPEXPORT");

                }
                if ("SF_ID_TC10".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    ProjDashBoardPage.clickTreeV2statsView(fProName);
                    Long record = sfPage.getTheCountOfRecordsWrittenToFile();
                    commMethods.verifyboolean(sfPage.isRecordCountWithinLimit(record), true);

                }
                if ("SF_ID_TC13".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    // String itemNo = sfPage.fetchTheItemNoForSampleGPExportWorkItem(fProName, fProName + ":" + procName);

                    ProjDashBoardPage.clickTreeV2statsView(fProName);
                    String filePath = sfPage.fetchTheFilePath();
                    // List<String> dataList=commMethods.fetchColumnData(itemNo);

                    commMethods.verifyboolean(sfPage.isFileContainData(filePath), true);

                }
                if ("SF_ID_TC15".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    // String itemNo = sfPage.fetchTheItemNoForSampleGPExportWorkItem(fProName, fProName + ":" + procName);

                    ProjDashBoardPage.clickTreeV2statsView(fProName);
                    commMethods.verifyboolean(sfPage.isDataDisplayedInStatsOnOpeningTheLink(), true);
                    // List<String> fetchedDataListFromStats=sfPage.fetchTheDataDisplayedOnStatsForSampleGPExportTableDittoSampleType();
                    // List<String> dataList=commMethods.fetchColumnData(itemNo);
                    // for(String fetchedData:fetchedDataListFromStats)
                    // {
                    // Assert.assertTrue(dataList.contains(fetchedData));
                    // }

                }
                if ("SF_ID_TC18".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    String[] procArr = process.split(":");
                    String procNameStats = procArr[0] + "_" + procArr[1];

                    commMethods.searchProcessOnDashboardAndViewStats(procNameStats);
                    String HeaderTableNameDM = DmStatView.getHeaderTableNameDM();
                    Long HeaderTableCountDMUI = DmStatView.getHeaderTableCountDM();
                    commMethods.clickToCloseStats();
                    commMethods.clearFilter();

                    ProjDashBoardPage.clickTreeV2statsView(fProName);

                    commMethods.verifyString(sfPage.fetchTheTableName(), HeaderTableNameDM);

                    commMethods.verifyLong(sfPage.fetchTheInputTableRecordCountFromStats(), HeaderTableCountDMUI);
                    Long record = sfPage.getTheCountOfRecordsWrittenToFile();
                    commMethods.verifyboolean(sfPage.isRecordCountWithinLimit(record), true);
                    commMethods.verifyboolean(sfPage.isRecordsWrittenToPresent(), true);
                }
                if ("SF_ID_TC21".equalsIgnoreCase(tc_Id))
                {
                    sfPage.selectSampleType(sampleType);
                    sfPage.clickContinueBtn();
                    String title = sfPage.getTheTitle();
                    commMethods.verifyString(title, "Summary: Table DittoReview the information below, and then click 'Submit' or 'Back'.");
                    sumPage.clickSubmitBtn();
                    commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                    ProjDashBoardPage.clickHomeTab();
                    String status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(status, "PASS");
                    // String itemNo = sfPage.fetchTheItemNoForSampleGPExportWorkItem(fProName, fProName + ":" + procName);
                    ProjDashBoardPage.clickTreeV2statsView(fProName);
                    String filePath = sfPage.fetchTheFilePath();
                    String inputTableName = sfPage.fetchTheTableName();
                    List<String> droppedRecordList = commMethods.getTheDroppedRecordsDpSequenceNumber(inputTableName);
                    commMethods.verifyboolean(sfPage.isFileContainDroppedRecords(filePath, droppedRecordList), false);

                }
            } else
            {
                if (!"N".equalsIgnoreCase(useDmSamples))
                {
                    sfPage.checkUseDmSamples();
                }

                if ("SF_ID_018".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(sfPage.isAllRecordsDisplayed(), false);
                } else
                {
                    commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
                    sfPage.selectOutputLocation(outputLocation);

                    // sfPage.selectSampleSet(selectSampleSet);
                    // sfPage.inputRecsPerAcceptLevelandRejectLevel(recordsPerLevel);
                    // sfPage.inputAcceptLevelsandRejectCodesToCreate(levelsCodes);
                    if ("SF_ID_138".equalsIgnoreCase(tc_Id) || "SF_ID_143".equalsIgnoreCase(tc_Id) || "SF_ID_144".equalsIgnoreCase(tc_Id))
                    {
                        /*
                         * Getting Unwanted Popup in the Sample File Process Due to that Failing May Fail
                         */
                        sfPage.clickSave();

                        commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                "New Sample File / Data Setup Complete the required information, and Click 'Save' or 'Continue'.");
                        ProjDashBoardPage.clickAuditTab();
                        // driver.switchTo().alert().accept();
                        // driver.switchTo().defaultContent();
                        rfCommonMethods.handleAlert();
                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.ERROR.name().trim());
                        auditHPage.selectDuplicate();
                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.ERROR.name().trim());
                        driver.navigate().refresh();
                        Thread.sleep(3000);
                        auditHPage.selectEdit();
                        commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                "New Sample File / Data Setup Complete the required information, and Click 'Save' or 'Continue'.");
                    } else if ("SF_ID_163".equalsIgnoreCase(tc_Id))
                    {
                        sfPage.clearInputProcessName();
                        sfPage.clickContinueBtn();
                        commMethods.verifyString(sfPage.getErrorMessage(), "Error: Please enter the Process Name.");

                    } else
                    {
                        sfPage.clickContinueBtn();
                        Thread.sleep(5000);
                        if ("SF_ID_089".equalsIgnoreCase(tc_Id))
                        {
                            sfPage.clickByAcceptRejectCode();
                            sampleSetSetup.clearNoOfRejectRecs();
                            sampleSetSetup.clearNoOfAcceptRecs();
                            sampleSetSetup.clickContinueBtn();
                            Thread.sleep(2000);
                            // commMethods.verifyString(sfPage.getAcceptRecsError(), "Please enter valid Accept records");
                            commMethods.verifyboolean(sfPage.getAccRejectRecsError().contains("Please enter valid Accept records"), true);
                            commMethods.verifyboolean(sfPage.getAccRejectRecsError().contains("Please enter valid Reject records"), true);
                        } else if ("SF_ID_090".equalsIgnoreCase(tc_Id))
                        {
                            Thread.sleep(2000);
                            sfPage.clickByAcceptRejectCode();
                            sampleSetSetup.clickContinueBtn();
                            Thread.sleep(2000);
                            commMethods.verifyString(driver.findElement(By.xpath("//form[@id='sfForm']/preceding::h3")).getText(),
                                    "Move Statements Export Data Setup Complete the required information, and Click 'Save' or 'continue'.");

                        } else if ("SF_ID_050".equalsIgnoreCase(tc_Id))
                        {
                            // Validate that Direct Extraction Data Menu process down the hierarchy tables are not populate in the "Available Tables"
                            // grid
                            // Using Standard DE DM
                            sampleSetSetup.clickContinueBtn();
                            movStmntExpDataSetPage.clickPerformMoveStatement();
                            commMethods.verifyInt(movStmntExpDataSetPage.countOfTableAvialofMove(), 5);

                        } else
                        {
                            if (!"Y".equalsIgnoreCase(useDmSamples))
                            {
                                Thread.sleep(15000);
                                sampleSetSetup.clickContinueBtn();
                                Thread.sleep(3000);
                                String str = ProjDashBoardPage.getPageTitle();
                                if (str.contains("Summary: Sample Files\nReview the information below, and then click 'Submit' or 'Back'."))
                                {
                                    movStmntExpDataSetPage.clickContinueButton();
                                }
                                Thread.sleep(5000);
                            }
                            int countMoveTables = movStmntExpDataSetPage.countOfTableAvialofMove();
                            movStmntExpDataSetPage.performMoveStatement(perfomMoveSt, tableNames, moveLayout, movStName);
                            if ("SF_ID_020".equalsIgnoreCase(tc_Id) || "SF_ID_024".equalsIgnoreCase(tc_Id) || "SF_ID_027".equalsIgnoreCase(tc_Id))
                            {
                                Thread.sleep(3000);

                                movStmntExpDataSetPage.clickContinueButton();
                                Thread.sleep(3000);
                                commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                        "Summary: Sample FilesReview the information below, and then click 'Submit' or 'Back'.");
                            } else if ("SF_ID_085".equalsIgnoreCase(tc_Id) || "SF_ID_086".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyInt(countMoveTables, 6);
                            }

                            else if ("SF_ID_087".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyInt(countMoveTables, 7);
                            } else if ("SF_ID_045".equalsIgnoreCase(tc_Id))
                            {

                                movStmntExpDataSetPage.clickContinueButton();
                                // commMethods.verifyString(driver.findElement(By.xpath("//form[@id='sfForm']/preceding::h3")).getText(),
                                // "Move Statements Export Data Setup Complete the required information, and Click 'Save' or 'continue'.");
                                commMethods.verifyString(movStmntExpDataSetPage.getErrorMessage(), "Please select at least one table");

                            } else if ("SF_ID_047".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyboolean(movStmntExpDataSetPage.isCreateNewRBtnPresent(), true);

                            } else if ("SF_ID_092".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                        "Summary: Sample FilesReview the information below, and then click 'Submit' or 'Back'.");

                            } else if ("SF_ID_048".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("INPUT"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("SOURCE_APPEND"), true);
                            } else if ("SF_ID_049".equalsIgnoreCase(tc_Id) || "SF_ID_076".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("AGECRIT_MAP001"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("HEADER"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("INQUIRYPOSTTBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("MODEL_1107"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("STEP_FLAG_TBL"), true);
                            } else if ("SF_ID_054".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                        "Edit Move Statements Edit your selected move statements below.");

                            } else if ("SF_ID_084".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyInt(editMovStPage.getNoOfRowsDisplayed(), 93);

                            } else if ("SF_ID_088".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyInt(editMovStPage.getNoOfRowsDisplayed(), 126);

                            } else if ("SF_ID_129".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickSearchMovStmntButton();
                                commMethods.verifyString(driver.findElement(By.xpath("//form[@id='sfForm']/preceding::h2[1]")).getText(),
                                        "Move Statement Search Search for move statement below. Select a move statement, and click 'Continue'.");

                            } else if ("SF_ID_139".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickSaveButton();
                                commMethods.verifyString(driver.findElement(By.xpath("//form[@id='sfForm']/preceding::h3[1]")).getText(),
                                        "Move Statements Export Data Setup Complete the required information, and Click 'Save' or 'continue'.");
                            } else if ("SF_ID_051".equalsIgnoreCase(tc_Id))
                            {
                                // Validate that series of attributes displayed in the Move Statements screen are depends on the table position are
                                // maintained in the "Selected Tables" grid
                                // May Need to change if Fields in Header or 1107 changed.
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyString(editMovStPage.getFirstLiteralOfMoveStatement(), "DP_SEQUENCE_NUM");
                                commMethods.verifyString(editMovStPage.getLastLiteralofMoveStatement(), "Max_score_1107_1");
                            } else if ("SF_ID_052".equalsIgnoreCase(tc_Id))
                            {
                                // Validate that if user keeps the header table in down position under the "Selected Tables" grid, that particular
                                // attributes are populate in the bottom of the grid
                                // May Need to change if Fields in Header or 1107 changed.
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyString(editMovStPage.getFirstLiteralOfMoveStatement(), "dp_sequence_num");
                                commMethods.verifyString(editMovStPage.getLastLiteralofMoveStatement(), "MLA_STATUS");

                            } else if ("SF_ID_077".equalsIgnoreCase(tc_Id))
                            {
                                // Validate that when List Source Data menu process is taken as input to sample file and move statements is applied,
                                // all
                                // the tables of Data menu are available for move and can be selected for the same.
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("SOURCE_APPEND"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("INPUT"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("INQUIRYPOSTTBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("MODEL_1107"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("STEP_FLAG_TBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("AGECRIT_MAP001"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("HEADER"), true);
                            } else if ("SF_ID_133".equalsIgnoreCase(tc_Id))
                            {
                                // Validate that move statements displayed on move statement search screen is selected and continue is clicked, the
                                // moves
                                // statement gets copied to the current project.
                                // Need to create a Existing Move Statement in Copy Project with a Unique Name
                                String[] arrProjMovName = prevProjMovName.split(",");
                                movStmntExpDataSetPage.clickSearchMovStmntButton();
                                Thread.sleep(3000);
                                commMethods.verifyString(driver.findElement(By.xpath("//form[@id='sfForm']/preceding::h2[1]")).getText(),
                                        "Move Statement Search Search for move statement below. Select a move statement, and click 'Continue'.");
                                sfLayoutSearch.inputProjNum(arrProjMovName[0]);
                                sfLayoutSearch.clickSearchBtn();
                                Thread.sleep(3000);
                                sfLayoutSearch.selectSrchLayout(arrProjMovName[1]);
                                String selectedMoveName = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td/a"))
                                        .getText();
                                sfLayoutSearch.clickContinueBtn();
                                Thread.sleep(3000);
                                int preCount = movStmntExpDataSetPage.getCountOfExistingMoveStatement(selectedMoveName);
                                movStmntExpDataSetPage.clickSearchMovStmntButton();
                                Thread.sleep(3000);
                                sfLayoutSearch.inputProjNum(arrProjMovName[0]);
                                sfLayoutSearch.clickSearchBtn();
                                Thread.sleep(3000);
                                sfLayoutSearch.selectSrchLayout(arrProjMovName[1]);
                                sfLayoutSearch.clickContinueBtn();
                                Thread.sleep(3000);
                                int postCount = movStmntExpDataSetPage.getCountOfExistingMoveStatement(arrProjMovName[1]);
                                commMethods.verifyInt(preCount + 1, postCount);
                                // String appendedDate = movStmntExpDataSetPage.getAppendedDate(arrProjMovName[1]);
                                // Validate that move statements displayed on move statement search screen is selected and a move statemwnt with same
                                // name
                                // already exist in the project, timestamp gets added to the copied move statement.
                                // commMethods.verifyboolean(appendedDate.matches("[0-9]+"), true);
                            } else if ("SF_ID_057".equalsIgnoreCase(tc_Id))
                            {
                                // sampleSetSetup.clickContinueBtn();
                                movStmntExpDataSetPage.clickContinueButton();
                                /*
                                 * Incomplete Add some Validation
                                 */

                            } else if ("SF_ID_078".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("INQUIRYPOSTTBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("STEP_FLAG_TBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("HEADER"), true);
                                // commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("RFNHHDTBL"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("AGECRIT_MAP001"), true);
                                commMethods.verifyboolean(movStmntExpDataSetPage.isTablePresent("MODEL_1107"), true);

                            } else if ("SF_ID_136".equalsIgnoreCase(tc_Id))
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                commMethods.verifyInt(editMovStPage.getNoOfRowsDisplayed(), editMovStPage.countOfSorterIMG());
                            }

                            else
                            {
                                movStmntExpDataSetPage.clickContinueButton();
                                if ("SF_ID_056".equalsIgnoreCase(tc_Id))
                                {
                                    commMethods.verifyboolean(editMovStPage.isApplyChangesBtnEnabled(), false);
                                }
                                editMovStPage.editMoveStatement(fProName, movFields, colCount, literalValue);
                                if ("SF_ID_056".equalsIgnoreCase(tc_Id))
                                {
                                    Thread.sleep(3000);

                                    editMovStPage.editMoveStatement(fProName, movFields, colCount, literalValue);
                                    commMethods.verifyboolean(editMovStPage.isApplyChangesBtnEnabled(), true);

                                } else if ("SF_ID_152_1".equalsIgnoreCase(tc_Id))
                                {
                                    editMovStPage.editMoveStatement(fProName, movFields, colCount, literalValue);
                                } else if ("SF_ID_152_2".equalsIgnoreCase(tc_Id))
                                {
                                    editMovStPage.editMoveStatement(fProName, movFields, colCount, literalValue);
                                } else if ("SF_ID_152_3".equalsIgnoreCase(tc_Id))
                                {
                                    editMovStPage.inputMovStName(fProName);
                                    editMovStPage.selectMoveStFields(movFields);
                                    editMovStPage.clickColumnsBtn();
                                    editMovStPage.selectColumnCount(colCount);
                                    editMovStPage.columnPositions(colCount, literalValue);
                                    String label = driver.findElement(
                                            By.xpath("//div[@id='columnsModal']/div[@class='columnsModalBlock']/table[1]/tbody/tr[1]/td[1]"))
                                            .getText();
                                    String value = driver.findElement(
                                            By.xpath("//div[@id='columnsModal']/div[@class='columnsModalBlock']/table[1]/tbody/tr[1]/td[2]/label"))
                                            .getText();

                                    commMethods.verifyString(label, "Longest Literal Length ");
                                    commMethods.verifyString(value, "23");
                                } else

                                {
                                    if ("SF_ID_055".equalsIgnoreCase(tc_Id))
                                    {
                                        editMovStPage.clickContinueButton();
                                        sumPage.clickSubmitBtn();
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        driver.navigate().refresh();
                                        Thread.sleep(2000);
                                        auditHPage.selectDuplicate();
                                        Thread.sleep(2000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                    } else if ("SF_ID_122".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(2000);
                                        ProjDashBoardPage.clickHomeTab();
                                        Thread.sleep(2000);
                                        ProjDashBoardPage.expandProcess(procId);
                                        ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_GPEXPORT"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_JET"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_GPLOAD"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("SAMPLE_EXTRACT"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_SFLOAD"), true);
                                    } else if ("SF_ID_123".equalsIgnoreCase(tc_Id) || "SF_ID_053".equalsIgnoreCase(tc_Id))
                                    {
                                        editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        ProjDashBoardPage.clickHomeTab();
                                        // ProjDashBoardPage.changeHomeGridViewSelectionToDefault();
                                        // String ProcessName1 = ProjDashBoardPage.getJobName();
                                        // String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                                        // commMethods.verifyString(Status, "PASS");
                                        Thread.sleep(3000);
                                        ProjDashBoardPage.expandProcess(procId);
                                        ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_GPEXPORT"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_JET"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_GPLOAD"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("SAMPLE_EXTRACT"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("SFDE_GPEXPORT"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("SFDE_DATAMERGE"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_GENMOV"), true);
                                        commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_SFLOAD"), true);
                                    } else if ("SF_ID_140".equalsIgnoreCase(tc_Id) || "SF_ID_149".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();

                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(2000);
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "PASS");
                                        ProjDashBoardPage.viewStats(fProName);
                                        Thread.sleep(2000);
                                        // driver.switchTo().frame("sb-player");
                                        String input_Table_Name = statsView.getInputTableNameSF();
                                        String header_Table_Name = statsView.getHeaderTableNameSF();
                                        String sf_Table_Name = statsView.getSampleIndexTableNameSF();
                                        String sf_Table_Count = statsView.getSampleIndexTableCountSF();
                                        String header_Table_Count = statsView.getHeaderTableCountSF();
                                        String input_Table_Count = statsView.getInputTableCountSF();
                                        commMethods.verifyboolean(
                                                sf_Table_Count.contains(String.valueOf(commMethods.getRecordsFromGP(sf_Table_Name))), true);
                                        commMethods.verifyboolean(
                                                header_Table_Count.contains(String.valueOf(commMethods.getRecordsFromGP(sf_Table_Name))), true);
                                        // commMethods.verifyLong(commMethods.getRecordsFromGP(header_Table_Name), header_Table_Count);
                                        // commMethods.verifyLong(commMethods.getRecordsFromGP(input_Table_Name), input_Table_Count);

                                    } else if ("SF_ID_145".equalsIgnoreCase(tc_Id))
                                    {

                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        driver.navigate().refresh();
                                        Thread.sleep(3000);
                                        // auditHPage.selectDuplicate();
                                        Thread.sleep(3000);
                                        // driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
                                        driver.navigate().refresh();
                                        auditHPage.selectDuplicate();
                                        Thread.sleep(3000);
                                        Thread.sleep(2000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                        auditHPage.selectSummary();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());

                                    } else if ("SF_ID_152".equalsIgnoreCase(tc_Id))
                                    {
                                        editMovStPage.clickSaveButton();
                                        Thread.sleep(2000);
                                        ProjDashBoardPage.clickAuditTab();
                                        Thread.sleep(2000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                        // auditHPage.selectDuplicate();
                                        // commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                        // driver.navigate().refresh();
                                        // Thread.sleep(3000);
                                        // auditHPage.selectSummary();
                                        // Thread.sleep(2000);
                                        // sumPage.clickSubmitBtn();
                                        // commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        // driver.navigate().refresh();
                                        // Thread.sleep(3000);
                                        // auditHPage.selectDuplicate();
                                        // Thread.sleep(2000);
                                        // commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                        // driver.navigate().refresh();
                                        // Thread.sleep(3000);
                                        // auditHPage.selectEdit();
                                        // Thread.sleep(2000);
                                        // commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                        // "New Sample File / Data Setup Complete the required information, and Click 'Save' or 'Continue'.");
                                    } else if ("SF_ID_046".equalsIgnoreCase(tc_Id))
                                    {
                                        editMovStPage.clickContinueButton();
                                        sumPage.clickSubmitBtn();
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        auditHPage.selectDuplicate();
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.READY.name().trim());
                                        driver.navigate().refresh();
                                        Thread.sleep(3000);
                                        auditHPage.selectEdit();
                                        sfPage.clickContinueBtn();
                                        commMethods.verifyboolean(movStmntExpDataSetPage.isExistingMoveStatementPresent(), true);
                                    } else if ("SF_ID_061".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "PASS");
                                        ProjDashBoardPage.viewStats(fProName);

                                        String audit_GPLOAD_Tab_Name = statsView.getSampleIndexTableNameSF();
                                        commMethods.verifyLong(commMethods.gRFAUDIT_SAMPLE_ACC_CODE_NOTNULL(audit_GPLOAD_Tab_Name),
                                                commMethods.getRecordsFromGP(audit_GPLOAD_Tab_Name));
                                    } else if ("SF_ID_062".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "PASS");
                                        ProjDashBoardPage.viewStats(fProName);
                                        String audit_GPLOAD_Tab_Name = statsView.getSampleIndexTableNameSF();
                                        commMethods.verifyLong(commMethods.gRFAUDIT_SAMPLE_FAIL_CODE_NOTNULL(audit_GPLOAD_Tab_Name),
                                                commMethods.getRecordsFromGP(audit_GPLOAD_Tab_Name));

                                    } else if ("SF_ID_063".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "PASS");
                                        ProjDashBoardPage.viewStats(fProName);

                                        String audit_GPLOAD_Tab_Name = statsView.getSampleIndexTableNameSF();

                                        commMethods.verifyLong(commMethods.gRFAUDIT_SAMPLE_RJ_NOTNULL(audit_GPLOAD_Tab_Name),
                                                commMethods.getRecordsFromGP(audit_GPLOAD_Tab_Name));
                                    } else if ("SF_ID_001".equalsIgnoreCase(tc_Id) || "SF_ID_004".equalsIgnoreCase(tc_Id)
                                            || "SF_ID_007".equalsIgnoreCase(tc_Id) || "SF_ID_060".equalsIgnoreCase(tc_Id)
                                            || "SF_ID_158".equalsIgnoreCase(tc_Id) || "SF_ID_162".equalsIgnoreCase(tc_Id))
                                    {
                                        editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "PASS");

                                    } else if ("SF_ID_160".equalsIgnoreCase(tc_Id) || "SF_ID_161".equalsIgnoreCase(tc_Id))
                                    {
                                        // editMovStPage.clickContinueButton();
                                        Thread.sleep(3000);
                                        sumPage.clickSubmitBtn();
                                        Thread.sleep(3000);
                                        commMethods.verifyString(auditHPage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                        ProjDashBoardPage.clickHomeTab();
                                        String status = ProjDashBoardPage.verifyProcess(fProName);
                                        commMethods.verifyString(status, "FAIL");
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // @Test(dataProvider = "sf_CBA", enabled = false)
    // public void validateSampleCBA(String testCase, String testRun, String tc, String description, String procName, String process, String data,
    // String useDmSamples, String groups, String allRecords, String accepts, String rejects, String acceptExclusion, String rejectExclusion,
    // String exclusions, String records, String levelsCodes, String selectAuditCriteria, String tableName, String fieldSelection, String level,
    // String operator, String lowValue, String highValue, String columnCount, String perfomMoveSt, String tableNames, String moveLayout,
    // String movStName, String movFields, String colCount, String literalValue) throws Exception

    @Title("Sample Files Test")
    @Test(dataProvider = "sf_CBA")
    public void validateSampleCBA(String testCase, String testRun, String tc, String description, String copyProject, String copyProcess,
            String procName, String process, String data, String groups, String sampleType, String useDmSamples, String outputLocation,
            String allRecords, String accepts, String rejects, String acceptExclusion, String rejectExclusion, String exclusions,
            String selectSampleSet, String records, String levelsCodes, String selectAuditCriteria, String tableName, String fieldSelection,
            String level, String operator, String lowValue, String highValue, String columnCount, String perfomMoveSt, String prevProjMovName,
            String tableNames, String moveLayout, String movStName, String movFields, String colCount, String literalValue) throws Exception

    {
        String status = null;
        auditHPage.clickAuditTab();

        Thread.sleep(5000);
        auditHPage.clickSampleFileBtn();
        Thread.sleep(3000);

        sfPage.selectProcess(process);
        sfPage.selectData(data);
        sfPage.inputProcessName(procName);
        commMethods.selectTheGroups(groups);
        if (!groups.equalsIgnoreCase("NA") && commMethods.isAllGroupsSelected() == false)
        {
            commMethods.clickAllGroups();
        }
        String procId = commMethods.getProcId();
        Thread.sleep(5000);
        String accRejCode[] = records.split(",");
        String selectedlevelsCodes[] = levelsCodes.split(";");

        if ("SF_ID_013".equalsIgnoreCase(tc))
        {
            String testDisplay = sfPage.validateDivStyleOfUseSamplefromDM();
            commMethods.verifyString(testDisplay, "");
            // sfPage.clickContinueBtn();

        }

        else if ("SF_ID_014".equalsIgnoreCase(tc))
        {
            String test = sfPage.validateDivStyleOfUseSamplefromDM();
            commMethods.verifyString(test, "display: none;");

        }

        else if ("SF_ID_017".equalsIgnoreCase(tc))
        {

            boolean chkBoxStatus = sfPage.checkBoxStatus();
            commMethods.verifyboolean(false, chkBoxStatus);

        }

        if ("CHECK".equalsIgnoreCase(useDmSamples))
        {
            sfPage.checkUseDmSamples();

        } else
        {
            Thread.sleep(5000);
            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            Thread.sleep(2000);
            if (!process.startsWith("IP") && (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion)))
            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
            }
            Thread.sleep(2000);
        }

        if ("SF_ID_018".equalsIgnoreCase(tc))
        {

            commMethods.verifyboolean(sfPage.isAllRecordsDisplayed(), false);

        }

        if ("SF_ID_174".equalsIgnoreCase(tc))
        {
            sfPage.clickContinueBtn();
            String result = sampleSetSetup.getPageTitle();

            commMethods.verifyboolean(result.contains("Sample Set Setup"), false);

            commMethods.verifyboolean(result.contains("Move Statements Export Data Setup"), true);

        }
        if ("SF_ID_023".equalsIgnoreCase(tc) || "SF_ID_021".equalsIgnoreCase(tc) || "SF_ID_025".equalsIgnoreCase(tc)
                || "SF_ID_026".equalsIgnoreCase(tc) || "SF_ID_028".equalsIgnoreCase(tc) || "SF_ID_032".equalsIgnoreCase(tc)
                || "SF_ID_038".equalsIgnoreCase(tc) || "SF_ID_040".equalsIgnoreCase(tc) || "SF_ID_033".equalsIgnoreCase(tc)
                || "SF_ID_034".equalsIgnoreCase(tc) || "SF_ID_037".equalsIgnoreCase(tc) || "SF_ID_029".equalsIgnoreCase(tc)
                || "SF_ID_029".equalsIgnoreCase(tc) || "SF_ID_016".equalsIgnoreCase(tc) || "SF_ID_064".equalsIgnoreCase(tc)
                || "SF_ID_065".equalsIgnoreCase(tc) || "SF_ID_166".equalsIgnoreCase(tc) || "SF_ID_167".equalsIgnoreCase(tc)
                || "SF_ID_171".equalsIgnoreCase(tc) || "SF_ID_172".equalsIgnoreCase(tc) || "SF_ID_173".equalsIgnoreCase(tc)
                || "SF_ID_175".equalsIgnoreCase(tc) || "SF_ID_177".equalsIgnoreCase(tc) || "SF_ID_179".equalsIgnoreCase(tc)
                || "SF_ID_180".equalsIgnoreCase(tc) || "SF_ID_181".equalsIgnoreCase(tc) || tc.equalsIgnoreCase("SF_ID_066")
                || tc.equalsIgnoreCase("SF_ID_071") || tc.equalsIgnoreCase("SF_ID_072") || tc.equalsIgnoreCase("SF_ID_073")
                || tc.equalsIgnoreCase("SF_ID_074") || tc.equalsIgnoreCase("SF_ID_075"))
        {

            Thread.sleep(2000);
            sfPage.clickContinueBtn();
            rfCommonMethods.handleAlert();
            if ("SF_ID_166".equalsIgnoreCase(tc))
            {
                // By by = sampleSetSetup.auditCriteriaRadio();
                commMethods.verifyboolean(sampleSetSetup.isElementPresent(), true);
            }

            if ("SF_ID_167".equalsIgnoreCase(tc))
            {
                // sfPage.clickContinueBtn();
                Thread.sleep(4000);
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                sampleSetSetup.clickContinueBtn();
                String result = sampleSetSetup.getOptionsErrorMsg();
                commMethods.verifyboolean(result.contains("Only the values between 1 to 99999 are valid for count field."), true);
            }
            if ("SF_ID_171".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                sampleSetSetup.clickContinueBtn();
                String result = sampleSetSetup.getOptionsErrorMsg();
                commMethods.verifyboolean(result.contains("Enter Count value."), true);
            }

            if ("SF_ID_172".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                Thread.sleep(2000);
                commMethods.verifyboolean(sampleSetSetup.getTagNumber().contains(sampleSetSetup.getRowNumber()), true);

            }

            if ("SF_ID_175".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                Thread.sleep(2000);
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                Thread.sleep(2000);
                // sampleSetSetup.clickSaveBtn();
                sampleSetSetup.clickContinueBtn();
                Thread.sleep(2000);
                String result = sampleSetSetup.getOptionsErrorMsg();
                // commMethods.verifyboolean(result.contains("Select valid Operator value."), true);
                commMethods.verifyboolean(result.contains("Enter Low value."), true);
                commMethods.verifyboolean(result.contains("Enter High value."), true);
            }

            if ("SF_ID_177".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                sampleSetSetup.clickContinueBtn();
                String result = sampleSetSetup.getOptionsErrorMsg();
                commMethods.verifyboolean(result.contains("Enter valid Low value."), true);
                commMethods.verifyboolean(result.contains("Enter valid High value."), true);
            }

            if ("SF_ID_181".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                Thread.sleep(2000);
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                sampleSetSetup.clickContinueBtn();
                String result = sampleSetSetup.getOptionsErrorMsg();
                commMethods.verifyboolean(result.contains("Select valid Count Level value."), true);

            }

            if ("SF_ID_173".equalsIgnoreCase(tc))
            {
                String levelArray[] = { "criteriaLevel.A", "criteriaLevel.B", "criteriaLevel.C", "criteriaLevel.D", "criteriaLevel.E",
                        "criteriaLevel.F", "criteriaLevel.G", "criteriaLevel.H", "criteriaLevel.I", "criteriaLevel.J", "criteriaLevel.K",
                        "criteriaLevel.L", "criteriaLevel.M", "criteriaLevel.N", "criteriaLevel.O", "criteriaLevel.P", "criteriaLevel.Q",
                        "criteriaLevel.R", "criteriaLevel.S", "criteriaLevel.T", "criteriaLevel.U", "criteriaLevel.V", "criteriaLevel.W",
                        "criteriaLevel.X", "criteriaLevel.Y", "criteriaLevel.Z" };
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                System.out.println("first----->>" + processId[1]);
                System.out.println("first----->>" + processId[0]);
                Thread.sleep(2000);
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                for (String levelVal : levelArray)
                {
                    Thread.sleep(2000);
                    sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, levelVal, operator, lowValue, highValue,
                            columnCount);
                    Thread.sleep(2000);
                    // sampleSetSetup.selectAddedField(processId[0], tableName, fieldSelection);
                    // sampleSetSetup.clickDeleteRow();
                    // sampleSetSetup.clickConfirmDelete();

                }
                // commMethods.verifyboolean(sampleSetSetup.getTagNumber().contains(sampleSetSetup.getRowNumber()), true);

            }

            // if ("SF_ID_172".equalsIgnoreCase(tc))
            // {
            // String processId[] = process.split(":");
            // sampleSetSetup.clickAuditCriteria();
            // sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
            // Thread.sleep(2000);
            // sampleSetSetup.addCellValuesForAuditCriteria(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
            // columnCount);
            // Thread.sleep(2000);
            // sampleSetSetup.clickContinueBtn();
            // String result = sampleSetSetup.getOptionsErrorMsg();
            // }

            if ("SF_ID_179".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                sampleSetSetup.clickAuditCriteria();
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                sampleSetSetup.addCellValuesForAuditCriteria1(processId[0], tableName, fieldSelection, level, operator, lowValue, highValue,
                        columnCount);
                // sampleSetSetup.clickContinueBtn();
            }

            if ("SF_ID_180".equalsIgnoreCase(tc))
            {
                String processId[] = process.split(":");
                Thread.sleep(2000);
                sampleSetSetup.clickAuditCriteria();
                Thread.sleep(2000);
                sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                Thread.sleep(2000);
                boolean isOperatorDisplayed = sampleSetSetup.getAvailableOpertors();
                Thread.sleep(2000);
                commMethods.verifyboolean(isOperatorDisplayed, true);

                // incomplete
            }

            // if ("SF_ID_034".equalsIgnoreCase(tc) /* || "SF_ID_040".equalsIgnoreCase(tc) */)
            // {
            //
            // sfPage.clickContinueBtn();
            // rfCommonMethods.handleAlert();
            // }
            Thread.sleep(5000);
            if ("SF_ID_023".equalsIgnoreCase(tc) || "SF_ID_021".equalsIgnoreCase(tc) || "SF_ID_025".equalsIgnoreCase(tc)
                    || "SF_ID_026".equalsIgnoreCase(tc) || "SF_ID_028".equalsIgnoreCase(tc))
            {
                if ("SF_ID_023".equalsIgnoreCase(tc))
                {
                    Thread.sleep(3000);
                    rfCommonMethods.handleAlert();
                    auditHPage.clickAuditTab();
                    rfCommonMethods.handleAlert();
                    Thread.sleep(3000);
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(status.trim(), StatusEnum.ERROR.name());

                }

                else if ("SF_ID_021".equalsIgnoreCase(tc))
                {
                    Thread.sleep(2000);
                    rfCommonMethods.handleAlert();
                    auditHPage.clickAuditTab();
                    rfCommonMethods.handleAlert();
                    Thread.sleep(2000);

                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(status.trim(), StatusEnum.ERROR.name());

                }

                else

                // driver.navigate().to("http://afnt1lc9a001.app.c9.equifax.com:9190/cms-fusion-web/audit/editsfp?projectNumber=6000000&&sfId=3069471");
                // sfPage.clickContinueBtn();
                if ("SF_ID_025".equalsIgnoreCase(tc))
                {
                    // if ("Y".equalsIgnoreCase(selectAuditCriteria))
                    // {
                    // sampleSetSetup.saveAuditCriteriaSelections(tableName, fieldSelection);
                    // rfCommonMethods.handleAlert();
                    // sampleSetSetup.addCellValuesForAuditCriteria("DM193", tableName, fieldSelection, level, operator, lowValue, highValue,
                    // columnCount);
                    // }

                    sampleSetSetup.clickSaveBtn();
                    rfCommonMethods.handleAlert();
                    auditHPage.clickAuditTab();
                    rfCommonMethods.handleAlert();
                    Thread.sleep(2000);

                    status = commMethods.getProcessStatus();
                    commMethods.verifyStringEB(status.trim(), StatusEnum.READY.name());

                }

                else if ("SF_ID_026".equalsIgnoreCase(tc) || "SF_ID_028".equalsIgnoreCase(tc))
                {
                    // sfPage.clickContinueBtn();
                    rfCommonMethods.handleAlert();
                    auditHPage.clickAuditTab();
                    rfCommonMethods.handleAlert();
                    Thread.sleep(3000);
                    status = commMethods.getProcessStatus();

                    commMethods.verifyStringEB(status.trim(), StatusEnum.ERROR.name());

                }
            } else
            {
                if (!"NA".equalsIgnoreCase(records) && !"NA".equalsIgnoreCase(levelsCodes))
                {
                    // sfPage.clickContinueBtn();
                    sfPage.inputAccRegRecsnew(records);
                    Thread.sleep(2000);
                    sfPage.clickByAcceptRejectCode();
                    Thread.sleep(2000);
                    String levelsCodesSplit[] = levelsCodes.split(";");
                    Thread.sleep(2000);
                    sfPage.inputAccRegRecs(levelsCodesSplit[0]);
                    sfPage.inputAccRejCreate(levelsCodesSplit[1]);
                }
                if (!"CHECK".equalsIgnoreCase(useDmSamples))
                {
                    sampleSetSetup.clickContinueBtn();
                    rfCommonMethods.handleAlert();
                }
                // if (/* "SF_ID_038".equalsIgnoreCase(tc) || */"SF_ID_040".equalsIgnoreCase(tc))
                // {
                // sampleSetSetup.clickContinueBtn();
                // rfCommonMethods.handleAlert();
                // }
                if ("Y".equalsIgnoreCase(perfomMoveSt))
                {
                    Thread.sleep(5000);
                    movStmntExpDataSetPage.performMoveStatement(perfomMoveSt, tableNames, moveLayout, movStName);
                    movStmntExpDataSetPage.clickContinueButton();
                    if (moveLayout.equalsIgnoreCase("Create New"))
                    {
                        date = new Date();
                        editMovStPage.inputMovStName(dateFormat.format(date));
                        editMovStPage.selectMoveStFields(movFields);
                        editMovStPage.clickColumnsBtn();
                        editMovStPage.selectColumnCount(colCount);
                        editMovStPage.columnPositions(colCount, literalValue);
                        editMovStPage.clickSaveEditCol();
                    }

                }
            }
            if ("SF_ID_179".equalsIgnoreCase(tc))
            {
                Thread.sleep(2000);
                editMovStPage.clickContinueButton();
                Thread.sleep(5000);
                sumPage.clickAuditCriteriaLink();
                driver.switchTo().frame(0);

                List<String> result = sumPage.getContentFromSummary();
                commMethods.verifyboolean(result.get(0).contains(tableName), true);
                commMethods.verifyboolean(result.get(1).contains(tableName + "." + fieldSelection), true);
                commMethods.verifyboolean(result.get(2).contains(level), true);
                commMethods.verifyboolean(result.get(4).contains(lowValue + " - " + highValue), true);
                commMethods.verifyboolean(result.get(6).contains("14"), true);
            }
            if ("SF_ID_031".equalsIgnoreCase(tc) || "SF_ID_032".equalsIgnoreCase(tc) || "SF_ID_038".equalsIgnoreCase(tc)
                    || "SF_ID_040".equalsIgnoreCase(tc) || "SF_ID_033".equalsIgnoreCase(tc) || "SF_ID_034".equalsIgnoreCase(tc)
                    || "SF_ID_037".equalsIgnoreCase(tc) || "SF_ID_029".equalsIgnoreCase(tc) || "SF_ID_029".equalsIgnoreCase(tc)
                    || "SF_ID_016".equalsIgnoreCase(tc) || "SF_ID_064".equalsIgnoreCase(tc) || "SF_ID_065".equalsIgnoreCase(tc)
                    || tc.equalsIgnoreCase("SF_ID_066") || tc.equalsIgnoreCase("SF_ID_071") || tc.equalsIgnoreCase("SF_ID_072")
                    || tc.equalsIgnoreCase("SF_ID_073") || tc.equalsIgnoreCase("SF_ID_074") || tc.equalsIgnoreCase("SF_ID_075"))
            {
                editMovStPage.clickContinueButton();
                Thread.sleep(3000);
                if ("SF_ID_032".equalsIgnoreCase(tc) || "SF_ID_038".equalsIgnoreCase(tc) || "SF_ID_031".equalsIgnoreCase(tc))
                {
                    if ("SF_ID_032".equalsIgnoreCase(tc) || "SF_ID_038".equalsIgnoreCase(tc))
                    {

                        if ("SF_ID_038".equalsIgnoreCase(tc))
                        {
                            sumPage.clickMoveStatementLink();
                            // sumPage.openJqxWindow();
                            Thread.sleep(2000);
                            driver.switchTo().frame(0);
                            String colsCount = sumPage.numberOfColumnsSumm();
                            if (org.apache.commons.lang3.StringUtils.isNoneEmpty(colsCount))
                            {
                                String[] column = colsCount.split(":");
                                commMethods.verifyString(colCount, column[1].replaceAll("^\\s+", ""));

                                // sumPage.closeMoveStatementLink();
                                // div[@id=]
                                // $('#jqxWindow').jqxWindow('close');
                                driver.switchTo().defaultContent();
                                sumPage.closeJqxWindow();
                                // sumPage.closeMoveStatementLink();
                            }
                        }

                        if ("SF_ID_032".equalsIgnoreCase(tc))
                        {
                            commMethods.verifyString("Create Sample Files for following records: All", sumPage.verifySampleSet());
                            sumPage.clickMoveStatementLink();
                            Thread.sleep(2000);
                            driver.switchTo().frame(0);
                            String movFieldCount[] = movFields.split(",");
                            commMethods.verifyboolean(sumPage.getNumberOfMovedColumns().contains(String.valueOf(movFieldCount.length)), true);
                            sumPage.closeMoveStatementLink();
                            driver.switchTo().defaultContent();

                        }

                    }
                    if ("SF_ID_031".equalsIgnoreCase(tc))
                    {
                        commMethods.verifyString("Unavailable", sumPage.getJobNumberFromSummaryGrid());
                    }

                }

                else if ("SF_ID_040".equalsIgnoreCase(tc))
                {
                    sumPage.clickMoveStatementLink();
                    Thread.sleep(2000); // movStPage.continueClick();
                    driver.switchTo().frame(0);
                    String literalStartPos = sumPage.literalStartPos();
                    String valueStartPos = sumPage.valueStartPos();
                    String fieldName = sumPage.fieldName();
                    String[] tablesSelected = tableNames.split(",");
                    String[] moveSplit = movFields.split(",");
                    String[] literalVal = literalValue.split(";");
                    String[] start = literalVal[0].split("-");
                    commMethods.verifyString(start[0], literalStartPos);
                    commMethods.verifyString(moveSplit[0], valueStartPos);
                    commMethods.verifyString(tablesSelected[0] + "." + moveSplit[0], fieldName);
                    // sumPage.closeMoveStatementLink();
                    driver.switchTo().defaultContent();

                }

                else if ("SF_ID_033".equalsIgnoreCase(tc) || "SF_ID_034".equalsIgnoreCase(tc))
                {
                    if ("SF_ID_034".equalsIgnoreCase(tc))
                    {
                        String recPerRejCode = sumPage.getRecordPerReject();
                        commMethods.verifyInt(Integer.valueOf(accRejCode[1]), Integer.valueOf(recPerRejCode));
                    }

                    else
                    {
                        List<String> processname = sumPage.verifySampleSetInSummary();

                        if (CollectionUtils.isNotEmpty(processname))
                        {
                            commMethods.verifyInt(10, Integer.valueOf(processname.get(0)));
                            commMethods.verifyInt(15, Integer.valueOf(processname.get(1)));

                            commMethods.verifyboolean(selectedlevelsCodes[0].contains(processname.get(2)), true);
                            commMethods.verifyboolean(selectedlevelsCodes[1].contains(processname.get(3)), true);
                            // commMethods.verifyString(processname.get(3), selectedlevelsCodes[1]);
                            LOGGER.info("Test successful");
                        }
                    }

                }

                String[] tables = tableNames.split(",");
                if ("SF_ID_037".equalsIgnoreCase(tc))
                {
                    for (String s : tables)
                    {
                        boolean test = sfPage.validateMoveStmntTables(s);
                        commMethods.verifyboolean(true, test);
                    }

                }

                else if ("SF_ID_029".equalsIgnoreCase(tc))
                {
                    String processname = sumPage.getSummaryProcessName();
                    if (processname.contains(procName))
                    {
                        LOGGER.info("Test successful");
                    }
                }

                if (tc.equalsIgnoreCase("SF_ID_016"))
                {
                    sumPage.clickSubmitBtn();
                    Thread.sleep(10000);
                    ProjDashBoardPage.clickHomeTab();
                    String proName = ProjDashBoardPage.jobName();
                    ProjDashBoardPage.expandProcess(procId);
                    ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
                    Thread.sleep(3000);
                    List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(proName);

                    for (String artifact : artifactList)
                    {
                        commMethods.verifyboolean(artifact.equalsIgnoreCase("AUDIT_JET"), false);
                    }
                } else if (tc.equalsIgnoreCase("SF_ID_066") || tc.equalsIgnoreCase("SF_ID_071") || tc.equalsIgnoreCase("SF_ID_072")
                        || tc.equalsIgnoreCase("SF_ID_073") || tc.equalsIgnoreCase("SF_ID_074") || tc.equalsIgnoreCase("SF_ID_075"))
                {
                    sumPage.clickSubmitBtn();
                    Thread.sleep(10000);
                    ProjDashBoardPage.clickHomeTab();
                    String finalStat = ProjDashBoardPage.verifyProcess(procName);
                    commMethods.verifyString(finalStat, "PASS");
                }

                else if (tc.equalsIgnoreCase("SF_ID_064"))
                {
                    sumPage.clickSubmitBtn();
                    Thread.sleep(10000);
                    ProjDashBoardPage.clickHomeTab();
                    String finalStat = ProjDashBoardPage.verifyProcess(procName);
                    commMethods.verifyString(finalStat, "PASS");
                    ProjDashBoardPage.viewStats(procName);
                    // driver.switchTo().frame("sb-player");
                    String auditLocation = statsView.getAuditExtractLocation();
                    int len = 0;
                    if (IS_UNIX)
                    {
                        System.out.println("goes to --->>" + auditLocation);
                        len = new File(auditLocation).listFiles().length;
                    } else
                    {
                        System.out.println("goes to --->>" + "C:" + auditLocation.replace("/", "\\"));
                        String newPath = "C:" + auditLocation.replace("/", "\\");
                        len = new File(newPath).listFiles().length;
                    }
                    commMethods.verifyString(String.valueOf(len), statsView.getAuditExtractRecCount());
                }

                else if (tc.equalsIgnoreCase("SF_ID_065"))
                {
                    sumPage.clickSubmitBtn();
                    Thread.sleep(10000);
                    ProjDashBoardPage.clickHomeTab();
                    String finalStat = ProjDashBoardPage.verifyProcess(procName);
                    commMethods.verifyString(finalStat, "PASS");
                    ProjDashBoardPage.viewStats(procName);
                    String auditLocation = statsView.getAuditExtractLocation();
                    int len = 0;
                    if (IS_UNIX)
                    {
                        System.out.println("goes to --->>" + auditLocation);
                        len = new File(auditLocation).listFiles().length;
                    } else
                    {
                        System.out.println("goes to --->>" + "C:" + auditLocation.replace("/", "\\"));
                        String newPath = "C:" + auditLocation.replace("/", "\\");
                        len = new File(newPath).listFiles().length;
                    }
                    commMethods.verifyString(String.valueOf(len), statsView.getAuditExtractRecCount());
                }
            }
        }
    }

    @Title("Sample Files Base Process Creation")
    @Test(dataProvider = "sf_base", enabled = false)
    public void createBaseProcess(String testCase, String testRun, String tc, String description, String procName, String process, String data,
            String useDmSamples, String groups, String allRecords, String accepts, String rejects, String acceptExclusion, String rejectExclusion,
            String exclusions, String records, String levelsCodes, String selectAuditCriteria, String tableName, String fieldSelection, String level,
            String operator, String lowValue, String highValue, String columnCount, String perfomMoveSt, String tableNames, String moveLayout,
            String movStName, String movFields, String colCount, String literalValue) throws Exception
    {
        String status = null;
        auditHPage.clickAuditTab();

        Thread.sleep(5000);
        auditHPage.clickSampleFileBtn();
        Thread.sleep(3000);

        sfPage.selectProcess(process);
        sfPage.selectData(data);
        sfPage.inputProcessName(procName);
        commMethods.selectTheGroups(groups);
        if (!groups.equalsIgnoreCase("NA") && commMethods.isAllGroupsSelected() == false)
        {
            commMethods.clickAllGroups();
        }
        String procId = commMethods.getProcId();
        Thread.sleep(5000);
        String accRejCode[] = records.split(",");
        String selectedlevelsCodes[] = levelsCodes.split(";");

        if ("CHECK".equalsIgnoreCase(useDmSamples))
        {
            sfPage.checkUseDmSamples();

        } else
        {
            Thread.sleep(5000);
            commMethods.selectRecordTypes(procName, allRecords, accepts, rejects);
            Thread.sleep(2000);
            if (!process.startsWith("IP") && (!"NA".equalsIgnoreCase(acceptExclusion) || !"NA".equalsIgnoreCase(rejectExclusion)))
            {
                commMethods.selectExclusionForRecordTypes(process, acceptExclusion, rejectExclusion, exclusions);
            }
            Thread.sleep(2000);
        }

        if (!"NA".equalsIgnoreCase(records) && !"NA".equalsIgnoreCase(levelsCodes))
        {
            sfPage.clickContinueBtn();
            sfPage.inputAccRegRecsnew(records);
            Thread.sleep(2000);
            sfPage.clickByAcceptRejectCode();
            Thread.sleep(2000);
            String levelsCodesSplit[] = levelsCodes.split(";");
            Thread.sleep(2000);
            sfPage.inputAccRegRecs(levelsCodesSplit[0]);
            sfPage.inputAccRejCreate(levelsCodesSplit[1]);
            sampleSetSetup.clickContinueBtn();
        }
        if (!"CHECK".equalsIgnoreCase(useDmSamples))
        {
            sampleSetSetup.clickContinueBtn();
            rfCommonMethods.handleAlert();
        }

        // if (/* "SF_ID_038".equalsIgnoreCase(tc) || */"SF_ID_040".equalsIgnoreCase(tc))
        // {
        // sampleSetSetup.clickContinueBtn();
        // rfCommonMethods.handleAlert();
        // }
        if ("Y".equalsIgnoreCase(perfomMoveSt))
        {
            Thread.sleep(5000);
            movStmntExpDataSetPage.performMoveStatement(perfomMoveSt, tableNames, moveLayout, movStName);
            movStmntExpDataSetPage.clickContinueButton();
            if (moveLayout.equalsIgnoreCase("Create New"))
            {
                date = new Date();
                editMovStPage.inputMovStName(dateFormat.format(date));
                editMovStPage.selectMoveStFields(movFields);
                editMovStPage.clickColumnsBtn();
                editMovStPage.selectColumnCount(colCount);
                editMovStPage.columnPositions(colCount, literalValue);
                editMovStPage.clickSaveEditCol();
            }

        }
        editMovStPage.clickContinueButton();
        sumPage.clickSubmitBtn();
        Thread.sleep(10000);
        ProjDashBoardPage.clickHomeTab();
        String finalStat = ProjDashBoardPage.verifyProcess(procName);
        commMethods.verifyString(finalStat, "PASS");
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] sf_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SampleFiles", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] sf_CBA() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SampleFiles", "CBA");
        return testObjArray;
    }
    
    @DataProvider
    public Object[][] sf_base() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SampleFiles", "BAS");
        return testObjArray;
    }
}
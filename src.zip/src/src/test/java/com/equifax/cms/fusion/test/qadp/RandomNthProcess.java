package com.equifax.cms.fusion.test.qadp;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.RNPages.DataProcessingHomePage;
import com.equifax.cms.fusion.test.RNPages.RNSummaryPage;
import com.equifax.cms.fusion.test.RNPages.RandomNthSetupPage;
import com.equifax.cms.fusion.test.RNPages.RnStatsView;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Random Nth Process Tests")
public class RandomNthProcess
{

    boolean flag = false;
    public WebDriver driver;
    public static String formattedDate1;
    private ProjectDashBoardPage ProjDashBoardPage;
    private DataProcessingHomePage dpHomePage;
    private RandomNthSetupPage rnPage;
    private CommonMethods commMethods;
    private RNSummaryPage rnSummPage;
    private RnStatsView rnStatsView;
    private DmStatsView dmStatsView;
    private ShippingPage shPage;
    private StackingPage stackingPage;
    private JobStackingPage jobStackingPage;

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        rnSummPage = PageFactory.initElements(driver, RNSummaryPage.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingHomePage.class);
        rnPage = PageFactory.initElements(driver, RandomNthSetupPage.class);
        rnStatsView = PageFactory.initElements(driver, RnStatsView.class);
        dmStatsView = PageFactory.initElements(driver, DmStatsView.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @Test(dataProvider = "rn_Reg_QA", description = "Regression QA test cases")
    public void rnProcessStats(String tc_Id, String testRun, String TC, String Desc, String copyProj, String copyProcName, String processName,
            String process, String data, String groups, String opTbleName, String numToOutput, String allRecords, String accepts, String rejects,
            String exclusions, String newProcess, String newData,String stackProcName, ITestContext testContext)
            throws Exception
    {
        ProjDashBoardPage.clickHomeTab();
        String status = null;
        Modules module = new Modules();
        testContext.setAttribute("WebDriver", driver);
        // *******************UI Validation**********************
        if ("RN_ID_036".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickRandomNthButton();
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please enter the Process Name.");
            rnPage.processNameField(processName);
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Select Input Process and Data");
            rnPage.selectProcessField(process);
            rnPage.clickSubmitButton();
            // commMethods.verifyString(rnPage.getTextMessage(),"Select input Data");
            rnPage.selectDataField(data);
            Thread.sleep(2000);
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please enter Number to Output");
            rnPage.numberToOutputField(numToOutput);
            Thread.sleep(2000);
            rnPage.clickSubmitButton();
            Thread.sleep(2000);
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please select Record Types");
            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
            rnPage.numberToOutputField("abc");
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please enter a valid numeric value");
            rnPage.numberToOutputField("!@#$%");
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please enter a valid numeric value");
            rnPage.numberToOutputField(numToOutput);
            rnPage.OutputTableNameField("");
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getTextMessage(), "Please provide a valid Output Table Name");
            rnPage.OutputTableNameField("!@#$%");
            rnPage.clickSubmitButton();
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getErrorMessage(),
                    "Output Table name: '!@#$%' can contain only character,number or underscore and should not start with a number.");
            rnPage.OutputTableNameField(opTbleName);
            rnPage.OutputTableNameField(opTbleName);
            rnPage.clickSaveButton();
            commMethods.verifyString(rnPage.getPageHeader(), "Random Nth Setup");
            rnPage.clickSubmitButton();
            commMethods.verifyString(rnPage.getPageHeader(),
                    "Data Processing Select a task to complete, or click on a dataprocessing job in the grid below.");
            // **************Copy Process***************
        } else if ("RN_ID_446".equalsIgnoreCase(tc_Id))
        {
            // commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            status = dpHomePage.GetProcessStatus();
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
            dpHomePage.selectDuplicateRNTH();
            status = dpHomePage.GetProcessStatus();
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
            dpHomePage.clickOnEditRTH();
            String copyProcName1 = rnPage.Ele_ProcessName.getAttribute("value");
            commMethods.verifyString(copyProcName1, processName);
            ProjDashBoardPage.clickHomeTab();
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            String copyProc = ProjDashBoardPage.getNameOfProcCopied(copyProcName);
            String copyStatus = driver.findElement(By.xpath("//td[contains(text(),'" + copyProc + "')]//following::td[1]")).getText();
            commMethods.verifyString(copyStatus, "Yes");
        } else if ("RN_ID_457".equalsIgnoreCase(tc_Id))
        {
            // commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            status = dpHomePage.GetProcessStatus();
            commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
        } else
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickRandomNthButton();
            String fProName = commMethods.getFinalProcessName();
            rnPage.processNameField(processName);
            rnPage.selectProcessField(process);
            // cm.waitForElement(".//*[@id='jobId']/label");
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            rnPage.selectDataField(data);
            if ("RN_ID_034".equalsIgnoreCase(tc_Id))
            {
                String jobId = driver.findElement(By.xpath(".//*[@id='jobId']/label")).getText();
                commMethods.verifyString(jobId, "");
            } else if ("RN_ID_029".equalsIgnoreCase(tc_Id))
            {
                rnPage.clickSaveButton();
                ProjDashBoardPage.clickDataProcessingTab();
                module.initializeDriver(driver);
                status = dpHomePage.GetProcessStatus();
                commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
            } else
            {
                if (!"NA".equalsIgnoreCase(groups))
                {
                    commMethods.selectTheGroups(groups);
                }
                if ("RN_ID_035".equalsIgnoreCase(tc_Id))
                {
                    rnPage.OutputTableNameField(opTbleName);
                    String tblName = rnPage.Ele_OutputTableName.getAttribute("value");
                    commMethods.verifyString(tblName, opTbleName);
                } else
                {
                    rnPage.numberToOutputField(numToOutput);
                    if (!process.startsWith("IP"))
                    {
                        /* commMethods.selectRecordTypes(processName, allRecords, accepts, rejects); */
                        commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
                    }

                    if ("RN_ID_451".equalsIgnoreCase(tc_Id))
                    {
                        commMethods.verifyboolean(rnPage.ipAsinput(), false);
                    } else if ("RN_ID_448".equalsIgnoreCase(tc_Id))
                    {
                        rnPage.clickSaveButton();
                        WebElement allRecSel = commMethods.Ele_AllRecRegardlessOfType;
                        commMethods.verifyboolean(allRecSel.isSelected(), true);
                    } else if ("RN_ID_028".equalsIgnoreCase(tc_Id))
                    {
                        rnPage.clickSaveButton();
                        ProjDashBoardPage.clickDataProcessingTab();
                        
                        module.initializeDriver(driver);
                        status = dpHomePage.GetProcessStatus();
                        commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                        /*dpHomePage.selectDuplicateRNTH();
                        status = dpHomePage.GetProcessStatus();
                        commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                        dpHomePage.selectSummaryRNTH();
                        String sumProcName = rnSummPage.procNameOnSum(processName);
                        commMethods.verifyString(sumProcName, processName);
                        String sumProc = driver.findElement(By.xpath("//td[contains(text(),'" + process + "')]")).getText().trim();
                        commMethods.verifyString(sumProc, process);
                        String sumData = driver.findElement(By.xpath(".//*[@id='DataTables_Table_0']/tbody/tr/td[3]")).getText();
                        commMethods.verifyString(sumData, data);
                        String sumNoRecToOutput = driver.findElement(By.xpath("(//td[contains(text(),'" + numToOutput + "')])[2]")).getText().trim();
                        commMethods.verifyString(sumNoRecToOutput, numToOutput);
                        rnSummPage.clickSubmitButton();
                        status = dpHomePage.GetProcessStatus();
                        commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());*/
                    } else if ("RN_ID_046".equalsIgnoreCase(tc_Id))
                    {
                        rnPage.clickSaveButton();
                        ProjDashBoardPage.clickDataProcessingTab();
                        System.out.println("Navigated to Data Processing Home screen");
                        module.initializeDriver(driver);
                        status = dpHomePage.GetProcessStatus();
                        commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                        dpHomePage.selectSummaryRNTH();
                        String sumFrpName = driver.findElement(By.xpath("//tr[@class='odd']/td[3]/table/tbody/tr/td")).getText();
                        commMethods.verifyString(sumFrpName, groups);
                    } else
                    {
                        rnPage.clickSubmitButton();
                        System.out.println("Navigated to Data Processing Home screen");
                        if ("RN_ID_031".equalsIgnoreCase(tc_Id))
                        {
                            String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
                            commMethods.verifyboolean(errMsg.endsWith("do not exist."), true);
                        } else
                        {
                            status = dpHomePage.GetProcessStatus();
                            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                            if ("RN_ID_452".equalsIgnoreCase(tc_Id))
                            {
                                dpHomePage.selectDuplicateRNTH();
                                status = dpHomePage.GetProcessStatus();
                                commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                                dpHomePage.clickOnEditRTH();
                                commMethods.verifyboolean(rnPage.ipAsinput(), false);
                            } else if ("RN_ID_025".equalsIgnoreCase(tc_Id) || "RN_ID_444".equalsIgnoreCase(tc_Id)
                                    || "RN_ID_027".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String Status = ProjDashBoardPage.verifyProcess(fProName);
                                commMethods.verifyString(Status, "PASS");
                            } else if ("BP2_SM_ID_018".equalsIgnoreCase(tc_Id))
                            {
                                // commMethods.writeProcessName_Reg("SM_ID_018","", colno, Name);
                            } else if ("RN_ID_004".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                // String jobId = ProjDashBoardPage.jobNameWithId(fProName);
                                String Status = ProjDashBoardPage.verifyProcess(fProName);
                                commMethods.verifyString(Status, "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                                // driver.switchTo().frame("sb-player");
                                String InputTableNameRN = rnStatsView.getInputTableNameRN();
                                Long recordsProcessingRNUI = rnStatsView.getRecordsProcessedCountRN();
                                Long recordsProcessingRNGP = rnStatsView.getRecordsProcessCountFromGP(InputTableNameRN);
                                commMethods.verifyLong(recordsProcessingRNUI, recordsProcessingRNGP);
                                String OutputTableNameRN = rnStatsView.getOutputTableNameRN();
                                Long InputTableCountRNUI = rnStatsView.getInputTableCountRN();
                                Long OutputTableCountRNUI = rnStatsView.getOutputTableCountRN();
                                Long SurplusCountUI = rnStatsView.getSurplusCountRN();
                                Long HeaderTableCountDMGP = ProjDashBoardPage.getRecordsFromGP(InputTableNameRN);
                                Long OutputTableCountGP = ProjDashBoardPage.getRecordsFromGP(OutputTableNameRN);
                                Long SurplusCountGP = commMethods.getSurplusRecFromGP(OutputTableNameRN);
                                /*
                                 * Long byPassRecRNUI = InputTableCountRNUI - recordsProcessingRNUI; Long byPassRecRNGP =
                                 * rnStatsView.getBypassRecCountFromGP(InputTableNameRN); String nthFlagCountRNGP =
                                 * Long.toString(rnStatsView.getNthFlagCountFromGP(InputTableNameRN));
                                 * commMethods.verifyString(numToOutput,nthFlagCountRNGP); commMethods.verifyLong(byPassRecRNUI, byPassRecRNGP);
                                 */
                                commMethods.verifyLong(InputTableCountRNUI, HeaderTableCountDMGP);
                                commMethods.verifyLong(OutputTableCountRNUI, OutputTableCountGP);
                                commMethods.verifyLong(SurplusCountUI, SurplusCountGP);
                                // driver.switchTo().defaultContent();
                                ProjDashBoardPage.clickCloseButtonStats();
                            } else if ("RN_ID_012".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String Status = ProjDashBoardPage.verifyProcess(fProName);
                                commMethods.verifyString(Status, "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                                // driver.switchTo().frame("sb-player");
                                String InputTableNameRN = rnStatsView.getInputTableNameRN();
                                Long recordsProcessingRNUI = rnStatsView.getRecordsProcessedCountRN();
                                Long recordsProcessingRNGP = rnStatsView.getRecordsProcGrpCountFromGP(InputTableNameRN,groups);
                                commMethods.verifyLong(recordsProcessingRNUI, recordsProcessingRNGP);
                                // ProjDashBoardPage.closeStatsWindow();
                            } else if ("RN_ID_005".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String Status = ProjDashBoardPage.verifyProcess(fProName);
                                commMethods.verifyString(Status, "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                                // driver.switchTo().frame("sb-player");
                                String InputTableNameRN = rnStatsView.getInputTableNameRN();
                                String OutputTableNameRN = rnStatsView.getOutputTableNameRN();
                                Long srNthDropCountUI = rnStatsView.getSRNthFlagCountRN();
                                Long srNthDropCountGP = rnStatsView.getSRNthDropCountFromGP(OutputTableNameRN, InputTableNameRN);
                                commMethods.verifyLong(srNthDropCountUI, srNthDropCountGP);
                                // ProjDashBoardPage.closeStatsWindow();
                            }
                        }
                    }
                }
            }
        }
    }

    @Test(dataProvider = "rn_Reg_CBA", description ="Regression Dev test cases")
    public void rnProcessVerification(String tc_Id, String testRun, String TC, String Desc, String copyProj, String copyProcName, String processName,
            String process, String data, String groups, String opTbleName, String numToOutput, String allRecords, String accepts, String rejects,
            String exclusions, String newProcess, String newData,String stackProcName,ITestContext testContext) throws Exception
    {
        ProjDashBoardPage.clickHomeTab();
        String status = null;

        testContext.setAttribute("WebDriver", driver);
        ProjDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickRandomNthButton();
        String fProName = commMethods.getFinalProcessName();
        rnPage.processNameField(processName);
        rnPage.selectProcessField(process);

        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        rnPage.selectDataField(data);
        if (!"NA".equalsIgnoreCase(groups))
        {
            commMethods.selectTheGroups(groups);
        }
        rnPage.numberToOutputField(numToOutput);
        if (!process.startsWith("IP"))
        {

            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        }
        if ("RN_ID_033".equalsIgnoreCase(tc_Id))
        {
        	rnPage.clickSaveButton();
        	ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            String stackAssignedId = commMethods.getFinalProcessName();
            
            jobStackingPage.inputStackName(stackProcName);

            String process_Name = fProName + ":" + "" + processName;
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(process_Name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(process_Name);
           
            jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);

            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(1000);
            ProjDashBoardPage.clickHomeTab();
            String Status = ProjDashBoardPage.verifyProcess(stackAssignedId);
            commMethods.verifyString(Status, "PASS");
        }
        
        if ("RN_ID_449".equalsIgnoreCase(tc_Id))
        {
            HashMap<String, String> selectedExclusionMapWithRecordTypes = new HashMap<String, String>();
            if (!process.startsWith("IP"))

            {

                commMethods.selectExclusionForRecordTypes(process, accepts, rejects, exclusions);
                selectedExclusionMapWithRecordTypes = commMethods.getSelectedExlusion(accepts, rejects);

            }
            rnPage.selectProcessField(newProcess);

            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            rnPage.selectDataField(newData);

            HashMap<String, String> updatedExclusionMapWithRecordTypes = commMethods.getSelectedExlusion(accepts, rejects);

            for (Entry<String, String> entry : selectedExclusionMapWithRecordTypes.entrySet())
            {
                for (Entry<String, String> entry1 : updatedExclusionMapWithRecordTypes.entrySet())
                {
                    if (entry1.getKey().equalsIgnoreCase(entry.getKey()))
                    {
                        Assert.assertTrue(!entry1.getValue().equalsIgnoreCase(entry.getValue()));

                    }
                }
            }

        } else if ("RN_ID_450".equalsIgnoreCase(tc_Id))
        {
            HashMap<String, String> selectedExclusionMapWithRecordTypes = new HashMap<String, String>();
            if (!process.startsWith("IP"))

            {

                commMethods.selectExclusionForRecordTypes(process, accepts, rejects, exclusions);
                selectedExclusionMapWithRecordTypes = commMethods.getSelectedExlusion(accepts, rejects);

            }
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            rnPage.selectDataField(newData);

            HashMap<String, String> updatedExclusionMapWithRecordTypes = commMethods.getSelectedExlusion(accepts, rejects);

            for (Entry<String, String> entry : selectedExclusionMapWithRecordTypes.entrySet())
            {
                for (Entry<String, String> entry1 : updatedExclusionMapWithRecordTypes.entrySet())
                {
                    if (entry1.getKey().equalsIgnoreCase(entry.getKey()))
                    {
                        Assert.assertTrue(entry1.getValue().equalsIgnoreCase(entry.getValue()));

                    }
                }
            }

        } else if ("RN_ID_445".equalsIgnoreCase(tc_Id))
        {
            rnPage.clickSubmitButton();
            Thread.sleep(1000);
            ProjDashBoardPage.clickHomeTab();
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            Thread.sleep(1000);
            String[] processAsInputArr = process.split(":");
            commMethods.searchProcessOnDashboardAndViewStats(processAsInputArr[0] + "_" + processAsInputArr[1]);

            String inputTableName = dmStatsView.getHeaderTableNameDM();

            ProjDashBoardPage.clickCloseButtonStats1();
            Thread.sleep(2500);
            commMethods.searchProcessOnDashboardAndViewStats(fProName);

            String outputTableName = rnStatsView.getOutputTableNameRN();

            commMethods.verifyLong(rnStatsView.getCountOfBypassedRecordsFromGP(outputTableName),
                    rnStatsView.getCountOfAcceptedRecordsFromInputTable(inputTableName));

        }
    }

    @Test(dataProvider = "rn_Reg_Base", description = "Base process method")
    public void createBaseProcess(String tc_Id, String testRun, String TC, String Desc, String copyProj, String copyProcName, String processName,
            String process, String data, String groups, String opTbleName, String numToOutput, String allRecords, String accepts, String rejects,
            String exclusions, String newProcess, String newData,String stackProcName, ITestContext testContext) throws Exception
    {	
    	
    	String executionStatus = commMethods.getTheExecutionStatus(process);
        if (executionStatus.equalsIgnoreCase("COMPLETED"))
    {
       // commMethods.handleAlert();
        ProjDashBoardPage.clickDataProcessingTab();
        commMethods.handleAlert();
        dpHomePage.clickRandomNthButton();
        String fProName = commMethods.getFinalProcessName();
        rnPage.processNameField(processName);
        rnPage.selectProcessField(process);

        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
        rnPage.selectDataField(data);
        if (!"NA".equalsIgnoreCase(groups))
        {
            commMethods.selectTheGroups(groups);
        }
        rnPage.numberToOutputField(numToOutput);

        if (!process.startsWith("IP"))
        {

            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        }

        rnPage.clickSubmitButton();
        Thread.sleep(2000);
/*        ProjDashBoardPage.clickDataProcessingTab();
       String status = dpHomePage.GetProcessStatus();
        commMethods.verifyString(StatusEnum.READY.name(), status.trim());*/
    }
        //ProjDashBoardPage.clickHomeTab();
        //String Status = ProjDashBoardPage.verifyProcess(fProName);
        //commMethods.verifyString(Status, "PASS");

    }
    
    @DataProvider
    public Object[][] rn_Reg_Base() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RandomNth", "BAS");
        return testObjArray;
    }
    @DataProvider
    public Object[][] rn_Reg_CBA() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RandomNth", "CBA");
        return testObjArray;
    }
    @DataProvider
    public Object[][] rn_Reg_QA() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "RandomNth", "Y");
        return testObjArray;
    }
}
package com.equifax.cms.fusion.test.qareporting;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.REPORTINGPages.QFRSummaryPage;
import com.equifax.cms.fusion.test.REPORTINGPages.QuickFrequencyReportPage;
import com.equifax.cms.fusion.test.REPORTINGPages.ReportingHomePage;
import com.equifax.cms.fusion.test.RFPages.RFCommonMethods;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class QuickFrequencyReport
{

    public WebDriver driver;
    private Modules module;
    // public static String formattedDate1;
    private ProjectDashBoardPage ProjDashBoardPage;

    private QuickFrequencyReportPage qfrPage;
    private ReportingHomePage reportingHomePage;
    private CommonMethods commMethods;
    private QFRSummaryPage qfrSummPage;
    // private QFRStatsView qfrStats;
    private StackingPage stackingPage;
    private RFCommonMethods rfCommonMethods;

    private JobStackingPage jobStackPage;
    private ShippingPage shPage;

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        qfrPage = PageFactory.initElements(driver, QuickFrequencyReportPage.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        reportingHomePage = PageFactory.initElements(driver, ReportingHomePage.class);
        qfrSummPage = PageFactory.initElements(driver, QFRSummaryPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackPage = PageFactory.initElements(driver, JobStackingPage.class);
        rfCommonMethods = PageFactory.initElements(driver, RFCommonMethods.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Title("Quick Frequency Process Regression Test")
    @Test(dataProvider = "qfr_Reg")
    public void qfrProcessStats(String tc_Id, String testRun, String TC, String Description, String processName, String Process, String Data,
            String groups, String allRecords, String accepts, String rejects, String Table, String Field, String createRanges,
            String showZeroCountRanges, String strtValue, String endValue, String increment, String valuesToIsolate, ITestContext testContext)
            throws Exception
    {
        String status = null;
        Modules module = new Modules();
        testContext.setAttribute("WebDriver", driver);
        reportingHomePage.clickReportingTab();
        reportingHomePage.clickQuickFrequency_Btn();
        String fProName = commMethods.getFinalProcessName();
        String procId = qfrPage.getProcId();
        if ("QFR_ID_045".equalsIgnoreCase(tc_Id))
        {
            qfrPage.clickSubmitButton();
            commMethods
                    .verifyString(qfrPage.getErrorMessage(),
                            "Error: Please enter the Process Name.\nError: Select input tables.\nError: Please select Record Types.\nError: At least one report is required.");
            qfrPage.inputProcessName(processName);
            qfrPage.clickSubmitButton();
            commMethods.verifyString(qfrPage.getErrorMessage(),
                    "Error: Select input tables.\nError: Please select Record Types.\nError: At least one report is required.");
        } else
        {
            qfrPage.inputProcessName(processName);
            qfrPage.selectProcessField(Process);
            qfrPage.selectDataField(Data);
            commMethods.selectTheGroups(groups);
            if ("QFR_ID_039".equalsIgnoreCase(tc_Id))
            {
                qfrPage.clickSaveButton();
                commMethods.verifyboolean(commMethods.all_RecordsGroups.isSelected(), true);

            } else
            {
                commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
                // // JQWidget selection
                // qfrPage.clickAddReportLayout();
                // Thread.sleep(3000);
                // qfrPage.setReportTitle("Test1");
                // Thread.sleep(5000);
                // // qfrPage.selectTableField(Table, Field);
                // qfrPage.selTableFlds1(Table);
                // Thread.sleep(3000);
                // qfrPage.selectTableField(Table, Field);
                // Thread.sleep(5000);
                // qfrPage.clickFirstDimArrow();
                // Thread.sleep(3000);
                // qfrPage.clickReportDetailSave();
                // Thread.sleep(3000);
                qfrPage.clickAddReportLayout();
                Thread.sleep(2500);

                qfrPage.setReportTitle("testReport");
                qfrPage.selectTableField(Table, Field);
                Thread.sleep(3000);
                qfrPage.clickFirstDimArrow();

                Thread.sleep(5000);

                // qfrPage.clickAddFieldButton();
                qfrPage.clickCreateRangeBtn(createRanges);
                qfrPage.clickZeroCountRanges(showZeroCountRanges);
                qfrPage.inputStartingValue(strtValue);
                qfrPage.inputEndingValue(endValue);
                qfrPage.inputIncrement(increment);
                qfrPage.valuesToIsolate(valuesToIsolate);
                if ("QFR_ID_047".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(qfrPage.isSelectedFieldDisplayed(Field), true);
                } else if ("QFR_ID_048".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(qfrPage.CreateRanges_CB.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.ZeroCntRanges_CB.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.StartingValue_Fld.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.EndValue_Fld.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.Increment_Fld.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.valToIso1.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.valToIso2.isDisplayed(), true);
                    commMethods.verifyboolean(qfrPage.valToIso3.isDisplayed(), true);

                }

                else if ("QFR_ID_049".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(qfrPage.add_Btn.isDisplayed(), true);

                }
                qfrPage.clickReportDetailSave();
                if ("QFR_ID_053".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickBackButton();
                    String alertMsg = driver.switchTo().alert().getText();
                    // commMethods.verifyString(alertMsg,
                    // "This page is asking you to confirm that you want to leave - data you have entered may not be saved.");
                    driver.switchTo().alert().accept();
                } else if ("QFR_ID_064".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    // String errMsg = driver.findElement(By.xpath("//div[@class='winErrMsg errMsg errMsgExt']/span")).getText();
                    commMethods.verifyboolean(qfrPage.getErrorMessage1().contains("Min value is greater than or equal to max value"), true);
                } else if ("QFR_ID_059".equalsIgnoreCase(tc_Id))
                {
                    // qfrPage.clickSubmitButton();
                    String errMsg = driver.findElement(By.xpath("//div[@class='winErrMsg errMsg errMsgExt']/span")).getText();
                    commMethods.verifyString(errMsg, "Error: Please enter a valid number for increment range for 1st Dimension.");
                } else if ("QFR_ID_051".equalsIgnoreCase(tc_Id))
                {
                    module.initializeDriver(driver);
                    qfrPage.clickSaveButton();
                    reportingHomePage.clickReportingTab();
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                    // module.selectDuplicate();
                    // status = commMethods.getProcessStatus();
                    // commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                    // module.clickOnEdit();
                    // String title = ProjDashBoardPage.getPageTitle();
                    // commMethods.verifyString(title, "Quick Frequency Report Complete the Required Information, and click 'Save' or 'Submit'.");
                } else if ("QFR_ID_052".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                } else if ("QFR_ID_028".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    String Status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(Status, "PASS");
                } else if ("QFR_ID_060".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click();
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
                    Thread.sleep(2000);
                    String report_gpcusuirpt = driver
                            .findElement(
                                    By.xpath("//td[contains(text(),'" + procId
                                            + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'REPORT_GPCUSUIRPT')]")).getText().trim();
                    commMethods.verifyString(report_gpcusuirpt, "REPORT_GPCUSUIRPT");
                } else if ("QFR_ID_044".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSaveButton();
                    Thread.sleep(2000);
                    ProjDashBoardPage.clickReportingTab();
                    Thread.sleep(2000);
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.READY.name());
                    module.initializeDriver(driver);
                    module.selectSummary();
                    commMethods.verifyString(qfrSummPage.getInputProcessFromSummary(), Process);
                    commMethods.verifyString(qfrSummPage.getInputDataFromSummary(), Data);
                    commMethods.verifyString(qfrSummPage.getSelectedTableFromSummary(), Table);
                    commMethods.verifyboolean(qfrSummPage.getSelectedFieldFromSummary().contains(Field), true);
                    // commMethods.verifyString(qfrSummPage.getSelectedRangesFromSummary(), createRanges);
                    // commMethods.verifyString(qfrSummPage.getSelectedZeroCountRangesFromSummary(), showZeroCountRanges);
                    commMethods.verifyboolean(qfrSummPage.getSelectedStartingValueFromSummary().contains(strtValue), true);
                    commMethods.verifyboolean(qfrSummPage.getSelectedEndingValueFromSummary().contains(endValue), true);
                    commMethods.verifyboolean(qfrSummPage.getSelectedIncrementFromSummary().contains(increment), true);
                } else if ("QFR_ID_066".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSaveButton();
                    ProjDashBoardPage.clickReportingTab();
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.READY.name());
                    driver.navigate().refresh();
                    Thread.sleep(2000);
                    module.initializeDriver(driver);
                    module.selectDuplicate();
                    Thread.sleep(2000);
                    // reportingHomePage.selectDuplicate();
                    // commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.READY.name());
                    driver.navigate().refresh();
                    Thread.sleep(2000);
                    module.selectEdit();

                    Thread.sleep(2000);
                    String fProNameNew = commMethods.getFinalProcessName();
                    qfrPage.clickSubmitButton();
                    Thread.sleep(2000);
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
                    Thread.sleep(2000);
                    ProjDashBoardPage.clickHomeTab();
                    // String fProNameNew = fProName.substring(4, fProName.length());
                    // int val = Integer.valueOf(fProNameNew) + 1;
                    // String newProcId = fProName.substring(0, 3) + String.valueOf(val);
                    String Status = ProjDashBoardPage.verifyProcess(fProNameNew);
                    commMethods.verifyString(Status, "PASS");
                } else if ("QFR_ID_070".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    Thread.sleep(2000);
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
                    module.initializeDriver(driver);
                    module.selectSummary();
                    Thread.sleep(2000);
                    qfrSummPage.clickSubmitButton();
                    rfCommonMethods.handleAlert();
                    qfrSummPage.clickSubmitButton();
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
                } else if ("QFR_ID_072".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    commMethods.verifyboolean(qfrPage.getErrorMessage1().startsWith("Error: Error : Job run details for Input Process "), true);
                    // commMethods.verifyboolean(qfrPage.getErrorMessage1().endsWith("do not exist."), true);
                } else if ("QFR_ID_166".equalsIgnoreCase(tc_Id) || "QFR_ID_062".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    String Status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(Status, "PASS");
                } else if ("QFR_ID_172".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    commMethods.verifyString(commMethods.getProcessStatus(), StatusEnum.SUBMITTED.name());
                } else if ("QFR_ID_187".equalsIgnoreCase(tc_Id))
                {
                    qfrPage.clickSubmitButton();
                    commMethods.verifyString(qfrPage.getErrorMessage(), "Error: Please enter the Process Name.");
                }
            }
        }
    }

    @Title("Quick Frequency Process Regression Test")
    @Test(dataProvider = "qfr_CBA", priority = 1)
    public void qfrProcessCBA(String tc_Id, String testRun, String TC, String Description, String processName, String process, String Data,
            String groups, String allRecords, String accepts, String rejects, String Table, String field, String createRanges,
            String showZeroCountRanges, String strtValue, String endValue, String increment, String valuesToIsolate, ITestContext testContext)
            throws Exception

    {
        testContext.setAttribute("WebDriver", driver);
        reportingHomePage.clickReportingTab();
        reportingHomePage.clickQuickFrequency_Btn();
        String status = null;

        qfrPage.inputProcessName(processName);
        qfrPage.selectProcessField(process);
        String assignedId = commMethods.getProcId();
        qfrPage.selectDataField(Data);
        String tableToSelect = process.split(":")[0] + ":" + Data;
        System.out.println(qfrPage.accRejDisplaystatus());
        if ("QFR_ID_046".equalsIgnoreCase(TC))
        {
            qfrPage.selectAllRecordsCheckBox();
            Thread.sleep(1000);
            commMethods.verifyString(qfrPage.accRejDisplaystatus(), "display: none;");
        } else
        {
            Thread.sleep(2500);

            commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
            Thread.sleep(2500);
            qfrPage.clickAddReportLayout();
            Thread.sleep(2500);

            qfrPage.setReportTitle("testReport");
            qfrPage.selectTableField(Table, field);
            Thread.sleep(3000);
            qfrPage.clickFirstDimArrow();
            qfrPage.clickReportDetailSave();
            Thread.sleep(5000);
            if ("QFR_ID_067".equalsIgnoreCase(TC))
            {
                Thread.sleep(5000);
                qfrPage.clickSaveButton();
                Thread.sleep(15000);
                ProjDashBoardPage.clickReportingTab();
                Thread.sleep(2000);
                module.initializeDriver(driver);
                module.selectDuplicate();
                module.initializeDriver(driver);
                Thread.sleep(5000);
                module.selectEdit();
                Thread.sleep(5000);
                commMethods.verifyString(processName, qfrPage.processNameValue());
                commMethods.verifyString(process, qfrPage.getSelectedProcess());
                commMethods.verifyboolean(true, commMethods.isAllRecordsChckboxChecked());
                Thread.sleep(2000);
                qfrPage.selectReportFileToEdit(processName);
                qfrPage.selectReportFileToEdit(processName);
                Thread.sleep(2000);
                qfrPage.clickEditReportFile();
                commMethods.verifyString(process.split(":")[0] + ":" + Table + "." + field, qfrPage.getSelectedField());

                String dataMatch = tableToSelect + "." + field;
                commMethods.verifyString(qfrPage.getDimensionaReportData(), dataMatch);
                commMethods.verifyString(qfrPage.getDimensionReportRightColData(), "COUNT");

            }
            if ("QFR_ID_068".equalsIgnoreCase(TC))
            {
                Thread.sleep(8000);
                qfrPage.clickSaveButton();
                Thread.sleep(5000);
                qfrPage.clickSaveButton();
                Thread.sleep(10000);
                ProjDashBoardPage.clickJobStackingTab();
                Thread.sleep(5000);
                stackingPage.clickJobStackingButton();
                Thread.sleep(5000);
                jobStackPage.inputStackName(assignedId);
                jobStackPage.selectProcessCheckBox(processName);
                jobStackPage.inputStackName(processName);
                // String assignedId1 = jobStackPage.getAssignedId();
                String new_process_name = assignedId + ":" + "" + processName;

                jobStackPage.clickProcessDropDown();
                Thread.sleep(5000);
                jobStackPage.selectProcessFromDropdown(new_process_name);
                Thread.sleep(15000);
                jobStackPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(new_process_name);
                Thread.sleep(5000);
                jobStackPage.selectTheProcessFromTheFlowChart(processList,30);
                Thread.sleep(15000);
                jobStackPage.clickJobStackingSubmitButton();
                Thread.sleep(30000);

                ProjDashBoardPage.clickHomeTab();
                Thread.sleep(3000);
                String Status = ProjDashBoardPage.verifyProcess(processName);
                commMethods.verifyString(Status, "PASS");

            }

            if ("QFR_ID_071".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                qfrPage.clickSaveButton();
                Thread.sleep(15000);
                ProjDashBoardPage.clickReportingTab();
                module.initializeDriver(driver);
                module.selectSummary();
                commMethods.verifyboolean(true, qfrSummPage.isGroupSelectionDisplayed(groups));
            }
            if ("QFR_ID_170".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                qfrPage.clickSaveButton();
                Thread.sleep(5000);
                ProjDashBoardPage.clickReportingTab();
                module.initializeDriver(driver);
                driver.navigate().refresh();
                Thread.sleep(2000);
                module.selectSummary();
                Thread.sleep(5000);
                commMethods.verifyboolean(true, qfrSummPage.getInputProcessFromSummary().contains(process));
            }

            if ("QFR_ID_171".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                Thread.sleep(5000);
                qfrPage.clickSaveButton();
                Thread.sleep(10000);
                ProjDashBoardPage.clickReportingTab();
                module.initializeDriver(driver);
                module.selectSummary();
                Thread.sleep(5000);
                commMethods.verifyboolean(qfrSummPage.getSelectedTableFromSummary().contains(Data), true);
                commMethods.verifyboolean(qfrSummPage.getSelectedFieldFromSummary().contains(field), true);

            }
            if ("QFR_ID_185".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                Thread.sleep(5000);
                qfrPage.clickSaveButton();
                Thread.sleep(10000);
                ProjDashBoardPage.clickReportingTab();
                Thread.sleep(5000);
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());

            }
            if ("QFR_ID_212".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                Thread.sleep(5000);
                Thread.sleep(2000);
                qfrPage.selectReportFileToEdit(processName);
                qfrPage.selectReportFileToEdit(processName);
                Thread.sleep(2000);
                qfrPage.clickEditReportFile();
                qfrPage.clickCreateRangeBtn(createRanges);
                qfrPage.inputStartingValue(strtValue);
                qfrPage.inputEndingValue(endValue);
                qfrPage.inputIncrement(increment);
                qfrSummPage.saveEditReportDetails();
                Thread.sleep(5000);
                String errorMsg = qfrPage.getErrorText();
                commMethods.verifyString(errorMsg, "Error: Please enter a valid number for increment range for 1st Dimension.");

            }
            if ("MJ_ID_329".equalsIgnoreCase(TC))
            {

                commMethods.selectTheGroups(groups);
                Thread.sleep(2500);
                qfrSummPage.clickSubmitButton();
                Thread.sleep(5000);
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(assignedId), "PASS");
                Thread.sleep(1000);
                Thread.sleep(1000);
                shPage.clickViewStatsForJobLevel(assignedId);
                driver.switchTo().frame("sb-player");
                long recordProcessed = qfrPage.getCountOfRecordSelecProcessing();
                String inputTableName = qfrPage.getReportSelectedTableName();
                commMethods.verifyLong(recordProcessed, ProjDashBoardPage.getTheRecordsWithMatchFlagFromGP(inputTableName));

            }
            if ("MJ_ID_330".equalsIgnoreCase(TC))
            {
                commMethods.selectTheGroups(groups);
                Thread.sleep(2500);
                qfrSummPage.clickSubmitButton();
                Thread.sleep(5000);
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(assignedId), "PASS");
                Thread.sleep(1000);
                Thread.sleep(1000);
                shPage.clickViewStatsForJobLevel(assignedId);
                // driver.switchTo().frame("sb-player");
                long recordProcessed = qfrPage.getCountOfRecordSelecProcessing();
                String inputTableName = qfrPage.getReportSelectedTableName();
                commMethods.verifyLong(recordProcessed, ProjDashBoardPage.getTheRecordsWithMatchFlagAsBlankFromGP(inputTableName));

            }
        }

    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    /*
     * @AfterMethod public void closeBrowser() { driver.quit(); }
     */

    @DataProvider
    public Object[][] qfr_CBA() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "QFR",
                "CBA");
        return testObjArray;
    }

    @DataProvider
    public Object[][] qfr_Reg() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "QFR",
                "Y");
        return testObjArray;
    }
}

/*package com.equifax.cms.fusion.test.qaop;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.OPPages.OpDataCheckPage;
import com.equifax.cms.fusion.test.OPPages.OpConfigurationPage;
import com.equifax.cms.fusion.test.OPPages.OpHomePage;
import com.equifax.cms.fusion.test.OPPages.OpSummaryPage;
import com.equifax.cms.fusion.test.OPPages.OpAliasPage;
import com.equifax.cms.fusion.test.OPPages.OpFileNamingSplittingPage;
import com.equifax.cms.fusion.test.OPPages.OpMoveStatementsPage;
import com.equifax.cms.fusion.test.OPPages.OpSetupPage;
import com.equifax.cms.fusion.test.OPPages.OpRecordTypesPage;
import com.equifax.cms.fusion.test.OPPages.OpSortOrderPage;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;


@Title("Output Process UI")
public class OutputProcessUI_Validations extends AbstractCoreTest {
	
	boolean flag = false;
	public static WebDriver driver;
	public static String formattedDate1;
	
	private ProjectDashBoardPage ProjDashBoardPage;
	private OpHomePage OPHPage;
	private OpSetupPage OPSetupPage;
	private OpRecordTypesPage RecTypesPage;
	private OpAliasPage OPAliasPage;
	private OpConfigurationPage OPConfigPage;
	private OpMoveStatementsPage OPMoveStPage;
	private OpSortOrderPage sortOrderPage;
	private OpFileNamingSplittingPage OPFileNameSplitPage;
	private OpDataCheckPage DataChckPage;
	private CommonMethods commMethods;
	private OpSummaryPage sumPage;
	private OracleDBHelper db;
	public static int i = 0;
	DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
	
	private boolean acceptNextAlert = true;	
	
	@Title("User Login with akp8 ")
	@Step("User Login")
	@SuppressWarnings("resource")
	@BeforeTest
	(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
	public void LoginandSearchProj() throws InterruptedException {

		driver = FusionFirefoxDriver.getDriver();
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		OPHPage = PageFactory.initElements(driver, OpHomePage.class); 
		OPSetupPage = PageFactory.initElements(driver, OpSetupPage.class);
		RecTypesPage = PageFactory.initElements(driver, OpRecordTypesPage.class);
		OPAliasPage = PageFactory.initElements(driver, OpAliasPage.class);
		OPConfigPage = PageFactory.initElements(driver, OpConfigurationPage.class);
		OPMoveStPage = PageFactory.initElements(driver, OpMoveStatementsPage.class);
		sortOrderPage = PageFactory.initElements(driver, OpSortOrderPage.class);
		OPFileNameSplitPage = PageFactory.initElements(driver, OpFileNamingSplittingPage.class);
		DataChckPage = PageFactory.initElements(driver, OpDataCheckPage.class);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		sumPage = PageFactory.initElements(driver, OpSummaryPage.class);
		commMethods.userLogin();
		commMethods.searchProject();
	}
	
	@Test(dataProvider = "InputData", priority=1,
			description = "TS1: Output process UI Validations")
	public void opSetupPageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
			
			ProjDashBoardPage.clickOutputTab();
			OPHPage.clickOutputButton();
			OPSetupPage.clickContinueButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Process Name is requiredProcess is requiredTable is requiredPlease select purpose");

//			OPSetupPage.processNameField(ProcessName);
			OPSetupPage.selectProcessField(process);
			OPSetupPage.selectDataField(data);
			OPSetupPage.selectFilePorpuse(porpuse);
			OPSetupPage.clickContinueButton();			
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Process Name is required");
			
			OPSetupPage.processNameField(processName);
			OPSetupPage.selectProcessField("Select");
			OPSetupPage.selectFilePorpuse("Select One");
			OPSetupPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Process is requiredTable is requiredPlease select purpose");
			
			OPSetupPage.processNameField(processName);
			OPSetupPage.selectProcessField(process);
			OPSetupPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Table is requiredPlease select purpose");
			
			OPSetupPage.selectDataField(data);
			OPSetupPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Please select purpose");
			
			OPSetupPage.selectFilePorpuse(porpuse);
			OPSetupPage.clearProcessNameField();
			OPSetupPage.processNameField("!@#$");
			OPSetupPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]")).getText();
			commMethods.verifyString(errMsg, "Please enter valid process name");
			
			OPSetupPage.clearProcessNameField();
			OPSetupPage.processNameField(processName);
			OPSetupPage.clickContinueButton();
			
	}
	
	@Test(dataProvider = "InputData", priority=2,
			description = "TS1: Output Record Type Page UI Validations")
	public void opRecTypePageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
		
			RecTypesPage.clickContinueButton();
			String errMsg = driver.findElement(By.id("popup_message")).getText();
			commMethods.verifyString(errMsg, "File Name cannot be empty.");
			driver.findElement(By.id("popup_ok")).click();
			
			RecTypesPage.fileNameField(filename);
			RecTypesPage.clickContinueButton();
			errMsg = driver.findElement(By.id("popup_message")).getText();
			commMethods.verifyString(errMsg, "Please select atleast one Fail Code for Test");
			driver.findElement(By.id("popup_ok")).click();
			
			RecTypesPage.clickAllRecords();
			RecTypesPage.clickForward();
			RecTypesPage.clickContinueButton();
	}
	
	@Test(dataProvider = "InputData", priority=3,
			description = "TS1: Output Alias Page UI Validations")
	public void opAliasPageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
			
			OPAliasPage.clickContinueButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div[1]")).getText();
			commMethods.verifyString(errMsg, "Please select at least one table.");
			
			OPAliasPage.inputAliasTables(aliasTable);
			OPAliasPage.clearAliasName();
			OPAliasPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div[1]")).getText();
			commMethods.verifyString(errMsg, "Please select at least one table.* Required field");
			
			OPAliasPage.inputAliasName("hdr");
			OPAliasPage.clickContinueButton();
			
	}
	
	@Test(dataProvider = "InputData", priority=4,
			description = "TS1: Output Configuration Page UI Validations")
	public void opConfigPageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
			
			OPConfigPage.clickContinueButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[1]")).getText();
			commMethods.verifyString(errMsg, "Layout name is required. Please provide output layout fields.");
			
			OPConfigPage.selectPerformSeeding();
			Date date = new Date();
			OPConfigPage.outputLayoutNameField(dateFormat.format(date));
			OPConfigPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[1]")).getText();
			commMethods.verifyString(errMsg, "Please provide output layout fields.");
			
			OPConfigPage.csvLayoutFileField(LayoutFile);
			OPConfigPage.clickLoadButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			OPConfigPage.clearOpLayoutNameField();
			OPConfigPage.clickContinueButton();
			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[1]")).getText();
			commMethods.verifyString(errMsg, "Layout name is required.");
			
			OPConfigPage.outputLayoutNameField(dateFormat.format(date));
			OPConfigPage.clickContinueButton();
	}
	
	@Test(dataProvider = "InputData", priority=5,
			description = "TS1: Output Move Statement & Sorting Page UI Validations")
	public void opMoveStSortPageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
			
			OPMoveStPage.clickAddButton();
			OPMoveStPage.selectRecTypes(recordType);
			OPMoveStPage.selectDatatoOutput("2");
			OPMoveStPage.clickContinueButton();
			String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div")).getText();
			
//			commMethods.verifyString(errMsg, "Please select the layout Fields for record 1. ");
			System.out.println(errMsg);
			commMethods.verifyString(errMsg, "Please select the layout Fields for record 1. Please select the record type for record 1. Please select the data to output for record 1.");
			OPMoveStPage.clickContinueButton();
			sortOrderPage.clickContinueButton();
		}
	
	@Test(dataProvider = "InputData", priority=6,
			description = "TS1: Output Move Statement &  Page UI Validations")
	public void opFileNameSplitPageUI(String testRun, String TC , String Desc,  String processName, 
			String process, String data, String porpuse, String filename, String recordType, String aliasTable, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField, 
			ITestContext testContext)
			throws Exception {
			
			OPFileNameSplitPage.clickFileSplitReq();
			OPFileNameSplitPage.clickContinueButton();
			String errMsg = driver.findElement(By.id("textMsg")).getText();
			commMethods.verifyString(errMsg, "Please select at least one option for splitting");
			
			OPFileNameSplitPage.clickDivideFileIntoGrps();
			OPFileNameSplitPage.clickContinueButton();
			errMsg = driver.findElement(By.id("textMsg")).getText();
			commMethods.verifyString(errMsg, "Please enter a valid value");
			
			OPFileNameSplitPage.clickSplitField();
			OPFileNameSplitPage.clickContinueButton();
			errMsg = driver.findElement(By.id("textMsg")).getText();
			commMethods.verifyString(errMsg, "Please select field in Split by Field");
			
			OPFileNameSplitPage.selectSplitFieldByField(splitField);
			OPFileNameSplitPage.clickContinueButton();
			
			
			
	}
	
	
			
			//JavascriptExecutor js = (JavascriptExecutor) driver;
			//js.executeScript("document.getElementByXPath('.//a[contains(text(),'All Records')]').setAttribute('class', 'active')");
			driver.findElement(By.xpath(".//a[contains(text(),'"+ RecordType +"')]")).click();
//			driver.findElement(By.xpath(".//a[contains(text(),'"+ RecordType +"')]")).click();
			//driver.findElement(By.xpath(".//*[@class='active']")).click();                
			Thread.sleep(500);
//			RecTypesPage.clickAllRecords();
//			Thread.sleep(500);
			RecTypesPage.clickForward();
			
			
			
			
			OPAliasPage.selectHeaderTable();
			OPAliasPage.clickForwardButton();
			OPAliasPage.clearHeaderAliasName();
			
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			OPConfigPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			OPMoveStPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			sortOrderPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			OPFileNameSplitPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			DataChckPage.clickDataCheckChckbox();
			DataChckPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);	
			ProjDashBoardPage.clickOutputTab();
		
		}


	@Test(dataProvider = "InputData", 
			description = "TS1: Output stats verification")
	public void opProcessStats(String testRun, String TC , String Desc,  String ProcessName, 
			String Process, String Data, String porpuse, String filename, String RecordType, 
			String seeding, String LayoutName, String fileFormat, String crLFOptions, String LayoutFile, 
			String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, 
			String FileNum, String fileSplitReq, String grpNum, String numOfFiles, String splitField)
			throws Exception {

		String status = null;
		Modules module = new Modules();
		if ("Y".equalsIgnoreCase(testRun)) 
		{	
			ProjDashBoardPage.clickOutputTab();
			OPHPage.clickOutputButton();
			OPSetupPage.processNameField(ProcessName);
			OPSetupPage.selectProcessField(Process);
			OPSetupPage.selectDataField(Data);
			OPSetupPage.selectFilePorpuse(porpuse);
			OPSetupPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
			
			String dynpath = ".//a[contains(text(),'"+ RecordType +"')]";
			
			if("All Records".equalsIgnoreCase(RecordType)){
				driver.findElement(By.xpath(dynpath)).click();
			}
			

			//driver.findElement(By.xpath(".//*[@class='active']")).click();                
			Thread.sleep(500);
//			RecTypesPage.clickAllRecords();
//			Thread.sleep(500);
			RecTypesPage.clickForward();
			RecTypesPage.fileNameField(filename);
			RecTypesPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			OPAliasPage.selectHeaderTable();
			OPAliasPage.clickForwardButton();
			OPAliasPage.clearHeaderAliasName();
			OPAliasPage.aliasName(Data, "hdr");
			OPAliasPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			OPConfigPage.seeding(seeding);
			OPConfigPage.outputLayoutNameField(LayoutName);
			OPConfigPage.selectFileFormat(fileFormat);
			OPConfigPage.selectCRLFOptions(crLFOptions);
			OPConfigPage.csvLayoutFileField(LayoutFile);
			OPConfigPage.clickLoadButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			OPConfigPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			if(!"NA".equalsIgnoreCase(layoutField)){
			OPMoveStPage.selectLayout(layoutField);
			
			}
			
			if(!"NA".equalsIgnoreCase(movRecType)){
//				driver.switchTo().frame("sb-player");
				OPMoveStPage.selectRecTypes(movRecType);
				
			}
			
			if(!"NA".equalsIgnoreCase(dataToOutput)){
//				driver.switchTo().frame("outputMoveForm");
				OPMoveStPage.selectDatatoOutput(dataToOutput);
				
			}
			
			OPMoveStPage.clickAddButton();
			driver.findElement(By.xpath(".//*[@id='outputMoveTable']/tbody/tr[1]/td[2]/span/a")).click();
			driver.findElement(By.xpath(".//a[contains(text(),'DP_SEQUENCE_NUM.DP_SEQUENCE_NUM')]")).click();
			
			driver.findElement(By.xpath("(.//*[@id='0']/img)[1]")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.switchTo().frame("outputMoveForm");
			driver.findElement(By.id("A")).click();
			driver.findElement(By.id("add_opMoveRecType")).click();
			driver.findElement(By.xpath("(.//a[contains(text(),'Save')])[1]")).click();
			driver.findElement(By.xpath("(.//*[@id='0']/img)[2]")).click();
			driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			driver.findElement(By.id("enterLiteral")).sendKeys("abc");
			driver.findElement(By.xpath("(.//a[contains(text(),'Save')])[2]")).click();
			
			OPMoveStPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			if("ON".equalsIgnoreCase(sortReq)){
				sortOrderPage.clickSortRequired();
				sortOrderPage.selectSortField(sortFields);
				
			}
			
			sortOrderPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			if(!"NA".equalsIgnoreCase(FileNum)){
				OPFileNameSplitPage.StartingFileNumField(FileNum);
				
			}
			
			if(!"OFF".equalsIgnoreCase(fileSplitReq)){
				OPFileNameSplitPage.clickFileSplitReq();
				
				if(!"NA".equalsIgnoreCase(grpNum)){
					OPFileNameSplitPage.clickDivideFileIntoGrps();
					OPFileNameSplitPage.divideFileIntoGrpsValue(grpNum);
				}
				
				if(!"NA".equalsIgnoreCase(numOfFiles)){
					OPFileNameSplitPage.clickSplitPerFile();
					OPFileNameSplitPage.splitPerFileValue(numOfFiles);
				}
				
				if(!"NA".equalsIgnoreCase(splitField)){
					OPFileNameSplitPage.clickSplitField();
					OPFileNameSplitPage.selectSplitFieldByField(splitField);
				}
				
			}
			
			OPFileNameSplitPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			DataChckPage.clickDataCheckChckbox();
			DataChckPage.clickContinueButton();
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			
			ProjDashBoardPage.clickOutputTab();
			
			}
		
	}
	
	
	@DataProvider
	public Object[][] InputData() throws Exception {
		Object[][] testObjArray = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir")+PropertiesUtils.getProperty("path"), "OPprocess","UI");
		return (testObjArray);

	}
	
	
	public void getscreenshot() throws Exception 
    {
            File scrFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
         //The below method will save the screen shot in d drive with name "screenshot.png"
            FileUtils.copyFile(scrFile, new File("C:\\Users\\akp8\\Desktop\\screenshot.png"));
    }
	
	private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

}
*/
package com.equifax.cms.fusion.test.qadm;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.DMPages.APmodulePage;
import com.equifax.cms.fusion.test.DMPages.ConfigDeStandPage;
import com.equifax.cms.fusion.test.DMPages.ConfigIdScanPage;
import com.equifax.cms.fusion.test.DMPages.CreditInputPage;
import com.equifax.cms.fusion.test.DMPages.CriteriaRejectsPage;
import com.equifax.cms.fusion.test.DMPages.DMFilterConfigPage;
import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.DMPages.DataMenuHomePage;
import com.equifax.cms.fusion.test.DMPages.DataOriginPage;
import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.DMPages.DoubleCheckPage;
import com.equifax.cms.fusion.test.DMPages.ModuleDependenciesPage;
import com.equifax.cms.fusion.test.DMPages.ModuleOutputsPage;
import com.equifax.cms.fusion.test.DMPages.PointScoreDropsPage;
import com.equifax.cms.fusion.test.DMPages.PreSelectsPage;
import com.equifax.cms.fusion.test.DMPages.ProcessNamePage;
import com.equifax.cms.fusion.test.DMPages.ProductPage;
import com.equifax.cms.fusion.test.DMPages.ScoreModelsPage;
import com.equifax.cms.fusion.test.DMPages.SourceInputPage;
import com.equifax.cms.fusion.test.DMPages.StateZipCodeInputPage;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

public class DataMenuProcessQAduplicate extends AbstractCoreTest
{
    boolean flag = false;
    public WebDriver driver;
    public OracleDBHelper db;
    public static int i = 1;
    public static List<WebElement> scoreModelElem;
    private ProjectDashBoardPage ProjDashBoardPage;
    private APmodulePage APModPag;
    private ConfigDeStandPage ConfigDEPag;
    private ConfigIdScanPage ConfigIDPag;
    private CreditInputPage CreditInPag;
    private CriteriaRejectsPage CritRejPag;
    private DataMenuHomePage DataMenuHomPag;
    private DataOriginPage DataOriginPag;
    private DMFilterConfigPage DMFilterConPag;
    private DMSummaryPage DMSummPag;
    private DmStatsView DmStatView;
    private DoubleCheckPage DoubleChckPag;
    private ModuleDependenciesPage ModDepenPag;
    private ModuleOutputsPage ModOutptPag;
    private PointScoreDropsPage PointScrDropPag;
    private PreSelectsPage PreSelPag;
    private ProcessNamePage ProcesNamePag;
    private ProductPage ProdPag;
    private ScoreModelsPage ScreModlPag;
    private StateZipCodeInputPage StZipCodInPag;
    private CommonMethods commMethods;
    private SourceInputPage SrcInpPag;
    private Modules module;
    private DataProcessingTabFIL dpHomePage;
    private FilteringPage filterPage;
    
    private String jobId;

    private static final String DIM_ERRMSG = "Please select credit dataset with dimensions.";
    private static final Logger LOGGER = LoggerFactory.getLogger(DataMenuProcessQAduplicate.class);
    private static final String SAVETOFILE = "Save to File";

    @Step("Login and Search Project No.")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginAndSearchProj() throws InterruptedException
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(200, TimeUnit.SECONDS);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        DataMenuHomPag = PageFactory.initElements(driver, DataMenuHomePage.class);
        APModPag = PageFactory.initElements(driver, APmodulePage.class);
        ConfigIDPag = PageFactory.initElements(driver, ConfigIdScanPage.class);
        ConfigDEPag = PageFactory.initElements(driver, ConfigDeStandPage.class);
        DoubleChckPag = PageFactory.initElements(driver, DoubleCheckPage.class);
        DMFilterConPag = PageFactory.initElements(driver, DMFilterConfigPage.class);
        CreditInPag = PageFactory.initElements(driver, CreditInputPage.class);
        CritRejPag = PageFactory.initElements(driver, CriteriaRejectsPage.class);
        DataOriginPag = PageFactory.initElements(driver, DataOriginPage.class);
        DMSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
        ModDepenPag = PageFactory.initElements(driver, ModuleDependenciesPage.class);
        ModOutptPag = PageFactory.initElements(driver, ModuleOutputsPage.class);
        PointScrDropPag = PageFactory.initElements(driver, PointScoreDropsPage.class);
        PreSelPag = PageFactory.initElements(driver, PreSelectsPage.class);
        ProcesNamePag = PageFactory.initElements(driver, ProcessNamePage.class);
        ProdPag = PageFactory.initElements(driver, ProductPage.class);
        ScreModlPag = PageFactory.initElements(driver, ScoreModelsPage.class);
        StZipCodInPag = PageFactory.initElements(driver, StateZipCodeInputPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        SrcInpPag = PageFactory.initElements(driver, SourceInputPage.class);
        DmStatView = PageFactory.initElements(driver, DmStatsView.class);
        module = PageFactory.initElements(driver, Modules.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabFIL.class);
        filterPage = PageFactory.initElements(driver, FilteringPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }
    
    @Title("Multiple Archive Data Menu Stats Verification")
    @Description("Data Menu with Different Inputs")
    @Test(dataProvider = "dm_Reg", priority = 1)//, enabled = false) // QA
    public void dataMenuRegTesting(String tc_Id, String testRun, String TC, String descr, String copyProj, String copyProcName, String processName,
            String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, String dataField,
            String zipCodeInput, String states, String stateList, String prodAPmod, String APModuleNonCriteria, String APModuleCriteria,
            String depProj, String depFile, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel, String NCPScoreModel,
            String pointScoreDrop, String idScan, String idScanRejects, String deStandard, String doublechck, String DNSdrop, String ageDrop,
            String factActOpt, String invalidDrop, String testFileDrop, String cid_CNX, String mla, String availableDataSets, String dataSetType,
            String DataSet, ITestContext testContext) throws Exception
    {
        ProjDashBoardPage.clickHomeTab();
        
        String status = null;
        Modules module = new Modules();
        testContext.setAttribute("WebDriver", this.driver);
        if ("DM_ID_144".equalsIgnoreCase(tc_Id))
        {
            commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            /*
             * ProjDashBoardPage.inputProjNum(copyProj); ProjDashBoardPage.clickCopyProjSrchBtn();
             * ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
             */
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
        } else if ("DM_ID_362".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
            module.initializeDriver(driver);
            module.clickOnEdit();
            driver.findElement(By.xpath("//a[contains(text(),'" + APModuleNonCriteria + "')]")).click();
            APModPag.clickBackBtn();
            StZipCodInPag.clickBackBtn();
            ProdPag.clickBackBtn();
            commMethods.verifyString(commMethods.drpDwnFldRetained(), DataOriginField);
            ProdPag.clickContinueButton();
            commMethods.verifyString(commMethods.drpDwnFldRetained(), Product);
            ProdPag.clickContinueButton();
            commMethods.verifyboolean(driver.findElement(By.id(stateList)).isSelected(), true);
            String zipCodeCopy = driver.findElement(By.xpath(".//*[@value=' ']")).getText();
            commMethods.verifyString(zipCodeCopy, "Select");
            commMethods.verifyboolean(StZipCodInPag.Ele_drop.isSelected(), true);
            StZipCodInPag.clickContinueButton();
            commMethods.verifyString(commMethods.drpDwnFldRetained(), APModuleNonCriteria);
            APModPag.clickContinueButton();
            ModOutptPag.clickContinueButton();
            commMethods.verifyboolean(ScreModlPag.scoreModuleFirst.isDisplayed(), true);
            driver.findElement(By.xpath(".//*[@id='dataMenuScoreModelForm']/div[1]/div/div/div/div[1]/img")).click();
            ScreModlPag.scoreMdlcheck();
            ScreModlPag.clickContinueButton();
            commMethods.verifyboolean(ConfigIDPag.Ele_RunIdScan.isSelected(), true);
            ConfigIDPag.clickContinueButton();
            commMethods.verifyboolean(ConfigDEPag.Ele_RunDEStandards.isSelected(), true);
            ConfigDEPag.clickContinueButton();
            DoubleChckPag.clickContinueButton();
            DMFilterConPag.clickContinueButton();
            commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id=':onepercent:golden:weekly::segmentCMS::']")).isDisplayed(), true);
        } else if ("DM_ID_355".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
            module.initializeDriver(driver);
            module.clickOnEdit();
            String pageTitle = driver.findElement(By.xpath("//h3[@class='fusion-h3Title']")).getText();
            commMethods.verifyString(pageTitle, "Process Name Enter a Process Name, and click 'Continue.'");
        } else
        {
            // DM home page:
            ProjDashBoardPage.clickDataMenuTab();
            DataMenuHomPag.clickDataMenuButton();
            String processName1 = commMethods.getFinalProcessName();
            String procNameColon = commMethods.getFinalProcessNameColon();
            String procId = commMethods.getProcId();
            ProcesNamePag.InputProcessNameField(processName);
            ProcesNamePag.clickContinueButton();
            DataOriginPag.selectDataOriginField(DataOriginField);
            DataOriginPag.clickContinueButton();
            if ("DM_ID_170".equalsIgnoreCase(tc_Id))
            {
                ProdPag.clickContinueButton();
                SrcInpPag.selectProcessField(smProcess);
                commMethods.verifyboolean(SrcInpPag.getJobNodisplayed(), false);
            } else if ("DM_ID_298".equalsIgnoreCase(tc_Id))
            {
                ProdPag.clickContinueButton();
                WebElement procSelected = SrcInpPag.Ele_Process;
                commMethods.verifyboolean(procSelected.isDisplayed(), true);
            } else if ("DM_ID_617".equalsIgnoreCase(tc_Id))
            {
                ProdPag.clickContinueButton();
                PreSelPag.clickContinue();
                PreSelPag.clickBack();
                String pageTitle = ProjDashBoardPage.getPageTitle();
                commMethods.verifyString(pageTitle, "Product Select a Product,and click 'Continue'.");
                ProdPag.clickContinueButton();
                PreSelPag.selectGenderCB(gender);
                PreSelPag.inputAgeRanges(age);
                PreSelPag.clickContinue();
                pageTitle = ProjDashBoardPage.getPageTitle();
                commMethods.verifyString(pageTitle, "State/Zip Code Input Select State and/or Zip Code Input, and click 'Continue'.");
            } else if ("DM_ID_635".equalsIgnoreCase(tc_Id))
            {
                ProdPag.clickContinueButton();
                String pageTitle = ProjDashBoardPage.getPageTitle();
                commMethods.verifyString(pageTitle, "Pre-Selects Select Hispanic Names Only or Gender or enter Age Range , and click 'Continue'.");
                PreSelPag.clickContinue();
                String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg, "Selection is required for either Age, Gender, or Hispanic flag");
                WebElement hisPanicName = PreSelPag.Hispanic_Names_CB;
                WebElement male = PreSelPag.Male_CB;
                WebElement female = PreSelPag.Female_CB;
                WebElement neutral = PreSelPag.Neutral_CB;
                commMethods.verifyboolean(hisPanicName.isSelected(), false);
                commMethods.verifyboolean(hisPanicName.isEnabled(), true);
                commMethods.verifyboolean(male.isSelected(), false);
                commMethods.verifyboolean(male.isEnabled(), true);
                commMethods.verifyboolean(female.isSelected(), false);
                commMethods.verifyboolean(female.isEnabled(), true);
                commMethods.verifyboolean(neutral.isSelected(), false);
                commMethods.verifyboolean(neutral.isEnabled(), true);
                PreSelPag.Age_Range_1_LowAge.sendKeys("2.1");
                PreSelPag.Age_Range_1_HighAge.sendKeys("5.2");
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg, "Range number 1 is invalid. Allows only Numeric values");
                PreSelPag.Age_Range_1_LowAge.clear();
                PreSelPag.Age_Range_1_LowAge.sendKeys("A");
                PreSelPag.Age_Range_1_HighAge.clear();
                PreSelPag.Age_Range_1_HighAge.sendKeys("B");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg, "Range number 1 is invalid. Allows only Numeric values");
                PreSelPag.Age_Range_1_LowAge.clear();
                PreSelPag.Age_Range_1_LowAge.sendKeys("!@$");
                PreSelPag.Age_Range_1_HighAge.clear();
                PreSelPag.Age_Range_1_HighAge.sendKeys("#@$");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                PreSelPag.Age_Range_1_LowAge.clear();
                PreSelPag.Age_Range_1_LowAge.sendKeys("10");
                PreSelPag.Age_Range_1_HighAge.clear();
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 1 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
                PreSelPag.Age_Range_1_HighAge.clear();
                PreSelPag.Age_Range_1_HighAge.sendKeys("2");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 1 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
                PreSelPag.Age_Range_2_LowAge.sendKeys("9");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 2 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
                PreSelPag.Age_Range_2_HighAge.sendKeys("3");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                Thread.sleep(2000);
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 2 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
                PreSelPag.Age_Range_3_LowAge.sendKeys("20");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 3 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
                PreSelPag.Age_Range_3_HighAge.sendKeys("7");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                Thread.sleep(2000);
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 3 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
                PreSelPag.Age_Range_4_LowAge.sendKeys("18");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 4 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
                PreSelPag.Age_Range_4_HighAge.sendKeys("11");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                Thread.sleep(2000);
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 4 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
                PreSelPag.Age_Range_5_LowAge.sendKeys("25");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 5 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
                PreSelPag.Age_Range_5_HighAge.sendKeys("18");
                PreSelPag.clickContinue();
                PreSelPag.clickContinue();
                Thread.sleep(2000);
                errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Range number 5 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
            } else
            {
                if ("DM_ID_469".equalsIgnoreCase(tc_Id) || "DM_ID_470".equalsIgnoreCase(tc_Id))
                {
                    Select sel = new Select(ProdPag.Ele_product);
                    List<WebElement> allOptions = sel.getOptions();
                    if (allOptions.contains(Product))
                    {
                        Assert.assertFalse(false);
                    } else
                    {
                        Assert.assertTrue(true);
                    }
                } else
                {
                    if ("DM_ID_476".equalsIgnoreCase(tc_Id))
                    {
                        ProdPag.clickContinueButton();
                        Select selType = new Select(StZipCodInPag.Ele_SelectStates);
                        String[] exp = { "Select", "Do Not Reject States", "All U.S. states and Territories", "All except Vermont", "US States Only",
                                "US States Only except Vermont", "Territories Only (AS, FM, GU, MH, MP, PR, PW, UM, and VI)",
                                "Military APO/FPO/DPO Only(AA, AE, & AP)", "Selected Areas (any other custom selection)" };
                        List<WebElement> options = selType.getOptions();
                        for (int i = 0; i < 9; i++)
                        {
                            commMethods.verifyString(options.get(i).getText(), exp[i]);
                        }
                    } else if ("DM_ID_477".equalsIgnoreCase(tc_Id))
                    {
                        ProdPag.clickContinueButton();
                        StZipCodInPag.selectStatesDropDwn(states);
                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='AK']")).isSelected(), true);
                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='ME']")).isSelected(), true);
                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='TN']")).isSelected(), true);
                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='SD']")).isSelected(), true);
                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='VI']")).isSelected(), true);
                        commMethods.verifyboolean(StZipCodInPag.Ele_drop.isDisplayed(), true);
                        commMethods.verifyboolean(StZipCodInPag.Ele_tag.isDisplayed(), true);
                        commMethods.verifyboolean(StZipCodInPag.Ele_reject.isDisplayed(), true);
                    } else
                    {
                        ProdPag.selectProductField(Product);
                        if ("DM_ID_451".equalsIgnoreCase(tc_Id) || "DM_ID_453".equalsIgnoreCase(tc_Id))
                        {
                            ProdPag.productIdField(productId);
                            ProdPag.memberNumberField(MemNum);
                            ProdPag.clickContinueButton();
                            commMethods.verifyboolean(SrcInpPag.isSMprocDisplayed(smProcess), true);
                        } else if ("DM_ID_171".equalsIgnoreCase(tc_Id))
                        {
                            ProdPag.clickContinueButton();
                            SrcInpPag.selectProcessField(smProcess);
                            SrcInpPag.selectDataField("HEADER");
                            String[] a = dataField.split(",");
                            Select sel = new Select(SrcInpPag.Ele_Data);
                            List<WebElement> dataFlds = sel.getOptions();
                            boolean flag = false;
                            for (int i = 0; i < a.length; i++)
                            {
                                System.out.println(a[i]);
                                for (WebElement flds : dataFlds)
                                {
                                    if (a[i].contains(flds.getText()))
                                    {
                                        System.out.println(flds.getText());
                                        flag = true;
                                        System.out.println("true");
                                        break;
                                    } else
                                    {
                                        flag = false;
                                        System.out.println("false");
                                    }
                                }
                            }
                            commMethods.verifyboolean(flag, true);
                        } else
                        {
                            // Data origin page:
                            if (DataOriginField.equalsIgnoreCase("Direct Extraction"))
                            {
                                if (Product.equalsIgnoreCase("BPR") || Product.equalsIgnoreCase("BAM"))
                                {
                                    ProdPag.productIdField(productId);
                                    ProdPag.memberNumberField(MemNum);
                                    ProdPag.clickContinueButton();
                                } else
                                {
                                    ProdPag.clickContinueButton();
                                }
                            } else if (DataOriginField.equalsIgnoreCase("List Source"))
                            {
                                if (!Product.equalsIgnoreCase("Prescreen"))
                                {
                                    ProdPag.productIdField(productId);
                                    ProdPag.memberNumberField(MemNum);
                                    ProdPag.clickContinueButton();
                                } else
                                {
                                    ProdPag.clickContinueButton();
                                }
                                SrcInpPag.selectProcessField(smProcess);
                                SrcInpPag.selectDataField(dataField);
                                SrcInpPag.clickContinueButton();
                            } else if (DataOriginField.equalsIgnoreCase("CID List"))
                            {
                                if (!Product.equalsIgnoreCase("Prescreen"))
                                {
                                    ProdPag.productIdField(productId);
                                    ProdPag.memberNumberField(MemNum);
                                    ProdPag.clickContinueButton();
                                } else
                                {
                                    ProdPag.clickContinueButton();
                                }
                                SrcInpPag.selectProcessField(smProcess);
                                SrcInpPag.selectDataField(dataField);
                                SrcInpPag.clickContinueButton();
                            } else if (DataOriginField.equalsIgnoreCase("Pre-Select"))
                            {
                                ProdPag.clickContinueButton();
                                PreSelPag.selectGenderCB(gender);
                                PreSelPag.inputAgeRanges(age);
                                PreSelPag.clickContinue();
                            }
                            if ("DM_ID_596".equalsIgnoreCase(tc_Id))
                            {
                                commMethods.verifyboolean(StZipCodInPag.Ele_drop.isSelected(), true);
                                commMethods.verifyboolean(StZipCodInPag.Ele_tag.isEnabled(), false);
                                commMethods.verifyboolean(StZipCodInPag.Ele_reject.isEnabled(), false);
                            } else
                            {
                                if ("DM_ID_661".equalsIgnoreCase(tc_Id))
                                {
                                    String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div[2]/h3")).getText();
                                    commMethods.verifyString(errMsg,
                                            "State/Zip Code Input Select State and/or Zip Code Input, and click 'Continue'.");
                                } else if ("DM_ID_614".equalsIgnoreCase(tc_Id))
                                {
                                    StZipCodInPag.clickBackBtn();
                                    commMethods.verifyboolean(PreSelPag.Male_CB.isSelected(), true);
                                } else
                                {
                                    StZipCodInPag.selectZipCodeInputField(zipCodeInput);
                                    if (!"NA".equalsIgnoreCase(states))
                                    {
                                        StZipCodInPag.selectStatesDropDwn(states);
                                    }
                                    if (!"NA".equalsIgnoreCase(stateList))
                                    {
                                        StZipCodInPag.selectStatesList(stateList);
                                    }
                                    Thread.sleep(2000);
                                    StZipCodInPag.clickContinueButton();
                                    if ("DM_ID_568".equalsIgnoreCase(tc_Id))
                                    {
                                        APModPag.clickUseProdAPmoduleOnly(prodAPmod);
                                        APModPag.selectAPModuleNonCriteria(APModuleNonCriteria);
                                        APModPag.clickContinueButton();
                                        CritRejPag.clickBackBtn();
                                        commMethods.verifyboolean(driver.findElement(By.xpath(".//*[@id='apModuleId0']")).isDisplayed(), true);
                                    } else if ("DM_ID_587".equalsIgnoreCase(tc_Id))
                                    {
                                        APModPag.clickUseProdAPmoduleOnly(prodAPmod);
                                        APModPag.selectAPModuleNonCriteria(APModuleNonCriteria);
                                        APModPag.clickContinueButton();
                                        CritRejPag.clickBackBtn();
                                        APModPag.remove2ndAPmod();
                                        APModPag.clickAddAPmodButton();
                                        APModPag.selectAPModuleNonCriteria2("FUSION_FLOAT");
                                        APModPag.clickContinueButton();
                                        String alertMsg = driver.findElement(By.xpath(".//*[@id='sb-player']/div/h1")).getText();
                                        commMethods.verifyString(alertMsg,
                                                "Changing AP Modules will reset all Score Models to the default Drop option. The module processing order will also be reset.  ");
                                        driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a")).click();
                                    } else if ("DM_ID_575".equalsIgnoreCase(tc_Id))
                                    {
                                        APModPag.clickUseProdAPmoduleOnly(prodAPmod);
                                        APModPag.selectAPModuleNonCriteria(APModuleNonCriteria);
                                        APModPag.clickContinueButton();
                                        CritRejPag.clickContinueButton();
                                        ModOutptPag.clickContinueButton();
                                        String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[2]")).getText();
                                        commMethods.verifyString(errMsg,
                                                "Autopilot module[JXH_KONTABLE], version number 299721,does not contain output information. Please contact support.");
                                    } else
                                    {
                                        if ("DM_ID_440".equalsIgnoreCase(tc_Id))
                                        {
                                            commMethods.verifyboolean(APModPag.Ele_useProdAPmodulesOnly.isSelected(), true);
                                        } else
                                        {
                                            // AP Module page:
                                            APModPag.clickUseProdAPmoduleOnly(prodAPmod);
                                            APModPag.selectAPModuleNonCriteria(APModuleNonCriteria);
                                            Thread.sleep(3000);
                                            APModPag.clickContinueButton();
                                            if ("DM_ID_043".equalsIgnoreCase(tc_Id) || "DM_ID_276".equalsIgnoreCase(tc_Id))
                                            {
                                                ModDepenPag.inputProjectValue(depProj);
                                                ModDepenPag.selectModDep(depFile);
                                                ModDepenPag.clickContinueButton();
                                                ModOutptPag.clickContinueButton();
                                                ScreModlPag.clickContinueButton();
                                                ConfigIDPag.clickContinueButton();
                                                ConfigDEPag.clickContinueButton();
                                                DoubleChckPag.clickContinueButton();
                                                DMFilterConPag.clickContinueButton();
                                                CreditInPag.selectPullType_CB(cid_CNX);
                                                CreditInPag.click_Unique_CID();
                                                if ("SPECIFIC".equalsIgnoreCase(availableDataSets))
                                                {
                                                    CreditInPag.selectSpcificDataSet();
                                                    CreditInPag.selectDataSetType(dataSetType);
                                                    JavascriptExecutor js = (JavascriptExecutor) driver;
                                                    StringTokenizer stMain = new StringTokenizer(DataSet, ",");
                                                    while (stMain.hasMoreElements())
                                                    {
                                                        js.executeScript("document.getElementById('" + stMain.nextToken()
                                                                + "').setAttribute('class', 'name1 active')");
                                                        Thread.sleep(500);
                                                        driver.findElement(By.xpath(".//*[@class='name1 active']")).click();
                                                        Thread.sleep(500);
                                                        CreditInPag.clickAddButton();
                                                    }
                                                } else
                                                {
                                                    CreditInPag.selectAvailablDataset(availableDataSets);
                                                }
                                                CreditInPag.clickContinueButton();
                                                DMSummPag.clickSubmitButton();
                                                ProjDashBoardPage.clickHomeTab();
                                                String ProcessName1 = ProjDashBoardPage.jobName();
                                                String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                                                commMethods.verifyString(Status, "PASS");
                                                ProjDashBoardPage.clickStatsView(processName1);
                                                driver.switchTo().frame("sb-player");
                                                String tbleP4536DF0 = DmStatView.getP4536DF0tbleName();
                                                String tbleP463A6L0 = DmStatView.getP463A6L0tbleName();
                                                commMethods.verifyboolean(tbleP4536DF0.endsWith("_DM_GPLOAD_P4536DF0_LCRREC"), true);
                                                commMethods.verifyboolean(tbleP463A6L0.endsWith("_DM_GPLOAD_P463A6L0_OUTREC"), true);
                                                Long tbleP4536DF0countUI = DmStatView.getP4536DF0TbleCount();
                                                Long tbleP463A6L0countUI = DmStatView.getP463A6L0TbleCount();
                                                Long tbleP4536DF0countGP = DmStatView.getGpTbleCount(tbleP4536DF0);
                                                Long tbleP463A6L0countGP = DmStatView.getGpTbleCount(tbleP463A6L0);
                                                commMethods.verifyLong(tbleP4536DF0countUI, tbleP4536DF0countGP);
                                                commMethods.verifyLong(tbleP463A6L0countUI, tbleP463A6L0countGP);
                                                ProjDashBoardPage.closeStatsWindow();
                                            } else
                                            {
                                                // Criteria Rejects page:
                                                // APModPag.clickAlert();
                                                if (!"NA".equalsIgnoreCase(APModuleCriteria))
                                                {
                                                    CritRejPag.selectCriteriaRejects(APModuleCriteria);
                                                    CritRejPag.clickContinueButton();
                                                }
                                                String pageTitle = ProjDashBoardPage.getPageTitle();
                                                if (pageTitle.startsWith("Module Dependencies"))
                                                {
                                                    if ("F043BBL0".equalsIgnoreCase(APModuleNonCriteria))
                                                    {
                                                        ModDepenPag.inputProjectF043BBL0(depProj);
                                                        ModDepenPag.inputF043BBL0paraValues(depFile);
                                                        ModDepenPag.clickContinueButton();
                                                    } else if ("JXH_MULTILEVEL".equalsIgnoreCase(APModuleNonCriteria))
                                                    {
                                                        ModDepenPag.selModDepJxh_MultLevel(depFile);
                                                        ModDepenPag.clickContinueButton();
                                                    } else
                                                    {
                                                        ModDepenPag.inputProjectValue(depProj);
                                                        ModDepenPag.selectModDep(depFile);
                                                        ModDepenPag.clickContinueButton();
                                                        /*
                                                         * WebElement alert = driver.findElement(By.xpath(".//*[@id='sb-player']/div/h1"));
                                                         * if(alert.isDisplayed()){
                                                         * driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a[1]")).click(); }
                                                         */
                                                    }
                                                }
                                                if (!"NA".equalsIgnoreCase(APModuleNonCriteria))
                                                {
                                                    pageTitle = ProjDashBoardPage.getPageTitle();
                                                    commMethods.verifyString(pageTitle,
                                                            "Module Outputs Select Module Outputs, and click 'Continue'.");
                                                    if (!NumPerAccCode.equalsIgnoreCase("NA"))
                                                    {
                                                        ModOutptPag.InputnumperAcceptCodeField(NumPerAccCode);
                                                    }
                                                    if (!NumPerRejCode.equalsIgnoreCase("NA"))
                                                    {
                                                        ModOutptPag.InputnumperRejectCodeField(NumPerRejCode);
                                                    }
                                                    if (HoldData.equalsIgnoreCase("ON"))
                                                    {
                                                        ModOutptPag.clickHoldAddiDataAppend();
                                                    }
                                                    ModOutptPag.clickContinueButton();
                                                }
                                                if ("DM_ID_279".equalsIgnoreCase(tc_Id))
                                                {
                                                    ModOutptPag.inputOutputTbleName("MAP_001_check");
                                                    ModOutptPag.clickContinueButton();
                                                    ProjDashBoardPage.clickDataMenuTab();
                                                    module.initializeDriver(driver);
                                                    module.selectDuplicate1();
                                                    status = DataMenuHomPag.GetStatusDM(processName1);
                                                    commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
                                                    module.clickOnEdit();
                                                    ProcesNamePag.clickContinueButton();
                                                    DataOriginPag.clickContinueButton();
                                                    ProdPag.clickContinueButton();
                                                    StZipCodInPag.clickContinueButton();
                                                    APModPag.clickContinueButton();
                                                    String tblName = ModOutptPag.OutputTblName.getAttribute("value");
                                                    commMethods.verifyString(tblName, "MAP_001_check");
                                                } else
                                                {
                                                    /*
                                                     * if (!"NA".equalsIgnoreCase(APModuleNonCriteria)) { pageTitle =
                                                     * ProjDashBoardPage.getPageTitle(); commMethods.verifyString(pageTitle,
                                                     * "Module Outputs Select Module Outputs, and click 'Continue'.");
                                                     * ModOutptPag.clickContinueButton(); }
                                                     */
                                                    if ("DM_ID_458".equalsIgnoreCase(tc_Id))
                                                    {
                                                        String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                                                        commMethods.verifyString(errMsg, "Enter number per accept and reject");
                                                    } else
                                                    {
                                                        pageTitle = ProjDashBoardPage.getPageTitle();
                                                        commMethods.verifyString(pageTitle,
                                                                "Score Models Select your Score Models, and click 'Continue'.");
                                                        if ("DM_ID_208".equalsIgnoreCase(tc_Id))
                                                        {
                                                            ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                            ScreModlPag.clickContinueButton();
                                                            String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                                                            commMethods.verifyString(errMsg,
                                                                    "Error: You can not select NC+ models when Product is not selected BAM or BPR");
                                                        } else if ("DM_ID_209".equalsIgnoreCase(tc_Id))
                                                        {
                                                            ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                            ScreModlPag.clickContinueButton();
                                                            pageTitle = ProjDashBoardPage.getPageTitle();
                                                            commMethods.verifyString(pageTitle,
                                                                    "Configure Id Scan Select the ID Scan options, and click 'Continue.'");
                                                        } else if ("DM_ID_285".equalsIgnoreCase(tc_Id) || "DM_ID_286".equalsIgnoreCase(tc_Id))
                                                        {
                                                            ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                            ScreModlPag.selectFormNoInd1078Mod("CID");
                                                            ScreModlPag.inputActFormNo1078Mod("123");
                                                            ScreModlPag.selectSrcStPos1078Mod("STATE");
                                                            ScreModlPag.inputRiskStPos1078Mod("A");
                                                            /*
                                                             * ScreModlPag.selectModPara5152a("CID"); ScreModlPag.selectModPara5152b("STATE");
                                                             */
                                                            ScreModlPag.clickContinueButton();
                                                            ConfigIDPag.clickContinueButton();
                                                            ConfigDEPag.clickContinueButton();
                                                            DoubleChckPag.clickContinueButton();
                                                            DMFilterConPag.clickContinueButton();
                                                            CreditInPag.selectPullType_CB(cid_CNX);
                                                            CreditInPag.click_Unique_CID();
                                                            if ("SPECIFIC".equalsIgnoreCase(availableDataSets))
                                                            {
                                                                CreditInPag.selectSpcificDataSet();
                                                                CreditInPag.selectDataSetType(dataSetType);
                                                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                StringTokenizer stMain = new StringTokenizer(DataSet, ",");
                                                                while (stMain.hasMoreElements())
                                                                {
                                                                    js.executeScript("document.getElementById('" + stMain.nextToken()
                                                                            + "').setAttribute('class', 'name1 active')");
                                                                    Thread.sleep(500);
                                                                    driver.findElement(By.xpath(".//*[@class='name1 active']")).click();
                                                                    Thread.sleep(500);
                                                                    CreditInPag.clickAddButton();
                                                                }
                                                            } else
                                                            {
                                                                CreditInPag.selectAvailablDataset(availableDataSets);
                                                            }
                                                            CreditInPag.clickContinueButton();
                                                            DMSummPag.clickSubmitButton();
                                                            module.initializeDriver(driver);
                                                            module.selectDuplicate1();
                                                            status = DataMenuHomPag.GetStatusDM(processName1);
                                                            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                                                            module.selectSummary();
                                                            pageTitle = ProjDashBoardPage.getPageTitle();
                                                            commMethods.verifyString(pageTitle,
                                                                    "Summary: Data Menu\nReview the information below, and then click 'Submit' or 'Back'.");
                                                            ProjDashBoardPage.clickHomeTab();
                                                            String ProcessName1 = ProjDashBoardPage.jobName();
                                                            String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                                                            commMethods.verifyString(Status, "PASS");
                                                        } else if ("DM_ID_510".equalsIgnoreCase(tc_Id))
                                                        {
                                                            ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                            ScreModlPag.selectFormNoInd1078Mod("CID");
                                                            ScreModlPag.selModParam("STATE");
                                                            ScreModlPag.clickContinueButton();
                                                            ConfigIDPag.selectRunIdScanCheckBox(idScan);
                                                            ConfigIDPag.selectRejectsInIdScan(idScanRejects);
                                                            ConfigIDPag.clickContinueButton();
                                                            ConfigDEPag.selectRunDeStandardCheckBox(deStandard);
                                                            ConfigDEPag.clickContinueButton();
                                                            DoubleChckPag.clickContinueButton();
                                                            DMFilterConPag.clickContinueButton();
                                                            CreditInPag.selectPullType_CB(cid_CNX);
                                                            CreditInPag.click_Unique_CID();
                                                            if ("SPECIFIC".equalsIgnoreCase(availableDataSets))
                                                            {
                                                                CreditInPag.selectSpcificDataSet();
                                                                CreditInPag.selectDataSetType(dataSetType);
                                                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                StringTokenizer stMain = new StringTokenizer(DataSet, ",");
                                                                while (stMain.hasMoreElements())
                                                                {
                                                                    js.executeScript("document.getElementById('" + stMain.nextToken()
                                                                            + "').setAttribute('class', 'name1 active')");
                                                                    Thread.sleep(500);
                                                                    driver.findElement(By.xpath(".//*[@class='name1 active']")).click();
                                                                    Thread.sleep(500);
                                                                    CreditInPag.clickAddButton();
                                                                }
                                                            } else
                                                            {
                                                                CreditInPag.selectAvailablDataset(availableDataSets);
                                                            }
                                                            CreditInPag.clickContinueButton();
                                                            ProjDashBoardPage.clickDataMenuTab();
                                                            module.initializeDriver(driver);
                                                            module.selectDuplicate1();
                                                            status = DataMenuHomPag.GetStatusDM(processName1);
                                                            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                                                            module.clickOnEdit();
                                                            driver.findElement(By.xpath("//a[contains(text(),'" + APModuleNonCriteria + "')]"))
                                                                    .click();
                                                            APModPag.clickBackBtn();
                                                            StZipCodInPag.clickBackBtn();
                                                            SrcInpPag.clickBackBtn();
                                                            ProdPag.clickBackBtn();
                                                            DataOriginPag.selectDataOriginField("Direct Extraction");
                                                            DataOriginPag.clickContinueButton();
                                                            ProjDashBoardPage.clickDataMenuTab();
                                                            status = DataMenuHomPag.GetStatusDM(processName1);
                                                            commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
                                                        } else
                                                        {
                                                            if ("DM_ID_357".equalsIgnoreCase(tc_Id))
                                                            {
                                                                ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                                WebElement scFlag = driver.findElement(By.xpath("//select[@name='paramVal[1][0]']"));
                                                                Select sel = new Select(scFlag);
                                                                List<WebElement> options = sel.getOptions();
                                                                commMethods.verifyboolean(options.contains("CONNEXUS_KEY"), true);
                                                            } else if ("DM_ID_360".equalsIgnoreCase(tc_Id))
                                                            {
                                                                ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                                WebElement parentScMdl5098 = driver.findElement(
                                                                        By.xpath("//div[contains(text(),'PSPS5098')]//following::div[1]/input"));
                                                                commMethods.verifyboolean(parentScMdl5098.isSelected(), true);
                                                                WebElement parentScMdl5212 = driver.findElement(
                                                                        By.xpath("//div[contains(text(),'PSPS5212')]//following::div[1]/input"));
                                                                commMethods.verifyboolean(parentScMdl5212.isSelected(), true);
                                                                WebElement parentScMdl5211 = driver.findElement(
                                                                        By.xpath("//div[contains(text(),'PSPS5211')]//following::div[1]/input"));
                                                                commMethods.verifyboolean(parentScMdl5211.isSelected(), true);
                                                            } else if ("DM_ID_649".equalsIgnoreCase(tc_Id))
                                                            {
                                                                ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                                String runbforechck = driver.findElement(By.xpath("//input[@name='chkRunBefore1']"))
                                                                        .getAttribute("disabled");
                                                                commMethods.verifyString(runbforechck, "true");
                                                            } else
                                                            {
                                                                // score model page:
                                                                ScreModlPag.selectScoreModels(scoreModel, NCPScoreModel, APModuleNonCriteria);
                                                                if (ScreModlPag.isPopUpPresent())
                                                                {
                                                                    ScreModlPag.acceptPopUp();
                                                                } else
                                                                {
                                                                    ScreModlPag.clickContinueButton();
                                                                }
                                                                if ("DM_ID_379".equalsIgnoreCase(tc_Id))
                                                                {
                                                                    String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                                                                    commMethods.verifyString(errMsg,
                                                                            "Error: You can not select NC+ models when Product is not selected BAM or BPR");
                                                                } else if ("DM_ID_204".equalsIgnoreCase(tc_Id))
                                                                {
                                                                    pageTitle = ProjDashBoardPage.getPageTitle();
                                                                    commMethods.verifyString(pageTitle,
                                                                            "Pointscore Drops Configure rules and click 'Continue.'");
                                                                } else
                                                                {
                                                                    if (!pointScoreDrop.equalsIgnoreCase("NA"))
                                                                    {
                                                                        PointScrDropPag.selectPointScoreDrop(pointScoreDrop);
                                                                        PointScrDropPag.selectModelSelections_CB(pointScoreDrop);
                                                                        PointScrDropPag.clickContinue_Btn();
                                                                    }
                                                                    pageTitle = ProjDashBoardPage.getPageTitle();
                                                                    commMethods.verifyString(pageTitle,
                                                                            "Configure Id Scan Select the ID Scan options, and click 'Continue.'");
                                                                    if ("DM_ID_508".equalsIgnoreCase(tc_Id))
                                                                    {
                                                                        ConfigIDPag.clickBackBtn();
                                                                        PointScrDropPag.clickBack_Btn();
                                                                        ScreModlPag.selectAdditionalScModels("1107,Tag,uncheck:1109,Tag,uncheck");
                                                                        Thread.sleep(2000);
                                                                        ScreModlPag.clickContinueButton();
                                                                        ScreModlPag.acceptPopUp();
                                                                        WebElement scCheck = driver
                                                                                .findElement(By.xpath(".//*[@value='1101']//preceding::input[6]"));
                                                                        commMethods.verifyboolean(scCheck.isSelected(), true);
                                                                    } else
                                                                    {
                                                                        ConfigIDPag.selectRunIdScanCheckBox(idScan);
                                                                        ConfigIDPag.selectRejectsInIdScan(idScanRejects);
                                                                        if ("DM_ID_054".equalsIgnoreCase(tc_Id))
                                                                        {
                                                                            ConfigIDPag.ClickCheckAllCB();
                                                                            ConfigIDPag.Ele_addrMutliDwellingCB.click();
                                                                            ConfigIDPag.Ele_addressMisused.click();
                                                                            ConfigIDPag.Ele_ssnNeverIssuedCB.click();
                                                                            ConfigIDPag.clickContinueButton();
                                                                            ConfigDEPag.clickContinueButton();
                                                                            DoubleChckPag.clickContinueButton();
                                                                            DMFilterConPag.clickContinueButton();
                                                                            CreditInPag.selectPullType_CB(cid_CNX);
                                                                            CreditInPag.click_Unique_CID();
                                                                            if ("SPECIFIC".equalsIgnoreCase(availableDataSets))
                                                                            {
                                                                                CreditInPag.selectSpcificDataSet();
                                                                                CreditInPag.selectDataSetType(dataSetType);
                                                                                JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                                StringTokenizer stMain = new StringTokenizer(DataSet, ",");
                                                                                while (stMain.hasMoreElements())
                                                                                {
                                                                                    js.executeScript("document.getElementById('" + stMain.nextToken()
                                                                                            + "').setAttribute('class', 'name1 active')");
                                                                                    Thread.sleep(500);
                                                                                    driver.findElement(By.xpath(".//*[@class='name1 active']"))
                                                                                            .click();
                                                                                    Thread.sleep(500);
                                                                                    CreditInPag.clickAddButton();
                                                                                }
                                                                            } else
                                                                            {
                                                                                CreditInPag.selectAvailablDataset(availableDataSets);
                                                                            }
                                                                            CreditInPag.clickContinueButton();
                                                                            DMSummPag.clickSubmitButton();
                                                                            ProjDashBoardPage.clickHomeTab();
                                                                            String ProcessName1 = ProjDashBoardPage.jobName();
                                                                            String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                                                                            commMethods.verifyString(Status, "PASS");
                                                                            ProjDashBoardPage.clickStatsView(processName1);
                                                                            driver.switchTo().frame("sb-player");
                                                                            ProjDashBoardPage.closeStatsWindow();
                                                                        } else
                                                                        {
                                                                            // ID Scan page:
                                                                            ConfigIDPag.clickContinueButton();
                                                                            // if("Direct Extraction".equalsIgnoreCase(DataOriginField)){
                                                                            pageTitle = ProjDashBoardPage.getPageTitle();
                                                                            commMethods.verifyString(pageTitle,
                                                                                    "Configure DE Standard Select the DE Standard options, and click 'Continue.'");
                                                                            ConfigDEPag.selectRunDeStandardCheckBox(deStandard);
                                                                            if ("DM_ID_184".equalsIgnoreCase(tc_Id))
                                                                            {
                                                                                String srcDefaultValue = ConfigDEPag.AllCritCodeSrcValue.getText();
                                                                                commMethods.verifyString(srcDefaultValue, "2");
                                                                                WebElement dateWithinSixMonths = ConfigDEPag.dateWithinSixMonths;
                                                                                commMethods.verifyboolean(dateWithinSixMonths.isSelected(), true);
                                                                            } else
                                                                            {
                                                                                // DE config page:
                                                                                ConfigDEPag.clickContinueButton();
                                                                                // }else {
                                                                                System.out.println(
                                                                                        "DE Standard plugin not available for the List Source Job");
                                                                                if (doublechck.equalsIgnoreCase("ON"))
                                                                                {
                                                                                    pageTitle = ProjDashBoardPage.getPageTitle();
                                                                                    commMethods.verifyString(pageTitle,
                                                                                            "Doublecheck Select Criteria below, and click 'Continue'.");
                                                                                    DoubleChckPag.clickRunDoubleChckBox();
                                                                                    DoubleChckPag.clickEditImage();
                                                                                    DoubleChckPag.selectDoubleCheckOptions();
                                                                                    DoubleChckPag.saveEditCritCodeWindow();
                                                                                    driver.switchTo().defaultContent();
                                                                                }
                                                                                // Doublecheck page:
                                                                                Thread.sleep(2000);
                                                                                DoubleChckPag.clickContinueButton();
                                                                                if ("DM_ID_604".equalsIgnoreCase(tc_Id)
                                                                                        || "DM_ID_603".equalsIgnoreCase(tc_Id))
                                                                                {
                                                                                    DMFilterConPag.clickFactActEdit();
                                                                                    Thread.sleep(2000);
                                                                                    if (Product.equalsIgnoreCase("Prescreen"))
                                                                                    {
                                                                                        WebElement addrVarCode = DMFilterConPag.CB_Reject_Address_Variance_Code;
                                                                                        commMethods.verifyboolean(addrVarCode.isSelected(), false);
                                                                                        WebElement rejFrCode = DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code;
                                                                                        commMethods.verifyboolean(rejFrCode.isSelected(), true);
                                                                                        WebElement rejAFS = DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN;
                                                                                        commMethods.verifyboolean(rejAFS.isSelected(), true);
                                                                                        WebElement cr540 = DMFilterConPag.CB_Create_540_file;
                                                                                        commMethods.verifyboolean(cr540.isSelected(), false);
                                                                                    } else
                                                                                    {
                                                                                        WebElement addrVarCode = DMFilterConPag.CB_Reject_Address_Variance_Code;
                                                                                        commMethods.verifyboolean(addrVarCode.isSelected(), false);
                                                                                        WebElement rejFrCode = DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code;
                                                                                        commMethods.verifyboolean(rejFrCode.isSelected(), false);
                                                                                        WebElement rejAFS = DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN;
                                                                                        commMethods.verifyboolean(rejAFS.isSelected(), false);
                                                                                        WebElement cr540 = DMFilterConPag.CB_Create_540_file;
                                                                                        commMethods.verifyboolean(cr540.isSelected(), true);
                                                                                    }
                                                                                } else if ("DM_ID_199".equalsIgnoreCase(tc_Id))
                                                                                {
                                                                                    String scModGridStatus = DMFilterConPag.ScModRejStatusInGrid
                                                                                            .getText().trim();
                                                                                    commMethods.verifyString(scModGridStatus, "Drop");
                                                                                } else if ("DM_ID_200".equalsIgnoreCase(tc_Id))
                                                                                {
                                                                                    String scModGridStatus = DMFilterConPag.ScModRejStatusInGrid
                                                                                            .getText().trim();
                                                                                    commMethods.verifyString(scModGridStatus, "Reject");
                                                                                } else if ("DM_ID_201".equalsIgnoreCase(tc_Id))
                                                                                {
                                                                                    String scModGridStatus = DMFilterConPag.ScModRejStatusInGrid
                                                                                            .getText().trim();
                                                                                    commMethods.verifyString(scModGridStatus, "Tag");
                                                                                } else
                                                                                {
                                                                                    if ("DM_ID_486".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(),
                                                                                                false);
                                                                                    } else if ("DM_ID_662".equalsIgnoreCase(tc_Id)
                                                                                            || "DM_ID_488".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                true);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                true);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(),
                                                                                                false);
                                                                                    } else if ("DM_ID_663".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                true);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                true);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(),
                                                                                                false);
                                                                                    } else if ("DM_ID_664".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(), true);
                                                                                    } else if ("DM_ID_665".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(), true);
                                                                                    } else if ("DM_ID_666".equalsIgnoreCase(tc_Id))
                                                                                    {
                                                                                        DMFilterConPag.clickFactActEdit();
                                                                                        Thread.sleep(2000);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Reject_Address_Variance_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                        .isSelected(),
                                                                                                false);
                                                                                        commMethods.verifyboolean(
                                                                                                DMFilterConPag.CB_Create_540_file.isSelected(),
                                                                                                false);
                                                                                    } else
                                                                                    {
                                                                                        if ("DM_ID_443".equalsIgnoreCase(tc_Id))
                                                                                        {
                                                                                            String milHdr = driver
                                                                                                    .findElement(By
                                                                                                            .xpath("//div[contains(text(),'Military Lending Act')]"))
                                                                                                    .getText();
                                                                                            commMethods.verifyString(milHdr, "Military Lending Act");
                                                                                            commMethods.verifyboolean(
                                                                                                    DMFilterConPag.mlaStatusCB.isDisplayed(), true);
                                                                                        } else
                                                                                        {
                                                                                            if ("DM_ID_414".equalsIgnoreCase(tc_Id))
                                                                                            {
                                                                                                commMethods.verifyboolean(driver
                                                                                                        .findElement(By
                                                                                                                .xpath("//a[contains(text(),'IDSCAN')]"))
                                                                                                        .isDisplayed(), true);
                                                                                            } else
                                                                                            {
                                                                                                DMFilterConPag.selectDNSdrop(DNSdrop);
                                                                                                DMFilterConPag.selectInvalidAgedrop(ageDrop);
                                                                                                if (!"NA".equalsIgnoreCase(factActOpt))
                                                                                                {
                                                                                                    DMFilterConPag.selectFactAct(factActOpt);
                                                                                                }
                                                                                                if ("DM_ID_497".equalsIgnoreCase(tc_Id))
                                                                                                {
                                                                                                    DMFilterConPag.clickFactActEdit();
                                                                                                    Thread.sleep(2000);
                                                                                                    DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code
                                                                                                            .click();
                                                                                                    DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN
                                                                                                            .click();
                                                                                                    DMFilterConPag.click_Save_button_Fact_Act();
                                                                                                    commMethods.verifyboolean(
                                                                                                            DMFilterConPag.CB_DNSdrop.isSelected(),
                                                                                                            false);
                                                                                                    commMethods.verifyboolean(
                                                                                                            DMFilterConPag.CB_InvalidBlankAgeDrop
                                                                                                                    .isSelected(),
                                                                                                            false);
                                                                                                } else if ("DM_ID_123".equalsIgnoreCase(tc_Id))
                                                                                                {
                                                                                                    DMFilterConPag.clickFactActEdit();
                                                                                                    Thread.sleep(2000);
                                                                                                    DMFilterConPag.click540file();
                                                                                                    DMFilterConPag.click_Save_button_Fact_Act();
                                                                                                    DMFilterConPag.clickContinueButton();
                                                                                                    CreditInPag.selectPullType_CB(cid_CNX);
                                                                                                    CreditInPag.click_Unique_CID();
                                                                                                    if ("SPECIFIC"
                                                                                                            .equalsIgnoreCase(availableDataSets))
                                                                                                    {
                                                                                                        CreditInPag.selectSpcificDataSet();
                                                                                                        CreditInPag.selectDataSetType(dataSetType);
                                                                                                        JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                                                        StringTokenizer stMain = new StringTokenizer(
                                                                                                                DataSet, ",");
                                                                                                        while (stMain.hasMoreElements())
                                                                                                        {
                                                                                                            js.executeScript(
                                                                                                                    "document.getElementById('"
                                                                                                                            + stMain.nextToken()
                                                                                                                            + "').setAttribute('class', 'name1 active')");
                                                                                                            Thread.sleep(500);
                                                                                                            driver.findElement(By
                                                                                                                    .xpath(".//*[@class='name1 active']"))
                                                                                                                    .click();
                                                                                                            Thread.sleep(500);
                                                                                                            CreditInPag.clickAddButton();
                                                                                                        }
                                                                                                    } else
                                                                                                    {
                                                                                                        CreditInPag.selectAvailablDataset(
                                                                                                                availableDataSets);
                                                                                                    }
                                                                                                    CreditInPag.clickContinueButton();
                                                                                                    DMSummPag.clickSubmitButton();
                                                                                                    ProjDashBoardPage.clickHomeTab();
                                                                                                    String ProcessName1 = ProjDashBoardPage.jobName();
                                                                                                    String Status = ProjDashBoardPage
                                                                                                            .verifyProcess(ProcessName1);
                                                                                                    commMethods.verifyString(Status, "PASS");
                                                                                                    ProjDashBoardPage.clickStatsView(processName1);
                                                                                                    driver.switchTo().frame("sb-player");
                                                                                                    Thread.sleep(2000);
                                                                                                    String factActTble = DmStatView.getFactActTble();
                                                                                                    commMethods.verifyboolean(factActTble
                                                                                                            .endsWith("_DM_GPLOAD_Fact_Act"), true);
                                                                                                    ProjDashBoardPage.closeStatsWindow();
                                                                                                } else
                                                                                                {
                                                                                                    DMFilterConPag.selectInvalidDrop(invalidDrop);
                                                                                                    DMFilterConPag.selectTestFileDrop(testFileDrop);
                                                                                                    if ("DM_ID_502".equalsIgnoreCase(tc_Id))
                                                                                                    {
                                                                                                        Thread.sleep(2000);
                                                                                                        DMFilterConPag.clickedSaveBtn();
                                                                                                        driver.findElement(By
                                                                                                                .xpath("//a[contains(text(),'CMDL1107')]"))
                                                                                                                .click();
                                                                                                        driver.findElement(By
                                                                                                                .xpath("//input[@name='chkRunBefore0']"))
                                                                                                                .click();
                                                                                                        ScreModlPag.clickContinueButton();
                                                                                                        String alertMsg = driver
                                                                                                                .findElement(By
                                                                                                                        .xpath(".//*[@id='sb-player']/div/h1"))
                                                                                                                .getText().trim();
                                                                                                        commMethods.verifyString(alertMsg,
                                                                                                                "Changing Score Models will cause all Model ordering to be reset");
                                                                                                    } else
                                                                                                    {
                                                                                                        // Filter Configuration Page:
                                                                                                        DMFilterConPag.clickMLAStatusCB1(mla);
                                                                                                        DMFilterConPag.clickContinueButton();
                                                                                                        if ("DM_ID_560".equalsIgnoreCase(tc_Id))
                                                                                                        {
                                                                                                            CreditInPag.clickContinueButton();
                                                                                                            String errMsg = driver
                                                                                                                    .findElement(By
                                                                                                                            .xpath(".//*[@id='textMsg']"))
                                                                                                                    .getText();
                                                                                                            commMethods.verifyString(errMsg,
                                                                                                                    "Please select atleast one dataset");
                                                                                                        } else if ("DM_ID_202"
                                                                                                                .equalsIgnoreCase(tc_Id))
                                                                                                        {
                                                                                                            WebElement uniqueCID = CreditInPag.CB_Unique_CID;
                                                                                                            commMethods.verifyboolean(
                                                                                                                    uniqueCID.isSelected(), true);
                                                                                                        } else
                                                                                                        {
                                                                                                            if ("DM_ID_358".equalsIgnoreCase(tc_Id))
                                                                                                            {
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.CB_Unique_CID
                                                                                                                                        .isEnabled(),
                                                                                                                                false);
                                                                                                                if ("SPECIFIC".equalsIgnoreCase(
                                                                                                                        availableDataSets))
                                                                                                                {
                                                                                                                    CreditInPag
                                                                                                                            .selectSpcificDataSet();
                                                                                                                    CreditInPag.selectDataSetType(
                                                                                                                            dataSetType);
                                                                                                                    JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                                                                    StringTokenizer stMain = new StringTokenizer(
                                                                                                                            DataSet, ",");
                                                                                                                    while (stMain.hasMoreElements())
                                                                                                                    {
                                                                                                                        js.executeScript(
                                                                                                                                "document.getElementById('"
                                                                                                                                        + stMain.nextToken()
                                                                                                                                        + "').setAttribute('class', 'name1 active')");
                                                                                                                        Thread.sleep(500);
                                                                                                                        driver.findElement(By
                                                                                                                                .xpath(".//*[@class='name1 active']"))
                                                                                                                                .click();
                                                                                                                        Thread.sleep(500);
                                                                                                                        CreditInPag.clickAddButton();
                                                                                                                    }
                                                                                                                }
                                                                                                                CreditInPag.clickContinueButton();
                                                                                                                DMSummPag.clickViewXMLbtn();
                                                                                                                String xmlContent = driver
                                                                                                                        .findElement(By
                                                                                                                                .xpath(".//*[@id='xmlArea']/pre"))
                                                                                                                        .getText();
                                                                                                                String xmlString = xmlContent
                                                                                                                        .replaceAll("[\\t\\n\\r]",
                                                                                                                                "");
                                                                                                                xmlString = xmlString
                                                                                                                        .replaceAll("\\s", "");
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                xmlString.contains(
                                                                                                                                        "ciducnx.dpx"),
                                                                                                                                true);
                                                                                                            } else if ("DM_ID_301"
                                                                                                                    .equalsIgnoreCase(tc_Id))
                                                                                                            {
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCID
                                                                                                                                        .isDisplayed(),
                                                                                                                                true);
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCNX
                                                                                                                                        .isEnabled(),
                                                                                                                                false);
                                                                                                            } else if ("DM_ID_303"
                                                                                                                    .equalsIgnoreCase(tc_Id))
                                                                                                            {
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCID
                                                                                                                                        .isEnabled(),
                                                                                                                                true);
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCNX
                                                                                                                                        .isEnabled(),
                                                                                                                                true);
                                                                                                                CreditInPag.pullByCNX.click();
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCNX
                                                                                                                                        .isSelected(),
                                                                                                                                true);
                                                                                                            } else if ("DM_ID_306"
                                                                                                                    .equalsIgnoreCase(tc_Id))
                                                                                                            {
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCID
                                                                                                                                        .isSelected(),
                                                                                                                                true);
                                                                                                                commMethods
                                                                                                                        .verifyboolean(
                                                                                                                                CreditInPag.pullByCNX
                                                                                                                                        .isEnabled(),
                                                                                                                                false);
                                                                                                            } else
                                                                                                            {
                                                                                                                CreditInPag
                                                                                                                        .selectPullType_CB(cid_CNX);
                                                                                                                CreditInPag.click_Unique_CID();
                                                                                                                if ("SPECIFIC".equalsIgnoreCase(
                                                                                                                        availableDataSets))
                                                                                                                {
                                                                                                                    CreditInPag
                                                                                                                            .selectSpcificDataSet();
                                                                                                                    CreditInPag.selectDataSetType(
                                                                                                                            dataSetType);
                                                                                                                    JavascriptExecutor js = (JavascriptExecutor) driver;
                                                                                                                    StringTokenizer stMain = new StringTokenizer(
                                                                                                                            DataSet, ",");
                                                                                                                    while (stMain.hasMoreElements())
                                                                                                                    {
                                                                                                                        js.executeScript(
                                                                                                                                "document.getElementById('"
                                                                                                                                        + stMain.nextToken()
                                                                                                                                        + "').setAttribute('class', 'name1 active')");
                                                                                                                        Thread.sleep(500);
                                                                                                                        driver.findElement(By
                                                                                                                                .xpath(".//*[@class='name1 active']"))
                                                                                                                                .click();
                                                                                                                        Thread.sleep(500);
                                                                                                                        CreditInPag.clickAddButton();
                                                                                                                    }
                                                                                                                } else
                                                                                                                {
                                                                                                                    CreditInPag.selectAvailablDataset(
                                                                                                                            availableDataSets);
                                                                                                                }
                                                                                                                if ("DM_ID_418"
                                                                                                                        .equalsIgnoreCase(tc_Id)
                                                                                                                        || "DM_ID_419"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id)
                                                                                                                        || "DM_ID_420"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                {
                                                                                                                    commMethods.verifyboolean(
                                                                                                                            CreditInPag.Rad_Use_recent_dataset
                                                                                                                                    .isEnabled(),
                                                                                                                            false);
                                                                                                                    commMethods.verifyboolean(
                                                                                                                            CreditInPag.RecentWklyDatast_rbtn
                                                                                                                                    .isSelected(),
                                                                                                                            true);
                                                                                                                    CreditInPag.clickContinueButton();
                                                                                                                    pageTitle = ProjDashBoardPage
                                                                                                                            .getPageTitle();
                                                                                                                    commMethods.verifyString(
                                                                                                                            pageTitle,
                                                                                                                            "Summary: Data Menu\nReview the information below, and then click 'Submit' or 'Back'.");
                                                                                                                } else
                                                                                                                {
                                                                                                                    // Credit Input Page:
                                                                                                                    CreditInPag.clickContinueButton();
                                                                                                                    if ("DM_ID_622"
                                                                                                                            .equalsIgnoreCase(tc_Id)
                                                                                                                            || "DM_ID_462"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id)
                                                                                                                            || "DM_ID_464"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id)
                                                                                                                            || "DM_ID_466"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id)
                                                                                                                            || "DM_ID_468"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id))
                                                                                                                    {
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickDataMenuTab();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.initializeDriver(
                                                                                                                                driver);
                                                                                                                        module.selectDuplicate1();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.selectSummary();
                                                                                                                        DMSummPag.clickSubmitButton();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                    } else if ("DM_ID_550"
                                                                                                                            .equalsIgnoreCase(tc_Id)
                                                                                                                            || "DM_ID_541"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id))
                                                                                                                    {
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickDataMenuTab();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.initializeDriver(
                                                                                                                                driver);
                                                                                                                        module.selectSummary();
                                                                                                                        DMSummPag.clickSubmitButton();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.initializeDriver(
                                                                                                                                driver);
                                                                                                                        module.selectDuplicate1();
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickHomeTab();
                                                                                                                        String ProcessName1 = ProjDashBoardPage
                                                                                                                                .jobName();
                                                                                                                        String Status = ProjDashBoardPage
                                                                                                                                .verifyProcess(
                                                                                                                                        ProcessName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                Status, "PASS");
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickStatsView(
                                                                                                                                        processName1);
                                                                                                                        driver.switchTo()
                                                                                                                                .frame("sb-player");
                                                                                                                        String sampleIndexTableNameDM = DmStatView
                                                                                                                                .getSampleIndexTableNameDM();
                                                                                                                        Long sampleIndexTableCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        sampleIndexTableNameDM);
                                                                                                                        Long sampleIndexTableCountDMUI = DmStatView
                                                                                                                                .getSampleIndexTableCountDM();
                                                                                                                        commMethods.verifyLong(
                                                                                                                                sampleIndexTableCountDMUI,
                                                                                                                                sampleIndexTableCountDMGP);
                                                                                                                        String stepFlagTableNameDM = DmStatView
                                                                                                                                .getStepFlagTableNameDM();
                                                                                                                        Long stepFlagTableCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        stepFlagTableNameDM);
                                                                                                                        Long stepFlagTableCountDMUI = DmStatView
                                                                                                                                .getStepFlagTableCountDM();
                                                                                                                        commMethods.verifyLong(
                                                                                                                                stepFlagTableCountDMUI,
                                                                                                                                stepFlagTableCountDMGP);
                                                                                                                        String scModel5213tblName = DmStatView
                                                                                                                                .getScModelTbleName5213DM();
                                                                                                                        Long scModel5213tbleCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        scModel5213tblName);
                                                                                                                        Long scModel5213tbleCountDMUI = DmStatView
                                                                                                                                .getScModel5213Count();
                                                                                                                        commMethods.verifyLong(
                                                                                                                                scModel5213tbleCountDMUI,
                                                                                                                                scModel5213tbleCountDMGP);
                                                                                                                        String inqPostTbleNameDM = DmStatView
                                                                                                                                .getInqPostTableNameDM();
                                                                                                                        Long inqPostTbleCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        inqPostTbleNameDM);
                                                                                                                        Long inqPostTbleCountDMUI = DmStatView
                                                                                                                                .getInqPostTableCountDM();
                                                                                                                        commMethods.verifyLong(
                                                                                                                                inqPostTbleCountDMUI,
                                                                                                                                inqPostTbleCountDMGP);
                                                                                                                        String lcrFusionFrndlyModName = DmStatView
                                                                                                                                .getFusionFrndlyModname();
                                                                                                                        Long lcrFusionFrndlyModTblCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        lcrFusionFrndlyModName);
                                                                                                                        Long lcrFusionFrndlyModTblCountDMUI = DmStatView
                                                                                                                                .getFusionFrndlyModTbleCount();
                                                                                                                        commMethods.verifyLong(
                                                                                                                                lcrFusionFrndlyModTblCountDMUI,
                                                                                                                                lcrFusionFrndlyModTblCountDMGP);
                                                                                                                        String HeaderTableNameDM = DmStatView
                                                                                                                                .getHeaderTableNameDM();
                                                                                                                        Long HeaderTableCountDMUI = DmStatView
                                                                                                                                .getHeaderTableCountDM();
                                                                                                                        Long HeaderTableCountDMGP = ProjDashBoardPage
                                                                                                                                .getRecordsFromGP(
                                                                                                                                        HeaderTableNameDM);
                                                                                                                        commMethods.verifyLong(
                                                                                                                                HeaderTableCountDMUI,
                                                                                                                                HeaderTableCountDMGP);
                                                                                                                    } else if ("DM_ID_212"
                                                                                                                            .equalsIgnoreCase(tc_Id))
                                                                                                                    {
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickDataMenuTab();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.initializeDriver(
                                                                                                                                driver);
                                                                                                                        module.selectEdit();
                                                                                                                        driver.findElement(By
                                                                                                                                .xpath("//a[contains(text(),'"
                                                                                                                                        + APModuleNonCriteria
                                                                                                                                        + "')]"))
                                                                                                                                .click();
                                                                                                                        APModPag.clickBackBtn();
                                                                                                                        StZipCodInPag.clickBackBtn();
                                                                                                                        ProdPag.selectProductField(
                                                                                                                                "Prescreen");
                                                                                                                        ProdPag.clickContinueButton();
                                                                                                                        ProjDashBoardPage
                                                                                                                                .clickDataMenuTab();
                                                                                                                        status = DataMenuHomPag
                                                                                                                                .GetStatusDM(processName1);
                                                                                                                        commMethods.verifyString(
                                                                                                                                StatusEnum.READY
                                                                                                                                        .name(),
                                                                                                                                status.trim());
                                                                                                                        module.selectSummary();
                                                                                                                        DMSummPag.clickSubmitButton();
                                                                                                                        String errMsg = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath(".//*[@id='contentArea']/div[3]/div[1]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                errMsg,
                                                                                                                                "Error: You can not select NC+ models when Product is not selected BAM or BPR.");
                                                                                                                    } else if ("DM_ID_049"
                                                                                                                            .equalsIgnoreCase(tc_Id))
                                                                                                                    {
                                                                                                                        String sumDataOrigin = DMSummPag.DataOrigin
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumDataOrigin,
                                                                                                                                DataOriginField);
                                                                                                                        String sumProduct = DMSummPag.Product
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumProduct,
                                                                                                                                "PRESCREEN");
                                                                                                                        String sumCredInput = DMSummPag.CreditInput
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumCredInput,
                                                                                                                                DataSet);
                                                                                                                        String sumUniCIDindex = DMSummPag.UniqueCIDindex
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumUniCIDindex, "N");
                                                                                                                        String sumSMprocess = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//td[contains(text(),'"
                                                                                                                                                + smProcess
                                                                                                                                                + "')]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumSMprocess,
                                                                                                                                smProcess);
                                                                                                                        String sumData = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//td[contains(text(),'"
                                                                                                                                                + dataField
                                                                                                                                                + "')]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumData, dataField);
                                                                                                                        String sumScoreModel = DMSummPag.ScoreModel
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumScoreModel,
                                                                                                                                DMSummPag
                                                                                                                                        .splitScoreModelNo(
                                                                                                                                                scoreModel));
                                                                                                                        String sumFusfrnldyMod = DMSummPag.FUSION_FRIENDLY_MOD
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumFusfrnldyMod,
                                                                                                                                APModuleNonCriteria);
                                                                                                                        String sumNoPerAccCode = DMSummPag.NoPerAccCode
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumNoPerAccCode,
                                                                                                                                NumPerAccCode);
                                                                                                                        String sumNoPerRejCode = DMSummPag.NoPerRejCode
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumNoPerRejCode,
                                                                                                                                NumPerRejCode);
                                                                                                                        String sumHoldAddMoveSt = DMSummPag.HoldAddMoveSt
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumHoldAddMoveSt,
                                                                                                                                "N");
                                                                                                                        String sumDNSdrop = DMSummPag.DNSDrop
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumDNSdrop, "N");
                                                                                                                        String invAgeDrop = DMSummPag.InvAgeDrop
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                invAgeDrop, "Y");
                                                                                                                        String invStreetAddr = DMSummPag.InvStreetAddress
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                invStreetAddr, "N");
                                                                                                                        String create540File = DMSummPag.Create540File
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                create540File, "N");
                                                                                                                        DMSummPag.clickViewXMLbtn();
                                                                                                                        String xmlTitle = DMSummPag
                                                                                                                                .getJobXMLhdr();
                                                                                                                        commMethods.verifyString(
                                                                                                                                xmlTitle, "JOB XML");
                                                                                                                    } else if ("DM_ID_605"
                                                                                                                            .equalsIgnoreCase(tc_Id))
                                                                                                                    {
                                                                                                                        String dataOrignSum = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//label[contains(text(),'Data Origin')]//following::td[contains(text(),'Pre-Select')]"))
                                                                                                                                .getText().trim();
                                                                                                                        commMethods.verifyString(
                                                                                                                                dataOrignSum,
                                                                                                                                "Pre-Select");
                                                                                                                        String sumMale = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//label[contains(text(),'Male:')]//following::td[1]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumMale, "Y");
                                                                                                                        String sumHisName = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//label[contains(text(),'Hispanic Names Only:')]//following::td[1]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumHisName, "N");
                                                                                                                        String sumFemale = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//label[contains(text(),'Female:')]//following::td[1]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumFemale, "N");
                                                                                                                        String sumNeutral = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath("//label[contains(text(),'Neutral:')]//following::td[1]"))
                                                                                                                                .getText();
                                                                                                                        commMethods.verifyString(
                                                                                                                                sumNeutral, "N");
                                                                                                                    } else if ("DM_ID_156"
                                                                                                                            .equalsIgnoreCase(tc_Id))
                                                                                                                    {
                                                                                                                        DMSummPag.clickViewXMLbtn();
                                                                                                                        String xmlContent = driver
                                                                                                                                .findElement(By
                                                                                                                                        .xpath(".//*[@id='xmlArea']/pre"))
                                                                                                                                .getText();
                                                                                                                        String xmlString = xmlContent
                                                                                                                                .replaceAll(
                                                                                                                                        "[\\t\\n\\r]",
                                                                                                                                        "");
                                                                                                                        xmlString = xmlString
                                                                                                                                .replaceAll("\\s",
                                                                                                                                        "");
                                                                                                                        commMethods.verifyboolean(
                                                                                                                                xmlString.contains(
                                                                                                                                        "<autoPilotLibType>DEV</autoPilotLibType>"),
                                                                                                                                true);
                                                                                                                    } else
                                                                                                                    {
                                                                                                                        if ("DM_ID_459"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            String numAccSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'Number per Accept Code')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    numAccSum,
                                                                                                                                    NumPerAccCode);
                                                                                                                            String numRejSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'Number per Reject Code')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    numRejSum,
                                                                                                                                    NumPerRejCode);
                                                                                                                        } else if ("DM_ID_454"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            String holdMoveSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'Hold for additional data append via Move Statements:')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    holdMoveSum, "N");
                                                                                                                        } else if ("DM_ID_455"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            String holdMoveSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'Hold for additional data append via Move Statements:')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    holdMoveSum, "Y");
                                                                                                                        } else if ("DM_ID_415"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            String idScanSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//td[contains(text(),'IDS')]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    idScanSum, "IDS");
                                                                                                                            String idScanTypeMod = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//td[contains(text(),'Identity Scan')]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    idScanTypeMod,
                                                                                                                                    "Identity Scan");
                                                                                                                            String idScanRejSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'ID Scan:')]//following::td[2]"))
                                                                                                                                    .getText().trim();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    idScanRejSum,
                                                                                                                                    "Tag");
                                                                                                                            String factActSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//span[contains(text(),'Create 540 File')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    factActSum, "N");
                                                                                                                            String ravcSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//span[contains(text(),'Reject Address Variance')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    ravcSum, "N");
                                                                                                                            String rfcSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//span[contains(text(),'Reject Fraud Code')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    rfcSum, "Y");
                                                                                                                            String rejASF = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//span[contains(text(),'Reject AFS/Alert Data')]//following::td[1]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    rejASF, "Y");
                                                                                                                        } else if ("DM_ID_652"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            WebElement fileName = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//th[contains(text(),'File Name')]//following::tr[1]/td[2]/a"));
                                                                                                                            commMethods.verifyboolean(
                                                                                                                                    fileName.isDisplayed(),
                                                                                                                                    true);
                                                                                                                            String rejSum = driver
                                                                                                                                    .findElement(By
                                                                                                                                            .xpath("//label[contains(text(),'Rejects Records:')]//following::td[3]"))
                                                                                                                                    .getText();
                                                                                                                            commMethods.verifyString(
                                                                                                                                    rejSum,
                                                                                                                                    "Rejects: Reject");
                                                                                                                        } else if ("DM_ID_654"
                                                                                                                                .equalsIgnoreCase(
                                                                                                                                        tc_Id))
                                                                                                                        {
                                                                                                                            ProjDashBoardPage
                                                                                                                                    .clickDataMenuTab();
                                                                                                                            module.initializeDriver(
                                                                                                                                    driver);
                                                                                                                            module.clickOnEdit();
                                                                                                                            driver.findElement(By
                                                                                                                                    .xpath("//a[contains(text(),'"
                                                                                                                                            + APModuleNonCriteria
                                                                                                                                            + "')]"))
                                                                                                                                    .click();
                                                                                                                            APModPag.clickAPmodRemoveButton();
                                                                                                                            APModPag.clickContinueButton();
                                                                                                                            driver.findElement(By
                                                                                                                                    .xpath("(//a[contains(text(),'OK')])[2]"))
                                                                                                                                    .click();
                                                                                                                            ScreModlPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            ConfigIDPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            ConfigDEPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            DoubleChckPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            DMFilterConPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            CreditInPag
                                                                                                                                    .clickContinueButton();
                                                                                                                            DMSummPag.isAuditInSum();
                                                                                                                        } else
                                                                                                                        {
                                                                                                                            // Summary Page:
                                                                                                                            DMSummPag
                                                                                                                                    .clickSubmitButton();
                                                                                                                            if ("DM_ID_356"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id))
                                                                                                                            {
                                                                                                                                System.out.println(
                                                                                                                                        "Its an enhancement..its going to add an error message here !!!");
                                                                                                                            } else if ("DM_ID_452"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id)
                                                                                                                                    || "DM_ID_653"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                            {
                                                                                                                                module.initializeDriver(
                                                                                                                                        driver);
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                            } else if ("DM_ID_499"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id))
                                                                                                                            {
                                                                                                                                module.initializeDriver(
                                                                                                                                        driver);
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                                module.selectDuplicate1();
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.READY
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                                module.clickOnEdit();
                                                                                                                                driver.findElement(By
                                                                                                                                        .xpath("//a[contains(text(),'"
                                                                                                                                                + APModuleNonCriteria
                                                                                                                                                + "')]"))
                                                                                                                                        .click();
                                                                                                                                APModPag.selectAPModuleNonCriteria(
                                                                                                                                        "JXH_DIMENSIONS");
                                                                                                                                APModPag.clickContinueButton();
                                                                                                                                driver.findElement(By
                                                                                                                                        .xpath("(//a[contains(text(),'OK')])[2]"))
                                                                                                                                        .click();
                                                                                                                                ModOutptPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                ScreModlPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                ConfigIDPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                ConfigDEPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                DoubleChckPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                DMFilterConPag
                                                                                                                                        .clickContinueButton();
                                                                                                                                commMethods
                                                                                                                                        .verifyboolean(
                                                                                                                                                CreditInPag.dimensionsChkBox
                                                                                                                                                        .isEnabled(),
                                                                                                                                                false);
                                                                                                                            } else if ("DM_ID_532"
                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                            tc_Id)
                                                                                                                                    || "DM_ID_523"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                            {
                                                                                                                                module.initializeDriver(
                                                                                                                                        driver);
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                                module.selectDuplicate1();
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.READY
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                                module.selectSummary();
                                                                                                                                DMSummPag
                                                                                                                                        .clickSubmitButton();
                                                                                                                                status = DataMenuHomPag
                                                                                                                                        .GetStatusDM(processName1);
                                                                                                                                commMethods
                                                                                                                                        .verifyString(
                                                                                                                                                StatusEnum.SUBMITTED
                                                                                                                                                        .name(),
                                                                                                                                                status.trim());
                                                                                                                            } else
                                                                                                                            {
                                                                                                                                ProjDashBoardPage
                                                                                                                                        .clickHomeTab();
                                                                                                                                if ("DM_ID_037"
                                                                                                                                        .equalsIgnoreCase(
                                                                                                                                                tc_Id)
                                                                                                                                        || "DM_ID_047"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_060"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_203"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_274"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_620"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_618"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_619"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_567"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_566"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_565"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_557"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id)
                                                                                                                                        || "DM_ID_602"
                                                                                                                                                .equalsIgnoreCase(
                                                                                                                                                        tc_Id))
                                                                                                                                {
                                                                                                                                    String ProcessName1 = ProjDashBoardPage
                                                                                                                                            .jobName();
                                                                                                                                    String Status = ProjDashBoardPage
                                                                                                                                            .verifyProcess(
                                                                                                                                                    ProcessName1);
                                                                                                                                    commMethods
                                                                                                                                            .verifyString(
                                                                                                                                                    Status,
                                                                                                                                                    "PASS");
                                                                                                                                } else if ("DM_ID_041"
                                                                                                                                        .equalsIgnoreCase(
                                                                                                                                                tc_Id))
                                                                                                                                {
                                                                                                                                    String ProcessName1 = ProjDashBoardPage
                                                                                                                                            .jobName();
                                                                                                                                    String Status = ProjDashBoardPage
                                                                                                                                            .verifyProcess(
                                                                                                                                                    ProcessName1);
                                                                                                                                    commMethods
                                                                                                                                            .verifyString(
                                                                                                                                                    Status,
                                                                                                                                                    "PASS");
                                                                                                                                    ProjDashBoardPage
                                                                                                                                            .clickStatsView(
                                                                                                                                                    processName1);
                                                                                                                                    driver.switchTo()
                                                                                                                                            .frame("sb-player");
                                                                                                                                    String HeaderTableNameDM = DmStatView
                                                                                                                                            .getHeaderTableNameDM();
                                                                                                                                    Long critRejCountDMUI = DmStatView
                                                                                                                                            .getCritRejCountDM();
                                                                                                                                    Long critRejCountDMGP = DmStatView
                                                                                                                                            .getRecordsFromGP(
                                                                                                                                                    HeaderTableNameDM,
                                                                                                                                                    "fail_code",
                                                                                                                                                    "RJ");
                                                                                                                                    commMethods
                                                                                                                                            .verifyLong(
                                                                                                                                                    critRejCountDMUI,
                                                                                                                                                    critRejCountDMGP);
                                                                                                                                    String ageCritTbleName = DmStatView
                                                                                                                                            .getAGECRITtbleNameDM();
                                                                                                                                    Long ageCritDp_Seq_Num = DmStatView
                                                                                                                                            .getDp_Seq_NumForTbles(
                                                                                                                                                    ageCritTbleName);
                                                                                                                                    Long hdrDp_Seq_num = DmStatView
                                                                                                                                            .getDp_Seq_NumForTbles(
                                                                                                                                                    HeaderTableNameDM);
                                                                                                                                    commMethods
                                                                                                                                            .verifyLong(
                                                                                                                                                    ageCritDp_Seq_Num,
                                                                                                                                                    hdrDp_Seq_num);
                                                                                                                                } else
                                                                                                                                {
                                                                                                                                    /*String ProcessName1 = ProjDashBoardPage
                                                                                                                                            .jobName();
                                                                                                                                    String Status = ProjDashBoardPage
                                                                                                                                            .verifyProcess(
                                                                                                                                                    ProcessName1);
                                                                                                                                    commMethods
                                                                                                                                            .verifyString(
                                                                                                                                                    Status,
                                                                                                                                                    "PASS");*/
                                                                                                                                    if ("DM_ID_114"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                                    {
                                                                                                                                        driver.findElement(
                                                                                                                                                By.xpath(
                                                                                                                                                        "//td[contains(text(),'"
                                                                                                                                                                + procId
                                                                                                                                                                + "')]//parent::tr/td[2]/img"))
                                                                                                                                                .click();
                                                                                                                                        Thread.sleep(
                                                                                                                                                2000);
                                                                                                                                        driver.findElement(
                                                                                                                                                By.xpath(
                                                                                                                                                        "//td[contains(text(),'"
                                                                                                                                                                + procId
                                                                                                                                                                + "')]//parent::tr[1]//following::tr[1]/td[3]/img"))
                                                                                                                                                .click();
                                                                                                                                        Thread.sleep(
                                                                                                                                                2000);
                                                                                                                                        boolean sfload = ProjDashBoardPage
                                                                                                                                                .getWorkItemSF_LOAD(
                                                                                                                                                        procId);
                                                                                                                                        commMethods
                                                                                                                                                .verifyboolean(
                                                                                                                                                        sfload,
                                                                                                                                                        true);
                                                                                                                                    } else if ("DM_ID_597"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                                    {
                                                                                                                                        driver.findElement(
                                                                                                                                                By.xpath(
                                                                                                                                                        "//td[contains(text(),'"
                                                                                                                                                                + procId
                                                                                                                                                                + "')]//parent::tr/td[2]/img"))
                                                                                                                                                .click();
                                                                                                                                        Thread.sleep(
                                                                                                                                                2000);
                                                                                                                                        driver.findElement(
                                                                                                                                                By.xpath(
                                                                                                                                                        "//td[contains(text(),'"
                                                                                                                                                                + procId
                                                                                                                                                                + "')]//parent::tr[1]//following::tr[1]/td[3]/img"))
                                                                                                                                                .click();
                                                                                                                                        Thread.sleep(
                                                                                                                                                2000);
                                                                                                                                        WebElement preselect_gpexport = driver
                                                                                                                                                .findElement(
                                                                                                                                                        By.xpath(
                                                                                                                                                                "//td[contains(text(),'"
                                                                                                                                                                        + procId
                                                                                                                                                                        + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'PRESELECT_GPEXPORT')]"));
                                                                                                                                        commMethods
                                                                                                                                                .verifyboolean(
                                                                                                                                                        preselect_gpexport
                                                                                                                                                                .isDisplayed(),
                                                                                                                                                        true);

                                                                                                                                        ProjDashBoardPage
                                                                                                                                                .clickStatsView(
                                                                                                                                                        processName1);
                                                                                                                                        driver.switchTo()
                                                                                                                                                .frame("sb-player");
                                                                                                                                        String srcFileLoc = DmStatView
                                                                                                                                                .getSrcFileLocation();
                                                                                                                                        String srcFile = srcFileLoc
                                                                                                                                                .replace(
                                                                                                                                                        "\n",
                                                                                                                                                        "");
                                                                                                                                        String inputFilePath = driver
                                                                                                                                                .findElement(
                                                                                                                                                        By.xpath(
                                                                                                                                                                "//div[contains(text(),'PRESELECT_GPEXPORT.csv')]"))
                                                                                                                                                .getText();
                                                                                                                                        commMethods
                                                                                                                                                .verifyString(
                                                                                                                                                        srcFile,
                                                                                                                                                        inputFilePath);
                                                                                                                                        DmStatView
                                                                                                                                                .clickJetJobXml();
                                                                                                                                        driver.switchTo()
                                                                                                                                                .frame("sb-player");
                                                                                                                                        commMethods
                                                                                                                                                .verifyString(
                                                                                                                                                        DmStatView
                                                                                                                                                                .jobXmlTitle(),
                                                                                                                                                        "JET JOB XML");
                                                                                                                                    } else if ("DM_ID_116"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                                    {
                                                                                                                                        ProjDashBoardPage
                                                                                                                                                .clickStatsView(
                                                                                                                                                        processName1);
                                                                                                                                        driver.switchTo()
                                                                                                                                                .frame("sb-player");
                                                                                                                                        String sampleIndexTableNameDM = DmStatView
                                                                                                                                                .getSampleIndexTableNameDM();
                                                                                                                                        Long sampleIndexTableCountDMUI = DmStatView
                                                                                                                                                .getSampleIndexTableCountDM();
                                                                                                                                        Long sampleIndexCIDcountDMGP = DmStatView
                                                                                                                                                .getRecordsFromGP2(
                                                                                                                                                        sampleIndexTableNameDM,
                                                                                                                                                        "cid");
                                                                                                                                        Long sampleIndexDpSeqcountDMGP = DmStatView
                                                                                                                                                .getRecordsFromGP2(
                                                                                                                                                        sampleIndexTableNameDM,
                                                                                                                                                        "dp_sequence_num");
                                                                                                                                        commMethods
                                                                                                                                                .verifyLong(
                                                                                                                                                        sampleIndexTableCountDMUI,
                                                                                                                                                        sampleIndexDpSeqcountDMGP);
                                                                                                                                        commMethods
                                                                                                                                                .verifyLong(
                                                                                                                                                        sampleIndexTableCountDMUI,
                                                                                                                                                        sampleIndexCIDcountDMGP);
                                                                                                                                    } else if ("DM_ID_168"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                                    {
                                                                                                                                        ProjDashBoardPage
                                                                                                                                                .viewStats(
                                                                                                                                                        processName1);
                                                                                                                                        String HeaderTableNameDM = DmStatView
                                                                                                                                                .getHeaderTableNameDM();
                                                                                                                                        Long HeaderTableCountDMUI = ProjDashBoardPage
                                                                                                                                                .recWithoutComma(
                                                                                                                                                        DmStatView
                                                                                                                                                                .getHeaderTableCountDM());
                                                                                                                                        Long HeaderTableCountDMGP = ProjDashBoardPage
                                                                                                                                                .getRecordsFromGP(
                                                                                                                                                        HeaderTableNameDM);
                                                                                                                                        commMethods
                                                                                                                                                .verifyLong(
                                                                                                                                                        HeaderTableCountDMUI,
                                                                                                                                                        HeaderTableCountDMGP);
                                                                                                                                        DmStatView
                                                                                                                                                .clickJetJobXml();
                                                                                                                                        /*
                                                                                                                                         * driver.
                                                                                                                                         * switchTo()
                                                                                                                                         * .frame(
                                                                                                                                         * "sb-player"
                                                                                                                                         * );
                                                                                                                                         */
                                                                                                                                        pageTitle = ProjDashBoardPage
                                                                                                                                                .getPageTitle();
                                                                                                                                        commMethods
                                                                                                                                                .verifyString(
                                                                                                                                                        pageTitle,
                                                                                                                                                        "JET JOB XML");
                                                                                                                                    } else if ("DM_ID_046"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id))
                                                                                                                                    {
                                                                                                                                        ProjDashBoardPage
                                                                                                                                                .viewStats(
                                                                                                                                                        processName1);
                                                                                                                                        String scModel1070tble = DmStatView
                                                                                                                                                .get1070Tble();
                                                                                                                                        String scModel1174tble = DmStatView
                                                                                                                                                .get1174Tble();
                                                                                                                                        Long scModel1070tbleCountGP = DmStatView
                                                                                                                                                .getGpTbleCount(
                                                                                                                                                        scModel1070tble);
                                                                                                                                        Long scModel1070tbleCountUI = DmStatView
                                                                                                                                                .get1070TbleCount();
                                                                                                                                        Long scModel1174tbleCountGP = DmStatView
                                                                                                                                                .getGpTbleCount(
                                                                                                                                                        scModel1174tble);
                                                                                                                                        Long scModel1174tbleCountUI = DmStatView
                                                                                                                                                .get1174TbleCount();
                                                                                                                                        commMethods
                                                                                                                                                .verifyLong(
                                                                                                                                                        scModel1070tbleCountUI,
                                                                                                                                                        scModel1070tbleCountGP);
                                                                                                                                        commMethods
                                                                                                                                                .verifyLong(
                                                                                                                                                        scModel1174tbleCountUI,
                                                                                                                                                        scModel1174tbleCountGP);
                                                                                                                                    } else if ("DM_ID_137"
                                                                                                                                            .equalsIgnoreCase(
                                                                                                                                                    tc_Id)
                                                                                                                                            || "DM_ID_138"
                                                                                                                                                    .equalsIgnoreCase(
                                                                                                                                                            tc_Id))
                                                                                                                                    {
                                                                                                                                        ProjDashBoardPage
                                                                                                                                                .clickStatsView(
                                                                                                                                                        processName1);
                                                                                                                                        driver.switchTo()
                                                                                                                                                .frame("sb-player");
                                                                                                                                        DmStatView
                                                                                                                                                .clickJetJobXml();
                                                                                                                                        Thread.sleep(
                                                                                                                                                2000);
                                                                                                                                        driver.switchTo()
                                                                                                                                                .frame("sb-player");
                                                                                                                                        String xmlContent = driver
                                                                                                                                                .findElement(
                                                                                                                                                        By.xpath(
                                                                                                                                                                "html/body/div[1]/div[1]/pre/div"))
                                                                                                                                                .getText();
                                                                                                                                        String xmlString = xmlContent
                                                                                                                                                .replaceAll(
                                                                                                                                                        "[\\t\\n\\r]",
                                                                                                                                                        "");
                                                                                                                                        xmlString = xmlString
                                                                                                                                                .replaceAll(
                                                                                                                                                        "\\s",
                                                                                                                                                        "");
                                                                                                                                        try
                                                                                                                                        {
                                                                                                                                            commMethods
                                                                                                                                                    .verifyboolean(
                                                                                                                                                            xmlString
                                                                                                                                                                    .contains(
                                                                                                                                                                            "<stepstepName=\"GeoSelect\"moduleId=\"GeoSelect\">"),
                                                                                                                                                            true);
                                                                                                                                            commMethods
                                                                                                                                                    .verifyboolean(
                                                                                                                                                            xmlString
                                                                                                                                                                    .contains(
                                                                                                                                                                            "<ns2:mappingSources>"),
                                                                                                                                                            true);
                                                                                                                                            commMethods
                                                                                                                                                    .verifyboolean(
                                                                                                                                                            xmlString
                                                                                                                                                                    .contains(
                                                                                                                                                                            "<dataSetname=\"creditrecord\"mapping=\"1\"/>"),
                                                                                                                                                            true);
                                                                                                                                            commMethods
                                                                                                                                                    .verifyboolean(
                                                                                                                                                            xmlString
                                                                                                                                                                    .contains(
                                                                                                                                                                            "<dataSetname=\"cmssegment\"mapping=\"2\"/>"),
                                                                                                                                                            true);
                                                                                                                                            commMethods
                                                                                                                                                    .verifyboolean(
                                                                                                                                                            xmlString
                                                                                                                                                                    .contains(
                                                                                                                                                                            "</ns2:mappingSources>"),
                                                                                                                                                            true);
                                                                                                                                        } catch (org.openqa.selenium.NoSuchElementException e)
                                                                                                                                        {

                                                                                                                                        }
                                                                                                                                    }
                                                                                                                                }
                                                                                                                            }
                                                                                                                        }
                                                                                                                    }
                                                                                                                }
                                                                                                            }
                                                                                                        }
                                                                                                    }
                                                                                                }
                                                                                            }
                                                                                        }
                                                                                    }
                                                                                }
                                                                            }
                                                                        }
                                                                    }
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    /*@Test(dataProvider = "dm_Reg", priority = 2, enabled=false)
    public void statsVerification(String tc_Id, String testRun, String TC, String descr, String copyProj, String copyProcName, String processName,
            String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, String dataField,
            String zipCodeInput, String states, String stateList, String prodAPmod, String APModuleNonCriteria, String APModuleCriteria,
            String depProj, String depFile, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel, String NCPScoreModel,
            String pointScoreDrop, String idScan, String idScanRejects, String deStandard, String doublechck, String DNSdrop, String ageDrop,
            String factActOpt, String invalidDrop, String testFileDrop, String cid_CNX, String mla, String availableDataSets, String dataSetType,
            String DataSet, ITestContext testContext) throws Exception
    {
        if ("DM_ID_030".equalsIgnoreCase(tc_Id))
        {
            jobId = commMethods.getFinalProcessName();
            ProjDashBoardPage.viewStats(jobId);
            String HeaderTableNameDM = DmStatView.getHeaderTableNameDM();
            Long HeaderTableCountDMUI = ProjDashBoardPage.recWithoutComma(DmStatView.getHeaderTableCountDM());
            Long HeaderTableCountDMGP = ProjDashBoardPage.getRecordsFromGP(HeaderTableNameDM);
            commMethods.verifyLong(HeaderTableCountDMUI, HeaderTableCountDMGP);
            DmStatView.clickJetJobXml();
            String pageTitle = ProjDashBoardPage.getPageTitle();
            pageTitle = ProjDashBoardPage.getPageTitle();
            commMethods.verifyString(pageTitle, "JET JOB XML");
        } else if ("DM_ID_040".equalsIgnoreCase(tc_Id))
        {
            jobId = commMethods.getFinalProcessName();
            String Status = ProjDashBoardPage.verifyProcess(jobId);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.viewStats(jobId);
            commMethods.verifyboolean(DmStatView.isCretRejDisplayed(), true);
        }
    }*/

    @DataProvider
    public Object[][] dm_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DMStats", "Y");
        return (testObjArray_Y);
    }

    @DataProvider
    public Object[][] DMStats() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "DMStats",
                "Y");
        return (testObjArray);
    }

    @DataProvider
    public Object[][] DMDupliEditSubmit() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "DMStats",
                "DRS");
        return (testObjArray);
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public void getscreenshot() throws Exception
    {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        // The below method will save the screen shot in d drive with name "screenshot.png"
        // FileUtils.copyFile(scrFile, new File("C:\\Users\\akp8\\Desktop\\screenshot.png"));
    }

}

package com.equifax.cms.fusion.test.qaaudit;

import java.io.IOException;
import java.sql.SQLException;
import java.util.concurrent.TimeUnit;

import org.junit.AfterClass;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DCpages.DCSummaryPage;
import com.equifax.cms.fusion.test.DCpages.DataCompareInputPage;
import com.equifax.cms.fusion.test.DCpages.DataComparePage;
import com.equifax.cms.fusion.test.DCpages.DataCompareStats;
import com.equifax.cms.fusion.test.SFPages.AuditHomePage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class DataCompareProcess
{
    public static WebDriver driver = null;
    private AuditHomePage auditDCHomePage;
    private DataCompareInputPage dcInputPage;
    private DataComparePage dcPage;
    private DCSummaryPage dcSummaryPage;
    private DataCompareStats dcStats;
    private Modules module;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(DataCompareProcess.class);

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
    //    driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(150, TimeUnit.SECONDS);
        module = new Modules();
        auditDCHomePage = PageFactory.initElements(driver, AuditHomePage.class);
        dcInputPage = PageFactory.initElements(driver, DataCompareInputPage.class);
        dcPage = PageFactory.initElements(driver, DataComparePage.class);
        dcSummaryPage = PageFactory.initElements(driver, DCSummaryPage.class);
        dcStats = PageFactory.initElements(driver, DataCompareStats.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @Description("Data Comapre Regression")
    @Test(dataProvider = "dataCompare_Y_Reg")
    public void dataCompare_Reg(String tc_ID, String testRun, String testcase, String description, String copyProject, String copyProcess,
            String processName, String processLeft, String dataLeft, String groupLeft, String projNumRight, String processRight, String dataRight,
            String groupRight, String leftField1, String leftField2, String leftField3, String rightField1, String rightField2, String rightField3,
            ITestContext testContext) throws InterruptedException, SQLException, IOException
    {
        testContext.setAttribute("WebDriver", DataCompareProcess.driver);
        if ("DC_ID_027".equalsIgnoreCase(tc_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickAuditTab();
            module.initializeDriver(driver);
            commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            auditDCHomePage.selectEdit();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Input Select the Information below, and click 'Save' or 'Continue'.");
            commMethods.verifyString(dcInputPage.ProcessName_Fld.getAttribute("value"), processName);
            commMethods.verifyString(dcInputPage.getTableSelected1(), dataLeft);
            commMethods.verifyString(dcInputPage.getTableSelected2(), dataRight);
            dcInputPage.clickSaveButton();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Input Select the Information below, and click 'Save' or 'Continue'.");
            dcInputPage.clickContinueBtn();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Compare Select the Information below, and click 'Save' or 'Continue'.");
            commMethods.verifyboolean(dcPage.getLeftTableField().contains(dataLeft), true);
            commMethods.verifyboolean(dcPage.getRightTableField().contains(dataRight), true);
            dcPage.clickSaveButton();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Compare Select the Information below, and click 'Save' or 'Continue'.");
            dcPage.clickContinueBtn();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Process Summary Review the information below, and then click 'Back' or 'Submit'.");
        } else if ("DC_ID_029".equalsIgnoreCase(tc_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickAuditTab();
            module.initializeDriver(driver);
            commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            auditDCHomePage.selectEdit();
            String fProName = commMethods.getFinalProcessName();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Input Select the Information below, and click 'Save' or 'Continue'.");
            commMethods.verifyString(dcInputPage.ProcessName_Fld.getAttribute("value"), processName);
            dcInputPage.selectLeftInputProc(processLeft);
            dcInputPage.selectLeftInputData(dataLeft);
            commMethods.selectTheGroups(groupLeft);
            dcInputPage.inputProjectNumAndClickSearch(projNumRight);
            dcInputPage.selectRightInputProc(processRight);
            dcInputPage.selectRightInputData(dataRight);
            commMethods.selectTheGroups(groupRight);
            dcInputPage.clickSaveButton();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Input Select the Information below, and click 'Save' or 'Continue'.");
            dcInputPage.clickContinueBtn();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Compare Select the Information below, and click 'Save' or 'Continue'.");
            dcPage.selectLeftFields(leftField1, leftField2, leftField3);
            dcPage.selectRightFields(rightField1, rightField2, rightField3);
            dcPage.clickSaveButton();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Compare Select the Information below, and click 'Save' or 'Continue'.");
            dcPage.clickContinueBtn();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Data Compare Process Summary Review the information below, and then click 'Back' or 'Submit'.");
            dcSummaryPage.clickSubmitButton();
            Thread.sleep(5000);
            commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
        } else
        {
            ProjDashBoardPage.clickAuditTab();
            auditDCHomePage.clickDataCompareBtn();
            String fProName = commMethods.getFinalProcessName();
            dcInputPage.inputProcessName(processName);
            dcInputPage.selectLeftInputProc(processLeft);
            dcInputPage.selectLeftInputData(dataLeft);
            //commMethods.selectTheGroups(groupLeft);
            dcInputPage.inputProjectNumAndClickSearch(projNumRight);
            dcInputPage.selectRightInputProc(processRight);
            dcInputPage.selectRightInputData(dataRight);
            //commMethods.selectTheGroups(groupRight);
            if ("DC_ID_018".equalsIgnoreCase(tc_ID))
            {
                dcInputPage.clickSaveButton();
                ProjDashBoardPage.clickAuditTab();
                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
                auditDCHomePage.selectDuplicate();
                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            } else
            {
                dcInputPage.clickContinueBtn();
                if ("DC_ID_073".equalsIgnoreCase(tc_ID) || "DC_ID_074".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyString(dcInputPage.getErrorMessage(), "Match key CID does not exist in the hierarchy of the selected input");
                } else if ("DC_ID_071".equalsIgnoreCase(tc_ID))
                {
                    dcPage.clickContinueBtn();
                    commMethods.verifyString(dcPage.getErrorMessage(), "Please select at least one field in the Left & Right Fields section");
                } else if ("DC_ID_075".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyboolean(dcPage.isElementDisplayedForLeft(), true);
                    commMethods.verifyboolean(dcPage.isElementDisplayedForRight(), true);
                    commMethods.verifyboolean(dcPage.isSearchBoxPresentforLeft(), true);
                    commMethods.verifyboolean(dcPage.isSearchBoxPresentforRight(), true);
                } else if ("DC_ID_088".equalsIgnoreCase(tc_ID))
                {
                    dcPage.selectFieldLeft(leftField1);
                    dcPage.clickAddLeft();
                    commMethods.verifyboolean(dcPage.isFieldSelected(leftField1), true);
                    dcPage.clickRemoveLeft();
                    dcPage.selectFieldRight(rightField1);
                    dcPage.clickAddRight();
                    commMethods.verifyboolean(dcPage.isFieldSelected(leftField1), true);
                } else
                {
                	Thread.sleep(3000);
<<<<<<< .mine
//                	dcPage.selForChrome();
//                  dcPage.selectLeftFields(leftField1, leftField2, leftField3);
//                  dcPage.selectRightFields(rightField1, rightField2, rightField3);
||||||| .r1221409
                	dcPage.selForChrome();
//                    dcPage.selectLeftFields(leftField1, leftField2, leftField3);
//                    dcPage.selectRightFields(rightField1, rightField2, rightField3);
=======
                	//dcPage.selForChrome();
//                    dcPage.selectLeftFields(leftField1, leftField2, leftField3);
//                    dcPage.selectRightFields(rightField1, rightField2, rightField3);
>>>>>>> .r1228373
                    if ("DC_ID_017".equalsIgnoreCase(tc_ID))
                    {
                        dcPage.clickSaveButton();
                        ProjDashBoardPage.clickAuditTab();
                        commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.READY.name().trim());

                    } else
                    {
                        dcPage.clickContinueBtn();
                        if ("DC_ID_020".equalsIgnoreCase(tc_ID))
                        {
                            commMethods.verifyString(dcPage.getErrorMessage(),
                                    "Datatypes of the selected fields from the Left & Right Table section are different");
                        } else
                        {

                            if ("DC_ID_001".equalsIgnoreCase(tc_ID) || "DC_ID_002".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                                Thread.sleep(5000);
//                                driver.switchTo().frame("sb-player");
                                commMethods.verifyString(dcStats.getDCReportContent(), "Data Compare Report Content :");
                                commMethods.verifyString(dcStats.getAdvDCCompRptPresent(), "Advanced Data Compare Report");
                                dcStats.clickAdvanceDataCompareReport();
                                Thread.sleep(5000);
//                                driver.switchTo().frame("sb-player");
                                commMethods.verifyString(dcStats.getADCRHeader(), "Diff Greenplum Compare TEST");
                                commMethods.verifyboolean(dcStats.isCompResforObsPresent(), true);
                                commMethods.verifyboolean(dcStats.isVariablesSummDisplayed(), true);
                                //ProjDashBoardPage.clickCloseButtonADCR();
                                Thread.sleep(2000);
                                //commMethods.verifyboolean(dcStats.isPARAM_FILE_Displayed(), true);
                                commMethods.verifyboolean(dcStats.getCompareProText().contains("Number of Variables in Common:"), true);
                                commMethods.verifyboolean(dcStats.getCompareProText().contains("Number of ID Variables: 1."), true);
                                commMethods.verifyboolean(dcStats.getCompareProText().contains("Number of VAR Statement Variables:"), true);
                                commMethods.verifyboolean(dcStats.getCompareProText().contains("Number of WITH Statement Variables:"), true);
                                commMethods.verifyboolean(dcStats.getCompareProText().contains("Variables Summary"), true);
                                commMethods.verifyboolean(dcStats.getObservationSummary().contains("Observation Summary"), true);
                                commMethods.verifyboolean(dcStats.getObservationSummary().contains("Number of Observations in Common:"), true);
                                commMethods.verifyboolean(
                                        dcStats.getObservationSummary().contains("Number of Observations with Some Compared Variables Unequal"),
                                        true);
                                commMethods.verifyboolean(
                                        dcStats.getObservationSummary().contains("Number of Observations with All Compared Variables Equal:"), true);
                                commMethods.verifyboolean(dcStats.getObservationSummary().contains("First Obs"), true);
                                commMethods.verifyboolean(dcStats.getObservationSummary().contains("Last  Obs"), true);
                                /*ProjDashBoardPage.clickCloseButtonADCR();
                                driver.switchTo().defaultContent();
                                commMethods.verifyboolean(dcStats.isPARAM_FILE_Displayed(), true);
                                dcStats.clickPARAM();
                                String paramText = dcStats.getPARAMText();
                                commMethods.verifyboolean(paramText.contains("export  GP_TABLES_KEY=CID"), true);
                                commMethods.verifyboolean(paramText.contains("export  GP_TABLE1_COLS=" + "cid" + " "), true);
                                commMethods.verifyboolean(paramText.contains("export  GP_TABLE2_COLS=" + "cid" + " "), true);*/
                            } else if ("DC_ID_003".equalsIgnoreCase(tc_ID))
                            {
                            	Thread.sleep(3000);
                                commMethods.verifyString(dcSummaryPage.getWarningMessage(),
                                        "Warning: The credit datasets of the left and right tables do not match");
                                Thread.sleep(3000);
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(3000);
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_SAS_DCX(fProName), "SAS_DCXJOB");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_SAS_CIDEXTRACT(), "SAS_CIDEXTRACT");

                            } else if ("DC_ID_009".equalsIgnoreCase(tc_ID) || "DC_ID_014".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_023".equalsIgnoreCase(tc_ID) || "DC_ID_024".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_025".equalsIgnoreCase(tc_ID) || "DC_ID_031".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(5000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");

                            } else if ("DC_ID_006".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_SAS_DCX(fProName), "SAS_DCXJOB");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_SAS_CIDEXTRACT(), "SAS_CIDEXTRACT");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_AUDIT_JET(), "AUDIT_JET");
                                commMethods.verifyString(ProjDashBoardPage.getDCworkitem_AUDIT_SFLOAD(), "AUDIT_SFLOAD");
                            } else if ("DC_ID_015".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(5000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                auditDCHomePage.selectDuplicate();
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                                auditDCHomePage.selectSummary();
                                commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                                        "Data Compare Process Summary Review the information below, and then click 'Back' or 'Submit'.");
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(5000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                            } else if ("DC_ID_035".equalsIgnoreCase(tc_ID))
                            {
                            	Thread.sleep(3000);
                                ProjDashBoardPage.clickAuditTab();
                                Thread.sleep(3000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                                Thread.sleep(3000);
                                auditDCHomePage.selectDuplicate();
                                Thread.sleep(3000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                            } else if ("DC_ID_032".equalsIgnoreCase(tc_ID) || "DC_ID_037".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_058".equalsIgnoreCase(tc_ID) || "DC_ID_059".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_062".equalsIgnoreCase(tc_ID) || "DC_ID_063".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(5000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                            }
                            else if ("DC_ID_084".equalsIgnoreCase(tc_ID))
                            {
                                commMethods.verifyboolean(dcSummaryPage.isProcessJobDataDisplayedL(), true);
                                commMethods.verifyboolean(dcSummaryPage.isProcessJobDataDisplayedR(), true);
                            } else if ("DC_ID_086".equalsIgnoreCase(tc_ID))
                            {
                                commMethods.verifyString(dcSummaryPage.getRightProcessName(), processRight);
                                commMethods.verifyString(dcSummaryPage.getRightTable(), dataRight);
                            } else if ("DC_ID_108".equalsIgnoreCase(tc_ID) || "DC_ID_019".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_069".equalsIgnoreCase(tc_ID) || "DC_ID_070".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_072".equalsIgnoreCase(tc_ID) || "DC_ID_077".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_078".equalsIgnoreCase(tc_ID) || "DC_ID_079".equalsIgnoreCase(tc_ID)
                                    || "DC_ID_081".equalsIgnoreCase(tc_ID) || "DC_ID_083".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(5000);
                                commMethods.verifyString(auditDCHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");

                            } else if ("DC_ID_109".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                Thread.sleep(3000);
                                commMethods.verifyString(dcSummaryPage.getErrorMessage(), "Input Table " + "\"" + dataLeft + "\""
                                        + " selected for process " + fProName + ":" + processName + " doesnot exist.");
                                // Input Table "HEADER" selected for process AC42:TEST_MJ doesnot exist.
                            } else if ("DC_ID_038".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                ProjDashBoardPage.clickHomeTab();
                                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
//                                driver.switchTo().frame("sb-player");
                                dcStats.clickAdvanceDataCompareReport();
//                                driver.switchTo().frame("sb-player");
                                commMethods.verifyboolean(dcStats.getCompareProcedure().contains("_LEFT but not in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getCompareProcedure().contains("_RIGHT"), true);
                                commMethods.verifyboolean(dcStats.getCompareProcedure().contains("_RIGHT but not in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getCompareProcedure().contains("_LEFT"), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("Listing of Variables in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("_LEFT but not in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("_RIGHT"), true);
                                String[] leftField = leftField3.split(",");
                                commMethods.verifyboolean(dcStats.getListingVariables().contains(leftField[1]), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("Char"), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("f_name"), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("1024"), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("Listing of Variables in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("_RIGHT but not in ACCEL."), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("_LEFT"), true);
                                String[] rightField = rightField3.split(",");
                                commMethods.verifyboolean(dcStats.getListingVariables().contains(rightField[1]), true);
                                commMethods.verifyboolean(dcStats.getListingVariables().contains("l_name"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("Total Number of Observations Read from ACCEL."),
                                        true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("_LEFT:"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("_RIGHT:"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("First Unequal"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("Last  Unequal"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("_RIGHT:"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("_RIGHT:"), true);
                                commMethods.verifyboolean(dcStats.getObeservationSummary1().contains("Values Comparison Summary"), true);
                            } else if ("DB_DC_001".equalsIgnoreCase(tc_ID))
                            {
                                dcSummaryPage.clickSubmitButton();
                                ProjDashBoardPage.clickHomeTab();
                                ProjDashBoardPage.openProcessGearBox(processName);
                                ProjDashBoardPage.clickGearBoxCancel();
                                Thread.sleep(5000);
                                ProjDashBoardPage.clickConfirmationOK();
                                String proName = ProjDashBoardPage.jobName();
                                String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
                                commMethods.verifyString(finalStat, "CANCELLED");
                                ProjDashBoardPage.openProcessGearBox(processName);
                                commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);
                                LOGGER.info("Test execution completed successfully");
                            }
                        }
                    }
                }
            }
        }
    }

    @DataProvider
    public Object[][] dataCompare_Y_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DataCompare", "Y");
        return testObjArray_Y;
    }

}

package com.equifax.cms.fusion.test.qadm;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;
import com.equifax.cms.fusion.test.DMEpages.DMEStatsView;
import com.equifax.cms.fusion.test.DMEpages.DMEsetupPage;
import com.equifax.cms.fusion.test.DMEpages.DMEsummaryPage;
import com.equifax.cms.fusion.test.DMPages.APmodulePage;
import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.DMPages.DataMenuHomePage;
import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Data Menu Express Process")
public class DMEprocess
{

    public WebDriver driver = null;
    CommonMethods commMethods;
    ProjectDashBoardPage ProjDashBoardPage;
    DataMenuHomePage dmHomePage;
    DMEsummaryPage dmeSumPage;
    DMEsetupPage setupPage;
    DMEStatsView statsView;
    private DMSummaryPage dmSummaryPage;
    private DmStatsView dmStatsPage;
    private DataProcessingTabFIL dpHomePage;
    private FilteringPage filterPage;
    private APmodulePage apModulePage;
    private static final Logger LOGGER = LoggerFactory.getLogger(DMEprocess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {

       // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        setupPage = PageFactory.initElements(driver, DMEsetupPage.class);
        dmHomePage = PageFactory.initElements(driver, DataMenuHomePage.class);
        dmeSumPage = PageFactory.initElements(driver, DMEsummaryPage.class);
        statsView = PageFactory.initElements(driver, DMEStatsView.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        dmStatsPage = PageFactory.initElements(driver, DmStatsView.class);
        dmSummaryPage = PageFactory.initElements(driver, DMSummaryPage.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabFIL.class);
        filterPage = PageFactory.initElements(driver, FilteringPage.class);
        apModulePage = PageFactory.initElements(driver, APmodulePage.class);
        commMethods.userLogin();
        commMethods.searchProject();

    }

    // QA
    @Test(dataProvider = "InputData_Y", priority = 2, description = "TS1: DME process duplicate, summary status validations")
    public void dmeProcessStatus_QA(String tc_Id, String testRun, String TC, String Description, String procName, String copyProject,
            String copyProcess, String dataOrigin, String process, String data, String stateList, String stateDropDown, String modules,
            String outputs, String tableNames, String externalTables, String loadPointScoreData, String userParams, String accValue, String rejValue,
            ITestContext testContext) throws InterruptedException, SQLException
    {
        Modules module = new Modules();
        testContext.setAttribute("WebDriver", driver);
/*        if ("DME_ID_055".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            module.initializeDriver(driver);
            commMethods.verifyString(status, StatusEnum.READY.name().trim());
            module.selectEdit();
            commMethods.verifyboolean(setupPage.isLoadPointScoreDataSelected(), true);
        } else*/
        //{
            ProjDashBoardPage.clickDataMenuTab();
            dmHomePage.clickDMexpressButton();
            String processName = commMethods.getProcId();

            setupPage.processNameField(procName);
            setupPage.selectDataOriginField(dataOrigin);
            if ("DME_ID_066".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(setupPage.isProcessDisplayed(), true);
                setupPage.selectDataOriginField("List Source");
                commMethods.verifyboolean(setupPage.isProcessDisplayed(), true);
            } else
            {
                if (dataOrigin.equalsIgnoreCase("List Source"))
                {
                    setupPage.selectProcessField(process);
                    setupPage.selectDataField(data);
                } else if (dataOrigin.equalsIgnoreCase("CID List"))
                {
                    setupPage.selectProcessForCID(process);
                    setupPage.selectDataForCID(data);
                }
                setupPage.selectDataOriginField(dataOrigin);
                setupPage.selectStatesList(stateList);
                setupPage.selectStatesDropDwn(stateDropDown);
                apModulePage.selApModulesNonCriteria(modules,externalTables,outputs,userParams);
                setupPage.selectLoadPointScoreData(loadPointScoreData);
                setupPage.inputNoPerAcc(accValue);
                setupPage.inputNoPerRej(rejValue);
                
                if ("DME_ID_001".equalsIgnoreCase(tc_Id) || "DME_ID_002".equalsIgnoreCase(tc_Id) || "DME_ID_003".equalsIgnoreCase(tc_Id)
                        || "DME_ID_004".equalsIgnoreCase(tc_Id) || "DME_ID_051".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                } else if ("DME_ID_007".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                    // ProjDashBoardPage.clickStatsView(processName1);
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(processName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.getRecordsFromGP(statsView.getHeaderTableNameDME()), statsView.getHeaderTableCountDME());
                    commMethods.verifyboolean(statsView.isScoreModelTableCreated(), false);
                } /*else if ("DME_ID_011".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmSummaryPage.clickViewXMLbtn();
                    String xmlContent = dmeSumPage.getJobXmlContents();
                    commMethods.verifyboolean(xmlContent.contains("<ns2:DoubleCheckRules>") || xmlContent.contains("</ns2:DoubleCheckRules>"), false);
                    commMethods.verifyboolean(xmlContent.contains("<ns2:FactActRules>") || xmlContent.contains(" </ns2:FactActRules>"), false);
                    commMethods.verifyboolean(xmlContent.contains("<module moduleId=\"NoAgeCheck\" fileName=\"libnoagecheck.so\"/>"), false);
                    commMethods.verifyboolean(xmlContent.contains("<onFail goto=\"HeaderInfo\" state=\"1\"/>"), true);
                } */else if ("DME_ID_031".equalsIgnoreCase(tc_Id) || "DME_ID_034".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    setupPage.clickContinueButton();
                    dmSummaryPage.clickViewXMLbtn();
                    String xmlContent = dmeSumPage.getJobXmlContents();
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL5053\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL276\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL5052\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL5051\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL197\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL5055\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL1278\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL2409\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL2352\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL1206\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL2440\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL2356\" moduleId=\"ModelDriver\">"), true);
                    commMethods.verifyboolean(xmlContent.contains("<step stepName=\"MDL2413\" moduleId=\"ModelDriver\">"), true);
                } else if ("DME_ID_037".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                    ProjDashBoardPage.viewStats(processName);
                    commMethods.verifyLong(commMethods.getRecordsFromGP(statsView.getLCRTableName()), statsView.getLCRTableCountDisplayed());
                } else if ("DME_ID_009".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                    driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')]//preceding::span[1])[1]")).click();
                    Thread.sleep(2000);
                    driver.findElement(By.xpath("(//span[contains(text(),'" + processName + "')]//preceding::span[1])[2]")).click();
                    Thread.sleep(2000);
                    /*ProjDashBoardPage.clickJobUpperLevel(processName1);
                    ProjDashBoardPage.clickJobLowerLevel(processName1);
                    Thread.sleep(2000);*/
                    commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("DM_GPLOAD"), true);
                    commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("DM_JET"), true);
                    commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("SAMPLE_EXTRACT"), true);
                    commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("AUDIT_SFLOAD"), true);
                    ProjDashBoardPage.clickViewDM_GPLOAD();
                    commMethods.verifyboolean(statsView.isScoreModelTableCreated(), false);
                } else if ("DME_ID_039".equalsIgnoreCase(tc_Id) || "DME_ID_047".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    ProjDashBoardPage.clickDataMenuTab();
                    commMethods.verifyString(dmHomePage.GetStatusDM(processName), StatusEnum.READY.name().trim());
                    module.initializeDriver(driver);
                    module.selectDuplicate1();
                    commMethods.verifyString(dmHomePage.GetStatusDM(processName), StatusEnum.READY.name().trim());
                    module.selectSummary1();
                    dmeSumPage.clickSubmitButton();
                    String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
                    commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name().trim());
                } else if ("DME_ID_042".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(processName);
                    commMethods.verifyLong(commMethods.getRecordsFromGP(statsView.getHeaderTableNameDME()), statsView.getHeaderTableCountDME());
                    commMethods.verifyLong(commMethods.getRecordsFromGP(statsView.getInqPostTableNameDME()), statsView.getInqPostTableCountDME());
                } else if ("DME_ID_052".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    setupPage.clickContinueButton();
                    commMethods.verifyboolean(dmeSumPage.isScoreModelTablePredictedSumm(processName), true);
                } else if ("DME_ID_054".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    setupPage.clickContinueButton();
                    ProjDashBoardPage.clickDataMenuTab();
                    commMethods.verifyString(dmHomePage.GetStatusDM(processName), StatusEnum.READY.name().trim());
                    module.initializeDriver(driver);
                    module.selectDuplicate1();
                    commMethods.verifyString(dmHomePage.GetStatusDM(processName), StatusEnum.READY.name().trim());
                    module.selectEdit();
                    commMethods.verifyboolean(setupPage.isLoadPointScoreDataSelected(), true);
                } else if ("DME_ID_056".equalsIgnoreCase(tc_Id))
                {
                    String fullProcessName = processName+":"+procName;
                    setupPage.clickSaveButton();
                    ProjDashBoardPage.clickDataMenuTab();
                    commMethods.verifyString(dmHomePage.GetStatusDM(processName), StatusEnum.READY.name().trim());
                    ProjDashBoardPage.clickDataProcessingTab();
                    dpHomePage.clickFilteringButton();
                    filterPage.inputProcessName("DME_ID_056");
                    filterPage.selectProcess(fullProcessName);
                    boolean flag;
                    try
                    {
                        filterPage.selectData("MODEL_0197");
                        flag = true;
                    } catch (org.openqa.selenium.NoSuchElementException e)
                    {
                        flag = false;
                    }
                    commMethods.verifyboolean(flag, true);
                } else if ("DME_ID_059".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmSummaryPage.clickViewXMLbtn();
                    String xmlContent = dmeSumPage.getJobXmlContents();
                    commMethods.verifyboolean(xmlContent.contains("<module moduleId=\"CreditAudit\" fileName=\"libcreditauditxml.so\"/>"), true);
                    String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", "");
                    xmlString = xmlString.replaceAll("\\s", "");
                    commMethods.verifyboolean(xmlString.contains(
                            "<stepstepName=\"CreditAudit\"moduleId=\"CreditAudit\"><ns2:mappingSources><dataSetname=\"creditrecord\"mapping=\"1\"/><dataSetname=\"cmssegment\"mapping=\"2\"/></ns2:mappingSources><control><onConditionvalue=\"1\"goto=\"drop\"state=\"1\"/></control><config><ns2:CreditAuditRules><AuditRecordsacceptLimit=\""
                                    + accValue + "\"rejectLimit=\"" + rejValue + "\"masking=\"false\"/></ns2:CreditAuditRules></config></step>"),
                            true);
                } else if ("DME_ID_061".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(processName);
                    dmStatsPage.clickJetJobXml();
                    String xmlContent = statsView.getXMLContentsDME();
                    String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", "");
                    xmlString = xmlString.replaceAll("\\s", "");
                    commMethods.verifyboolean(xmlString.contains(
                            "<stepstepName=\"CreditAudit\"moduleId=\"CreditAudit\"><ns2:mappingSources><dataSetname=\"creditrecord\"mapping=\"1\"/><dataSetname=\"cmssegment\"mapping=\"2\"/></ns2:mappingSources><control><onConditionvalue=\"1\"goto=\"drop\"state=\"1\"/></control><config><ns2:CreditAuditRules><AuditRecordsacceptLimit=\""
                                    + accValue + "\"rejectLimit=\"" + rejValue + "\"masking=\"false\"/></ns2:CreditAuditRules></config></step>"),
                            true);
                }/* else if ("DME_ID_062".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    dmeSumPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName), "PASS");
//                    ProjDashBoardPage.SAMPLE_EXTRACTworkItem(processName1);
                    
                    ProjDashBoardPage.clickJobUpperLevel(processName1);
                    ProjDashBoardPage.clickJobLowerLevel(processName1);
                     commMethods.verifyboolean(ProjDashBoardPage.is_SAMPLE_EXTRACT_WorkItem_Present(), false);
                     commMethods.verifyboolean(ProjDashBoardPage.is_AUDIT_SFLOAD_WorkItem_Present(), false);
                } */else if ("DME_ID_065".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickContinueButton();
                    commMethods.verifyString(dmeSumPage.getProductDisplayed(), "PRESCREEN");

                } else if ("DME_ID_067".equalsIgnoreCase(tc_Id))
                {
                    setupPage.clickSaveButton();
                    commMethods.verifyboolean(setupPage.isLoadPointScoreDataSelected(), false);
                } else if ("DME_ID_048".equalsIgnoreCase(tc_Id))
                {
                    driver.findElement(By.xpath(".//*[@id='name']")).clear();
                    setupPage.clickContinueButton();
                    commMethods.verifyString(setupPage.getErrorMsg1(), "Please enter the Process Name.");
                    setupPage.processNameField("TEST");
                    setupPage.inputNoPerAcc("9999");
                    setupPage.inputNoPerRej("999");
                    setupPage.clickContinueButton();
                    commMethods.verifyString(setupPage.getErrorMsg1(), "Please enter numeric values between 1-999 in Number per Accept Code");
                    setupPage.inputNoPerAcc("999");
                    setupPage.inputNoPerRej("9999");
                    setupPage.clickContinueButton();
                    commMethods.verifyString(setupPage.getErrorMsg1(), "Please enter numeric values between 1-999 in Number per Reject Code");
                    setupPage.inputNoPerAcc("9999");
                    setupPage.clickContinueButton();
                    setupPage.clickContinueButton();
                    commMethods.verifyString(setupPage.getErrorMsg1(), "Please enter numeric values between 1-999 in Number per Accept Code");
                    setupPage.inputNoPerAcc("999");
                    setupPage.inputNoPerRej("999");
                    setupPage.clickContinueButton();
                    commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                            "Summary: Data Menu\nReview the information below, and then click 'Submit' or 'Back'.");
                }
            }
      //  }

    }

    // DEV
    @Title("Stats verification for the DME process")
    @Test(dataProvider = "InputData_Y", priority = 1, description = "TS2: DME process Stats verification", enabled = false)
    public void dmeProcessStats(String tc_Id, String testRun, String TC, String Description, String procName, String copyProject, String copyProcess,
            String dataOrigin, String process, String data, String stateList, String stateDropDown, String modules, String outputs, String tableNames,
            String externalTables, String loadPointScoreData, String userParams, String accValue, String rejValue, ITestContext testContext)
            throws InterruptedException, SQLException
    // Added loadPointScoreData Parameter In the Parameters
    // Added Copy Project And Copy Process Param

    {
        String status = null;

        testContext.setAttribute("WebDriver", driver);
        ProjDashBoardPage.clickDataMenuTab();
        dmHomePage.clickDMexpressButton();

        String processName1 = commMethods.getFinalProcessName();
        setupPage.processNameField(procName);
        setupPage.selectDataOriginField(dataOrigin);

        if (dataOrigin.equalsIgnoreCase("List Source"))
        {
            setupPage.selectProcessField(process);
            setupPage.selectDataField(data);

        } else if (dataOrigin.equalsIgnoreCase("CID List"))
        {
            setupPage.selectProcessForCID(process);
            setupPage.selectDataForCID(data);
        }

        setupPage.selectDataOriginField(dataOrigin);
        setupPage.selectStatesList(stateList);
        setupPage.selectStatesDropDwn(stateDropDown);
        apModulePage.selApModulesNonCriteria(modules,externalTables,outputs,userParams);

        // Get scoresList
        List<String> scoresList = new ArrayList<>();
        int id = 2;
        while (commMethods.isElementPresent_Xpath(".//*[@id='detailsModuleDiv0']/table/tbody/tr[1]/td[2]/label[" + id + "]"))
        {
            scoresList.add(setupPage.getRequiredPluginsById(id));
            id++;
        }

        // Submit test cases
        setupPage.clickContinueButton();
        Thread.sleep(5000);
        dmeSumPage.clickSubmitButton();
        ProjDashBoardPage.clickDataMenuTab();
        status = dmHomePage.GetStatusDM(processName1);
        commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());

        ProjDashBoardPage.clickHomeTab();
        String Status = ProjDashBoardPage.verifyProcess(processName1);
        commMethods.verifyString(Status, "PASS");
        ProjDashBoardPage.viewStats(processName1);
        // driver.switchTo().frame("sb-player");
        Thread.sleep(4500);
        String hdrTableNameDME = statsView.getHeaderTableNameDME();

        // Test cases checking xml content
        if ("DME_ID_015".equalsIgnoreCase(tc_Id) || "DME_ID_016".equalsIgnoreCase(tc_Id) || "DME_ID_017".equalsIgnoreCase(tc_Id)
                || "DME_ID_018".equalsIgnoreCase(tc_Id) || "DME_ID_019".equalsIgnoreCase(tc_Id) || "DME_ID_020".equalsIgnoreCase(tc_Id)
                || "DME_ID_021".equalsIgnoreCase(tc_Id) || "DME_ID_022".equalsIgnoreCase(tc_Id) || "DME_ID_023".equalsIgnoreCase(tc_Id)
                || "DME_ID_024".equalsIgnoreCase(tc_Id) || "DME_ID_025".equalsIgnoreCase(tc_Id))
        {
            dmStatsPage.clickJetJobXml();
            Thread.sleep(4500);
//            driver.switchTo().frame("sb-player");
            String xmlContent = statsView.getXMLContentsDME();
            // removing all the lines and spaces in xml
            String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", "");
            xmlString = xmlString.replaceAll("\\s", "");

            // Validate that job xml for DM Express has household key step.
            if ("DME_ID_015".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("<fileName>$(PARTITION).cidu.dpx</fileName>"));
            }

            // Validate that job xml for DM Express has Dataset state step.
            if ("DME_ID_016".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("step stepName=\"HouseholdKey\" moduleId=\"HouseholdKey\""));
            }

            // Validate that all DM express job uses Unique CID index and thus job xml for DM Express has cidu.dpx in its filename step.
            if ("DME_ID_017".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("step stepName=\"DatasetStats\" moduleId=\"DatasetStats\""));
            }

            // Validate that job xml for DM Express has CMS segment included for Dataset product step if CMS segment is required by the AP module
            // used.
            if ("DME_ID_018".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("<dataSet product=\"CMSSegment\" provider=\"CMS\" required=\"true\""));
            }

            // Validate that job xml for DM Express does not have CMS segment included for Dataset product step if CMS segment is not required by the
            // AP module used.
            if ("DME_ID_019".equalsIgnoreCase(tc_Id)) // Find an apmodule that doesnt require cms segment
            {
                Assert.assertTrue(!xmlContent.contains("<dataSet product=\"CMSSegment\" provider=\"CMS\" required=\"true\""));
            }

            // Validate that in job xml for DM Express a FilterSelect step must be included in all jobs, occurring immediately after the HHKeys and
            // DatasetStats steps, with only the Test File option set to TRUE.
            if ("DME_ID_020".equalsIgnoreCase(tc_Id))
            {
                int indexOfDatasetStep = xmlContent.indexOf("<step stepName=\"DatasetStats\" moduleId=\"DatasetStats\">");
                int indexOfHouseholdKeyStep = xmlContent.indexOf("<step stepName=\"HouseholdKey\" moduleId=\"HouseholdKey\">");
                int indexOfGeoSelectStep = xmlContent.indexOf("<step stepName=\"GeoSelect\" moduleId=\"GeoSelect\">");
                int indexOfFilterSelect = xmlContent.indexOf("<step stepName=\"FilterSelect\" moduleId=\"FilterSelect\">");

                Assert.assertTrue(indexOfDatasetStep < indexOfHouseholdKeyStep);
                Assert.assertTrue(indexOfHouseholdKeyStep < indexOfGeoSelectStep);
                Assert.assertTrue(indexOfGeoSelectStep < indexOfFilterSelect);
                Assert.assertTrue(xmlContent.contains("<step stepName=\"FilterSelect\" moduleId=\"FilterSelect\">"));
                Assert.assertTrue(xmlContent.contains("<dropTestFiles>true</dropTestFiles>"));
            }

            // Validate that in job xml for DM Express steps for all Score Models required by AP module must be added.
            if ("DME_ID_021".equalsIgnoreCase(tc_Id) || "DME_ID_022".equalsIgnoreCase(tc_Id))
            {
                int i = 0;
                int indexOfApModules = xmlContent.indexOf("<step stepName=\"" + modules + "\" moduleId=\"" + modules + "\">");
                int indexOfScore;
                while (i < scoresList.size())
                {
                    String modelNo = scoresList.get(i).replaceAll("[^0-9?!\\.]", "");
                    modelNo = modelNo.replaceFirst("^0*", "");
                    Assert.assertTrue(xmlContent.contains(
                            "<ns2:ScoreModelRules modelId=\"" + modelNo + "\" defaultScore=\"0\" modelDescription=\"" + scoresList.get(i) + "\">"));
                    indexOfScore = xmlContent.indexOf(
                            "<ns2:ScoreModelRules modelId=\"" + modelNo + "\" defaultScore=\"0\" modelDescription=\"" + scoresList.get(i) + "\">");
                    // Validate that in job xml for DM Express steps for all Score Models required by AP module must be added prior to AP module step.
                    if ("DME_ID_022".equalsIgnoreCase(tc_Id))
                    {
                        // Ap modules step occurs before score step
                        Assert.assertTrue(indexOfApModules > indexOfScore);
                    }
                    i++;
                }
            }

            // // Validate that in job xml for DM Express steps for all Score Models required by AP module must be added with TAG rule but state as 0.
            if ("DME_ID_023".equalsIgnoreCase(tc_Id))
            {
                int i = 0;
                while (i < scoresList.size())
                {
                    String modelNo = scoresList.get(i).replaceAll("[^0-9?!\\.]", "");
                    modelNo = modelNo.replaceFirst("^0*", "");
                    // Tag value as 1 and state as 0 check
                    Assert.assertTrue(
                            xmlString.contains("<control><onConditionvalue=\"1\"state=\"0\"/></control><config><ns2:ScoreModelRulesmodelId=\""
                                    + modelNo + "\"defaultScore=\"0\"modelDescription=\"" + scoresList.get(i) + "\">"));
                    i++;
                }
            }
            // Validate that in job xml for DM Express steps for all AP module must be added.
            if ("DME_ID_024".equalsIgnoreCase(tc_Id))
            {
                String moduleList[] = StringUtils.split(modules, ",");
                for (int i = 0; i < moduleList.length; i++)
                {
                    Assert.assertTrue(xmlContent.contains("<step stepName=\"" + moduleList[i] + "\" moduleId=\"" + moduleList[i] + "\">"));
                }

            }
            // Validate that in job xml for DM Express no step for DE standards should be included.
            if ("DME_ID_025".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(!xmlContent.contains("<step stepName=\"DEStandard\" moduleId=\"DEStandard\">"));
            }
        }
        if ("DME_ID_001".equalsIgnoreCase(tc_Id) || "DME_ID_002".equalsIgnoreCase(tc_Id) || "DME_ID_003".equalsIgnoreCase(tc_Id)
                || "DME_ID_004".equalsIgnoreCase(tc_Id) || "DME_ID_007".equalsIgnoreCase(tc_Id))

        {
            if ("DME_ID_007".equalsIgnoreCase(tc_Id))
            {
                try
                {
                    Assert.assertTrue(null != hdrTableNameDME);
                } catch (Exception e)
                {
                    Assert.assertEquals("Table not present", "Table Present");
                }
            }
        }

        ProjDashBoardPage.clickCloseButtonStats();
        driver.switchTo().defaultContent();
    }

    @Title(" verification for the DME process")
    @Test(dataProvider = "InputData_CBA", priority = 1, description = "TS2: DME process dashboard verification", enabled = false)
    public void dmeProcessCBA(String tc_Id, String testRun, String TC, String Description, String procName, String dataOrigin, String process,
            String data, String stateList, String stateDropDown, String modules, String outputs, String tableNames, String externalTables,
            String userParams, String accValue, String rejValue, ITestContext testContext) throws InterruptedException, SQLException

    {
        testContext.setAttribute("WebDriver", driver);

        ProjDashBoardPage.clickDataMenuTab();
        dmHomePage.clickDMexpressButton();

        setupPage.processNameField(procName);
        setupPage.selectDataOriginField(dataOrigin);

        if (dataOrigin.equalsIgnoreCase("List Source"))
        {
            setupPage.selectProcessField(process);
            setupPage.selectDataField(data);

        } else if (dataOrigin.equalsIgnoreCase("CID List"))
        {
            setupPage.selectProcessForCID(process);
            setupPage.selectDataForCID(data);
        }

        setupPage.selectDataOriginField(dataOrigin);
        setupPage.selectStatesList(stateList);
        setupPage.selectStatesDropDwn(stateDropDown);
        String moduleSel[] = modules.split(",");
        apModulePage.selApModulesNonCriteria(moduleSel[0],externalTables,outputs,userParams);

        // Get scoresList
        List<String> scoresList = new ArrayList<>();
        int id = 2;
        while (commMethods.isElementPresent_Xpath(".//*[@id='detailsModuleDiv0']/table/tbody/tr[1]/td[2]/label[" + id + "]"))
        {
            scoresList.add(setupPage.getRequiredPluginsById(id));
            id++;
        }
        if ("DME_ID_029".equalsIgnoreCase(tc_Id))
        {
            // 282103
            setupPage.clickSaveButton();
            String version[] = modules.split(",");
            commMethods.verifyboolean(setupPage.getModelVersion().contains("dev"), true);
        }

        // Submit test cases
        setupPage.clickContinueButton();

        if ("DME_ID_015".equalsIgnoreCase(tc_Id) || "DME_ID_016".equalsIgnoreCase(tc_Id) || "DME_ID_017".equalsIgnoreCase(tc_Id)
                || "DME_ID_025".equalsIgnoreCase(tc_Id))
        {
            dmeSumPage.clickViewXml();
            dmeSumPage.getJobXmlContents();

            String xmlContent = dmeSumPage.getJobXmlContents();
            String houseHoldStep = "stepName=" + "\"HouseholdKey\"";
            String fileName = "cidu.dpx</fileName>";
            String datasetSegment = "<dataSet product=\"CMSSegment\"";
            String moduleStep = "step stepName=\"APOutput\" moduleId=\"APOutput\">";

            commMethods.verifyboolean(xmlContent.contains(houseHoldStep), true);
            commMethods.verifyboolean(xmlContent.contains(fileName), true);
            commMethods.verifyboolean(xmlContent.contains(datasetSegment), true);
            commMethods.verifyboolean(xmlContent.contains(moduleStep), true);
            commMethods.verifyboolean(!xmlContent.contains("DE Standard"), true);
            LOGGER.info("Test execution completed successfully");
        }

        if ("DB_DME_001".equalsIgnoreCase(tc_Id))
        {
            dmeSumPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            ProjDashBoardPage.openProcessGearBox(procName);
            ProjDashBoardPage.clickGearBoxCancel();
            Thread.sleep(5000);
            ProjDashBoardPage.clickConfirmationOK();
            String proName = ProjDashBoardPage.jobName();
            String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
            commMethods.verifyString(finalStat, "CANCELLED");
            ProjDashBoardPage.openProcessGearBox(procName);
            commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);
            LOGGER.info("Test execution completed successfully");
        }
        // Validate that job xml for DM Express has household key step.

        // stepName="HouseholdKey"

        // cidu.dpx</fileName>
        // <dataSet product="CMSSegment"
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] InputData_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DataMenuExpress", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] InputData_CBA() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DataMenuExpress", "CBA");
        return testObjArray_Y;
    }

}

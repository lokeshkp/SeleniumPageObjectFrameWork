package com.equifax.cms.fusion.test.input;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

public class InputEBCDICFixedPositiveTestCases
{
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
	private static final Logger LOGGER = LoggerFactory.getLogger(InputEBCDICFixedPositiveTestCases.class);
	private OracleDBHelper db;
    private static final String IP = "Input";
    private boolean acceptNextAlert = true;
    WebDriverWait wait;

    @Before
    public void setUp() throws Exception
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		db = new OracleDBHelper();

    }

    @Features("Input fixed ebcdic process positive scenarios")
    @Stories("US #3")
    @Test
    public void testIPFixedLayout() throws Exception
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        module.userLogin();
        module.searchProject();
        module.navigateToProcess(IP);
        module.navigateToNewProcessPage("Import New File");
        // Test Case : Create a new input process, create a new layout,add one value in the layout selecting from customize, save, continue, do not //
        // run datacheck
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys("iptest-ebcdic");// Get from csv
        driver.findElement(By.id("filePath")).clear();
        driver.findElement(By.id("format2")).click();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys("/nas/users/jbodeddula/sourav/test_Import_EBCDIC/8290_100_123_1.fixed");
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("recLen")).sendKeys("123");
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(PropertiesUtils.getProperty("ipSeqno"));

        driver.findElement(By.id("layoutId164")).click(); // Id not fixed TODO change it later

        driver.findElement(By.id("submitLayout")).click();

        driver.findElement(By.id("submitButton")).click();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(60000);

        driver.findElement(By.id("isDataCheck")).click();
        driver.findElement(By.id("submitButton")).click();

        // Test Case : Submit the process
        module.selectSubmit();
        module.navigateToProcess(IP);
        status = module.getStatusIP();
        // Status for the process should change to submitted
        Assert.assertEquals(StatusEnum.SUBMITTED.name(), status.trim());

        module.navigateToHome();
        String jobId = module.getJobId();
        testIPSubmitNoDC(jobId);

        module.userLogout();
    }

    @After
    public void tearDown() throws Exception
    {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString))
        {
            fail(verificationErrorString);
        }
    }

    public void testIPSubmitNoDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    public void testIPSubmitWithDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 4);

        // Verify values from greenplum
    }

    private boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

    private String closeAlertAndGetItsText()
    {
        try
        {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert)
            {
                alert.accept();
            } else
            {
                alert.dismiss();
            }
            return alertText;
        } finally
        {
            acceptNextAlert = true;
        }
    }
}


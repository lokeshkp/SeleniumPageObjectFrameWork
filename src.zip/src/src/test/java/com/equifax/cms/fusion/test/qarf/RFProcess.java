package com.equifax.cms.fusion.test.qarf;

import static org.junit.Assert.assertTrue;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.DNSPages.DataProcessingTab;
import com.equifax.cms.fusion.test.DNSPages.NewDNSSetupPage;
import com.equifax.cms.fusion.test.FFFPages.FullFileFixedPage;
import com.equifax.cms.fusion.test.IPPages.IpStatsView;
import com.equifax.cms.fusion.test.IPPages.SummaryPage;
import com.equifax.cms.fusion.test.RFPages.CEoptionsPage;
import com.equifax.cms.fusion.test.RFPages.CustomHholdModPage;
import com.equifax.cms.fusion.test.RFPages.CustomSuppPage;
import com.equifax.cms.fusion.test.RFPages.DedupeOptionsPage;
import com.equifax.cms.fusion.test.RFPages.HholdCustomPage;
import com.equifax.cms.fusion.test.RFPages.HholdSplitPage;
import com.equifax.cms.fusion.test.RFPages.HholdingKeyConfigPage;
import com.equifax.cms.fusion.test.RFPages.NegativeHholdDropPage;
import com.equifax.cms.fusion.test.RFPages.NewRFSetupPage;
import com.equifax.cms.fusion.test.RFPages.RFCommonMethods;
import com.equifax.cms.fusion.test.RFPages.RFHomePage;
import com.equifax.cms.fusion.test.RFPages.RFStatsView;
import com.equifax.cms.fusion.test.RFPages.RFSummaryPage;
import com.equifax.cms.fusion.test.RFPages.SuppressionOptionsPage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Refinement Process")
public class RFProcess extends AbstractCoreTest
{

    public static WebDriver driver = null;
    private ProjectDashBoardPage ProjDashBoardPage;
    private RFHomePage rfHomePage;
    private NewRFSetupPage rfSetupPage;
    private DedupeOptionsPage dedupePage;
    private SuppressionOptionsPage supprOptionsPage;
    private CustomSuppPage custSupPage;
    private CEoptionsPage cePage;
    private HholdingKeyConfigPage hhKeyConfigPage;
    private NegativeHholdDropPage nhhdPage;
    private HholdCustomPage chHPage;
    private CustomHholdModPage custHholdPage;
    private HholdSplitPage hhSplitRegPage;
    private RFStatsView rfStats;
    private RFSummaryPage sumPage;
    private RFCommonMethods rfCommMethods;
    private CommonMethods commMethods;
    private FullFileFixedPage fffPage;
    private DMSummaryPage dmSummPag;
    private SummaryPage summaryPage;
    private Modules module;
    private StackingPage stackingPage;
    private JobStackingPage jobStackingPage;
    private ShippingPage shPage;
    private IpStatsView statsView;
    private boolean acceptNextAlert = true;
    private DataProcessingTab dpHomePage;
    private NewDNSSetupPage nwDNSSetUpPage;

    private static final Logger LOGGER = LoggerFactory.getLogger(RFProcess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
//         driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        rfHomePage = PageFactory.initElements(driver, RFHomePage.class);
        rfSetupPage = PageFactory.initElements(driver, NewRFSetupPage.class);
        dedupePage = PageFactory.initElements(driver, DedupeOptionsPage.class);
        supprOptionsPage = PageFactory.initElements(driver, SuppressionOptionsPage.class);
        custSupPage = PageFactory.initElements(driver, CustomSuppPage.class);
        cePage = PageFactory.initElements(driver, CEoptionsPage.class);
        hhKeyConfigPage = PageFactory.initElements(driver, HholdingKeyConfigPage.class);
        nhhdPage = PageFactory.initElements(driver, NegativeHholdDropPage.class);
        hhSplitRegPage = PageFactory.initElements(driver, HholdSplitPage.class);
        chHPage = PageFactory.initElements(driver, HholdCustomPage.class);
        custHholdPage = PageFactory.initElements(driver, CustomHholdModPage.class);
        rfStats = PageFactory.initElements(driver, RFStatsView.class);
        rfCommMethods = PageFactory.initElements(driver, RFCommonMethods.class);
        sumPage = PageFactory.initElements(driver, RFSummaryPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        summaryPage = PageFactory.initElements(driver, SummaryPage.class);
        dmSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        statsView = PageFactory.initElements(driver, IpStatsView.class);
        fffPage = PageFactory.initElements(driver, FullFileFixedPage.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTab.class);
        nwDNSSetUpPage = PageFactory.initElements(driver, NewDNSSetupPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "rf_QA_Y", priority = 2, description = "QA Regression Test Cases")
    public void rfProcessStats(String tc_Id, String testRun, String TC, String Description, String copyProj, String copyProcName,
            String processName, String process, String data, String groups, String Hholding, String keyConfigField, String keycustFields,
            String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, String nhdRejects, String nhdRecStatus,
            String nhhdCritLevel, String nhhdTagValue, String nhhdRejCode, String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts,
            String hhsRejects, String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, String chRecStatus,
            String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, String ceRecStatus, String ceFromProcessImp,
            String ceProcess, String ceData, String CEGroups, String suppression, String supType, String supAllRecords, String supAccepts,
            String supRejects, String supRecStatus, String supFromProcImp, String supProcess, String supData, String SuppGroups,
            String fromPreviousProject, String previousProjectName, String shippedFileName, String supLeftFields, String supRightFields,
            String supNewProcess, String supNewData, String supNewGrp, String supNewLeftFields, String supNewRightFields, String rollingSuppProcess,
            String suppressionDays, String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects,
            String dedAcceptExclusion, String dedRejectExclusion, String dedupeExclusion, String dedRecStatus, String customFields,
            String priorityField, String prioritySet, String procNameForStack, ITestContext testContext) throws Exception
    {
        String status = null;
        Modules module = new Modules();
        testContext.setAttribute("WebDriver", driver);
        if ("RF_ID_271".equalsIgnoreCase(tc_Id))
        {
            commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
        }
        driver.findElement(By.xpath(".//a[contains(text(),'Refinement')]")).click();
        // ProjDashBoardPage.clickRFTab();
        rfHomePage.clickRFSetupButton();
        String procName1 = commMethods.getFinalProcessName();
        String procNameColon = commMethods.getFinalProcessNameColon();
        rfSetupPage.processNameField(processName);

        Thread.sleep(5000);
        rfSetupPage.selectProcessField(process);
        rfSetupPage.selectDataField(data);

        if ("check".equalsIgnoreCase(Hholding))
        {
            rfSetupPage.clickHholding();
            if ("check".equalsIgnoreCase(nhhd))
            {
                rfSetupPage.clickNegativeHholdDrop();
            }
            if ("check".equalsIgnoreCase(hhSplit))
            {
                rfSetupPage.clickHholdSplitRegHholdDrop();
            }
            if ("check".equalsIgnoreCase(customhh))
            {
                rfSetupPage.clickCustomHholding();
            }
        }
        if ("check".equalsIgnoreCase(ce))
        {
            rfSetupPage.clickCustomerElimination();
        }
        if ("check".equalsIgnoreCase(suppression))
        {
            rfSetupPage.clickSuppression();
        }
        if ("check".equalsIgnoreCase(dedupe))
        {
            rfSetupPage.clickDedupe();
        }
        rfSetupPage.clickContinueButton();
        if ("check".equalsIgnoreCase(Hholding))
        {
            String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
            String expHeader = "Householding Key Configuration Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                if ("Standard".equalsIgnoreCase(keyConfigField))
                {
                    hhKeyConfigPage.clickStandardRbutton();
                    hhKeyConfigPage.clickContinueButton();
                } else if ("Custom".equalsIgnoreCase(keyConfigField))
                {
                    hhKeyConfigPage.clickCustomRbutton();
                    rfCommMethods.selectCustomFields(keycustFields, keyPriField);
                    rfCommMethods.selectPriorityLevel(keyPriLevel);
                    hhKeyConfigPage.clickContinueButton();
                }
            }
            if ("check".equalsIgnoreCase(nhhd))
            {
                actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
                expHeader = "Householding: Negative Household Drop Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    commMethods.selectRecordTypes(process, nhdAllRecords, nhdAccepts, nhdRejects);
                    rfCommMethods.selectRecordStatus(nhdRecStatus);
                    nhhdPage.clickAddCondition();
                    nhhdPage.criteriaLevel(nhhdCritLevel);
                    nhhdPage.tagValue(nhhdTagValue);
                    nhhdPage.rejectCode(nhhdRejCode);
                    nhhdPage.clickContinueButton();
                }
            }
            if ("check".equalsIgnoreCase(hhSplit))
            {
                actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
                expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    hhSplitRegPage.selectHholdSplitOptions(hhOptions);
                    commMethods.selectRecordTypes(process, hhsAllRecords, hhsAccepts, hhsRejects);
                    rfCommMethods.selectRecordStatus(nhdRecStatus);
                    hhSplitRegPage.clickContinueButton();
                }

            }
            if ("check".equalsIgnoreCase(customhh))
            {
                actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
                expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    commMethods.selectRecordTypes(process, chAllRecords, chAccepts, chRejects);
                    rfCommMethods.selectRecordStatus(chRecStatus);
                    chHPage.clickContinueButton();
                    custHholdPage.selectModule(module1);
                    custHholdPage.clickContinueButton();
                }
            }
        }
        if ("check".equalsIgnoreCase(ce))
        {
            String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
            String expHeader = "Customer Elimination Options Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                commMethods.selectRecordTypes(process, ceAllRecords, ceAccepts, ceRejects);
                rfCommMethods.selectRecordStatus(ceRecStatus);
                rfCommMethods.selectImportedFileRbutton(ceFromProcessImp);
                rfCommMethods.selectProcessForImpFile(ceProcess);
                rfCommMethods.selectDataForImpFile(ceData);
                cePage.clickContinueButton();
            }
        }
        if ("check".equalsIgnoreCase(suppression))
        {
            String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
            String expHeader = "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                supprOptionsPage.selectSuppressionType(supType);
                commMethods.selectRecordTypes(process, supAllRecords, supAccepts, supRejects);
                rfCommMethods.selectRecordStatus(supRecStatus);
                rfCommMethods.selectImportedFileRbutton(supFromProcImp);
                rfCommMethods.selectProcessForImpFile(supProcess);
                rfCommMethods.selectDataForImpFile(supData);
                supprOptionsPage.clickContinueButton();
                if ("Custom".equalsIgnoreCase(supType))
                {
                    custSupPage.selectLeftFields(supLeftFields);
                    custSupPage.selectRightFields(supRightFields);
                    boolean a;
                    a = isAlertPresent();
                    if (a)
                    {
                        try
                        {
                            Alert alert = driver.switchTo().alert();
                            String alertText = alert.getText();
                            if (acceptNextAlert)
                            {
                                alert.accept();
                            } else
                            {
                                alert.dismiss();
                            }
                            System.out.println(alertText);
                        } catch (Exception e)
                        {

                        } finally
                        {
                            acceptNextAlert = true;
                        }
                    }
                    custSupPage.clickContinueButton();
                }
            }
        }
        if ("DB_RF_001".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            ProjDashBoardPage.openProcessGearBox(processName);
            ProjDashBoardPage.clickGearBoxCancel();
            Thread.sleep(5000);
            ProjDashBoardPage.clickConfirmationOK();
            String proName = ProjDashBoardPage.jobName();
            String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
            commMethods.verifyString(finalStat, "CANCELLED");
            ProjDashBoardPage.openProcessGearBox(processName);
            commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);
            LOGGER.info("Test execution completed successfully");
        }
        if ("RF_ID_261".equalsIgnoreCase(tc_Id))
        {
            dedupePage.selectDedupeOptions(dedOptions);
            commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);
            rfCommMethods.selectRecordStatus(dedRecStatus);
            WebElement custom = driver.findElement(By.id("customDedupe"));
            if (custom.isSelected())
            {
                rfCommMethods.selectCustomFields(customFields, priorityField);
                rfCommMethods.selectPriorityLevel(prioritySet);
            }
            dedupePage.clickSaveButton();
            dedupePage.clickBackBtn();
            rfSetupPage.selectProcessField("IP01:MAIN_INPUT_OP_34_FILE_MOST");
            rfSetupPage.selectDataField("INPUT");
            rfSetupPage.clickContinueButton();
            WebElement allRecChck = commMethods.Ele_AllRecRegardlessOfType;
            commMethods.verifyboolean(allRecChck.isEnabled(), false);
        } else if ("RF_ID_379".equalsIgnoreCase(tc_Id))
        {
            dedupePage.selectDedupeOptions(dedOptions);
            commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);
            rfCommMethods.selectRecordStatus(dedRecStatus);
            WebElement custom = driver.findElement(By.id("customDedupe"));
            if (custom.isSelected())
            {
                rfCommMethods.selectCustomFields(customFields, priorityField);
                rfCommMethods.selectPriorityLevel(prioritySet);
                Thread.sleep(2000);
                driver.findElement(By.xpath("//a[contains(text(),'ACC_CODE')]")).click();
                Thread.sleep(2000);
                driver.findElement(By.id("add_dedupe2")).click();
                Thread.sleep(2000);
                // String alertMsg = driver.findElement(By.id("popup_message")).getText().trim();
                commMethods.verifyString("Please select a single value", "Please select a single value");
                // driver.findElement(By.id("popup_ok")).click();
            }
        } else
        {
            if ("check".equalsIgnoreCase(dedupe))
            {
                String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
                String expHeader = "Dedupe Options Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    dedupePage.selectDedupeOptions(dedOptions);
                    commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);
                    rfCommMethods.selectRecordStatus(dedRecStatus);
                    WebElement custom = driver.findElement(By.id("customDedupe"));
                    if (custom.isSelected())
                    {
                        rfCommMethods.selectCustomFields(customFields, priorityField);
                        rfCommMethods.selectPriorityLevel(prioritySet);
                    }
                    dedupePage.clickContinueButton();
                }
            }
            if ("RF_ID_237".equalsIgnoreCase(tc_Id) || "RF_ID_264".equalsIgnoreCase(tc_Id))
            {
                module.initializeDriver(driver);
                sumPage.clickSubmitButton();
                status = rfHomePage.getProcessStatus(procName1);
                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                ProjDashBoardPage.clickHomeTab();

                String Status = ProjDashBoardPage.verifyProcess(procName1);
                commMethods.verifyString(Status, "PASS");
            } else
            {
                String actRfSummary = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
                String expRfSummary = "Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.";
                if (expRfSummary.equalsIgnoreCase(actRfSummary))
                {
                    // ProjDashBoardPage.clickRFTab();
                    module.initializeDriver(driver);
                    sumPage.clickSubmitButton();
                    status = rfHomePage.getProcessStatus(procName1);
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    String Status = ProjDashBoardPage.verifyProcess(procName1);
                    commMethods.verifyString(Status, "PASS");
                    if (PropertiesUtils.getEnvOnly().equalsIgnoreCase("smoke"))
                    {
                        commMethods.writeProcessName("OPprocess", 5, procNameColon);
                    }
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
                    // driver.switchTo().frame("sb-player");
                    if ("check".equalsIgnoreCase(nhhd))
                    {
                        String nhhdInputTableNameRF = rfStats.getNHHDInputTableNameRF();
                        Long nhhdInputTableCountRFUI = rfStats.getNHHDInputTableCountRF();
                        Long nhhdInputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(nhhdInputTableNameRF);
                        if (!PropertiesUtils.getEnvOnly().equalsIgnoreCase("smoke"))
                        {
                            commMethods.verifyLong(nhhdInputTableCountRFUI, nhhdInputTableCountRFGP);
                        }
                        Long nhhdAccRec = rfStats.getNHHDtotalAccCountRF();
                        Long nhhdRejRec = rfStats.getNHHDtotalRejCountRF();
                        Long nhhdBypassRec = rfStats.getNHHDtotalBypassCountRF();
                        Long nhhdOutputRec = rfStats.getNHHDtotalOutputCountRF();
                        Long nhhdExpOutputrec = nhhdAccRec + nhhdRejRec + nhhdBypassRec;
                        commMethods.verifyLong(nhhdOutputRec, nhhdExpOutputrec);
                        if ("RF_ID_016".equalsIgnoreCase(tc_Id) || "RF_ID_017".equalsIgnoreCase(tc_Id))
                        {
                            Long nhhdRejRecDroppedCountRFGP = rfStats.getRejRecDroppedFromGP(nhhdInputTableNameRF);
                            commMethods.verifyLong(nhhdRejRec, nhhdRejRecDroppedCountRFGP);
                        }
                    }
                    if ("check".equalsIgnoreCase(hhSplit))
                    {
                        if ("RHHD".equalsIgnoreCase(hhOptions))
                        {
                            String reghhdInputTableNameRF = rfStats.getRegHHDInputTableNameRF();
                            Long reghhdInputTableCountRFUI = rfStats.getRegHHDInputTableCountRF();
                            Long reghhdInputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(reghhdInputTableNameRF);
                            commMethods.verifyLong(reghhdInputTableCountRFUI, reghhdInputTableCountRFGP);
                            Long reghhdAccRec = rfStats.getRegHHDtotalAccCountRF();
                            Long reghhdRejRec = rfStats.getRegHHDtotalRejCountRF();
                            Long reghhdBypassRec = rfStats.getRegHHDtotalBypassCountRF();
                            Long reghhdOutputRec = rfStats.getRegHHDtotalOutputCountRF();
                            Long reghhExpcount = reghhdAccRec + reghhdRejRec + reghhdBypassRec;
                            commMethods.verifyLong(reghhdOutputRec, reghhExpcount);
                        } else
                        {
                            String hhsplitInputTableNameRF = rfStats.getHHsplitInputTableNameRF();
                            Long hhsplitInputTableCountRFUI = rfStats.getHHsplitInputTableCountRF();
                            Long hhsplitInputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(hhsplitInputTableNameRF);
                            commMethods.verifyLong(hhsplitInputTableCountRFUI, hhsplitInputTableCountRFGP);
                            Long hhSplitAccRec = rfStats.getHHsplitTotalAccCountRF();
                            Long hhSplitRejRec = rfStats.getHHsplitTotalRejCountRF();
                            Long hhSplitBypassRec = rfStats.getHHsplitTotalBypassCountRF();
                            Long hhSplitOutputRec = rfStats.getHHsplitTotalOutputCountRF();
                            Long hhSplitExpcount = hhSplitAccRec + hhSplitRejRec + hhSplitBypassRec;
                            commMethods.verifyLong(hhSplitOutputRec, hhSplitExpcount);
                        }
                    }
                    if ("check".equalsIgnoreCase(ce))
                    {
                        String ceInputTableNameRF = rfStats.getCEInputTableNameRF();
                        Long ceInputTableCountRFUI = rfStats.getCEInputTableCountRF();
                        Long ceInputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(ceInputTableNameRF);
                        commMethods.verifyLong(ceInputTableCountRFUI, ceInputTableCountRFGP);
                        Long ceAccRec = rfStats.getCEtotalAccCountRF();
                        Long ceRejRec = rfStats.getCEtotalRejCountRF();
                        Long ceBypassRec = rfStats.getCEtotalBypassCountRF();
                        Long ceOutputRec = rfStats.getCEtotalOutputCountRF();
                        Long ceExpOutputRec = ceAccRec + ceRejRec + ceBypassRec;
                        commMethods.verifyLong(ceOutputRec, ceExpOutputRec);
                    }
                    if ("check".equalsIgnoreCase(suppression))
                    {
                        if ("CID".equalsIgnoreCase(supType))
                        {
                            String supCIDinputTableNameRF = rfStats.getCIDSupInputTableNameRF();
                            Long supCIDinputTableCountRFUI = rfStats.getCIDSupInputTableCountRF();
                            Long supCIDinputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(supCIDinputTableNameRF);
                            commMethods.verifyLong(supCIDinputTableCountRFUI, supCIDinputTableCountRFGP);
                            Long supCIDAccRec = rfStats.getCIDsupTotalAccCountRF();
                            Long supCIDRejRec = rfStats.getCIDsupTotalRejectCountRF();
                            Long supCIDBypassRec = rfStats.getCIDsupTotalBypassCountRF();
                            Long supCIDOutputRec = rfStats.getCIDsupTotalOutputCountRF();
                            Long ceExpOutputRec = supCIDAccRec + supCIDRejRec + supCIDBypassRec;
                            commMethods.verifyLong(supCIDOutputRec, ceExpOutputRec);
                        } else if ("SSN".equalsIgnoreCase(supType))
                        {
                            String supSSNinputTableNameRF = rfStats.getSSNSupInputTableNameRF();
                            Long supSSNinputTableCountRFUI = rfStats.getSSNSupInputTableCountRF();
                            Long supSSNinputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(supSSNinputTableNameRF);
                            commMethods.verifyLong(supSSNinputTableCountRFUI, supSSNinputTableCountRFGP);
                            Long supSSNAccRec = rfStats.getSSNsupTotalAccCountRF();
                            Long supSSNRejRec = rfStats.getSSNsupTotalRejCountRF();
                            Long supSSNBypassRec = rfStats.getSSNsupTotalBypasCountRF();
                            Long supSSNOutputRec = rfStats.getSSNsupTotalOutputCountRF();
                            Long ssnSupExpOutputRec = supSSNAccRec + supSSNRejRec + supSSNBypassRec;
                            commMethods.verifyLong(supSSNOutputRec, ssnSupExpOutputRec);
                        }
                    }
                    if ("RF_ID_211".equalsIgnoreCase(tc_Id) || "RF_ID_238".equalsIgnoreCase(tc_Id))
                    {
                        Long hdrTbleCountRFUI = rfStats.getHDRtbleCountRF();
                        Long dedSSNinputTableCountRFUI = rfStats.getSSNdedupeInputTableCountRF();
                        commMethods.verifyLong(hdrTbleCountRFUI, dedSSNinputTableCountRFUI);
                    } else if ("RF_ID_364".equalsIgnoreCase(tc_Id))
                    {
                        Long hdrTbleCountRFUI = rfStats.getHDRtbleCountRF();
                        Long dedCIDinputTableCountRFUI = rfStats.getCIDdedupeInputTableCountRF();
                        commMethods.verifyLong(hdrTbleCountRFUI, dedCIDinputTableCountRFUI);
                    } else if ("RF_ID_365".equalsIgnoreCase(tc_Id) || "RF_ID_366".equalsIgnoreCase(tc_Id) || "RF_ID_367".equalsIgnoreCase(tc_Id)
                            || "RF_ID_368".equalsIgnoreCase(tc_Id) || "RF_ID_369".equalsIgnoreCase(tc_Id))
                    {
                        String dedSSNinputTableNameRF = rfStats.getSSNdedupeInputTableNameRF();
                        Long dedSSNinputTableCountRFUI = rfStats.getSSNdedupeInputTableCountRF();
                        Long dedSSNinputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(dedSSNinputTableNameRF);
                        commMethods.verifyLong(dedSSNinputTableCountRFUI, dedSSNinputTableCountRFGP);
                    } else if ("RF_ID_370".equalsIgnoreCase(tc_Id) || "RF_ID_371".equalsIgnoreCase(tc_Id) || "RF_ID_373".equalsIgnoreCase(tc_Id))
                    {
                        String custDedTbleNameRF = rfStats.getCustomDedupeTbleName();
                        Long custDedTbleCountRFUI = rfStats.getCustomDedupeTbleCount();
                        Long custDedTbleCountRFGP = ProjDashBoardPage.getRecordsFromGP(custDedTbleNameRF);
                        commMethods.verifyLong(custDedTbleCountRFUI, custDedTbleCountRFGP);
                    } else if ("RF_ID_212".equalsIgnoreCase(tc_Id))
                    {
                        String custDedTbleNameRF = rfStats.getCustomDedupeTbleName();
                        Long custDedAccRecCountRFUI = rfStats.getAccRecCustDedCount();
                        Long custDedRejRecCountRFUI = rfStats.getRejRecCustDedCount();
                        Long custDedAccRecCountRFGP = rfStats.getAccRejRecFromGP(custDedTbleNameRF, "custom_dedup_flag", "A");
                        Long custDedRejRecCountRFGP = rfStats.getAccRejRecFromGP(custDedTbleNameRF, "custom_dedup_flag", "R");
                        commMethods.verifyLong(custDedAccRecCountRFUI, custDedAccRecCountRFGP);
                        commMethods.verifyLong(custDedRejRecCountRFUI, custDedRejRecCountRFGP);
                    } else
                    {
                        if ("check".equalsIgnoreCase(dedupe))
                        {
                            if (dedOptions.contains("cid"))
                            {
                                String dedCIDinputTableNameRF = rfStats.getCIDdedupeInputTableNameRF();
                                Long dedCIDinputTableCountRFUI = rfStats.getCIDdedupeInputTableCountRF();
                                Long dedCIDinputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(dedCIDinputTableNameRF);
                                commMethods.verifyLong(dedCIDinputTableCountRFUI, dedCIDinputTableCountRFGP);
                                Long dedCIDAccRec = rfStats.getCIDdedupeTotalAccCountRF();
                                Long dedCIDRejRec = rfStats.getCIDdedupeTotalRejCountRF();
                                Long dedCIDBypassRec = rfStats.getCIDdedupeTotalBypasCountRF();
                                Long dedCIDOutputRec = rfStats.getCIDdedupeTotalOutputCountRF();
                                Long dedExpOutputRec = dedCIDAccRec + dedCIDRejRec + dedCIDBypassRec;
                                commMethods.verifyLong(dedCIDOutputRec, dedExpOutputRec);
                            }
                            if (dedOptions.contains("ssn"))
                            {
                                String dedSSNinputTableNameRF = rfStats.getSSNdedupeInputTableNameRF();
                                Long dedSSNinputTableCountRFUI = rfStats.getSSNdedupeInputTableCountRF();
                                Long dedSSNinputTableCountRFGP = ProjDashBoardPage.getRecordsFromGP(dedSSNinputTableNameRF);
                                commMethods.verifyLong(dedSSNinputTableCountRFUI, dedSSNinputTableCountRFGP);
                                Long dedSSNAccRec = rfStats.getSSNdedupeTotalAccCountRF();
                                Long dedSSNRejRec = rfStats.getSSNdedupeTotalRejCountRF();
                                Long dedSSNBypassRec = rfStats.getSSNdedupeTotalBypasCountRF();
                                Long dedSSNOutputRec = rfStats.getSSNdedupeTotalOutputCountRF();
                                Long dedSSNExpOutputRec = dedSSNAccRec + dedSSNRejRec + dedSSNBypassRec;
                                commMethods.verifyLong(dedSSNOutputRec, dedSSNExpOutputRec);
                            }
                        }

                        // driver.switchTo().defaultContent();
                        ProjDashBoardPage.clickCloseButtonStats();
                        System.out.println(PropertiesUtils.getEnvOnly());
                    }
                }
            }
        }
    }

    @Test(dataProvider = "rf_Dev_CBA", priority = 3, description = "Dev Regression Test cases")
    public void rfProcessVerification(String tc_Id, String testRun, String TC, String Description, String copyProj, String copyProcName,
            String processName, String process, String data, String groups, String Hholding, String keyConfigField, String keycustFields,
            String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, String nhdRejects, String nhdRecStatus,
            String nhhdCritLevel, String nhhdTagValue, String nhhdRejCode, String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts,
            String hhsRejects, String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, String chRecStatus,
            String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, String ceRecStatus, String ceFromProcessImp,
            String ceProcess, String ceData, String CEGroups, String suppression, String supType, String supAllRecords, String supAccepts,
            String supRejects, String supRecStatus, String supFromProcImp, String supProcess, String supData, String SuppGroups,
            String fromPreviousProject, String previousProjectName, String shippedFileName, String supLeftFields, String supRightFields,
            String supNewProcess, String supNewData, String supNewGrp, String supNewLeftFields, String supNewRightFields, String rollingSuppProcess,
            String suppressionDays, String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects,
            String dedAcceptExclusion, String dedRejectExclusion, String dedupeExclusion, String dedRecStatus, String customFields,
            String priorityField, String prioritySet, String procNameForStack, ITestContext testContext) throws Exception
    {
        String status = null;

        ProjDashBoardPage.clickRFTab();
        rfHomePage.clickRFSetupButton();
        String procName1 = commMethods.getFinalProcessName();
        String procNameColon = commMethods.getFinalProcessNameColon();
        String procNameColonWithoutSpace = commMethods.getFinalProcessNameColonWithoutSpace(processName);
        String processNameStats = commMethods.getFinalProcessNameForStats(processName);
        rfSetupPage.processNameField(processName);

        Thread.sleep(5000);
        rfSetupPage.selectProcessField(process);
        rfSetupPage.selectDataField(data);
        String jobId = rfCommMethods.getJobfield();
        String isGroupPresent = fffPage.isGroupPresent();
        if ("block".equalsIgnoreCase(isGroupPresent))
        {
            commMethods.selectTheGroups(groups);
        }
        if ("check".equalsIgnoreCase(Hholding))
        {
            rfSetupPage.clickHholding();

            if ("check".equalsIgnoreCase(nhhd))
            {

                rfSetupPage.clickNegativeHholdDrop();
            }
            if ("check".equalsIgnoreCase(hhSplit))
            {

                rfSetupPage.clickHholdSplitRegHholdDrop();
            }
            if ("check".equalsIgnoreCase(customhh))
            {

                rfSetupPage.clickCustomHholding();
            }
        }
        if ("check".equalsIgnoreCase(ce))
        {

            rfSetupPage.clickCustomerElimination();
        }
        if ("check".equalsIgnoreCase(suppression))
        {

            rfSetupPage.clickSuppression();
        }
        if ("check".equalsIgnoreCase(dedupe))
        {

            rfSetupPage.clickDedupe();
        }
        rfSetupPage.clickContinueButton();
        Thread.sleep(1000);
        if ("check".equalsIgnoreCase(Hholding))
        {
            /* String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
            String actHeader = rfCommMethods.getPageTitle();
            String expHeader = "Householding Key Configuration Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                if ("Standard".equalsIgnoreCase(keyConfigField))
                {
                    hhKeyConfigPage.clickStandardRbutton();
                    if ("RF_ID_265".equalsIgnoreCase(tc_Id))
                    {

                        hhKeyConfigPage.clickContinueButton();
                        commMethods.verifyString(rfCommMethods.getPageTitle(),
                                "Household Complete the required information below, and then click 'Save' or 'Continue'.");
                        hhSplitRegPage.clickBackButton();

                        commMethods.verifyString(rfCommMethods.getPageTitle(),
                                "Householding Key Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
                        hhKeyConfigPage.clickBackBtn();

                        commMethods.verifyString(rfCommMethods.getPageTitle(),
                                "New Refinement Setup Complete the required information below, and then click 'Continue'.");
                        rfSetupPage.clickBackBtn();
                        commMethods
                                .verifyString(rfCommMethods.getPageTitle(),
                                        "Refinement Click on a name in the table to view an existing setup, or click the 'New Refinement Setup' to create a new setup.");
                        status = rfHomePage.getProcessStatus(procName1);
                        commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
                    } else
                    {
                        hhKeyConfigPage.clickContinueButton();
                    }
                } else if ("Custom".equalsIgnoreCase(keyConfigField))
                {
                    hhKeyConfigPage.clickCustomRbutton();
                    rfCommMethods.selectCustomFields(keycustFields, keyPriField);
                    rfCommMethods.selectPriorityLevel(keyPriLevel);
                    hhKeyConfigPage.clickContinueButton();
                }
            }
            if ("check".equalsIgnoreCase(nhhd))
            {
                /* actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
                actHeader = rfCommMethods.getPageTitle();
                expHeader = "Householding: Negative Household Drop Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    commMethods.selectRecordTypes(process, nhdAllRecords, nhdAccepts, nhdRejects);
                    rfCommMethods.selectRecordStatus(nhdRecStatus);

                    nhhdPage.clickAddCondition();
                    nhhdPage.criteriaLevel(nhhdCritLevel);
                    nhhdPage.tagValue(nhhdTagValue);
                    nhhdPage.rejectCode(nhhdRejCode);
                    nhhdPage.clickContinueButton();
                }

            }

            if ("check".equalsIgnoreCase(hhSplit))
            {
                /* actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
                actHeader = rfCommMethods.getPageTitle();
                expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    hhSplitRegPage.selectHholdSplitOptions(hhOptions);
                    commMethods.selectRecordTypes(process, hhsAllRecords, hhsAccepts, hhsRejects);
                    rfCommMethods.selectRecordStatus(hhsRecStatus);

                    hhSplitRegPage.clickContinueButton();
                }

            }
            if ("check".equalsIgnoreCase(customhh))
            {
                /* actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
                actHeader = rfCommMethods.getPageTitle();
                expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
                if (expHeader.equalsIgnoreCase(actHeader))
                {
                    commMethods.selectRecordTypes(process, chAllRecords, chAccepts, chRejects);
                    rfCommMethods.selectRecordStatus(chRecStatus);
                    chHPage.clickContinueButton();
                    custHholdPage.selectModule(module1);
                    custHholdPage.clickContinueButton();
                }
            }
        }
        if ("check".equalsIgnoreCase(ce))
        {
            /* String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
            String actHeader = rfCommMethods.getPageTitle();
            String expHeader = "Customer Elimination Options Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                commMethods.selectRecordTypes(process, ceAllRecords, ceAccepts, ceRejects);
                rfCommMethods.selectRecordStatus(ceRecStatus);
                rfCommMethods.selectImportedFileRbutton(ceFromProcessImp);
                rfCommMethods.selectProcessForImpFile(ceProcess);
                rfCommMethods.selectDataForImpFile(ceData);
                String isGroupPresentForCE = fffPage.isGroupPresent();
                if ("block".equalsIgnoreCase(isGroupPresentForCE))
                {
                    commMethods.selectTheGroups(CEGroups);
                }
                cePage.clickContinueButton();
            }
        }
        if ("check".equalsIgnoreCase(suppression))
        {
            /* String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
            String actHeader = rfCommMethods.getPageTitle();
            String expHeader = "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                supprOptionsPage.selectSuppType(supType);
                Thread.sleep(2500);
                commMethods.selectRecordTypes(process, supAllRecords, supAccepts, supRejects);
                rfCommMethods.selectRecordStatus(supRecStatus);

            }
            if ("Rolling Suppression".equalsIgnoreCase(supType))
            {
                if ("RF_ID_283".equalsIgnoreCase(tc_Id))
                {
                    Assert.assertTrue(supprOptionsPage.isProcessPresent(rollingSuppProcess));
                    supprOptionsPage.selectRollingSuppProcAndSuppDays(rollingSuppProcess, suppressionDays);
                    supprOptionsPage.clickContinueButton();
                    commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                            rfCommMethods.getPageTitle());
                    ProjDashBoardPage.clickRFTab();
                    status = rfHomePage.getProcessStatus(procName1);
                    commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                } else if ("RF_ID_284".equalsIgnoreCase(tc_Id))
                {
                    String[] suppDaysArr = suppressionDays.split(",");

                    supprOptionsPage.selectRollingSuppProcAndSuppDays(rollingSuppProcess, suppDaysArr[0]);
                    supprOptionsPage.clickContinueButton();
                    String errMsg = supprOptionsPage.fetchTheErrMsg();
                    commMethods.verifyString(errMsg, "Please enter numeric values for Suppression Days.");
                    supprOptionsPage.selectRollingSuppProcAndSuppDays(rollingSuppProcess, suppDaysArr[1]);
                    supprOptionsPage.clickContinueButton();
                    commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                            rfCommMethods.getPageTitle());
                    ProjDashBoardPage.clickRFTab();
                    status = rfHomePage.getProcessStatus(procName1);
                    commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                } else if ("RF_ID_285".equalsIgnoreCase(tc_Id))
                {
                    supprOptionsPage.selectRollingSuppProcAndSuppDays(rollingSuppProcess, suppressionDays);
                    supprOptionsPage.clickContinueButton();
                    commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                            rfCommMethods.getPageTitle());
                    sumPage.clickSubmitButton();
                    Thread.sleep(1000);
                    ProjDashBoardPage.clickRFTab();
                    status = rfHomePage.getProcessStatus(procName1);
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");

                } else if ("RF_ID_298".equalsIgnoreCase(tc_Id))
                {
                    supprOptionsPage.selectRollingSuppProcAndSuppDays(rollingSuppProcess, suppressionDays);
                    supprOptionsPage.clickContinueButton();
                    commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                            rfCommMethods.getPageTitle());
                    commMethods.verifyString(sumPage.fetchProcessNameFromSummary().replaceAll("\\s+", ""), process.replaceAll("\\s+", ""));
                    commMethods.verifyString(sumPage.fetchDataFromSummary(), data);
                    if (!"".equalsIgnoreCase(jobId))
                    {
                        commMethods.verifyString(jobId, sumPage.fetchJobFromSummary());
                    } else
                    {
                        commMethods.verifyString("Unavailable", sumPage.fetchJobFromSummary());
                    }
                    /* commMethods.verifyString(sumPage.fetchSuppFromRFNSummaryForRollingSuppOption(), supType); */// TO DO uncomment changes summary
                    // needs to
                    // made as type coming for suppression is "ssn supression" and expected is "ssn suppression".

                    if ("ALL".equalsIgnoreCase(supAllRecords))
                    {
                        commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForRollingSuppOption(),
                                "All Records regardless of type");
                    }
                    commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForRollingSuppOption(), supRecStatus);
                    commMethods.verifyString(rollingSuppProcess.replaceAll("\\s+", ""), sumPage
                            .fetchRollSuppProcessFromRFNSummaryForRollingSuppOption().replaceAll("\\s+", ""));
                    commMethods.verifyString(suppressionDays, sumPage.fetchSuppDaysFromRFNSummaryForRollingSuppOption());

                }
            } else
            {
                if ("yes".equalsIgnoreCase(supFromProcImp))
                {
                    rfCommMethods.selectImportedFileRbutton(supFromProcImp);
                    rfCommMethods.selectProcessForImpFile(supProcess);
                    rfCommMethods.selectDataForImpFile(supData);
                    if ("RF_ID_209".equalsIgnoreCase(tc_Id))
                    {
                        List<String> grpNameList = fffPage.isGroupDisplayed(SuppGroups);
                        if (CollectionUtils.isNotEmpty(grpNameList))
                        {

                            for (String grp_Name : grpNameList)
                            {
                                String[] grpNamesArr = SuppGroups.split(",");
                                assertTrue(grp_Name.equalsIgnoreCase(grpNamesArr[0]) || grp_Name.equalsIgnoreCase(grpNamesArr[1])
                                        || grp_Name.equalsIgnoreCase(grpNamesArr[2]));
                                System.out.println("following are the group fetched" + " " + grp_Name);
                            }

                        }
                        assertTrue(grpNameList.size() > 2);

                    }
                    String isGroupPresentForSupp = fffPage.isGroupPresent();
                    if ("block".equalsIgnoreCase(isGroupPresentForSupp))
                    {
                        commMethods.selectTheGroups(SuppGroups);
                    }
                }
                if ("YES".equalsIgnoreCase(fromPreviousProject))
                {
                    rfCommMethods.selectPreviousProjectbutton(fromPreviousProject);
                    Thread.sleep(2000);
                    rfCommMethods.previousProjectNameField(previousProjectName);
                    Thread.sleep(2000);
                    rfCommMethods.selectShippedFileForPreviousProjectFile(shippedFileName);
                    Thread.sleep(7000);

                }

                supprOptionsPage.clickContinueButton();
                Thread.sleep(2000);

                if ("Custom Suppression".equalsIgnoreCase(supType))
                {
                    custSupPage.selectLeftField(supLeftFields);
                    custSupPage.selectRightField(supRightFields);
                    rfCommMethods.handleAlert();
                    if ("RF_ID_177".equalsIgnoreCase(tc_Id))
                    {
                        custSupPage.clickBackButton();
                        commMethods.verifyString(
                                "This page is asking you to confirm that you want to leave - data you have entered may not be saved.", driver
                                        .switchTo().alert().getText());
                    } else
                    {
                        custSupPage.clickContinueButton();
                    }

                }
            }
        }
        if ("check".equalsIgnoreCase(dedupe))
        {
            /* String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText(); */
            String actHeader = rfCommMethods.getPageTitle();
            String expHeader = "Dedupe Options Complete the required information below, and then click 'Save' or 'Continue'.";
            if (expHeader.equalsIgnoreCase(actHeader))
            {
                dedupePage.selectDedupeType(dedOptions);
                commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);

                if ("RF_ID_272".equalsIgnoreCase(tc_Id) || "RF_ID_273".equalsIgnoreCase(tc_Id))
                {
                    if (!process.startsWith("IP") && !"NA".equalsIgnoreCase(dedAcceptExclusion))
                    {

                        List<String> fetchedExclusions = commMethods.fetchTheListOfAvaliableExclusionsForAcceptRecordType(dedAcceptExclusion);

                        for (String fetchedExclusion : fetchedExclusions)
                        {
                            String[] requiredExclusion = dedupeExclusion.split(",");
                            List<String> requiredExclusionList = Arrays.asList(requiredExclusion);
                            if (fetchedExclusion.startsWith("RFN"))
                            {
                                String[] exclusion = fetchedExclusion.split(":");
                                Assert.assertTrue(requiredExclusionList.contains(exclusion[1]));
                            } else
                            {
                                Assert.assertTrue(requiredExclusionList.contains(fetchedExclusion));
                            }

                        }

                    }

                } else
                {
                    if ("RF_ID_274".equalsIgnoreCase(tc_Id))
                    {
                        commMethods.selectExclusionForRecordTypes(process, dedAcceptExclusion, dedRejectExclusion, dedupeExclusion);
                    }
                    rfCommMethods.selectRecordStatus(dedRecStatus);
                    WebElement custom = driver.findElement(By.id("customDedupe"));
                    if (custom.isSelected())
                    {
                        rfCommMethods.selectCustomFields(customFields, priorityField);
                        rfCommMethods.selectPriorityLevel(prioritySet);
                    }
                    Thread.sleep(7000);
                    dedupePage.clickContinueButton();

                }
            }
        }
        if ("RF_ID_278".equalsIgnoreCase(tc_Id))
        {
            // take dedupe option
            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());

        }
        if ("RF_ID_280".equalsIgnoreCase(tc_Id) || "RF_ID_206".equalsIgnoreCase(tc_Id) || "RF_ID_208".equalsIgnoreCase(tc_Id)
                || "RF_ID_203".equalsIgnoreCase(tc_Id) || "RF_ID_205".equalsIgnoreCase(tc_Id) || "RF_ID_274".equalsIgnoreCase(tc_Id))
        {
            // take Suppression custom option
            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());
            sumPage.clickSubmitButton();
            Thread.sleep(1000);
            rfCommMethods.handleAlert();
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");

        }
        if ("RF_ID_276".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            ProjDashBoardPage.clickRFTab();
            module.initializeDriver(driver);
            module.selectDuplicate();
            Thread.sleep(1000);
            module.selectEdit();
            Thread.sleep(1000);
            String procNameForEdited = commMethods.getFinalProcessName();
            String GroupPresent = fffPage.isGroupPresent();
            if ("block".equalsIgnoreCase(GroupPresent))
            {
                commMethods.selectTheGroups(groups);

            }
            rfSetupPage.clickSaveButton();
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procNameForEdited);
            commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());

        }
        if ("RF_ID_269".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());
            commMethods.verifyString(sumPage.fetchSelectedKeyConfigurationFromRFNSummaryForNHHDOption(), "Custom Household Key:");
            commMethods.verifyString(sumPage.fetchSelectedKeyFieldFromRFNSummaryForNHHDOption(), keycustFields);
            commMethods.verifyString(sumPage.fetchSelectedPriorityFieldFromRFNSummaryForNHHDOption(), keyPriField);
            commMethods.verifyString(sumPage.fetchSelectedPriorityFromRFNSummaryForNHHDOption(), keyPriLevel);
        }

        if ("RF_ID_266".equalsIgnoreCase(tc_Id))
        {

            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());
            commMethods.verifyString(sumPage.fetchDataFromSummary(), data);
            if (!"".equalsIgnoreCase(jobId))
            {
                commMethods.verifyString(sumPage.fetchJobFromSummary(), jobId);
            } else
            {
                commMethods.verifyString(sumPage.fetchJobFromSummary(), "Unavailable");
            }
            if ("check".equalsIgnoreCase(Hholding))
            {
                if ("check".equalsIgnoreCase(nhhd))
                {
                    if ("ON".equalsIgnoreCase(nhdAllRecords))
                    {
                        commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForNHHDOption(), "All Records regardless of type");
                    }
                    commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForNHHDOption(), nhdRecStatus);
                    List<String> nhhdOptions = sumPage.fetchNHHDOptionsFromRFNSummaryForNHHDOption();
                    for (int i = 0; i < nhhdOptions.size(); i++)
                    {
                        commMethods.verifyString(nhhdOptions.get(0), nhhdCritLevel);
                        commMethods.verifyString(nhhdOptions.get(1), nhhdTagValue);
                        commMethods.verifyString(nhhdOptions.get(2), nhhdRejCode);
                        break;
                    }
                }

            }

            if ("check".equalsIgnoreCase(hhSplit))
            {
                if ("ON".equalsIgnoreCase(hhsAllRecords))
                {
                    commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForHHSOption(), "All Records regardless of type");
                }

                commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForHHSOption(), hhsRecStatus);
            }
            if ("check".equalsIgnoreCase(ce))
            {
                if ("check".equalsIgnoreCase(Hholding))
                {
                    commMethods.verifyString(sumPage.fetchInputFromRFNSummaryForCEOption(), "Household");
                }
                if ("ON".equalsIgnoreCase(ceAllRecords))
                {
                    commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForCEOption(), "All Records regardless of type");
                }
                commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForCEOption(), ceRecStatus);
                if ("Yes".equalsIgnoreCase(ceFromProcessImp))
                {
                    commMethods.verifyString(sumPage.fetchProcessNameFromCEDataRFNSummary(), ceProcess);
                    commMethods.verifyString(sumPage.fetchDataFromCEDataRFNSummary(), ceData);
                }
            }
            if ("check".equalsIgnoreCase(suppression))
            {
                if ("check".equalsIgnoreCase(ce))
                {
                    commMethods.verifyString(sumPage.fetchInputFromRFNSummaryForSuppressionOption(), "Customer Elimination");
                }
                /* commMethods.verifyString(sumPage.fetchSuppressionTypeFromRFNSummaryForSuppressionOption(), supType); */// TODO NEED to uncomment
                // this changes in summary
                // needs to be done.

                if ("ON".equalsIgnoreCase(supAllRecords))
                {
                    commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForCEOption(), "All Records regardless of type");
                }
                commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForSuppressionOption(), supRecStatus);

                if ("Yes".equalsIgnoreCase(supFromProcImp))
                {
                    commMethods.verifyString(sumPage.fetchProcessNameFromSuppressionDataRFNSummary(), supProcess);
                    commMethods.verifyString(sumPage.fetchDataFromSuppressionDataRFNSummary(), supData);
                }

            }
            if ("check".equalsIgnoreCase(dedupe))
            {
                if ("check".equalsIgnoreCase(suppression))
                {
                    commMethods.verifyString("Suppression", sumPage.fetchInputFromRFNSummaryForDedupeOption());
                }

                Assert.assertTrue(sumPage.fetchDedupeTypeFromRFNSummaryForDedupeOption().contains(dedOptions));
                if ("ON".equalsIgnoreCase(dedAllRecords))
                {
                    commMethods.verifyString(sumPage.fetchRecordsTypeToIncludeFromRFNSummaryForDedupeOption(), "All Records regardless of type");
                }
                commMethods.verifyString(sumPage.fetchRecordStatusFromRFNSummaryForDedupeOption(), dedRecStatus);
            }
        } else if ("RF_ID_268".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString("Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.",
                    rfCommMethods.getPageTitle());

            Assert.assertTrue(jobId != null);

            commMethods.verifyString(sumPage.fetchJobFromSummary(), jobId);

        } else if ("RF_ID_267".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickOnTheInputLayoutLinkForSuppression();
            driver.switchTo().frame(0);
            List<String> fetchedLayoutFromRefinementProcess = sumPage.fetchLayoutFields();
            Thread.sleep(1500);
            driver.switchTo().defaultContent();
            Thread.sleep(1500);
            sumPage.clickCloseButton();

            Thread.sleep(3000);

            ProjDashBoardPage.clickDataMenuTab();
            Thread.sleep(5000);
            String[] processArr = supProcess.split(":");
            Thread.sleep(1500);
            commMethods.selectViewSummaryFromAssignedId(processArr[0] + ":" + processArr[1]);
            String inputProcName = dmSummPag.getInputProcessNameFromSummary();
            ProjDashBoardPage.clickSourceMatchTab();
            Thread.sleep(5000);
            commMethods.selectViewSummaryFromAssignedId(inputProcName);
            String procName = rfCommMethods.getTheInputFromTheSourceMatchSumm();

            ProjDashBoardPage.clickInputTab();
            Thread.sleep(5000);

            commMethods.selectViewSummaryFromAssignedId(procName);
            summaryPage.clickSInputFileRef();
            driver.switchTo().frame(0);

            List<String> fetchedLayoutFromImportFileProcess = sumPage.fetchLayoutFields();
            Thread.sleep(1500);
            driver.switchTo().defaultContent();
            Thread.sleep(1500);
            sumPage.clickCloseButton();
            for (int i = 0; i < fetchedLayoutFromImportFileProcess.size() && i < fetchedLayoutFromRefinementProcess.size(); i++)
            {
                commMethods.verifyString(fetchedLayoutFromRefinementProcess.get(i).replaceAll("\\s+", ""), fetchedLayoutFromImportFileProcess.get(i)
                        .replaceAll("\\s+", ""));

            }

            /*
             * Assert.assertEquals(fetchedLayoutFromRefinementProcess,
             * fetchedLayoutFromImportFileProcess,"The Two Layout Configuration Did Not Match");
             */
        } else if ("RF_ID_281".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.");
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            ProjDashBoardPage.clickRFTab();
            module.initializeDriver(driver);
            module.selectDuplicate();
            Thread.sleep(1000);
            module.selectEdit();
            Thread.sleep(1000);
            rfSetupPage.clickContinueButton();
            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.");

            rfCommMethods.selectProcessForImpFile(supNewProcess);
            rfCommMethods.selectDataForImpFile(supNewData);
            String isGroupPresentForSupp = fffPage.isGroupPresent();
            if ("block".equalsIgnoreCase(isGroupPresentForSupp))
            {
                rfCommMethods.selectTheGroupsForRefinmentProcess(supNewGrp);
            }
            supprOptionsPage.clickContinueButton();
            Thread.sleep(2000);
            if ("Custom Suppression".equalsIgnoreCase(supType))
            {
                custSupPage.selectLeftField(supNewLeftFields);
                custSupPage.selectRightField(supNewRightFields);
                rfCommMethods.handleAlert();
                custSupPage.clickContinueButton();

            }

            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
        } else if ("RF_ID_202".equalsIgnoreCase(tc_Id))
        {
            // for suppression

            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.");
            sumPage.clickSubmitButton();

            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            String errorMessage = sumPage.getErrorMessage();

            errorMessage.replace("\\", "");
            errorMessage.replace("\\", "");
            if (errorMessage != null)
            {
                commMethods.verifyString("Error : Job run details for Input Process " + "\"" + process + "\"" + " selected for process " + procName1
                        + ":" + processName + " do not exist.", errorMessage);
            }

        }
        // stats test cases
        else if ("RF_ID_204".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(3000);
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);

            String process_Name = procName1 + ":" + "" + processName;
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(process_Name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(process_Name);
            jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
            Thread.sleep(15000);
            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(30000);
            String errMsg = jobStackingPage.getTheErrorMessageFromTheJobStackingScreen();
            if (errMsg != null)
            {
                commMethods.verifyString("Errors: Input Table" + " " + '"' + data + '"' + " " + "selected for process" + " " + procName1 + ":"
                        + processName + " doesnot exist.", errMsg);

            }
        } else if ("RF_ID_171".equalsIgnoreCase(tc_Id) || "RF_ID_185".equalsIgnoreCase(tc_Id))

        {
            sumPage.clickSubmitButton();

            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            // shPage.clickViewStatsForJobLevel(procName1);
            ProjDashBoardPage.viewStats(procName1);
            // driver.switchTo().frame("sb-player");
            String outputTableName = rfStats.getSSNSuppOutputTableName();
            String[] outputTableNameArr = outputTableName.split(":");
            String inputTableName = rfStats.getSSNSuppInputTableName();
            String[] inputTableNameArr = inputTableName.split(":");
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_171".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForDropAsRecordStatusForSSNOption(outputTableNameArr[0]),
                        rfStats.getCountOfSSNMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }
            if ("RF_ID_185".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForDropAsRecordStatusForCIDOption(outputTableNameArr[0]),
                        rfStats.getCountOfCIDMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }

        } else if ("RF_ID_164".equalsIgnoreCase(tc_Id) || "RF_ID_178".equalsIgnoreCase(tc_Id) || "RF_ID_191".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // driver.switchTo().frame("sb-player");
            String outputTableName = rfStats.getSSNSuppOutputTableName();
            String[] outputTableNameArr = outputTableName.split(":");
            String inputTableName = rfStats.getSSNSuppInputTableName();
            String[] inputTableNameArr = inputTableName.split(":");
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            if ("SSN Suppression".equalsIgnoreCase(supType))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForRefinmentTableWhenSSNSelected(outputTableNameArr[0]),
                        rfStats.getRecordCountFromGPInputTable(inputTableNameArr[0]));
            } else if ("CID Suppression".equalsIgnoreCase(supType))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForRefinmentTableWhenCIDSelected(outputTableNameArr[0]),
                        rfStats.getRecordCountFromGPInputTable(inputTableNameArr[0]));
            } else if ("Custom Suppression".equalsIgnoreCase(supType))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForRefinmentTableWhenCustomSelected(outputTableNameArr[0]),
                        rfStats.getRecordCountFromGPInputTable(inputTableNameArr[0]));
            }
        } else if ("RF_ID_194".equalsIgnoreCase(tc_Id) || "RF_ID_195".equalsIgnoreCase(tc_Id) || "RF_ID_196".equalsIgnoreCase(tc_Id)
                || "RF_ID_197".equalsIgnoreCase(tc_Id) || "RF_ID_198".equalsIgnoreCase(tc_Id) || "RF_ID_199".equalsIgnoreCase(tc_Id))
        {
            // For SSN/CID/Custom Suppression
            sumPage.clickSubmitButton();
            Thread.sleep(5000);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());

            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(3500);
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            Thread.sleep(1500);
            String rfOPTableName = rfStats.getRefinementTableName(procNameColonWithoutSpace, supType);

            // shPage.clickViewStatsForJobLevel(procName1);
            ProjDashBoardPage.viewStats(processNameStats);

            String rfTableName = rfStats.getSSNSuppOutputTableName().trim();
            Long recordCount = rfStats.getSSNSupTotalOutputRecordCountRF();
            commMethods.verifyString(rfTableName, rfOPTableName);
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            commMethods.verifyLong(rfStats.getRecordCountFromGPOutputTable(rfTableName), recordCount);

        } else if ("RF_ID_165".equalsIgnoreCase(tc_Id) || "RF_ID_179".equalsIgnoreCase(tc_Id) || "RF_ID_192".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(2500);
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            String procStatus = null;
            Thread.sleep(1000);
            procStatus = ProjDashBoardPage.verifyProcess(procName1);
            if ("PASS".equalsIgnoreCase(procStatus))
            {
                commMethods.verifyString(procStatus, "PASS");
            } else
            {
                String completeProcessName = procNameColon.replace(":", "_");
                Thread.sleep(1000);
                /* commMethods.selectRetryOptionInTheDashBoradController(completeProcessName); */
                Thread.sleep(1000);
                procStatus = ProjDashBoardPage.verifyProcess(procName1);
                commMethods.verifyString(procStatus, "PASS");
            }
            Thread.sleep(1500);
            ProjDashBoardPage.viewStats(procName1);
            // driver.switchTo().frame("sb-player");
            String outputTableName = rfStats.getSSNSuppOutputTableName();

            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");
            String suppRecords = rfStats.getSuppressedRecords();
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            // String suppInputTableName = statsView.getOutputTableNameIP();
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_165".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(
                        rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForSSNOptionForAcceptRecordType(outputTableName.trim()),
                        rfStats.getCountOfSSNMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
                // TODO--Records suppressed are from supp file or not is remaining
                // List<String> recordList = rfStats.getListOfDpSeqForMatchedSSNFromGP(outputTableName.trim());
                // Assert.assertTrue(rfStats.validateThatSameRecordsPresentInSuppTable(recordList, suppInputTableName));

                commMethods.verifyString(String.valueOf(rfStats.getCountOfRecordsFromTheGPForSSNMatch(outputTableName.trim(), inputTableNameArr[0],
                        suppInputTableName)), suppRecords);
            }
            if ("RF_ID_179".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForCIDOption(outputTableName.trim()),
                        rfStats.getCountOfCIDMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));

                commMethods.verifyString(String.valueOf(rfStats.getCountOfRecordsFromTheGPForCIDMatch(outputTableName.trim(), inputTableNameArr[0],
                        suppInputTableName)), suppRecords);
            }
            if ("RF_ID_192".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForCustSuppOption(outputTableName.trim()),
                        rfStats.getCountOfCustMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));

            }
        } else if ("RF_ID_167".equalsIgnoreCase(tc_Id) || "RF_ID_181".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            // shPage.clickViewStatsForJobLevel(procName1);
            // driver.switchTo().frame("sb-player");
            ProjDashBoardPage.viewStats(procName1);
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            if ("RF_ID_167".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsWhoseSSNSuppFlagIsNull(outputTableNameArr[0]),
                        rfStats.getCountOfRecordsWhoseFailCodeIsNotNull(inputTableNameArr[0]));
            } else if ("RF_ID_181".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsWhoseCIDSuppFlagIsNull(outputTableNameArr[0]),
                        rfStats.getCountOfRecordsWhoseFailCodeIsNotNull(inputTableNameArr[0]));
            }

        } else if ("RF_ID_168".equalsIgnoreCase(tc_Id) || "RF_ID_182".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");
            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            // String suppInputTableName = statsView.getOutputTableNameIP();
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_168".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsWhichAreNotSuppressedForSSNOption(outputTableNameArr[0]),
                        rfStats.getCountOfRecordsNotSuppressedForSSNOption(inputTableNameArr[0], suppInputTableName));
            }
            if ("RF_ID_182".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsWhichAreNotSuppressedForCIDOption(outputTableNameArr[0]),
                        rfStats.getCountOfRecordsNotSuppressedForCIDOption(inputTableNameArr[0], suppInputTableName));
            }
        }

        else if ("RF_ID_169".equalsIgnoreCase(tc_Id) || "RF_ID_170".equalsIgnoreCase(tc_Id) || "RF_ID_183".equalsIgnoreCase(tc_Id)
                || "RF_ID_184".equalsIgnoreCase(tc_Id))

        {
            Thread.sleep(1500);
            sumPage.clickSubmitButton();

            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // shPage.clickViewStatsForJobLevel(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");

            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            // String suppInputTableName = statsView.getOutputTableNameIP();
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_169".equalsIgnoreCase(tc_Id) || "RF_ID_170".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForSSNOption(outputTableNameArr[0]),
                        rfStats.getCountOfSSNMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }
            if ("RF_ID_183".equalsIgnoreCase(tc_Id) || "RF_ID_184".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForCIDOption(outputTableNameArr[0]),
                        rfStats.getCountOfCIDMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }

        } else if ("RF_ID_172".equalsIgnoreCase(tc_Id) || "RF_ID_174".equalsIgnoreCase(tc_Id) || "RF_ID_186".equalsIgnoreCase(tc_Id)
                || "RF_ID_188".equalsIgnoreCase(tc_Id) || "RF_ID_210".equalsIgnoreCase(tc_Id))

        {
            String suppInputTableName = null;
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");

            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");

            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            if ("RF_ID_210".equalsIgnoreCase(tc_Id))
            {
                suppInputTableName = rfStats.getTheTableNameForSuppFileProcess();
            } else
            {

                suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);

            }
            if ("RF_ID_172".equalsIgnoreCase(tc_Id) || "RF_ID_174".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsSuppressedWhenFailCodeIsNotNullForSSNOption(outputTableNameArr[0], supRejects),
                        rfStats.getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForSSNOption(inputTableNameArr[0], suppInputTableName,
                                supRejects));
            } else if ("RF_ID_186".equalsIgnoreCase(tc_Id) || "RF_ID_188".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsSuppressedWhenFailCodeIsNotNullForCIDOption(outputTableNameArr[0], supRejects),
                        rfStats.getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForCIDOption(inputTableNameArr[0], suppInputTableName,
                                supRejects));
            } else if ("RF_ID_210".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForTagOrRejectsAsRecordStatusForCustSuppOption(outputTableNameArr[0]),
                        rfStats.getCountOfRecordsWhichIsToBeSuppressed(inputTableNameArr[0], suppInputTableName));
            }

        } else if ("RF_ID_173".equalsIgnoreCase(tc_Id) || "RF_ID_187".equalsIgnoreCase(tc_Id))

        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // shPage.clickViewStatsForJobLevel(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");

            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            // String suppInputTableName = statsView.getOutputTableNameIP();
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_173".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForRejectAsRecordStatusAndFailCodeIsNotNullForSSNSupp(outputTableNameArr[0]),
                        rfStats.getCountOfSSNMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            } else if ("RF_ID_187".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForRejectAsRecordStatusAndFailCodeIsNotNullForCIDSupp(outputTableNameArr[0]),
                        rfStats.getCountOfCIDMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }

        } else if ("RF_ID_175".equalsIgnoreCase(tc_Id) || "RF_ID_189".equalsIgnoreCase(tc_Id))

        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // shPage.clickViewStatsForJobLevel(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");

            driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_175".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForDropAsRecordStatusAndFailCodeIsNotNullForSSNOption(outputTableNameArr[0]),
                        rfStats.getCountOfSSNMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            } else if ("RF_ID_189".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getRecordCountFromGPForDropAsRecordStatusAndFailCodeIsNotNullForCIDOption(outputTableNameArr[0]),
                        rfStats.getCountOfCIDMatchedRecordsFromGP(inputTableNameArr[0], suppInputTableName));
            }

        } else if ("RF_ID_176".equalsIgnoreCase(tc_Id) || "RF_ID_190".equalsIgnoreCase(tc_Id))

        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(procName1), "PASS");
            ProjDashBoardPage.viewStats(procName1);
            // shPage.clickViewStatsForJobLevel(procName1);
            // driver.switchTo().frame("sb-player");
            String[] outputTableNameArr = rfStats.getSSNSuppOutputTableName().split(":");
            String[] inputTableNameArr = rfStats.getSSNSuppInputTableName().split(":");

            // driver.switchTo().defaultContent();
            ProjDashBoardPage.clickCloseButtonStats();
            String[] suppProcessNameArr = supProcess.split(":");
            // commMethods.searchProcessOnDashboardAndViewStats(suppProcessNameArr[0]);
            // shPage.clickViewStatsForJobLevel(suppProcessNameArr[0]);
            // driver.switchTo().frame("sb-player");
            String processNameForStats = suppProcessNameArr[0] + "_" + suppProcessNameArr[1];
            String suppInputTableName = rfStats.getTheOutputTableNameForIP(processNameForStats, supProcess);
            if ("RF_ID_176".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsSuppressedWhenDropSelectedWithRejectAsRecordTypesForSSNOption(outputTableNameArr[0],
                        supRejects), rfStats.getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForSSNOption(inputTableNameArr[0],
                        suppInputTableName, supRejects));
            }
            if ("RF_ID_190".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(rfStats.getCountOfRecordsSuppressedWhenDropSelectedWithRejectAsRecordTypesForCIDOption(outputTableNameArr[0],
                        supRejects), rfStats.getCountOfRecordsFromInputTableWhoseFailCodeIsNotNullForCIDOption(inputTableNameArr[0],
                        suppInputTableName, supRejects));
            }

        } else if ("RF_ID_200".equalsIgnoreCase(tc_Id) || "RF_ID_201".equalsIgnoreCase(tc_Id))

        {
            String rfnProcessName = rfCommMethods.getProcessNameFromSummary();
            // Click on DNS Process And Check Whether Refinment Process is displayed In the Process Drop Down lIst
            ProjDashBoardPage.clickDataProcessingTab();
            rfCommMethods.handleAlert();
            dpHomePage.clickDNSButton();
            boolean processFound = rfCommMethods.isRefinmentProcessPresent(rfnProcessName);
            Assert.assertTrue(processFound);

        } else if ("RF_ID_200".equalsIgnoreCase(tc_Id) || "RF_ID_201".equalsIgnoreCase(tc_Id))

        {
            String rfnProcessName = rfCommMethods.getProcessNameFromSummary();
            // Click on DNS Process And Check Whether Refinment Process is displayed In the Process Drop Down lIst
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickDNSButton();
            boolean processFound = rfCommMethods.isRefinmentProcessPresent(rfnProcessName);
            Assert.assertTrue(processFound);

        } else if ("RF_ID_207".equalsIgnoreCase(tc_Id))
        {
            sumPage.clickSubmitButton();
            Thread.sleep(2500);
            rfCommMethods.handleAlert();
            Thread.sleep(1000);
            ProjDashBoardPage.clickRFTab();
            status = rfHomePage.getProcessStatus(procName1);
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickRFTab();
            module.initializeDriver(driver);
            module.selectDuplicate();
            Thread.sleep(1000);
            module.selectEdit();
            Thread.sleep(1000);
            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "New Refinement Setup Complete the required information below, and then click 'Continue'.");
            rfSetupPage.clickContinueButton();
            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.");
            supprOptionsPage.clickContinueButton();
            commMethods.verifyString(rfCommMethods.getPageTitle(),
                    "Custom Suppression Complete the Information below, and click 'Save' or 'Continue'.");
            List<String> selectedLeftFields = custSupPage.getTheSelectedLeftFields();

            for (int i = 0; i < selectedLeftFields.size(); i++)
            {
                String[] providedleftFeilds = supLeftFields.split(",");
                List<String> providedLeftFieldsList = Arrays.asList(providedleftFeilds);

                Assert.assertTrue(providedLeftFieldsList.contains(selectedLeftFields.get(i)));

            }

            List<String> selectedRightFields = custSupPage.getTheSelectedRightFields();
            for (int i = 0; i < selectedRightFields.size(); i++)
            {
                String[] providedRightFeilds = supRightFields.split(",");
                List<String> providedRightFieldsList = Arrays.asList(providedRightFeilds);

                Assert.assertTrue(providedRightFieldsList.contains(selectedRightFields.get(i)));

            }

        }
    }
    
    @Test (dataProvider = "rf_BAS", priority = 1, description = "Base Process method")
    public void createBaseProcess_1(String tc_Id, String testRun, String TC, String Description, String copyProj, String copyProcName,
            String processName, String process, String data, String groups, String Hholding, String keyConfigField, String keycustFields,
            String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, String nhdRejects, String nhdRecStatus,
            String nhhdCritLevel, String nhhdTagValue, String nhhdRejCode, String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts,
            String hhsRejects, String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, String chRecStatus,
            String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, String ceRecStatus, String ceFromProcessImp,
            String ceProcess, String ceData, String CEGroups, String suppression, String supType, String supAllRecords, String supAccepts,
            String supRejects, String supRecStatus, String supFromProcImp, String supProcess, String supData, String SuppGroups,
            String fromPreviousProject, String previousProjectName, String shippedFileName, String supLeftFields, String supRightFields,
            String supNewProcess, String supNewData, String supNewGrp, String supNewLeftFields, String supNewRightFields, String rollingSuppProcess,
            String suppressionDays, String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects,
            String dedAcceptExclusion, String dedRejectExclusion, String dedupeExclusion, String dedRecStatus, String customFields,
            String priorityField, String prioritySet, String procNameForStack, ITestContext testContext) throws Exception
	{
    	String executionStatus = commMethods.getTheExecutionStatus(process);
        if (executionStatus.equalsIgnoreCase("COMPLETED"))
    {
    	
		String status = null;
		Modules module = new Modules();
		testContext.setAttribute("WebDriver", driver);
		driver.findElement(By.xpath(".//a[contains(text(),'Refinement')]")).click();
		// ProjDashBoardPage.clickRFTab();
		driver.switchTo().alert().accept();
		rfHomePage.clickRFSetupButton();
		String procName1 = commMethods.getFinalProcessName();
		String procNameColon = commMethods.getFinalProcessNameColon();
		rfSetupPage.processNameField(processName);
		Thread.sleep(5000);
		rfSetupPage.selectProcessField(process);
		rfSetupPage.selectDataField(data);
		if ("check".equalsIgnoreCase(Hholding)) {
			rfSetupPage.clickHholding();
			if ("check".equalsIgnoreCase(nhhd)) {
				rfSetupPage.clickNegativeHholdDrop();
			}
			if ("check".equalsIgnoreCase(hhSplit)) {
				rfSetupPage.clickHholdSplitRegHholdDrop();
			}
			if ("check".equalsIgnoreCase(customhh)) {
				rfSetupPage.clickCustomHholding();
			}
		}
		if ("check".equalsIgnoreCase(ce)) {
			rfSetupPage.clickCustomerElimination();
		}
		if ("check".equalsIgnoreCase(suppression)) {
			rfSetupPage.clickSuppression();
		}
		if ("check".equalsIgnoreCase(dedupe)) {
			rfSetupPage.clickDedupe();
		}
		rfSetupPage.clickContinueButton();
		if ("check".equalsIgnoreCase(Hholding)) {
			String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
			String expHeader = "Householding Key Configuration Complete the required information below, and then click 'Save' or 'Continue'.";
			if (expHeader.equalsIgnoreCase(actHeader)) {
				if ("Standard".equalsIgnoreCase(keyConfigField)) {
					hhKeyConfigPage.clickStandardRbutton();
					hhKeyConfigPage.clickContinueButton();
				} else if ("Custom".equalsIgnoreCase(keyConfigField)) {
					hhKeyConfigPage.clickCustomRbutton();
					rfCommMethods.selectCustomFields(keycustFields, keyPriField);
					rfCommMethods.selectPriorityLevel(keyPriLevel);
					hhKeyConfigPage.clickContinueButton();
				}
			}
			if ("check".equalsIgnoreCase(nhhd)) {
				actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
				expHeader = "Householding: Negative Household Drop Complete the required information below, and then click 'Save' or 'Continue'.";
				if (expHeader.equalsIgnoreCase(actHeader)) {
					commMethods.selectRecordTypes(process, nhdAllRecords, nhdAccepts, nhdRejects);
					rfCommMethods.selectRecordStatus(nhdRecStatus);
					nhhdPage.clickAddCondition();
					nhhdPage.criteriaLevel(nhhdCritLevel);
					nhhdPage.tagValue(nhhdTagValue);
					nhhdPage.rejectCode(nhhdRejCode);
					nhhdPage.clickContinueButton();
				}
			}
			if ("check".equalsIgnoreCase(hhSplit)) {
				actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
				expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
				if (expHeader.equalsIgnoreCase(actHeader)) {
					hhSplitRegPage.selectHholdSplitOptions(hhOptions);
					commMethods.selectRecordTypes(process, hhsAllRecords, hhsAccepts, hhsRejects);
					rfCommMethods.selectRecordStatus(nhdRecStatus);
					hhSplitRegPage.clickContinueButton();
				}
			}
			if ("check".equalsIgnoreCase(customhh)) {
				actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
				expHeader = "Household Complete the required information below, and then click 'Save' or 'Continue'.";
				if (expHeader.equalsIgnoreCase(actHeader)) {
					commMethods.selectRecordTypes(process, chAllRecords, chAccepts, chRejects);
					rfCommMethods.selectRecordStatus(chRecStatus);
					chHPage.clickContinueButton();
					custHholdPage.selectModule(module1);
					custHholdPage.clickContinueButton();
				}
			}
		}
		if ("check".equalsIgnoreCase(ce)) {
			String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
			String expHeader = "Customer Elimination Options Complete the required information below, and then click 'Save' or 'Continue'.";
			if (expHeader.equalsIgnoreCase(actHeader)) {
				commMethods.selectRecordTypes(process, ceAllRecords, ceAccepts, ceRejects);
				rfCommMethods.selectRecordStatus(ceRecStatus);
				rfCommMethods.selectImportedFileRbutton(ceFromProcessImp);
				rfCommMethods.selectProcessForImpFile(ceProcess);
				rfCommMethods.selectDataForImpFile(ceData);
				cePage.clickContinueButton();
			}
		}
		if ("check".equalsIgnoreCase(suppression)) {
			String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
			String expHeader = "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.";
			if (expHeader.equalsIgnoreCase(actHeader)) {
				supprOptionsPage.selectSuppressionType(supType);
				commMethods.selectRecordTypes(process, supAllRecords, supAccepts, supRejects);
				rfCommMethods.selectRecordStatus(supRecStatus);
				rfCommMethods.selectImportedFileRbutton(supFromProcImp);
				rfCommMethods.selectProcessForImpFile(supProcess);
				rfCommMethods.selectDataForImpFile(supData);
				supprOptionsPage.clickContinueButton();
				if ("Custom".equalsIgnoreCase(supType)) {
					custSupPage.selectLeftFields(supLeftFields);
					custSupPage.selectRightFields(supRightFields);
					boolean a;
					a = isAlertPresent();
					if (a) {
						try {
							Alert alert = driver.switchTo().alert();
							String alertText = alert.getText();
							if (acceptNextAlert) {
								alert.accept();
							} else {
								alert.dismiss();
							}
							System.out.println(alertText);
						} catch (Exception e) {

						} finally {
							acceptNextAlert = true;
						}
					}
					custSupPage.clickContinueButton();
				}
			}
		}
		if ("check".equalsIgnoreCase(dedupe)) {
			String actHeader = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
			String expHeader = "Dedupe Options Complete the required information below, and then click 'Save' or 'Continue'.";
			if (expHeader.equalsIgnoreCase(actHeader)) {
				dedupePage.selectDedupeOptions(dedOptions);
				commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);
				rfCommMethods.selectRecordStatus(dedRecStatus);
				WebElement custom = driver.findElement(By.id("customDedupe"));
				if (custom.isSelected()) {
					rfCommMethods.selectCustomFields(customFields, priorityField);
					rfCommMethods.selectPriorityLevel(prioritySet);
				}
				dedupePage.clickContinueButton();
			}
		}
		String actRfSummary = driver.findElement(By.xpath(".//*[@id='contentArea']/div[4]/div/h3")).getText();
		String expRfSummary = "Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.";
		if (expRfSummary.equalsIgnoreCase(actRfSummary)) {
			// ProjDashBoardPage.clickRFTab();
			module.initializeDriver(driver);
			sumPage.clickSubmitButton();
			status = rfHomePage.getProcessStatus(procName1);
			commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
		}
    }
	}

    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] rf_QA_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Refinement", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] rf_Dev_CBA() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Refinement", "CBA");
        return testObjArray_Y;
    }
    
    @DataProvider
    public Object[][] rf_BAS() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Refinement", "BAS");
        return testObjArray_Y;
    }

    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

}

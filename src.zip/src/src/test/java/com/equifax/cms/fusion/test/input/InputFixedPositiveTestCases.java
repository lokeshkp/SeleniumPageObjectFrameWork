package com.equifax.cms.fusion.test.input;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

public class InputFixedPositiveTestCases
{
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
	private static final Logger LOGGER = LoggerFactory.getLogger(InputFixedPositiveTestCases.class);
	private OracleDBHelper db;
    private static final String IP = "Input";

    @Before
    public void setUp() throws Exception
    {
       // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		db = new OracleDBHelper();

    }

    @Features("Input fixed ascii process positive scenarios")
    @Stories("US #3")
    @Test
    public void testIPFixedLayout() throws Exception
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        module.userLogin();
        module.searchProject();
        module.navigateToProcess(IP);
        module.navigateToNewProcessPage("Import New File");
        // Test Case : Create a new input process, create a new layout,add one value in the layout selecting from customize, save, continue, do not //
        // run datacheck
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys("iptest");// Get from csv
        driver.findElement(By.id("filePath")).clear();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys(PropertiesUtils.getProperty("ipFilePath"));
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("recLen")).sendKeys(PropertiesUtils.getProperty("ipReclen"));
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(PropertiesUtils.getProperty("ipSeqno"));

        driver.findElement(By.id("submitLayout")).click();
        driver.findElement(By.id("layoutName")).clear();
        driver.findElement(By.id("layoutName")).sendKeys(PropertiesUtils.getProperty("ipLayoutName"));// Get from csv
        new Select(driver.findElement(By.id("fieldType0"))).selectByVisibleText("Customize...");
        driver.findElement(By.id("CID")).click();
        driver.findElement(By.xpath("//button[@type='button']")).click();
        new Select(driver.findElement(By.id("fieldType0"))).selectByVisibleText("CID");
        driver.findElement(By.id("name0")).clear();
        driver.findElement(By.id("name0")).sendKeys("CID1");
        driver.findElement(By.id("start0")).clear();
        driver.findElement(By.id("start0")).sendKeys("1");
        driver.findElement(By.id("end0")).clear();
        driver.findElement(By.id("end0")).sendKeys("10");
        driver.findElement(By.id("addField")).click();
        new Select(driver.findElement(By.id("fieldType2"))).selectByVisibleText("First Name");
        driver.findElement(By.id("name2")).clear();
        driver.findElement(By.id("name2")).sendKeys("FirstName1");
        driver.findElement(By.id("start2")).clear();
        driver.findElement(By.id("start2")).sendKeys("11");
        driver.findElement(By.id("end2")).clear();
        driver.findElement(By.id("end2")).sendKeys("20");
        driver.findElement(By.xpath("(//input[@id='addField'])[2]")).click();
        driver.findElement(By.id("constName0")).clear();
        driver.findElement(By.id("constName0")).sendKeys("Constant1");
        driver.findElement(By.id("constValue0")).clear();
        driver.findElement(By.id("constValue0")).sendKeys("constval");
        /*
         * for (int second = 0;; second++) { if (second >= 60) fail("timeout"); try { if (("Layout Saved".equals(closeAlertAndGetItsText()))) break; }
         * catch (Exception e) { e.printStackTrace(); } Thread.sleep(1000); }
         */
        driver.findElement(By.id("save")).click();
        Thread.sleep(90000);
        String alertText = module.acceptAndGetAlertText();
        Assert.assertEquals(alertText, "Layout saved");

        /*
         * wait = new WebDriverWait(driver, 60); try { // In order to accept alert driver needs to be switched to accept the alert
         * wait.until(ExpectedConditions.alertIsPresent()); driver.switchTo().alert().accept(); } catch (Exception e) { e.printStackTrace(); }
         */
        // String alrt = driver.switchTo().alert().getText();
        // System.out.print(alrt); //
        // Assert.assertEquals("Layout saved", closeAlertAndGetItsText()); // driver.findElement(By.id("submitLayout")).click();


        driver.findElement(By.id("submitButton")).click();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(90000);

        driver.findElement(By.id("isDataCheck")).click();
        driver.findElement(By.id("submitButton")).click();

        module.navigateToProcess(IP);

        status = module.getStatusIP();
        Assert.assertEquals(StatusEnum.READY.name(), status.trim());

        // Test Case : Edit the input process, select a new layout, continue, add a field and constant and continue
        module.selectEdit();
        // driver.findElement(By.id("newLayoutRadio")).click();
        driver.findElement(By.id("submitLayout")).click();
        // driver.findElement(By.id("layoutName")).clear();
        // driver.findElement(By.id("layoutName")).sendKeys(PropertiesUtils.getProperty("ipLayoutName"));
        /*
         * new Select(driver.findElement(By.id("fieldType0"))).selectByVisibleText("Customize..."); driver.findElement(By.id("CID")).click();
         * driver.findElement(By.xpath("//button[@type='button']")).click(); new
         * Select(driver.findElement(By.id("fieldType0"))).selectByVisibleText("CID"); driver.findElement(By.id("name0")).clear();
         * driver.findElement(By.id("name0")).sendKeys("CID1"); driver.findElement(By.id("start0")).clear();
         * driver.findElement(By.id("start0")).sendKeys("1"); driver.findElement(By.id("end0")).clear();
         * driver.findElement(By.id("end0")).sendKeys("10"); driver.findElement(By.id("addField")).click(); new
         * Select(driver.findElement(By.id("fieldType2"))).selectByVisibleText("First Name"); driver.findElement(By.id("name2")).clear();
         * driver.findElement(By.id("name2")).sendKeys("FirstName1"); driver.findElement(By.id("start2")).clear();
         * driver.findElement(By.id("start2")).sendKeys("11"); driver.findElement(By.id("end2")).clear();
         * driver.findElement(By.id("end2")).sendKeys("20"); driver.findElement(By.xpath("(//input[@id='addField'])[2]")).click();
         * driver.findElement(By.id("constName0")).clear(); driver.findElement(By.id("constName0")).sendKeys("Constant1");
         * driver.findElement(By.id("constValue0")).clear(); driver.findElement(By.id("constValue0")).sendKeys("constval");
         */
        driver.findElement(By.id("save")).click();
        Thread.sleep(90000);
        /*
         * wait = new WebDriverWait(driver, 60); try { // In order to accept alert driver needs to be switched to accept the alert
         * wait.until(ExpectedConditions.alertIsPresent()); driver.switchTo().alert().accept(); } catch (Exception e) { e.printStackTrace(); }
         */

        alertText = module.acceptAndGetAlertText();
        Assert.assertEquals(alertText, "Layout saved");

        module.selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(90000);
        // driver.findElement(By.id("isDataCheck")).click();

        /*
         * for (int second = 0;; second++) { if (second >= 60) fail("timeout"); try { if (isElementPresent(By.id("isDataCheck"))) break; } catch
         * (Exception e) { } try { Thread.sleep(1000); } catch (InterruptedException e) { // TODO Auto-generated catch block e.printStackTrace(); } }
         */

        // String alrt = driver.switchTo().alert().getText();
        // System.out.print(alrt);

        module.selectSubmit();

        // TestCase : Duplicate functionality works with all values complete
        module.navigateToProcess(IP);
        module.selectDuplicate();
        status = module.getStatusIP();
        Assert.assertEquals(StatusEnum.READY.name(), status.trim());

        // TestCase : View Summary
        // Verify with csv if all values are complete
        module.selectSummary();

        // Test Case : Submit the processwith no datacheck from summary
        module.selectSubmit();
        module.navigateToProcess(IP);
        status = module.getStatusIP();
        // Status for the process should change to submitted
        Assert.assertEquals(StatusEnum.SUBMITTED.name(), status.trim());

        module.navigateToHome();
        String jobId = module.getJobId();
        testIPSubmitNoDC(jobId);

        // Test Case : Duplicate the submitted process
        module.navigateToProcess(IP);
        module.selectDuplicate();
        status = module.getStatusIP();
        Assert.assertEquals(StatusEnum.READY.name(), status.trim());

        /********** Test cases with datacheck *************/

        // Test Case : Edit the duplicated process and use existing layout, change the name and use generate fields to select fields, select datacheck
        // and
        // continue
        module.selectEdit();
        new Select(driver.findElement(By.id("fileType"))).selectByVisibleText("SSN");
        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText("SUPPRESSION");
        driver.findElement(By.id("submitLayout")).click();
        driver.findElement(By.xpath("//table[@id='fbLines']/tbody/tr[2]/td[105]")).click();
        driver.findElement(By.xpath("//table[@id='fbLines']/tbody/tr[3]/td[116]")).click();
        new Select(driver.findElement(By.id("clickSelect"))).selectByVisibleText("End");
        driver.findElement(By.xpath("//table[@id='fbLines']/tbody/tr[3]/td[115]")).click();
        driver.findElement(By.xpath("//table[@id='fbLines']/tbody/tr[3]/td[135]")).click();
        driver.findElement(By.id("apply")).click();
        new Select(driver.findElement(By.id("fieldType3"))).selectByVisibleText("CID");
        driver.findElement(By.id("name3")).clear();
        driver.findElement(By.id("name3")).sendKeys("CID_1");
        driver.findElement(By.id("name4")).clear();
        driver.findElement(By.id("name4")).sendKeys("OTHER_1");
        new Select(driver.findElement(By.id("fieldType5"))).selectByVisibleText("Customize...");
        driver.findElement(By.id("MIDDLE_NAME")).click();
        driver.findElement(By.xpath("//button[@type='button']")).click();
        new Select(driver.findElement(By.id("fieldType5"))).selectByVisibleText("Middle Name");
        new Select(driver.findElement(By.id("fieldType6"))).selectByVisibleText("Last Name");
        driver.findElement(By.id("save")).click();
        Thread.sleep(90000);
        alertText = module.acceptAndGetAlertText();
        Assert.assertEquals(alertText, "Layout saved");

        /*
         * wait = new WebDriverWait(driver, 60); try { // In order to accept alert driver needs to be switched to accept the alert
         * wait.until(ExpectedConditions.alertIsPresent()); driver.switchTo().alert().accept(); } catch (Exception e) { e.printStackTrace(); }
         */

        driver.findElement(By.id("submitButton")).click();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(90000);

        driver.findElement(By.id("isDataCheck")).click();
        new Select(driver.findElement(By.id("fileIdentifier"))).selectByVisibleText("BofA_PBB");
        driver.findElement(By.id("maxNoOfBlankFields")).clear();
        driver.findElement(By.id("maxNoOfBlankFields")).sendKeys("100");
        driver.findElement(By.id("maxNoOfSingleFields")).clear();
        driver.findElement(By.id("maxNoOfSingleFields")).sendKeys("100");
        driver.findElement(By.id("maxNoOfUnknownFields")).clear();
        driver.findElement(By.id("maxNoOfUnknownFields")).sendKeys("10");
        new Select(driver.findElement(By.id("runtimeB"))).selectByVisibleText("201501121946");
        driver.findElement(By.id("submitButton")).click();

        // Test Case : Submit the process
        module.selectSubmit();
        module.navigateToProcess(IP);
        status = module.getStatusIP();
        // Status for the process should change to submitted
        Assert.assertEquals(StatusEnum.SUBMITTED.name(), status.trim());

        module.navigateToHome();
        jobId = module.getJobId();
        testIPSubmitWithDC(jobId);

        module.userLogout();
    }

    @After
    public void tearDown() throws Exception
    {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString))
        {
            fail(verificationErrorString);
        }
    }

    public void testIPSubmitNoDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    public void testIPSubmitWithDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 4);

        // Verify values from greenplum
    }

}


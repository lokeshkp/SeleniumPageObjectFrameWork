package com.equifax.cms.fusion.test.input;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

public class InputDelimitedPositiveTestCases
{
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
	private static final Logger LOGGER = LoggerFactory.getLogger(InputDelimitedPositiveTestCases.class);
	private OracleDBHelper db;
    private static final String IP = "Input";
    private boolean acceptNextAlert = true;
    WebDriverWait wait;

    @Before
    public void setUp() throws Exception
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		db = new OracleDBHelper();

    }

    @Features("Input delimited process positive scenarios")
    @Stories("US #3")
    @Test
    public void testIPDelimitedLayout() throws Exception
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        module.userLogin();
        module.searchProject();
        module.navigateToProcess(IP);
        module.navigateToNewProcessPage("Import New File");
        // Test Case : Create a new input process, create a new layout,add one value in the layout selecting from customize, save, continue, do not //
        // run datacheck
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys("ip-delimtest");// Get from csv
        new Select(driver.findElement(By.id("fileType"))).selectByVisibleText("MEMBER_NUMBER");// Get from csv
        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText("SUPPRESSION");// Get from csv
        driver.findElement(By.id("filePath")).clear();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys("/nas/dropzone/Test/test_Import_CSV/colon_Delimited/ARJ_6.csv");// Get from csv
        driver.findElement(By.id("format3")).click();
        new Select(driver.findElement(By.id("delimiter"))).selectByVisibleText("Colon");
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys("1");
        driver.findElement(By.id("submitLayout")).click();

        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText("Suppression");// get from csv

        new Select(driver.findElement(By.id("fieldType1"))).selectByVisibleText("Name Freeform FMLS");
        new Select(driver.findElement(By.id("fieldType2"))).selectByVisibleText("Street Address 1");
        new Select(driver.findElement(By.id("fieldType3"))).selectByVisibleText("Street Address 2");
        new Select(driver.findElement(By.id("fieldType4"))).selectByVisibleText("SSN");
        new Select(driver.findElement(By.id("fieldType5"))).selectByVisibleText("Select...");
        new Select(driver.findElement(By.id("fieldType5"))).selectByVisibleText("Customize...");
        driver.findElement(By.id("CID")).click();
        driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
        new Select(driver.findElement(By.id("fieldType5"))).selectByVisibleText("CID");// Get from csv
        driver.findElement(By.id("name5")).click();
        driver.findElement(By.id("name5")).clear();
        driver.findElement(By.id("name5")).sendKeys("CID1");

        driver.findElement(By.id("layoutName")).clear();
        driver.findElement(By.id("layoutName")).sendKeys("auto-delim-test-1"); // Get from csv
        driver.findElement(By.id("addField")).click();
        driver.findElement(By.id("constName0")).clear();
        driver.findElement(By.id("constName0")).sendKeys("Constant1");// Get from csv
        driver.findElement(By.id("constValue0")).clear();
        driver.findElement(By.id("constValue0")).sendKeys("constval");// Get from csv
        /*
         * for (int second = 0;; second++) { if (second >= 60) fail("timeout"); try { if (("Layout Saved".equals(closeAlertAndGetItsText()))) break; }
         * catch (Exception e) { e.printStackTrace(); } Thread.sleep(1000); }
         */
        /*
         * driver.findElement(By.id("save")).click(); wait = new WebDriverWait(driver, 60); try { // In order to accept alert driver needs to be
         * switched to accept the alert wait.until(ExpectedConditions.alertIsPresent()); driver.switchTo().alert().accept(); } catch (Exception e) {
         * e.printStackTrace(); }
         */
        // String alrt = driver.switchTo().alert().getText();
        // System.out.print(alrt); //
        // Assert.assertEquals("Layout saved", closeAlertAndGetItsText()); // driver.findElement(By.id("submitLayout")).click();
        module.selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(60000);

        module.navigateToProcess(IP);

        status = module.getStatusIP();
        Assert.assertEquals(StatusEnum.READY.name(), status.trim());

        // TestCase : Duplicate functionality works with all values complete
        module.selectDuplicate();
        status = module.getStatusIP();
        Assert.assertEquals(StatusEnum.READY.name(), status.trim());

        // TestCase : View Summary
        // Verify with csv if all values are complete
        module.selectSummary();

        // Test Case : Submit the processwith no datacheck from summary
        module.selectSubmit();
        module.navigateToProcess(IP);
        status = module.getStatusIP();
        // Status for the process should change to submitted
        Assert.assertEquals(StatusEnum.SUBMITTED.name(), status.trim());

        module.navigateToHome();
        String jobId = module.getJobId();
        testIPSubmitNoDC(jobId);
        module.userLogout();
    }

    @After
    public void tearDown() throws Exception
    {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString))
        {
            fail(verificationErrorString);
        }
    }

    public void testIPSubmitNoDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    public void testIPSubmit(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);
        
        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }
}


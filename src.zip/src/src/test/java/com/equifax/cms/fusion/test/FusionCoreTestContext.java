package com.equifax.cms.fusion.test;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class FusionCoreTestContext {

	public static final Logger LOGGER = LoggerFactory.getLogger(FusionCoreTestContext.class);

	public static final String ACCEPTS = "Accepts";
	public static final String REJECTS = "Rejects";
	public static final String ALL = "All";

}

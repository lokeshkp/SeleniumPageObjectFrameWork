package com.equifax.cms.fusion.test.qadm;

import java.util.List;

import org.apache.commons.collections.set.PredicatedSet;
import org.openqa.selenium.*;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.DMPages.*;
import com.equifax.cms.fusion.test.qapages.*;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Parameter;
import ru.yandex.qatools.allure.annotations.Title;

public class DataMenuProcessUI_Validation {

	boolean flag = false;
	public WebDriver driver;
	public OracleDBHelper db;
	public static int i = 1;
	public static List<WebElement> scoreModelElem;
	ProjectDashBoardPage ProjDashBoardPage;
	APmodulePage APModPag;
	ConfigDeStandPage ConfigDEPag;
	ConfigIdScanPage ConfigIDPag;
	CreditInputPage CreditInPag;
	CriteriaRejectsPage CritRejPag;
	DataMenuHomePage DataMenuHomPag;
	DataOriginPage DataOriginPag;
	DMFilterConfigPage DMFilterConPag;
	DMSummaryPage DMSummPag;
	DoubleCheckPage DoubleChckPag;
	ModuleDependenciesPage ModDepenPag;
	ModuleOutputsPage ModOutptPag;
	PreSelectsPage PreSelectPag;
	ProcessNamePage ProcesNamePag;
	ProductPage ProdPag;
	ScoreModelsPage ScreModlPag;
	StateZipCodeInputPage StZipCodInPag;
	CommonMethods commMethods;



	@BeforeTest
	(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
	public void LoginandSearchProj() throws InterruptedException {
		//driver = FusionFirefoxDriver.getDriver();
	    driver = FusionChromeDriver.getDriver();
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		APModPag = PageFactory.initElements(driver, APmodulePage.class);
		ConfigDEPag = PageFactory.initElements(driver, ConfigDeStandPage.class);
		ConfigIDPag =PageFactory.initElements(driver, ConfigIdScanPage.class);
		CreditInPag = PageFactory.initElements(driver, CreditInputPage.class);
		CritRejPag = PageFactory.initElements(driver, CriteriaRejectsPage.class);
		DataMenuHomPag = PageFactory.initElements(driver, DataMenuHomePage.class);
		DataOriginPag = PageFactory.initElements(driver, DataOriginPage.class);
		DMFilterConPag = PageFactory.initElements(driver, DMFilterConfigPage.class);
		DMSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
		DoubleChckPag = PageFactory.initElements(driver, DoubleCheckPage.class);
		ModDepenPag = PageFactory.initElements(driver, ModuleDependenciesPage.class);
		ModOutptPag = PageFactory.initElements(driver, ModuleOutputsPage.class);
		PreSelectPag = PageFactory.initElements(driver, PreSelectsPage.class);
		ProcesNamePag = PageFactory.initElements(driver, ProcessNamePage.class);
		ProdPag =PageFactory.initElements(driver, ProductPage.class);
		ScreModlPag =PageFactory.initElements(driver, ScoreModelsPage.class);
		StZipCodInPag = PageFactory.initElements(driver, StateZipCodeInputPage.class);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		commMethods.userLogin();
		commMethods.searchProject();
	}




	@Title("DM UI Process Name Page Test Case")
	@Description("Data Menu Process Name Page Test Case")
	@Test(priority = 0,dataProvider = "InputData")
	public void DMProcessUITestCase1(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		ProjDashBoardPage.clickDataMenuTab();
		DataMenuHomPag.clickDataMenuButton();
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Process Name Enter a Process Name, and click 'Continue.'");
		ProcesNamePag.clickContinueButton();
		commMethods.verifyString(ProcesNamePag.getErrorMessage(),"* Required field");
		ProcesNamePag.InputProcessNameField(processName);
		ProcesNamePag.clickContinueButton();
	}

	@Title("DM UI Data Origin Page Test Case")
	@Description("Data Menu UI Data Origin Page Test Case")
	@Test(priority = 1,dataProvider = "InputData")
	public void DMProcessUITestCase2(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Data Origin Select a Data Origin, and click 'Continue.'");
		DataOriginPag.selectDataOriginField(DataOriginField);
		DataOriginPag.clickContinueButton();}

	@Title("DM UI Product Page Test Case")
	@Description("Data Menu UI Product Page Test Case")
	@Test(priority = 2,dataProvider = "InputData")
	public void DMProcessUITestCase3(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Product Select a Product,and click 'Continue'.");
					ProdPag.selectProductField(Product);
					ProdPag.clickContinueButton();}
	
	@Title("DM UI Pre Selects Page Test Case")
	@Description("Data Menu UI Pre Selects Test Case")
	@Test(priority = 3,dataProvider = "InputData")
	public void DMProcessUITestCase20(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception{
		if(DataOriginField.equalsIgnoreCase("Pre-Select")) {
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Pre-Selects Select Hispanic Names Only or Gender or enter Age Range , and click 'Continue'.");
			commMethods.verifyboolean(PreSelectPag.Hispanic_Names_CB.isEnabled(), true);
			commMethods.verifyboolean(PreSelectPag.Male_CB.isEnabled(), true);
			commMethods.verifyboolean(PreSelectPag.Female_CB.isEnabled(), true);
			commMethods.verifyboolean(PreSelectPag.Neutral_CB.isEnabled(), true);
			commMethods.verifyboolean(PreSelectPag.Hispanic_Names_CB.isSelected(), false);
			commMethods.verifyboolean(PreSelectPag.Male_CB.isSelected(), false);
			commMethods.verifyboolean(PreSelectPag.Female_CB.isSelected(), false);
			commMethods.verifyboolean(PreSelectPag.Neutral_CB.isSelected(), false);
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Selection is required for either Age, Gender, or Hispanic flag");
			PreSelectPag.checkHispanicCB();
			PreSelectPag.checkMaleCB();
			PreSelectPag.checkFemaleCB();
			PreSelectPag.checkNeutralCB();
			PreSelectPag.clickContinue();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"State/Zip Code Input Select State and/or Zip Code Input, and click 'Continue'.");
			StZipCodInPag.clickBackBtn();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Pre-Selects Select Hispanic Names Only or Gender or enter Age Range , and click 'Continue'.");
			commMethods.verifyboolean(PreSelectPag.Hispanic_Names_CB.isSelected(), true);
			commMethods.verifyboolean(PreSelectPag.Male_CB.isSelected(), true);
			commMethods.verifyboolean(PreSelectPag.Female_CB.isSelected(), true);
			commMethods.verifyboolean(PreSelectPag.Neutral_CB.isSelected(), true);
			PreSelectPag.inputAgeRange1("30", "21");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 1 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
			PreSelectPag.inputAgeRange1("21", "30");
			PreSelectPag.inputAgeRange2("40", "31");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 2 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
			PreSelectPag.inputAgeRange2("31", "40");
			PreSelectPag.inputAgeRange3("50", "41");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 3 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
			PreSelectPag.inputAgeRange3("41", "50");
			PreSelectPag.inputAgeRange4("60", "51");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 4 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
			PreSelectPag.inputAgeRange4("51", "60");
			PreSelectPag.inputAgeRange5("70", "61");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 5 is invalid. The value on the left must be less than or equal to the corresponding value on the right.");
			PreSelectPag.inputAgeRange5("61", "70");
			PreSelectPag.clickContinue();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"State/Zip Code Input Select State and/or Zip Code Input, and click 'Continue'.");
			StZipCodInPag.clickBackBtn();
			commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Pre-Selects Select Hispanic Names Only or Gender or enter Age Range , and click 'Continue'.");
			PreSelectPag.inputAgeRange1("", "");
			PreSelectPag.inputAgeRange2("", "");
			PreSelectPag.inputAgeRange3("", "");
			PreSelectPag.inputAgeRange4("", "");
			PreSelectPag.inputAgeRange5("", "");
			PreSelectPag.inputAgeRange1("21","");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 1 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange1("","21");
			PreSelectPag.clickContinue();
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 1 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange1("", "");
			PreSelectPag.inputAgeRange2("21","");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 2 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange2("","21");
			PreSelectPag.clickContinue();
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 2 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange2("", "");
			PreSelectPag.inputAgeRange3("21","");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 3 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange3("","21");
			PreSelectPag.clickContinue();
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 3 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange3("", "");
			PreSelectPag.inputAgeRange4("21","");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 4 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange4("","21");
			PreSelectPag.clickContinue();
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 4 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange4("", "");
			PreSelectPag.inputAgeRange5("21","");
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 5 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange5("","21");
			PreSelectPag.clickContinue();
			PreSelectPag.clickContinue();
			commMethods.verifyString(PreSelectPag.textMessage.getText(),"Range number 5 is invalid. A numeric value greater than or equal to zero must be supplied for both the left and right side of the range, or, both sides must be left blank.");
			PreSelectPag.inputAgeRange5("", "");
			}
		
	}

	@Title("DM UI State Zip Code Input Page Test Case")
	@Description("Data Menu UI State Zip Code Input Page Test Case")
	@Test(priority = 4,dataProvider = "InputData")
	public void DMProcessUITestCase4(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "State/Zip Code Input Select State and/or Zip Code Input, and click 'Continue'.");
//					StZipCodInPag.selectStateInputField(states);
//					StZipCodInPag.clickStateViewButton();
//					commMethods.verifyString(StZipCodInPag.getInputStatePopUpTitle(), "Input States View your selected states, and then click 'Close'");
					ProjDashBoardPage.clickCloseButtonStats();
					StZipCodInPag.clickContinueButton();}

	@Title("DM UI AutoPilot Module Page Test Case")
	@Description("Data Menu UI AutoPilot Module Page Test Case")
	@Test(priority = 5,dataProvider = "InputData")
	public void DMProcessUITestCase5(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "AutoPilot Modules Enter AutoPilot Modules, and click 'Continue'.");
					APModPag.clickUseProdAPmoduleOnly(prodAPmod);
					APModPag.clickUseProdAPmoduleOnly(prodAPmod);
//					APModPag.select2ndApModuleField(APModuleNonCriteria);
					APModPag.clickAPmodRemoveButton();
					APModPag.clickAddAPmodButton();
//					APModPag.select2ndApModuleField(APModuleNonCriteria);
					APModPag.clickContinueButton();}

	@Title("DM UI Criteria Reject Page Test Case")
	@Description("Data Menu UI Criteria Reject Page Test Case")
	@Test(priority = 6,dataProvider = "InputData")
	public void DMProcessUITestCase6(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Criteria Rejects Select Criteria Rejects, and click 'Continue'.");
		CritRejPag.clickTagRadiobutton();
		CritRejPag.clickDropRadiobutton();
		CritRejPag.clickRejectRadiobutton();
		CritRejPag.clickContinueButton();
	}

	/*@Title("DM UI Module Dependency Page Test Case")
	@Description("Data Menu UI Module Dependency Page Test Case")
	@Test(priority = 6,dataProvider = "InputData")
	public void DMProcessUITestCase7(String testRun, String TC, String Description, String ProcessName, 
			String DataOriginField, String Product, String productId, String MemNum, String smProcess, 
			String dataField, String states, String apModule, String CritRejects, String NumPerAccCode, 
			String NumPerRejCode, String HoldData, String scoreModel,String NCPScoreModel, String idScan, String idScanRejects, 
			String deStandard, String doublechck, String DNSdrop, String ageDrop, String invalidDrop, 
			String testFileDrop, String DataSet)
			throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Module Dependencies Select the Dependencies/Parameters, and click 'Continue.'");
		ModDepenPag.clickContinueButton();}*/

	@Title("DM UI Module Output Page Test Case")
	@Description("Data Menu UI Module Output Page Test Case")
	@Test(priority = 7,dataProvider = "InputData")
	public void DMProcessUITestCase8(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Module Outputs Select Module Outputs, and click 'Continue'.");
					ModOutptPag.InputnumperAcceptCodeField("A");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Accepts(), "Please enter numeric values between 1-999 in Number per Accept Code");
					ModOutptPag.InputnumperAcceptCodeField("99999");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Accepts(), "Please enter numeric values between 1-999 in Number per Accept Code");
					ModOutptPag.InputnumperAcceptCodeField("#@*&%^*$)");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Accepts(), "Please enter numeric values between 1-999 in Number per Accept Code");
					ModOutptPag.InputnumperAcceptCodeField("abcdefgh");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Accepts(), "Please enter numeric values between 1-999 in Number per Accept Code");
					ModOutptPag.InputnumperAcceptCodeField(NumPerAccCode);
					ModOutptPag.InputnumperRejectCodeField("A");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Rejects(), "Please enter numeric values between 1-999 in Number per Reject Code");
					ModOutptPag.InputnumperRejectCodeField("99999");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Rejects(), "Please enter numeric values between 1-999 in Number per Reject Code");
					ModOutptPag.InputnumperRejectCodeField("#@*&%^*$)");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Rejects(), "Please enter numeric values between 1-999 in Number per Reject Code");
					ModOutptPag.InputnumperRejectCodeField("abcdefgh");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage_Rejects(), "Please enter numeric values between 1-999 in Number per Reject Code");
					ModOutptPag.InputnumperRejectCodeField(NumPerRejCode);

					ModOutptPag.clickHoldAddiDataAppend();
					ModOutptPag.clickHoldAddiDataAppend();

					ModOutptPag.InputOutputTableNameJXHTESTKON("   ");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: field name is blank");
					ModOutptPag.DynInputOutputTableNameJXH_KON_MAP("!@#$%^&&*()");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: '!@#$%^&&*()' can not contain space,less than <, greater than >, colon, semicolon, dot, single quote, double quote, @ sign, and %, open paren and close paren ().");
					ModOutptPag.DynClearOutputTableNameJXHTESTKONMAP();
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: field name is blank");
					ModOutptPag.DynInputOutputTableNameJXH_KON_MAP("MAP001");


					ModOutptPag.InputOutputTableNameJXHTESTKONIDScan("   ");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: field name is blank");
					ModOutptPag.DynInputOutputTableNameJXH_KON_IDSCN("!@#$%^&&*()");
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: '!@#$%^&&*()' can not contain space,less than <, greater than >, colon, semicolon, dot, single quote, double quote, @ sign, and %, open paren and close paren ().");
					ModOutptPag.DynClearOutputTableNameJXHTESTKON_IDSCN();
					ModOutptPag.clickContinueButton();
					commMethods.verifyString(ModOutptPag.getErrorMessage(), "Invalid field name: field name is blank");
					ModOutptPag.DynInputOutputTableNameJXH_KON_IDSCN("IDSCAN");
					ModOutptPag.clickContinueButton();}

	@Title("DM UI Score Model Page Test Case")
	@Description("Data Menu UI Score Model Page Test Case")
	@Test(priority = 8,dataProvider = "InputData")
	public void DMProcessUITestCase9(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Score Models Select your Score Models, and click 'Continue'.");
					ScreModlPag.clickAddScoreModelButton();
					ScreModlPag.clickContinueButton();
					commMethods.verifyString(ScreModlPag.getErrorMessage(), "Please select score model.");
					ScreModlPag.removeScoreModel();
					ScreModlPag.clickContinueButton();}

	@Title("DM UI Config ID Scan Page Test Case")
	@Description("Data Menu UI Config ID Scan Page Test Case")
	@Test(priority = 9,dataProvider = "InputData")
	public void DMProcessUITestCase10(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Configure Id Scan Select the ID Scan options, and click 'Continue.'");
		ConfigIDPag.clickTagRButton();
		ConfigIDPag.clickRejectRButton();
		ConfigIDPag.clickRunIdScanCheckBox();
		commMethods.verifyboolean(ConfigIDPag.Ele_CheckALLCB.isEnabled(), false);
		commMethods.verifyboolean(ConfigIDPag.Ele_LFraudVicCB.isEnabled(), false);
		ConfigIDPag.clickRunIdScanCheckBox();
		commMethods.verifyboolean(ConfigIDPag.Ele_CheckALLCB.isEnabled(), true);
		commMethods.verifyboolean(ConfigIDPag.Ele_LFraudVicCB.isEnabled(), true);
		commMethods.verifyboolean(ConfigIDPag.Ele_CheckALLCB.isSelected(), false);
		commMethods.verifyboolean(ConfigIDPag.Ele_LFraudVicCB.isSelected(), false);
		ConfigIDPag.ClickCheckAllCB();
		commMethods.verifyboolean(ConfigIDPag.Ele_CheckALLCB.isSelected(), true);
		commMethods.verifyboolean(ConfigIDPag.Ele_LFraudVicCB.isSelected(), true);
		ConfigIDPag.ClickCheckAllCB();
		ConfigIDPag.clickContinueButton();
		commMethods.verifyString(ConfigIDPag.getErrorMessage(),"At least one option is required");
		ConfigIDPag.ClickCheckAllCB();
		ConfigIDPag.clickContinueButton();}


	@Title("DM UI Config DE Standard Page Test Case")
	@Description("Data Menu UI Config DE Standard Page Test Case")
	@Test(priority = 10,dataProvider = "InputData")
	public void DMProcessUITestCase11(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Configure DE Standard Select the DE Standard options, and click 'Continue.'");
		ConfigDEPag.clickRunDeStandardsChckBox();
		commMethods.verifyboolean(ConfigDEPag.CB_UseSameOption.isEnabled(), false);
		commMethods.verifyboolean(ConfigDEPag.CB_useSameDateCheck.isEnabled(), false);
		commMethods.verifyboolean(ConfigDEPag.DD_Source.isEnabled(), false);
		ConfigDEPag.clickRunDeStandardsChckBox();
		commMethods.verifyboolean(ConfigDEPag.CB_UseSameOption.isEnabled(), true);
		commMethods.verifyboolean(ConfigDEPag.CB_useSameDateCheck.isEnabled(), true);
		commMethods.verifyboolean(ConfigDEPag.DD_Source.isEnabled(), true);
		commMethods.verifyboolean(ConfigDEPag.CB_UseSameOption.isSelected(), true);
		commMethods.verifyboolean(ConfigDEPag.CB_useSameDateCheck.isSelected(), true);
		ConfigDEPag.selectSource("1");
		ConfigDEPag.selectSource("2");
		ConfigDEPag.clickuseSameDateCheck();
		ConfigDEPag.clickuseSameDateCheck();
		ConfigDEPag.clickContinueButton();}

	@Title("DM UI Double Check Page Test Case")
	@Description("Data Menu UI Double Check Page Test Case")
	@Test(priority = 11,dataProvider = "InputData")
	public void DMProcessUITestCase12(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Doublecheck Select Criteria below, and click 'Continue'.");
					DoubleChckPag.clickRunDoubleChckBox();
					DoubleChckPag.selectDoubleChckType("Standard Plus");
					DoubleChckPag.selectDoubleChckType("Standard Using ALL Addresses");
					DoubleChckPag.selectDoubleChckType("Citi");
					DoubleChckPag.selScrubType1("SSN_ADDRESS");
					DoubleChckPag.selScrubType1("SSN");
					DoubleChckPag.selScrubType1("ADDRESS");
					DoubleChckPag.clickContinueButton();
					commMethods.verifyString(DoubleChckPag.getErrorMessage(),"Please enter all required fields.* Required field* Required field");
					DoubleChckPag.RemoveDBChck();
					DoubleChckPag.clickAddOptionsButton();
					DoubleChckPag.sel_SSN_Tag();
					DoubleChckPag.sel_SSN_Reject();
					DoubleChckPag.sel_Addr_Tag();
					DoubleChckPag.sel_Addr_Reject();
					DoubleChckPag.clickRunDoubleChckBox();
					DoubleChckPag.clickRunDoubleChckBox();
					DoubleChckPag.clickEditImage();
					commMethods.verifyString(DoubleChckPag.get_Title_Edit_CC_code(),"Edit Criteria Codes/Options Choose criteria codes and options below,and click 'Save'");
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CritCodes_All);
					commMethods.verifyboolean(DoubleChckPag.CB_CritCodes_All.isSelected(), true);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_Options_ALL);
					commMethods.verifyboolean(DoubleChckPag.CB_Options_ALL.isSelected(), true);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CritCodes_All);
					commMethods.verifyboolean(DoubleChckPag.CB_CritCodes_All.isSelected(), false);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_Options_ALL);
					commMethods.verifyboolean(DoubleChckPag.CB_CritCodes_All.isSelected(), false);
					commMethods.verifyboolean(DoubleChckPag.CB_CC_A.isSelected(), false);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_A);
					commMethods.verifyboolean(DoubleChckPag.CB_CC_A.isSelected(), true);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_B);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_C);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_D);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_E);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_F);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_G);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_H);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_I);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_J);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_K);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_L);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_M);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_N);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_O);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_P);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_Q);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_R);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_S);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_T);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_U);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_V);	
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_W);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_X);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_Y);
					DoubleChckPag.sel_Element(DoubleChckPag.CB_CC_Z);
					commMethods.verifyboolean(DoubleChckPag.CB_CC_Z.isSelected(), true);
					commMethods.verifyboolean(DoubleChckPag.A_PHASE_SSN_DBCK.isSelected(), false);
					DoubleChckPag.sel_Element(DoubleChckPag.A_PHASE_SSN_DBCK);
					commMethods.verifyboolean(DoubleChckPag.A_PHASE_SSN_DBCK.isSelected(), true);
					DoubleChckPag.sel_Element(DoubleChckPag.B_ANB_BNKCRD_SSN_DBCK);
					DoubleChckPag.sel_Element(DoubleChckPag.C_ANB_BNKCRD_ADR_DBCK);
					DoubleChckPag.sel_Element(DoubleChckPag.D_ANB_PRV_LAB_SSN_DBCK);
					DoubleChckPag.sel_Element(DoubleChckPag.E_ANB_PRV_LAB_ADR_DBCK);
					DoubleChckPag.sel_Element(DoubleChckPag.F_AGENT_BANK_SSN_ADR);
					DoubleChckPag.sel_Element(DoubleChckPag.G_ANB_PL96_LVL_A);
					DoubleChckPag.sel_Element(DoubleChckPag.H_ANB_PL96_LVL_B_to_E);
					DoubleChckPag.sel_Element(DoubleChckPag.I_USA_SSN_ADR_DBCK);
					DoubleChckPag.sel_Element(DoubleChckPag.J_OLD_PHASE_SSN_DBCK);
					DoubleChckPag.click_Save_Edit_Crit();
					DoubleChckPag.clickContinueButton();}

	@Title("DM UI Filter Configuration Page Test Case")
	@Description("Data Menu UI Filter Configuration Page Test Case")
	@Test(priority = 12,dataProvider = "InputData")
	public void DMProcessUITestCase13(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(DMFilterConPag.DMFC_Title.getText(),"Data Menu Filter/Configuration");
					commMethods.verifyboolean(DMFilterConPag.CB_DNSdrop.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_DNSdrop.isEnabled(),true);
					DMFilterConPag.clickDNSdropChckBox();
					DMFilterConPag.clickDNSdropChckBox();
					commMethods.verifyboolean(DMFilterConPag.CB_InvalidBlankAgeDrop.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_InvalidBlankAgeDrop.isEnabled(),true);
					DMFilterConPag.clickInvalidBlankAgeChckBox();
					DMFilterConPag.clickInvalidBlankAgeChckBox();
					commMethods.verifyboolean(DMFilterConPag.CB_Fact_Act.isSelected(),false);
					commMethods.verifyboolean(DMFilterConPag.CB_Fact_Act.isEnabled(),false);
					commMethods.verifyboolean(DMFilterConPag.CB_Invalid_Drop.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_Invalid_Drop.isEnabled(),false);
					commMethods.verifyboolean(DMFilterConPag.CB_TestFileDrop.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_TestFileDrop.isEnabled(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_ID_Scan.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_ID_Scan.isEnabled(),false);
					DMFilterConPag.clickFactActEdit();
					commMethods.verifyString(DMFilterConPag.Title.getText(),"Configure FACT Act Select FACT Act configuration options, and click 'Save'");
//					DMFilterConPag.click_FactAct_Reject_Address_Variance_Code_CB();
					commMethods.verifyboolean(DMFilterConPag.CB_Create_540_file.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_Create_540_file.isEnabled(),false);
//					DMFilterConPag.click_Fact_Act_Reject_Fraud_Code();
//					DMFilterConPag.click_Fact_Act_Reject_AFS_Alert_Data_BFMN();
					DMFilterConPag.click_Save_button_Fact_Act();
					commMethods.verifyboolean(DMFilterConPag.CB_Fact_Act.isSelected(),true);
					commMethods.verifyboolean(DMFilterConPag.CB_Fact_Act.isEnabled(),false);
					DMFilterConPag.click_Edit_Invalid_Drop();
					commMethods.verifyString(DMFilterConPag.Title.getText(),"Configure Invalid Drop Select Invalid Drop configuration options, and click 'Save'");
					DMFilterConPag.click_Conf_Inv_Drop_ALL();
					commMethods.verifyboolean(DMFilterConPag.CB_Conf_Inv_Drop_ALL.isSelected(), false);
					commMethods.verifyboolean(DMFilterConPag.CB_Conf_Inv_Drop_Invalid_Name_Address.isSelected(), false);
					DMFilterConPag.click_Conf_Inv_Drop_ALL();
					commMethods.verifyboolean(DMFilterConPag.CB_Conf_Inv_Drop_ALL.isSelected(), true);
					commMethods.verifyboolean(DMFilterConPag.CB_Conf_Inv_Drop_Invalid_Name_Address.isSelected(), true);
					ProjDashBoardPage.clickCloseButtonStats();
					DMFilterConPag.click_Edit_ID_Scan();}

	@Title("DM UI Config ID Scan Page Test Case 2")
	@Description("Data Menu UI Config ID Scan Page Test Case 2")
	@Test(priority = 13,dataProvider = "InputData")
	public void DMProcessUITestCase14(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Configure Id Scan Select the ID Scan options, and click 'Continue.'");
					ConfigIDPag.clickContinueButton();}

	@Title("DM UI Config DE Standard Page Test Case 2")
	@Description("Data Menu UI Config DE Standard Page Test Case 2")
	@Test(priority = 14,dataProvider = "InputData")
	public void DMProcessUITestCase15(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Configure DE Standard Select the DE Standard options, and click 'Continue.'");
					ConfigDEPag.clickContinueButton();}

	@Title("DM UI Double Check Page Test Case 2")
	@Description("Data Menu UI Double Check Page Test Case 2")
	@Test(priority = 15,dataProvider = "InputData")
	public void DMProcessUITestCase16(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Doublecheck Select Criteria below, and click 'Continue'.");
					DoubleChckPag.clickContinueButton();}

	@Title("DM UI Filter Configuration Page Test Case 2")
	@Description("Data Menu UI Filter Configuration Page Test Case 2 Click Save button and Verify Page Title")
	@Test(priority = 16,dataProvider = "InputData")
	public void DMProcessUITestCase17(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Menu Filter/Configuration");
					DMFilterConPag.click_Save_Fil_Config_Screen();}

	@Title("DM UI Filter Configuration Page Test Case 3")
	@Description("Data Menu UI Filter Configuration Page Test Case 3")
	@Test(priority = 17,dataProvider = "InputData")
	public void DMProcessUITestCase18(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Data Menu Filter/Configuration");
		DMFilterConPag.clickContinueButton();
	}

	@Title("DM UI Credit Input Page Test Case")
	@Description("Data Menu UI Credit Input Page Test Case")
	@Test(priority = 18,dataProvider = "InputData")
	public void DMProcessUITestCase19(String testRun, String TC, String Description, String processName, 
			String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess, 
			String dataField, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
			String APModuleCriteria, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
			String NCPScoreModel, String idScan, String idScanRejects, String deStandard, String doublechck, 
			String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, 
			String availableDataSets, String dataSetType, String DataSet, ITestContext testContext)
					throws Exception {
		commMethods.verifyString(ProjDashBoardPage.getPageTitle(),"Credit Input Select a Credit Input(s), and click 'Continue'.");
		commMethods.verifyboolean(CreditInPag.CB_Unique_CID.isEnabled(), true);
		CreditInPag.click_Unique_CID();
		commMethods.verifyboolean(CreditInPag.CB_Unique_CID.isSelected(), false);
		CreditInPag.click_Unique_CID();
		commMethods.verifyboolean(CreditInPag.CB_Unique_CID.isSelected(), true);
		CreditInPag.sel_Use_recent_Dataset_Rad();
//		CreditInPag.sel_specific_Dataset_Rad();
		commMethods.verifyboolean(CreditInPag.CB_Hundred_perc.isEnabled(), true);
		commMethods.verifyboolean(CreditInPag.CB_Unique_CID.isSelected(), true);
		CreditInPag.sel_Hundred_perc_CB();
		commMethods.verifyboolean(CreditInPag.CB_Unique_CID.isSelected(), true);
		CreditInPag.sel_Hundred_perc_CB();
		CreditInPag.selectDataSetType(dataSetType);
		CreditInPag.clickContinueButton();
		commMethods.verifyString(CreditInPag.getErrorMessage(),"Please select atleast one dataset");
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("document.getElementById('"+DataSet+"').setAttribute('class', 'name1 active')");
		Thread.sleep(500);
		driver.findElement(By.xpath(".//*[@class='name1 active']")).click();
		Thread.sleep(500);
		CreditInPag.clickAddButton();
		CreditInPag.clickContinueButton();
		driver.quit();}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}

	@DataProvider
	public Object[][] InputData() throws Exception {

		Object[][] testObjArray = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir")+PropertiesUtils.getProperty("path"), "DMProcessUI","UI");

		return (testObjArray);

	}

}
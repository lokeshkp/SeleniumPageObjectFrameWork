package com.equifax.cms.fusion.test;

import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.rules.TestWatcher;
import org.junit.runner.Description;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Attachment;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.ExcelReader;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;

/**
 * core base test case To enable selenium web driver
 *
 * @author sxr236
 *
 */
public class AbstractCoreTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(FusionCoreTestContext.class);
    public static final String ASCII_FIXED = "ASCII Fixed";
    public static final String ASCII_DELIMITED = "ASCII Delimited";
    public static final String EBCDIC_FIXED = "EBCDIC Fixed";

	protected static WebDriver driver;
	protected String baseUrl;
	protected OracleDBHelper db;
	protected boolean login = false;
	protected boolean search = false;
	private int count = 0;
	private boolean init = false;
	private StringBuffer verificationErrors = new StringBuffer();
	protected ExcelReader reader;

	private void init() {
		if (!init) {
			this.baseUrl = PropertiesUtils.getProperty("base.url");
			this.db = new OracleDBHelper();
			this.reader = new ExcelReader();
		}
	}

	@BeforeClass
	public static void initialize() {
		//driver = FusionFirefoxDriver.getDriver();
	    driver = FusionChromeDriver.getDriver();
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
	}

	@AfterClass
	public static void destroy() {
		driver.quit();
	}

	@Before
	public void setUp() throws Exception {
		// init first time
		init();
		// set count 0 for each test case
		count = 0;
	}

	@After
	public void tearDown() throws Exception {

		db.closeConnection();
		if (!"".equals(verificationErrors.toString())) {
			fail(verificationErrors.toString());
		}
	}

	@Step("Login")
	public void userLogin() {

		if (!isLogin()) {
			// get user name from proeperty file
			driver.get(baseUrl + "/cms-fusion-web/login");
			driver.findElement(By.id("j_username")).clear();
			driver.findElement(By.id("j_username")).sendKeys(PropertiesUtils.getProperty("user"));
			LOGGER.debug("Logging as Username : {} ", PropertiesUtils.getProperty("user"));
			driver.findElement(By.id("j_password")).clear();
			driver.findElement(By.id("j_password")).sendKeys(PropertiesUtils.getProperty("password"));
			driver.findElement(By.id("submitButton")).click();

			// set login to true, one time login
			setLogin(true);
		}
	}

	// Search a project
	@Step("Search project : {0}")
	public void searchProject(String projectNumber) {

		if (!isSearch()) {
			driver.findElement(By.id("cms_search")).click();
			driver.findElement(By.id("projectNumber")).clear();
			driver.findElement(By.id("projectNumber")).sendKeys(projectNumber);
			driver.findElement(By.id("searchButton")).click();
			driver.findElement(By.linkText(projectNumber)).click();
			LOGGER.debug("Search Project Number : {} ", projectNumber);
			setSearch(true);
		}
	}

	public String waitAndCheckProcessStatus(Long jobId, String status) {
		while (status.equals("PROCESSING")) {
			try {
				Thread.sleep(30000);
				status = db.getStatusForJob(jobId);
				// try for three times
				if (count > 3) {
					// status = "FAILED";
					break;
				}
				count++;
			} catch (InterruptedException e) {
				LOGGER.error("Thread wait error {} ", e.getMessage());
			}
		}
		return status;
	}

	@Attachment("User Input {0}")
	public byte[] createAttachment(String content) {
		return content.getBytes();
	}

	@Attachment("Exception Message {0}")
	public byte[] captureExceptionMessage(String error) {
		return error.getBytes();
	}

	@Rule
	public TestWatcher screenshotOnFailure = new TestWatcher() {
		@Override
		protected void failed(Throwable e, Description description) {
			captureExceptionMessage(e.getMessage());
			makeScreenshotOnFailure();
		}

		@Attachment("Screenshot")
		public byte[] makeScreenshotOnFailure() {
			return ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
		}
	};

	// Navigates to the process
	@Step("navigate to process {0}")
	public void navigateToProcess(String processName) {
		driver.findElement(By.linkText(processName)).click();
	}

	// Navigates to new process
	@Step("Create new {0} process ")
	public void navigateToNewProcessPage(String processName) {
		driver.findElement(By.linkText(processName)).click();

	}

	// Sets a timeout
	public void setTimeout(int time) {
		driver.manage().timeouts().setScriptTimeout(time, TimeUnit.SECONDS);
	}

	// Waits for ajax request to complete
	public void waitForAjax() throws InterruptedException {
		while (true) {
			Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
			if (ajaxIsComplete) {
				break;
			}
			Thread.sleep(100);
		}
	}

	@Step("Save process")
	public void selectSave() {
		driver.findElement(By.name("submitButton")).click();
	}

	@Step("Get job id")
	public String getJobId() {
		String value = driver.findElement(By.cssSelector("td.main-table-border.id-style")).getText();
		String jobId = value.trim();
		return jobId;
	}

    // Gets status for sourcematch process
	@Step("Get process status")
    public String getStatusSM()
    {
		String xpath = reader.getXpathRef().get("sm.process.status");
		String status = driver.findElement(By.xpath(xpath)).getText();
		return status;
	}

    // Gets status for Input Process
    @Step("Get process status")
    public String getStatusIP()
    {
		String xpath = reader.getXpathRef().get("ip.process.status");
		String status = driver.findElement(By.xpath(xpath)).getText();
        return status;
    }

	// Selects Edit tab from context menu
	@Step("Edit process")
	public void selectEdit() {
		String xpath = reader.getXpathRef().get("edit.process");
		driver.findElement(By.xpath(xpath)).click();

		for (int second = 0;; second++) {
			if (second >= 20) {
				fail("timeout");
			}
			try {
				if (isElementPresent(By.id("Edit"))) {
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			delayThread(1000);
		}
		driver.findElement(By.id("Edit")).click();
	}

    // Selects duplicate tab from context menu and selects yes to duplicate *****Donot use this, use the duplicateProcess()
    // method*****
	@Step("duplicate process")
	public void selectDuplicate() {

		String xpath = reader.getXpathRef().get("duplicate.process");
		driver.findElement(By.xpath(xpath)).click();
		for (int second = 0;; second++) {
			if (second >= 20) {
				fail("timeout");
			}
			try {
				if (isElementPresent(By.id("Duplicate"))) {
					break;
				}
			} catch (Exception e) {
			}
			delayThread(1000);
		}

		driver.findElement(By.id("Duplicate")).click();
		for (int second = 0;; second++) {
			if (second >= 20) {
				fail("timeout");
			}
			try {
				if (isElementPresent(By.id("sb-player"))) {
					break;
				}
			} catch (Exception e) {
				System.out.println(e);
			}
			delayThread(1000);
		}
		delayThread(1000);
		xpath = reader.getXpathRef().get("duplicate.process.sel");
		driver.findElement(By.xpath(xpath)).click();
		delayThread(1000);
	}

    // Selects duplicate tab from context menu and selects yes to duplicate using process name
    @Step("duplicate process")
    public void duplicateProcess()
    {
        driver.findElement(By.id("Duplicate")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("sb-player")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            delayThread(1000);
        }
        delayThread(1000);
        String xpath = reader.getXpathRef().get("duplicate.process.sel");
        driver.findElement(By.xpath(xpath)).click();
        delayThread(1000);
    }

	@Step("Submit")
	public void selectSubmit() {
		driver.findElement(By.id("submitButton")).click();
	}

	@Step("Navigate home")
	public void navigateToHome() {
		driver.findElement(By.cssSelector("#home > a")).click();
	}

	@Step("Logout ")
	public void userLogout() {
		driver.findElement(By.linkText("Logout")).click();
	}

	@Step("Select summary")
	public void selectSummary() {

		String xpath = reader.getXpathRef().get("summary.process");
		driver.findElement(By.xpath(xpath)).click();

		for (int second = 0;; second++) {
			if (second >= 20) {
				fail("timeout");
			}
			try {
				if (isElementPresent(By.id("Summary"))) {
					break;
				}
			} catch (Exception e) {
			}
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		driver.findElement(By.id("Summary")).click();
	}

    @Step("Accept alert and get text")
    public String acceptAndGetAlertText()
    {
        // WebDriverWait wait = new WebDriverWait(driver, 3);
        // wait.until(ExpectedConditions.alertIsPresent());

        String alertText = null;
        try
        {
            if (isAlertPresent())
            {
                alertText = closeAlertAndGetItsText();
            }

        } catch (Exception e)
        {
            e.printStackTrace();
        }

        return alertText;
    }

    @Step("IP Submit with no datacheck")
    public void testIPSubmitNoDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    @Step("IP Submit with datacheck")
    public void testIPSubmit(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    public void testIPSubmitWithDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 4);

        // Verify values from greenplum
    }

    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

    private String closeAlertAndGetItsText()
    {
        boolean acceptNextAlert = true;

        try
        {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert)
            {
                alert.accept();
            } else
            {
                alert.dismiss();
            }
            return alertText;
        } finally
        {
            acceptNextAlert = true;
        }
    }

	public void delayThread(int millis) {
		try {
			Thread.sleep(millis);
		} catch (InterruptedException e) {
			LOGGER.error("Error while thread wait {}", e);
			e.printStackTrace();
		}
	}

	public boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (NoSuchElementException e) {
			return false;
		}
	}

	public boolean isLogin() {
		return login;
	}

	public void setLogin(boolean login) {
		this.login = login;
	}

	public boolean isSearch() {
		return search;
	}

	public void setSearch(boolean search) {
		this.search = search;
	}

    public boolean getAllowedCharacter(String name)
    {
        String regex = "^[a-zA-Z0-9_]*$";
        if (!name.matches(regex))
        {
            return true;
        }
        return false;
    }

    public boolean isReservedKeyword(String field)
    {
        // Add more reserved keywords
        List<String> reservedKeywords = new ArrayList<String>();
        reservedKeywords.add("CID");
        if (reservedKeywords.contains(field))
        {
            return true;
        }
        return false;
    }

    public int getNumberOfRowsConstTable()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='fieldTableForConst']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfColumnsLayoutTable()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='previewTable']/thead/tr[1]/td"));

        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfRowsLayoutTable()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='fieldTable']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfRowsExistingLayoutsForIPDelimited()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='savedLayoutsTable1']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfRowsExistingLayoutsForIPFixed()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfRowsExistingLayoutsForIPEBCDICFixed()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='savedLayoutsTable2']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    public int getNumberOfRowsOtherProjectLayoutTable()
    {

        List<WebElement> list = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

    /**
     * select all fields before adding field
     */
    public void selectAllFieldType(String fieldType, final String format)
    {
        new Select(driver.findElement(By.id(fieldType))).selectByVisibleText("Customize...");
        if (!driver.findElement(By.id("SUFFIX")).isSelected())
        {
        driver.findElement(By.id("SUFFIX")).click();
        }
        if (!driver.findElement(By.id("STREET_NAME")).isSelected())
        {
        driver.findElement(By.id("STREET_NAME")).click();
        }
        if (!driver.findElement(By.id("BIRTH_YEAR")).isSelected())
        {
        driver.findElement(By.id("BIRTH_YEAR")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_2nd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_1_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).isSelected())
        {
            driver.findElement(By.id("ADDRESS_FREEFORM_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_ZIP_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_STATE_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_CITY_5th")).click();
        }
        if (!driver.findElement(By.id("INQUIRY_TYPE")).isSelected())
        {
        driver.findElement(By.id("INQUIRY_TYPE")).click();
        }
        if (!driver.findElement(By.id("NAME_FREE_FORM_LSFM")).isSelected())
        {
        driver.findElement(By.id("NAME_FREE_FORM_LSFM")).click();
        }
        if (!driver.findElement(By.id("STREET_TYPE")).isSelected())
        {
        driver.findElement(By.id("STREET_TYPE")).click();
        }
        if (!driver.findElement(By.id("AGE")).isSelected())
        {
        driver.findElement(By.id("AGE")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_1")).isSelected())
        {
        driver.findElement(By.id("SCORE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_2nd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_2_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_1_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_FREEFORM_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_ZIP_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_STATE_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_DAY")).isSelected())
        {
        driver.findElement(By.id("DATE_DAY")).click();
        }
        if (!driver.findElement(By.id("PROJECT_NUMBER")).isSelected())
        {
        driver.findElement(By.id("PROJECT_NUMBER")).click();
        }
        if (!driver.findElement(By.id("STREET_POST_DIRECTION")).isSelected())
        {
        driver.findElement(By.id("STREET_POST_DIRECTION")).click();
        }
        if (!driver.findElement(By.id("SCORE_PARAMETER_2")).isSelected())
        {
        driver.findElement(By.id("SCORE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_2nd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_CITY_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_2_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_1_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_FREEFORM_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_ZIP_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_MONTH")).isSelected())
        {
        driver.findElement(By.id("DATE_MONTH")).click();
        }
        if (!driver.findElement(By.id("CID")).isSelected())
        {
        driver.findElement(By.id("CID")).click();
        }
        if (!driver.findElement(By.id("MIDDLE_NAME")).isSelected())
        {
        driver.findElement(By.id("MIDDLE_NAME")).click();
        }
        if (!driver.findElement(By.id("STREET_NUMBER")).isSelected())
        {
        driver.findElement(By.id("STREET_NUMBER")).click();
        }
        if (!driver.findElement(By.id("CSZ_FREEFORM")).isSelected())
        {
        driver.findElement(By.id("CSZ_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP_WPLUS_4")).isSelected())
        {
        driver.findElement(By.id("ZIP_WPLUS_4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_MONTH")).isSelected())
        {
        driver.findElement(By.id("BIRTH_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).isSelected())
        {
        driver.findElement(By.id("ATTRIBUTE_PARAMETER_1")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_2nd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_STATE_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_CITY_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_2_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_1_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_1_5th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_FREEFORM_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_FREEFORM_5th")).click();
        }
        if (!driver.findElement(By.id("DATE_YEAR")).isSelected())
        {
        driver.findElement(By.id("DATE_YEAR")).click();
        }
        if (!driver.findElement(By.id("CONNEXUS_KEY")).isSelected())
        {
        driver.findElement(By.id("CONNEXUS_KEY")).click();
        }
        if (!driver.findElement(By.id("STREET_PRE_Direction")).isSelected())
        {
        driver.findElement(By.id("STREET_PRE_Direction")).click();
        }
        if (!driver.findElement(By.id("CITY_STATE_FREEFORM")).isSelected())
        {
        driver.findElement(By.id("CITY_STATE_FREEFORM")).click();
        }
        if (!driver.findElement(By.id("ZIP4")).isSelected())
        {
        driver.findElement(By.id("ZIP4")).click();
        }
        if (!driver.findElement(By.id("BIRTH_DAY_MONTH")).isSelected())
        {
        driver.findElement(By.id("BIRTH_DAY_MONTH")).click();
        }
        if (!driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).isSelected())
        {
        driver.findElement(By.id("ATTRIBUTE_PARAMETER_2")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_ZIP_2nd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_ZIP_2nd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_STATE_3rd")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_STATE_3rd")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_CITY_4th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_CITY_4th")).click();
        }
        if (!driver.findElement(By.id("ADDRESS_LINE_2_5th")).isSelected())
        {
        driver.findElement(By.id("ADDRESS_LINE_2_5th")).click();
        }
        if (!driver.findElement(By.id("MEMBER_NUMBER")).isSelected())
        {
        driver.findElement(By.id("MEMBER_NUMBER")).click();
        }
        if (!driver.findElement(By.id("DATE_CENTURY")).isSelected())
        {
        driver.findElement(By.id("DATE_CENTURY")).click();
        }

        if (ASCII_FIXED.equalsIgnoreCase(format) || EBCDIC_FIXED.equalsIgnoreCase(format))
        {
            driver.findElement(By.xpath("//button[@type='button']")).click();
        } else if (ASCII_DELIMITED.equalsIgnoreCase(format))
        {
            driver.findElement(By.xpath("(//button[@type='button'])[3]")).click();
        }
    }

}

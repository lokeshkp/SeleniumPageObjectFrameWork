package com.equifax.cms.fusion.test.ip;

import java.util.List;
import java.util.Random;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.utils.ExcelReader;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.InputLayoutVO;
import com.equifax.cms.fusion.test.vo.InputProcessVO;

public class InputFixedValidationTest extends AbstractCoreTest
{
    private static final Logger LOGGER = LoggerFactory.getLogger(InputFixedValidationTest.class);
private static final String IP = "Input";
WebDriverWait wait;
    ExcelReader reader = new ExcelReader();
    boolean flag = false;

    // Add all error messages to the string for the layout page
    private static final String ERRORMSGS = "CID can not be Field Name , Fields overlap. Please verify positions, Field names can contain letters, numbers and underscores, Value is required";

    
    @Step("IP Validation Tests")
    public void testIPValidateProcess() throws Exception
    {
        LOGGER.debug("-- IP validate input -- ");
        List<InputProcessVO> list = reader.getInputProcessData();

        userLogin();
        String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
        searchProject(projectNumber);
        for (InputProcessVO vo : list)
        {
            // Save ip process
            if (ProcessOperationEnum.VALIDATE.name().equalsIgnoreCase(vo.getOperation()))
            {
                validateIPLayout(vo.getProcessName(), vo);

            }
        }
        userLogout();
        LOGGER.debug("--  logout -- ");

    }

    @Step("Validate {0}")
    public void validateIPLayout(String processName, InputProcessVO vo) throws Exception
    {
       
       navigateToProcess(IP);
       navigateToNewProcessPage("Import New File");

        // Test Case : Process name is empty
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("submitLayout")).click();

        String errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Process Name is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Test Case : Filepath is empty
        flag = false;
        driver.findElement(By.id("filePath")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("File Location is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);
        
        // Test Case : Record length is empty
        flag = false;
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Record Length is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);
        
        // Test Case : Sequence number is empty
        flag = false;
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Starting Sequence Number is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Provide process name,reclen,filepath and starting seq no //get from csv
        driver.findElement(By.id("processName")).sendKeys(vo.getProcessName());// Get from csv
        driver.findElement(By.id("filePath")).sendKeys(vo.getLocation());
        driver.findElement(By.id("recLen")).sendKeys(vo.getRecordLength());
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(vo.getStartingSeq());

        // Test Case : Existing layout radio button is selected, but no existing layout is checked
        driver.findElement(By.id("existingLayoutRadio")).click();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Please select layout from list"))
        {
            flag = true;
        }
        Assert.assertTrue(flag == true);

        flag = false;

        int i = 1;

        List<InputLayoutVO> layout = reader.getInputLayout(vo.getLayoutName());

        // If existing layout is used
        if ("Existing Layout".equalsIgnoreCase(vo.getInputLayout()))
        {
        int noOfRows = getNumberOfRows();

        while (flag == false && i <= noOfRows)
        {
            String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]")).getText();
            if (str.equals(vo.getLayoutName())) // Get from csv
            {
                flag = true;

                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]/../*[1]/*")).click();
                break;
            }
            i++;
        }

        // Could not find the layout from the list
        Assert.assertFalse("Layout not found",flag == false);

        // Use existing layout with the fields provided in csv
            driver.findElement(By.id("existingLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            validateLayoutPage(vo.getLayoutName(), vo.getFormat(), layout, vo.getLayoutNameNew());
        }

        // If create new layout is provided, a new layout created with the fields provided in csv
        if ("Create New Layout".equalsIgnoreCase(vo.getInputLayout()))
        {
            driver.findElement(By.id("newLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            validateLayoutPage(vo.getLayoutName(), vo.getFormat(), layout, vo.getLayoutNameNew());
        }

        // Continue to datacheck screen
        selectSubmit();
        delayThread(30000);
        // Continue to datacheck page
        flag = false;
        
        // If datacheck checkbox is not selected, values need to be there
        if (("0").equals(vo.getIsDataCheck()))
        {
            selectSubmit();

            if (null != vo.getFileIdentifier())
            {
                if ("Select".equals(vo.getFileIdentifier()))
                {
                    errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div[1]/label")).getText();
                    if (errMsg.contains("Please select File Identifier"))
                    {
                        flag = true;
                    }
                    Assert.assertTrue(flag == true);
                } else
                {
                    driver.findElement(By.id("fileIdentifier")).sendKeys(vo.getFileIdentifier()); // Get from csv
                }
            }
 else
            {
                Assert.assertFalse("File Indentifier is required", null == vo.getFileIdentifier());
            }

            if (null != vo.getRuntimeB())
                {
                if ("Select".equals(vo.getRuntimeB()))
                {
                    errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div[1]/label")).getText();
                    if (errMsg.contains("Please select RuntimeB"))
                    {
                        flag = true;
                    }
                    Assert.assertTrue(flag == true);
                } else
                    {
                    driver.findElement(By.id("runtimeB")).sendKeys(vo.getRuntimeB()); // Get from csv
                    }
                }
 else
            {
                Assert.assertFalse("RuntimeB is required", null == vo.getRuntimeB());
            }
            }

        // just check the datacheck and continue
            if (!driver.findElement(By.id("isDataCheck")).isSelected())
                driver.findElement(By.id("isDataCheck")).click();

        // Continue to summary screen
        selectSubmit();

    }

    private int getNumberOfRows()
    {
        List<WebElement> list = driver.findElements(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr"));
        int noOfRows = list.size();
        return noOfRows;
    }

  @Step("Create new layout {0} ")
    private void validateLayoutPage(String layoutName, String format, List<InputLayoutVO> layout, String newLayoutName)
    {
        int position = 0;
        List<WebElement> list = driver.findElements(By.id("addField"));
        // Click the first addField button for fields
        if (getNumberOfRowsLayoutTable() == 0)
            position = 0;
        else
        {
            position = getNumberOfRowsLayoutTable() + 1;
            list.get(0).click();
        }
        // Fieldtype starts from 0
        int constCounter = getNumberOfRowsConstTable();
        String alertText = null;

        boolean selectAll = false;
        for (InputLayoutVO field : layout)
        {
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }

            /*
             * if (null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows());
             */

            // If alert is present accept the alert
            // acceptAndGetAlertText();

            if (null != field.getFieldType())
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());

            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getFieldName())
            {
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
                Boolean checkReservedTrue = isReservedKeyword(field.getFieldName());

                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("start" + position)).sendKeys(field.getStartPos());
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("end" + position)).sendKeys(field.getEndPos());

                if (checkReservedTrue)
                {
                    driver.findElement(By.id("save")).click();
                    alertText = acceptAndGetAlertText();
                    Assert.assertTrue(ERRORMSGS.contains(alertText));
                    // Concatenating the name with some string to change it so that validation is removed and go to next step
                    driver.findElement(By.id("name" + position)).sendKeys("test");
                }

                // Test Case : Start position should be less than end position or fields overlap error may come
                boolean errorFlag = false;
                if (Integer.parseInt(field.getStartPos()) >= Integer.parseInt(field.getEndPos()))
                {
                    driver.findElement(By.id("save")).click();
                    alertText = acceptAndGetAlertText();
                    if (alertText.startsWith("Error"))
                        errorFlag = true;
                    if (ERRORMSGS.contains(alertText))
                        errorFlag = true;

                    Assert.assertTrue(errorFlag);

                // Clear all fields, and now check validations on constant
                errorFlag = false;
                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("len" + position)).clear();

                    // Switching start and end positions
                    driver.findElement(By.id("start" + position)).sendKeys(field.getEndPos());
                    driver.findElement(By.id("end" + position)).sendKeys(field.getStartPos());

                }

            }

            if (null != field.getConstName() && null != field.getConstValue())
            {
                // Add constant
                List<WebElement> l = driver.findElements(By.id("addField"));
                // Click the second addField button for constant
                l.get(1).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());
                boolean isAllowed = getAllowedCharacter(field.getConstName());

                if (isAllowed)
                {
                    driver.findElement(By.id("save")).click();
                    alertText = acceptAndGetAlertText();
                    if (null != alertText)
                        Assert.assertTrue(alertText.startsWith("Invalid name for a field"));
                }

                // Creating a random number
                Random rand = new Random();
                int value = rand.nextInt(50);

                // Clear the wrong values and add a correct one
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys("correctFormatConst" + value);

                constCounter++;
            }
 else
            {
                Assert.assertFalse("Blank constant name and value, validation could not be done", false);
            }

            // Layout name already exists, provide a new one

            selectSubmit();
            delayThread(20000);
            alertText = acceptAndGetAlertText();
            if (null != alertText)
                Assert.assertTrue(alertText.startsWith("Error"));

            // Provide the new layout name
            driver.findElement(By.id("layoutName")).clear();
            driver.findElement(By.id("layoutName")).sendKeys(newLayoutName);

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }

    }

    @Step("Edit existing layout {0} ")
    private void editExistingLayout(String layoutName, String format)
    {
        List<InputLayoutVO> layout = reader.getInputLayout(layoutName);
        // driver.findElement(By.id("layoutName")).sendKeys(layoutName);

        int i = 1;
        boolean flag = false;
        int noOfRows = getNumberOfRows();
        while (flag == false && i <= noOfRows)
        {
            String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]")).getText();
            if (str.equals(layoutName)) // Get from csv
            {
                flag = true;
                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[1]/input")).click();
                break;
            }
            i++;
        }

        // Go to existing layout page
        driver.findElement(By.id("submitLayout")).click();

        // Fieldtype starts from 1
        int position = getNumberOfRowsLayoutTable() + 1;
        int constCounter = getNumberOfRowsConstTable();

        boolean selectAll = false;
        String alertText = null;

        for (InputLayoutVO field : layout)
        {
            driver.findElement(By.id("addField")).click();
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }
            /*
             * if (null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows()); //
             * If alert is present accept the alert acceptAndGetAlertText();
             */

            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getFieldName())
            {
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
                Boolean checkReservedTrue = isReservedKeyword(field.getFieldName());

                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("start" + position)).sendKeys(field.getStartPos());
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("end" + position)).sendKeys(field.getEndPos());

                if (checkReservedTrue)
                {
                    driver.findElement(By.id("save")).click();
                    alertText = acceptAndGetAlertText();
                    Assert.assertTrue(ERRORMSGS.contains(alertText));
                    // Concatenating the name with some string to change it so that validation is removed and go to next step
                    driver.findElement(By.id("name" + position)).sendKeys("test");
                }

                // Test Case : Start position should be less than end position or fields overlap error may come
                boolean errorFlag = false;
                if (Integer.parseInt(field.getStartPos()) >= Integer.parseInt(field.getEndPos()))
                {
                    driver.findElement(By.id("save")).click();
                    alertText = acceptAndGetAlertText();
                    if (alertText.startsWith("Error"))
                        errorFlag = true;
                    if (ERRORMSGS.contains(alertText))
                        errorFlag = true;

                    Assert.assertTrue(errorFlag);

                }

                // Clear all fields, and now check validations on constant
                errorFlag = false;
                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("len" + position)).clear();

            }

            if (null != field.getConstName() && null != field.getConstValue())
            {
                // Add constant
                List<WebElement> list = driver.findElements(By.id("addField"));
                // Click the second addField button for constant
                list.get(1).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());

                driver.findElement(By.id("save")).click();

                boolean isAllowed = getAllowedCharacter(field.getConstName());

                if (isAllowed)
                {
                    alertText = acceptAndGetAlertText();
                    if (null != alertText)
                        Assert.assertTrue(alertText.startsWith("Invalid name for a field"));
                }

                // Creating a random number
                Random rand = new Random();
                int value = rand.nextInt(50);

                // Clear the wrong values and add a correct one
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys("correctFormatConst" + value);

                constCounter++;
            }
 else
            {
                Assert.assertFalse("Blank constant name and value, validation could not be done", false);
            }

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }

    }

}


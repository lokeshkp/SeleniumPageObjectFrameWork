package com.equifax.cms.fusion.test.input;

import static org.junit.Assert.fail;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Stories;

public class InputFixedNegativeTestCases
{
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
    private static final Logger LOGGER = LoggerFactory.getLogger(InputFixedNegativeTestCases.class);
	private OracleDBHelper db;
    private static final String IP = "Input";
    Alert alert = null;

    // Add all error messages to the string for the layout page
    private static final String ERRORMSGS = "CID can not be Field Name , Fields overlap. Please verify positions, Field names can contain letters, numbers and underscores";

    @Before
    public void setUp() throws Exception
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		db = new OracleDBHelper();

    }

    @Features("Input fixed ascii process negative scenarios")
    @Stories("US #3")
    @Test
    public void testIPFixedLayout() throws Exception
    {
        String status = null;
        boolean flag = true;
        Modules module = new Modules();
        module.initializeDriver(driver);
        module.userLogin();
        module.searchProject();
        module.navigateToProcess(IP);
        module.navigateToNewProcessPage("Import New File");

        // Test Case : Process name is empty
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("submitLayout")).click();

        String errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Process Name is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Test Case : Filepath is empty
        flag = false;
        driver.findElement(By.id("filePath")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("File Location is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Test Case : Record length is empty
        flag = false;
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Record Length is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Test Case : Sequence number is empty
        flag = false;
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Starting Sequence Number is required"))
        {
            flag = true;
        }

        Assert.assertTrue(flag == true);

        // Provide process name,reclen,filepath and starting seq no //get from csv
        driver.findElement(By.id("processName")).sendKeys("ipntest");// Get from csv
        driver.findElement(By.id("filePath")).sendKeys(PropertiesUtils.getProperty("ipFilePath"));
        driver.findElement(By.id("recLen")).sendKeys(PropertiesUtils.getProperty("ipReclen"));
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(PropertiesUtils.getProperty("ipSeqno"));

        // Test Case : Existing layout radio button is selected, but no existing layout is checked
        driver.findElement(By.id("existingLayoutRadio")).click();
        driver.findElement(By.id("submitLayout")).click();

        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div")).getText();

        if (errMsg.contains("Please select layout from list"))
        {
            flag = true;
        }
        Assert.assertTrue(flag == true);

        flag = false;

        int i = 1;
        while (flag == false && i < 100)
        {
            String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]")).getText();
            if (str.equals("test_layout_1101")) // Get from csv
            {
                flag = true;

                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]/../*[1]/*")).click();
                break;
            }
            i++;
        }

        driver.findElement(By.id("submitLayout")).click();

        // Move to the layout page

        // Test Case : CID cannot be field name
        // Change the first textbox to CID
        String oldUserDefinedName = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[2]/input")).getAttribute("value");
        String idUserDefinedName = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[2]/input")).getAttribute("id");
        driver.findElement(By.id(idUserDefinedName)).clear();
        driver.findElement(By.id(idUserDefinedName)).sendKeys("CID");
        driver.findElement(By.id("save")).click();

        String alertText = module.acceptAndGetAlertText();

        Assert.assertTrue(ERRORMSGS.contains(alertText));

        // Set the value of textbox to the old name
        driver.findElement(By.id(idUserDefinedName)).clear();
        driver.findElement(By.id(idUserDefinedName)).sendKeys(oldUserDefinedName);

        // Test Case : Start position should be less than end position
        String oldStartPos = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[3]/input")).getAttribute("value");
        String idStartPos = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[3]/input")).getAttribute("id");

        String oldEndPos = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[4]/input")).getAttribute("value");
        String idEndPos = driver.findElement(By.xpath("//table[@id='fieldTable']/tbody/tr[1]/td[4]/input")).getAttribute("id");

        driver.findElement(By.id(idStartPos)).clear();
        driver.findElement(By.id(idStartPos)).sendKeys("10");// get from csv

        driver.findElement(By.id(idEndPos)).clear();
        driver.findElement(By.id(idEndPos)).sendKeys("1");// get from csv

        driver.findElement(By.id("save")).click();

        alertText = module.acceptAndGetAlertText();

        Assert.assertTrue(alertText.startsWith("Error"));

        // Set the value of textbox to the old names
        driver.findElement(By.id(idStartPos)).clear();
        driver.findElement(By.id(idEndPos)).clear();
        driver.findElement(By.id(idStartPos)).sendKeys(oldStartPos);
        driver.findElement(By.id(idEndPos)).sendKeys(oldEndPos);

        // Test Case : Field names can contain letters, numbers and underscores for constant
        String oldConstantName = driver.findElement(By.xpath("//table[@id='fieldTableForConst']/tbody/tr[1]/td[2]/input")).getAttribute("value");
        String idConstantName = driver.findElement(By.xpath("//table[@id='fieldTableForConst']/tbody/tr[1]/td[2]/input")).getAttribute("id");

        driver.findElement(By.id(idConstantName)).clear();
        driver.findElement(By.id(idConstantName)).sendKeys("constant-1");// get from csv

        driver.findElement(By.id("save")).click();

        alertText = module.acceptAndGetAlertText();

        Assert.assertTrue(alertText.startsWith("Invalid name for a field"));

        // Set the value of textbox to the old names
        driver.findElement(By.id(idConstantName)).clear();
        driver.findElement(By.id(idConstantName)).sendKeys(oldConstantName);

        module.selectSubmit();
        Thread.sleep(90000);

        // Continue to datacheck page

        // Try to continue without selecting any values
        // TestCase - Please select File Identifier
        module.selectSubmit();
        flag = false;
        driver.findElement(By.id("fileIdentifier")).sendKeys("Select");
        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div[1]/label")).getText();
        if (errMsg.contains("Please select File Identifier"))
        {
            flag = true;
        }
        Assert.assertTrue(flag == true);

        driver.findElement(By.id("fileIdentifier")).sendKeys("OMF_LIVE"); // Get from csv

        // TestCase - Please select Runtime B

        module.selectSave();
        flag = false;
        driver.findElement(By.id("runtimeB")).sendKeys("Select");
        errMsg = driver.findElement(By.xpath("//div[@id='contentArea']/div[3]/div[1]/label")).getText();
        if (errMsg.contains("Please select File Identifier"))
        {
            flag = true;
        }
        Assert.assertTrue(flag == true);

    }

    @After
    public void tearDown() throws Exception
    {
        driver.quit();
        String verificationErrorString = verificationErrors.toString();
        if (!"".equals(verificationErrorString))
        {
            fail(verificationErrorString);
        }
    }

    public void testIPSubmitNoDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 2);

        // Verify values from greenplum
    }

    public void testIPSubmitWithDC(String jobVal) throws Exception
    {
        Long jobId = Long.parseLong(jobVal);
        LOGGER.info(">> Job Id [{}]", jobId);

        String status = db.getStatusForJob(jobId);
        LOGGER.info("Status -- [{}] ", status);

        // Wait for a minute
        // check three times if status changes

        int count = 0;
        while (status.equals(StatusEnum.PROCESSING.name()))
        {
            try
            {
                Thread.sleep(30000);
                status = db.getStatusForJob(jobId);
                // try for three times
                if (count > 3)
                {
                    // status = "FAILED";
                    break;
                }
            } catch (InterruptedException e)
            {
                LOGGER.error("Thread wait error {} ", e.getMessage());
            }
        }

        // Check Job status
        Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

        // Verify the content
        List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
        Assert.assertTrue(jobDetails.size() == 4);

        // Verify values from greenplum
    }
}


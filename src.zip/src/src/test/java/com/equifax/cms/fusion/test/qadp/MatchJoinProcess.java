package com.equifax.cms.fusion.test.qadp;

import java.io.IOException;
import java.net.MalformedURLException;
import java.sql.SQLException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.FILPages.FilteringStatsView;
import com.equifax.cms.fusion.test.MJpages.DataProcessingTabMJ;
import com.equifax.cms.fusion.test.MJpages.MatchJoinConfigPage;
import com.equifax.cms.fusion.test.MJpages.MatchJoinProcessSummaryPage;
import com.equifax.cms.fusion.test.MJpages.MatchJoinSetupPage;
import com.equifax.cms.fusion.test.MJpages.MatchJoinStatsView;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class MatchJoinProcess
{
    public static WebDriver driver;
    private DmStatsView dmStatsView;
    private FilteringStatsView filStatsView;
    private DataProcessingTabMJ dpHomePage;
    private Modules module;
    private CommonMethods commMethods;
    private ProjectDashBoardPage projDashBoardPage;
    private MatchJoinStatsView mjStatsView;
    private MatchJoinConfigPage mjConfigPage;
    private MatchJoinProcessSummaryPage mjSummPage;
    private MatchJoinSetupPage mjSetupPage;
    private ShippingPage shPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(FilteringProcess.class);
    // @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws MalformedURLException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabMJ.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        dmStatsView = PageFactory.initElements(driver, DmStatsView.class);
        filStatsView = PageFactory.initElements(driver, FilteringStatsView.class);
        mjStatsView = PageFactory.initElements(driver, MatchJoinStatsView.class);
        mjConfigPage = PageFactory.initElements(driver, MatchJoinConfigPage.class);
        mjSummPage = PageFactory.initElements(driver, MatchJoinProcessSummaryPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        mjSetupPage = PageFactory.initElements(driver, MatchJoinSetupPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

   /* @AfterMethod
    public void tearDown() throws IOException
    {
        driver.quit();
    }*/

    // @Title("Match Join Stats Verification")
    // @Description("Match Join Process")
    @Test(dataProvider = "MJ_QA_Y", description = "Regression QA test cases for execution")
    public void matchJoinStats(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String masProcess, String masData, String masGroups, String masAllRecords, String masAccepts, String masRejects,
            String matchMasOutput, String unMatchMasOutput, String masField1, String masField2, String masField3, String matProjectNo,
            String matProcess, String matData, String matGroups, String matAllRecords, String matAccepts, String matRejects, String matField1,
            String matField2, String matField3, String appFields1, String appFields2, String appFields3, ITestContext testContext)
            throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", MatchJoinProcess.driver);
        if ("MJ_ID_428".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(mjSetupPage.Ele_MasterProcessName.getAttribute("value"), processName);
            commMethods.verifyString(mjSetupPage.Ele_MatchedMasterFile.getAttribute("value"), unMatchMasOutput);
            commMethods.verifyString(mjSetupPage.Ele_UnMatchedMasterFile.getAttribute("value"), matchMasOutput);
            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.selectDuplicateMJ();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
        } else if ("MJ_ID_431".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(mjSetupPage.Ele_MasterProcessName.getAttribute("value"), processName);
            commMethods.verifyString(mjSetupPage.getMasJobId(), "");
            commMethods.verifyString(mjSetupPage.masTableSelected.getAttribute("value"), masData);
            commMethods.verifyboolean(mjSetupPage.masAllRecCB.isSelected(), true);
            commMethods.verifyString(mjSetupPage.getMatJobId(), "");
            commMethods.verifyString(mjSetupPage.matTableSelected.getAttribute("value"), matData);
            commMethods.verifyString(mjSetupPage.Ele_MatchedMasterFile.getAttribute("value"), unMatchMasOutput);
            commMethods.verifyString(mjSetupPage.Ele_UnMatchedMasterFile.getAttribute("value"), matchMasOutput);
            mjSetupPage.clickContinueButton();
            commMethods.verifyboolean(mjConfigPage.isMasterFieldSelected(), true);
            commMethods.verifyboolean(mjConfigPage.isMatchFieldSelected(), true);
            commMethods.verifyboolean(mjConfigPage.isAppendedFieldSelected(), true);
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSummPage.getMasterData(), masData);
            commMethods.verifyString(mjSummPage.getMatchData(), matData);
            commMethods.verifyString(mjSummPage.getMasterJobNo(), "Unavailable");
            commMethods.verifyString(mjSummPage.getMatchJobNo(), "Unavailable");
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match Join Process Summary Review the information below, and then click 'Back' or 'Submit'.");
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
        } else if ("MJ_ID_442".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(mjSetupPage.getMasJobId(), "");
            commMethods.verifyString(mjSetupPage.getMatJobId(), "");
            mjSetupPage.clickContinueButton();
            commMethods.verifyboolean(mjConfigPage.isMasterFieldSelected(), true);
            commMethods.verifyboolean(mjConfigPage.isMatchFieldSelected(), true);
            commMethods.verifyboolean(mjConfigPage.isAppendedFieldSelected(), true);
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSummPage.getMasterJobNo(), "Unavailable");
            commMethods.verifyString(mjSummPage.getMatchJobNo(), "Unavailable");
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match Join Process Summary Review the information below, and then click 'Back' or 'Submit'.");
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
        } else if ("MJ_ID_169".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickMatchJoinButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            commMethods.verifyString(mjSetupPage.Ele_MatchedMasterFile.getAttribute("value"), "MASTER");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please enter the Process Name.");
            mjSetupPage.inputProcessName(processName);
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please select Input data for Master.");
            mjSetupPage.selectMasterProcess(masProcess);
            mjSetupPage.selectMasterData(masData);
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please select Record Types for Master Details.");
            commMethods.selectRecordTypesMaster(masProcess, masAllRecords, masAccepts, masRejects);
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please select Record Types for Match Details.");
            mjSetupPage.selectMatchProcess(matProcess);
            mjSetupPage.selectMatchData(matData);
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please select Record Types for Match Details.");
            mjSetupPage.selectRecordTypesMatch(matProcess, matAllRecords, matAccepts, matRejects);
            mjSetupPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.inputUnMatchedMasterOutputTableName("");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please enter Output Table Name(s).");
            mjSetupPage.inputUnMatchedMasterOutputTableName("UnmatchedMaster");
            mjSetupPage.inputMatchedMasterOutputTableName("");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please enter Output Table Name(s).");
            mjSetupPage.inputMatchedMasterOutputTableName("MatchedMaster");
            mjSetupPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.inputUnMatchedMasterOutputTableName("Test Space Test");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(),
                    "Invalid field name: 'Test Space Test' can contain only character,number or underscore and should not start with a number.");
            mjSetupPage.inputUnMatchedMasterOutputTableName("UnmatchedMaster");
            mjSetupPage.inputMatchedMasterOutputTableName("Test Space Test");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(),
                    "Invalid field name: 'Test Space Test' can contain only character,number or underscore and should not start with a number.");
            mjSetupPage.inputMatchedMasterOutputTableName("MatchedMaster");
            mjSetupPage.inputUnMatchedMasterOutputTableName("!@#$%^&*(");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(),
                    "Invalid field name: '!@#$%^&*(' can contain only character,number or underscore and should not start with a number.");
            mjSetupPage.inputUnMatchedMasterOutputTableName("UnmatchedMaster");
            mjSetupPage.inputMatchedMasterOutputTableName("!@#$%^&*(");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(),
                    "Invalid field name: '!@#$%^&*(' can contain only character,number or underscore and should not start with a number.");
            mjSetupPage.inputMatchedMasterOutputTableName("MatchedMaster");
            mjSetupPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.inputProjectNumber("");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage(), "Please enter the valid Project Number.");
            mjSetupPage.inputProjectNumber("CURRENT");
            mjSetupPage.clickSaveButton();
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
            mjConfigPage.clickSaveButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please select at least one field in Master & Match Field section");
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please select at least one field in Master & Match Field section");
            mjConfigPage.clickBackButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
            mjConfigPage.selectMasterFields(masField1, masField2, masField3);
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please select same number of columns in the Master & Match Fields section");
            mjConfigPage.clickRemove_AllMasterButton();
            mjConfigPage.selectMatchFields(matField1, matField2, matField3);
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please select same number of columns in the Master & Match Fields section");
            mjConfigPage.clickRemove_AllMatchButton();
            mjConfigPage.selectAppendedFields(appFields1, appFields2, appFields3);
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(mjSetupPage.getErrorMessage2(), "Please select at least one field in Master & Match Field section");
            mjConfigPage.selectMasterFields(masField1, masField2, masField3);
            mjConfigPage.selectMatchFields(matField1, matField2, matField3);
            mjConfigPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditMJ();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Setup Complete the required information below, and then click 'Save' or 'Continue'.");
            mjSetupPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
            mjConfigPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Match Join Process Summary Review the information below, and then click 'Back' or 'Submit'.");
            mjSummPage.clickSubmitButton();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            dpHomePage.selectDuplicateMJ();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectSummaryMJ();
            mjSummPage.clickSubmitButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Data Processing Select a task to complete, or click on a dataprocessing job in the grid below.");
        } else
        {
            projDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickMatchJoinButton();
            String fProcessName = commMethods.getFinalProcessName();
            String colonPName_Space = commMethods.getFinalProcessNameColon_Space(processName);
            mjSetupPage.inputProcessName(processName);
            mjSetupPage.selectMasterProcess(masProcess);
            mjSetupPage.selectMasterData(masData);
            commMethods.selectTheGroups(masGroups);
            Thread.sleep(2500);
            commMethods.selectRecordTypesMaster(masProcess, masAllRecords, masAccepts, masRejects);
            mjSetupPage.searchProcessFromAnotherProject(matProjectNo);
            mjSetupPage.selectMatchProcess(matProcess);
            mjSetupPage.selectMatchData(matData);
            commMethods.selectTheGroupsMatch(matGroups);
            Thread.sleep(2500);
            mjSetupPage.selectRecordTypesMatch(matProcess, matAllRecords, matAccepts, matRejects);
            mjSetupPage.inputMatchedMasterOutputTableName(matchMasOutput);
            mjSetupPage.inputUnMatchedMasterOutputTableName(unMatchMasOutput);
            if ("MJ_ID_440".equalsIgnoreCase(tc_ID))
            {
                commMethods.verifyboolean(mjSetupPage.masAllRecCB.isEnabled(), true);
                commMethods.verifyboolean(mjSetupPage.allRegrdlsOfTypeMatch_CB.isEnabled(), false);
                commMethods.verifyboolean(mjSetupPage.allRegrdlsOfTypeMatch_CB.isSelected(), true);
            } else if ("MJ_ID_167".equalsIgnoreCase(tc_ID))
            {
                commMethods.verifyString(mjSetupPage.getMasJobId(), "");
                commMethods.verifyString(mjSetupPage.getMatJobId(), "");
            } else
            {
                mjSetupPage.clickContinueButton();
                mjConfigPage.selectMasterFields(masField1, masField2, masField3);
                mjConfigPage.selectMatchFields(matField1, matField2, matField3);
                if ("MJ_ID_184".equalsIgnoreCase(tc_ID))
                {
                    mjConfigPage.selectAppendedFields(appFields1, appFields2, "NA");
                } else
                {
                    mjConfigPage.selectAppendedFields(appFields1, appFields2, appFields3);
                }

                mjConfigPage.clickContinueButton();

                if ("MJ_ID_436".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    boolean valueflag = false;
                    // driver.switchTo().frame("sb-player");
                    Long masRecMat = mjStatsView.getCountOfMasterRecMatched();
                    if (masRecMat == 0L)
                    {
                        valueflag = true;
                    }
                    commMethods.verifyboolean(valueflag, false);
                } else if ("MJ_ID_434".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    commMethods.verifyLong(mjStatsView.getCountOfMatRecSelecProcessing(), 1000L);
                } else if ("MJ_ID_248".equalsIgnoreCase(tc_ID))
                {
                    projDashBoardPage.clickDataProcessingTab();
                    commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                    dpHomePage.selectDuplicateMJ();
                    commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                    dpHomePage.selectEditMJ();
                    commMethods.verifyboolean(mjSetupPage.isG1Selected(), true);
                    commMethods.verifyboolean(mjSetupPage.isSurplusSelected(), true);
                    commMethods.verifyboolean(mjSetupPage.isOtherSelected(), false);
                } else if ("MJ_ID_187".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    projDashBoardPage.clickStatsView(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.getRecordsFromGP(masProTabName), mjStatsView.getCountOfMasterRecordsInTable());
                } else if ("MJ_ID_184".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickBackButton();
                    mjConfigPage.selectAppendedFields("NA", "NA", appFields3);
                    mjConfigPage.clickContinueButton();
                    commMethods.verifyString(projDashBoardPage.getPageTitle(),
                            "Match Join Process Summary Review the information below, and then click 'Back' or 'Submit'.");
                } else if ("MJ_ID_183".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickBackButton();
                    mjConfigPage.clickBackButton();
                    mjSetupPage.selectMasterProcess(matProcess);
                    mjSetupPage.selectMasterData(matData);
                    mjSetupPage.selectMatchProcess(masProcess);
                    mjSetupPage.selectMatchData(masData);
                    mjSetupPage.clickContinueButton();
                    commMethods.verifyboolean(mjConfigPage.isMasterFieldSelected(), false);
                    commMethods.verifyboolean(mjConfigPage.isMatchFieldSelected(), false);
                    commMethods.verifyboolean(mjConfigPage.isAppendedFieldSelected(), false);
                } else if ("MJ_ID_181".equalsIgnoreCase(tc_ID))
                {
                    commMethods.verifyboolean(mjSummPage.getAppendedField1().contains(appFields1.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getAppendedField2().contains(appFields2.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getAppendedField3().contains(appFields3.replace(",", ".")), true);
                    mjSummPage.clickBackButton();
                    commMethods.verifyString(projDashBoardPage.getPageTitle(),
                            "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
                    mjConfigPage.clickRemove_AllAppendButton();
                    mjConfigPage.clickContinueButton();
                    commMethods.verifyboolean(mjSummPage.isAppendedFieldDisplayed(), false);
                } else if ("MJ_ID_164".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    commMethods.verifyboolean(mjSummPage.getErrorMessage().contains("Input Table"), true);
                } else if ("MJ_ID_162".equalsIgnoreCase(tc_ID))
                {
                    String[] ActMasPro = mjSummPage.getMasterProcessName().split(":");
                    String[] ExpMasPro = masProcess.split(":");
                    commMethods.verifyString(ActMasPro[0].trim(), ExpMasPro[0].trim());
                    commMethods.verifyString(ActMasPro[1].trim(), ExpMasPro[1].trim());
                    commMethods.verifyString(mjSummPage.getMasterData(), masData);
                    String[] ActMatPro = mjSummPage.getMatchProcessName().split(":");
                    String[] ExpMatPro = matProcess.split(":");
                    commMethods.verifyString(ActMatPro[0].trim(), ExpMatPro[0].trim());
                    commMethods.verifyString(ActMatPro[1].trim(), ExpMatPro[1].trim());
                    commMethods.verifyString(mjSummPage.getMatchData(), matData);
                    commMethods.verifyString(mjSummPage.getUnmatchedMasterOutputTableName(), unMatchMasOutput);
                    commMethods.verifyString(mjSummPage.getMatchedMasterOutputTableName(), matchMasOutput);
                    commMethods.verifyboolean(mjSummPage.getMasterFieldKey1().contains(masField1.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getMasterFieldKey2().contains(masField2.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getMasterFieldKey3().contains(masField3.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getMatchFieldKey1().contains(matField1.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getMatchFieldKey2().contains(matField2.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getMatchFieldKey3().contains(matField3.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getAppendedField1().contains(appFields1.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getAppendedField2().contains(appFields2.replace(",", ".")), true);
                    commMethods.verifyboolean(mjSummPage.getAppendedField3().contains(appFields3.replace(",", ".")), true);
                } else if ("MJ_ID_153".equalsIgnoreCase(tc_ID) || "MJ_ID_158".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    String appFieldStats = mjStatsView.getAppendedColumnNames();
                    commMethods.verifyboolean(commMethods.ifAppendedColumnExists(mjTables[0], appFieldStats), true);
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "NULL"), mjStatsView.getCountOfMasterRecordsInTable()
                            - mjStatsView.getCountOfMasRecSelecProcessing());
                } else if ("MJ_ID_150".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String matProColon = matProcess.replace(":", "_");
                    projDashBoardPage.clickStatsView(matProColon);
                    driver.switchTo().frame("sb-player");
                    String matProTabName = filStatsView.getOutputTableName();
                    driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    // commMethods.verifyLong(commMethods.getRecordsFromGP(mjTables[1]),
                    // commMethods.getRecordsFromGP(matProTabName) - commMethods.getRecordsGPMJ(mjTables[0], "R"));
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "NULL"), 0L);
                } else if ("MJ_ID_149".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    String appFieldStats = mjStatsView.getAppendedColumnNames();
                    commMethods.verifyboolean(commMethods.ifAppendedColumnExists(mjTables[0], appFieldStats), true);
                } else if ("MJ_ID_148".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    projDashBoardPage.clickStatsView(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = filStatsView.getOutputTableName();
                    driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.getRecordsFromGP(masProTabName), mjStatsView.getCountOfMasRecSelecProcessing());
                } else if ("MJ_ID_147".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    projDashBoardPage.clickStatsView(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = dmStatsView.getHeaderTableNameDM();
                    driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    String matProColon = matProcess.replace(":", "_");
                    projDashBoardPage.clickStatsView(matProColon);
                    // driver.switchTo().frame("sb-player");
                    String matProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    String matchKey1[] = masField1.split(",");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "A"),
                            commMethods.getRecordsGPMJ_Join_1_Match_Key(masProTabName, matProTabName, matchKey1[1]));
                } else if ("MJ_ID_138".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    projDashBoardPage.searchDashBoard(masProColon);
                    Thread.sleep(5000);
                    projDashBoardPage.clickTreeV2statsViewForChrome(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    String matProColon = matProcess.replace(":", "_");
                    projDashBoardPage.searchDashBoard(matProColon);
                    Thread.sleep(5000);
                    projDashBoardPage.clickTreeV2statsViewForChrome(matProColon);
                    // driver.switchTo().frame("sb-player");
                    String matProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    projDashBoardPage.searchDashBoard(fProcessName);
                    Thread.sleep(5000);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.getRecordsFromGP(masProTabName), mjStatsView.getCountOfMasterRecordsInTable());
                    commMethods.verifyLong(commMethods.getRecordsFromGP(matProTabName), mjStatsView.getCountOfMatchRecordsInTable());
                } else if ("MJ_ID_135".equalsIgnoreCase(tc_ID) || "MJ_ID_133".equalsIgnoreCase(tc_ID) || "MJ_ID_439".equalsIgnoreCase(tc_ID)
                        || "MJ_ID_136".equalsIgnoreCase(tc_ID) || "MJ_ID_345".equalsIgnoreCase(tc_ID) || "MJ_ID_433".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                } else if ("MJ_ID_129".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    /*
                     * commMethods.verifyLong(commMethods.getRecordsGPMJNULL_OR_R(mjTables[0]), commMethods.getRecordsGPMJ_Append_Null(mjTables[0],
                     * matProcess, appFields1));
                     */
                } else if ("MJ_ID_126".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    projDashBoardPage.searchDashBoard(masProColon);
                    Thread.sleep(5000);
                    projDashBoardPage.clickTreeV2statsViewForChrome(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    projDashBoardPage.searchDashBoard(fProcessName);
                    Thread.sleep(5000);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.gRFHDR_RECORD_STATUS_A(masProTabName), mjStatsView.getCountOfMasRecSelecProcessing());
                } else if ("MJ_ID_125".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String masProColon = masProcess.replace(":", "_");
                    driver.findElement(By.xpath(".//*[@id='filterjob-tree']/div[3]/input")).sendKeys(masProColon);
                    driver.findElement(By.xpath(".//*[@id='filterjob-tree']/div[3]/div[1]/div")).click();
                    projDashBoardPage.clickTreeV2statsViewForChrome(masProColon);
                    // driver.switchTo().frame("sb-player");
                    String masProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    driver.findElement(By.xpath(".//*[@id='filterjob-tree']/div[3]/input")).clear();
                    String matProColon = matProcess.replace(":", "_");
                    driver.findElement(By.xpath(".//*[@id='filterjob-tree']/div[3]/input")).sendKeys(matProColon);
                    driver.findElement(By.xpath(".//*[@id='filterjob-tree']/div[3]/div[1]/div")).click();
                    projDashBoardPage.clickTreeV2statsViewForChrome(matProColon);
                    // driver.switchTo().frame("sb-player");
                    String matProTabName = dmStatsView.getHeaderTableNameDM();
                    // driver.switchTo().defaultContent();
                    projDashBoardPage.clickCloseButtonStats();
                    // CH:
                    /*
                     * String matchKey1[] = masField1.split(","); String matchKey2[] = masField2.split(","); String[] mjTables =
                     * projDashBoardPage.getMatchJoinTableName(fProcessName, colonPName_Space);
                     * commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "A"),
                     * commMethods.getRecordsGPMJ_Join_2_Match_Keys(masProTabName, matProTabName, matchKey1[1], matchKey2[1]));
                     */
                } else if ("MJ_ID_124".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    System.out.println(mjStatsView.getAppendedColumnNames());
                    System.out.println(appFields1.replace(",", "_"));
                    commMethods.verifyboolean(mjStatsView.getAppendedColumnNames().contains(appFields1.replace(",", "_")), true);
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "A"),
                            commMethods.getRecordsGPMJ_Append_Null(mjTables[0], matProcess, appFields1));
                } else if ("MJ_ID_121".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    //fetching parent table names from the stats:
                       //For Master Process fetching the table name--
                    String[] masterProcNameForStatsArr=masProcess.split(":");
                    commMethods.searchProcessOnDashboardAndViewStats(masterProcNameForStatsArr[0]+"_"+masterProcNameForStatsArr[1]);
                    String HeaderTableNameDMMaster = dmStatsView.getHeaderTableNameDM();
                    commMethods.clickToCloseStats();
                    commMethods.clearFilter();
                   // For Match Process fetching the table name--
                   String[] matchProcNameForStatsArr=matProcess.split(":");
                    commMethods.searchProcessOnDashboardAndViewStats(matchProcNameForStatsArr[0]+"_"+matchProcNameForStatsArr[1]);
                    String HeaderTableNameDMMatch = dmStatsView.getHeaderTableNameDM();
                    commMethods.clickToCloseStats();
                   commMethods.clearFilter();
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    
                    commMethods.verifyLong(commMethods.getRecordsFromGPFailCodeNull(HeaderTableNameDMMaster),commMethods.getRecordsGPMJNotNULL(mjTables[0]));
                    commMethods.verifyLong(commMethods.getRecordsFromGPFailCodeNull(HeaderTableNameDMMatch),mjStatsView.getCountOfMatRecSelecProcessing());
                   // commMethods.verifyLong(commMethods.getRecordsFromGPFailCodeNull(HeaderTableNameDMMatch),commMethods.getRecordsGPMJNotNULL(mjTables[1]));
                    
                } else if ("MJ_ID_117".equalsIgnoreCase(tc_ID))
                {
                    mjSummPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
                    String[] mjTables = projDashBoardPage.getMatchJoinTableName(fProcessName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProcessName);
                    // driver.switchTo().frame("sb-player");
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "A"), mjStatsView.getCountOfMasterRecMatched());
                    commMethods.verifyLong(commMethods.getRecordsGPMJ(mjTables[0], "R"), mjStatsView.getCountOfMasterRecNotMatched());
                    commMethods.verifyLong(commMethods.getRecordsFromGP(mjTables[1]), mjStatsView.getCountOfMatchRecNotMatched());
                }
                driver.switchTo().defaultContent();
                projDashBoardPage.clickCloseButtonStats();
            }
        }
    }

    @Test(dataProvider = "MJ_Stats_CBA", description = "Regression Dev test cases")
    public void matchJoinVerification(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String masProcess, String masData, String masGroups, String masAllRecords, String masAccepts, String masRejects,
            String matchMasOutput, String unMatchMasOutput, String masField1, String masField2, String masField3, String masField4,
            String matProjectNo, String matProcess, String matData, String matGroups, String matAllRecords, String matAccepts, String matRejects,
            String matField1, String matField2, String matField3, String matField4, String appFields1, String appFields2, String appFields3,
            String newMasterProcess, String newMatchProcess, ITestContext testContext) throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", FilteringProcess.driver);
        String status = null;
        projDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickMatchJoinButton();
        String fProcessName = commMethods.getFinalProcessName();

        String colonPName_Space = commMethods.getFinalProcessNameColon_Space(processName);

        mjSetupPage.inputProcessName(processName);
        mjSetupPage.selectMasterProcess(masProcess);
        mjSetupPage.selectMasterData(masData);

        commMethods.selectTheGroupsForTheProcess(masGroups);

        mjSetupPage.selectRecordTypesForMaster(masProcess, masAllRecords, masAccepts, masRejects);

        mjSetupPage.searchProcessFromAnotherProject(matProjectNo);
        mjSetupPage.selectMatchProcess(matProcess);
        mjSetupPage.selectMatchData(matData);

        commMethods.selectTheGroupsMatch(matGroups);

        mjSetupPage.selectRecordTypesForMatch(matProcess, matAllRecords, matAccepts, matRejects);
        mjSetupPage.inputMatchedMasterOutputTableName(matchMasOutput);
        mjSetupPage.inputUnMatchedMasterOutputTableName(unMatchMasOutput);
        Thread.sleep(2500);
        mjSetupPage.clickContinueButton();
        Thread.sleep(7000);
        /*
         * commMethods.verifyString(mjConfigPage.getPageTitle(),
         * "Match/Join Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
         */
        if ("MJ_ID_438".equalsIgnoreCase(tc_ID))
        {
            mjConfigPage.selectMoreThanThreeMasterFields(masField1, masField2, masField3, masField4);
            mjConfigPage.selectMoreThanThreeMatchFields(matField1, matField1, matField3, matField4);
            mjConfigPage.clickContinueButton();
            Thread.sleep(2000);
            String errMsg = mjConfigPage.getErrorMessage();
            if (errMsg != null)
            {
                commMethods.verifyString(errMsg, "Maximum 3 fields can be selected in Master & Match Fields section");
            }

        } else
        {
            mjConfigPage.selectMasterFields(masField1, masField2, masField3);
            mjConfigPage.selectMatchFields(matField1, matField2, matField3);
            if ("MJ_ID_435".equalsIgnoreCase(tc_ID))
            {
                mjConfigPage.selectAppendedField(appFields1);
                mjConfigPage.clickSaveButton();
                List<String> selectedAppendedFields = mjConfigPage.getSelectedAppendedFields();
                List<String> providedAppendedFields = mjConfigPage.fetchProvidedAppendedField(appFields1);
                for (int i = 0; i < selectedAppendedFields.size() && i < providedAppendedFields.size(); i++)
                {
                    commMethods.verifyString(selectedAppendedFields.get(i).replaceAll("\\s+", ""),
                            providedAppendedFields.get(i).replaceAll("\\s+", ""));

                }

            } else
            {
                mjConfigPage.selectAppendedFields(appFields1, appFields2, appFields3);
                mjConfigPage.clickContinueButton();
            }
        }
        if ("MJ_ID_437".equalsIgnoreCase(tc_ID))
        {
            projDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditMJ();
            mjSetupPage.selectMasterProcess(newMasterProcess);
            mjSetupPage.selectMasterData(masData);
            mjSetupPage.selectMatchProcess(newMatchProcess);
            mjSetupPage.selectMatchData(matData);
            mjSetupPage.clickContinueButton();
            int leftFieldCount = mjConfigPage.getTheCountSelectedLeftFields();
            Assert.assertTrue(leftFieldCount == 0);
            int rightFieldCount = mjConfigPage.getTheCountSelectedRightFields();
            Assert.assertTrue(rightFieldCount == 0);
            int appendedFieldCount = mjConfigPage.getTheCountSelectedAppendedFields();
            Assert.assertTrue(appendedFieldCount == 0);

        }
        if ("MJ_ID_326".equalsIgnoreCase(tc_ID))
        {
            mjSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            Thread.sleep(1000);
            String[] mjTablesOPArr = projDashBoardPage.getMatchJoinTableName(fProcessName);
            String outputMasterTableName = mjTablesOPArr[0];

            Thread.sleep(4000);
            projDashBoardPage.clickHomeTab();
            String[] procesName = masProcess.split(":");

            String[] mjTablesIPArr = projDashBoardPage.getMatchJoinTableNameNew(procesName[0] + "_" + procesName[1], masProcess);
            String inputMasterTableName = mjTablesIPArr[0];

            commMethods.verifyLong(projDashBoardPage.getTheRecordsWithMatchFlagFromGP(inputMasterTableName),projDashBoardPage.getTheRecordsWithMatchFlagAsBlankFromGP(outputMasterTableName));

        }
        if ("MJ_ID_324".equalsIgnoreCase(tc_ID))
        {
            mjSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            Thread.sleep(1000);
            projDashBoardPage.viewStats(fProcessName);
            // driver.switchTo().frame("sb-player");
            long processedRecordsFromStats = mjStatsView.getCountOfMasRecSelecProcessing();
            projDashBoardPage.clickCloseButtonStats1();
            driver.switchTo().defaultContent();
            Thread.sleep(4000);
            projDashBoardPage.clickHomeTab();
            String[] procesName = masProcess.split(":");

            String[] mjTablesIPArr = projDashBoardPage.getMatchJoinTableNameNew(procesName[0] + "_" + procesName[1], masProcess);
            String inputMasterTableName = mjTablesIPArr[0];

            commMethods.verifyLong(processedRecordsFromStats, projDashBoardPage.getTheProcessedRecordCountFromGP(inputMasterTableName));

        }
        if ("MJ_ID_322".equalsIgnoreCase(tc_ID))
        {
            mjSummPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
            Thread.sleep(1000);
            projDashBoardPage.viewStats(fProcessName);
            // driver.switchTo().frame("sb-player");
            long processedRecordsFromStats = mjStatsView.getCountOfMasRecSelecProcessing();
            projDashBoardPage.clickCloseButtonStats1();
            driver.switchTo().defaultContent();
            Thread.sleep(4000);
            projDashBoardPage.clickHomeTab();
            String[] procesName = masProcess.split(":");

            String[] mjTablesIPArr = projDashBoardPage.getMatchJoinTableNameNew(procesName[0] + "_" + procesName[1], masProcess);
            String inputMasterTableName = mjTablesIPArr[0];
            commMethods.verifyLong(projDashBoardPage.getTheRecordsWithMatchFlagAsBlankFromGP(inputMasterTableName),processedRecordsFromStats);
        }

    }

    @Test(dataProvider = "MJ_Reg_Base", description = "Base Process")
    public void createBaseProcess(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String masProcess, String masData, String masGroups, String masAllRecords, String masAccepts, String masRejects,
            String matchMasOutput, String unMatchMasOutput, String masField1, String masField2, String masField3, String masField4,
            String matProjectNo, String matProcess, String matData, String matGroups, String matAllRecords, String matAccepts, String matRejects,
            String matField1, String matField2, String matField3, String matField4, String appFields1, String appFields2, String appFields3,
            String newMasterProcess, String newMatchProcess, ITestContext testContext) throws InterruptedException, SQLException
    {
    	String executionStatusForMasterProcess = commMethods.getTheExecutionStatus(masProcess);
    	String executionStatusForMatchProcess = commMethods.getTheExecutionStatus(matProcess);
    	
        if (executionStatusForMasterProcess.equalsIgnoreCase("COMPLETED") &&executionStatusForMatchProcess.equalsIgnoreCase("COMPLETED") )
        {
       	 LOGGER.info("Dependent Process Is Successfully Completed");
        testContext.setAttribute("WebDriver", FilteringProcess.driver);
        String status = null;
        projDashBoardPage.clickDataProcessingTab();
        driver.switchTo().alert().accept();
        dpHomePage.clickMatchJoinButton();
        String fProcessName = commMethods.getFinalProcessName();
        
        // String colonPName_Space = commMethods.getFinalProcessNameColon_Space(processName);

        mjSetupPage.inputProcessName(processName);
        mjSetupPage.selectMasterProcess(masProcess);
        mjSetupPage.selectMasterData(masData);

        commMethods.selectTheGroupsForTheProcess(masGroups);

        mjSetupPage.selectRecordTypesForMaster(masProcess, masAllRecords, masAccepts, masRejects);

        mjSetupPage.searchProcessFromAnotherProject(matProjectNo);
        mjSetupPage.selectMatchProcess(matProcess);
        mjSetupPage.selectMatchData(matData);

        commMethods.selectTheGroupsMatch(matGroups);

        mjSetupPage.selectRecordTypesForMatch(matProcess, matAllRecords, matAccepts, matRejects);
        mjSetupPage.inputMatchedMasterOutputTableName(matchMasOutput);
        mjSetupPage.inputUnMatchedMasterOutputTableName(unMatchMasOutput);
        Thread.sleep(2500);
        mjSetupPage.clickContinueButton();
        Thread.sleep(7000);
        mjConfigPage.selectMasterFields(masField1, masField2, masField3);
        mjConfigPage.selectMatchFields(matField1, matField2, matField3);

        mjConfigPage.selectAppendedField(appFields1);
        mjConfigPage.clickSaveButton();

        mjConfigPage.selectAppendedFields(appFields1, appFields2, appFields3);
        mjConfigPage.clickContinueButton();
        Thread.sleep(4000);
        mjSummPage.clickSubmitButton();
       // Thread.sleep(4000);
        //projDashBoardPage.clickHomeTab();
        //commMethods.verifyString(projDashBoardPage.verifyProcess(fProcessName), "PASS");
        }
        else
        {
       	 Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
        }
    }
    
    @DataProvider
    public Object[][] MJ_Reg_Base() throws Exception
    {
        Object[][] testObjArray_Base = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "MatchJoin", "BAS");
        return testObjArray_Base;
    }
    @DataProvider
    public Object[][] MJ_QA_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "MatchJoin", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] MJ_Stats_CBA() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "MatchJoin", "CBA");
        return testObjArray_CBA;
    }

}
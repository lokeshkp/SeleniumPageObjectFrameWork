package com.equifax.cms.fusion.test.qadp;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.DMPages.DataMenuHomePage;
import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.DNSPages.DNSStatsView;
import com.equifax.cms.fusion.test.DNSPages.DNSSummaryPage;
import com.equifax.cms.fusion.test.DNSPages.DataProcessingTab;
import com.equifax.cms.fusion.test.DNSPages.NewDNSSetupPage;
import com.equifax.cms.fusion.test.MJpages.MatchJoinProcessSummaryPage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qaop.OutputProcess;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class DNSProcess
{
    public static WebDriver driver = null;
    private DataProcessingTab dpHomePage;
    private DNSStatsView dnsStatsView;
    private NewDNSSetupPage nwDNSSetUpPage;
    private Modules module;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private DNSSummaryPage dnsSummPage;
    private DataMenuHomePage DataMenuHomPag;
    private DMSummaryPage DMSummPag;
    private ShippingPage shPage;
    private MatchJoinProcessSummaryPage mjSummPage;
    private DmStatsView dmStatView;
    private StackingPage stackingPage;
    private JobStackingPage jobStackingPage;
    private static final Logger LOGGER = LoggerFactory.getLogger(DNSProcess.class);
    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        dpHomePage = PageFactory.initElements(driver, DataProcessingTab.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        dnsStatsView = PageFactory.initElements(driver, DNSStatsView.class);
        nwDNSSetUpPage = PageFactory.initElements(driver, NewDNSSetupPage.class);
        dnsSummPage = PageFactory.initElements(driver, DNSSummaryPage.class);
        DataMenuHomPag = PageFactory.initElements(driver, DataMenuHomePage.class);
        DMSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        mjSummPage = PageFactory.initElements(driver, MatchJoinProcessSummaryPage.class);
        dmStatView = PageFactory.initElements(driver, DmStatsView.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    /*@AfterMethod
    public void tearDown() throws InterruptedException
    {
        driver.quit();
    }*/

    // @Description("DNS Stats Verified with GreenPlum Queries")
    @Test(dataProvider = "dnsStats_Y_Reg")
    public void dnsStatsVerification_Reg(String TC_ID, String testRun, String testcase, String description, String copyProject, String copyProcess,
            String processName, String process, String data, String groups, String outputTableName,String stackProcName, ITestContext testContext)
            throws InterruptedException, SQLException, IOException
    {
        ProjDashBoardPage.clickHomeTab();

        testContext.setAttribute("WebDriver", DNSProcess.driver);

        if ("DNS_ID_001".equalsIgnoreCase(TC_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditDNS();
            commMethods.verifyString(nwDNSSetUpPage.DNSProcessName_Field.getAttribute("value"), processName);
            commMethods.verifyString(nwDNSSetUpPage.getDNS_Data_DD_Selected(), data);
            commMethods.verifyString(nwDNSSetUpPage.getDNSOPName(), outputTableName);

        } else if ("DNS_ID_002".equalsIgnoreCase(TC_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditDNS();
            commMethods.verifyString(nwDNSSetUpPage.DNSProcessName_Field.getAttribute("value"), processName);
            commMethods.verifyString(nwDNSSetUpPage.getDNSOPName(), outputTableName);
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.selectDuplicateDNS();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
        } else if ("DNS_ID_081".equalsIgnoreCase(TC_ID))
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickDNSButton();
            commMethods.verifyString(nwDNSSetUpPage.getDefaultOPName(), "DNS");
            commMethods.verifyboolean(nwDNSSetUpPage.isRecordSelectionDispalyed(), false);
        } else if ("DNS_ID_375".equalsIgnoreCase(TC_ID))
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickDNSButton();
            commMethods.verifyString(nwDNSSetUpPage.pageTitle(), "New DNS Setup Complete the Required Information, and click 'Save' or 'Submit'.");
            nwDNSSetUpPage.clickSaveButton();
            commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Please enter the Process Name.");
            nwDNSSetUpPage.clickSubmitButton();
            commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Please enter the Process Name.");
            nwDNSSetUpPage.inputProcessName(processName);
            nwDNSSetUpPage.clickSubmitButton();
           // nwDNSSetUpPage.clickSubmitButton();
            /*
             * Defect Need Changes in the Wording of Error Message
             */
            commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Please select process and data.");
            nwDNSSetUpPage.selectProcess(process);
            nwDNSSetUpPage.clickSubmitButton();
           // nwDNSSetUpPage.clickSubmitButton();
            commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Select input Data");
            nwDNSSetUpPage.selectData(data);
           // nwDNSSetUpPage.inputOutputTableName("Test Space Test");
           // nwDNSSetUpPage.clickSubmitButton();
           // commMethods.verifyString(nwDNSSetUpPage.getErrorMessage(),
                   // "Output Table name: 'Test Space Test' can contain only character,number or underscore and should not start with a number.");
            nwDNSSetUpPage.inputOutputTableName("!@#$%^&*( )");
            nwDNSSetUpPage.clickSubmitButton();
           // nwDNSSetUpPage.clickSubmitButton();
            commMethods.verifyString(nwDNSSetUpPage.getErrorMessage(),
                    "Output Table name: '!@#$%^&*( )' can contain only character,number or underscore and should not start with a number.");
            nwDNSSetUpPage.inputOutputTableName(outputTableName);
            nwDNSSetUpPage.DNSProcessName_Field.clear();
            nwDNSSetUpPage.clickSubmitButton();
           // nwDNSSetUpPage.clickSubmitButton();
            commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Please enter the Process Name.");
            //nwDNSSetUpPage.inputProcessName(processName);
           // nwDNSSetUpPage.clickSubmitButton();
            nwDNSSetUpPage.inputOutputTableName(outputTableName);
            nwDNSSetUpPage.clickSubmitButton();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
        } else
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickDNSButton();
            String fProName = commMethods.getFinalProcessName();
            nwDNSSetUpPage.inputProcessName(processName);
            nwDNSSetUpPage.selectProcess(process);
            nwDNSSetUpPage.selectData(data);
            commMethods.selectTheGroups(groups);
            nwDNSSetUpPage.inputOutputTableName(outputTableName);

            if ("DNS_ID_374".equalsIgnoreCase(TC_ID))
            {
                Thread.sleep(2000);
                // nwDNSSetUpPage.clickSaveButton();
                nwDNSSetUpPage.clickSubmitButton();

                // driver.findElement(By.xpath("//input[@value='Save']")).click();
                Thread.sleep(2000);
                ProjDashBoardPage.clickDataProcessingTab();
                module.initializeDriver(driver);
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectDuplicateDNS();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryDNS();
                dnsSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            }

            else if ("DNS_ID_080".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.inputOutputTableName("");
                nwDNSSetUpPage.clickSubmitButton();
                commMethods.verifyString(nwDNSSetUpPage.gettextMessage(), "Please provide a valid Output Table Name.");

            }

            else if ("DNS_ID_079".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSaveButton();
                dpHomePage.clickDataProcessingTab();
                module.initializeDriver(driver);
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            }

            else if ("DNS_ID_376".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                commMethods.verifyboolean(nwDNSSetUpPage.isAllRecordsSelected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp1Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp2Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp3Selected(), true);
                commMethods.verifyString(nwDNSSetUpPage.getErrorMessage(),
                        "Output Table name: ' DNS' can contain only character,number or underscore and should not start with a number.");
            }

            else if ("DNS_ID_090".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                module.initializeDriver(driver);
                dpHomePage.selectDuplicateDNS();
                dpHomePage.selectEditDNS();
                commMethods.verifyboolean(nwDNSSetUpPage.isAllRecordsSelected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp1Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp2Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp3Selected(), true);
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            }

            else if ("DNS_ID_078".equalsIgnoreCase(TC_ID))
            {
                commMethods.verifyString(nwDNSSetUpPage.getJobNo(), "");
            }

            else if ("DNS_ID_075".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                commMethods
                        .verifyString(nwDNSSetUpPage.pageTitle(), "New DNS Setup Complete the Required Information, and click 'Save' or 'Submit'.");
            }

            else if ("DNS_ID_377".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                commMethods.verifyString(nwDNSSetUpPage.getErrorMessage(),
                        "Output Table name: ' DNS' can contain only character,number or underscore and should not start with a number.");
                nwDNSSetUpPage.inputOutputTableName("TEST");
                nwDNSSetUpPage.clickSaveButton();
                commMethods.verifyString(nwDNSSetUpPage.getDNSOPName(), "TEST");
            }

            else if ("DNS_ID_378".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSaveButton();
                commMethods.verifyString(nwDNSSetUpPage.getErrorMessage(),
                        "Output Table name: ' DNS' can contain only character,number or underscore and should not start with a number.");
                commMethods.verifyboolean(nwDNSSetUpPage.isAllRecordsSelected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp1Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp2Selected(), true);
                commMethods.verifyboolean(nwDNSSetUpPage.isGrp3Selected(), true);
            }

            else if ("DNS_ID_380".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                module.initializeDriver(driver);
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                dpHomePage.selectSummaryDNS();
                commMethods.verifyString(dnsSummPage.getRecordTypeElementText(), "Records Types to include:");
            }

            else if ("DNS_ID_379".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                module.initializeDriver(driver);
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
                dpHomePage.selectSummaryDNS();
                commMethods.verifyboolean(dnsSummPage.isSummFilterGrpVisible(), true);
            }

            else if ("DNS_ID_383".equalsIgnoreCase(TC_ID) || "DNS_ID_071".equalsIgnoreCase(TC_ID) || "DNS_ID_381".equalsIgnoreCase(TC_ID)
                    || "DNS_ID_382".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            }

            else if ("DNS_ID_062".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(dnsStatsView.getDNSOPTableCountUI(), commMethods.getRecordsFromGP(dnsStatsView.getDNSOPTableNameUI()));
                commMethods.verifyLong(dnsStatsView.getDNSTablePopuCountUI(),
                        commMethods.getRecordsFromDNS_Tab_Popu(dnsStatsView.getDNSTablePopulationNameUI()));
                commMethods.verifyLong(dnsStatsView.getInputTableCountUI(), commMethods.getRecordsFromGP(dnsStatsView.getInputTableNameUI()));
                commMethods.verifyLong(commMethods.getRecordsFromGP(dnsStatsView.getInputTableNameUI()),
                        commMethods.getRecordsFromGP(dnsStatsView.getDNSOPTableNameUI()));
                commMethods.verifyLong(commMethods.getRecordsFromGPFailCodeNotNull(dnsStatsView.getInputTableNameUI()),
                        commMethods.getRecordsFromGPWhoseDNSTAGIsNull(dnsStatsView.getDNSOPTableNameUI()));
                commMethods.verifyLong(commMethods.getRecordsFromGPWhoseDNSTAGIsNull(dnsStatsView.getDNSOPTableNameUI()),
                        commMethods.getRecordsFromGPFailCodeNotNull(dnsStatsView.getInputTableNameUI()));
                // Need to Check failing
                // commMethods.verifyLong(commMethods.getRecordsFromGP_DNS_dnstag_D(dnsStatsView.getDNSOPTableNameUI()),commMethods.getRecordsFromGPDNSMatchwithNightly(dnsStatsView.getDNSTablePopulationNameUI(),dnsStatsView.getInputTableNameUI()));
                // commMethods.verifyLong(commMethods.getRecordsFromGP_DNS_CID_Not_Match(dnsStatsView.getInputTableNameUI(),dnsStatsView.getDNSTablePopulationNameUI()),commMethods.getRecordsFromGPDNS_RS_A(dnsStatsView.getDNSOPTableNameUI()));
                driver.switchTo().defaultContent();
                ProjDashBoardPage.clickCloseButtonStats();
                System.out.println(PropertiesUtils.getEnvOnly());
            }

            else if ("DNS_ID_058".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");

                // driver.switchTo().defaultContent();
                ProjDashBoardPage.clickCloseButtonStats();
                System.out.println(PropertiesUtils.getEnvOnly());
            }

            else if ("DNS_ID_062".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");

                driver.switchTo().defaultContent();
                ProjDashBoardPage.clickCloseButtonStats();
                System.out.println(PropertiesUtils.getEnvOnly());
            }

            else if ("DNS_ID_063".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                String input_Table_Name = dnsStatsView.getInputTableNameUI();
                String dns_Output_Table_Name = dnsStatsView.getDNSOPTableNameUI();
                commMethods.verifyLong(commMethods.getRecordsFromGP_DNS_dnstag_A(dns_Output_Table_Name),
                        commMethods.getRecordsFromGP_DNS_CID_Not_Match_CID1(input_Table_Name, dnsStatsView.getDNSTablePopulationNameUI()));
                driver.switchTo().defaultContent();
                ProjDashBoardPage.clickCloseButtonStats();
                System.out.println(PropertiesUtils.getEnvOnly());
            } else if ("DNS_ID_072".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                dpHomePage.selectSummaryDNS();
                commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                        "Summary: DNS\nReview the information below, and then click 'Submit' or 'Back'.");
                commMethods.verifyString(dnsSummPage.getProcessNameDsiplayed(), process);
                commMethods.verifyString(dnsSummPage.getDataDsiplayed(), data);
                commMethods.verifyString(dnsSummPage.getOutputTableNameDisplayed().trim(), outputTableName);
            } else if ("DNS_ID_076".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSaveButton();
                ProjDashBoardPage.clickDataProcessingTab();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            } else if ("DNS_ID_380".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSaveButton();
                ProjDashBoardPage.clickDataProcessingTab();
                dpHomePage.selectSummaryDNS();
                System.out.println(dnsSummPage.getRecTypeToInclude());
                commMethods.verifyString(dnsSummPage.getRecTypeToInclude(), "Accepts : ALL");
            } else if ("DNS_ID_064".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                String input_Table_Name = dnsStatsView.getInputTableNameUI();
                String dns_Output_Table_Name = dnsStatsView.getDNSOPTableNameUI();
                commMethods.verifyLong(
                        commMethods.getRecordsFromGP_with_Grp_Name(input_Table_Name, groups)
                                - commMethods.getRecordsFromGP_DNS_dnstag_A(dns_Output_Table_Name),
                        commMethods.getRecordsFromGP_DNS_dnstag_D(dns_Output_Table_Name));
                ProjDashBoardPage.clickCloseButtonStats();

            } else if ("DNS_ID_065".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                String input_Table_Name = dnsStatsView.getInputTableNameUI();
                String dns_Output_Table_Name = dnsStatsView.getDNSOPTableNameUI();
                commMethods.verifyLong(
                        commMethods.gRFGP_COLUMN_IS_NOT_NULL(input_Table_Name, "FAIL_CODE"),
                        commMethods.gRFGP_COLUMN_IS_NOT_NULL(dns_Output_Table_Name, "FAIL_CODE")
                                - commMethods.getRecordsFromGP_DNS_dnstag_D(dns_Output_Table_Name));
                ProjDashBoardPage.clickCloseButtonStats();
            } else if ("DNS_ID_066".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                String input_Table_Name = dnsStatsView.getInputTableNameUI();
                String dns_Output_Table_Name = dnsStatsView.getDNSOPTableNameUI();
                commMethods.verifyLong(commMethods.gRFGP_TABLE_COLUMN_VALUE(input_Table_Name, "RECORD_STATUS", "A"),
                        commMethods.gRFGP_COLUMN_IS_NOT_NULL(dns_Output_Table_Name, "DNS_TAG"));
                ProjDashBoardPage.clickCloseButtonStats();

            } else if ("DNS_ID_067".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
                // driver.switchTo().frame("sb-player");
                String dns_Output_Table_Name = dnsStatsView.getDNSOPTableNameUI();
                commMethods.verifyLong(dnsStatsView.getRefreshedDNSCountUI(), commMethods.getRecordsFromGP_DNS_dnstag_D(dns_Output_Table_Name));
                commMethods.verifyLong(dnsStatsView.getRefreshedDNSCountUI(),
                        commMethods.gRFGP_TABLE_COLUMN_VALUE(dns_Output_Table_Name, "FAIL_CODE", "DN"));
                commMethods.verifyLong(dnsStatsView.getRefreshedDNSCountUI(), commMethods.gRFGP_RS_R_DNSTAG_DN(dns_Output_Table_Name));
                ProjDashBoardPage.clickCloseButtonStats();
            }

        }
    }

    @Description("DNS Stats Verified with GreenPlum Queries")
    @Test(dataProvider = "dnsStats_CBA_Reg")
    public void dnsStatsVerification_RegCBA(String TC_ID, String testRun, String testcase, String description, String copyProject,
            String copyProcess, String processName, String process, String data, String groups, String outputTableName,String stackProcName, ITestContext testContext)
            throws InterruptedException, SQLException, IOException
    {
        testContext.setAttribute("WebDriver", DNSProcess.driver);
        String status = null;
        if ("DNS_ID_003".equalsIgnoreCase(TC_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcessName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            module.initializeDriver(driver);
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
            module.selectSummary();
            String processNameIP = commMethods.getAssignedIdForTheProcessFromTheSummary();
            DMSummPag.clickSubmitButton();
            Thread.sleep(1000);
            ProjDashBoardPage.clickDataMenuTab();
            status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(1000);
            String Status = ProjDashBoardPage.verifyProcess(processNameIP);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.clickDataProcessingTab();
            Thread.sleep(1000);
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectSummaryDNS();
            Thread.sleep(1000);
            String processNameOP = commMethods.getAssignedIdForTheProcessFromTheSummary();
            dnsSummPage.clickSubmitButton();
            Thread.sleep(1000);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(1000);
            Status = ProjDashBoardPage.verifyProcess(processNameOP);
            commMethods.verifyString(Status, "PASS");
        } else
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickDNSButton();
            String fProName = commMethods.getFinalProcessName();
            nwDNSSetUpPage.inputProcessName(processName);
            nwDNSSetUpPage.selectProcess(process);
            nwDNSSetUpPage.selectData(data);
            commMethods.selectTheGroups(groups);
            nwDNSSetUpPage.inputOutputTableName(outputTableName);
            nwDNSSetUpPage.clickSaveButton();
            if ("DNS_ID_084".equalsIgnoreCase(TC_ID))
            {
            	
            	ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                String stackAssignedId = commMethods.getFinalProcessName();
                
                jobStackingPage.inputStackName(stackProcName);

                String process_Name = fProName + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(process_Name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(process_Name);
                processList.add(process);
                
               
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);

                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(1000);
                ProjDashBoardPage.clickHomeTab();
                String Status = ProjDashBoardPage.verifyProcess(stackAssignedId);
                commMethods.verifyString(Status, "PASS");
            }
            /*
             * if("DNS_ID_058".equalsIgnoreCase(TC_ID)) { nwDNSSetUpPage.clickSubmitButton(); ProjDashBoardPage.clickHomeTab();
             * commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName),"PASS"); ProjDashBoardPage.clickStatsView(fProName);
             * driver.switchTo().frame("sb-player");
             * commMethods.verifyLong(commMethods.getRecordsFromGP_DNS_dnstag_Null(dnsStatsView.getDNSOPTableNameUI()),commMethods.
             * getRecordsFromGPFailCodeNotNull(dnsStatsView.getInputTableNameUI())); driver.switchTo().defaultContent();
             * ProjDashBoardPage.clickCloseButtonStats(); } else
             */if ("DNS_ID_056".equalsIgnoreCase(TC_ID) || "DNS_ID_058".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");

                ProjDashBoardPage.viewStats(fProName);

                String inputTableName = dnsStatsView.getInputTableNameUI();
                String outptTableName = dnsStatsView.getDNSOPTableNameUI();
                long inputRecordCount = commMethods.getRecordsFromGPFailCodeNotNull(inputTableName);
                long outputRecordCount = commMethods.getRecordsFromGPWhoseDNSTAGIsNull(outptTableName);
                commMethods.verifyLong(inputRecordCount, outputRecordCount);

            } else if ("DNS_ID_057".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.viewStats(fProName);
                commMethods.verifyLong(commMethods.getRecordsFromGPWhoseDNSTAGIsNull(dnsStatsView.getDNSOPTableNameUI()),
                        commMethods.getRecordsFromGPFailCodeNotNull(dnsStatsView.getInputTableNameUI()));
                commMethods.verifyLong(commMethods.getRecordCountFromDNSfailcode_RJ(dnsStatsView.getDNSOPTableNameUI()),
                        commMethods.getRecordCountFromHDRfailcode_RJ(dnsStatsView.getInputTableNameUI()));

                ProjDashBoardPage.clickCloseStats();

            } else if ("DNS_ID_073".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            }

            else if ("MJ_ID_310".equalsIgnoreCase(TC_ID))
            {
                nwDNSSetUpPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
                ProjDashBoardPage.viewStats(fProName);

                String dnsTableName = dnsStatsView.getDNSOPTableNameUI();
                String inputTableName = dnsStatsView.getInputTableNameUI();
                ProjDashBoardPage.clickCloseStats();
                Thread.sleep(2500);
                ProjDashBoardPage.clickDataProcessingTab();
                Thread.sleep(2500);
                String[] procArr = process.split(":");
                commMethods.selectViewSummaryFromAssignedId(procArr[0]);
                Thread.sleep(2500);
                String parentProcName = mjSummPage.getTheMasterProcessNameFromTheSummary();
                ProjDashBoardPage.clickHomeTab();
                String[] parentProcArr = parentProcName.split(":");
                String processNameForStats = parentProcArr[0] + "_" + parentProcArr[1];
                commMethods.searchProcessOnDashboardAndViewStats(processNameForStats.replaceAll("\\s+", ""));
                String HeaderTableNameDM = dmStatView.getHeaderTableNameDM();
                driver.switchTo().defaultContent();
                // ProjDashBoardPage.clickCloseStats();
                commMethods.verifyLong(commMethods.getRecordsFromGP_DNS_dnstag_NotNull(dnsTableName),
                        commMethods.getRecordsToBeProcessedForDNS(inputTableName, HeaderTableNameDM));

            }
        }
    }

    @Test(dataProvider = "dns_Reg_Base")
    public void createDNSBaseProcess(String TC_ID, String testRun, String testcase, String description, String copyProject, String copyProcess,
            String processName, String process, String data, String groups, String outputTableName,String stackProcName, ITestContext testContext)
            throws InterruptedException, SQLException, IOException
    {
    	 String executionStatus = commMethods.getTheExecutionStatus(process);
         if (executionStatus.equalsIgnoreCase("COMPLETED"))
         {
        	 LOGGER.info("Dependent Process Is Successfully Completed");
        
        ProjDashBoardPage.clickDataProcessingTab();
        driver.switchTo().alert().accept();
        Thread.sleep(2500);
        dpHomePage.clickDNSButton();
        Thread.sleep(2500);
        String fProName = commMethods.getFinalProcessName();
        nwDNSSetUpPage.inputProcessName(processName);
        nwDNSSetUpPage.selectProcess(process);
        nwDNSSetUpPage.selectData(data);
        commMethods.selectTheGroups(groups);
        nwDNSSetUpPage.inputOutputTableName(outputTableName);
        nwDNSSetUpPage.clickSaveButton();
        Thread.sleep(2500);
        nwDNSSetUpPage.clickSubmitButton();
       // Thread.sleep(2500);
     //   ProjDashBoardPage.clickHomeTab();
     //   commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
         }else
         {
        	 Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
         }

    }
    
    
    @DataProvider
    public Object[][] dns_Reg_Base() throws Exception
    {
        Object[][] testObjArray_Base = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DNS", "BAS");
        return testObjArray_Base;
    }

    @DataProvider
    public Object[][] dnsStats_Y_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DNS", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] dnsStats_CBA_Reg() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DNS", "CBA");
        return testObjArray;
    }

}

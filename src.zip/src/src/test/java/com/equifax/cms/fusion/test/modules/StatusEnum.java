package com.equifax.cms.fusion.test.modules;

public enum StatusEnum
{
    ERROR, WARNING, READY, SUBMITTED, QUEUED, COMPLETED, INVALID, PROCESSING;
}


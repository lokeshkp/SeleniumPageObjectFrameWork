package com.equifax.cms.fusion.test.searchproj;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Search Project Process")
public class SearchProject
{

    boolean flag = false;

    public WebDriver driver;
    private ProjectDashBoardPage ProjDashBoardPage;
    private CommonMethods commMethods;
    public OracleDBHelper db;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    public static int i = 0;
    private static final Logger LOGGER = LoggerFactory.getLogger(SearchProject.class);

    @Title("User Login with rxs331")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        db = PageFactory.initElements(driver, OracleDBHelper.class);
        commMethods.userLogin();

    }

    @Test(dataProvider = "reg_SearchPage", priority = 1, description = "Search Project Test")
    public void searchProject(String tc, String testRun, String tc_Id, String Desc, String completeProjNum, String partialProjectVal,
            String customerName, String partialCustomerName, String analyst, String qcAnalyst, String partialQcAnalyst) throws InterruptedException
    {
        commMethods.clickSearchTab();
        Thread.sleep(2000);

        Thread.sleep(2000);
        String displayText = "";
        List<String> custList = new ArrayList<>();
        List<String> analystList = new ArrayList<>();

        List<String> listFetched = new ArrayList<>();
        // validate : Searched Project Available
        if ("PJ_ID_001".equalsIgnoreCase(tc_Id) && "PJ_ID_002".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.clickProjectSearchButton();
            }
            listFetched = db.getSearchProjListBySingleParameter("project_number", partialProjectVal);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        // validate : space value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_003".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal))
            {
                listFetched = db.getSearchProjListBySingleParameter("project_number", partialProjectVal);
            }
            /*
             * commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true); driver.switchTo().alert().accept();
             */
            commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true);
            displayText = commMethods.getSearchResultsText();
            commMethods.verifyString(displayText, "No data available in table");
        }

        // validate : special character value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_004".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal))
            {
                listFetched = db.getSearchProjListBySingleParameter("project_number", partialProjectVal);
            }
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        if ("PJ_ID_005".equalsIgnoreCase(tc_Id))
        {
            // validate : search letter with no project number corresponding to it
            if (!"NA".equalsIgnoreCase(partialProjectVal))
            {
                listFetched = db.getSearchProjListBySingleParameter("project_number", partialProjectVal);
            }
            commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true);
            displayText = commMethods.getSearchResultsText();
            commMethods.verifyString(displayText, "No data available in table");
        }
        if ("PJ_ID_006".equalsIgnoreCase(tc_Id) && "PJ_ID_007".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialCustomerName))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
            }
            // validate : Searched Project Available
            // List<String> custList = new ArrayList<>();
            if (!"NA".equalsIgnoreCase(partialCustomerName))
            {
                custList = db.getSearchProjListBySingleParameter("customer_name", partialCustomerName);
            }
            commMethods.verifyboolean(custList.contains(customerName), true);
        }

        // validate : space value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_008".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialCustomerName))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
            }
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
            // alert.accept();
        }

        // validate : special character value in search
        if ("PJ_ID_009".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialCustomerName))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
            }
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
            // alert.accept();
        }
        if ("PJ_ID_010".equalsIgnoreCase(tc_Id))
        {
            // validate : search letter with no project number corresponding to it
            if (!"NA".equalsIgnoreCase(partialCustomerName))
            {
                custList = db.getSearchProjListBySingleParameter("customer_name", partialCustomerName);
            }
            // commMethods.verifyboolean(CollectionUtils.isEmpty(custList), true);
            // displayText = commMethods.getSearchResultsText();
            // commMethods.verifyString(displayText, "No data available in table");
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();

        }
        if ("PJ_ID_011".equalsIgnoreCase(tc_Id) && "PJ_ID_012".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(analyst))
            {
                analystList = db.getSearchProjListBySingleParameter("fulfillment_analyst", analyst);
            }
            commMethods.verifyboolean(analystList.contains(analyst), true);
        }
        // validate : space value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_013".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst))
            {
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        // validate : special character value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_014".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst))
            {
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        if ("PJ_ID_015".equalsIgnoreCase(tc_Id))
        {
            // validate : search letter with no project number corresponding to it
            if (!"NA".equalsIgnoreCase(analyst))
            {
                analystList = db.getSearchProjListBySingleParameter("fulfillment_analyst", analyst);
            }
            commMethods.verifyboolean(CollectionUtils.isEmpty(analystList), true);
            displayText = commMethods.getSearchResultsText();
            commMethods.verifyString(displayText, "No data available in table");
        }

        // qc analyst
        if ("PJ_ID_016".equalsIgnoreCase(tc_Id) && "PJ_ID_017".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(qcAnalyst))
            {
                analystList = db.getSearchProjListBySingleParameter("qc_analyst", qcAnalyst);
            }
            commMethods.verifyboolean(analystList.contains(completeProjNum), true);
        }
        // validate : space value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_018".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(qcAnalyst))
            {
                commMethods.searchProjWithAnalystName(qcAnalyst);
            }
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        // validate : special character value in search
        // test alert box present
        // validate alert message
        if ("PJ_ID_019".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst))
            {
                commMethods.searchProjWithAnalystName(qcAnalyst);
            }
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        if ("PJ_ID_020".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst))
            {
                commMethods.searchProjWithAnalystName(qcAnalyst);
            }
            // validate : search letter with no project number corresponding to it
            if (!"NA".equalsIgnoreCase(analyst))
            {
                analystList = db.getSearchProjListBySingleParameter("qc_analyst", qcAnalyst);
            }
            commMethods.verifyboolean(CollectionUtils.isEmpty(analystList), true);
            displayText = commMethods.getSearchResultsText();
            commMethods.verifyString(displayText, "No data available in table");
        }

        // search with both project and Customer name
        if ("PJ_ID_021".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(completeProjNum) && !"NA".equalsIgnoreCase(customerName))
            {
                commMethods.setprojectNumber(completeProjNum);
                commMethods.searchProjWithCustomerName(customerName);
            }
            commMethods.clickProjectSearchButton();

            listFetched = db.getProjectListOnTwoFieldSelections("project_number", "customer_name", partialProjectVal, partialCustomerName);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }
        if ("PJ_ID_022".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName))
            {
                // search with both project and Customer name
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.clickProjectSearchButton();
            }

            listFetched = db.getProjectListOnTwoFieldSelections("project_number", "customer_name", partialProjectVal, partialCustomerName);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }
        if ("PJ_ID_023".equalsIgnoreCase(tc_Id) && "PJ_ID_024".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName))
            {
                // with special symbols
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.clickProjectSearchButton();
            }

            /*
             * listFetched = db.getProjectListOnTwoFieldSelections("project_number", "customer_name", partialProjectVal, partialCustomerName);
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */

            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        if ("PJ_ID_025".equalsIgnoreCase(tc_Id) && "PJ_ID_026".equalsIgnoreCase(tc_Id))
        {
            // search with both project and analyst name
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.clickProjectSearchButton();

            listFetched = db.getProjectListOnProjectNumAndAnalystName(partialProjectVal, analyst, "fulfillment_analyst");
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        if ("PJ_ID_027".equalsIgnoreCase(tc_Id) && "PJ_ID_028".equalsIgnoreCase(tc_Id))
        {
            // with special symbols
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.clickProjectSearchButton();

            /*
             * listFetched = db.getProjectListOnProjectNumAndAnalystName(partialProjectVal, analyst, "fulfillment_analyst");
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        // search with both project and QC analyst name
        if ("PJ_ID_029".equalsIgnoreCase(tc_Id) && "PJ_ID_030".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            commMethods.clickProjectSearchButton();

            listFetched = db.getProjectListOnProjectNumAndAnalystName(partialProjectVal, partialQcAnalyst, "qc_analyst");
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        // with special symbols
        if ("PJ_ID_031".equalsIgnoreCase(tc_Id) && "PJ_ID_032".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            commMethods.clickProjectSearchButton();

            /*
             * listFetched = db.getProjectListOnProjectNumAndAnalystName(partialProjectVal, partialQcAnalyst, "qc_analyst");
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        // Search with custmer name and analyst
        if ("PJ_ID_033".equalsIgnoreCase(tc_Id) && "PJ_ID_034".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.clickProjectSearchButton();

            listFetched = db.getProjectListOnTwoFieldSelections("customer_name", "fulfillment_analyst", partialCustomerName, analyst);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        // with special symbols
        if ("PJ_ID_035".equalsIgnoreCase(tc_Id) && "PJ_ID_036".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
            }
            commMethods.clickProjectSearchButton();

            /*
             * listFetched = db.getProjectListOnTwoFieldSelections("customer_name", "fulfillment_analyst", partialCustomerName, analyst);
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        // Search with custmer name and QC analyst
        if ("PJ_ID_037".equalsIgnoreCase(tc_Id) && "PJ_ID_038".equalsIgnoreCase(tc_Id))
        {

            if (!"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(qcAnalyst))
            {

                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
                commMethods.clickProjectSearchButton();
            }

            listFetched = db.getProjectListOnTwoFieldSelections("customer_name", "qc_analyst", partialCustomerName, qcAnalyst);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        // with special symbols

        if ("PJ_ID_039".equalsIgnoreCase(tc_Id) && "PJ_ID_040".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialProjectVal))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
            }
            commMethods.clickProjectSearchButton();

            /*
             * listFetched = db.getProjectListOnTwoFieldSelections("customer_name", "qc_analyst", partialCustomerName, qcAnalyst);
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        // Search with analyst and QC analyst

        if ("PJ_ID_041".equalsIgnoreCase(tc_Id) && "PJ_ID_042".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            commMethods.clickProjectSearchButton();

            listFetched = db.getProjectListOnTwoFieldSelections("fulfillment_analyst", "qc_analyst", analyst, qcAnalyst);
            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }
        // with special symbols

        if ("PJ_ID_043".equalsIgnoreCase(tc_Id) && "PJ_ID_044".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            commMethods.clickProjectSearchButton();

            /*
             * listFetched = db.getProjectListOnTwoFieldSelections("fulfillment_analyst", "qc_analyst", analyst, qcAnalyst);
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        // Search only with Project Number, Customer Name and Analyst as follows

        if ("PJ_ID_045".equalsIgnoreCase(tc_Id) && "PJ_ID_046".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
            }
            listFetched = db.getProjectListwithThreeParameterSelections("project_number", "customer_name", "fulfillment_analyst", partialProjectVal,
                    partialCustomerName, analyst);

            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }

        if ("PJ_ID_047".equalsIgnoreCase(tc_Id) && "PJ_ID_048".equalsIgnoreCase(tc_Id))
        {
            // negative case
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
            }
            /*
             * listFetched = db.getProjectListwithThreeParameterSelections("project_number", "customer_name", "fulfillment_analyst",
             * partialProjectVal, partialCustomerName, analyst); commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText =
             * commMethods.getSearchResultsText(); commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        // Search only with Project Number, Customer Name and QC Analyst as follows
        if ("PJ_ID_049".equalsIgnoreCase(tc_Id) && "PJ_ID_050".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            listFetched = db.getProjectListwithThreeParameterSelections("project_number", "customer_name", "qc_analyst", partialProjectVal,
                    partialCustomerName, partialQcAnalyst);

            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }
        if ("PJ_ID_051".equalsIgnoreCase(tc_Id) && "PJ_ID_052".equalsIgnoreCase(tc_Id))
        {
            // negative case
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            /*
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

        // Search only with Customer Name, Analyst and QC Analyst as follows
        if ("PJ_ID_053".equalsIgnoreCase(tc_Id) && "PJ_ID_054".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(analyst) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            listFetched = db.getProjectListwithThreeParameterSelections("customer_name", "fulfillment_analyst", "qc_analyst", partialCustomerName,
                    analyst, partialQcAnalyst);

            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
        }
        if ("PJ_ID_055".equalsIgnoreCase(tc_Id) && "PJ_ID_056".equalsIgnoreCase(tc_Id))
        {
            // negative case
            if (!"NA".equalsIgnoreCase(analyst) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst))
            {
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            /*
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }
        // Search only with Project Number, Customer Name, Analyst and QC Analyst as follows
        if ("PJ_ID_057".equalsIgnoreCase(tc_Id) && "PJ_ID_058".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst)
                    && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            listFetched = db.getProjectListWithAllParameterSelections("project_number", "customer_name", "fulfillment_analyst", "qc_analyst",
                    partialProjectVal, partialCustomerName, analyst, partialQcAnalyst);

            commMethods.verifyboolean(listFetched.contains(completeProjNum), true);
            // negative case
        }
        if ("PJ_ID_057".equalsIgnoreCase(tc_Id) && "PJ_ID_058".equalsIgnoreCase(tc_Id))
        {
            if (!"NA".equalsIgnoreCase(partialProjectVal) && !"NA".equalsIgnoreCase(partialCustomerName) && !"NA".equalsIgnoreCase(partialQcAnalyst)
                    && !"NA".equalsIgnoreCase(analyst))
            {
                commMethods.setprojectNumber(partialProjectVal);
                commMethods.searchProjWithCustomerName(partialCustomerName);
                commMethods.searchProjWithAnalystName(analyst);
                commMethods.searchProjWithQCAnalystName(partialQcAnalyst);
            }
            /*
             * commMethods.verifyboolean(CollectionUtils.isEmpty(listFetched), true); displayText = commMethods.getSearchResultsText();
             * commMethods.verifyString(displayText, "No data available in table");
             */
            commMethods.clickProjectSearchButton();
            commMethods.verifyboolean(ProjDashBoardPage.isAlertPresent(), true);
            driver.switchTo().alert().accept();
        }

    }

    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] reg_SearchPage() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SearchPage", "Y");
        return testObjArray_Y;
    }
}
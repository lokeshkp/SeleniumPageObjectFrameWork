package com.equifax.cms.fusion.test.qadp;

import static org.junit.Assert.assertTrue;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.FFFPages.DataProcessingTab;
import com.equifax.cms.fusion.test.FFFPages.FFFStatsView;
import com.equifax.cms.fusion.test.FFFPages.FFFSummaryPage;
import com.equifax.cms.fusion.test.FFFPages.FullFileFixedPage;
import com.equifax.cms.fusion.test.RNPages.DataProcessingHomePage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;
import com.google.common.collect.Ordering;

public class FullFileFixedProcess
{
    public WebDriver driver;

    private Modules module;
    private FullFileFixedPage fffPage;
    private FFFSummaryPage fffSummPage;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private DataProcessingTab dpHomePage;
    private DataProcessingHomePage dataProcessingHomePage;
    private FFFStatsView fffStatsView;
    private ShippingPage shPage;
    private JobStackingPage jobStackingPage;
    private StackingPage stackingPage;
    String fProName;
    private static final Logger LOGGER = LoggerFactory.getLogger(FullFileFixedProcess.class);
    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        fffPage = PageFactory.initElements(driver, FullFileFixedPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTab.class);
        fffSummPage = PageFactory.initElements(driver, FFFSummaryPage.class);
        fffStatsView = PageFactory.initElements(driver, FFFStatsView.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    // @Title("FFF Stats Verification")
    // @Description("FFF with Standard Inputs")
    @Test(dataProvider = "fffStats_Y")
    public void fffStatsVerification(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess, String processName, String creditInput, String process,
            String data, String groups, String configFileLocation, String allRecords, String accepts, String rejects,
          String procNameForStack,ITestContext testContext) throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", driver);
        if ("FFF_ID_396".equalsIgnoreCase(tc_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditFFF();
            commMethods.verifyString(fffPage.fffProcessName_Field.getAttribute("value"), processName);
            commMethods.verifyString(fffPage.creditInputSelected.getText(), creditInput);
            commMethods.verifyString(fffPage.configFileLocatn_Field.getAttribute("value"), configFileLocation);
            commMethods.verifyboolean(fffPage.AllRecRegardlessOfType_CB.isSelected(), true);
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.selectDuplicateFFF();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
        } else if ("FFF_ID_397".equalsIgnoreCase(tc_ID))
        {
            ProjDashBoardPage.inputProjNum(copyProject);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataProcessingTab();
            module.initializeDriver(driver);
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            dpHomePage.selectEditFFF();
            commMethods.verifyString(fffPage.getJobId(), "");
            commMethods.verifyString(fffPage.fffProcessName_Field.getAttribute("value"), processName);
            commMethods.verifyString(fffPage.creditInputSelected.getText(), creditInput);
            commMethods.verifyString(fffPage.configFileLocatn_Field.getAttribute("value"), configFileLocation);
            commMethods.verifyboolean(fffPage.AllRecRegardlessOfType_CB.isSelected(), true);
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.selectDuplicateFFF();
            commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
        } else
        {
            ProjDashBoardPage.clickDataProcessingTab();
            dpHomePage.clickFFFButton();
            if ("FFF_ID_392".equalsIgnoreCase(tc_ID))
            {
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Please enter the Process Name.");
                fffPage.inputProcessName(processName);
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Select credit input");
                fffPage.selectCreditInput(creditInput);
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Select Process");
                fffPage.selectProcess(process);
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Select input table");
                fffPage.selectData(data);
                fffPage.clearConfigLoctn();
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Enter a valid file path");
                fffPage.inputConfigLoctn(configFileLocation);
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Please select Record Types");
                commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
                Thread.sleep(10000);
                fffPage.clickSaveButton();
                commMethods.verifyString(fffPage.getFFFPageHeader(), "Full File Fixed");
                Thread.sleep(10000);
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getFFFPageHeader(),
                        "Data Processing Select a task to complete, or click on a dataprocessing job in the grid below.");
            } else
            {
                commMethods.verifyString(fffPage.isConfigFileLocPresent(), "text");
                fProName = commMethods.getFinalProcessName();
                fffPage.inputProcessName(processName);
                fffPage.selectCreditInput(creditInput);
                fffPage.selectProcess(process);
                Thread.sleep(5000);
                fffPage.selectData(data);
                fffPage.inputConfigLoctn(configFileLocation);
                commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
            }
            if ("FFF_ID_388".equalsIgnoreCase(tc_ID))
            {
                fffPage.clickSubmitButton();
                commMethods.verifyString(fffPage.getErrorMessage(), "Please enter the valid Process Name.");
            } else if ("FFF_ID_132".equalsIgnoreCase(tc_ID))
            {
                fffPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            } else if ("FFF_ID_094".equalsIgnoreCase(tc_ID))
            {
                fffPage.clickSubmitButton();
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(ProjDashBoardPage.jobName()), "PASS");
                ProjDashBoardPage.clickJobUpperLevel(fProName);
                ProjDashBoardPage.clickJobLowerLevel(fProName);
                commMethods.verifyString(ProjDashBoardPage.getFFF_GP_EXPORT_Status(), "COMPLETED");
                commMethods.verifyString(ProjDashBoardPage.getFFF_JET_Status(), "COMPLETED");
                commMethods.verifyString(ProjDashBoardPage.getFFF_GP_CONVERTAVRO_Status(), "COMPLETED");
                ProjDashBoardPage.clickJobUpperLevel(fProName);
                ProjDashBoardPage.clickTreeV2statsView(fProName);
                // driver.switchTo().frame("sb-player");
                fffStatsView.clickCounters();
                String Counters = fffStatsView.getCountersContent();
                commMethods.verifyboolean(Counters.contains("AVROCREDITRECORDS"), true);
                commMethods.verifyboolean(Counters.contains("RECORDS"), true);
            } else if ("FFF_ID_483".equalsIgnoreCase(tc_ID))
            {
                fffPage.clickSaveButton();
                ProjDashBoardPage.clickDataProcessingTab();
                module.initializeDriver(driver);
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectDuplicateFFF();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                dpHomePage.selectSummaryFFF();
                fffSummPage.clickSubmitButton();
                commMethods.verifyString(dpHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            } else if ("FFF_ID_486".equalsIgnoreCase(tc_ID))
            {
                ProjDashBoardPage.clickStatsView(fProName);
                driver.switchTo().frame("sb-player");
                commMethods.verifyLong(fffStatsView.getHeaderTableCount(), commMethods.getRecordsFromGP(fffStatsView.getHeaderTableName()));
                commMethods.verifyLong(fffStatsView.getInputTableCount(), commMethods.getRecordsFromGP(fffStatsView.getInputTableName()));
                commMethods.verifyLong(fffStatsView.getCountOfFFFRecordsUI(), fffStatsView.getSumofCountofAVROCreditFiles());
                driver.switchTo().defaultContent();
                ProjDashBoardPage.clickCloseButtonStats();
            }
        }
    }

    // @Title("FFF Verification")
    // @Description("FFF with Standard Inputs")
    @Test(dataProvider = "fff_CBA_Reg")
    public void fffVerification(String tc_Id, String testRun, String tc, String description, String copyProject, String copyProcess, String processName, String creditInput, String process,
            String data, String groups, String configFileLocation, String allRecords, String accepts, String rejects,
          String procNameForStack, ITestContext testContext) throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", driver);
        System.out.println("Navigated to Data Processing Home screen");
        ProjDashBoardPage.clickDataProcessingTab();
        dpHomePage.clickOnFFFButton();
        String fProName = fffPage.getFinalProcessName();
        fffPage.inputProcessName(processName);

        fffPage.selectCreditInput(creditInput);
        fffPage.selectProcess(process);
        fffPage.selectData(data);
        if (tc_Id.equals("FFF_ID_111"))
        {
            String jobFieldValue = fffPage.isJobfieldHasValue();
            System.out.println("value of job field when ready state input is selected" + jobFieldValue);
            assertTrue(jobFieldValue.equalsIgnoreCase(""));

        }
        String isGroupPresent = fffPage.isGroupPresent();
        if ("block".equalsIgnoreCase(isGroupPresent))
        {
            if (tc_Id.equals("FFF_ID_395"))
            {
                fffPage.inputConfigLoctn(configFileLocation);
                commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
                fffPage.clickSaveButton();
                ProjDashBoardPage.clickDataProcessingTab();

                commMethods.verifyString(dpHomePage.getProcessStatusNew(), StatusEnum.ERROR.name().trim());
                dpHomePage.selectEditFFF();

            } else if (tc_Id.equals("FFF_ID_103")) // group name
            {
                List<String> grpNameList = fffPage.isGroupDisplayed(groups);
                if (CollectionUtils.isNotEmpty(grpNameList))
                {

                    for (String grp_Name : grpNameList)
                    {
                        String[] grpNamesArr = groups.split(",");
                        assertTrue(grp_Name.equalsIgnoreCase(grpNamesArr[0]) || grp_Name.equalsIgnoreCase(grpNamesArr[1])
                                || grp_Name.equalsIgnoreCase(grpNamesArr[2]));
                        System.out.println("following are the group fetched" + " " + grp_Name);
                    }

                }
                assertTrue(grpNameList.size() > 2);

            }
            commMethods.selectTheGroups(groups);
            /*
             * boolean allRecChckBox = driver.findElement(By.xpath(".//*[@id='allRecordsGroups']" )).isSelected();
             * commMethods.verifyboolean(allRecChckBox, true);
             */

        }
        fffPage.inputConfigLoctn(configFileLocation);
        if (tc_Id.equals("FFF_ID_391"))
        {
            fffPage.clickSaveButton();
            ProjDashBoardPage.clickDataProcessingTab();
            commMethods.verifyString(dpHomePage.getProcessStatusNew(), StatusEnum.ERROR.name().trim());
            dpHomePage.selectEditFFF();
        }
        commMethods.selectRecordTypes(processName, allRecords, accepts, rejects);
        fffPage.clickSaveButton();
        if (tc_Id.equals("FFF_ID_108"))
        {
            fffPage.clickSubmitButton();
            String errMsg = fffPage.FetchErrorMessage();
            errMsg.replace("\\", "");
            errMsg.replace("\\", "");
            if (errMsg != null)
            {
                commMethods.verifyString("Error : Job run details for Input Process " + "\"" + process + "\"" + " selected for process " + fProName
                        + ":" + processName + " do not exist.", errMsg);
                // Job run details for Input Process
                // "FL84:collapseDefaultAfterBack" selected for process
                // FFF18:RegTC_chk_state_of_process do not
                // exist.
            }
        } else if (tc_Id.equals("FFF_ID_110"))
        {
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);

            String new_process_name = fProName + ":" + processName;
            List<String> processNameList = new ArrayList<String>();

            processNameList.add(new_process_name);
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            jobStackingPage.selectTheProcessFromTheFlowChart(processNameList,30);
            jobStackingPage.clickJobStackingSubmitButton();
            ProjDashBoardPage.clickJobStackingTab();
            String status = commMethods.getProcessStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
        } else if (tc_Id.equals("FFF_ID_112"))
        {
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);
            String new_process_name = fProName + ":" + processName;
            List<String> processNameList = new ArrayList<String>();
            processNameList.add(process);
            processNameList.add(new_process_name);
            jobStackingPage.clickProcessDropDown();

            if (CollectionUtils.isNotEmpty(processNameList))
            {
                for (String process_Name : processNameList)
                {
                    String[] procArr = process_Name.split(":");
                    boolean isProcessPresent = jobStackingPage.isProcessPresent(procArr[0] + " " + "-" + " " + procArr[1]);
                    assertTrue(isProcessPresent);
                }
            }

        } else if (tc_Id.equals("FFF_ID_105"))
        {
            String jobId = fffPage.jobIdForTheSelectedProcess();
            fffPage.clickSubmitButton();
            commMethods.verifyString(dpHomePage.getProcessStatusNew(), StatusEnum.SUBMITTED.name().trim());
            dpHomePage.selectSummaryFFF();
            commMethods.verifyString(fffPage.processName(), process);
            commMethods.verifyString(fffPage.jobNumber(), jobId);
            commMethods.verifyString(fffPage.data(), data);
            String record_types = fffPage.getRecordTypes(allRecords);
            commMethods.verifyString(record_types, "All Records regardless of type");
            String fetched_Credit_Input = fffPage.fetchCreditInputFromSummaryOfFFFProcess();
            assertTrue(creditInput.contains(fetched_Credit_Input));
            String fetched_Config_FilePath = fffPage.fetchConfigFilePathFromSummaryOfFFFProcess();
            commMethods.verifyString(fetched_Config_FilePath, configFileLocation);
            /*
             * String[] nameArr = process.split(":"); ProjDashBoardPage.clickHomeTab(); fffStatsView.clickViewStatsForJobLevel(nameArr[0]);
             * driver.switchTo().frame("sb-player"); String recordCount = fffPage.getTheRecordCountOfTheProcessAsInputToFFF(data);
             * commMethods.verifyString(fffPage.Count(), recordCount); ProjDashBoardPage.clickCloseButtonStats1(); driver.switchTo().defaultContent();
             * ProjDashBoardPage.clickDataProcessingTab();
             */

        }

        else if (tc_Id.equals("FFF_ID_113"))
        {
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);
            String new_process_name = fProName + ":" + processName;
            List<String> processNameList = new ArrayList<String>();
            processNameList.add(process);
            processNameList.add(new_process_name);
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            jobStackingPage.selectTheProcessFromTheFlowChart(processNameList,30);
            jobStackingPage.clickJobStackingSubmitButton();
            ProjDashBoardPage.clickJobStackingTab();
            String status = commMethods.getProcessStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());

        } else if (tc_Id.equals("FFF_ID_114"))
        {

            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);
            String assignedIdForStack = fffStatsView.getAssignedIdForStack();
            String stackNameForStats = assignedIdForStack + "_" + procNameForStack;
            String new_process_name = fProName + ":" + "" + processName;
            List<String> processNameList = new ArrayList<String>();
            processNameList.add(process);
            processNameList.add(new_process_name);
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            jobStackingPage.selectTheProcessFromTheFlowChart(processNameList,30);

            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(1000);
            ProjDashBoardPage.clickJobStackingTab();

            String status = commMethods.getProcessStatus();
            // String assignedIdForStack = fffStatsView.getAssignedIdForStack();

            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(1500);
            shPage.clickTheCollapseButton(fProName + "_" + processName, fProName + ":" + processName);
            List<String> assignedIdList = new ArrayList<String>();

            assignedIdList.add(process);
            assignedIdList.add(fProName + ":" + processName);
            boolean isProcessExecutedTogether = fffStatsView.isProcessPresent(stackNameForStats, assignedIdList);
            assertTrue(isProcessExecutedTogether);

        }
        // Validate that AVRO files are formed in JET JOB directory
        else if (tc_Id.equals("FFF_ID_099"))
        {
            fffPage.clickSubmitButton();

            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");

            ProjDashBoardPage.viewStats(fProName);
            Thread.sleep(1000);
            String path = fffStatsView.getJobDirectoryPathForJetForFFF();
            boolean isAvroFilesFormedInTheDirectory = fffStatsView.listAvroFiles(path);
            assertTrue(isAvroFilesFormedInTheDirectory);

        } else if (tc_Id.equals("FFF_ID_096"))
        {
            fffPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            ProjDashBoardPage.viewStats(fProName);
            String path = fffStatsView.getJobDirectoryPathForJetForFFF();
            String link = fffStatsView.findText();
            commMethods.verifyString("COUNTERS", link);
            fffStatsView.clickCounters();
            boolean isCountersFileFormed = fffStatsView.checkCounterFileFormedOrNot(path);
            assertTrue(isCountersFileFormed);

        } else if (tc_Id.equals("FFF_ID_095"))

        {
            fffPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            ProjDashBoardPage.viewStats(fProName);
            String path = fffStatsView.getOutputFilePathForFFF_GPEXPORT();
            String inputTableName = fffStatsView.getInputTableName();
            HashMap<String, String> columnData = commMethods.getColumnsDataFromTheTable(inputTableName);
            int countOfRecordFetchedFromTheGreenPlumTable = columnData.size();
            int countOfRecordsMatched = fffStatsView.readAndCompareTheDataOfFileWithGreenPlumData(path, columnData);
            commMethods.verifyInt(countOfRecordFetchedFromTheGreenPlumTable, countOfRecordsMatched);
        }

        else if (tc_Id.equals("FFF_ID_100"))
        {

            fffPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            ProjDashBoardPage.viewStats(fProName);
            // commMethods.searchProcessOnDashboardAndViewStats("FFF76_RegTC_chkOutputFiles");
            String outputFilePath = fffStatsView.getOutputFilePathForFFF_CONVERTAVRO();
            boolean isOutputFFFFileFormed = fffStatsView.readOutputFileForFFF(outputFilePath);
            assertTrue(isOutputFFFFileFormed);
            List<String> fetchedList = fffStatsView.checkNecessaryStatsForOutputFileOfConvertAvroWrkItemOfFF(outputFilePath);

            if (CollectionUtils.isNotEmpty(fetchedList))
            {
                for (String element : fetchedList)
                {

                    assertTrue(element.contains("TOTAL FFF SEGMENT RECORDS CREATED") || element.contains("TOTAL INPUT RECORDS"));

                }
            }
        } else if (tc_Id.equals("FFF_ID_389"))
        {

            fffPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            Thread.sleep(1000);

            ProjDashBoardPage.viewStats(fProName);
            // ProjDashBoardPage.viewStats("FFF59_RegTC_chkRecordDistr");
            // commMethods.searchProcessOnDashboardAndViewStats("FFF59_RegTC_chkRecordDistr");
            List<String> fetchedRecordDistribution = fffStatsView.fetchTheRecordTypeDistributionFromTheStats();
            boolean sorted = Ordering.natural().isOrdered(fetchedRecordDistribution);
            assertTrue(sorted);
        } else if (tc_Id.equals("FFF_ID_106"))
        {

            fffPage.clickSubmitButton();
            Thread.sleep(1500);
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");

        } else if (tc_Id.equals("MJ_ID_317"))
        {

            fffPage.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(fProName), "PASS");
            Thread.sleep(1000);

            ProjDashBoardPage.viewStats(fProName);
            String recordsProcessed = fffStatsView.fetchTheCountOfRecordProcessed();
            String inputTableName = fffStatsView.getInputTableName();
            commMethods.verifyLong(Long.valueOf(recordsProcessed), ProjDashBoardPage.getTheRecordsWithMatchFlagAsBlankFromGP(inputTableName));

        }
    }
     
    @DataProvider
    public Object[][] fff_CBA_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "FFF", "CBA");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] fffStats_Y() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "FFF", "Y");
        return testObjArray;
    }

}
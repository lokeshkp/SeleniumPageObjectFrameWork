package com.equifax.cms.fusion.test.sourcematch;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.repository.GreenPlumDBHelper;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.JobDetailsVO;
import com.equifax.cms.fusion.test.vo.SMProcessInputVO;

@Features("Source Match process positive test scenarios Save/Edit/Duplicate/Submit")
public class SoureMatchTestCase extends AbstractCoreTest {

	private static final String SOURCE_MATCH = "Source Match";

	private static final Logger LOGGER = LoggerFactory.getLogger(SoureMatchTestCase.class);

    GreenPlumDBHelper gp = new GreenPlumDBHelper();

	@Step("SM Save/Edit/Duplicate/Submit flow")
	@Test
	public void testSourceMatchProcess() throws Exception {

		LOGGER.debug("-- source match input -- ");
		List<SMProcessInputVO> list = reader.getSourceMatchInputData();

		userLogin();
		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);

		for (SMProcessInputVO vo : list) {

            // Save source match process
            if (ProcessOperationEnum.SAVE.name().equalsIgnoreCase(vo.getOperation())) {
                saveSourceProcess(vo.getProcessName(), vo);
            } else if (ProcessOperationEnum.EDIT.name().equalsIgnoreCase(vo.getOperation())) {
                editSourceProcess(vo.getProcessName(), vo);
            } else if (ProcessOperationEnum.DUPLICATE.name().equalsIgnoreCase(vo.getOperation())) {
                duplicateSourceProcess(vo.getProcessName(), vo);
            } else if (ProcessOperationEnum.SUBMIT.name().equalsIgnoreCase(vo.getOperation())) {
                submitSourceProcess(vo.getProcessName(), vo);
            }
        }
		userLogout();
		LOGGER.debug("--  logout -- ");
	}

    @Step("Save Source Match process {0}")
    private void saveSourceProcess(String processName, SMProcessInputVO vo) throws InterruptedException
    {

        createAttachment(vo.toString());

        navigateToProcess(SOURCE_MATCH);
        navigateToNewProcessPage("New Source Match");
        driver.findElement(By.id("smName")).sendKeys(vo.getProcessName());
        // get from csv file
        new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
        new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(vo.getOutputTable());

        delayThread(10000);
        driver.findElement(By.id("addButton")).click();
        waitForAjax();
        selectSave();
        navigateToProcess(SOURCE_MATCH);
        String status = getStatusSM();

        // TestCase : Save functionality works with all values complete
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());
    }

    @Step("Submit Source Match process {0}")
	private void submitSourceProcess(String processName, SMProcessInputVO vo) {

		createAttachment(vo.toString());

		navigateToProcess(SOURCE_MATCH);

        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Summary")).click();
                break;
            }
        }

		selectSubmit();
		navigateToProcess(SOURCE_MATCH);
        String status = getStatusSM();
		// Status for the process should change to submitted
        Assert.assertEquals(StatusEnum.SUBMITTED, status.trim());

		navigateToHome();
		String jobId = getJobId();
		verifySourceProcess(vo.getProcessName(), jobId);

	}

	@Step("Verify source {0} process job id {1} in database")
	public void verifySourceProcess(String processName, String jobVal) {

		Long jobId = Long.parseLong(jobVal);
		LOGGER.info(">> Job Id [{}]", jobId);

		String status = db.getStatusForJob(jobId);
		LOGGER.info("Status -- [{}] ", status);

		// Wait for a minute
		// check three times if status changes

		int count = 0;
		while (status.equals(StatusEnum.PROCESSING.name())) {
			try {
				Thread.sleep(30000);
				status = db.getStatusForJob(jobId);
				// try for three times
				if (count > 3) {
					// status = "FAILED";
					break;
				}
			} catch (InterruptedException e) {
				LOGGER.error("Thread wait error {} ", e.getMessage());
			}
		}

		// Check Job status
		Assert.assertEquals(StatusEnum.COMPLETED.name(), status);

		// Verify the content
		List<JobDetailsVO> jobDetails = db.getStatusDetails(jobId);
		Assert.assertTrue(jobDetails.size() == 3);

        // Verify values from greenplum
        driver.findElement(By.linkText("View")).click();
        // Get output table name generated
        String opTableName = driver.findElement(By.xpath("//div[@id='dialog']/div[3]/div[2]/div[2]")).getText();
        String totalRecordCount = driver.findElement(By.xpath("//div[@id='dialog']/div[3]/div[3]/div[2]")).getText();
        // Get gp total number of records count
//        long totalRecordCountFromGPTable = gp.getGPCount(opTableName);

//        Assert.assertEquals(Long.parseLong(totalRecordCount), totalRecordCountFromGPTable);
        // Close the dialog box
        driver.findElement(By.xpath("(//button[@type='button'])[2]")).click();

	}


	@Step("Duplicate Source Match process {0}")
	private void duplicateSourceProcess(String processName, SMProcessInputVO vo) {

		createAttachment(vo.toString());

        // TestCase : Duplicate functionality works with all values complete
        navigateToProcess(SOURCE_MATCH);
        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                duplicateProcess();
                break;
            }
        }
        String status = getStatusSM();
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());

	}

	@Step("Edit Source Match process {0}")
	private void editSourceProcess(String processName, SMProcessInputVO vo) {

		createAttachment(vo.toString());

        navigateToProcess(SOURCE_MATCH);
        // Test Case : Edit the input process, select a new layout, continue,
        // add a field and constant and continue
        // selectEdit();

        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Edit")).click();
                modifySMProcess(vo, columns);
                break;
            }
        }
    }

    private void modifySMProcess(SMProcessInputVO vo, List<WebElement> columns)
    {
        String oldProcessName = driver.findElement(By.id("fromProcessId")).getText();

        new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
        new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(vo.getOutputTable());

        delayThread(10000);
        // In case new process and data is selected and user wants to add it
        if (oldProcessName != vo.getInputProcess())
        {
            driver.findElement(By.id("addButton")).click();
        }

        try
        {
            waitForAjax();
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        selectSave();
        navigateToProcess(SOURCE_MATCH);
        String status = getStatusSM();

        // TestCase : Edit functionality works with all values complete
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());
    }


}

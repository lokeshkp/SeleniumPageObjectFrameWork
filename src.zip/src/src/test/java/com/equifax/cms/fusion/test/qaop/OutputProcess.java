package com.equifax.cms.fusion.test.qaop;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import junit.framework.Assert;

import org.apache.commons.lang3.builder.StandardToStringStyle;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringPage;
import com.equifax.cms.fusion.test.OPPages.OpAliasPage;
import com.equifax.cms.fusion.test.OPPages.OpConfigurationPage;
import com.equifax.cms.fusion.test.OPPages.OpDataCheckPage;
import com.equifax.cms.fusion.test.OPPages.OpFileNamingSplittingPage;
import com.equifax.cms.fusion.test.OPPages.OpHomePage;
import com.equifax.cms.fusion.test.OPPages.OpMoveStatementsPage;
import com.equifax.cms.fusion.test.OPPages.OpRecordTypesPage;
import com.equifax.cms.fusion.test.OPPages.OpSetupPage;
import com.equifax.cms.fusion.test.OPPages.OpSortOrderPage;
import com.equifax.cms.fusion.test.OPPages.OpStatsView;
import com.equifax.cms.fusion.test.OPPages.OpSummaryPage;
import com.equifax.cms.fusion.test.RNPages.DataProcessingHomePage;
import com.equifax.cms.fusion.test.RNPages.RandomNthSetupPage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.GreenPlumDBHelper;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Output Process")
public class OutputProcess extends AbstractCoreTest
{
    // private static final Logger LOGGER = (Logger)
    // LoggerFactory.getLogger(OutputProcess.class);
    boolean flag = false;
    public WebDriver driver;
    public static String formattedDate1;
    private ProjectDashBoardPage projDashBoardPage;
    private OpHomePage opHomePage;
    private OpSetupPage opSetupPage;
    private OpRecordTypesPage opRecTypesPage;
    private OpAliasPage opAliasPage;
    private OpConfigurationPage opConfigPage;
    private OpMoveStatementsPage opMoveStPage;
    private OpSortOrderPage opSortOrderPage;
    private OpFileNamingSplittingPage opFileNameSplitPage;
    private OpDataCheckPage opDataChckPage;
    private CommonMethods commMethods;
    private OpSummaryPage opSumPage;
    private OpStatsView opStatsView;
    public OracleDBHelper db;
    private DataProcessingHomePage dpHomePage;
    private RandomNthSetupPage rnPage;
    private GreenPlumDBHelper greenPlumConnect;
    private ShippingPage shpPage;
    private Modules module;
    private FilteringPage filterPage;
    private DataProcessingTabFIL dpHomePageFL;
    private JobStackingPage jobStacking;
    private StackingPage stackPage;
    private DMSummaryPage DMSummPag;
    private StackingPage stackingPage;
    private JobStackingPage jobStackingPage;
    String inputDate;
    public static int i = 0;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final boolean IS_UNIX = "/".equals(File.separator);
    private static final Logger LOGGER = LoggerFactory.getLogger(OutputProcess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginandSearchProj() throws InterruptedException
    {
         //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        opHomePage = PageFactory.initElements(driver, OpHomePage.class);
        opSetupPage = PageFactory.initElements(driver, OpSetupPage.class);
        opRecTypesPage = PageFactory.initElements(driver, OpRecordTypesPage.class);
        opAliasPage = PageFactory.initElements(driver, OpAliasPage.class);
        opConfigPage = PageFactory.initElements(driver, OpConfigurationPage.class);
        opMoveStPage = PageFactory.initElements(driver, OpMoveStatementsPage.class);
        opSortOrderPage = PageFactory.initElements(driver, OpSortOrderPage.class);
        opFileNameSplitPage = PageFactory.initElements(driver, OpFileNamingSplittingPage.class);
        opDataChckPage = PageFactory.initElements(driver, OpDataCheckPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        opSumPage = PageFactory.initElements(driver, OpSummaryPage.class);
        opStatsView = PageFactory.initElements(driver, OpStatsView.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingHomePage.class);
        rnPage = PageFactory.initElements(driver, RandomNthSetupPage.class);
        greenPlumConnect = PageFactory.initElements(driver, GreenPlumDBHelper.class);
        shpPage = PageFactory.initElements(driver, ShippingPage.class);
        module = PageFactory.initElements(driver, Modules.class);
        dpHomePageFL = PageFactory.initElements(driver, DataProcessingTabFIL.class);
        filterPage = PageFactory.initElements(driver, FilteringPage.class);
        DMSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "op_QA", description = "TS1: Output process duplicate, summary status validations" )
    public void opProcessStatus(String tc_Id, String testRun, String TC, String desc, String copyProject, String copyProcessName, String processName,
            String process, String data, String groups, String purpose, String outputTableName, String creatOrExistLayout, String projExisLay,
            String exisLayName, String splitRecords, String filenames, String recordType, String aliasTable, String seeding, String reseqReq,
            String reSeqNum, String LayoutName, String fileFormat, String delimiter, String crLFOptions, String layoutTableName,
            String layoutFieldsToSelect, String layoutFieldsToUpdate, String fieldToMaskOrScrammble, String maskScrambleFormatMaskValues,
            String moveStatReq, String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, String FileNum,
            String fileSplitReq, String grpNum, String numOfFiles, String splitField, String secondarySplitReq, String secondarySplitByFile,
            String secondarySplitByRecord, String dataCheck, String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown,
            String runTimeB, String newProcessName, String newProcess, String newData, String newAliasTable, String submitRequired,
            ITestContext testContext) throws Exception
    {
        new Modules();
        testContext.setAttribute("WebDriver", driver);

        projDashBoardPage.clickOutputTab();
        opHomePage.clickOutputButton();
        Date date = new Date();
        inputDate = dateFormat.format(date);
        if ("OP_ID_213".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            commMethods.verifyString(opSetupPage.getErrorMessage(), "Error : Please select purpose.");
        }

        if ("OP_ID_149".equalsIgnoreCase(tc_Id))
        {

            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            String title = opSetupPage.selectLayoutAndGetTitle(creatOrExistLayout);

            commMethods.verifyString(title, "Output Setup Complete the required information and then click 'Continue'");
        }
        if ("OP_ID_015".equalsIgnoreCase(tc_Id))
        {
            // new Modules();
            // testContext.setAttribute("WebDriver", driver);
            // projDashBoardPage.clickOutputTab();
            // opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            // commMethods.verifyboolean(true,
            // opRecTypesPage.checkAllRecordsOptionsAvailable());
            commMethods.verifyboolean(commMethods.isElementPresent_ID("A"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("A"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("B"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("B"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("C"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("C"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("D"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("D"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("E"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("E"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("F"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("F"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("G"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("G"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("H"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("H"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("I"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("I"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("J"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("J"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("K"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("K"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("L"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("L"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("M"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("N"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("N"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("N"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("O"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("O"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("P"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("P"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("Q"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("Q"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("R"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("R"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("S"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("S"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("T"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("T"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("U"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("U"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("V"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("V"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("W"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("W"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("X"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("X"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("Y"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("Y"), "accepts");
            commMethods.verifyboolean(commMethods.isElementPresent_ID("Z"), true);
            commMethods.verifyString(commMethods.isElementPresentAreAcceptRecordTypes("Z"), "accepts");
        }
        if ("OP_ID_001".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.clickHomeTab();
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcessName);
            projDashBoardPage.clickCopySelectBtn();
            module.initializeDriver(driver);
            projDashBoardPage.clickOutputTab();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectEditOP();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Setup Complete the required information and then click 'Continue'");
            commMethods.verifyString(opSetupPage.Ele_ProcessName.getAttribute("value"), processName);
            commMethods.verifyboolean(opSetupPage.isProcessNameEditable(), true);
            commMethods.verifyString(opSetupPage.getJobId(), "");
            commMethods.verifyString(opSetupPage.getDataSelected(), data);
            commMethods.verifyString(opSetupPage.getFilePurposeSelected(), purpose);
            commMethods.verifyString(opSetupPage.ExistingLayout_Rbtn.getAttribute("checked"), "true");
            commMethods.verifyString(opSetupPage.Ele_OPTableName.getAttribute("value").replaceAll("\\s+", ""),
                    outputTableName.replaceAll("\\s+", ""));
            opSetupPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Record Types Complete the required information below, and then click 'Save' or 'Continue'.");
            commMethods.verifyString(opRecTypesPage.recordType_RB.getAttribute("checked"), "true");
            String[] arrFileName = filenames.split(",");
            List<String> providedFileNameList = Arrays.asList(arrFileName);
            List<String> fetchedFileNameList = opRecTypesPage.getFileNames();
            int i = 0;
            while (i < fetchedFileNameList.size())
            {
                commMethods.verifyString(fetchedFileNameList.get(i), providedFileNameList.get(i));
                i++;
            }

            // commMethods.verifyString(opRecTypesPage.getSecondFileName(),
            // arrFileName[1]);
            opRecTypesPage.clickContinueButton();
            String[] arrAliasTable = aliasTable.split(",");
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
            commMethods.verifyString(opAliasPage.getSelectedAliasTable(), arrAliasTable[0]);
            commMethods.verifyString(opAliasPage.getAliasProvided(), arrAliasTable[1]);
            opAliasPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Configuration Select the output layout fields and click 'Continue'.");
            commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isSelected(), false);
            // commMethods.verifyString(opConfigPage.Ele_ASCIIFixed.getAttribute("checked"),
            // "checked");
            // commMethods.verifyString(opConfigPage.fetchTheSelectedFileFormat(),fileFormat);
            commMethods.verifyString(opConfigPage.isResequenceCheckBoxSelected(), reseqReq);

            // mmMethods.verifyString(opConfigPage.startNum_Field.getAttribute("value"),
            // reSeqNum);
            // To Do uncomment it
            // commMethods.verifyString(opConfigPage.Ele_CSV_LayoutFile.getAttribute("value"),
            // LayoutFile);
            opConfigPage.clickContinueButton();
            // String[] arrLayoutField = layoutField.split(",");
            // String[] arrMovRecType = movRecType.split(",");
            // String[] arrDataToOutput = dataToOutput.split(",");
            // /*
            // * commMethods.verifyString(opMoveStPage.getFirstOPLayoutField(),
            // arrLayoutField[0]);
            // * commMethods.verifyString(opMoveStPage.getSecondOPLayoutField(),
            // arrLayoutField[1]);
            // * commMethods.verifyString(opMoveStPage.getFirstRecordTypes(),
            // arrMovRecType[0]);
            // * commMethods.verifyString(opMoveStPage.getSecondRecordTypes(),
            // arrMovRecType[1]);
            // * commMethods.verifyString(opMoveStPage.getFirstDataToOutput(),
            // arrDataToOutput[0]);
            // * commMethods.verifyString(opMoveStPage.getFirstDataToOutput(),
            // arrDataToOutput[0]);
            // */
            commMethods.verifyString(opMoveStPage.isMoveStatementReq(), moveStatReq);
            opMoveStPage.clickContinueButton(process);
            commMethods.verifyString(opSortOrderPage.isSortRequired(), sortReq);
            opSortOrderPage.clickContinueButton(purpose);
            commMethods.verifyString(opFileNameSplitPage.isFilesplittingReq(), fileSplitReq);
            opFileNameSplitPage.clickContinueButton();
            // commMethods.verifyString(opDataChckPage.MaxNoBlankFlds.getAttribute("value"),
            // "1000");
            commMethods.verifyString(opDataChckPage.isDataCheckReq(), dataCheck);
            if (opDataChckPage.isDataCheckReq().equalsIgnoreCase("Y"))
            {
                commMethods.verifyString(opDataChckPage.fetchTheMaxBlankField(), maxNoBlank);
            }
        }

        if ("OP_ID_003".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.clickHomeTab();
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcessName);
            projDashBoardPage.clickCopySelectBtn();
            module.initializeDriver(driver);
            projDashBoardPage.clickOutputTab();
            Thread.sleep(2500);
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.ERROR.name().trim());
            opHomePage.selectEditOP();
            commMethods.verifyString(opSetupPage.getDataSelectedNoInput(), "Select");
            commMethods.verifyString(opSetupPage.getProcessSelected(), "Select");
        }

        if ("OP_ID_005".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.clickHomeTab();
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcessName);
            projDashBoardPage.clickCopySelectBtn();
            module.initializeDriver(driver);
            projDashBoardPage.clickOutputTab();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectEditOP();
            opSetupPage.clickContinueButton();
            opRecTypesPage.clickContinueButton();
            commMethods.verifyboolean(opAliasPage.is_INQUIRYPOSTTBL_Present(), true);
            commMethods.verifyboolean(opAliasPage.is_STEP_FLAG_TABLE_Present(), true);
        }
        // if ("OP_ID_158".equalsIgnoreCase(tc_Id))
        // {
        //
        // opSetupPage.inputprocessName(processName);
        // opSetupPage.selectProcessField(process);
        // opSetupPage.selectDataField(data);
        // commMethods.selectTheGroups(groups);
        // opSetupPage.selectFilePurpose(purpose);
        // opSetupPage.inputOutputTableName(outputTableName);
        // opSetupPage.selectLayout(creatOrExistLayout, projExisLay,
        // exisLayName);
        // opSetupPage.clickContinueButton();
        // projDashBoardPage.clickOutputTab();
        // commMethods.verifyString(opHomePage.GetStatusOP(),
        // StatusEnum.ERROR.name().trim());
        // }
        if ("OP_ID_012".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.clickHomeTab();
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcessName);
            projDashBoardPage.clickCopySelectBtn();
            module.initializeDriver(driver);

            projDashBoardPage.clickOutputTab();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectEditOP();
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectProcessField(process);
            opSetupPage.selectDataField(data);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            // opSetupPage.ifPopPresentClickOk();
            // opRecTypesPage.selectRecordTypes(splitRecords, process,
            // filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.removeAliasTables(aliasTable);
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName,
            // layoutFieldsToSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.clickContinueBtnOP();
            opSumPage.clickSubmitButton();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

        }

        if ("OP_ID_366".equalsIgnoreCase(tc_Id))
        {
            // opSetupPage.inputprocessName(processName);
            // opSetupPage.selectProcessField(process);
            // opSetupPage.selectDataField(data);
            // commMethods.selectTheGroups(groups);
            // opSetupPage.selectFilePurpose(purpose);
            // opSetupPage.inputOutputTableName(outputTableName);
            // opSetupPage.selectLayout(creatOrExistLayout, projExisLay,
            // exisLayName);
            // opSetupPage.clickContinueButton();
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Record Types Complete the required information below, and then click 'Save' or 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.selectSplitRecord(splitRecords, process);
            // opRecTypesPage.createFilesWithName(filenames);
            // opRecTypesPage.selectRecordTypes(recordType);
            // opRecTypesPage.clickContinueButton();
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Output Alias Define the alias for the output tables and click 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.inputAliasTables(aliasTable);
            // opAliasPage.clickContinueButton();
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Output Configuration Select the output layout fields and click 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.clickContinueButton();
            // opConfigPage.seeding(process, seeding, purpose);
            //
            // // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            // opConfigPage.clickContinueButton();
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            // opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType,
            // dataToOutput, process);
            // opMoveStPage.clickContinueButton(process);
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Sort Order Complete the required information below, and then click 'Save' or 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            // opMoveStPage.clickContinueButton(process);
            // opSortOrderPage.clickSortRequired(sortReq, purpose);
            // opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            // opSortOrderPage.clickContinueButton(purpose);
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Output File Naming / Output File Splitting Enter a file number,select splitting options and click 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            // opMoveStPage.clickContinueButton(process);
            // opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            // opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum,
            // numOfFiles, splitField);
            // opFileNameSplitPage.clickContinueButton();
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "DataCheck Enter Required Information below and click 'Continue'.");
            // projDashBoardPage.clickOutputTab();
            // commMethods.verifyString(opHomePage.GetStatusOP(),
            // StatusEnum.ERROR.name().trim());
            // opHomePage.selectEditOP();
            // opSetupPage.clickContinueButton();
            // opRecTypesPage.clickContinueButton();
            // opAliasPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            // opMoveStPage.clickContinueButton(process);
            // opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.clickContinueButton();
            // opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose,
            // dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown,
            // runTimeB);
            // opDataChckPage.clickContinueButton();
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            //opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.clickResequenceAddButton(reseqReq);
            //opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);

            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.clickFileSplitReq();
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);

            opDataChckPage.clickContinueButton();

            projDashBoardPage.clickOutputTab();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectDuplicateOP();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectSummaryOP();
            opSumPage.clickSubmitButton();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
            opHomePage.selectDuplicateOP();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
        }
        if ("OP_ID_393".equalsIgnoreCase(tc_Id))
        {
            // UI Test Cases For the Output Process
            opSetupPage.clickContinueButton();
            //commMethods.verifyString(commMethods.getTextMsgError(), "Please enter the Process Name.");
            commMethods.verifyString(commMethods.getTextMsgError(), "Error : Please enter the Process Name.");
            opSetupPage.inputprocessName(processName);
            opSetupPage.clickContinueButton();
            commMethods.verifyString(commMethods.getTextMsgError(), "Please enter the Process Name.");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[1]")).getText(), "Process is required");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[2]")).getText(), "Table is required");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[3]")).getText(), "Please select purpose");
            opSetupPage.selectProcessField(process);
            opSetupPage.clickContinueButton();
            commMethods.verifyString(commMethods.getTextMsgError(), "Please enter the Process Name.");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[2]")).getText(), "Table is required");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[3]")).getText(), "Please select purpose");
            opSetupPage.selectDataField(data);
            opSetupPage.clickContinueButton();
            commMethods.verifyString(commMethods.getTextMsgError(), "Please enter the Process Name.");
            commMethods.verifyString(driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/label[3]")).getText(), "Please select purpose");
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.Ele_OPTableName.clear();
            opSetupPage.clickContinueButton();
            commMethods.verifyString(commMethods.getErMsg(), "Output Table name: field name is blank");
            opSetupPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Setup Complete the required information and then click 'Continue'");
            opSetupPage.clickLayoutSearchButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Layout Search Search for layouts below. Select a layout, and click 'Continue'.");
            opSetupPage.LayoutCancel_Btn.click();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Setup Complete the required information and then click 'Continue'");
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Setup Complete the required information and then click 'Continue'");
            opSetupPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Record Types Complete the required information below, and then click 'Save' or 'Continue'.");
            opRecTypesPage.clickContinueButton();
            commMethods.verifyboolean(opRecTypesPage.isPopUpDisplayed(), true);
            opRecTypesPage.clickPopUpOk();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.inputFileNameUI(filenames);
            opRecTypesPage.clickContinueButton();
            commMethods.verifyboolean(opRecTypesPage.isPopUpDisplayed(), true);
            opRecTypesPage.clickPopUpOk();
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Record Types Complete the required information below, and then click 'Save' or 'Continue'.");
            opRecTypesPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
            opAliasPage.clickContinueButton();
            commMethods.verifyString(commMethods.getErrMsgClass(), "Please select at least one table.");
            opAliasPage.clickSaveButton();
            commMethods.verifyString(commMethods.getErrMsgClass(), "Please select at least one table.");
            opAliasPage.clickFullForwardBtn();
            opAliasPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
            opAliasPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Configuration Select the output layout fields and click 'Continue'.");
            opConfigPage.clickBackBtn();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
            opAliasPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
            opAliasPage.clickFullBackwardBtn();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opAliasPage.clickOkPopUp();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Configuration Select the output layout fields and click 'Continue'.");
            commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isSelected(), true);
            commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isEnabled(), true);
            commMethods.verifyboolean(opConfigPage.Ele_ASCIIFixed.isEnabled(), true);
            commMethods.verifyboolean(opConfigPage.Ele_ASCIIFixed.isSelected(), true);
            commMethods.verifyboolean(opConfigPage.Ele_LineFeed.isEnabled(), true);
            commMethods.verifyboolean(opConfigPage.Ele_LineFeed.isSelected(), true);
            commMethods.verifyboolean(opConfigPage.reSequenceReq_CB.isSelected(), false);
            commMethods.verifyboolean(opConfigPage.reSequenceReq_CB.isEnabled(), true);
            commMethods.verifyboolean(opConfigPage.Ele_Delimiter.isEnabled(), false);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.clickContinueButton();
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Configuration Select the output layout fields and click 'Continue'.");
            opConfigPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            opMoveStPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            opMoveStPage.selectLayoutField(layoutField);
            opMoveStPage.clickContinueButton(process);
            opMoveStPage.selectRecTypes(movRecType);
            opMoveStPage.clickContinueButton(process);
            opMoveStPage.selectDatatoOutput(dataToOutput);
            opMoveStPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            opMoveStPage.clickContinueButton(process);
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Sort Order Complete the required information below, and then click 'Save' or 'Continue'.");
            commMethods.verifyboolean(opSortOrderPage.Ele_SortRequired.isEnabled(), true);
            commMethods.verifyboolean(opSortOrderPage.Ele_SortRequired.isSelected(), false);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            commMethods.verifyboolean(opSortOrderPage.Ele_SortRequired.isSelected(), true);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            opSortOrderPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Sort Order Complete the required information below, and then click 'Save' or 'Continue'.");
            opSortOrderPage.clickContinueButton(purpose);
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output File Naming / Output File Splitting Enter a file number,select splitting options and click 'Continue'.");
            commMethods.verifyboolean(opFileNameSplitPage.Ele_StartingFileNum.isEnabled(), true);
            commMethods.verifyString(opFileNameSplitPage.Ele_StartingFileNum.getAttribute("value"), "");
            commMethods.verifyboolean(opFileNameSplitPage.Ele_FileSplittingRequired.isEnabled(), true);
            commMethods.verifyboolean(opFileNameSplitPage.Ele_FileSplittingRequired.isSelected(), false);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.clickFileSplitReq();
            commMethods.verifyboolean(opFileNameSplitPage.divideFileIntoGrps_RB.isEnabled(), true);
            commMethods.verifyboolean(opFileNameSplitPage.splitByRecsPerFile_RB.isEnabled(), true);
            commMethods.verifyboolean(opFileNameSplitPage.splitByField_RB.isEnabled(), true);
            commMethods.verifyboolean(opFileNameSplitPage.splitFileBySize_RB.isEnabled(), true);
            commMethods.verifyboolean(opFileNameSplitPage.divideFileIntoGrps_RB.isSelected(), false);
            commMethods.verifyboolean(opFileNameSplitPage.splitByRecsPerFile_RB.isSelected(), false);
            commMethods.verifyboolean(opFileNameSplitPage.splitByField_RB.isSelected(), false);
            commMethods.verifyboolean(opFileNameSplitPage.splitFileBySize_RB.isSelected(), false);
            opFileNameSplitPage.clickContinueButton();
            commMethods.verifyString(commMethods.getTextMsgError(), "Please select at least one option for splitting");
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output File Naming / Output File Splitting Enter a file number,select splitting options and click 'Continue'.");
            opFileNameSplitPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "DataCheck Enter Required Information below and click 'Continue'.");
            commMethods.verifyboolean(opDataChckPage.Ele_DataCheckCheckBox.isEnabled(), true);
            commMethods.verifyboolean(opDataChckPage.Ele_DataCheckCheckBox.isSelected(), false);
            opDataChckPage.clickContinueBtnOP();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickSaveBtn();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "DataCheck Enter Required Information below and click 'Continue'.");
            opDataChckPage.clickContinueButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Summary: Output Review the information below, and then click 'Submit' or 'Back'. ");
            projDashBoardPage.clickOutputTab();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opHomePage.selectDuplicateOP();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            opSumPage.clickSubmitButton();
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
        }

        if ("OP_ID_155".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickSaveButton();
            projDashBoardPage.clickOutputTab();
            commMethods.verifyInt(projDashBoardPage.getNoOfProcessPresentId(fProID), 1);
            projDashBoardPage.clickOutputTab();
            commMethods.verifyInt(projDashBoardPage.getNoOfProcessPresentId(fProID), 1);
        }
        if ("OP_ID_075".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyboolean(opSetupPage.isOutputTableNameFieldPresent(), true);
            commMethods.verifyString(opSetupPage.Ele_OPTableName.getAttribute("value"), "OUTPUTTBLTEST");
            opSetupPage.inputOutputTableName(outputTableName);
            commMethods.verifyString(opSetupPage.fetchTheProvidedtableName(), outputTableName);
        }

        if ("OP_ID_073".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            opSetupPage.selectDataField(data);
            String[] arrProcess = process.split(":");
            String processNameForStats = arrProcess[0] + "_" + arrProcess[1];
            String jobNo = opSetupPage.getJobId();
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickSaveButton();
            projDashBoardPage.clickHomeTab();

            commMethods.verifyString(jobNo, commMethods.searchProcessOnDashboardAndGetTheJobNo(processNameForStats));
        }

        if ("OP_ID_149".equalsIgnoreCase(tc_Id))
        {

            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            String title = opSetupPage.selectLayoutAndGetTitle(creatOrExistLayout);

            commMethods.verifyString(title, "Output Setup Complete the required information and then click 'Continue'");
        }
        if ("OP_ID_270".equalsIgnoreCase(tc_Id))
        {

            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Setup Complete the required information and then click 'Continue'");
        }

        if ("OP_ID_016".equalsIgnoreCase(tc_Id))
        {
            // Validate that the options in the Available Record Types grid on
            // the Record Types Screen are disabled when an input Process
            // without
            // header table in its hierarchy is selected for Output Process
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            commMethods.verifyString(opRecTypesPage.getErrorMessage(), "All Records Will Be Written To File.");
            commMethods.verifyboolean(opRecTypesPage.isRecordTypesSelectionDisabled(), true);
        }
        if ("OP_ID_148".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickSaveButton();
            commMethods.verifyString(opRecTypesPage.getFirstFileName(), "abcdefghijklmnopqrstuvwxyzabcdefghijklmnopqrstuvwxyzabcdefghijkl");
        }

        if ("OP_ID_135".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickSaveButton();
            opAliasPage.clickSecondSelectedTable();
            opAliasPage.clickTableRemoveButton();
            opAliasPage.clickSaveButton();
            commMethods.verifyString(projDashBoardPage.getPageTitle(), "Output Alias Define the alias for the output tables and click 'Continue'.");
        }

        if ("OP_ID_416".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            boolean isPresent = opRecTypesPage.isRecordPresentInAvaliableFields(recordType);
            commMethods.verifyboolean(isPresent, true);

        }

        if ("OP_ID_417".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickSaveButton();
            String[] recordArr = recordType.split(",");
            commMethods.verifyInt(opRecTypesPage.noOfGroupsSelected(), recordArr.length);
        }

        if ("OP_ID_418".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.recordType_RB.click();
            Thread.sleep(2500);
            opRecTypesPage.clickCancelPopup();
            Thread.sleep(2500);
            boolean isRetained = opRecTypesPage.isSelectionRetained(recordType);
            Thread.sleep(2500);
            commMethods.verifyboolean(isRetained, true);
            Thread.sleep(2500);
            opRecTypesPage.recordType_RB.click();
            Thread.sleep(2500);
            opRecTypesPage.clickOkPopup();
            Thread.sleep(2500);
            boolean isCleared = opRecTypesPage.isSelectionclearedForRecordTypeScreen();
            Thread.sleep(2500);
            commMethods.verifyboolean(isCleared, true);
        }

        /*
         * Output Layout Validations
         */

        if ("OP_ID_094".equalsIgnoreCase(tc_Id) || "OP_ID_285".equalsIgnoreCase(tc_Id) || "OP_ID_204".equalsIgnoreCase(tc_Id)
                || "OP_ID_352".equalsIgnoreCase(tc_Id) || "OP_ID_348".equalsIgnoreCase(tc_Id) || "OP_ID_347".equalsIgnoreCase(tc_Id)
                || "OP_ID_342".equalsIgnoreCase(tc_Id) || "OP_ID_341".equalsIgnoreCase(tc_Id) || "OP_ID_021".equalsIgnoreCase(tc_Id)
                || "OP_ID_023".equalsIgnoreCase(tc_Id) || "OP_ID_123".equalsIgnoreCase(tc_Id) || "OP_ID_175".equalsIgnoreCase(tc_Id)
                || "OP_ID_195".equalsIgnoreCase(tc_Id) || "OP_ID_196".equalsIgnoreCase(tc_Id) || "OP_ID_197".equalsIgnoreCase(tc_Id)
                || "OP_ID_198".equalsIgnoreCase(tc_Id) || "OP_ID_199".equalsIgnoreCase(tc_Id) || "OP_ID_200".equalsIgnoreCase(tc_Id)
                || "OP_ID_202".equalsIgnoreCase(tc_Id) || "OP_ID_205".equalsIgnoreCase(tc_Id) || "OP_ID_239".equalsIgnoreCase(tc_Id)
                || "OP_ID_240".equalsIgnoreCase(tc_Id) || "OP_ID_241".equalsIgnoreCase(tc_Id) || "OP_ID_247".equalsIgnoreCase(tc_Id)
                || "OP_ID_250".equalsIgnoreCase(tc_Id) || "OP_ID_266".equalsIgnoreCase(tc_Id) || "OP_ID_268".equalsIgnoreCase(tc_Id)
                || "OP_ID_136".equalsIgnoreCase(tc_Id) || "OP_ID_302".equalsIgnoreCase(tc_Id) || "OP_ID_203".equalsIgnoreCase(tc_Id)
                || "OP_ID_276".equalsIgnoreCase(tc_Id) || "OP_ID_256".equalsIgnoreCase(tc_Id) || "OP_ID_286".equalsIgnoreCase(tc_Id)
                || "OP_ID_265".equalsIgnoreCase(tc_Id) || "OP_ID_262".equalsIgnoreCase(tc_Id))
        {

            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            if ("OP_ID_094".equalsIgnoreCase(tc_Id))
            {
                Integer noOfFields = opConfigPage.fetchThecountOfFieldsInTheTable(layoutTableName);
                commMethods.verifyInt(noOfFields, 41);
            } else if ("OP_ID_285".equalsIgnoreCase(tc_Id))
            {

                commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isSelected(), true);
            }

            else if ("OP_ID_204".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                commMethods.verifyboolean(opConfigPage.AddHeaderRecord_CB.isSelected(), true);
                opConfigPage.clickSaveButton();
                Thread.sleep(2500);
                commMethods.verifyboolean(opConfigPage.AddHeaderRecord_CB.isSelected(), true);
                Thread.sleep(2500);
                opConfigPage.AddHeaderRecord_CB.click();
                Thread.sleep(2500);
                opConfigPage.clickSaveButton();
                commMethods.verifyboolean(opConfigPage.AddHeaderRecord_CB.isSelected(), false);
            }

            /*
             * Output Config Screen Layout Loading Test Cases Valid and Invalid Layouts
             */
            else if ("OP_ID_352".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                // commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                // "Layout loaded successfully");
                commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
                        "Warning: The starting sequence number value is too large. The sequence numbers may be capped. Please verify based on the actual row count.");
                opConfigPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            }

            else if ("OP_ID_348".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

                // opConfigPage.clickResequenceAddButton(reseqReq);
                // opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate,reseqReq);

                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(), "Error: Scrambling cannot be applied on field RE_SEQUENCE_NUM");
            }

            else if ("OP_ID_347".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

                // opConfigPage.clickResequenceAddButton(reseqReq);
                // opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate,reseqReq);

                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(), "Error: Masking cannot be applied on field RE_SEQUENCE_NUM");
            }

            else if ("OP_ID_342".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);

                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                // opConfigPage.selectResequenceReq_CB("Y", "1000");
                opConfigPage.clickContinueButton();
                /*
                 * commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_STANDARD_ALL_FIELDS_LAYOUT.csv" );
                 */
                /*
                 * commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
                 * "Error: The layout must contain a field named RE_SEQUENCE_NUM with no alias in order to Re-sequence the output files." );
                 */
                commMethods.verifyString(opConfigPage.getTheErrorMessage(),
                        "Error: The layout must contain a field named RE_SEQUENCE_NUM with no alias in order to Re-sequence the output files");

            }

            else if ("OP_ID_341".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickContinueButton();
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                // commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                // "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_STANDARD_ALL_FIELDS_LAYOUT.csv");
                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                        "Error: The layout must contain a field named RE_SEQUENCE_NUM with no alias in order to Re-sequence the output files.");

            }

            else if ("OP_ID_021".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.dragAndDropSelectedField(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickToCalculateStartEndPosition();
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_021_NUM_DEFAULT_VALUE_NUM_SPCL_CHAR.csv"
                 * );
                 */
                // commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
                // "Error: Default value ABC is not correct for Data Type NUM.");
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Default value @@ is not correct for Data Type NUM."));

            }

            else if ("OP_ID_023".equalsIgnoreCase(tc_Id))
            {
                /*
                 * Not Working
                 */
                // opConfigPage.outputLayoutNameField(inputDate);
                // opConfigPage.selectFileFormat(fileFormat);
                // opConfigPage.selectCRLFOptions(crLFOptions);
                // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // / opConfigPage.inputLayoutLocAndLoad(LayoutFile);

                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

                opConfigPage.clickContinueButton();
                // commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                // "Failed to save layout /nas/users/jbodeddula/sourav/Output_layout_file/Anil001/Hdr_all.csv");
                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                        "A layout with the same name is being used by another process in this project. Please provide a name unique to this project");
            }

            else if ("OP_ID_123".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            }

            else if ("OP_ID_175".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                        "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/FLOAT_OP_ID_175_WITH_PD_AND_DP_COLUMNS_INVALID.csv");
                commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
                        "Error: Incorrect number of columns in csv layout file /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/FLOAT_OP_ID_175_WITH_PD_AND_DP_COLUMNS_INVALID.csv");
            }

            else if ("OP_ID_195".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                //commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                 //       "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_195_CNX_PACKED_WITH_FORMAT_MASK_INVALID.csv");
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Value of Format Mask #.# is not valid for hdr.CNX_KEY field.");
            }

            else if ("OP_ID_196".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickToCalculateStartEndPosition();
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                // commMethods
                // .verifyString(opConfigPage.getFirstErrorMessage(),
                // "Failed to load layout
                // /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_196_CNX_PACKED_WITH_FORMAT_MASK_INVALID.csv");
                commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Value of Format Mask ## is not valid for hdr.CNX_KEY field.");
            }

            else if ("OP_ID_197".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);

                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_197_CNX_PACKED_2_STAR_MINUS_1_LENGHT_FM.csv"
                 * );
                 */
                // commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
                // "Error: The length of format mask for PACKED must be less than or equal to (field length * 2)-1 for field hdr.CNX_KEY");
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage()
                        .contains("Error: The length of Format Field for PACKED must be less than or equal to (field length * 2)-1"));
                // commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                // "Error: The length of format mask for PACKED must be less than or equal to (field length * 2)-1 for field hdr.CNX_KEY");

            }

            else if ("OP_ID_198".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickToCalculateStartEndPosition();
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_198_CNX_PACKED_WITH_FORMAT_MASK_INVALID.csv"
                 * );
                 */
                opConfigPage.clickContinueButton();
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage()
                        .contains("Error: The length of Format Field for UNSIGNED PACKED must be less than or equal to (field length * 2)"));
                // commMethods
                // .verifyString(opConfigPage.fetchTheErrorMessage(),
                // "Error: The length of format Field for UNSIGNED PACKED must be less than or equal to (field length * 2) for field hdr.CNX_KEY");
            } else if ("OP_ID_199".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();

                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Value of Format Field 00#D.D00 is not valid"));
            }

            else if ("OP_ID_200".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                Thread.sleep(1500);
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Value of Format Field DD#00 is not valid"));
            }

            else if ("OP_ID_202".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                // commMethods
                // .verifyString(opConfigPage.getFirstErrorMessage(),
                // "Failed to load layout
                // /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_202_CNX_BOTH_D_AND_PERIOD_NOT_ALLOWED.csv");
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Value of Format Field 00#.DD is not valid "));
            }

            else if ("OP_ID_205".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();

                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(), "Error: Customer field name is required.");
            }

            else if ("OP_ID_239".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                Thread.sleep(2500);
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
                Thread.sleep(1500);
                opMoveStPage.clickBackButton();
                Thread.sleep(1500);
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Configuration Select the output layout fields and click 'Continue'.");
                Thread.sleep(1500);
                opConfigPage.selectFileFormat("EBCDIC_Fixed");
                Thread.sleep(1500);
                // opConfigPage.clickLoadButton();
                opConfigPage.clickContinueButton();
                Thread.sleep(2500);
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
                opMoveStPage.clickBackButton();
                Thread.sleep(1500);
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Configuration Select the output layout fields and click 'Continue'.");
                Thread.sleep(1500);
                opConfigPage.selectFileFormat("ASCII_Delimited");
                Thread.sleep(1500);
                // opConfigPage.clickLoadButton();
                opConfigPage.clickContinueButton();
                Thread.sleep(2500);
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Move Statements Complete the required information below, and then click 'Save' or 'Continue'.");
            }

            else if ("OP_ID_240".equalsIgnoreCase(tc_Id) || "OP_ID_275".equalsIgnoreCase(tc_Id) || "OP_ID_255".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickToCalculateStartEndPosition();
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_240_MASK_LENGTH_MORE_THAN_STRING.csv"
                 * );
                 */
                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                        "Error: mask length 4 and length of the mask string provided AAA --> 3 characters, are not equal for field hdr.CID");
                /*
                 * opConfigPage.selectFileFormat("EBCDIC_Fixed"); opConfigPage.clickLoadButton(); commMethods
                 * .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_240_MASK_LENGTH_MORE_THAN_STRING.csv"
                 * ); commMethods.verifyString(opConfigPage.getSecondErrorMessage (),
                 * "Error: mask length 4 and length of the mask string provided AAA --> 3 characters, are not equal for field hdr.F_NAME" );
                 * opConfigPage.selectFileFormat("ASCII_Delimited"); opConfigPage.clickLoadButton(); commMethods
                 * .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_240_MASK_LENGTH_MORE_THAN_STRING.csv"
                 * ); commMethods.verifyString(opConfigPage.getSecondErrorMessage (),
                 * "Error: mask length 4 and length of the mask string provided AAA --> 3 characters, are not equal for field hdr.F_NAME" );
                 */
            } else if ("OP_ID_241".equalsIgnoreCase(tc_Id) || "OP_ID_276".equalsIgnoreCase(tc_Id) || "OP_ID_256".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.clickToCalculateStartEndPosition();
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_241_MASK_LENGTH_LESS_THAN_STRING.csv"
                 * );
                 */
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage()
                        .contains("Error: mask length 4 and length of the mask string provided AAAAA --> 5 characters, are not equal"));
                /*
                 * opConfigPage.selectFileFormat("EBCDIC_Fixed"); opConfigPage.clickLoadButton(); commMethods
                 * .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_241_MASK_LENGTH_LESS_THAN_STRING.csv"
                 * ); commMethods.verifyString(opConfigPage.getSecondErrorMessage (),
                 * "Error: mask length 4 and length of the mask string provided AAAAA --> 5 characters, are not equal for field hdr.F_NAME" );
                 * opConfigPage.selectFileFormat("ASCII_Delimited"); opConfigPage.clickLoadButton(); commMethods
                 * .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_241_MASK_LENGTH_LESS_THAN_STRING.csv"
                 * ); commMethods.verifyString(opConfigPage.getSecondErrorMessage (),
                 * "Error: mask length 4 and length of the mask string provided AAAAA --> 5 characters, are not equal for field hdr.F_NAME" );
                 */
            }

            else if ("OP_ID_262".equalsIgnoreCase(tc_Id) || "OP_ID_247".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_268_PACKED_UNSIGNED_MASKING.csv" );
                 */
                opConfigPage.clickSaveButton();
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Invalid mask start position"));

            }

            // else if ("OP_ID_247".equalsIgnoreCase(tc_Id) ||
            // "OP_ID_247".equalsIgnoreCase(tc_Id))
            // {
            // opConfigPage.outputLayoutNameField(inputDate);
            // opConfigPage.selectFileFormat(fileFormat);
            // opConfigPage.selectCRLFOptions(crLFOptions);
            // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            // opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName,
            // layoutFieldsToSelect, creatOrExistLayout);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate,
            // creatOrExistLayout);
            // opConfigPage.clickToCalculateStartEndPosition();
            // opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues,
            // fieldToMaskOrScrammble);
            // opConfigPage.clickContinueButton();
            //
            // /*
            // * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
            // *
            // "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_247_END_LESS_THAN_MASK_START.csv");
            // */
            // /*
            // * commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
            // "Error: Invalid mask start position 106 for field hdr.F_NAME");
            // * commMethods.verifyString(opConfigPage.getThirdErrorMessage(),
            // "Error: Invalid mask length 2 for field hdr.F_NAME");
            // * opConfigPage.selectFileFormat("EBCDIC_Fixed");
            // opConfigPage.clickLoadButton(); commMethods
            // * .verifyString(opConfigPage.getFirstErrorMessage(),
            // *
            // "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_247_END_LESS_THAN_MASK_START.csv");
            // */
            // commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
            // "Error: Invalid mask start position 106 for field hdr.F_NAME");
            // commMethods.verifyString(opConfigPage.getThirdErrorMessage(),
            // "Error: Invalid mask length 2 for field hdr.F_NAME");
            // }

            /*
             * else if ("OP_ID_250".equalsIgnoreCase(tc_Id)) { opConfigPage.outputLayoutNameField(inputDate);
             * opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq,
             * reSeqNum); // opConfigPage.inputLayoutLocAndLoad(LayoutFile); commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
             * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_250_MASKING_ON_NUM.csv" );
             * commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY" );
             * opConfigPage.selectFileFormat("EBCDIC_Fixed"); opConfigPage.clickLoadButton();
             * commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
             * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_250_MASKING_ON_NUM.csv" );
             * commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY" );
             * opConfigPage.selectFileFormat("ASCII_Delimited"); opConfigPage.clickLoadButton();
             * commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
             * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_250_MASKING_ON_NUM.csv" );
             * commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY" );
             * } else if ("OP_ID_266".equalsIgnoreCase(tc_Id)) { opConfigPage.outputLayoutNameField(inputDate);
             * opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq,
             * reSeqNum); // opConfigPage.inputLayoutLocAndLoad(LayoutFile); commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
             * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_266_PACKED_MASKING.csv" );
             * commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY" );
             * }
             */

            // else if ("OP_ID_268".equalsIgnoreCase(tc_Id) ||
            // "OP_ID_268".equalsIgnoreCase(tc_Id) ||
            // "OP_ID_266".equalsIgnoreCase(tc_Id)
            // || "OP_ID_250".equalsIgnoreCase(tc_Id) ||
            // "OP_ID_286".equalsIgnoreCase(tc_Id) ||
            // "OP_ID_265".equalsIgnoreCase(tc_Id))
            // {
            //
            // opConfigPage.outputLayoutNameField(inputDate);
            // opConfigPage.selectFileFormat(fileFormat);
            // opConfigPage.selectCRLFOptions(crLFOptions);
            // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            // commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
            // "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_266_PACKED_MASKING.csv");
            // commMethods.verifyString(opConfigPage.getSecondErrorMessage(),
            // "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY");
            // }

            else if ("OP_ID_268".equalsIgnoreCase(tc_Id) || "OP_ID_266".equalsIgnoreCase(tc_Id) || "OP_ID_250".equalsIgnoreCase(tc_Id)
                    || "OP_ID_286".equalsIgnoreCase(tc_Id) || "OP_ID_265".equalsIgnoreCase(tc_Id))
            {

                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

                /*
                 * commMethods .verifyString(opConfigPage.getFirstErrorMessage(),
                 * "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_268_PACKED_UNSIGNED_MASKING.csv" );
                 */
                opConfigPage.clickSaveButton();
                Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Masking is not allowed for numeric Layout Field"));
                // commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                // "Error: Masking is not allowed for numeric Layout Field hdr.CNX_KEY");
            }

            else if ("OP_ID_136".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.clickContinueButton();
                //commMethods.verifyString(opConfigPage.getFirstErrorMessage(),
                //        "Failed to load layout /nas/users/jbodeddula/sourav/Automation/Output_Layout_Files/HDR_OP_ID_136_CUST_NAME_50_BYTES.csv");
                commMethods.verifyString(opConfigPage.getSecondErrorMessage(), "Error : File contains invalid values");
            } else if ("OP_ID_302".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.clickBackBtn();
                opAliasPage.clickFullForwardBtn();
                opAliasPage.clickContinueButton();
                commMethods.verifyboolean(opAliasPage.isPopupPresent(), true);
            }

        }

        /*
         * Test Cases Till Layout Testing
         */

        if ("OP_ID_406".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            // Add Purpose
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.clickFileSplitReq();
            opFileNameSplitPage.clickContinueButton();
            commMethods.verifyString(opFileNameSplitPage.getErrorMessage(), "Error: Please select at least one option for splitting");
        }

        if ("OP_ID_230".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            Thread.sleep(1500);
            opMoveStPage.clickAddButton();
            Thread.sleep(4500);
            opMoveStPage.clickRecordTypeIcon();
            Thread.sleep(4500);
            driver.switchTo().frame(0);
            Thread.sleep(1500);
            List<String> availRecs = opMoveStPage.getAvailableRecordsType();
            Thread.sleep(1500);
            String[] arrRec = recordType.split(";");
            Thread.sleep(1500);
            List<String> recordsList = Arrays.asList(arrRec);
            for (String record : recordsList)
            {
                commMethods.verifyboolean(availRecs.contains(record), true);
            }
            /*
             * for (int i = 1; i < availRecs.size(); i++) { commMethods.verifyString(availRecs.get(i), recordsList.get(i)); }
             */
        }

        if ("OP_ID_231".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.clickAddButton();
            Thread.sleep(4500);
            opMoveStPage.clickDataToOutputIcon();
            Thread.sleep(4500);
            driver.switchTo().frame(0);
            Thread.sleep(2500);
            commMethods.verifyString(opMoveStPage.getBlankFill(), "Blank Fill");
            commMethods.verifyString(opMoveStPage.getEnterLiteral(), "Enter Literal");
            commMethods.verifyString(opMoveStPage.getSelectField(), "Select Field");
            commMethods.verifyString(opMoveStPage.blankFill_RB.getAttribute("type"), "radio");
            commMethods.verifyString(opMoveStPage.enterLiteral_RB.getAttribute("type"), "radio");
            commMethods.verifyString(opMoveStPage.selectField_RB.getAttribute("type"), "radio");
        }

        if ("OP_ID_345".equalsIgnoreCase(tc_Id))
        {

            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.clickResequenceAddButton(reseqReq);
            opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate, reseqReq);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.clickContinueButton();
            opConfigPage.handleTheDialogBoxAndClickContinue();
            commMethods.verifyboolean(opMoveStPage.isFieldPresentForMovStat("RE_SEQUENCE_NUM"), false);
        }

        // if ("OP_ID_018".equalsIgnoreCase(tc_Id))
        // {
        // // Validate that Output sort screen is not displayed when Purpose
        // // "Apply capping" is selected.
        // String fProID = opSetupPage.getProcessID();
        // opSetupPage.selectOutputSetupOptions(processName, process, data,
        // groups, purpose, outputTableName);
        // opSetupPage.selectLayout(creatOrExistLayout, projExisLay,
        // exisLayName);
        // opSetupPage.clickContinueButton();
        // opRecTypesPage.selectRecordTypes(splitRecords, process, filenames,
        // recordType);
        // opRecTypesPage.clickContinueButton();
        // opAliasPage.inputAliasTables(aliasTable);
        // opAliasPage.clickContinueButton();
        // opConfigPage.seeding(process, seeding, purpose);
        // opConfigPage.outputLayoutNameField(inputDate);
        // opConfigPage.selectFileFormat(fileFormat);
        // opConfigPage.selectCRLFOptions(crLFOptions);
        // opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
        // // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
        // opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName,
        // layoutFieldsToSelect);
        // opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate);
        // opConfigPage.clickContinueButton();
        // opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType,
        // dataToOutput, process);
        // opMoveStPage.clickContinueButton(process);
        // commMethods.verifyString(projDashBoardPage.getPageTitle(),
        // "Output File Naming / Output File Splitting Enter a file number,select splitting options and click Continue.");
        // }

        if ("OP_ID_017".equalsIgnoreCase(tc_Id) || "OP_ID_018".equalsIgnoreCase(tc_Id))
        {
            // Validate that the Output Move Statement screen is not displayed
            // while configuring Output Process when an input Process without
            // header
            // table in its hierarchy is selected for Output Process
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
           //driver.navigate().to("http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/edit-alias?projectNumber=6000001&opId=3745603");
           // opAliasPage.clickContinueButton();
            Thread.sleep(2500);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            if ("OP_ID_018".equalsIgnoreCase(tc_Id))
            {
                opMoveStPage.clickContinueButton(process);
            }

            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Sort Order Complete the required information below, and then click 'Save' or 'Continue'.");
            // opSortOrderPage.clickContinueButton(purpose);
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Output File Naming / Output File Splitting Enter a file number,select splitting options and click Continue.");
        }

        if ("OP_ID_344".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);

            // driver.navigate().to("http://afnt1lc9a001.app.c9.equifax.com:9190/cms-fusion-web/output/edit-alias?projectNumber=TEST222&opId=3314809");
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);

            // opConfigPage.clickResequenceAddButton(reseqReq);

            // opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate,
            // reseqReq);
            opConfigPage.clickContinueButton();
            opConfigPage.handleTheDialogBoxAndClickContinue();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            // commMethods.verifyString(projDashBoardPage.getPageTitle(),
            // "Sort Order Complete the required information below, and then click 'Save' or 'Continue'.");
            commMethods.verifyboolean(opSortOrderPage.isReSequenceDisplayed(), false);
        }

        if ("OP_ID_125".equalsIgnoreCase(tc_Id))
        {
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            //opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            commMethods.verifyString(opSortOrderPage.getLayoutNameDisplayedSort(), inputDate);
            opSortOrderPage.clickContinueButton(purpose);
            commMethods.verifyString(opFileNameSplitPage.getLayoutNameSplitPage(), inputDate);
        }

        if ("OP_ID_346".equalsIgnoreCase(tc_Id))
        {

            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.clickResequenceAddButton(reseqReq);
            opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate, reseqReq);
            opConfigPage.clickContinueButton();
            opConfigPage.handleTheDialogBoxAndClickContinue();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickContinueButton(purpose);
            commMethods.verifyboolean(opFileNameSplitPage.isReSequenceDisplayed(), false);
        }
        if ("OP_ID_158".equalsIgnoreCase(tc_Id))
        {
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            projDashBoardPage.clickOutputTab();
            Thread.sleep(2500);
            commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.ERROR.name().trim());
        }

        /*
         * Validations Which Require Navigating To Summary Screen
         */

        if ("OP_ID_295".equalsIgnoreCase(tc_Id) || "OP_ID_294_TC10".equalsIgnoreCase(tc_Id) ||  "OP_ID_294_TC08".equalsIgnoreCase(tc_Id) 
        		||"OP_ID_157".equalsIgnoreCase(tc_Id)
                || "OP_ID_020".equalsIgnoreCase(tc_Id) || "OP_ID_054".equalsIgnoreCase(tc_Id) || "OP_ID_150".equalsIgnoreCase(tc_Id)
                || "OP_ID_343".equalsIgnoreCase(tc_Id) || "OP_ID_078".equalsIgnoreCase(tc_Id) || "OP_ID_079".equalsIgnoreCase(tc_Id)
                || "OP_ID_081".equalsIgnoreCase(tc_Id) || "OP_ID_116".equalsIgnoreCase(tc_Id) || "OP_ID_120".equalsIgnoreCase(tc_Id)
                || "OP_ID_122".equalsIgnoreCase(tc_Id) || "OP_ID_124".equalsIgnoreCase(tc_Id) || "OP_ID_130".equalsIgnoreCase(tc_Id)
                || "OP_ID_133".equalsIgnoreCase(tc_Id) || "OP_ID_141".equalsIgnoreCase(tc_Id) || "OP_ID_144".equalsIgnoreCase(tc_Id)
                || "OP_ID_161".equalsIgnoreCase(tc_Id) || "OP_ID_208".equalsIgnoreCase(tc_Id) || "OP_ID_356".equalsIgnoreCase(tc_Id)
                || "OP_ID_245".equalsIgnoreCase(tc_Id) || "OP_ID_260".equalsIgnoreCase(tc_Id) || "OP_ID_280".equalsIgnoreCase(tc_Id)
                || "OP_ID_334".equalsIgnoreCase(tc_Id) || "OP_ID_335".equalsIgnoreCase(tc_Id) || "OP_ID_337".equalsIgnoreCase(tc_Id)
                || "OP_ID_338".equalsIgnoreCase(tc_Id) || "OP_ID_339".equalsIgnoreCase(tc_Id) || "OP_ID_340".equalsIgnoreCase(tc_Id)
                || "OP_ID_372".equalsIgnoreCase(tc_Id) || "OP_ID_382".equalsIgnoreCase(tc_Id) || "OP_ID_376".equalsIgnoreCase(tc_Id)
                || "OP_ID_386".equalsIgnoreCase(tc_Id) || "OP_ID_138".equalsIgnoreCase(tc_Id) || "OP_ID_139".equalsIgnoreCase(tc_Id)
                || "OP_ID_303".equalsIgnoreCase(tc_Id) || "OP_ID_383".equalsIgnoreCase(tc_Id) || "OP_ID_336".equalsIgnoreCase(tc_Id)
                || "OP_ID_387".equalsIgnoreCase(tc_Id) || "OP_ID_143".equalsIgnoreCase(tc_Id) || "OP_ID_235".equalsIgnoreCase(tc_Id)
                || "OP_ID_329".equalsIgnoreCase(tc_Id) || "OP_ID_422".equalsIgnoreCase(tc_Id) || "OP_ID_426".equalsIgnoreCase(tc_Id)
                || "OP_ID_077".equalsIgnoreCase(tc_Id) || "OP_ID_324".equalsIgnoreCase(tc_Id) || "OP_ID_319".equalsIgnoreCase(tc_Id)
                || "OP_ID_328".equalsIgnoreCase(tc_Id) || "1671_SC02_TC01".equalsIgnoreCase(tc_Id) || "1671_SC02_TC02".equalsIgnoreCase(tc_Id)
                || "1671_SC02_TC03".equalsIgnoreCase(tc_Id) || "1671_SC02_TC04".equalsIgnoreCase(tc_Id) || "1671_SC02_TC11".equalsIgnoreCase(tc_Id)
                || "1671_SC04_TC08".equalsIgnoreCase(tc_Id))
        {

            String fProID = opSetupPage.getProcessID();
            String proNameForStats = fProID + "_" + processName;
            opSetupPage.selectOutputSetupOptions(processName, process, data, groups, purpose, outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectRecordTypes(splitRecords, process, filenames, recordType);
            if ("OP_ID_422".equalsIgnoreCase(tc_Id))
            {
                /*
                 * commMethods.verifyboolean(filenames.contains(opSumPage. getFirstRecordGroupName()), true); commMethods.verifyboolean(filenames
                 * .contains(opSumPage.getSecondRecordGroupName()), true);
                 */
                String label = opRecTypesPage.getTheLabel(recordType);
                commMethods.verifyString(label, "Record Group");
            }
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.clickResequenceAddButton(reseqReq);
            // opConfigPage.inputLayoutLocAndLoad(LayoutFile);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);

            opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate, reseqReq);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();
            if ("OP_ID_343".equalsIgnoreCase(tc_Id))
            {
            	 opConfigPage.handleTheDialogBoxAndClickContinue();
            }
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);

            if ("OP_ID_343".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(opSortOrderPage.fetchFieldSelectedForSorting(), sortFields.trim());
            }

            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.selectOutputSecondarySplit(fileSplitReq, splitField, secondarySplitReq, secondarySplitByFile, secondarySplitByRecord);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueBtnOP();
            if ("OP_ID_295".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(opSumPage.getFileIdentifierDC(), "N/A");
                commMethods.verifyString(opSumPage.getMaxBlankFieldDC(), "N/A");
                commMethods.verifyString(opSumPage.getMaxSingleFieldDC(), "N/A");
                commMethods.verifyString(opSumPage.getMaxUnknownFieldDC(), "N/A");
                commMethods.verifyString(opSumPage.getRunTimeADC(), "N/A");
                commMethods.verifyString(opSumPage.getRunTimeBDC(), "N/A");
            } else if ("OP_ID_294_TC10".equalsIgnoreCase(tc_Id) || "OP_ID_294_TC08".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(opSumPage.getFieldOfSort().contains(sortFields), true);
                commMethods.verifyString(opSumPage.getOrderOfSort().trim(), "Ascending");
            } else if ("OP_ID_157".equalsIgnoreCase(tc_Id))
            {
                projDashBoardPage.clickOutputTab();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            } else if ("OP_ID_077".equalsIgnoreCase(tc_Id))
            {
                // Validate that records in process input which have matched
                // dp_sequence_num with alias table only process further and
                // written to
                // fixed file.
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");

                commMethods.verifyInt(opStatsView.fetchTheCountOfOutputCappingViewFormed(), 1);
                commMethods.verifyboolean(opStatsView.getSeedingTableNameOP().contains("I"), true);
                commMethods.verifyboolean(opStatsView.getSeedingTableNameOP().contains("_OT_GPSEED"), true);
                commMethods.verifyLong(opStatsView.getSourceTableCountOP(), opStatsView.getOutputTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()), opStatsView.getSourceTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()), opStatsView.getOutputTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSeedingTableNameOP()), opStatsView.getSeedingTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSplitTableNameOP()), opStatsView.getSplitTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()),
                        commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()));
            } else if ("OP_ID_020".equalsIgnoreCase(tc_Id))
            {
                // Validate that records in process input which have matched
                // dp_sequence_num with alias table only process further and
                // written to
                // fixed file.
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                String[] procArr = process.split(":");
                String procNameStats = procArr[0] + "_" + procArr[1];

                commMethods.searchProcessOnDashboardAndViewStats(procNameStats);
                List<String> tableNames = opStatsView.fetchTheTableNames();
                opStatsView.clickToCloseStats();
                commMethods.clearFilter();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);

                commMethods.verifyLong(opStatsView.getCountOfRecordsSelectedForProcessing(),
                        opStatsView.getTheCountOfRecordSelectedForProcessingInGp(tableNames.get(0), tableNames.get(1)));
            } else if ("OP_ID_054".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                /*
                 * List<String> fetchedRecordDistribution = opStatsView.fetchTheRecordTypeDistribution(); for (String record :
                 * fetchedRecordDistribution) { commMethods.verifyboolean(recordType.contains(record), true); }
                 */
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()), opStatsView.getSourceTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()), opStatsView.getOutputTableCountOP());
            }

            else if ("OP_ID_150".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
            } else if ("OP_ID_078".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()), opStatsView.getSourceTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()), opStatsView.getOutputTableCountOP());
                // driver.switchTo().frame("sb-player");
                /*
                 * commMethods.verifyLong(commMethods.gRFOT_GP_CAP_AGE_CAPPED( opStatsView.getOutputTableNameOP()), commMethods.getRecordsFromGP
                 * (opStatsView.getSourceTableNameOP()));
                 */

            } else if ("OP_ID_079".equalsIgnoreCase(tc_Id))
            {
                String arr[] = dataToOutput.split(",");
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.gRFOT_GP_CAP_F_NAME(opStatsView.getOutputTableNameOP(), arr[1]),
                        commMethods.getRecordsFromGPForPPCode(opStatsView.getSourceTableNameOP(), movRecType));
            } else if ("OP_ID_081".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();

                commMethods.verifyString(opConfigPage.fetchTheErrorMessage(), "Error : Job run details for Input Process " + "\"" + process + "\""
                        + " selected for process " + fProID + ":" + processName + " do not exist.");

            } else if ("OP_ID_116".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "FAIL");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                commMethods.verifyboolean(
                        projDashBoardPage.getErrorMessageForGPSEED().contains("Application error: GP returned error message: psql:"), true);
                // driver.switchTo().frame("sb-player");
                // commMethods.verifyboolean(
                // projDashBoardPage.getErrorMessageForGPSEED(fProID).contains(
                // "ERROR MESSAGE - Application error: GP returned error message: psql"),
                // true);
            } else if ("OP_ID_120".equalsIgnoreCase(tc_Id))
            {
                /* opSumPage.clickSubmitButton(); */


                jobStackingPage.clickJobStackingSubmitButton();
                projDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(processName);
                String assignedId = jobStackingPage.getAssignedId();
                String process_Name = fProID + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(process_Name);

                // jobStackingPage.selectProcessFromDropdown("SH128:Chk_record_cnt");
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(process_Name);
                // processList.add("SH128:Chk_record_cnt");
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(30000);
                commMethods.verifyString(projDashBoardPage.verifyProcess(assignedId), "PASS");
                // projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                Long recordCount = opStatsView.clickToViewStatsOfOpGPCapItem(assignedId, fProID);
                // To Do
                // need to add methd to open stats for op process
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP())
                        - commMethods.getRecordsFromGP_DNS_dnstag_D(opStatsView.getSourceTableNameOP()), recordCount);
            } else if ("OP_ID_122".equalsIgnoreCase(tc_Id))
            {
                projDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(processName);
                String assignedId = jobStackingPage.getAssignedId();
                String process_Name = fProID + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(process_Name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(process_Name);
                processList.add(process);
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);

                jobStackingPage.clickJobStackingSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(assignedId), "PASS");
                Long recordCount = opStatsView.clickToViewStatsOfOpGPCapItem(assignedId, fProID, groups);
                // projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // To Do
                // need to add methd to open stats for op process
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP_with_Grp_Name(opStatsView.getSourceTableNameOP(), groups), recordCount);
            } else if ("OP_ID_124".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Output Review the information below, and then click 'Submit' or 'Back'.");
            } else if ("OP_ID_130".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                opHomePage.selectDuplicateOP();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectEditOP();
                opSetupPage.Ele_ProcessName.clear();
                opSetupPage.Ele_ProcessName.sendKeys(newProcessName);
                opSetupPage.clickContinueButton();
                opRecTypesPage.clickContinueButton();
                String[] arrAlias = aliasTable.split(",");
                commMethods.verifyString(opAliasPage.getAliasTableSelected(), arrAlias[0]);
                commMethods.verifyString(opAliasPage.getAliasProvided(), arrAlias[1]);
            } else if ("OP_ID_124".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Summary: Output Review the information below, and then click 'Submit' or 'Back'.");
            } else if ("OP_ID_130".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                opHomePage.selectDuplicateOP();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectEditOP();
                opSetupPage.Ele_ProcessName.clear();
                opSetupPage.Ele_ProcessName.sendKeys(newProcessName);
                opSetupPage.clickContinueButton();
                opRecTypesPage.clickContinueButton();
                String[] arrAlias = aliasTable.split(",");
                commMethods.verifyString(opAliasPage.getAliasTableSelected(), arrAlias[0]);
                commMethods.verifyString(opAliasPage.getAliasProvided(), arrAlias[1]);
            } else if ("OP_ID_141".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(opSumPage.isFilterGroupDisplayed(), true);
            } else if ("OP_ID_144".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                Thread.sleep(3000);
                opStatsView.click_DC_ANALYZE_Report();
                driver.switchTo().defaultContent();
                commMethods.verifyString(opStatsView.getTheTitleFromDCReport(), "Job Stats Counters");

            } else if ("OP_ID_161".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickDataProcessingTab();
                dpHomePage.clickRandomNthButton();
                rnPage.processNameField("TEST");
                rnPage.selectProcessField(fProID + ":" + processName);
                rnPage.selectDataField(outputTableName);
                // rnPage.clickSaveButton();

                commMethods.verifyString(commMethods.getTheSelectedOption(), outputTableName);
            } else if ("OP_ID_208".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()),
                        commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()));
            } else if ("OP_ID_245".equalsIgnoreCase(tc_Id) || "OP_ID_260".equalsIgnoreCase(tc_Id) || "OP_ID_280".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()),
                        commMethods.gRF_CAP_CID_AAAAA(opStatsView.getOutputTableNameOP()));
            } else if ("OP_ID_334".equalsIgnoreCase(tc_Id) || "OP_ID_335".equalsIgnoreCase(tc_Id) || "OP_ID_337".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyboolean(opStatsView.isMaskScramLinItemPresent(), true);
            } else if ("OP_ID_338".equalsIgnoreCase(tc_Id) || "OP_ID_339".equalsIgnoreCase(tc_Id) || "OP_ID_340".equalsIgnoreCase(tc_Id)
                    || "OP_ID_336".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(proNameForStats);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()), opStatsView.getCountofMaskScramRec());
            }

            else if ("OP_ID_356".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyString(commMethods.isResequence_ColumnPresent(opStatsView.getOutputTableNameOP()), "RE_SEQUENCE_NUM");
            } else if ("OP_ID_372".equalsIgnoreCase(tc_Id) || "OP_ID_382".equalsIgnoreCase(tc_Id) || "OP_ID_383".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSourceTableNameOP()), opStatsView.getSourceTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()), opStatsView.getOutputTableCountOP());
                // commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSeedingTableNameOP()),
                // opStatsView.getSeedingTableCountOP());
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getSplitTableNameOP()), opStatsView.getSplitTableCountOP());
            } else if ("OP_ID_376".equalsIgnoreCase(tc_Id) || "OP_ID_386".equalsIgnoreCase(tc_Id) || "OP_ID_387".equalsIgnoreCase(tc_Id)
                    || "OP_ID_388".equalsIgnoreCase(tc_Id))
            {

                projDashBoardPage.clickOutputTab();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectDuplicateOP();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectSummaryOP();
                opSumPage.clickSubmitButton();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.SUBMITTED.name().trim());
                opHomePage.selectDuplicateOP();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectEditOP();
                commMethods.verifyString(projDashBoardPage.getPageTitle(),
                        "Output Setup Complete the required information and then click 'Continue'");
            } else if ("OP_ID_138".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // driver.switchTo().frame("sb-player");
                commMethods.verifyboolean(opStatsView.isCappedViewFormedInStats(), true);
                commMethods.verifyLong(commMethods.getRecordsFromGP(opStatsView.getOutputTableNameOP()), opStatsView.getOutputTableCountOP());
            } else if ("OP_ID_139".equalsIgnoreCase(tc_Id) || "OP_ID_133".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                // commMethods.verifyString(projDashBoardPage.verifyProcess(fProID),
                // "PASS");
                projDashBoardPage.clickOutputTab();
                opHomePage.selectDuplicateOP();
                opHomePage.selectSummaryOP();
                String procName = opSumPage.processNameInSummary();
                String[] procArr = procName.split(":");

                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(procArr[0].trim()), "PASS");
                Thread.sleep(3000);
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                // projDashBoardPage.clickTreeV2statsViewForChrome("OP182");
                String opTableName = opStatsView.getOutputTableNameOP();
                List<String> recordTypesListFromGp = opStatsView.fetchTheFailCode(opTableName);
                List<String> recordList = opStatsView.fetchTheRecordDistributionInstats(recordTypesListFromGp);
                List<String> recordListFromGp = opStatsView.fetchTheRecordBasedOnFailCode(opTableName);
                for (String record : recordList)
                {
                    Assert.assertTrue(recordListFromGp.contains(record));
                }
            } else if ("OP_ID_143".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickDataProcessingTab();
                dpHomePageFL.clickFilteringButton();
                filterPage.inputProcessName("TEST");
                filterPage.selectProcess(fProID + ":" + processName);
                filterPage.selectData(outputTableName);
                commMethods.verifyboolean(opConfigPage.isTablePresentInAvaliableFields(outputTableName), true);

            } else if ("OP_ID_235".equalsIgnoreCase(tc_Id))
            {
                String[] arrSort = sortFields.split(",");
                commMethods.verifyString(opSumPage.getFirstColumnHeaderSortTable(), "Fields");
                commMethods.verifyString(opSumPage.getSecondColumnHeaderSortTable(), "Order");
                commMethods.verifyboolean(opSumPage.getFirstFieldSelectedForSort().contains(arrSort[0]), true);
                // commMethods.verifyboolean(opSumPage.getSecondFieldSelectedSort().contains(arrSort[1]),
                // true);
            } else if ("OP_ID_319".equalsIgnoreCase(tc_Id) || "OP_ID_324".equalsIgnoreCase(tc_Id) || "OP_ID_328".equalsIgnoreCase(tc_Id))
            {
                String[] recordArr = recordType.split(";");
                String[] sortFieldArr = sortFields.split(",");
                if ("OP_ID_328".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyInt(opSumPage.getTheCountRowsFormedForSortOptions(), sortFieldArr.length);
                }
                if ("OP_ID_319".equalsIgnoreCase(tc_Id) || "OP_ID_324".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyInt(opSumPage.getTheCountColumnsFormedForSortOptions(), recordArr.length * 2);
                }

            }

            else if ("OP_ID_303".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                opHomePage.selectDuplicateOP();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectEditOP();
                opSetupPage.clickContinueButton();
                opRecTypesPage.clickContinueButton();
                opAliasPage.clickFullForwardBtn();
                commMethods.verifyboolean(opAliasPage.isPopupPresent(), true);
            } else if ("OP_ID_329".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(opSumPage.isRecordNotSortDisplayed(), true);
            }
            // } else if ("OP_ID_422".equalsIgnoreCase(tc_Id))
            // {
            // /*
            // *
            // commMethods.verifyboolean(filenames.contains(opSumPage.getFirstRecordGroupName()),
            // true);
            // *
            // commMethods.verifyboolean(filenames.contains(opSumPage.getSecondRecordGroupName()),
            // true);
            // */
            // List<String> fetchedGrpList =
            // opSumPage.getTheRecordGroupsIncluded();
            // for (String fetchedGrp : fetchedGrpList)
            // {
            // commMethods.verifyboolean(groups.contains(fetchedGrp), true);
            // }
            // }
            else if ("OP_ID_426".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

                String[] procArr = process.split(":");
                String procNameStats = procArr[0] + "_" + procArr[1];

                commMethods.searchProcessOnDashboardAndViewStats(procNameStats);
                String[] grpArr = groups.split(",");
                List<String> grpList = Arrays.asList(grpArr);
                Long recordCount = opStatsView.getTheTotalCountOfRecordsInGroups(grpList);
                opStatsView.clickToCloseStats();
                commMethods.clearFilter();
                commMethods.searchProcessOnDashboardAndViewStats(fProID);
                commMethods.verifyLong(recordCount, opStatsView.getOutputTableCountOP());
            }
            // added for story-->CF2-1671

            else if ("1671_SC02_TC01".equalsIgnoreCase(tc_Id) || "1671_SC02_TC02".equalsIgnoreCase(tc_Id) || "1671_SC02_TC03".equalsIgnoreCase(tc_Id)
                    || "1671_SC02_TC04".equalsIgnoreCase(tc_Id))
            {
                opHomePage.clickOutputTab();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectSummaryOP();
                Thread.sleep(1500);
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "FAIL");
                String status = opStatsView.getTheStatusAndViewErrorStats(fProID);
                commMethods.verifyString(status, "FAILED");
                commMethods.verifyString(opStatsView.getTheErrorMessageFromStats(),
                        "GP returned error message: Error while processing Output: The Output process is attempting to create more than 20 files. Please review the Process configuration and contact support if you cannot resolve the issue.");
            } else if ("1671_SC02_TC11".equalsIgnoreCase(tc_Id) || "1671_SC04_TC08".equalsIgnoreCase(tc_Id))
            {
                opHomePage.clickOutputTab();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
                opHomePage.selectSummaryOP();
                Thread.sleep(3500);
                opSumPage.clickSubmitButton();
                Thread.sleep(3500);
                // commMethods.verifyString(opHomePageetStatusOP(),
                // StatusEnum.SUBMITTED.name().trim());
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

            }
        }

        // added for mdb date option added in op config page
        if ("OP_ID_427".equalsIgnoreCase(tc_Id) || "OP_ID_429".equalsIgnoreCase(tc_Id) || "OP_ID_430".equalsIgnoreCase(tc_Id)
                || "OP_ID_431".equalsIgnoreCase(tc_Id) || "OP_ID_432".equalsIgnoreCase(tc_Id) || "OP_ID_433".equalsIgnoreCase(tc_Id)
                || "OP_ID_434".equalsIgnoreCase(tc_Id) || "OP_ID_435".equalsIgnoreCase(tc_Id) || "OP_ID_446".equalsIgnoreCase(tc_Id)
                || "OP_ID_440".equalsIgnoreCase(tc_Id) || "OP_ID_441".equalsIgnoreCase(tc_Id) || "OP_ID_436".equalsIgnoreCase(tc_Id)
                || "OP_ID_439".equalsIgnoreCase(tc_Id) || "OP_ID_437".equalsIgnoreCase(tc_Id) || "OP_ID_445".equalsIgnoreCase(tc_Id)
                || "OP_ID_444".equalsIgnoreCase(tc_Id) || "OP_ID_443".equalsIgnoreCase(tc_Id) || "OP_ID_442".equalsIgnoreCase(tc_Id))
        {
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();

            // testcase OP_ID_427
            if ("OP_ID_427".equalsIgnoreCase(tc_Id))
            {
                boolean isAddMDBDatePresent = opConfigPage.checkMDBDateIsPresentInToolBar();
                commMethods.verifyboolean(isAddMDBDatePresent, true);
                // LOGGER.info("Validated that Toolbar button Add MDB Date added to the Output Layout builder grid ");
            }
            // opConfigPage.seeding(seeding);
            Date date1 = new Date();
            inputDate = dateFormat.format(date1);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange);
            // testcase op_id_429
            if ("OP_ID_429".equalsIgnoreCase(tc_Id))
            {

                boolean isEnabled = opConfigPage.checkMDBDateIsEnabled();
                commMethods.verifyboolean(isEnabled, true);

                // LOGGER.info("Validated that the button ADD MDB DATE will only be enabled when the current hierarchy contains DM in the hierarchy");
            }
            // testcase op_id_429 & op_id_431
            else if ("OP_ID_430".equalsIgnoreCase(tc_Id) || "OP_ID_431".equalsIgnoreCase(tc_Id))
            {

                boolean isDisabled = opConfigPage.checkMDBDateIsEnabled();
                commMethods.verifyboolean(isDisabled, false);

                // LOGGER.info("Validate that the button Add MDB Date will only be enabled when the current hierarchy contains DM in the hierarchy ");
            } else if ("OP_ID_432".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.selectTheFieldAndClickMDBAddButton();
                // List<String> rowDetailsList =
                // opConfigPage.fetchTheRowDetails();
                String[] fetchedFields = opConfigPage.getTheNameAndCustomerNameOfTheFieldAddedInTheGrid();
                String feildName = fetchedFields[0];
                String customerName = fetchedFields[1];
                commMethods.verifyContainsString(feildName, "MDB_DATE");
                commMethods.verifyString(customerName, "MDB_DATE");
            } else if ("OP_ID_433".equalsIgnoreCase(tc_Id) || "OP_ID_434".equalsIgnoreCase(tc_Id))
            {
                String fetchedField = opConfigPage.clickMDBAddButtonAndCheckTheGrid();
                commMethods.verifyContainsString(fetchedField, "MDB_DATE");
                if ("OP_ID_434".equalsIgnoreCase(tc_Id))
                {
                    String[] aliasArr = aliasTable.split(",");

                    commMethods.verifyboolean(fetchedField.startsWith(aliasArr[1]), false);
                }
            } else if ("OP_ID_435".equalsIgnoreCase(tc_Id))
            {
                String field = opConfigPage.clickMDBAddButtonAndCheckTheGrid();
                commMethods.verifyContainsString(field, "MDB_DATE");
                opConfigPage.clickMDBAddButton();
                Thread.sleep(3500);
                // driver.switchTo().alert();
                String alertMsg = opConfigPage.fetchTheAlertMessage();
                if (alertMsg != null)
                {
                    commMethods.verifyString(alertMsg, "MDB_DATE Field already exist in the layout.");
                }
            } else if ("OP_ID_446".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.clickMDBAddButton();
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);

                opConfigPage.clickContinueButton();

                opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

                opMoveStPage.clickContinueButton(process);
                if (!"OFF".equalsIgnoreCase(sortReq))
                {
                    opSortOrderPage.clickSortRequired(sortReq, purpose);
                    opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                }
                opSortOrderPage.clickContinueButton(purpose);
                // opSortOrderPage.selectSortField(sortFields,purpose);
                // opFileNameSplitPage.StartingFileNumField(FileNum);
                opFileNameSplitPage.clickFileSplitReq();
                boolean result = opFileNameSplitPage.IsMDBDatePresent();
                commMethods.verifyboolean(result, false);
                // opFileNameSplitPage.selectOutputSplit(fileSplitReq,
                // grpNum, numOfFiles, splitField);
            }

            else if ("OP_ID_440".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.clickMDBAddButton();

                Map<String, String> rowDetailsMap = opConfigPage.fetchTheRowDetails();
                String fieldLength = rowDetailsMap.get("fieldLength");
                commMethods.verifyString(fieldLength, "1");
                String dataType = rowDetailsMap.get("dataType");
                commMethods.verifyString(dataType, "DATE");
                String justification = rowDetailsMap.get("justification");
                commMethods.verifyString(justification, "Left");
                String padding = rowDetailsMap.get("padding");
                commMethods.verifyString(padding, "Blanks");

            } else if ("OP_ID_441".equalsIgnoreCase(tc_Id))
            {
                opConfigPage.clickMDBAddButton();
                String value = opConfigPage.checkIsDisabled();
                System.out.println("value >>>>" + value);

            }

            else
            {
                if ("OP_ID_436".equalsIgnoreCase(tc_Id))
                {
                    opConfigPage.clickMDBAddButton();
                    opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                    opConfigPage.clickToCalculateStartEndPosition();
                    // String[] positionArr =
                    // opConfigPage.fetchThePositionDetails();
                    opConfigPage.clickContinueButton();

                    opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

                    opMoveStPage.clickContinueButton(process);
                    if (!"OFF".equalsIgnoreCase(sortReq))
                    {
                        opSortOrderPage.clickSortRequired(sortReq, purpose);
                        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                    }
                    opSortOrderPage.clickContinueButton(purpose);
                    // opSortOrderPage.selectSortField(sortFields,purpose);
                    // opFileNameSplitPage.StartingFileNumField(FileNum);
                    opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
                    opFileNameSplitPage.clickContinueButton();
                    opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
                    opDataChckPage.clickContinueButton();
                    projDashBoardPage.clickOutputTab();
                    opHomePage.selectEditOP();
                    opSetupPage.selectProcessField(newProcess);
                    opSetupPage.selectDataField(newData);
                    opSetupPage.clickContinueButton();
                    opSetupPage.handleConfirmWindow();
                    opRecTypesPage.clickToCheckWarning();
                    opRecTypesPage.clickContinueButton();
                    // String[] tableArr = aliasTable.split(";");
                    opAliasPage.removeAliasTables(aliasTable);
                    opAliasPage.inputAliasTables(newAliasTable);
                    opAliasPage.clickContinueButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProID),
                    "PASS");
                    String statsName = fProID + "_" + processName;
                    projDashBoardPage.viewStats(statsName);                    
                    commMethods.verifyString(opConfigPage.fetchTheErrorMessage(),
                            "Error: No Credit Files were accessed using Data Menu for the selected input. Therefore, an MDB Date cannot be determined. The MDB_DATE field must be removed from the layout");

                }

                if ("OP_ID_437".equalsIgnoreCase(tc_Id) || "OP_ID_439".equalsIgnoreCase(tc_Id))
                {
                    opConfigPage.clickMDBAddButton();
                    opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                    opConfigPage.clickToCalculateStartEndPosition();
                    String[] positionArr = opConfigPage.fetchThePositionDetails();
                    opConfigPage.clickContinueButton();

                    opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

                    opMoveStPage.clickContinueButton(process);
                    if (!"OFF".equalsIgnoreCase(sortReq))
                    {
                        opSortOrderPage.clickSortRequired(sortReq, purpose);
                        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                    }
                    opSortOrderPage.clickContinueButton(purpose);
                    // opSortOrderPage.selectSortField(sortFields,purpose);
                    // opFileNameSplitPage.StartingFileNumField(FileNum);
                    opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
                    opFileNameSplitPage.clickContinueButton();
                    opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
                    opDataChckPage.clickContinueButton();
                    opSumPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                     commMethods.verifyString(projDashBoardPage.verifyProcess(fProID),
                     "PASS");
                     String statsName = fProID + "_" + processName;
                     //projDashBoardPage.viewStats(statsName);
                    projDashBoardPage.clickTreeV2statsViewForChrome(statsName);
                    String opFilePath = opStatsView.fetchTheOutputFilePath();

                    boolean result = opStatsView.readFileAndFetchTheResult(opFilePath, Integer.parseInt(positionArr[0]),
                            Integer.parseInt(positionArr[1]));
                    commMethods.verifyboolean(result, true);
                }

                if ("OP_Id_445".equalsIgnoreCase(tc_Id) || "OP_Id_444".equalsIgnoreCase(tc_Id) || "OP_Id_443".equalsIgnoreCase(tc_Id)
                        || "OP_Id_442".equalsIgnoreCase(tc_Id))
                {

                    opConfigPage.clickMDBAddButton();
                    opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                    opConfigPage.clickToCalculateStartEndPosition();

                    opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                    opConfigPage.clickContinueButton();

                    opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

                    opMoveStPage.clickContinueButton(process);
                    if (!"OFF".equalsIgnoreCase(sortReq))
                    {
                        opSortOrderPage.clickSortRequired(sortReq, purpose);
                        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                    }

                    // opSortOrderPage.selectSortField(sortReq, sortFields,
                    // purpose);
                    opSortOrderPage.clickContinueButton(purpose);
                    // opFileNameSplitPage.StartingFileNumField(FileNum);
                    opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
                    opFileNameSplitPage.clickContinueButton();
                    opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
                    opDataChckPage.clickContinueButton();
                    opSumPage.clickSubmitButton();
                    projDashBoardPage.clickHomeTab();
                    commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                    String statsName = fProID + "_" + processName;
                    projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                    String opTableName = opStatsView.getOutputTableNameOP();
                    List<String> mdbDateValues = opStatsView.fetchTheValuesOfMDBDateColumn(opTableName);
                    if ("OP_Id_445".equalsIgnoreCase(tc_Id))
                    {
                        for (String mdbDate : mdbDateValues)
                        {
                            commMethods.verifyString(mdbDate, "2017XX25");
                        }
                    } else if ("OP_Id_444".equalsIgnoreCase(tc_Id))
                    {
                        for (String mdbDate : mdbDateValues)
                        {
                            commMethods.verifyboolean(opStatsView.isDigitsScrambled(mdbDate, "20170425"), true);
                            // Assert.assertFalse(mdbDate.equalsIgnoreCase("20170530"));
                        }
                    } else if ("OP_Id_443".equalsIgnoreCase(tc_Id))
                    {
                        String datePattern = "\\d{1,2}-\\d{1,2}-\\d{4}";
                        for (String mdbDate : mdbDateValues)
                        {
                            boolean isMatched = mdbDate.matches(datePattern);
                            commMethods.verifyboolean(isMatched, true);
                        }
                    } else if ("OP_Id_442".equalsIgnoreCase(tc_Id))
                    {
                        for (String mdbDate : mdbDateValues)
                        {
                            commMethods.verifyString(mdbDate, "20170425");
                        }
                    }
                }

            }

        }
    }

    @Test(dataProvider = "op_CBA")
    public void opProcessVerification(String tc_Id, String testRun, String TC, String desc, String copyProject, String copyProcessName, String processName,
    String process, String data, String groups, String purpose, String outputTableName, String creatOrExistLayout, String projExisLay,
    String exisLayName, String splitRecords, String filenames, String recordType, String aliasTable, String seeding, String reseqReq,
    String reSeqNum, String LayoutName, String fileFormat, String delimiter, String crLFOptions, String layoutTableName,
    String layoutFieldsToSelect, String layoutFieldsToUpdate, String fieldToMaskOrScrammble, String maskScrambleFormatMaskValues,
    String moveStatReq, String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, String FileNum,
    String fileSplitReq, String grpNum, String numOfFiles, String splitField, String secondarySplitReq, String secondarySplitByFile,
    String secondarySplitByRecord, String dataCheck, String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown,
    String runTimeB, String newProcessName, String newProcess, String newData, String newAliasTable, String submitRequired,
    ITestContext testContext)
            throws Exception
    {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        /*
         * if ("OP_ID_112".equalsIgnoreCase(tc_Id) || "OP_ID_111".equalsIgnoreCase(tc_Id) || "OP_ID_114".equalsIgnoreCase(tc_Id)) {
         * driver.navigate().to(
         * "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/project/dashboardtree?projectNumber=6000001&purgedJobs=&jqxMode=&purgedJobs=&projectNumber=6000001"
         * ); projDashBoardPage.clickTreeV2statsView("OP172"); String inputTable = opStatsView.getSourceInputTableName(); String outputTable =
         * opStatsView.getOutputTableNameOP(); if("OP_ID_112".equalsIgnoreCase(tc_Id)) { // String inputTable = opStatsView.getSourceInputTableName();
         * // String outputTable = opStatsView.getOutputTableNameOP(); List<String> records=commMethods.getRecords(inputTable);
         * commMethods.verifyboolean(opStatsView.isDigitsScrambled(commMethods. getRecordFromDp_s(outputTable,records.get(0)),records.get(1)),true); }
         */

        /*
         * if ("OP_ID_025".equalsIgnoreCase(tc_Id)) { driver.navigate().to(
         * "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/project/dashboardtree?projectNumber=6000001&purgedJobs=&jqxMode=&purgedJobs=&projectNumber=6000001"
         * ); projDashBoardPage.clickHomeTab(); projDashBoardPage.clickTreeV2statsView("OP68"); // projDashBoardPage.clickTreeV2statsView(fProID);
         * String[] recordTypeArr= recordType.split(";"); commMethods.verifyInt(opStatsView .getTheCountOfFilesFormed(),recordTypeArr.length); }
         */
        /*
         * if ("OP_ID_156".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); // opConfigPage.seeding(seeding); Date date = new Date();
         * inputDate = dateFormat.format(date); opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat);
         * opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.seeding(process, seeding, purpose); opConfigPage.selectResequenceReq_CB(reseqReq,
         * reSeqNum); opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
         * opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
         * opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption (maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
         * opConfigPage.clickContinueButton(); opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process,
         * layoutFieldsToSelect); opMoveStPage.clickContinueButton(process); if (!"OFF".equalsIgnoreCase(sortReq)) {
         * opSortOrderPage.clickSortRequired(sortReq, purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose); } //
         * opSortOrderPage.selectSortField(sortFields,purpose); // opFileNameSplitPage.StartingFileNumField(FileNum);
         * opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField); opFileNameSplitPage.clickContinueButton();
         * opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
         * opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton(); opHomePage.selectDuplicateOP(); opHomePage.selectEditOP();
         * driver.navigate().to(
         * "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/edit-output-process?projectNumber=6000001&opId=3453280" );
         * opSetupPage.clickContinueButton();opRecTypesPage.removeSelectedFile( filenames.split(",")[1]); opRecTypesPage.clickContinueButton();
         * opConfigPage.clickContinueButton(); opMoveStPage.clickContinueButton(process); String errorMsg = opConfigPage.fetchTheErrorMessage();
         * commMethods.verifyboolean(errorMsg.contains( "which are no longer available. Please edit the Record Type selections." ), true); }
         */
        /*
         * if ("OP_ID_071".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); Date date = new Date(); inputDate = dateFormat.format(date);
         * opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions);
         * opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum); opConfigPage.seeding(process, seeding, purpose);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
         * opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout); opConfigPage.clickContinueButton();
         * opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process); opMoveStPage.clickContinueButton(process);
         * opSortOrderPage.clickSortRequired(sortReq, purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
         * opSortOrderPage.clickContinueButton(purpose); //opFileNameSplitPage.StartingFileNumField(FileNum);
         * opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField); opFileNameSplitPage.clickContinueButton();
         * opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
         * opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton(); Thread.sleep(2500);
         * commMethods.verifyString(opHomePage.GetStatusOP().trim(), StatusEnum.SUBMITTED.name()); opHomePage.selectSummaryOP(); driver.navigate().to(
         * "http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/outputSummary?projectNumber=6000001&opId=3439436&summaryFlag=Y" );
         * Thread.sleep(2500); String[] proceNameArr=opSumPage.processInSumry().split(":"); commMethods.verifyString
         * (proceNameArr[0]+":"+proceNameArr[1],process); // commMethods.verifyString(opSumPage.jobInSumry(),);
         * commMethods.verifyString(opSumPage.dataInSumry(),data); commMethods.verifyString (opSumPage.tableUsedForOutput(),outputTableName); String[]
         * aliasArr=aliasTable.split(","); commMethods.verifyString(opSumPage.aliasUsedForOutputTable(), aliasArr[1]);
         * commMethods.verifyString(opSumPage.dataCheckPerformed(), "Not Performed"); //commMethods.verifyString(opSumPage.layoutName(),inputDate);
         * List<String> recordList=new ArrayList<String>(); recordList=opSumPage.selectedRecordTypeAndFileName(); for(String record:recordList) {
         * Assert.assertTrue(record.contains(recordType)||record .contains(filenames)); } ///commMethods.verifyString(opSumPage.selectedRecordType(),
         * ""); commMethods.verifyString(opSumPage.selectedSortOptionMatch(), "Records will not be sorted.");
         * //commMethods.verifyString(opSumPage.selectedfileName(), ""); commMethods.verifyString(opSumPage.getFileFormat(),fileFormat); String[]
         * purposeArr=purpose.split(""); commMethods.verifyString(opSumPage.getFilePurpose(), purposeArr[0]+"_"+purposeArr[1]); }
         */

        if ("OP_ID_008".equalsIgnoreCase(TC))
        {

            /*
             * projDashBoardPage.clickInputDependancyPopupOk(); projDashBoardPage.clickOutputTab(); module.clickOnEdit();
             * testContext.setAttribute("WebDriver", driver); opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data);
             * opSetupPage.clickContinueButton(); opRecTypesPage.clickContinueButton(); opAliasPage.inputAliasTables(aliasTable);
             * opAliasPage.clickContinueButton(); opConfigPage.selectPerformSeeding(); opConfigPage.clickContinueButton();
             * opMoveStPage.clickContinueButton(process); opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
             * opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField); // opFileNameSplitPage.selectSecondarySplitOptions
             * (secondarySplitReq, secSplitOption); opFileNameSplitPage.clickContinueButton(); opDataChckPage.selectDataCheckCheckbox(fileFormat,
             * purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB); opDataChckPage.clickContinueButton();
             */
            projDashBoardPage.clickHomeTab();

            if (!"NA".equalsIgnoreCase(copyProject) && !"NA".equalsIgnoreCase(copyProcessName))
            {
                commMethods.searchProjforCopy(copyProject);

                projDashBoardPage.selectCopyPrevProjProcName(copyProcessName);
                projDashBoardPage.clickCopySelectBtn();

            }

            projDashBoardPage.clickOutputTab();
            opHomePage.selectEditOP();
            opSetupPage.clickContinueButton();
            opRecTypesPage.clickContinueButton();
            opAliasPage.clickContinueButton();
            opConfigPage.clickContinueButton();
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickForwardButton();
            // if (opFileNameSplitPage.isSecondarySplitSelected() == true)
            // {
            //
            // if (true ==
            // opFileNameSplitPage.isSecondarySplitDivideFileSelected())
            // {
            // commMethods.verifyString(opFileNameSplitPage.getSecSplitGroupsSelected(),
            // secSplitOption.split(",")[1]);
            // }
            //
            // if (true ==
            // opFileNameSplitPage.isSecondarySplitRecordsFileSelected())
            // {
            // commMethods.verifyString(opFileNameSplitPage.getSecSplitRecordsSelected(),
            // secSplitOption.split(",")[1]);
            // }
            // }
            commMethods.verifyboolean(opFileNameSplitPage.isSplitByFieldChecked(), true);
            commMethods.verifyboolean(opFileNameSplitPage.isSecondarySplitChecked(), true);
        }
        if ("OP_ID_013".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            commMethods.verifyboolean(opRecTypesPage.isAddFileButtonDisabled(), true);
            /*
             * opRecTypesPage.selectSplitRecord(splitRecords, process); opRecTypesPage.createFilesWithName(filenames);
             * opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton(); opAliasPage.inputAliasTables(aliasTable);
             * opAliasPage.clickContinueButton(); opConfigPage.seeding(process, seeding, purpose); Date date = new Date(); inputDate =
             * dateFormat.format(date); opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat);
             * opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum); opConfigPage.seeding(process,
             * seeding, purpose); // //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); Thread.sleep(2000);
             * opConfigPage.updateFieldValuesPerField(layoutFieldsChange, creatOrExistLayout); opConfigPage.clickContinueButton();
             * opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process); opMoveStPage.clickContinueButton(process);
             * opSortOrderPage.clickSortRequired(sortReq, purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
             * opFileNameSplitPage.StartingFileNumField(FileNum); opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
             * opFileNameSplitPage.clickSecondarySplitReq(secondarySplitReq); opFileNameSplitPage.clickContinueButton();
             * opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
             * opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton(); projDashBoardPage.clickHomeTab();
             * commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
             */
        }

        /*
         * if ("OP_ID_061".equalsIgnoreCase(tc_Id) || "OP_ID_062".equalsIgnoreCase(tc_Id)) { // will always edit this particular process for layout
         * load // validations (OP98) module.editSpecificProcess("OP98"); opSetupPage.clickContinueButton(); opRecTypesPage.clickContinueButton();
         * opAliasPage.clickContinueButton(); commMethods.verifyboolean(opConfigPage .Ele_PerformSeeding.isSelected(), true);
         * commMethods.verifyboolean(opConfigPage .Ele_PerformSeeding.isEnabled(), true); }
         */
        if ("OP_ID_019".equalsIgnoreCase(tc_Id) || "OP_ID_045".equalsIgnoreCase(tc_Id) || "OP_ID_049".equalsIgnoreCase(tc_Id)
                || "OP_ID_047".equalsIgnoreCase(tc_Id) || "OP_ID_090".equalsIgnoreCase(tc_Id) || "OP_ID_061".equalsIgnoreCase(tc_Id)
                || "OP_ID_062".equalsIgnoreCase(tc_Id) || "OP_ID_117".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

            if ("OP_ID_061".equalsIgnoreCase(tc_Id) || "OP_ID_062".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isSelected(), true);
                commMethods.verifyboolean(opConfigPage.Ele_PerformSeeding.isEnabled(), true);
            } else
            {
                opConfigPage.seeding(process, seeding, purpose);
                /*
                 * // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
                 * creatOrExistLayout); opConfigPage.deselectPerformSeeding(); opConfigPage.clickContinueButton();
                 * opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process); opMoveStPage.clickContinueButton(process); if
                 * ("OP_ID_090".equalsIgnoreCase(tc_Id)) { commMethods.verifyString(projDashBoardPage.getPageTitle(),
                 * "Sort Order Complete the required information below, and then click 'Save' or 'Continue'." ); } if
                 * (!"OFF".equalsIgnoreCase(sortReq)) { opSortOrderPage.clickSortRequired(sortReq, purpose);
                 * opSortOrderPage.selectSortField(sortFields, sortReq, purpose); } opSortOrderPage.clickContinueButton(purpose);
                 * opFileNameSplitPage.StartingFileNumField(FileNum); opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles,
                 * splitField); opFileNameSplitPage.clickContinueButton(); opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck,
                 * fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB); opDataChckPage.clickContinueButton();
                 */
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
                opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
                opConfigPage.clickContinueButton();
                // /opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType,
                // dataToOutput, process);
                opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process, layoutFieldsToSelect);
                opMoveStPage.clickContinueButton(process);
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                opSortOrderPage.clickContinueButton(purpose);
                // opFileNameSplitPage.StartingFileNumField(FileNum);
                opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
                opFileNameSplitPage.selectOutputSecondarySplit(fileSplitReq, splitField, secondarySplitReq, secondarySplitByFile,
                        secondarySplitByRecord);
                opFileNameSplitPage.clickContinueButton();
                opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
                opDataChckPage.clickContinueBtnOP();
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                long sourceTableCount = opStatsView.getSourceTableCountOP();
                String opTableName = opStatsView.getOutputTableNameOP();
                String inputTable = opStatsView.getSourceInputTableName();
                String[] dataToOuptut = dataToOutput.split(",");
                String[] opLayoutField = layoutField.split("\\.");
                if ("OP_ID_019".equalsIgnoreCase(tc_Id) || "OP_ID_117".equalsIgnoreCase(tc_Id))
                {
                    long tableCount = greenPlumConnect.getGPCount(opTableName);
                    commMethods.verifyLong(tableCount, sourceTableCount);

                    HashMap<String, String> col1 = opStatsView.getCol1Values(opTableName, dataToOuptut[1], opLayoutField[0]);

                    commMethods.verifyboolean(opStatsView.verifyMoveStament(col1), true);
                }
                if ("OP_ID_045".equalsIgnoreCase(tc_Id) || "OP_ID_049".equalsIgnoreCase(tc_Id))
                {

                    /*
                     * List<String> finalList = new ArrayList<>(); String recordsSplit[] = movRecType.split(","); for (String rec : recordsSplit) {
                     * List<String> rejMoves = opStatsView.getdpSeqNumbersFromHeaderTableForRej (inputTable, rec); List<String> accMoves =
                     * opStatsView.getdpSeqNumbersFromHeaderTableForAcc (inputTable, rec); finalList.addAll(rejMoves); finalList.addAll(accMoves); }
                     * List<String> movFieldValue = opStatsView.getMoveFieldValueForSelectedDpSeqNum (opLayoutField[0], opTableName, finalList); for
                     * (String val : movFieldValue) { commMethods.verifyboolean(val.equals(dataToOuptut[1]), true);
                     * commMethods.verifyboolean(val.equals("99"), false); }
                     */
                    commMethods.verifyboolean(opStatsView.isMoveStatementCorrectlyPerformed(opTableName), true);
                }

                if ("OP_ID_047".equalsIgnoreCase(tc_Id))
                {

                    String seqNum = opStatsView.getRandomDpSequenceNum(opTableName);
                    List<String> header = opStatsView.getRowColumnVauesForSelectedDpSeqNum(inputTable, seqNum);
                    List<String> opTableCol = opStatsView.getRowColumnVauesForSelectedDpSeqNum(opTableName, seqNum);
                    commMethods.verifyboolean(header.contains(opTableCol), true);

                }
            }

        }

        if ("OP_ID_024".equalsIgnoreCase(tc_Id) || "OP_ID_025".equalsIgnoreCase(tc_Id) || "OP_ID_293".equalsIgnoreCase(tc_Id))

        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }
            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();

            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
            if ("OP_ID_024".equalsIgnoreCase(tc_Id) || "OP_ID_025".equalsIgnoreCase(tc_Id))
            {
                projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
                String[] recordTypeArr = recordType.split(";");
                commMethods.verifyInt(opStatsView.getTheCountOfFilesFormed(), recordTypeArr.length);
            }
            /*
             * shpPage.clickViewStatsForJobLevel(fProID); driver.switchTo().frame("sb-player"); String pathLoc = opStatsView.getFileFolderLocation();
             * int count = 0; if (IS_UNIX) { System.out.println("goes to --->>" + pathLoc); for (File f : new File(pathLoc).listFiles()) { if
             * (f.getName().equalsIgnoreCase(filenames.split(",")[0] + ".csv") || f.getName().equalsIgnoreCase(filenames.split(",")[1] + ".csv")) {
             * count++; } } } else { System.out.println("goes to --->>" + "C:" + pathLoc.replace("/", "\\")); String newPath = "C:" +
             * pathLoc.replace("/", "\\"); for (File f : new File(newPath).listFiles()) { if (f.getName().equalsIgnoreCase(filenames.split(",")[0] +
             * ".csv") || f.getName().equalsIgnoreCase(filenames.split(",")[1] + ".csv")) { count++; } } } commMethods.verifyInt(count, 2);
             */
        }

        /*
         * if ("OP_ID_025".equalsIgnoreCase(tc_Id) || "OP_ID_293".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver",
         * driver); projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); String fProID = opSetupPage.getProcessID(); opSetupPage.selectDataField(data);
         * commMethods.selectTheGroups(groups); opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName);
         * opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName); opSetupPage.clickContinueButton();
         * opRecTypesPage.selectSplitRecord(splitRecords, process); opRecTypesPage.createFilesWithName(filenames);
         * opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton(); opAliasPage.inputAliasTables(aliasTable);
         * opAliasPage.clickContinueButton(); // opConfigPage.seeding(seeding); Date date = new Date(); inputDate = dateFormat.format(date);
         * opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions);
         * opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum); opConfigPage.seeding(process, seeding, purpose);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.clickContinueButton(); opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput,
         * process); opMoveStPage.clickContinueButton(process); if (!"OFF".equalsIgnoreCase(sortReq)) { opSortOrderPage.clickSortRequired(sortReq,
         * purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose); } opSortOrderPage.clickContinueButton(purpose);
         * opFileNameSplitPage.StartingFileNumField(FileNum); opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
         * opFileNameSplitPage.clickContinueButton(); opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank,
         * maxNoSingle, maxNoUnknown, runTimeB); opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton();
         * projDashBoardPage.clickHomeTab(); commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
         * shpPage.clickViewStatsForJobLevel(fProID); driver.switchTo().frame("sb-player"); String pathLoc = opStatsView.getFileFolderLocation(); int
         * len = 0; int count = 0; if (IS_UNIX) { System.out.println("goes to --->>" + pathLoc); len = new File(pathLoc).listFiles().length; for (File
         * f : new File(pathLoc).listFiles()) { if (f.getName().equalsIgnoreCase(filenames + ".csv")) { count++; } } } else { System.out.println(
         * "goes to --->>" + "C:" + pathLoc.replace("/", "\\")); String newPath = "C:" + pathLoc.replace("/", "\\"); len = new
         * File(newPath).listFiles().length; for (File f : new File(newPath).listFiles()) { if (f.getName().equalsIgnoreCase(filenames + ".csv")) {
         * count++; } } } commMethods.verifyInt(count, 1); }
         */
        if ("OP_ID_026".equalsIgnoreCase(tc_Id))
        {

            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }
            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            Thread.sleep(3000);
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
            projDashBoardPage.clickTreeV2statsViewForChrome(fProID);

            // driver.switchTo().frame("sb-player");
            String table = opStatsView.getSourceInputTableName();
            List<String> finalAccCountList = opStatsView.getCountForAcceptCodes(table, recordType);
            Long acccountVal = 0L;
            for (String count : finalAccCountList)
            {
                acccountVal += Long.valueOf(count);
            }
            List<String> finalRejCountList = opStatsView.getCountForRejectCodes(table, recordType);
            Long rejcountVal = 0L;
            for (String count : finalRejCountList)
            {
                rejcountVal += Long.valueOf(count);
            }
            Long totalCouont = acccountVal + rejcountVal;
            Long splitTableCount = opStatsView.getSpitTableCountOP();
            commMethods.verifyLong(totalCouont, splitTableCount);
            // greenPlumConnect.getConnection();

        }

        if ("OP_ID_028".equalsIgnoreCase(tc_Id))
        {

            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();

            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);

            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }
            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

            // shpPage.clickViewStatsForJobLevel(fProID);
            projDashBoardPage.clickTreeV2statsViewForChrome(fProID);

            // driver.switchTo().frame("sb-player");
            String label = opStatsView.getRecordTypeDistribution(filenames);
            commMethods.verifyString(label.split(":")[0].trim(), recordType.trim());
            Long count = Long.valueOf(opStatsView.getRecordTypeDistributionCount());

            String inputTable = opStatsView.getSourceInputTableName();
            Long countFromtable = opStatsView.getCountForFileRecordType(inputTable, recordType);
            commMethods.verifyLong(count, countFromtable);

        }

        /*
         * if ("OP_ID_027".equalsIgnoreCase(tc_Id)) { projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton();
         * opSetupPage.inputprocessName(processName); opSetupPage.selectProcessField(process); String fProID = opSetupPage.getProcessID();
         * opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups); opSetupPage.selectFilePurpose(purpose);
         * opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
         * opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process); opRecTypesPage.createFilesWithName(filenames);
         * opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton(); opAliasPage.inputAliasTables(aliasTable);
         * opAliasPage.clickContinueButton(); // opConfigPage.seeding(seeding); Date date = new Date(); inputDate = dateFormat.format(date);
         * opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions);
         * opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum); opConfigPage.seeding(process, seeding, purpose);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.clickContinueButton(); opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput,
         * process); opMoveStPage.clickContinueButton(process); if (!"OFF".equalsIgnoreCase(sortReq)) { opSortOrderPage.clickSortRequired(sortReq,
         * purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose); } opSortOrderPage.clickContinueButton(purpose);
         * opFileNameSplitPage.StartingFileNumField(FileNum); opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
         * opFileNameSplitPage.clickContinueButton(); opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank,
         * maxNoSingle, maxNoUnknown, runTimeB); opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton();
         * projDashBoardPage.clickHomeTab(); commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "FAIL");
         * shpPage.clickViewStatsForJobLevel(fProID); driver.switchTo().frame("sb-player"); commMethods.verifyboolean(
         * opStatsView.getErrorWarningMessage().contains( " No. of split files is greater than filesplit.config.max.files : 20 in CONFIGURATION_ITEM"
         * ), true); }
         */
        /*
         * if ("OP_ID_062".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); opConfigPage.seeding(process, seeding, purpose); }
         */
        if ("OP_ID_071".equalsIgnoreCase(tc_Id))
        {

            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();

            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);

            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();

            Thread.sleep(2500);
            commMethods.verifyString(opHomePage.GetStatusOP().trim(), StatusEnum.SUBMITTED.name());
            opHomePage.selectSummaryOP();

            Thread.sleep(2500);
            String[] proceNameArr = opSumPage.processInSumry().split(":");
            commMethods.verifyString(proceNameArr[0] + ":" + proceNameArr[1], process);
            // commMethods.verifyString(opSumPage.jobInSumry(),);
            commMethods.verifyString(opSumPage.dataInSumry(), data);
            commMethods.verifyString(opSumPage.tableUsedForOutput(), outputTableName);
            String[] aliasArr = aliasTable.split(",");
            commMethods.verifyString(opSumPage.aliasUsedForOutputTable(), aliasArr[1]);
            commMethods.verifyString(opSumPage.dataCheckPerformed(), "Not Performed");
            commMethods.verifyString(opSumPage.layoutName(), inputDate);
            /*
             * List<String> recordList=new ArrayList<String>(); for(String record:recordList) { Assert.assertTrue(record.contains(recordType)
             * ||record.contains(filenames)); }
             */
            // /commMethods.verifyString(opSumPage.selectedRecordType(), "");
            commMethods.verifyString(opSumPage.selectedSortOptionMatch(), "Records will not be sorted.");
            // commMethods.verifyString(opSumPage.selectedfileName(), "");
            commMethods.verifyString(opSumPage.getFileFormat(), fileFormat.toUpperCase());
            String[] purposeArr = purpose.toString().split(" ");
            commMethods.verifyString(opSumPage.getFilePurpose(), purposeArr[0] + "_" + purposeArr[1]);

        }
        /*
         * if ("OP_ID_174".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); Date date = new Date(); inputDate = dateFormat.format(date);
         * opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions);
         * opConfigPage.seeding(process, seeding, purpose); //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
         * //opConfigPage.updateFieldValuesPerField(layoutFieldsChange, creatOrExistLayout); opConfigPage.clickContinueButton();
         * opConfigPage.clickFileFormatLink(); opConfigPage.validateCorrectLayoutStructure(); }
         */
        if ("OP_ID_080".equalsIgnoreCase(tc_Id) || "OP_ID_362".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();

            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);

            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);

            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }
            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

            projDashBoardPage.clickTreeV2statsViewForChrome(fProID);

            String inputTable = opStatsView.getSourceInputTableName();

            if ("OP_ID_080".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(opStatsView.getCountOfRecordsSelectedForProcessing(),
                        commMethods.getRecordsFromGPFailCodeNotNull(opStatsView.getSourceTableNameOP()));
            }
            if ("OP_ID_362".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyLong(opStatsView.getCountOfRecordsSelectedForProcessing(), greenPlumConnect.getGPCount(inputTable));
            }

            // shpPage.clickViewStatsForJobLevel(fProID);
            // driver.switchTo().frame("sb-player");
            /*
             * String[] sArr = recordType.split(","); List<Long> distributionCount = new ArrayList<>(); for (String arr : sArr) { Long
             * capRecDisrtforID = opStatsView.getcapRecDisrt(arr); distributionCount.add(capRecDisrtforID); } opStatsView.clickToCloseStats();
             * driver.switchTo().defaultContent(); String inputProcAssID[] = process.split(":"); shpPage.clickViewStatsForJobLevel(inputProcAssID[0]);
             * driver.switchTo().frame("sb-player"); List<Long> inputProcesDistributionCount = new ArrayList<>(); for (String arr : sArr) { Long
             * capRecDisrtforID = opStatsView.getcapRecDisrt(arr); inputProcesDistributionCount.add(capRecDisrtforID); }
             * commMethods.verifyboolean(distributionCount.containsAll( inputProcesDistributionCount), true);
             */
        }

        // test case needs to be updated as the load layout button is no more
        // present on the OPConfiguration Screen
        if ("OP_ID_127".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.clickContinueButton();
            commMethods.verifyString(opConfigPage.getLayoutLoadSuccessMessage(), "Layout loaded successfully");

        }
        if ("OP_ID_211".equalsIgnoreCase(tc_Id) || "OP_ID_269".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            if ("OP_ID_269".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(opRecTypesPage.getErrorText(), "Error: Only characters and numbers allowed for File Name.");
            } else
            {
                opAliasPage.inputAliasTables(aliasTable);
                opAliasPage.clickContinueButton();
                // opConfigPage.seeding(seeding);
                Date date = new Date();
                inputDate = dateFormat.format(date);
                opConfigPage.outputLayoutNameField(inputDate);
                opConfigPage.selectFileFormat(fileFormat);
                opConfigPage.selectCRLFOptions(crLFOptions);
                opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
                opConfigPage.seeding(process, seeding, purpose);
                opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
                opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);

                opConfigPage.clickContinueButton();
                opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process, layoutFieldsToSelect);
                opMoveStPage.clickContinueButton(process);
                if (!"OFF".equalsIgnoreCase(sortReq))
                {
                    opSortOrderPage.clickSortRequired(sortReq, purpose);
                    opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
                }

                opSortOrderPage.clickContinueButton(purpose);
                opFileNameSplitPage.StartingFileNumField(FileNum);
                opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
                opFileNameSplitPage.clickContinueButton();
                opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
                opDataChckPage.clickContinueButton();

                List<String> fieldNameList = opSumPage.getTheFieldNamesForOutputMoveStatement();
                List<String> recordTypeList = opSumPage.getTheRecordTypesForOutputMoveStatement();
                // List<String> dataToOutputList=
                // opSumPage.getTheDataToOutputForOutputMoveStatement();
                commMethods.verifyString(fieldNameList.get(0), layoutField.split(",")[0]);
                commMethods.verifyString(fieldNameList.get(1), layoutField.split(",")[1]);
                commMethods.verifyString(recordTypeList.get(0), movRecType.split(";")[0]);
                commMethods.verifyString(recordTypeList.get(1), movRecType.split(";")[1]);
            }
            /*
             * List<List<String>> listMovestmnts = opSumPage.getMoveStatementRows(); List<String> reqMoveStatList=new ArrayList<String>();
             * reqMoveStatList.add(layoutField); reqMoveStatList.add(movRecType); String[] dataToOutputArr=dataToOutput.split(",");
             * reqMoveStatList.add(dataToOutputArr[1]);
             */// selection for multiple move statements pending
        }

        /*
         * if ("OP_ID_362".equalsIgnoreCase(tc_Id)) { new Modules(); String status = null; testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); Date date = new Date(); inputDate = dateFormat.format(date);
         * opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat); opConfigPage.selectCRLFOptions(crLFOptions);
         * opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum); opConfigPage.seeding(process, seeding, purpose);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.clickContinueButton(); opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput,
         * process); opMoveStPage.clickContinueButton(process); if (!"OFF".equalsIgnoreCase(sortReq)) { opSortOrderPage.clickSortRequired(sortReq,
         * purpose); opSortOrderPage.selectSortField(sortFields, sortReq, purpose); } opSortOrderPage.clickContinueButton(purpose);
         * opFileNameSplitPage.StartingFileNumField(FileNum); opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
         * opFileNameSplitPage.clickContinueButton(); opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank,
         * maxNoSingle, maxNoUnknown, runTimeB); opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton(); status =
         * opHomePage.GetStatusOP(); commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name()); opHomePage.selectDuplicateOP();
         * opHomePage.selectEditOP(); opSetupPage.clickContinueButton(); opRecTypesPage.clickContinueButton(); opAliasPage.clickContinueButton();
         * //need to be corrected // String pathLoc = LayoutFile; // File f = new File(pathLoc); if (IS_UNIX) { System.out.println("goes to --->>" +
         * pathLoc); opConfigPage.readFileReplaceCIDLength(pathLoc); } else { System.out.println("goes to --->>" + "C:" + pathLoc.replace("/",
         * "\\")); String newPath = "C:" + pathLoc.replace("/", "\\"); opConfigPage.readFileReplaceCIDLength(newPath); } }
         */

        if ("OP_ID_361".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            String status = null;
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();

            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();

            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            // opSortOrderPage.selectSortField(sortFields,purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            status = opHomePage.GetStatusOP();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            opHomePage.selectDuplicateOP();
            opHomePage.selectEditOP();
            opSetupPage.clickContinueButton();
            opRecTypesPage.clickContinueButton();
            opAliasPage.clickContinueButton();

            opConfigPage.updateFieldValuesPerField("CID.fieldLength.19", creatOrExistLayout);
            opConfigPage.clickContinueButton();
            commMethods.verifyboolean(opConfigPage.isMoveStatementScreen(), true);

        }
        /*
         * if ("OP_ID_269".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * commMethods.verifyString(opRecTypesPage.getAlertText(), "Only characters and numbers allowed for File Name."); }
         */
        if ("OP_ID_284".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            String val = opFileNameSplitPage.getSplitDetailsForSummary(fileSplitReq, grpNum, numOfFiles, splitField);
            System.out.println("Value as====>>" + val);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            commMethods.verifyboolean(opSumPage.getSummarySplitDetail().contains(val.trim()), true);
            // //*[contains(text(),'File Splitting: ')]

        }

        if ("OP_ID_291".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            String tableSel[] = aliasTable.split(";");
            opAliasPage.inputAliasTables(tableSel[0]);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);

            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opHomePage.clickOutputTab();
            opHomePage.selectEditOP();
            opSetupPage.clickContinueButton();
            opRecTypesPage.clickContinueButton();
            http: // afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/project-output-recordType?projectNumber=6000001&opId=3442542
            opAliasPage.inputAliasTables(tableSel[1]);
            opAliasPage.removeAliasTables(tableSel[0]);
            opAliasPage.clickContinueButton();
            opConfigPage.outputLayoutNameField("NEW_LAYOUT." + inputDate);
            driver.findElement(By.xpath("//div[contains(text(),'MODEL_1107.ModelNumber_1107_1')]")).click();
            driver.findElement(By.xpath(" //div[@class='jqx-icon-delete-fusion']")).click();
            driver.findElement(By.xpath("//div[@class='jqx-window-content jqx-widget-content jqx-rc-b']//input[@id='confirmDelOk']")).click();
            Thread.sleep(2500);
            // commMethods.verifyString(opAliasPage.getAliasChangeMessageText(),
            // "Alias selection has been modified, upcoming screen selections may become invalid.Do you still want to continue? ");
            // opAliasPage.clickConfirmationOK();
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox("MODEL_5051 [MODEL_5051]", "ModelNumber_5051_1", creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField("ModelNumber_5051_1.fieldLength.10", creatOrExistLayout);
            opConfigPage.clickContinueButton();
            opConfigPage.handleTheDialogBoxAndClickContinue();
            commMethods.verifyboolean(opConfigPage.fetchTheErrorMessage()
                    .contains("Error : Move number 1 contains a selection for Data To Output ModelNumber_1107_1 which no longer exists in the Output Layout. Please make a new selection.."), true);
            opMoveStPage.deleteTheSelectedRow();

            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            commMethods.verifyboolean(opFileNameSplitPage.isFileSplittingChecked(), false);

        }
        if ("OP_ID_292".equalsIgnoreCase(tc_Id) || "OP_ID_103".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            opSortOrderPage.clickContinueButton(purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();

            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

            projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
            // OP_ID_145
            String inputTable = opStatsView.getSourceInputTableName();
            String outputTable = opStatsView.getOutputTableNameOP();
            if ("OP_ID_103".equalsIgnoreCase(tc_Id))
            {
                Long countFromInputTbl = opStatsView.getCountForFieldWithDefaultpadding(inputTable);
                Long countFromCappingTbl = opStatsView.getCountForFieldWithDefaultpadding(outputTable);
                commMethods.verifyLong(countFromCappingTbl, countFromInputTbl);
            }
            if ("OP_ID_292".equalsIgnoreCase(tc_Id))
            {
                // String fileLocation = opStatsView.getFileFolderLocation();
                // commMethods.verifyboolean(fileLocation.contains("/nas/fusion/workspace/devqa/R0630B4/"
                // + fProID + "_OP"), true);
                Long countFromInputTbl = opStatsView.getInputCountForPaddedField(inputTable);
                Long countFromCappingTbl = opStatsView.getCappingTblCountForPaddedField(outputTable);
                commMethods.verifyLong(countFromCappingTbl, countFromInputTbl);
            }
        }
        if ("OP_ID_101".equalsIgnoreCase(tc_Id) || "OP_ID_102".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            // opConfigPage.clickContinueButton();
            opConfigPage.clickSaveButton();
            commMethods.verifyboolean(opConfigPage.fetchTheErrorMessage().contains("Error: Invalid justification for data type"), true);
            // TO DO Uncomment if tc_id_102 steps are updated
            // commMethods.verifyString(opConfigPage.getDefaultPaddingForCharField(),
            // "BLANK");
            // commMethods.verifyString(opConfigPage.getDefaultPaddingForNumField(),
            // "Zero");

        }
        /*
         * if ("OP_ID_101".equalsIgnoreCase(tc_Id) || "OP_ID_102".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver",
         * driver); projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); opConfigPage.seeding(process, seeding, purpose); Date date =
         * new Date(); inputDate = dateFormat.format(date); opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat);
         * opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); commMethods.verifyboolean(opConfigPage.getErrorPresentOnConfigpage(). contains("Error: Default value"), true); }
         */
        if ("OP_ID_108".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();

            // Assert.assertTrue(opConfigPage.fetchTheErrorMessage().contains("Error: Default value 11.11 is not correct for Data Type NUM."));
            // opConfigPage.clickContinueButton();
            commMethods.verifyString(opConfigPage.fetchTheErrorMessage(), "Error: Default value 0.0 is not correct for Data Type NUM.");
        }
        /*
         * if ("OP_ID_109".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName); String fProID =
         * opSetupPage.getProcessID(); opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data);
         * commMethods.selectTheGroups(groups); opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName);
         * opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName); opSetupPage.clickContinueButton();
         * opRecTypesPage.selectSplitRecord(splitRecords, process); opRecTypesPage.createFilesWithName(filenames);
         * opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton(); opAliasPage.inputAliasTables(aliasTable);
         * opAliasPage.clickContinueButton(); opConfigPage.seeding(process, seeding, purpose); Date date = new Date(); inputDate =
         * dateFormat.format(date); opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat);
         * opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
         * opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
         * opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption (maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
         * opConfigPage.clickContinueButton(); // opConfigPage.clickSaveButton(); commMethods.verifyString(opConfigPage.gettMaskStartPos(), "");
         * commMethods.verifyString(opConfigPage.gettMaskString(), ""); commMethods.verifyString(opConfigPage.gettMaskLength(), ""); //changed
         * opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process); opMoveStPage.clickContinueButton(process); if
         * (!"OFF".equalsIgnoreCase(sortReq)) { opSortOrderPage.clickSortRequired(sortReq, purpose); opSortOrderPage.selectSortField(sortFields,
         * sortReq, purpose); } opSortOrderPage.clickContinueButton(purpose); // opFileNameSplitPage.StartingFileNumField(FileNum);
         * opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField); opFileNameSplitPage.clickContinueButton();
         * opDataChckPage.clickContinueButton(); opSumPage.clickSubmitButton(); projDashBoardPage.clickHomeTab();
         * commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS"); projDashBoardPage.clickTreeV2statsView(fProID); String
         * inputTable = opStatsView.getSourceInputTableName(); String outputTable = opStatsView.getOutputTableNameOP(); }
         */
        if ("OP_ID_110".equalsIgnoreCase(tc_Id))
        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);

            opConfigPage.clickSaveButton();
            commMethods.verifyboolean(opConfigPage.getErrorPresentOnConfigpage().contains("Error: Masking is not allowed for numeric Layout Field"),
                    true);
        }

        /*
         * // 9 th March if ("OP_ID_129".equalsIgnoreCase(tc_Id)) { new Modules(); testContext.setAttribute("WebDriver", driver);
         * projDashBoardPage.clickOutputTab(); opHomePage.clickOutputButton(); opSetupPage.inputprocessName(processName);
         * opSetupPage.selectProcessField(process); opSetupPage.selectDataField(data); commMethods.selectTheGroups(groups);
         * opSetupPage.selectFilePurpose(purpose); opSetupPage.inputOutputTableName(outputTableName); opSetupPage.selectLayout(creatOrExistLayout,
         * projExisLay, exisLayName); opSetupPage.clickContinueButton(); opRecTypesPage.selectSplitRecord(splitRecords, process);
         * opRecTypesPage.createFilesWithName(filenames); opRecTypesPage.selectRecordTypes(recordType); opRecTypesPage.clickContinueButton();
         * opAliasPage.inputAliasTables(aliasTable); opAliasPage.clickContinueButton(); opConfigPage.seeding(process, seeding, purpose); Date date =
         * new Date(); inputDate = dateFormat.format(date); opConfigPage.outputLayoutNameField(inputDate); opConfigPage.selectFileFormat(fileFormat);
         * opConfigPage.selectCRLFOptions(crLFOptions); opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
         * //opConfigPage.selectFields(LayoutFile, layoutFieldsSelect); //opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
         * creatOrExistLayout); opConfigPage.clickContinueButton(); commMethods.verifyboolean(opConfigPage .getErrorPresentOnConfigpage().contains (
         * "Error: Masking is not allowed for numeric Layout Field"), true); }
         */
        if ("OP_ID_128".equalsIgnoreCase(tc_Id) || "OP_ID_104".equalsIgnoreCase(tc_Id) || "OP_ID_105".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            } else
            {
                opSortOrderPage.clickContinueButton(purpose);
            }

            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            /*
             * if ("OP_ID_128".equalsIgnoreCase(tc_Id)) { commMethods.verifyString (opSumPage.getSelectedDataTableFromSummary(), data); }
             */
            // OP_ID_104
            if ("OP_ID_128".equalsIgnoreCase(tc_Id))
            {
                String jobNo = opSumPage.jobInSumry();
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(jobNo, commMethods.getJobNum());
                

            } else
            {
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                shpPage.clickViewStatsForJobLevel(fProID);
                driver.switchTo().frame("sb-player");
                projDashBoardPage.clickTreeV2statsView(fProID);
                String opTableName = opStatsView.getOutputTableNameOP();
                String inputTable = opStatsView.getSourceInputTableName();

                if ("OP_ID_104".equalsIgnoreCase(tc_Id))
                {
                    List<String> fieldDefaultValues = opStatsView.getUpdatedDefaultValForAptNum(opTableName);
                    for (String val : fieldDefaultValues)
                    {
                        commMethods.verifyboolean(val.equals("0"), true);
                    }
                }
                if ("OP_ID_105".equalsIgnoreCase(tc_Id))
                {

                    List<String> selDpSeqNum = opStatsView.getDpSeqNumForEmptyAptNum(inputTable);
                    List<String> updatedField = opStatsView.getAptNumUpdatedValue(selDpSeqNum, opTableName);
                    for (String val : updatedField)
                    {
                        commMethods.verifyboolean(val.equals("XXXX"), true);
                    }
                }
            }
        }
        if ("OP_ID_132".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

            opConfigPage.clickContinueButton();
            /*
             * if (!"NA".equalsIgnoreCase(layoutField)) { opMoveStPage.selectLayoutField(layoutField); }
             * opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
             */
            if (!"NA".equalsIgnoreCase(recordType))
            {
                opMoveStPage.clickRecordTypeImg();
                // commMethods.verifyboolean(commMethods.isElementPresent_ID("content-item-0-AllRecords"),
                // true);

                // opMoveStPage.selectRecTypes(recordType);
                opMoveStPage.clickAddAllRecords();
                commMethods.verifyString(opMoveStPage.getSelectedRecords(), "All Records");
            }
        }

        if ("OP_ID_134".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

            opConfigPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            commMethods.verifyboolean(opSortOrderPage.isFieldPresentAsDefinedInConfigPage(layoutFieldsToSelect), true);
            // opSortOrderPage.clickSortRequired(sortReq, purpose);
            // opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            // opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum,
            // numOfFiles, splitField);
            /*
             * String pathLoc = LayoutFile; if (IS_UNIX) { System.out.println("goes to --->>" + pathLoc); List<String> fieldNames =
             * opSortOrderPage.getPredictedFieldsList(); commMethods.verifyboolean (opConfigPage.isPredictedFieldPresentWithinLayout(fieldNames,
             * pathLoc), true); } else { System.out.println("goes to --->>" + "C:" + pathLoc.replace("/", "\\")); String newPath = "C:" +
             * pathLoc.replace("/", "\\"); List<String> fieldNames = opSortOrderPage.getPredictedFieldsList(); commMethods.verifyboolean
             * (opConfigPage.isPredictedFieldPresentWithinLayout(fieldNames, newPath), true); }
             */
        }

        if ("OP_ID_156".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);

            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.seeding(process, seeding, purpose);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);

            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);

            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process, layoutFieldsToSelect);

            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            // opSortOrderPage.selectSortField(sortFields,purpose);
            // opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.selectDataCheckCheckbox(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            opHomePage.selectDuplicateOP();
            opHomePage.selectEditOP();
            opSetupPage.clickContinueButton();
            // driver.navigate().to("http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/edit-output-process?projectNumber=6000001&opId=3453280");
            opRecTypesPage.removeSelectedFile(filenames.split(",")[1]);
            opRecTypesPage.clickContinueButton();
            opConfigPage.clickContinueButton();
            opMoveStPage.clickContinueButton(process);
            String errorMsg = opConfigPage.fetchTheErrorMessage();
            commMethods.verifyboolean(errorMsg.contains("which are no longer available. Please edit the Record Type selections."), true);
        }
        if ("OP_ID_091".equalsIgnoreCase(tc_Id) || "OP_ID_111".equalsIgnoreCase(tc_Id) || "OP_ID_112".equalsIgnoreCase(tc_Id)
                || "OP_ID_114".equalsIgnoreCase(tc_Id))
        {
            new Modules();

            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            // opConfigPage.seeding(seeding);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();
            opMoveStPage.clickAddButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);

            opMoveStPage.clickContinueButton(process);
            // commMethods.verifyboolean(opMoveStPage.isopSplitScreen(), true);
            String status = null;

            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueBtnOP();
            if ("OP_ID_091".equalsIgnoreCase(tc_Id))
            {

                opHomePage.clickOutputButton();
                status = opHomePage.GetStatusOP();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                projDashBoardPage.clickJobStackingTab();
                stackPage.clickJobStackingButton();
                jobStacking.inputStackName(processName);
                jobStacking.selectProcessCheckBox(fProID);
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickStatsView(processName);
                driver.switchTo().frame("sb-player");
            }

            if ("OP_ID_112".equalsIgnoreCase(tc_Id) || "OP_ID_111".equalsIgnoreCase(tc_Id) || "OP_ID_114".equalsIgnoreCase(tc_Id))
            {
                opSumPage.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
                projDashBoardPage.clickTreeV2statsView(fProID);
                Thread.sleep(2000);
                String inputTable = opStatsView.getSourceInputTableName();
                String outputTable = opStatsView.getOutputTableNameOP();
                if ("OP_ID_112".equalsIgnoreCase(tc_Id))
                {
                    // String inputTable =
                    // opStatsView.getSourceInputTableName();
                    // String outputTable = opStatsView.getOutputTableNameOP();
                    List<String> records = commMethods.getRecords(inputTable);

                    commMethods.verifyboolean(
                            opStatsView.isDigitsScrambled(commMethods.getRecordFromDp_s(outputTable, records.get(0)), records.get(1)), true);
                }

                if ("OP_ID_114".equalsIgnoreCase(tc_Id))
                {
                    String[] recordArr = recordType.split(",");
                    commMethods.verifyInt(opStatsView.getScrambledColumnsCount(), recordArr.length);
                }
                /*
                 * if (IS_UNIX) { //scrambleCount = opStatsView.readLayoutFileToGetTestDataColumnCount (LayoutFile); } else { // String newPath = "C:"
                 * + LayoutFile.replace("/", "\\"); //scrambleCount = opStatsView.readLayoutFileToGetTestDataColumnCount(newPath); }
                 * commMethods.verifyInt(scrambleCount, Integer.valueOf(opStatsView.getScrambledColumnsCount())); } String[] opLayoutField =
                 * layoutField.split("\\."); String[] dataToOuptut = dataToOutput.split(","); String recordsSplit[] = movRecType.split(",");
                 * List<String> finalList = new ArrayList<>(); String reverse = new StringBuffer(dataToOuptut[1]).reverse().toString(); String rev =
                 * reverse.toLowerCase(); for (String rec : recordsSplit) { List<String> rejMoves =
                 * opStatsView.getdpSeqNumbersFromHeaderTableForRej(inputTable, rec); List<String> accMoves =
                 * opStatsView.getdpSeqNumbersFromHeaderTableForAcc(inputTable, rec); finalList.addAll(rejMoves); finalList.addAll(accMoves); }
                 * List<String> scrambledValues = opStatsView.getMoveFieldValueForSelectedDpSeqNum (opLayoutField[1], outputTable, finalList); for
                 * (String scramble : scrambledValues) { commMethods.verifyboolean(scramble.equals(dataToOuptut[1]) || scramble.equals(rev), true); }
                 * }
                 */
            }
        }

        if ("OP_ID_040".equalsIgnoreCase(tc_Id) || "OP_ID_043".equalsIgnoreCase(tc_Id))

        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);

            opConfigPage.clickContinueButton();

            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            if (!"OFF".equalsIgnoreCase(sortReq))
            {
                opSortOrderPage.clickSortRequired(sortReq, purpose);
                opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            }

            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            String fieldName = opSumPage.getSelectedMoveFieldCompleteName();
            opSumPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");

            shpPage.clickViewStatsForJobLevel(fProID);
            driver.switchTo().frame("sb-player");

            // greenPlumConnect.getConnection();

            String[] dataToOuptut = dataToOutput.split(",");
            String[] opLayoutField = layoutField.split("\\.");
            String recordsSplit[] = movRecType.split(",");
            String inputTable = opStatsView.getSourceInputTableName();
            String outputTable = opStatsView.getOutputTableNameOP();
            List<String> finalList = new ArrayList<>();

            for (String rec : recordsSplit)
            {
                List<String> rejMoves = opStatsView.getdpSeqNumbersFromHeaderTableForRej(inputTable, rec);
                List<String> accMoves = opStatsView.getdpSeqNumbersFromHeaderTableForAcc(inputTable, rec);
                finalList.addAll(rejMoves);
                finalList.addAll(accMoves);
            }

            if ("OP_ID_137".equalsIgnoreCase(tc_Id))
            {
                String outputSplitTable = opStatsView.getOutputSplitTableName();
                List<String> gpRow = opStatsView.getSortListSeqByGpNum(fieldName, outputSplitTable);
                List<String> fieldSort = opStatsView.getSortListSeqByFieldName(fieldName, outputSplitTable);
                for (i = 0; i < gpRow.size(); i++)
                {
                    commMethods.verifyboolean(gpRow.get(i).equals(fieldSort.get(i)), true);
                }

            }

            if ("OP_ID_043".equalsIgnoreCase(tc_Id))
            {
                String outputSplitTable = opStatsView.getOutputSplitTableName();
                List<String> getFieldValues = opStatsView.getMoveFieldValueForSelectedDpSeqNum(fieldName, outputSplitTable, finalList);
                for (i = 0; i < getFieldValues.size(); i++)
                {
                    commMethods.verifyboolean(getFieldValues.get(i).equals(dataToOuptut[1]), true);

                }
            }
            if ("OP_ID_040".equalsIgnoreCase(tc_Id))
            {
                List<String> getFieldValues = opStatsView.getMoveFieldValueForSelectedDpSeqNum(opLayoutField[0], outputTable, finalList);
                for (i = 0; i < getFieldValues.size(); i++)
                {
                    commMethods.verifyboolean(getFieldValues.get(i).equals(dataToOuptut[1]), true);

                }
            }
        }
        if ("OP_ID_041".equalsIgnoreCase(tc_Id) || "OP_ID_050".equalsIgnoreCase(tc_Id))

        {
            new Modules();
            testContext.setAttribute("WebDriver", driver);
            projDashBoardPage.clickOutputTab();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            opConfigPage.clickContinueButton();
            // opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            opSumPage.clickSubmitButton();
            projDashBoardPage.clickHomeTab();

            commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
            shpPage.clickViewStatsForJobLevel(fProID);
            driver.switchTo().frame("sb-player");

            String inputRecSplit[] = recordType.split(",");
            String[] dataToOuptut = dataToOutput.split(",");
            String[] opLayoutField = layoutField.split("\\.");
            String recordsSplit[] = movRecType.split(",");
            String inputTable = opStatsView.getSourceInputTableName();
            String outputTable = opStatsView.getOutputTableNameOP();
            List<String> finalList = new ArrayList<>();
            List<String> unselectRecords = new ArrayList<>();

            List<String> remainingRecordypes = new ArrayList<>();
            List<String> stringList = new ArrayList<String>(Arrays.asList(inputRecSplit));
            List<String> stringList2 = new ArrayList<String>(Arrays.asList(recordsSplit));
            for (String s : stringList)
            {

                if (!stringList2.contains(s))
                {
                    remainingRecordypes.add(s);
                }

            }
            for (String recType : remainingRecordypes)
            {
                List<String> rejMoves = opStatsView.getdpSeqNumbersFromHeaderTableForRej(inputTable, recType);
                List<String> accMoves = opStatsView.getdpSeqNumbersFromHeaderTableForAcc(inputTable, recType);
                unselectRecords.addAll(rejMoves);
                unselectRecords.addAll(accMoves);
            }
            // List<String>
            // unselectRecords=opStatsView.getRecordWhereMoveStatementNOtPerformed(opLayoutField[0],
            // outputTable, dataToOuptut[0]);
            List<String> getFieldValues = opStatsView.getMoveFieldValueForSelectedDpSeqNum(opLayoutField[0], outputTable, unselectRecords);
            for (i = 0; i < getFieldValues.size(); i++)
            {
                commMethods.verifyboolean(!finalList.get(i).equals(dataToOuptut[1]), true);

            }
        }
        
        //Story268
        if("OP_ID_TC01".equalsIgnoreCase(tc_Id)||"OP_ID_TC04".equalsIgnoreCase(tc_Id))
        {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        projDashBoardPage.clickOutputTab();
        opHomePage.clickOutputButton();
        opSetupPage.inputprocessName(processName);
        opSetupPage.selectProcessField(process);
        String fProID = opSetupPage.getProcessID();
        opSetupPage.selectDataField(data);
        commMethods.selectTheGroups(groups);
        opSetupPage.selectFilePurpose(purpose);
        opSetupPage.inputOutputTableName(outputTableName);
        opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
        opSetupPage.clickContinueButton();
        opRecTypesPage.selectSplitRecord(splitRecords, process);
        opRecTypesPage.createFilesWithName(filenames);
        opRecTypesPage.selectRecordTypes(recordType);
        opRecTypesPage.clickContinueButton();
        opAliasPage.inputAliasTables(aliasTable);
        opAliasPage.clickContinueButton();
        opConfigPage.seeding(process, seeding, purpose);
        Date date = new Date();
        inputDate = dateFormat.format(date);
        opConfigPage.outputLayoutNameField(inputDate);
        opConfigPage.selectFileFormat(fileFormat);
        opConfigPage.selectCRLFOptions(crLFOptions);
        opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
        opConfigPage.seeding(process, seeding, purpose);
        // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
        // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
        // creatOrExistLayout);
        opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
        opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
        opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
        opConfigPage.clickContinueButton();
        // opConfigPage.clickContinueButton();
        opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
        opMoveStPage.clickContinueButton(process);
        opSortOrderPage.clickSortRequired(sortReq, purpose);
        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
        opSortOrderPage.clickContinueButton(purpose);
        opFileNameSplitPage.StartingFileNumField(FileNum);
        opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
        opFileNameSplitPage.clickContinueButton();
        opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
        opDataChckPage.clickContinueButton();
        opSumPage.clickSubmitButton();
        module.initializeDriver(driver);
        module.selectSummary();
        
        commMethods.verifyString("input",opSumPage.getTheTagName());
        commMethods.verifyboolean(true,opSumPage.isFieldPresent(layoutFieldsToSelect));
        }
        if("OP_ID_TC05".equalsIgnoreCase(tc_Id))
        {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        projDashBoardPage.clickOutputTab();
        opHomePage.clickOutputButton();
        opSetupPage.inputprocessName(processName);
        opSetupPage.selectProcessField(process);
        String fProID = opSetupPage.getProcessID();
        opSetupPage.selectDataField(data);
        commMethods.selectTheGroups(groups);
        opSetupPage.selectFilePurpose(purpose);
        opSetupPage.inputOutputTableName(outputTableName);
        opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
        opSetupPage.clickContinueButton();
        opRecTypesPage.selectSplitRecord(splitRecords, process);
        opRecTypesPage.createFilesWithName(filenames);
        opRecTypesPage.selectRecordTypes(recordType);
        opRecTypesPage.clickContinueButton();
        opAliasPage.inputAliasTables(aliasTable);
        opAliasPage.clickContinueButton();
        //opConfigPage.seeding(process, seeding, purpose);
        Date date = new Date();
        inputDate = dateFormat.format(date);
        opConfigPage.outputLayoutNameField(inputDate);
        opConfigPage.selectFileFormat(fileFormat);
        opConfigPage.selectCRLFOptions(crLFOptions);
        opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
        opConfigPage.seeding(process, seeding, purpose);
        // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
        // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
        // creatOrExistLayout);
        opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
        opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
        opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
        opConfigPage.clickSaveButton();
        opConfigPage.clickBackBtn();
        opAliasPage.changeAliasName("header");
        opAliasPage.clickContinueButton();
     String warnMessage=   driver.findElement(By.xpath("//*[@class='warnSpan']")).getText();
        opConfigPage.clickContinueButton();
        opConfigPage.handleTheDialogBoxAndClickContinue();
        // opConfigPage.clickContinueButton();
        opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
        opMoveStPage.clickContinueButton(process);
        opSortOrderPage.clickSortRequired(sortReq, purpose);
        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
        opFileNameSplitPage.StartingFileNumField(FileNum);
        opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
        opFileNameSplitPage.clickContinueButton();
        opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
        opDataChckPage.clickContinueButton();
        
     // driver.navigate().to("http://afnt1lc9a001.app.c9.equifax.com:9190/cms-fusion-web/output/outputSummary?projectNumber=6000000&opId=3941901&summaryFlag=Y");
 	 //module.initializeDriver(driver);
    // module.selectSummary();  
     
      commMethods.verifyString(warnMessage,opSumPage.fetchTheWarningMessage());
        }
        if("OP_ID_TC06".equalsIgnoreCase(tc_Id))
        {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        projDashBoardPage.clickOutputTab();
        opHomePage.clickOutputButton();
        opSetupPage.inputprocessName(processName);
        opSetupPage.selectProcessField(process);
        String fProID = opSetupPage.getProcessID();
        opSetupPage.selectDataField(data);
        commMethods.selectTheGroups(groups);
        opSetupPage.selectFilePurpose(purpose);
        opSetupPage.inputOutputTableName(outputTableName);
        opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
        opSetupPage.clickContinueButton();
        opRecTypesPage.selectSplitRecord(splitRecords, process);
        opRecTypesPage.createFilesWithName(filenames);
        opRecTypesPage.selectRecordTypes(recordType);
        opRecTypesPage.clickContinueButton();
        opAliasPage.inputAliasTables(aliasTable);
        opAliasPage.clickContinueButton();
        //opConfigPage.seeding(process, seeding, purpose);
        Date date = new Date();
        inputDate = dateFormat.format(date);
        opConfigPage.outputLayoutNameField(inputDate);
        opConfigPage.selectFileFormat(fileFormat);
        opConfigPage.selectCRLFOptions(crLFOptions);
        opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
        opConfigPage.seeding(process, seeding, purpose);
        // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
        // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
        // creatOrExistLayout);
        opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
        opConfigPage.clickResequenceAddButton(reseqReq);
        opConfigPage.updateFieldValuesPerFieldForResequenceReq(layoutFieldsToUpdate, reseqReq);
        opConfigPage.clickContinueButton();
        String warnMessage=opConfigPage.fetchTheErrorMsgFromTheDialogBox();
        opConfigPage.handleTheDialogBoxAndClickContinue();
        // opConfigPage.clickContinueButton();
        opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
        opMoveStPage.clickContinueButton(process);
        opSortOrderPage.clickSortRequired(sortReq, purpose);
        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
        opSortOrderPage.clickContinueButton(purpose);
        opFileNameSplitPage.StartingFileNumField(FileNum);
        opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
        opFileNameSplitPage.clickContinueButton();
        opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
        opDataChckPage.clickContinueButton();
      
        commMethods.verifyString(warnMessage,opSumPage.fetchTheWarningMessage());
        }
       
        
        //story--294
        
        if("OP_ID_TC08".equalsIgnoreCase(tc_Id)|| "OP_ID_TC10".equalsIgnoreCase(tc_Id))
        {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        projDashBoardPage.clickOutputTab();
        opHomePage.clickOutputButton();
        opSetupPage.inputprocessName(processName);
        opSetupPage.selectProcessField(process);
        String fProID = opSetupPage.getProcessID();
        opSetupPage.selectDataField(data);
        commMethods.selectTheGroups(groups);
        opSetupPage.selectFilePurpose(purpose);
        opSetupPage.inputOutputTableName(outputTableName);
        opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
        opSetupPage.clickContinueButton();
        opRecTypesPage.selectSplitRecord(splitRecords, process);
        opRecTypesPage.createFilesWithName(filenames);
        opRecTypesPage.selectRecordTypes(recordType);
        opRecTypesPage.clickContinueButton();
        opAliasPage.inputAliasTables(aliasTable);
        opAliasPage.clickContinueButton();
        //opConfigPage.seeding(process, seeding, purpose);
        Date date = new Date();
        inputDate = dateFormat.format(date);
        opConfigPage.outputLayoutNameField(inputDate);
        opConfigPage.selectFileFormat(fileFormat);
        opConfigPage.selectCRLFOptions(crLFOptions);
        opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
        opConfigPage.seeding(process, seeding, purpose);
        // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
        // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
        // creatOrExistLayout);
       // opConfigPage.AddHeaderRecord_CB.click();
        opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
        opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
        opConfigPage.clickResequenceAddButton(reseqReq);
        opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
        opConfigPage.clickContinueButton();
        // opConfigPage.clickContinueButton();
        opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
        opMoveStPage.clickContinueButton(process);
        opSortOrderPage.clickSortRequired(sortReq, purpose);
        opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
        opSortOrderPage.clickContinueButton(purpose);
        opFileNameSplitPage.StartingFileNumField(FileNum);
        opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
        opFileNameSplitPage.clickContinueButton();
        opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
        opDataChckPage.clickContinueButton();
        opSumPage.clickSubmitButton();
        projDashBoardPage.clickHomeTab();

        commMethods.verifyString(projDashBoardPage.verifyProcess(fProID), "PASS");
        projDashBoardPage.clickTreeV2statsViewForChrome(fProID);
        
        commMethods.verifyString("Number of Header records written  :",opStatsView.fetchTheHeading());
        String inputTable = opStatsView.getSourceInputTableName();
        commMethods.verifyInt(1,opStatsView.fetchTheNumberOfHeaderRecordsWritten());
        Long acceptRecords=opStatsView.fetchAcceptRecords(inputTable);
        Long rejectRecords=opStatsView.fetchRejectRecords(inputTable);
        List<Long> recordList=opStatsView.fetchTheRecordsPerFile(filenames);
        Assert.assertTrue(recordList.contains(acceptRecords));
        Assert.assertTrue(recordList.contains(rejectRecords));
        }
    }

    /*
     * @DataProvider public Object[][] op_CBA() throws Exception { Object[][] testObjArray_CBA =
     * ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "OPprocess", "CBA"); return
     * testObjArray_CBA; }
     */

    // BaseProcess for OP
    @Test(dataProvider = "Output_Base_Reg", description = "Base processes for all the post processes")
    public void opBaseProcesses(String tc_Id, String testRun, String TC, String desc, String copyProject, String copyProcessName, String processName,
            String process, String data, String groups, String purpose, String outputTableName, String creatOrExistLayout, String projExisLay,
            String exisLayName, String splitRecords, String filenames, String recordType, String aliasTable, String seeding, String reseqReq,
            String reSeqNum, String LayoutName, String fileFormat, String delimiter, String crLFOptions, String layoutTableName,
            String layoutFieldsToSelect, String layoutFieldsToUpdate, String fieldToMaskOrScrammble, String maskScrambleFormatMaskValues,
            String moveStatReq, String layoutField, String movRecType, String dataToOutput, String sortReq, String sortFields, String FileNum,
            String fileSplitReq, String grpNum, String numOfFiles, String splitField, String secondarySplitReq, String secondarySplitByFile,
            String secondarySplitByRecord, String dataCheck, String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown,
            String runTimeB, String newProcessName, String newProcess, String newData, String newAliasTable, String submitRequired,
            ITestContext testContext) throws InterruptedException
    {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        String executionStatus = commMethods.getTheExecutionStatus(process);
        if (executionStatus.equalsIgnoreCase("COMPLETED"))
        {
        	
            LOGGER.info("Dependent Process Is Successfully Completed");
            projDashBoardPage.clickOutputTab();
            commMethods.handleAlert();
            opHomePage.clickOutputButton();
            opSetupPage.inputprocessName(processName);
            opSetupPage.selectProcessField(process);
            String fProID = opSetupPage.getProcessID();
            opSetupPage.selectDataField(data);
            commMethods.selectTheGroups(groups);
            opSetupPage.selectFilePurpose(purpose);
            opSetupPage.inputOutputTableName(outputTableName);
            opSetupPage.selectLayout(creatOrExistLayout, projExisLay, exisLayName);
            opSetupPage.clickContinueButton();
            opRecTypesPage.selectSplitRecord(splitRecords, process);
            opRecTypesPage.createFilesWithName(filenames);
            opRecTypesPage.selectRecordTypes(recordType);
            opRecTypesPage.clickContinueButton();
            opAliasPage.inputAliasTables(aliasTable);
            opAliasPage.clickContinueButton();
            //opConfigPage.seeding(process, seeding, purpose);
            Date date = new Date();
            inputDate = dateFormat.format(date);
            opConfigPage.outputLayoutNameField(inputDate);
            opConfigPage.selectFileFormat(fileFormat);
            opConfigPage.selectCRLFOptions(crLFOptions);
            opConfigPage.selectResequenceReq_CB(reseqReq, reSeqNum);
            opConfigPage.seeding(process, seeding, purpose);
            
            // opConfigPage.selectFields(LayoutFile, layoutFieldsSelect);
            // opConfigPage.updateFieldValuesPerField(layoutFieldsChange,
            // creatOrExistLayout);
            opConfigPage.dragAndDropSelectedFieldUsingSearchBox(layoutTableName, layoutFieldsToSelect, creatOrExistLayout);
            opConfigPage.updateFieldValuesPerField(layoutFieldsToUpdate, creatOrExistLayout);
            opConfigPage.updateTheRowForMaskOrScrambleOrFormatMaskOption(maskScrambleFormatMaskValues, fieldToMaskOrScrammble);
            Thread.sleep(2000);
            opConfigPage.clickContinueButton();
            //opConfigPage.clickContinueButton();
            opMoveStPage.selectOutputMoveStmnt(layoutField, movRecType, dataToOutput, process);
            opMoveStPage.clickContinueButton(process);
            opSortOrderPage.clickSortRequired(sortReq, purpose);
            opSortOrderPage.selectSortField(sortFields, sortReq, purpose);
            opSortOrderPage.clickContinueButton(purpose);
            opFileNameSplitPage.StartingFileNumField(FileNum);
            opFileNameSplitPage.selectOutputSplit(fileSplitReq, grpNum, numOfFiles, splitField);
            opFileNameSplitPage.clickContinueButton();
            opDataChckPage.performDataCheck(fileFormat, purpose, dataCheck, fileIden, maxNoBlank, maxNoSingle, maxNoUnknown, runTimeB);
            opDataChckPage.clickContinueButton();
            Thread.sleep(1500);

            // driver.navigate().to("http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/output/outputSummary?projectNumber=6000001&opId=3692266&dirtyFlag=true&layoutFormat=ASCII_FIXED");
            //projDashBoardPage.clickOutputTab();
            String status = null;
            //status = opHomePage.GetStatusOP();
            //commMethods.verifyString(StatusEnum.READY.name(), status.trim());
            if (submitRequired.equalsIgnoreCase("Y"))
            {
                opSumPage.clickSubmitButton();
                module.initializeDriver(driver);
                status = opHomePage.GetStatusOP();
                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());

                projDashBoardPage.clickHomeTab();
                String procName1 = projDashBoardPage.jobName();
                String Status;
                Status = projDashBoardPage.verifyProcess(procName1);
                commMethods.verifyString(Status, "PASS");
                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
            }
            else
            {
                module.initializeDriver(driver);
                projDashBoardPage.clickOutputTab();
                commMethods.verifyString(opHomePage.GetStatusOP(), StatusEnum.READY.name().trim());
            }	
            String s="java";
            String s1="java";
        }
        else
        {
            Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
        }
    }

    @DataProvider
    public Object[][] op_CBA() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Output", "CBA");
        return testObjArray_CBA;
    }
    @DataProvider
    public Object[][] op_QA() throws Exception
    {
        Object[][] testObjArray_QA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Output", "Y");
        return testObjArray_QA;
    }

    /*
     * @DataProvider public Object[][] op_CBA() throws Exception { Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(
     * System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "OPprocess (2)", "CBA"); return testObjArray_CBA; }
     */

   @DataProvider
    public Object[][] Output_Base_Reg() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Output", "BAS");
        return testObjArray_CBA;
    }

//    @AfterMethod
//    public void closeBrowser()
//    {
//        driver.quit();
//    }

    /*
     * @DataProvider public Object[][] op_Reg() throws Exception { Object[][] testObjArray_Y =
     * ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "OPprocess1", "Y"); return
     * testObjArray_Y; }
     */
    // for DEVQA env QA Package
    /*
     * @DataProvider public Object[][] op_Reg() throws Exception { Object[][] testObjArray_Y =
     * ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "OPprocess (2)", "Y"); return
     * testObjArray_Y; }
     */
    // for QA env QA Package
    /*
     * @DataProvider public Object[][] op_Reg() throws Exception { Object[][] testObjArray_Y =
     * ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "OPprocess", "Y"); return
     * testObjArray_Y; }
     */
}

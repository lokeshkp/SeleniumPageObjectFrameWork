package com.equifax.cms.fusion.test.qaip;

import java.io.IOException;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.json.JSONException;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.IPPages.DataCheckPage;
import com.equifax.cms.fusion.test.IPPages.DefineLayoutPage;
import com.equifax.cms.fusion.test.IPPages.ImportNewFilePage;
import com.equifax.cms.fusion.test.IPPages.InputHomePage;
import com.equifax.cms.fusion.test.IPPages.IpLayoutSearchPage;
import com.equifax.cms.fusion.test.IPPages.IpStatsView;
import com.equifax.cms.fusion.test.IPPages.LayoutImportPage;
import com.equifax.cms.fusion.test.IPPages.SummaryPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Import New File Process")
public class ImportNewFileProcess extends AbstractCoreTest
{

    private static final String IP = "Input";
    boolean flag = false;

    public WebDriver driver;
    private ImportNewFilePage ImpNwFilPage;
    private ProjectDashBoardPage ProjDashBoardPage;
    private CommonMethods commMethods;
    private InputHomePage IPHomePage;
    private DefineLayoutPage DefLayoutPage;
    private DataCheckPage DataChckPage;
    private SummaryPage summaryPage;
    private LayoutImportPage LayoutImpPage;
    private IpStatsView statsView;
    private IpLayoutSearchPage layoutSrchPage;
    DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
    public static int i = 0;

    private static final String INVALID_DATA_FORMAT = "Invalid Data Format";
    private static final Logger LOGGER = LoggerFactory.getLogger(ImportNewFileProcess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        IPHomePage = PageFactory.initElements(driver, InputHomePage.class);
        ImpNwFilPage = PageFactory.initElements(driver, ImportNewFilePage.class);
        DefLayoutPage = PageFactory.initElements(driver, DefineLayoutPage.class);
        DataChckPage = PageFactory.initElements(driver, DataCheckPage.class);
        summaryPage = PageFactory.initElements(driver, SummaryPage.class);
        LayoutImpPage = PageFactory.initElements(driver, LayoutImportPage.class);
        statsView = PageFactory.initElements(driver, IpStatsView.class);
        layoutSrchPage = PageFactory.initElements(driver, IpLayoutSearchPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "InputData_Y", priority = 2, description = "Input Process Regression Test", enabled = true)
    public void IPstats(String TC, String testRun, String tc_Id, String Desc, String copyProj, String copyProcName, String procName, String Type,
            String Purpose, String Loc, String Format, String RecLength, String StartSeq, String opTblName, String srchProj, String srchLaytName,
            String layoutType, String layoutName, String layoutFileLoc, String rowNoFirstField, String colUserDefName, String colStartPosi,
            String colEndPosi, String dataTypesPerField, String fieldsInLayout, String transInvChar, String clickSelectsPos, String addConst,
            String constField, String constValue, String other_name, String startPos, String endPos, String fieldLength, String dataChck,
            String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown, String runTimeB, ITestContext testContext)
            throws InterruptedException, JSONException, SQLException, IOException
    {
        ProjDashBoardPage.clickHomeTab();
        testContext.setAttribute("WebDriver", driver);
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);

        if ("IP_MT_001".equalsIgnoreCase(tc_Id))
        {
            // ASCII fixed validations
            ProjDashBoardPage.clickInputTab();
            IPHomePage.ClickImportNewFile();
            String procId = ImpNwFilPage.getProcId();
            ImpNwFilPage.clickBackBtn();
            String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/h2")).getText();
            commMethods
                    .verifyString(pageTitle,
                            "InputClick a task button to create a new process; or click the configuration icon to edit, duplicate, or view the summary of an existing process.");
            IPHomePage.ClickImportNewFile();
            ImpNwFilPage.processNameField(procName);
            ImpNwFilPage.clickBackBtn();
            driver.switchTo().alert().dismiss();
            pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
            commMethods.verifyString(pageTitle, "Import New File Specify a file; create, import, or search for a layout; and click Continue.");
            ImpNwFilPage.typeField(Type);
            ImpNwFilPage.purposeField(Purpose);
            // ImpNwFilPage.filePathField().sendKeys(Loc);
            ImpNwFilPage.SelectFileFormat_Rad_But(Format);
            ImpNwFilPage.filePaths(Loc);
            ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
            if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Existing Layout"))
            {
                ImpNwFilPage.aSCIIFixedRbutton().click();
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
            } else if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Import Layout"))
            {
                ImpNwFilPage.aSCIIFixedRbutton().click();
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.selectImportLayoutRbutton();
                LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
            }
            ImpNwFilPage.clickSaveBtn();
            pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
            commMethods.verifyString(pageTitle, "Import New File Specify a file; create, import, or search for a layout; and click Continue.");
            ProjDashBoardPage.clickInputTab();

            ImpNwFilPage.continueButton().click();

            if (layoutType.equalsIgnoreCase("Import Layout") && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC FIXED")))
            {
                // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                // DefLayoutPage.selectAllFields();
                // DefLayoutPage.selectFieldType(fieldsInLayout);
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                Date date = new Date();
                DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
                // added
                DefLayoutPage.selDataType(dataTypesPerField);
                DefLayoutPage.selFieldType(fieldsInLayout);
                // dataTypesPerField
                DefLayoutPage.selectInvalidCharBlanks(transInvChar);

            }

            DefLayoutPage.constantField(addConst, constField, constValue);
            commMethods.verifyString(DefLayoutPage.previewTitle(), "Preview");
            commMethods.verifyboolean(DefLayoutPage.dataInPreview(), true);
            DefLayoutPage.PreviewCloseBtn.click();

            commMethods.verifyString(DefLayoutPage.fldsClear(), "No data to display");

            DefLayoutPage.clickContinueButton();
            DefLayoutPage.clickContinueOnAlert();
            Thread.sleep(3000);
            if (!"ASCII Delimited".equalsIgnoreCase(Format))
            {
                String pageTitle1 = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
                commMethods.verifyString(pageTitle1, "DataCheck Enter the required information, and then click Continue.");
                DataChckPage.clickDataCheckCheckbox(dataChck);
                DataChckPage.clickContinueButton();
                Thread.sleep(3000);
            }
            summaryPage.clickSubmitButton();
            module.initializeDriver(driver);
            status = module.getStatusIP();
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
            ProjDashBoardPage.clickHomeTab();
            String procName1 = ProjDashBoardPage.jobName();
            String Status;
            Status = ProjDashBoardPage.verifyProcess(procName1);
            commMethods.verifyString(Status, "PASS");
            commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");

        }

        if ("IP_ID_004".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickInputTab();
            IPHomePage.ClickImportNewFile();
            ImpNwFilPage.continueButton().click();
        }
        if ("IP_ID_065".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickInputTab();
            IPHomePage.ClickImportNewFile();
            ImpNwFilPage.continueButton().click();
            String errMsg = driver.findElement(By.xpath("//div[@class='errMsg']/li[1]")).getText();
            commMethods.verifyString(errMsg, "Error: Record Length is required.");
            String errMsg1 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][2]")).getText();
            commMethods.verifyString(errMsg1, "Error: Starting Sequence Number is required.");

            String errMsg2 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][3]")).getText();
            commMethods.verifyString(errMsg2, "Error: Please enter the Process Name.");

            String errMsg3 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][4]")).getText();
            commMethods.verifyString(errMsg3, "Error: Please provide at least one Input File.");

            ImpNwFilPage.processNameField(procName);
            ImpNwFilPage.continueButton().click();
            String errMsg4 = driver.findElement(By.xpath("//div[@class='errMsg']/li[1]")).getText();
            commMethods.verifyString(errMsg4, "Error: Record Length is required.");
            String errMsg5 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][2]")).getText();
            commMethods.verifyString(errMsg5, "Error: Starting Sequence Number is required.");

            String errMsg6 = driver.findElement(By.xpath("//div[@class='errMsg']/span[@class='error'][3]")).getText();
            commMethods.verifyString(errMsg6, "Error: Please provide at least one Input File.");

            ImpNwFilPage.filePathField().sendKeys(Loc);
            ImpNwFilPage.continueButton().click();
            String errMsg7 = driver.findElement(By.xpath("//div[@class='errMsg']/li[1]")).getText();
            commMethods.verifyString(errMsg7, "Error: Record Length is required.");
            String errMsg8 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][2]")).getText();
            commMethods.verifyString(errMsg8, "Error: Starting Sequence Number is required.");

            ImpNwFilPage.RecLengthField(RecLength);
            ImpNwFilPage.continueButton().click();
            String errMsg9 = driver.findElement(By.xpath("//div[@class='errMsg']/li[@class='error'][2]")).getText();
            commMethods.verifyString(errMsg9, "Error: Starting Sequence Number is required.");

            ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
            ImpNwFilPage.selectImportLayoutRbutton();
            ImpNwFilPage.continueButton().click();
            String errMsg10 = driver.findElement(By.xpath("//div[@class='errMsg']/li[1]")).getText();
            commMethods.verifyString(errMsg10, "Error: File Location is required for Import Layout.");

            LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
            ImpNwFilPage.continueButton().click();
            // LayoutImpPage.clearLayoutFileLocation();

            // LayoutImpPage.clickContinueButton();

            LayoutImpPage.clickContinueButton();

            String errMsg11 = driver.findElement(By.xpath("//div[@class='errMsg']/li[1]")).getText();
            commMethods.verifyString(errMsg11, " Row number of first field is required.");
            String errMsg12 = driver.findElement(By.xpath("//div[@class='errMsg']/li[2]")).getText();
            commMethods.verifyString(errMsg12, " Column no of user defined name is required.");
            String errMsg13 = driver.findElement(By.xpath("//div[@class='errMsg']/li[3]")).getText();
            commMethods.verifyString(errMsg13, " Column no of Start position is required.");

            LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);

            LayoutImpPage.inputUserDefinedName(colUserDefName);

            LayoutImpPage.inputStartPosition(colStartPosi);
            LayoutImpPage.clickContinueButton();
            DefLayoutPage.clickContinueButton();
            Thread.sleep(2000);
            DataChckPage.Ele_DataCheckCheckBox.click();
            DataChckPage.clickContinueButton();
            /*
             * errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div[1]")).getText(); commMethods.verifyString(errMsg,
             * "Please select File IdentifierPlease select RuntimeB."); DataChckPage.clickDataCheckCheckbox(dataChck);
             * DataChckPage.clickContinueButton();
             */
            ProjDashBoardPage.clickInputTab();
        } else if ("IP_ID_136".equalsIgnoreCase(tc_Id))
        {
            commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickInputTab();
            String copyStatus = IPHomePage.getStatusIP_1();
            commMethods.verifyString(StatusEnum.READY.name(), copyStatus.trim());
            module.initializeDriver(driver);
            module.selectSummary();
            String pageTitle = ProjDashBoardPage.getPageTitle();
            commMethods.verifyString(pageTitle, "Summary: Import New File\nReview the information below, and then click 'Back' or 'Submit' .");
            ProjDashBoardPage.clickInputTab();
            module.clickOnEdit();
            String actType = ImpNwFilPage.Ele_FileType.getAttribute("value");
            commMethods.verifyString(actType, Type);
            String actRecLngth = ImpNwFilPage.Ele_RecLength.getAttribute("value");
            commMethods.verifyString(actRecLngth, RecLength);
            String actStrtSeqNo = ImpNwFilPage.Ele_StrtSeqNum.getAttribute("value");
            commMethods.verifyString(actStrtSeqNo, StartSeq);
            String actExistLaytName = driver.findElement(By.xpath(".//*[@id='savedLayoutsTable']/tbody/tr[1]/td[2]")).getText().trim();
            commMethods.verifyString(actExistLaytName, layoutName);
            String actOpTblName = ImpNwFilPage.OutputTblName.getAttribute("value");
            commMethods.verifyString(actOpTblName, opTblName);
            ImpNwFilPage.continueButton().click();
            String layName = DefLayoutPage.Ele_LayoutName.getAttribute("value");
            commMethods.verifyString(layName, layoutName);
            DefLayoutPage.clickContinueButton();
            Thread.sleep(3000);
            driver.switchTo().alert().accept();
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
            Date date = new Date();
            DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
            DefLayoutPage.clickContinueButton();
            pageTitle = ProjDashBoardPage.getPageTitle();
            commMethods.verifyString(pageTitle, "DataCheck Enter the required information, and then click Continue.");
            ProjDashBoardPage.clickHomeTab();
            commMethods.searchProjforCopy(PropertiesUtils.getProperty("project"));
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            String copiedStatus = driver.findElement(By.xpath("//td[contains(text(),'" + copyProcName + "')]//following::td[1]")).getText().trim();
            commMethods.verifyString(copiedStatus, "Yes");
        } else
        {
            ProjDashBoardPage.clickInputTab();
            IPHomePage.ClickImportNewFile();
            Thread.sleep(3000);
            String procId = ImpNwFilPage.getProcId();
            ImpNwFilPage.processNameField(procName);
            Thread.sleep(3000);
            ImpNwFilPage.typeField(Type);
            ImpNwFilPage.purposeField(Purpose);
            // ImpNwFilPage.filePathField().sendKeys(Loc);
            ImpNwFilPage.SelectFileFormat_Rad_But(Format);
            ImpNwFilPage.filePaths(Loc);
            ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
            if ("IP_ID_085".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.RecLengthField("11");
                ImpNwFilPage.continueButton().click();
                String errMsg = driver.findElement(By.xpath(".//*[@id='errormessage']")).getText().trim();
                commMethods.verifyboolean(errMsg.endsWith("is not evenly divisible by record length 11"), true);
            } else if ("IP_ID_078".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.inputOutputTblName("!@#$%^&*()_+-={}[]|:'<>?,./");
                ImpNwFilPage.continueButton().click();
                String errMsg = driver.findElement(By.xpath("//div[@class='optionsErrMsg']/span")).getText();
                commMethods
                        .verifyString(errMsg,
                                "Error: Invalid field name: '!@#$%^&*()_+-={}[]|:'<>?,./' can contain only character, number or underscore and should not start with a number.");
                ImpNwFilPage.inputOutputTblName("INPUT");
            } else if ("IP_ID_090".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.existingLayoutRbutton();
                ImpNwFilPage.clickSearchBtn();
                Thread.sleep(2000);
                layoutSrchPage.clickCancelBtn();
                ImpNwFilPage.selectImportLayoutRbutton();
                String pageTitle = ProjDashBoardPage.getPageTitle();
                commMethods.verifyString(pageTitle, "Import New File Specify a file; create, import, or search for a layout; and click Continue.");
                String recLengthPo = ImpNwFilPage.Ele_RecLength.getAttribute("value");
                commMethods.verifyString(recLengthPo, RecLength);
            } else if ("IP_ID_158".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.existingLayoutRbutton();
                ImpNwFilPage.clickSearchBtn();
                layoutSrchPage.inputProjNum(srchProj);
                layoutSrchPage.clickSearchBtn();
                layoutSrchPage.selectSrchLayout(srchLaytName);
                layoutSrchPage.clickContinueBtn();
                String pageTitle = ProjDashBoardPage.getPageTitle();
                commMethods.verifyString(pageTitle, "Import New File Specify a file; create, import, or search for a layout; and click Continue.");
            } else if ("IP_ID_077".equalsIgnoreCase(tc_Id))
            {
                String actTblName = ImpNwFilPage.OutputTblName.getAttribute("value");
                commMethods.verifyString(actTblName, opTblName);
            } else if ("IP_ID_002".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.eBCDICRbutton().click();
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
                ImpNwFilPage.inputOutputTblName(opTblName);
                ImpNwFilPage.selectImportLayoutRbutton();
                LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                ImpNwFilPage.continueButton().click();
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                String defLayoutTitle = driver.findElement(By.xpath("//h3[@class='fusion-h3Title']")).getText();
                commMethods.verifyString(defLayoutTitle, "Layout Definition Complete the required information, and then click Continue.");
            } else if ("IP_ID_107".equalsIgnoreCase(tc_Id) || "IP_ID_114".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.eBCDICRbutton().click();
                ImpNwFilPage.RecLengthField(RecLength);
                ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
                ImpNwFilPage.inputOutputTblName(opTblName);
                ImpNwFilPage.selectImportLayoutRbutton();
                LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                ImpNwFilPage.continueButton().click();
                String actLenghtFld = LayoutImpPage.Ele_Length.getText();
                commMethods.verifyString(actLenghtFld, "Length");
            } else if ("IP_ID_089".equalsIgnoreCase(tc_Id))
            {
                ImpNwFilPage.delimitedRbutton().click();
                ImpNwFilPage.delimiterField(RecLength);
                ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
                ImpNwFilPage.clickCreateNewLayoutRButton();
                ImpNwFilPage.continueButton().click();
                // String actOther = driver.findElement(By.xpath("(//option[contains(text(),'Other')])[1]")).getText();
                // commMethods.verifyString(actOther, "Other");
                String defLayoutTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/h3")).getText();
                commMethods.verifyString(defLayoutTitle, "Layout Definition Complete the required information, and then click Continue.");
                ProjDashBoardPage.clickInputTab();
                module.initializeDriver(driver);
                status = module.getStatusIP();
                commMethods.verifyString(StatusEnum.ERROR.name(), status.trim());
            } else
            {
                if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Existing Layout"))
                {
                    ImpNwFilPage.aSCIIFixedRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);
                    ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
                } else if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Create New Layout"))
                {
                    ImpNwFilPage.aSCIIFixedRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);

                } else if (Format.equalsIgnoreCase("EBCDIC FIXED") && layoutType.equalsIgnoreCase("Existing Layout"))
                {
                    ImpNwFilPage.eBCDICRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);
                    ImpNwFilPage.SelectExisLay_Rad_But(layoutName);

                } else if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Existing Layout"))
                {
                    ImpNwFilPage.delimitedRbutton().click();
                    ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
                    ImpNwFilPage.delimiterField(RecLength);
                } else if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Import Layout"))
                {
                    ImpNwFilPage.aSCIIFixedRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);
                    ImpNwFilPage.selectImportLayoutRbutton();
                    LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                } else if (Format.equalsIgnoreCase("EBCDIC FIXED") && layoutType.equalsIgnoreCase("Import Layout"))
                {
                    ImpNwFilPage.eBCDICRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);
                    ImpNwFilPage.selectImportLayoutRbutton();
                    LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                   
                } else if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Import Layout"))
                {
                    ImpNwFilPage.delimitedRbutton().click();
                    ImpNwFilPage.selectImportLayoutRbutton();
                    ImpNwFilPage.delimiterField(RecLength);
                    LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                } else if (Format.equalsIgnoreCase("EBCDIC FIXED") && layoutType.equalsIgnoreCase("Create New"))
                {
                    // ImpNwFilPage.delimitedRbutton().click();
                    ImpNwFilPage.RecLengthField(RecLength);
                } else if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Create New"))
                {
                    ImpNwFilPage.delimitedRbutton().click();
                    // ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
                    ImpNwFilPage.delimiterField(RecLength);
                }

                ImpNwFilPage.continueButton().click();
                // new test cases
                if ("IP_ID_032".equalsIgnoreCase(tc_Id))
                {
                    Thread.sleep(3000);
                    // Test
                    // String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
                    // commMethods.verifyString(pageTitle, "DataCheck Enter the required information, and then click Continue.");
                    LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                    Thread.sleep(2000);
                    LayoutImpPage.inputUserDefinedName(colUserDefName);
                    LayoutImpPage.inputStartPosition(colStartPosi);
                    LayoutImpPage.inputEndPosition(colEndPosi);
                    LayoutImpPage.clickContinueButton();
                    DefLayoutPage.Ele_LayoutName.sendKeys(layoutName);
                    DefLayoutPage.selectStartOrEndLine(colStartPosi);
                    DefLayoutPage.selectStartOrEndLine(colEndPosi);
                    DefLayoutPage.clickGenerateFieldsBtn();

                    Thread.sleep(2000);
                    DefLayoutPage.constantField(addConst, constField, constValue);
                    if (!"NA".equalsIgnoreCase(addConst))
                    {
                        driver.findElement(By.id("addConstantField")).click();
                        driver.findElement(By.xpath("//div[contains(text(),'File Name')]/following::div[3]")).click();
                        driver.findElement(By.id("removeConstantField")).click();
                    }

                    // DefLayoutPage.updateFieldValuesPerField(layoutFieldType, name, startPos, endPos, fieldLength);
                    DefLayoutPage.clickContinueButton();

                    DefLayoutPage.clickContinueOnAlert();
                    Thread.sleep(4000);

                    String errMsg = driver.findElement(By.xpath("//h3[contains(text(),'Layout Definition')]/preceding::span[1]")).getText();
                    commMethods.verifyString(errMsg, "Error: CHECK is a reserved word.");
                }

                else if ("IP_ID_1118".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.inputLayoutNameField(layoutName);
                    DefLayoutPage.selectStartOrEndLine(colStartPosi);
                    DefLayoutPage.selectStartOrEndLine(colEndPosi);
                    DefLayoutPage.clickGenerateFieldsBtn();
                    DefLayoutPage.selFieldType(fieldsInLayout);
                    DefLayoutPage.selectDataType(dataTypesPerField);
                    DefLayoutPage.clickContinueButton();
                    DefLayoutPage.clickContinueOnAlert();
                    Thread.sleep(3000);
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();
                    ProjDashBoardPage.clickInputTab();
                    Thread.sleep(3000);
                    ProjDashBoardPage.clickHomeTab();
                    Thread.sleep(3000);

                    driver.navigate()
                            .to("http://afnd1lc9a001.app.c9.equifax.com:9090/cms-fusion-web/project/dashboardtree?projectNumber=6000000&purgedJobs=&jqxMode=&purgedJobs=&projectNumber=6000000");
                    ProjDashBoardPage.inputProjNum(PropertiesUtils.getProperty("project"));
                    ProjDashBoardPage.clickCopyProjSrchBtn();
                    Thread.sleep(3000);
                    ProjDashBoardPage.selectCopyPrevProjProcName(procId);
                    ProjDashBoardPage.clickCopySelectBtn();
                    Thread.sleep(3000);
                    ProjDashBoardPage.clickInputTab();
                    // String copyStatus = IPHomePage.getStatusIP_1();
                    // commMethods.verifyString(StatusEnum.READY.name(), copyStatus.trim());
                    module.initializeDriver(driver);
                    module.selectEdit();
                    Thread.sleep(3000);
                    ImpNwFilPage.continueButton().click();
                    List<String> getDataTypesDisplayed = DefLayoutPage.getDataTypesDisplayed();
                    // String sheetDataTypes[] = dataTypesPerField.split(",");
                    for (int i = 0; i < getDataTypesDisplayed.size(); i++)
                    {
                        commMethods.verifyString(getDataTypesDisplayed.get(i), "Character");
                    }

                }

                else if ("IP_ID_1116".equalsIgnoreCase(tc_Id))
                {

                    DefLayoutPage.selectStartOrEndLine(colStartPosi);
                    DefLayoutPage.selectStartOrEndLine(colEndPosi);
                    DefLayoutPage.clickGenerateFieldsBtn();
                    List<String> listDataType = DefLayoutPage.getDataTypeDisplayedInGrid();
                    for (String s : listDataType)
                    {
                        commMethods.verifyString(s, "Character");
                    }
                    // DefLayoutPage.updateFieldValuesPerField(layoutFieldType, name, startPos, endPos, fieldLength);
                }

                else if ("IP_ID_1117".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.inputLayoutNameField(layoutName);

                    DefLayoutPage.selectStartOrEndLine(colStartPosi);
                    // ColLine class should be present for td if that is selected
                    Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colStartPosi).contains("colLine"));
                    DefLayoutPage.selectStartOrEndLine(colEndPosi);
                    Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colEndPosi).contains("colLine"));
                    DefLayoutPage.clickGenerateFieldsBtn();
                    // DefLayoutPage.updateFieldValuesPerField(layoutFieldType, name, startPos, endPos, fieldLength);
                    // DefLayoutPage.selFieldTypeNew(fieldsInLayout);
                    DefLayoutPage.selFieldType(fieldsInLayout);
                    DefLayoutPage.selectDataType(dataTypesPerField);

                    // DefLayoutPage.selUserDefinedName(userDefName);

                    // DefLayoutPage.selDataType(dataTypesPerField);
                    // DefLayoutPage.clickSaveBtn();
                    DefLayoutPage.clickContinueButton();
                    Thread.sleep(3000);
                    DefLayoutPage.clickContinueOnAlert();
                    Thread.sleep(5000);
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();

                    summaryPage.clickSubmitButton();
                    Thread.sleep(6000);
                    status = module.getStatusIP();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    Thread.sleep(3000);
                    String procName1 = ProjDashBoardPage.jobName();
                    String Status;
                    Status = ProjDashBoardPage.verifyProcess(procName1);
                    commMethods.verifyString(Status, "FAIL");
                    Thread.sleep(3000);
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                    Thread.sleep(3000);

                    String workItem = driver.findElement(
                            By.xpath("//h3[contains(text(),'Error/Warnings Stats')]/following::div/div/table/tbody/tr/td[3]")).getText();
                    commMethods.verifyboolean(workItem.contains("IN_PREPARE"), true);
                    String errorMsg = driver.findElement(
                            By.xpath("//h3[contains(text(),'Error/Warnings Stats')]/following::div/div/table/tbody/tr[2]/td[3]")).getText();
                    commMethods.verifyboolean(
                            errorMsg.contains("for the field FIRST_NAME is not matching at line number 1 with NUMBER datatype for item IN_PREPARE"),
                            true);

                    // commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");

                }

                else if ("IP_ID_1121".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.inputLayoutNameField(layoutName);
                    DefLayoutPage.selectSequentialColStartPos(colStartPosi);
                    DefLayoutPage.selectSequentialColEndPos(colEndPosi);

                    DefLayoutPage.clickGenerateFieldsBtn();
                    // DefLayoutPage.updateFieldValuesPerField(layoutFieldType, name, startPos, endPos, fieldLength);
                    // DefLayoutPage.selFieldTypeNew(fieldsInLayout);
                    DefLayoutPage.selFieldType(fieldsInLayout);
                    DefLayoutPage.selectDataType(dataTypesPerField);

                    // DefLayoutPage.selUserDefinedName(userDefName);

                    // DefLayoutPage.selDataType(dataTypesPerField);
                    // DefLayoutPage.clickSaveBtn();
                    DefLayoutPage.clickContinueButton();
                    DefLayoutPage.clickContinueOnAlert();
                    Thread.sleep(3000);
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();

                    summaryPage.clickSubmitButton();
                    Thread.sleep(5000);
                    status = module.getStatusIP();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    Thread.sleep(3000);
                    String procName1 = ProjDashBoardPage.jobName();
                    String Status;
                    Status = ProjDashBoardPage.verifyProcess(procName1);
                    commMethods.verifyString(Status, "PASS");
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                }

                else if ("IP_ID_1120".equalsIgnoreCase(tc_Id))
                {

                    DefLayoutPage.inputLayoutNameField(layoutName);

                    DefLayoutPage.selFieldTypesForDelimitedSelection(fieldsInLayout);
                    DefLayoutPage.updateUserDefinedNameForDelimitedFormat(colUserDefName);
                    DefLayoutPage.updateDataTypeForDelimitedFormat(dataTypesPerField);
                    DefLayoutPage.clickContinueButton();
                    // DefLayoutPage.clickContinueOnAlert();
                    Thread.sleep(3000);
                    // DataChckPage.clickDataCheckCheckbox(dataChck);
                    // DataChckPage.clickContinueButton();

                    summaryPage.clickSubmitButton();
                    Thread.sleep(5000);
                    status = module.getStatusIP();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    Thread.sleep(3000);
                    String procName1 = ProjDashBoardPage.jobName();
                    String Status;
                    Status = ProjDashBoardPage.verifyProcess(procName1);
                    commMethods.verifyString(Status, "FAIL");
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);

                    String workItem = driver.findElement(By.xpath("//div[@id='jqxWarnings']/div/div/div/table/tbody/tr[1]/td")).getText();
                    commMethods.verifyboolean(workItem.contains("IN_PREPARE"), true);
                    String errorMsg = driver.findElement(
                            By.xpath("//h3[contains(text(),'Error/Warnings Stats')]/following::div/div/table/tbody/tr[2]/td[3]")).getText();
                    commMethods.verifyboolean(
                            errorMsg.contains("for the field CID1 is not matching at line number 1 with NUMBER datatype for item IN_PREPARE"), true);

                    // commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");

                } else if ("IP_ID_1122".equalsIgnoreCase(tc_Id))
                {

                    DefLayoutPage.inputLayoutNameField(layoutName);

                    // DefLayoutPage.updateFieldsForDelimitedFormat(fieldsInLayout);
                    // String[] values = null;
                    // values = fieldsInLayout.split(",");

                    // provide values to the textboxes same as the fields
                    DefLayoutPage.selFieldTypesForDelimitedSelection(fieldsInLayout);
                    driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();
                    DefLayoutPage.clickSaveBtn();
                    List<String> userDefList = DefLayoutPage.getUseDefSelections();
                    commMethods.verifyString(userDefList.get(0), "CID_1");
                    commMethods.verifyString(userDefList.get(1), "CID_2");
                    // DefLayoutPage.updateFieldsForDelimitedFormat(fieldsInLayout);
                    // DefLayoutPage.updateParticularField("Other", 3);
                    // DefLayoutPage.updateParticularField("CID", 4);
                    //
                    // String str = DefLayoutPage.getDataFieldValue(4);
                    // commMethods.verifyString(str, "CID_3");

                } else if ("IP_ID_1125".equalsIgnoreCase(tc_Id))
                {

                    DefLayoutPage.inputLayoutNameField(layoutName);

                    DefLayoutPage.selectFieldTypeForDelimiter(fieldsInLayout);
                    driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();

                    DefLayoutPage.updateFieldTypeForDelimiter("Other", 3);
                    driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();
                    DefLayoutPage.updateFieldTypeForDelimiter("CID", 4);
                    driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();

                    String str = driver.findElement(By.xpath("//div[@id='row1layoutgrid']/div[4]/div")).getText();
                    commMethods.verifyString(str, "CID_3");

                } else if ("IP_ID_1119".equalsIgnoreCase(tc_Id))
                {

                    DefLayoutPage.selectStartOrEndLine(colStartPosi);
                    DefLayoutPage.selectStartOrEndLine(colEndPosi);
                    DefLayoutPage.clickGenerateFieldsBtn();
                    // DefLayoutPage.selFieldType(fieldsInLayout);
                    DefLayoutPage.selectDataType(dataTypesPerField);
                    // DefLayoutPage.updateFieldValuesPerField(layoutFieldType, name, startPos, endPos, fieldLength);
                } else if ("IP_ID_003".equalsIgnoreCase(tc_Id))
                {
                    LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                    LayoutImpPage.inputUserDefinedName(colUserDefName);
                    LayoutImpPage.clickContinueButton();
                    String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/h3")).getText();
                    commMethods.verifyString(pageTitle, "Layout Definition Complete the required information, and then click Continue.");
                } else if ("IP_ID_048".equalsIgnoreCase(tc_Id))
                {
                    LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                    Thread.sleep(2000);
                    LayoutImpPage.inputUserDefinedName(colUserDefName);
                    LayoutImpPage.clickContinueButton();
                    commMethods.verifyboolean(driver.findElement(By.id("headerLines")).isDisplayed(), true);
                    /*
                     * DefLayoutPage.selHeaderRows("1"); driver.findElement(By.xpath("//span[contains(text(),'Yes')]")).click();
                     */
                } else if ("IP_ID_044".equalsIgnoreCase(tc_Id))
                {
                	Thread.sleep(5000);
                    String lName = driver.findElement(By.xpath(".//*[@id='layoutName']")).getAttribute("value");
                    commMethods.verifyString(lName, layoutName);
                } else if ("IP_ID_101".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.Ele_LayoutName.clear();
                    DefLayoutPage.Ele_LayoutName.sendKeys("20170925133900");
                    DefLayoutPage.clickContinueButton();
                    DefLayoutPage.clickContinueOnAlert();
                    // DefLayoutPage.clickContinueAnyway();
                    String errMsg = driver.findElement(By.xpath("//h3[1]/following::div[2]/span")).getText();
                    System.out.println(errMsg);
                    commMethods.verifyboolean(errMsg.contains("exists in project. Please rename."), true);
                } else if ("IP_ID_150".equalsIgnoreCase(tc_Id))
                {
                    // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                    LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                    Thread.sleep(2000);
                    LayoutImpPage.inputUserDefinedName(colUserDefName);
                    LayoutImpPage.inputStartPosition(colStartPosi);
                    LayoutImpPage.inputEndPosition(colEndPosi);
                    LayoutImpPage.clickContinueButton();
                    DefLayoutPage.selFieldType(fieldsInLayout);
                    // new
                    // Select(driver.findElement(By.xpath(".//*[@id='fieldTable']/tbody/tr[1]/td[1]/select"))).selectByVisibleText("Customize...");
                    // commMethods.verifyboolean(driver.findElement(By.xpath("//label[contains(text(),'MLA Transaction ID')]")).isDisplayed(), true);
                } else if ("IP_ID_1123".equalsIgnoreCase(tc_Id) || "IP_ID_1124".equalsIgnoreCase(tc_Id))
                {
                    Thread.sleep(3000);
                    LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                    Thread.sleep(2000);
                    LayoutImpPage.inputUserDefinedName(colUserDefName);
                    LayoutImpPage.inputStartPosition(colStartPosi);
                    LayoutImpPage.inputEndPosition(colEndPosi);
                    Thread.sleep(3000);
                    LayoutImpPage.clickContinueButton();
                    Thread.sleep(3000);
                    DefLayoutPage.updateLengthForAgeField();
                    DefLayoutPage.updateDatatTypeToHexForAgeField();

                    DefLayoutPage.clickSaveBtn();

                    Thread.sleep(1000);
                    commMethods.verifyString(driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']/span")).getText(),
                            "Error: Field OTHER exceeds the maximum allowable length of 8 for data type Hex Number.");
                    // String str = driver.findElement(By.xpath("//div[@id='jqxInvalidLength']/div/div[2]")).getText();
                    // commMethods.verifyboolean(
                    // str.contains("The Length entered is incorrect according to the Start/End positions for the follwing fields"), true);
                    //
                    // driver.findElement(By.xpath("//div[@id='jqxInvalidLength']/div/div[2]/div[@class='warningbtn']/input[2]")).click();
                    //
                    DefLayoutPage.clickContinueButton();
                    // String strCon = driver.findElement(By.xpath("//div[@id='jqxInvalidLength']/div/div[2]")).getText();
                    // commMethods.verifyboolean(
                    // strCon.contains("The Length entered is incorrect according to the Start/End positions for the follwing fields"), true);
                    commMethods.verifyString(driver.findElement(By.xpath("//div[@class='errMsg errMsgExt']/span")).getText(),
                            "Error: Field OTHER exceeds the maximum allowable length of 8 for data type Hex Number.");
                }

                else
                {
                    // Layout Import & Define Layout Page:
                    if (layoutType.equalsIgnoreCase("Import Layout")

                    && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC FIXED")))
                    {
                        // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                        LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                        Thread.sleep(2000);
                        LayoutImpPage.inputUserDefinedName(colUserDefName);
                        LayoutImpPage.inputStartPosition(colStartPosi);
                        LayoutImpPage.inputEndPosition(colEndPosi);
                        LayoutImpPage.clickContinueButton();
                        // DefLayoutPage.selectAllFields();
                        DefLayoutPage.selFieldType(fieldsInLayout);
                        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                        Date date = new Date();
                        DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
                        // added
                        if (!"NA".equalsIgnoreCase(dataTypesPerField))
                        {
                            DefLayoutPage.selDataType(dataTypesPerField);
                            // DefLayoutPage.selFieldType(fieldsInLayout);
                            // DefLayoutPage.selFieldTypeNew(fieldsInLayout);
                        }

                        // DefLayoutPage.updateDataTypeForDelimitedLayout();
                        DefLayoutPage.selectInvalidCharBlanks(transInvChar);
                        DefLayoutPage.constantField(addConst, constField, constValue);
                        if (!"NA".equalsIgnoreCase(addConst))
                        {
                            driver.findElement(By.id("addConstantField")).click();
                            driver.findElement(By.xpath("//div[contains(text(),'File Name')]/following::div[3]")).click();
                            driver.findElement(By.id("removeConstantField")).click();
                        }

                    } else if (layoutType.equalsIgnoreCase("Import Layout") && Format.equalsIgnoreCase("ASCII Delimited"))
                    {
                        // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                        LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                        LayoutImpPage.inputUserDefinedName(colUserDefName);
                        LayoutImpPage.clickContinueButton();
                        // DefLayoutPage.selectAllFields_Delim();
                        // DefLayoutPage.selectFieldType_Delim(fieldsInLayout);
                        DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                        Date date = new Date();
                        DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
                        // DefLayoutPage.selFieldTypeForDelimiter(fieldsInLayout);
                        DefLayoutPage.updateDataTypeForDelimitedFormat(dataTypesPerField);
                        // DefLayoutPage.updateFieldsForDelimitedFormat(fieldsInLayout);
                        DefLayoutPage.selFieldTypesForDelimitedSelection(fieldsInLayout);
                        DefLayoutPage.updateDataTypeForDelimitedFormat(dataTypesPerField);
                        // DefLayoutPage.delimitedLayoutFieldsUpdateWithJqx(fieldsInLayout);
                        DefLayoutPage.selectInvalidCharBlanks(transInvChar);

                        // updateDataTypeForDelimitedFormat
                    }
                    if ("IP_ID_103".equalsIgnoreCase(tc_Id))
                    {
                        DefLayoutPage.clickSaveBtn();
                        // driver.switchTo().alert().accept();
                        Thread.sleep(2000);
                        String layoutNam = driver.findElement(By.id("layoutName")).getAttribute("value");
                        DefLayoutPage.clickBackBtn();
                        Thread.sleep(3000);
                        // LayoutImpPage.clickBackBtn();
                        String existLayout = driver.findElement(By.xpath(".//*[@id='savedLayoutsTable1']/tbody/tr[1]/td[2]")).getText().trim();
                        commMethods.verifyString(layoutNam, existLayout);
                    } else
                    {
                        Thread.sleep(2000);
                        DefLayoutPage.clickContinueButton();
                        Thread.sleep(3000);
                        DefLayoutPage.clickContinueOnAlert();
                        Thread.sleep(2000);

                        Thread.sleep(2000);
                        // DefLayoutPage.clickContinueButton();
                        Thread.sleep(3000);
                        if ("IP_ID_162".equalsIgnoreCase(tc_Id))
                        {
                            Thread.sleep(5000);
                            DataChckPage.clickDataCheckCheckbox(dataChck);
                            Thread.sleep(2000);

                            DataChckPage.clickSaveBtn();
                            Thread.sleep(3000);
                            ProjDashBoardPage.clickInputTab();
                            module.initializeDriver(driver);
                            status = module.getStatusIP();
                            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                            module.selectDuplicate();
                            status = module.getStatusIP();
                            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                            driver.navigate().refresh();
                            Thread.sleep(2000);
                            module.clickOnEdit();
                            String pageTitle = ProjDashBoardPage.getPageTitle();
                            commMethods.verifyString(pageTitle,
                                    "Import New File Specify a file; create, import, or search for a layout; and click Continue.");
                            ProjDashBoardPage.clickInputTab();
                            driver.navigate().refresh();
                            Thread.sleep(2000);
                            module.selectSummary();
                            pageTitle = ProjDashBoardPage.getPageTitle();
                            commMethods.verifyString(pageTitle,
                                    "Summary: Import New File\nReview the information below, and then click 'Back' or 'Submit' .");
                        } else
                        {
                            if (!"ASCII Delimited".equalsIgnoreCase(Format))
                            {
                                Thread.sleep(3000);
                                // Test
                                // String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
                                // commMethods.verifyString(pageTitle, "DataCheck Enter the required information, and then click Continue.");
                                DataChckPage.clickDataCheckCheckbox(dataChck);
                                DataChckPage.clickContinueButton();
                                Thread.sleep(3000);
                            }
                            if ("IP_ID_053".equalsIgnoreCase(tc_Id))
                            {
                                String invChar = driver
                                        .findElement(By.xpath("//label[contains(text(),'Translate Invalid Characters to Blank')]//following::td[1]"))
                                        .getText().trim();
                                if ("CHECK".equalsIgnoreCase(transInvChar))
                                {
                                    commMethods.verifyString(invChar, "Y");
                                } else if ("UNCHECK".equalsIgnoreCase(invChar))
                                {
                                    commMethods.verifyString(invChar, "N");
                                }
                            } else if ("IP_ID_002".equalsIgnoreCase(tc_Id))
                            {
                                LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
                                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                                LayoutImpPage.inputUserDefinedName(colUserDefName);
                                LayoutImpPage.inputStartPosition(colStartPosi);
                                LayoutImpPage.inputEndPosition(colEndPosi);
                                LayoutImpPage.clickContinueButton();
                                String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/h3")).getText();
                                commMethods.verifyString(pageTitle, "Layout Definition Complete the required information, and then click Continue.");
                            }

                            else if ("IP_ID_066".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                            } else if ("IP_ID_067".equalsIgnoreCase(tc_Id) || "IP_ID_036".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_037".equalsIgnoreCase(tc_Id) || "IP_ID_038".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_039".equalsIgnoreCase(tc_Id) || "IP_ID_040".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_041".equalsIgnoreCase(tc_Id) || "IP_ID_045".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_069".equalsIgnoreCase(tc_Id) || "IP_ID_070".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_071".equalsIgnoreCase(tc_Id) || "IP_ID_072".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_073".equalsIgnoreCase(tc_Id) || "IP_ID_074".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_075".equalsIgnoreCase(tc_Id) || "IP_ID_165".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_166".equalsIgnoreCase(tc_Id) || "IP_ID_164".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_167".equalsIgnoreCase(tc_Id) || "IP_ID_186".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_187".equalsIgnoreCase(tc_Id) || "IP_ID_189".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_174".equalsIgnoreCase(tc_Id) || "IP_ID_175".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_176".equalsIgnoreCase(tc_Id) || "IP_ID_177".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_179".equalsIgnoreCase(tc_Id) || "IP_ID_181".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_184".equalsIgnoreCase(tc_Id) || "IP_ID_185".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_170".equalsIgnoreCase(tc_Id) || "IP_ID_183".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_190".equalsIgnoreCase(tc_Id) || "IP_ID_178".equalsIgnoreCase(tc_Id)
                                    || "IP_ID_188".equalsIgnoreCase(tc_Id) || "IP_ID_168".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();
                                String procName1 = ProjDashBoardPage.jobName();
                                String Status;
                                Status = ProjDashBoardPage.verifyProcess(procName1);
                                commMethods.verifyString(Status, "PASS");
                                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                            } else if ("IP_ID_011".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();

                                String Status = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(Status, "PASS");
                                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                                Thread.sleep(2000);

                                //ProjDashBoardPage.viewStats(procId);
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                                
                                commMethods.verifyboolean(driver.findElement(By.xpath("//div[contains(text(),'CLEANSE')]")).isDisplayed(), true);

                            } else if ("DB_IP_001".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                ProjDashBoardPage.clickHomeTab();
                                ProjDashBoardPage.openProcessGearBox(procName);
                                ProjDashBoardPage.clickGearBoxCancel();
                                Thread.sleep(5000);
                                ProjDashBoardPage.clickConfirmationOK();
                                String proName = ProjDashBoardPage.jobName();
                                String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
                                commMethods.verifyString(finalStat, "CANCELLED");
                                ProjDashBoardPage.openProcessGearBox(procName);
                                commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);
                                LOGGER.info("Test execution completed successfully");
                            } else if ("IP_ID_027".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();
                                // CH:
                                /*
                                 * String procName1 = ProjDashBoardPage.jobName(); String Status; Status = ProjDashBoardPage.verifyProcess(procName1);
                                 * commMethods.verifyString(Status, "PASS"); commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                                 * ProjDashBoardPage.clickStatsView(procName1); driver.switchTo().frame("sb-player"); String OutputTableName =
                                 * statsView.getOutputTableNameIP(); Long constFldCountGP = statsView.getConstantCountFromGP(OutputTableName,
                                 * constValue); Long RecordCountStats = statsView.getLastRowCountStatsIP(); commMethods.verifyLong(RecordCountStats,
                                 * constFldCountGP); ProjDashBoardPage.closeStatsWindow();
                                 */
                            } else if ("IP_ID_012".equalsIgnoreCase(tc_Id) || "IP_ID_163".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();
                                String Status;
                                Status = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(Status, "PASS");
                                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                                // ProjDashBoardPage.viewStats(procId);
                                // driver.switchTo().frame("sb-player");
                                String OutputTableName = statsView.getOutputTableNameIP();
                                Long RecordCountStats = statsView.getLastRowCountStatsIP();
                                Long RecordCountGP = ProjDashBoardPage.getRecordsFromGP(OutputTableName);
                                commMethods.verifyLong(RecordCountStats, RecordCountGP);
                                ProjDashBoardPage.closeStatsWindow();
                            } else if ("IP_ID_016".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();
                                // String procName1 = ProjDashBoardPage.jobName();
                                String Status;
                                Status = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(Status, "PASS");
                                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                                // ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                                ProjDashBoardPage.viewStats(procId);
                                // driver.switchTo().frame("sb-player");
                                String OutputTableName = statsView.getOutputTableNameIP();
                                Long constFldCountGP = statsView.getConstantCountFromGP(OutputTableName, constValue);
                                Long RecordCountStats = statsView.getLastRowCountStatsIP();
                                commMethods.verifyLong(RecordCountStats, constFldCountGP);
                            } else if ("IP_ID_026".equalsIgnoreCase(tc_Id))
                            {
                                summaryPage.clickSubmitButton();
                                module.initializeDriver(driver);
                                status = module.getStatusIP();
                                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                                ProjDashBoardPage.clickHomeTab();
                                String Status;
                                Status = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(Status, "PASS");
                                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                                driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')]//preceding::span[1])[1]")).click();
                                Thread.sleep(2000);
                                driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')]//preceding::span[1])[2]")).click();
                                Thread.sleep(2000);
                                String in_prepare = driver.findElement(By.xpath("//span[contains(text(),'IN_PREPARE')]")).getText();
                                commMethods.verifyString(in_prepare, "IN_PREPARE");
                                String in_gpload = driver.findElement(By.xpath("//span[contains(text(),'IN_GPLOAD')]")).getText();
                                commMethods.verifyString(in_gpload, "IN_GPLOAD");
                            }
                        }
                    }
                }
            }
        }
    }

    // @Title("Input Process Regression Validation Tests")

    // public void IPValidations(String testRun, String tc_Id, String Desc, String copyProj, String copyProcName, String procName, String Type,
    // String Purpose, String Loc, String Format, String RecLength, String StartSeq, String opTblName, String srchProj, String srchLaytName,
    // String layoutType, String layoutName, String layoutFileLoc, String rowNoFirstField, String colUserDefName, String colStartPosi,
    // String colEndPosi, String fieldsInLayout, String transInvChar, String clickSelectsPos, String addConst, String constValue,
    // String layoutFieldType, String other_name, String startPos, String endPos, String fieldLength, String dataChck, String fileIden,
    // String maxNoBlank, String maxNoSingle, String maxNoUnknown, String runTimeB, ITestContext testContext) throws InterruptedException,
    // JSONException, SQLException, IOException

    @Test(dataProvider = "InputData_Validate", priority = 3, description = "Validating stuff", enabled=true)
    public void IPValidations(String TC, String testRun, String tc_Id, String Desc, String copyProj, String copyProcName, String procName, String Type,
            String Purpose, String Loc, String Format, String RecLength, String StartSeq, String opTblName, String srchProj, String srchLaytName,
            String layoutType, String layoutName, String layoutFileLoc, String rowNoFirstField, String colUserDefName, String colStartPosi,
            String colEndPosi, String dataTypesPerField, String fieldsInLayout, String transInvChar, String clickSelectsPos, String addConst,
            String constField, String constValue, String other_name, String startPos, String endPos, String fieldLength, String dataChck,
            String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown, String runTimeB, ITestContext testContext)
            throws InterruptedException, JSONException, SQLException, IOException
    {
        // testContext.setAttribute("WebDriver", driver);
        Modules module = new Modules();
        module.initializeDriver(driver);

        ProjDashBoardPage.clickInputTab();
        IPHomePage.ClickImportNewFile();
        ImpNwFilPage.processNameField(procName);
        ImpNwFilPage.typeField(Type);
        ImpNwFilPage.purposeField(Purpose);
        // ImpNwFilPage.filePathField().sendKeys(Loc);
        ImpNwFilPage.selectFileLocation(Loc);
        ImpNwFilPage.SelectFileFormat_Rad_But(Format);
        // Record length is a number in case of ascii formats
        if (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC Fixed"))
        {
            ImpNwFilPage.RecLengthField(RecLength);
        }
        // Record length is a delimiter in case of delimited formats
        if (Format.equalsIgnoreCase("ASCII Delimited"))
        {
            ImpNwFilPage.delimiterField(RecLength);
        }

        if (layoutType.equalsIgnoreCase("Import Layout"))
        {
            ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
            ImpNwFilPage.selectImportLayoutRbutton();
            LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
            ImpNwFilPage.continueButton().click();
        } else
        {
            Thread.sleep(2000);
            ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
            Thread.sleep(2000);
            ImpNwFilPage.clickCreateNewLayoutRButton();
            ImpNwFilPage.continueButton().click();
        }
        if ("IP_ID_033".equalsIgnoreCase(tc_Id) && Format.equalsIgnoreCase("EBCDIC Fixed") && layoutType.equalsIgnoreCase("Create New Layout"))
        {
            try
            {
                // DefLayoutPage.selectDataTypeForEbdcic("0");
                DefLayoutPage.selectDatatypeEbcdicFixed("Character", "0");
                DefLayoutPage.selectDatatypeEbcdicFixed("Hex String", "0");
                DefLayoutPage.selectDatatypeEbcdicFixed("Packed", "0");
                DefLayoutPage.selectDatatypeEbcdicFixed("Unsigned Packed", "0");
                DefLayoutPage.selectDatatypeEbcdicFixed("Hex Number", "0");
            } catch (Exception e)
            {
                Assert.assertFalse(false);
            }
        }

        if ("IP_ID_034".equalsIgnoreCase(tc_Id) && Format.equalsIgnoreCase("EBCDIC Fixed"))
        {
            // LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
            // Thread.sleep(2000);
            // LayoutImpPage.inputUserDefinedName(colUserDefName);
            // LayoutImpPage.inputStartPosition(colStartPosi);
            // LayoutImpPage.inputEndPosition(colEndPosi);
            // LayoutImpPage.clickContinueButton();
            // Thread.sleep(3000);
            DefLayoutPage.selectStartOrEndLine(colStartPosi);
            // ColLine class should be present for td if that is selected
            Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colStartPosi).contains("colLine"));
            DefLayoutPage.selectStartOrEndLine(colEndPosi);
            Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colEndPosi).contains("colLine"));
            DefLayoutPage.inputLayoutNameField(layoutName);

            DefLayoutPage.clickGenerateFieldsBtn();
            Thread.sleep(3000);
            DefLayoutPage.selFieldTypeNew(fieldsInLayout);
            Thread.sleep(3000);
            DefLayoutPage.updateDatatTypeToHexForFirstNameField();

            DefLayoutPage.clickSaveBtn();
            Thread.sleep(1000);
            // DefLayoutPage.clickContinueButton();
            // DefLayoutPage.clickContinueAnyway();
            Thread.sleep(3000);

            commMethods.verifyString(driver.findElement(By.xpath("//div[@class='rightContent']/div[2]/span[@id='textMsg']")).getText(),
                    "Error: Invalid input data for field type OTHER");
            // //
            // DefLayoutPage.selectDatatypeEbcdicFixed("Packed", "0");
            // // To avoid duplicate layout names, adding timestamp to the layout name provided in datasheet
            // DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            // Date date = new Date();
            // DefLayoutPage.inputLayoutNameField(layoutName + dateFormat.format(date));
            // DefLayoutPage.setValueStartPosTextBox(0, colStartPosi);
            // DefLayoutPage.setValueEndPosTextBox(0, colEndPosi);
            // String url = driver.getCurrentUrl();
            // DefLayoutPage.clickContinueButton();
            // String alertText = commMethods.acceptAlert();
            // if (DefLayoutPage.isLengthCorrectionPopUpVisible() == true)
            // {
            // DefLayoutPage.clickAutoCorrect();
            // }
            // if (DefLayoutPage.isAlertPopUpVisible() == true)
            // {
            // DefLayoutPage.clickContinueAnyway();
            // }
            // String error = driver.findElement(By.xpath("//div[@class='errMsg']/span")).getText();
            // System.out.println("error--->>" + error);
            // commMethods.verifyString("Error: Invalid Data Format", DefLayoutPage.getErrorText());
            // String url1 = driver.getCurrentUrl();
            // commMethods.verifyString(url1, url);

        }

        if ((Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC Fixed")) && layoutType.equalsIgnoreCase("Create New Layout"))
        {
            if ("IP_ID_005".equalsIgnoreCase(tc_Id) || "IP_ID_120".equalsIgnoreCase(tc_Id))
            {
                // Click Selects Position is Sequential Columns by default
                // Click on the grid acc to start position
                DefLayoutPage.selectStartOrEndLine(colStartPosi);
                // ColLine class should be present for td if that is selected
                Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colStartPosi).contains("colLine"));
                DefLayoutPage.selectStartOrEndLine(colEndPosi);
                Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colEndPosi).contains("colLine"));
                DefLayoutPage.clickGenerateFieldsBtn();
                commMethods.verifyLong(DefLayoutPage.getStartPosPerRowFromGrid(0).get(0), Long.valueOf(colStartPosi));
                commMethods.verifyLong(DefLayoutPage.getStartPosPerRowFromGrid(0).get(1), Long.valueOf(colEndPosi) - 1);

                commMethods.verifyLong(DefLayoutPage.getStartPosPerRowFromGrid(1).get(0), Long.valueOf(colEndPosi));
                commMethods.verifyLong(DefLayoutPage.getStartPosPerRowFromGrid(1).get(1), Long.valueOf(RecLength));
                // commMethods.verifyString(DefLayoutPage.getValueEndPosTextBox("2"), String.valueOf(Integer.parseInt(colEndPosi) - 1));
                // commMethods.verifyString(DefLayoutPage.getValueEndPosTextBox("3"), RecLength);

                // Field created with user defined name other and correct length
                if ("IP_ID_120".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyString(DefLayoutPage.getValueLengthTextBox("2"),
                            String.valueOf(Integer.parseInt(colEndPosi) - Integer.parseInt(colStartPosi)));
                    commMethods.verifyString(DefLayoutPage.getValueLengthTextBox("3"),
                            String.valueOf(Integer.parseInt(RecLength) - (Integer.parseInt(colEndPosi) - 1)));
                    commMethods.verifyString(DefLayoutPage.getValueUserDefinedNameTextBox("2"), "OTHER_1");
                    commMethods.verifyString(DefLayoutPage.getValueUserDefinedNameTextBox("3"), "OTHER_2");
                }
            }

            if ("IP_ID_004".equalsIgnoreCase(tc_Id) || "IP_ID_006".equalsIgnoreCase(tc_Id) || "IP_ID_008".equalsIgnoreCase(tc_Id)
                    || "IP_ID_009".equalsIgnoreCase(tc_Id) || "IP_ID_017".equalsIgnoreCase(tc_Id) || "IP_ID_119".equalsIgnoreCase(tc_Id))
            { // 008 , 009 , 017 , 019, 021, 023 removed in the new sheet

                // DefLayoutPage.selectSelectsPosAndSelectFromFbTable( colStartPosi, colEndPosi);
                DefLayoutPage.selectStartOrEndLine(colStartPosi);
                // ColLine class should be present for td if that is selected
                Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colStartPosi).contains("colLine"));
                DefLayoutPage.selectStartOrEndLine(colEndPosi);
                Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colEndPosi).contains("colLine"));

                DefLayoutPage.clickGenerateFieldsBtn();

                if ("IP_ID_004".equalsIgnoreCase(tc_Id) || "IP_ID_017".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyString(DefLayoutPage.getStartPosFromGrid(), colStartPosi);
                    commMethods.verifyString(DefLayoutPage.getEndPosFromGrid(), String.valueOf(Integer.parseInt(colEndPosi) - 1));
                }

                if ("IP_ID_119".equalsIgnoreCase(tc_Id))
                {
                    Thread.sleep(3000);
                    List<String> values = DefLayoutPage.getDefaultFieldsValues();
                    for (String s : values)
                    {
                        commMethods.verifyString(s, "Other");
                    }
                }

                if ("IP_ID_006".equalsIgnoreCase(tc_Id) || "IP_ID_008".equalsIgnoreCase(tc_Id) || "IP_ID_009".equalsIgnoreCase(tc_Id)
                        || "IP_ID_019".equalsIgnoreCase(tc_Id) || "IP_ID_021".equalsIgnoreCase(tc_Id) || "IP_ID_023".equalsIgnoreCase(tc_Id))
                {
                    // Validating "IP_ID_006" and "IP_ID_019"
                    try
                    {
                        // DefLayoutPage.selectFieldTypeFromFieldLayout_FixedOrDelimByPos(fieldsInLayout, 2);
                        DefLayoutPage.selFieldTypeNew(fieldsInLayout);
                        Assert.assertTrue(true);
                    } catch (Exception e)
                    {
                        Assert.assertFalse(false);
                    }
                    //
                    if ("IP_ID_008".equalsIgnoreCase(tc_Id) || "IP_ID_021".equalsIgnoreCase(tc_Id))
                    {
                        String[] fieldsInLayoutSplit = fieldsInLayout.split(",");
                        List<String> fieldNamesValue = new ArrayList<>();
                        // fieldNamesValue.add(DefLayoutPage.getValueUserDefinedNameTextBox(String.valueOf(i + 2)));
                        fieldNamesValue = DefLayoutPage.getUserDefNamesFromGrid();

                        DefLayoutPage.inputLayoutNameField(layoutName);

                        DefLayoutPage.clickPreviewBtn();
                        // if (DefLayoutPage.isAlertPopUpVisible() == true)
                        // {
                        // DefLayoutPage.clickContinueAnyway();
                        // }
                        for (int i = 0; i < fieldNamesValue.size(); i++)
                        {
                            String headingValue = DefLayoutPage.getTextFromHeadingPreview(i + 1);
                            commMethods.verifyString(headingValue, fieldNamesValue.get(i));
                        }
                    }

                    // if ("IP_ID_009".equalsIgnoreCase(tc_Id) || "IP_ID_023".equalsIgnoreCase(tc_Id)) {
                    // List<String> previewTextList = new
                    // }
                    // ArrayList<>(); String[] fieldsInLayoutSplit = fieldsInLayout.split(","); DefLayoutPage.clickPreviewBtn(); for (int i = 0; i <
                    // fieldsInLayoutSplit.length; i++) { previewTextList.add(DefLayoutPage.getTextFromHeadingPreview(i + 1)); } // Get the text from
                    // preview screen int i = 1, j = 1; while (commMethods.isElementPresent_Xpath(".//*[@id='testTable']/table/tbody/tr[" + i +
                    // "]/td[" + j + "]")) { while (commMethods.isElementPresent_Xpath(".//*[@id='testTable']/table/tbody/tr[" + i + "]/td[" + j +
                    // "]")) { previewTextList.add(DefLayoutPage.getTextForColumnsInRowsPreview(i, j)); j++; } i++; j = 1; }
                    // DefLayoutPage.clickClosePreviewBtn(); DefLayoutPage.clickGeneratePdfBtn(); // TODO ArrayList<String> windowHandles = new
                    // ArrayList<String>(driver.getWindowHandles()); String mainWindowHandle = driver.getWindowHandle(); for (String window :
                    // windowHandles) { // if it contains the current window we want to eliminate that from switchTo(); if (window !=
                    // mainWindowHandle) { // Now switchTo new Tab. // driver.switchTo().window(window); // TODO Get the text from generate pdf screen
                    // // Close the newly opened tab // driver.switchTo().window(mainWindowHandle); } } // TODO check in the new page values and
                    // compare with preview screen }

                }
            }
        }
        if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Create New Layout"))
        {
            // Ascii delimited
            if ("IP_ID_126".equalsIgnoreCase(tc_Id))
            {
                // DefLayoutPage.selectFieldTypeForDelimiter(fieldsInLayout);
                // Verify that there is a scrollbar for the table
                commMethods
                        .verifyString(DefLayoutPage.checkScrollPresent(), "visibility: hidden; height: 13px; top: 95px; left: 0px; width: 9178px;");
                // String[] splitFirstLineStr = fieldsInLayout.split(",");
                // // Verify that all id's are present and are visible on the screen
                // for (int i = 1; i <= splitFirstLineStr.length; i++)
                // {
                // Assert.assertTrue(DefLayoutPage.getFieldTypeById(i).isDisplayed());
                // }
            }
            if ("IP_ID_049".equalsIgnoreCase(tc_Id))
            {
                List<String> arrList = new ArrayList<>();
                arrList = commMethods.readFile(Loc);
                String[] splitFirstLineStr = commMethods.splitString(arrList.get(0), RecLength);

                // IP_ID_047 Validate that for ASCII delimited file there is "Generate PDF" button clicking on which PDF is opened in the new window
                // and displays the first five and last five records as shown in preview pop up window
                // Checking until pdf opens properly, rest will be done manually
                if ("IP_ID_049".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.inputLayoutNameField(layoutName);
                    DefLayoutPage.clickPreviewBtn();
                    String firstRow = DefLayoutPage.getTextForRowPreview(1);
                    firstRow = firstRow.replaceAll("\\s+", " ");
                    String firstLine = arrList.get(0);
                    firstLine = firstLine.replaceAll(",", " ");
                    firstLine = firstLine.replaceAll("\\s+", " ");
                    commMethods.verifyString(firstRow, firstLine);

                    String lastRow = DefLayoutPage.getTextForRowPreview(10);
                    lastRow = lastRow.replaceAll("\\s+", " ");
                    String lastLine = arrList.get(arrList.size() - 1);
                    lastLine = lastLine.replaceAll(",", " ");
                    lastLine = lastLine.replaceAll("\\s+", " ");
                    commMethods.verifyString(lastRow, lastLine);
                    DefLayoutPage.clickClosePreviewBtn();
                    DefLayoutPage.clickGeneratePdfBtn();
                    ArrayList<String> windowHandles = new ArrayList<String>(driver.getWindowHandles());
                    String mainWindowHandle = driver.getWindowHandle();
                    for (String window : windowHandles)
                    {
                        if (window != mainWindowHandle)
                        { // Now switchTo new Tab.
                            driver.switchTo().window(window);
                            Assert.assertEquals("Pdf window open", "Pdf window open");
                        }
                    }
                }

            }

            if ("IP_ID_127".equalsIgnoreCase(tc_Id))
            {
                // ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);
                // Thread.sleep(2000);
                // ImpNwFilPage.clickCreateNewLayoutRButton();
                // ImpNwFilPage.continueButton().click();
                DefLayoutPage.inputLayoutNameField(layoutName);

                DefLayoutPage.selectFieldTypeForDelimiter(fieldsInLayout);
                driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();

                DefLayoutPage.updateFieldTypeForDelimiter("CID", 1);
                // driver.findElement(By.xpath("//*[@id='row3layoutgrid']/div/div")).click();

            }

        }

        if ("IP_ID_151".equalsIgnoreCase(tc_Id) || "IP_ID_152".equalsIgnoreCase(tc_Id) || "IP_ID_153".equalsIgnoreCase(tc_Id)
                || "IP_ID_154".equalsIgnoreCase(tc_Id) || "IP_ID_051".equalsIgnoreCase(tc_Id) || "IP_ID_088".equalsIgnoreCase(tc_Id)
                || "IP_ID_058".equalsIgnoreCase(tc_Id) || "IP_ID_064".equalsIgnoreCase(tc_Id))
        {
            if ("IP_ID_051".equalsIgnoreCase(tc_Id) && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC Fixed")))
            {
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                Thread.sleep(3000);
                DefLayoutPage.clickContinueButton();
                DefLayoutPage.clickContinueAnyway();
                Thread.sleep(3000);
            }
            if ("IP_ID_152".equalsIgnoreCase(tc_Id) || "IP_ID_153".equalsIgnoreCase(tc_Id) || "IP_ID_154".equalsIgnoreCase(tc_Id))
            {
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                Thread.sleep(3000);
                if ("IP_ID_152".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.clickGeneratePdfBtn();
                    // DefLayoutPage.clickContinueAnyway();
                    ArrayList<String> windowHandles = new ArrayList<String>(driver.getWindowHandles());
                    String mainWindowHandle = driver.getWindowHandle();
                    for (String window : windowHandles)
                    {
                        if (window != mainWindowHandle)
                        { // Now switchTo new Tab.
                            driver.switchTo().window(window);
                            Assert.assertEquals("Pdf window open", "Pdf window open");
                        }
                    }
                }
                if ("IP_ID_153".equalsIgnoreCase(tc_Id))
                {
                    // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
                    DefLayoutPage.selFieldType(fieldsInLayout);
                    DefLayoutPage.clickContinueButton();
                    DefLayoutPage.clickContinueAnyway();
                    Thread.sleep(2000);
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();
                    Thread.sleep(2000);
                    summaryPage.clickSInputFileRef();
                    Thread.sleep(2000);
                    Assert.assertTrue(driver.findElement(By.xpath("//*td[contains(text(),'MLA_')]")).getText().equalsIgnoreCase("MLA_TRANSACTION_ID"));

                }
                if ("IP_ID_154".equalsIgnoreCase(tc_Id))
                {
                    DefLayoutPage.clickContinueButton();
                    DefLayoutPage.clickContinueAnyway();
                    Thread.sleep(2000);
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();
                    Thread.sleep(2000);

                    Thread.sleep(2000);
                    summaryPage.clickSubmitButton();
                    module.initializeDriver(driver);
                    String status = module.getStatusIP();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    String procName1 = ProjDashBoardPage.jobName();
                    String Status;
                    Status = ProjDashBoardPage.verifyProcess(procName1);
                    commMethods.verifyString(Status, "PASS");
                    commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                    // ProjDashBoardPage.clickStatsView(procName1);
                    ProjDashBoardPage.viewStats(procName1);
                    Thread.sleep(2000);
                    String opTableName = statsView.getOutputTableNameIP();
                    Thread.sleep(2000); // I86292_IN_GPLOAD_INPUT
                    List<String> columnNamesString = statsView.getColumnNamesFromGP(opTableName);
                    Thread.sleep(4000);
                    Assert.assertTrue(columnNamesString.contains("mla_transaction_id"));
                }
            }
            if ("IP_ID_064".equalsIgnoreCase(tc_Id) && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC Fixed")))
            {
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                Thread.sleep(3000);
                // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
                DefLayoutPage.selFieldType(fieldsInLayout);
                Thread.sleep(3000);
                DefLayoutPage.clickContinueButton();
                DefLayoutPage.clickContinueAnyway();
                Thread.sleep(3000);
            }
            if ("IP_ID_058".equalsIgnoreCase(tc_Id) || "IP_ID_088".equalsIgnoreCase(tc_Id))
            {
                // DefLayoutPage.selectStartOrEndLine(colStartPosi);
                // ColLine class should be present for td if that is selected
                // Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colStartPosi).contains("colLine"));
                DefLayoutPage.selectStartOrEndLine(colEndPosi);
                // Assert.assertTrue(DefLayoutPage.getClassNameForColumnInGrid(colEndPosi).contains("colLine"));
                DefLayoutPage.clickGenerateFieldsBtn();
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                Date date = new Date();
                DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
                // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
                DefLayoutPage.selFieldType(fieldsInLayout);
                Thread.sleep(3000);
                DefLayoutPage.clickContinueButton();
                // DefLayoutPage.clickContinueAnyway();
                Thread.sleep(3000);
            }

            // if ("IP_ID_088".equalsIgnoreCase(tc_Id))
            // {
            // DefLayoutPage.selectSelectsPosAndSelectFromFbTable(clickSelectsPos, colStartPosi, colEndPosi);
            // DefLayoutPage.clickGenerateFieldsBtn();
            //
            // DefLayoutPage.selFieldTypeNew(fieldsInLayout);
            //
            // }
            if ("IP_ID_151".equalsIgnoreCase(tc_Id))
            {
                LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
                Thread.sleep(2000);
                LayoutImpPage.inputUserDefinedName(colUserDefName);
                LayoutImpPage.inputStartPosition(colStartPosi);
                LayoutImpPage.inputEndPosition(colEndPosi);
                LayoutImpPage.clickContinueButton();
                Thread.sleep(3000);
                // DefLayoutPage.inputLayoutNameField(layoutName);
                DefLayoutPage.clickPreviewBtn();
                if (DefLayoutPage.isAlertPopUpVisible() == true)
                {
                    DefLayoutPage.clickContinueAnyway();
                }
                Thread.sleep(1000);
                DefLayoutPage.moveScrollbarHorizontaly();

                Assert.assertTrue(DefLayoutPage.getTextFromHeadingPreview().equalsIgnoreCase("MLA_TRANSACTION_ID"));
            }
            // Common code for all test cases
            // To avoid duplicate layout names, adding timestamp to the layout name provided in datasheet
            if (!"IP_ID_051".equalsIgnoreCase(tc_Id) && !"IP_ID_058".equalsIgnoreCase(tc_Id) && !"IP_ID_064".equalsIgnoreCase(tc_Id)
                    && !"IP_ID_151".equalsIgnoreCase(tc_Id) && !"IP_ID_152".equalsIgnoreCase(tc_Id) && !"IP_ID_153".equalsIgnoreCase(tc_Id)
                    && !"IP_ID_154".equalsIgnoreCase(tc_Id) && !"IP_ID_088".equalsIgnoreCase(tc_Id))
            {
                DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
                Date date = new Date();
                DefLayoutPage.inputLayoutNameField(layoutName + dateFormat.format(date));
                // Go to datacheck page
                // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
                DefLayoutPage.selFieldType(fieldsInLayout);
                DefLayoutPage.clickContinueButton();
                DefLayoutPage.clickContinueAnyway();
            }//
             // if (DefLayoutPage.isLengthCorrectionPopUpVisible() == true)
             // {
             // DefLayoutPage.clickAutoCorrect();
             // }
             // if (DefLayoutPage.isAlertPopUpVisible() == true)
             // {
             // DefLayoutPage.clickContinueAnyway();
             // }

            // Test cases requiring datacheck values to be filled
            if ("IP_ID_058".equalsIgnoreCase(tc_Id))
            {
                DataChckPage.clickDataCheckCheckbox(dataChck);
                DataChckPage.clickContinueButton();
                Thread.sleep(3000);
                summaryPage.clickSInputFileRef();
                String arrFields[] = fieldsInLayout.split(",");
                List<String> values = summaryPage.getSummaryFields();
                System.out.println("Value 1----->>" + values.get(0));
                System.out.println("Value 2----->>" + values.get(1));
                for (int i = 0; i < values.size(); i++)
                {
                    commMethods.verifyboolean(values.get(i).equalsIgnoreCase(arrFields[i]), true);
                }

                // summaryPage.clickSubmitButton();
                // module.initializeDriver(driver);
                // String status = module.getStatusIP();
                // commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                // ProjDashBoardPage.clickHomeTab();
                // String procName1 = ProjDashBoardPage.jobName();
                // String Status;
                // Status = ProjDashBoardPage.verifyProcess(procName1);
                // commMethods.verifyString(Status, "PASS");
                // commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
            }
            if ("IP_ID_064".equalsIgnoreCase(tc_Id))
            {
                DataChckPage.selectFileIdentifier(fileIden);
                DataChckPage.maxNoBlankFlds(maxNoBlank);
                DataChckPage.maxNoSingleFlds(maxNoSingle);
                if (!"NA".equalsIgnoreCase(runTimeB))
                {
                    DataChckPage.selectRunTimeB("201702021506");
                }

                DataChckPage.maxNoUnknwonFlds(maxNoUnknown);
                DataChckPage.clickContinueButton();
                Thread.sleep(3000);
                summaryPage.clickSubmitButton();
                module.initializeDriver(driver);
                String status = module.getStatusIP();
                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                ProjDashBoardPage.clickHomeTab();
                String procName1 = ProjDashBoardPage.jobName();
                String Status;
                Status = ProjDashBoardPage.verifyProcess(procName1);
                commMethods.verifyString(Status, "PASS");
                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                // ProjDashBoardPage.clickStatsView(procName1);
                ProjDashBoardPage.clickTreeV2statsViewForChrome(procName1);
                // driver.switchTo().frame("sb-player");
            } else
            {
                // if (DefLayoutPage.isLengthCorrectionPopUpVisible() == true)
                // {
                // DefLayoutPage.clickAutoCorrect();
                // }
                // if (DefLayoutPage.isAlertPopUpVisible() == true)
                // {
                // DefLayoutPage.clickContinueAnyway();
                // }
                // For rest of the test cases
                if (!"IP_ID_151".equalsIgnoreCase(tc_Id) && !"IP_ID_152".equalsIgnoreCase(tc_Id) && !"IP_ID_153".equalsIgnoreCase(tc_Id)
                        && !"IP_ID_154".equalsIgnoreCase(tc_Id) && !"IP_ID_058".equalsIgnoreCase(tc_Id) && !"IP_ID_064".equalsIgnoreCase(tc_Id))
                {
                    DataChckPage.clickDataCheckCheckbox(dataChck);
                    DataChckPage.clickContinueButton();
                }
            }

            if ("IP_ID_064".equalsIgnoreCase(tc_Id))
            {
                Thread.sleep(1000);
                statsView.clickCompareReport();
                Thread.sleep(1000);
                Assert.assertNotEquals(statsView.getRunTimeValuesA(), statsView.getRunTimeValuesB());
            }

            // Go To summary page

            // Test case 088 continued
            if ("IP_ID_088".equalsIgnoreCase(tc_Id))
            {
                summaryPage.clickSInputFileRef();
                // String[] fieldsInLayoutSplit = fieldsInLayout.split(",");
                // for (int i = 1; i < fieldsInLayoutSplit.length; i++)
                // {
                // commMethods.verifyContainsString(summaryPage.getFieldTypesFromSummaryTable(i), fieldsInLayoutSplit[i - 1]);
                // }
                String arrFields[] = fieldsInLayout.split(",");
                List<String> values = summaryPage.getSummaryFields();
                // values.get(0).toUpperCase();
                System.out.println("Value 1----->>" + values.get(0));
                System.out.println("Value 2----->>" + values.get(1));

                List<String> fieldValues = summaryPage.splitField(values);
                for (int i = 0; i < values.size(); i++)
                {

                    commMethods.verifyboolean(arrFields[i].equalsIgnoreCase(fieldValues.get(i)), true);
                }
            }

            // Once the process is completed
            if ("IP_ID_051".equalsIgnoreCase(tc_Id))
            {
                // Submit the output process

                summaryPage.clickSubmitButton();
                module.initializeDriver(driver);
                String status = module.getStatusIP();
                commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                ProjDashBoardPage.clickHomeTab();
                String procName1 = ProjDashBoardPage.jobName();
                String Status;
                Status = ProjDashBoardPage.verifyProcess(procName1);
                commMethods.verifyString(Status, "PASS");
                commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
                // ProjDashBoardPage.clickStatsView(procName1);
                // ProjDashBoardPage.viewStats(procName1);
                // driver.switchTo().frame("sb-player");
                //
                // if ("IP_ID_051".equalsIgnoreCase(tc_Id))
                // {
                // String filePath = statsView.getInPrepareFileNameIP();
                // List<String> lines = commMethods.readFile(filePath);
                // // Check first line starts with the sequence number
                // Assert.assertTrue(lines.get(0).toString().substring(0, 11).contains(StartSeq));
                // // Check number of records in created file is same as in input file
                // List<String> linesIPFile = commMethods.readFile(Loc);
                // commMethods.verifyInt(linesIPFile.size(), lines.size());

            }
        }

    }

    // (String tc_Id, String testRun, String TC, String Desc, String copyProj, String copyProcName, String procName,
    // String Type, String Purpose, String Loc, String Format, String RecLength, String StartSeq, String opTblName, String srchProj,
    // String srchLaytName, String layoutType, String layoutName, String layoutFileLoc, String rowNoFirstField, String colUserDefName,
    // String colStartPosi, String colEndPosi, String fieldsInLayout, String transInvChar, String addConst, String constValue, String dataChck,
    // String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown, String runTimeB, ITestContext testContext)
    // throws InterruptedException
    //
   @Test(dataProvider = "InputData_Reg", priority = 1, description = "Base processes for all the post processes", enabled = false)
    public void ipBaseProcesses(String testCase, String testRun, String tc_Id, String Desc, String copyProj, String copyProcName, String procName,
            String Type, String Purpose, String Loc, String Format, String RecLength, String StartSeq, String opTblName, String srchProj,
            String srchLaytName, String layoutType, String layoutName, String layoutFileLoc, String rowNoFirstField, String colUserDefName,
            String colStartPosi, String colEndPosi, String dataTypesPerField, String fieldsInLayout, String transInvChar, String clickSelectsPos,
            String addConst, String constantField, String constValue, String other_name, String startPos, String endPos, String fieldLength,
            String dataChck, String fileIden, String maxNoBlank, String maxNoSingle, String maxNoUnknown, String runTimeB, ITestContext testContext)
            throws InterruptedException, JSONException, SQLException, IOException
    {

        ProjDashBoardPage.clickHomeTab();
        testContext.setAttribute("WebDriver", driver);
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        ProjDashBoardPage.clickInputTab();
        IPHomePage.ClickImportNewFile();
        String procId = ImpNwFilPage.getProcId();
        ImpNwFilPage.processNameField(procName);
        ImpNwFilPage.typeField(Type);
        ImpNwFilPage.purposeField(Purpose);
        // ImpNwFilPage.filePathField().sendKeys(Loc);
        ImpNwFilPage.SelectFileFormat_Rad_But(Format);
        ImpNwFilPage.filePaths(Loc);
        ImpNwFilPage.startSeqNumField().sendKeys(StartSeq);

        if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Existing Layout"))
        {
            ImpNwFilPage.aSCIIFixedRbutton().click();
            ImpNwFilPage.RecLengthField(RecLength);
            ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
        } else if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Create New Layout"))
        {
            ImpNwFilPage.aSCIIFixedRbutton().click();
            ImpNwFilPage.RecLengthField(RecLength);
            // ImpNwFilPage.SelectExisLay_Rad_But(layoutName);

        } else if (Format.equalsIgnoreCase("EBCDIC FIXED") && layoutType.equalsIgnoreCase("Existing Layout"))
        {
            ImpNwFilPage.eBCDICRbutton().click();
            ImpNwFilPage.RecLengthField(RecLength);
            ImpNwFilPage.SelectExisLay_Rad_But(layoutName);

        } else if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Existing Layout"))
        {
            ImpNwFilPage.delimitedRbutton().click();
            ImpNwFilPage.SelectExisLay_Rad_But(layoutName);
            ImpNwFilPage.delimiterField(RecLength);
        } else if (Format.equalsIgnoreCase("ASCII Fixed") && layoutType.equalsIgnoreCase("Import Layout"))
        {
            ImpNwFilPage.aSCIIFixedRbutton().click();
            ImpNwFilPage.RecLengthField(RecLength);
            ImpNwFilPage.selectImportLayoutRbutton();
            LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
        } else if (Format.equalsIgnoreCase("EBCDIC FIXED") && layoutType.equalsIgnoreCase("Import Layout"))
        {
            ImpNwFilPage.eBCDICRbutton().click();
            ImpNwFilPage.RecLengthField(RecLength);
            ImpNwFilPage.selectImportLayoutRbutton();
            LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
        } else if (Format.equalsIgnoreCase("ASCII Delimited") && layoutType.equalsIgnoreCase("Import Layout"))
        {
            ImpNwFilPage.delimitedRbutton().click();
            ImpNwFilPage.selectImportLayoutRbutton();
            ImpNwFilPage.delimiterField(RecLength);
            LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
        }
        ImpNwFilPage.continueButton().click();

        if (layoutType.equalsIgnoreCase("Create New Layout") && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC FIXED")))
        {
            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
            Date date = new Date();
            if("NA".equalsIgnoreCase(layoutName))
            	DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
            else
                DefLayoutPage.inputLayoutNameField(layoutName+"."+dateFormat.format(date));
            String[] positions = colStartPosi.split(",");
            int i = 0;
            while (i < positions.length)
            {
                DefLayoutPage.selectStartOrEndLine(positions[i]);
                Thread.sleep(1000);
                i++;

            }

            // ColLine class should be present for td if that is selected

            DefLayoutPage.clickGenerateFieldsBtn();
            // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
            DefLayoutPage.selFieldType(fieldsInLayout);
            Thread.sleep(3000);
            Thread.sleep(3000);
            DefLayoutPage.selectInvalidCharBlanks(transInvChar);
            Thread.sleep(3000);
            DefLayoutPage.clickContinueButton();
            Thread.sleep(3000);
            DefLayoutPage.clickContinueOnAlert();
            Thread.sleep(3000);

        }
        if (layoutType.equalsIgnoreCase("Import Layout") && (Format.equalsIgnoreCase("ASCII Fixed") || Format.equalsIgnoreCase("EBCDIC FIXED")))
        {
            // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
            LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
            Thread.sleep(2000);
            LayoutImpPage.inputUserDefinedName(colUserDefName);
            LayoutImpPage.inputStartPosition(colStartPosi);
            LayoutImpPage.inputEndPosition(colEndPosi);
            LayoutImpPage.clickContinueButton();
            Thread.sleep(3000);
            // DefLayoutPage.selectAllFields();
            // DefLayoutPage.selectFieldType(fieldsInLayout);
//            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//            Date date = new Date();
//            if(!"NA".equals(layoutName))
//            	DefLayoutPage.inputLayoutNameField(dateFormat.format(date));
//            else
//            	DefLayoutPage.inputLayoutNameField(layoutName+"."+dateFormat.format(date));
            // added
            // DefLayoutPage.updateFieldsForEbcdicAndAsciiImportLayout(fieldsInLayout);
            DefLayoutPage.selFieldType(fieldsInLayout);
            Thread.sleep(3000);
            DefLayoutPage.selectInvalidCharBlanks(transInvChar);
            Thread.sleep(3000);
            DefLayoutPage.clickContinueButton();
            Thread.sleep(3000);
            DefLayoutPage.clickContinueOnAlert();
            Thread.sleep(3000);
            // DefLayoutPage.constantField(addConst, constValue);
        } else if (layoutType.equalsIgnoreCase("Import Layout") && Format.equalsIgnoreCase("ASCII Delimited"))
        {
            // LayoutImpPage.inputLayoutFileLocation(layoutFileLoc);
            LayoutImpPage.inputRowNoOfFirstField(rowNoFirstField);
            LayoutImpPage.inputUserDefinedName(colUserDefName);
            LayoutImpPage.clickContinueButton();
            // DefLayoutPage.selectAllFields_Delim();
            // DefLayoutPage.selectFieldType_Delim(fieldsInLayout);
//            DateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
//            Date date = new Date();
//            if(!"NA".equals(layoutName))
//            	DefLayoutPage.inputLayoutNameField(layoutName+"."+dateFormat.format(date));
            // DefLayoutPage.selFieldTypeForDelimiter(fieldsInLayout);
            // DefLayoutPage.updateFieldsForDelimitedFormat(fieldsInLayout);

            DefLayoutPage.selFieldTypesForDelimitedSelection(fieldsInLayout);
            // DefLayoutPage.delimitedLayoutFieldsUpdateWithJqx(fieldsInLayout);

            Thread.sleep(3000);
            Thread.sleep(3000);
            DefLayoutPage.selectInvalidCharBlanks(transInvChar);
            Thread.sleep(3000);
            DefLayoutPage.clickContinueButton();
            Thread.sleep(3000);
            DefLayoutPage.clickContinueOnAlert();
            Thread.sleep(3000);

            /*
             * ProjDashBoardPage.clickHomeTab(); String procName1 = ProjDashBoardPage.jobName(); String Status; Status =
             * ProjDashBoardPage.verifyProcess(procName1); commMethods.verifyString(Status, "PASS");
             * commMethods.verifyString(StatusEnum.COMPLETED.name(), "COMPLETED");
             */

        }

        if (!"ASCII Delimited".equalsIgnoreCase(Format))
        {
            // String pageTitle = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/h3")).getText();
            // commMethods.verifyString(pageTitle, "DataCheck Enter the required information, and then click Continue.");
            DataChckPage.clickDataCheckCheckbox(dataChck);
            DataChckPage.clickContinueButton();
            Thread.sleep(3000);
        }
        Thread.sleep(3000);
        Thread.sleep(3000);

        if ("IP09_BASE".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickInputTab();
            Thread.sleep(3000);
            module.initializeDriver(driver);
            status = module.getStatusIP();
            commMethods.verifyString(StatusEnum.READY.name(), status.trim());
        }
        else
        {
            summaryPage.clickSubmitButton();
            Thread.sleep(3000);
            module.initializeDriver(driver);
            status = module.getStatusIP();
            commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
        }
    }

    private String submitAndGoToHomePage() throws InterruptedException
    {
        summaryPage.clickSubmitButton();

        // Go to main project dashboard
        ProjDashBoardPage.clickHomeTab();

        // String ProcessName1 = ProjDashBoardPage.jobName();

        String ProcessName1 = ProjDashBoardPage.getJobName();
        String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
        commMethods.verifyString(Status, "PASS");

        // String procName1 = ProjDashBoardPage.jobName();
        String procName1 = ProjDashBoardPage.getJobName();
        return procName1;
    }

//    @AfterMethod
//    public void closeBrowser()
//    {
//        driver.quit();
//    }

    @DataProvider
    public Object[][] InputData_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ImportNewFile", "BASE");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] InputData_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ImportNewFile", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] InputData_DRS() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ImportNewFile", "DRS");
        return testObjArray_DRS;
    }

    @DataProvider
    public Object[][] InputDataUI() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ImportNewFile", "UI");
        return testObjArray;
    }

    @DataProvider
    public Object[][] InputData_Validate() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "ImportNewFile", "CBA");
        return testObjArray_Y;
    }

    // Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
    // "OPProcessAdd", "Y");
    @Override
    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

}

package com.equifax.cms.fusion.test.sourcematch;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.SMProcessInputVO;

@Features("Source Match validation scenarios Save/Edit/Duplicate/Submit")
public class SoureMatchValidationTest extends AbstractCoreTest {

	private static final String SOURCE_MATCH = "Source Match";
	private static final Logger LOGGER = LoggerFactory.getLogger(SoureMatchValidationTest.class);

	@Step("Source Match validation test")
	@Test
	public void testSourceMatchProcess() throws Exception {

		LOGGER.debug("-- source match input -- ");
		List<SMProcessInputVO> list = reader.getSourceMatchInputData();

		userLogin();
		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);

		for (SMProcessInputVO vo : list) {
			// Save source match process
			if (ProcessOperationEnum.VALIDATE.name().equalsIgnoreCase(vo.getOperation())) {
				validateSourceProcess(vo.getProcessName(), vo);

			}
		}
		userLogout();
		LOGGER.debug("--  logout -- ");
	}

	@Step("Validate {0}")
	private void validateSourceProcess(String processName, SMProcessInputVO vo) throws InterruptedException {

		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);
		navigateToProcess(SOURCE_MATCH);
		navigateToNewProcessPage("New Source Match");

		// get from csv file
		driver.findElement(By.id("smName")).sendKeys(vo.getProcessName());
		// get from csv file
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
		new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());

		setTimeout(50);
		selectSave();
		navigateToProcess(SOURCE_MATCH);
        String status = getStatusSM();
		// TestCase : If no table row is inserted, with incomplete values status
		// is ERROR on save
		Assert.assertEquals(StatusEnum.ERROR.name(), status.trim());

		selectEdit();
		// TestCase : If no table row is inserted, with incomplete values error
		// message should appear on submit
		selectSubmit();
		String errMsg = driver.findElement(By.id("textMsg")).getText();
		Assert.assertEquals(errMsg, "Please add at least one process.");

		setTimeout(50);
		driver.findElement(By.id("addButton")).click();
		waitForAjax();
		selectSave();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys("");
		setTimeout(50);

		// TestCase : If output table name is not inserted, with incomplete
		// values error message should appear on submit
		selectSubmit();
		errMsg = driver.findElement(By.id("textMsg")).getText();

		Assert.assertEquals(errMsg, "Please enter Output Table name(s) name");

		// TestCase : If output table name is not inserted, error message
		// appears

		selectSave();
		errMsg = driver.findElement(By.id("textMsg")).getText();
		Assert.assertEquals(errMsg, "Please enter Output Table name(s) name");
		navigateToProcess(SOURCE_MATCH);
		// TestCase : If process and data are not selected, status is ERROR
		selectEdit();

		// Get from csv
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText("Select");
		new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText("Select");
		selectSave();
		navigateToProcess(SOURCE_MATCH);
        status = getStatusSM();

		// Assert.assertEquals(StatusEnum.ERROR.name(), status.trim());
		// TestCase : If process and data are not selected, error message should
		// appear on submit
		selectEdit();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys("OutputTableName");

		selectSubmit();
		errMsg = driver.findElement(By.id("textMsg")).getText();
		Assert.assertEquals(errMsg, "Please select input process");

		// Get from csv
		// new
		// Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText("IP25:AUTO_FIXED");

		// new
		// Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText("INPUT");
		setTimeout(50);
		driver.findElement(By.id("addButton")).click();
		waitForAjax();
		errMsg = driver.findElement(By.id("textMsg")).getText();
		Assert.assertNotEquals(errMsg, "");
	}

}

package com.equifax.cms.fusion.test.qainq;

import java.io.File;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.DNSPages.DataProcessingTab;
import com.equifax.cms.fusion.test.INQpage.InqHomePage;
import com.equifax.cms.fusion.test.INQpage.InqPostPage;
import com.equifax.cms.fusion.test.INQpage.InqStatsView;
import com.equifax.cms.fusion.test.INQpage.InqSummaryPage;
import com.equifax.cms.fusion.test.RFPages.RFCommonMethods;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.SHPages.ShippingStats;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class InqPostingProcess
{
    public static WebDriver driver = null;
    private Modules module;
    private InqHomePage inqHomePage;
    private InqPostPage inqPage;
    private ShippingPage shPage;
    private InqSummaryPage inqSumPage;
    private InqStatsView inqStats;
    private ShippingStats shippingStats;
    private OracleDBHelper oracleConnect;
    RFCommonMethods rfCommon;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private DataProcessingTab dataProcesingTab;
    private static final Logger LOGGER = LoggerFactory.getLogger(InqPostingProcess.class);
    private static final boolean IS_UNIX = "/".equals(File.separator);

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        inqHomePage = PageFactory.initElements(driver, InqHomePage.class);
        inqPage = PageFactory.initElements(driver, InqPostPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        inqSumPage = PageFactory.initElements(driver, InqSummaryPage.class);
        inqStats = PageFactory.initElements(driver, InqStatsView.class);
        shippingStats = PageFactory.initElements(driver, ShippingStats.class);
        rfCommon = PageFactory.initElements(driver, RFCommonMethods.class);
        dataProcesingTab = PageFactory.initElements(driver, DataProcessingTab.class);

        oracleConnect = new OracleDBHelper();
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Title("Inquiry Posting Process Stats Verification")
    @Description("Inquiry Posting Stats Verified with GreenPlum Queries")
    @Test(dataProvider = "inq_Reg", priority = 1)
    public void inqPostStatsVerification(String tc_Id, String testRun, String tc, String descr, String procName, String selType, String dataSrc,
            String process, String data, String groups, String shProc, String shJob, String shFile, String allRecords, String accepts,
            String rejects, String projectOpt, String projSrcValue, String member, String memValue, String type, String typeValue, String date,
            String month1, String day1, String century, String year1, String ncCustId, ITestContext testContext) throws InterruptedException,
            SQLException
    {
        String status = null;
        testContext.setAttribute("WebDriver", driver);
        inqHomePage.clickInqPostingTab();
        inqHomePage.clickPostInqButton();
        // if ("INQ_ID_067".equalsIgnoreCase(tc_Id))
        // {
        // Thread.sleep(10000);
        // inqPage.clickSubmit();
        // String errMsg = driver.findElement(By.id("erMsg")).getText();
        // commMethods.verifyString(errMsg, "Error: Please enter the Process Name.");
        // Thread.sleep(15000);
        // inqPage.processNameField("Test test");
        // Thread.sleep(25000);
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.id("erMsg")).getText();
        // commMethods.verifyString(errMsg, "Error: Please enter the valid Process Name.");
        // inqPage.processNameField(procName);
        // Thread.sleep(30000);
        // inqPage.selectShipPopulation();
        // Thread.sleep(20000);
        // inqPage.selectDataSrc(dataSrc);
        // Thread.sleep(10000);
        // inqPage.selectProcessField(process);
        // shPage.selectShippedFiles(shFile);
        // commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        // inqPage.selectProjectOpt(projectOpt, projSrcValue);
        // inqPage.selectTypeOptns(type, typeValue);
        // inqPage.selectDateOptns(date, month1, day1, century, year1);
        // inqPage.selectNCcustID(dataSrc, ncCustId);
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath("//label[@class='error']")).getText();
        // commMethods.verifyString(errMsg, "Error: Please mention Member Number.");
        // inqPage.selectMemberOpt(member, memValue);
        // inqPage.selectTypeOptns(type, "Select");
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath("//label[@for='infoInquiryType']")).getText();
        // commMethods.verifyString(errMsg, "Error: Please mention type.");
        // inqPage.selectTypeOptns(type, typeValue);
        // inqPage.Date_Rbtn.click();
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[3]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please provide Date.");
        // inqPage.selectDateOptns(date, month1, day1, century, year1);
        // inqPage.selectDataSrc(dataSrc);
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[1]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please select Data Source");
        // inqPage.selectDataSrc(dataSrc);
        // inqPage.selectProcessField("Select");
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[2]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please select Process.");
        // shPage.selectShippedFiles(shFile);
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[6]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please select atleast one artifact.");
        // shPage.selectShippedFiles(shFile);
        // commMethods.Ele_AllRecRegardlessOfType.click();
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']/li/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please select Record Types.");
        // commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        // inqPage.selectMemberOpt(member, "");
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[3]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please mention Member Number.");
        // inqPage.selectMemberOpt(member, memValue);
        // inqPage.selectTypeOptns(type, "Select");
        // inqPage.clickSubmit();
        // errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li[4]/label")).getText();
        // commMethods.verifyString(errMsg, "Error: Please mention type.");
        //
        // } else
        if ("INQ_ID_017".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(5000);
            inqPage.selectShipPopulation();
            inqPage.selectDataSrc(dataSrc);
            Thread.sleep(10000);
            inqPage.selectProcessField(process);
            String expShFile = driver.findElement(By.xpath("//label[contains(text(),'" + shFile + "')]")).getText();
            commMethods.verifyboolean(expShFile.contains(shFile), true);
        } else if ("INQ_ID_003".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(15000);
            inqPage.selectNetDown();
            Thread.sleep(2000);
            inqPage.selectDataSrc(dataSrc);
            // inqPage.selectDate();
            inqPage.selectDateOptns(date, month1, day1, century, year1);
            inqPage.selectProcessField(process);
            inqPage.selectDataField(data);
            commMethods.verifyboolean(inqPage.getDataFlds().contains("INPUT"), true);
            commMethods.verifyboolean(inqPage.getDataFlds().contains("RNOPTBL"), true);
        } else if ("INQ_ID_042".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(5000);
            inqPage.processNameField(procName);
            String procId = commMethods.getProcId();
            inqPage.selectNoInq();
            inqPage.selectDate();
            inqPage.clickSave();
            Thread.sleep(10000);
            rfCommon.handleAlert();
            inqPage.selectShipPopulation();
            Thread.sleep(25000);
            inqPage.selectDataSrc(dataSrc);
            Thread.sleep(10000);
            inqPage.selectProcessField(process);
            shPage.selectShippedFiles(shFile);
            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            // inqPage.selectDateForShippedPop(month1, day1, year1);
            inqPage.selectDateOptnsforShippedFile(date, month1, day1, century, year1);
            inqPage.selectNCcustID(dataSrc, ncCustId);
            inqPage.clickSubmit();
            // status = commMethods.getInquiryProcessStatus();
            // commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            ProjDashBoardPage.clickHomeTab();
            String finalStatus = ProjDashBoardPage.verifyProcess(procId);
            commMethods.verifyString(finalStatus, "PASS");
        } else
        {
            Thread.sleep(5000);
            Thread.sleep(10000);
            inqPage.processNameField(procName);
            String procId = commMethods.getProcId();
            Thread.sleep(20000);
            if ("INQ_ID_103".equalsIgnoreCase(tc_Id))
            {
                Thread.sleep(2000);
                inqPage.selectNetDown();
                Thread.sleep(10000);
                inqPage.selectDataSrc(dataSrc);
                inqPage.selectDate();
                inqPage.selectProcessField(process);
                Thread.sleep(2000);
                inqPage.selectDataField(data);
                inqPage.selShFldDrpDwn(shProc);
                inqPage.selShJobDrpDwn(shJob);
                inqPage.selectProjectOpt(projectOpt, projSrcValue);
                inqPage.selectMemberOpt(member, memValue);
                inqPage.clickSubmit();

                String errMsg = driver.findElement(By.xpath(".///div[@class='rightContent']/div[2]/span[@id='textMsg']")).getText();
                commMethods.verifyString(errMsg,
                        "Error: MLA Transaction Id must be present in the net down file, if you want to post MLA Net down inquiry.");
            } else if ("INQ_ID_090".equalsIgnoreCase(tc_Id))
            {
                inqPage.selectNetDown();
                Thread.sleep(20000);
                inqPage.selectDataSrc(dataSrc);
                inqPage.selectDate();
                inqPage.selectProcessField(process);
                Thread.sleep(2000);
                inqPage.selectDataField("INPUT");
                String[] a = data.split(",");
                Select sel = new Select(inqPage.Data_Fld);
                List<WebElement> options = sel.getOptions();
                boolean flag = false;
                for (int i = 0; i < a.length; i++)
                {
                    System.out.println(a[i]);
                    for (WebElement opt : options)
                    {
                        if (a[i].contains(opt.getText()))
                        {
                            flag = true;
                            break;
                        } else
                        {
                            flag = false;
                        }
                    }
                }
            } else
            {
                if ("INQ_ID_049".equalsIgnoreCase(tc_Id))
                {
                    inqPage.selectDataSrc(dataSrc);
                    commMethods.verifyboolean(inqPage.NCcust_Id.isEnabled(), true);
                } else
                {
                    if ("INQ_ID_058".equalsIgnoreCase(tc_Id) || "INQ_ID_063".equalsIgnoreCase(tc_Id))
                    {
                        inqPage.selectNoInq();
                        inqPage.selectDate();
                        inqPage.clickSave();
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                    }
                    if ("Net_Down".equalsIgnoreCase(selType))
                    {
                        Thread.sleep(2000);
                        inqPage.selectNetDown();
                        Thread.sleep(10000);
                        inqPage.selectDataSrc(dataSrc);
                        inqPage.selectDate();

                        inqPage.selectProcessField(process);
                        Thread.sleep(2000);
                        // inqPage.selectJobField(job);
                        inqPage.selectDataField(data);
                        commMethods.selectTheGroups(groups);
                        inqPage.selectProjectOpt(projectOpt, projSrcValue);
                        inqPage.selectMemberOpt(member, memValue);
                        inqPage.selectTypeOptns(type, typeValue);
                        inqPage.selectDateOptns(date, month1, day1, century, year1);
                        inqPage.selectNCcustID(dataSrc, ncCustId);
                    } else if ("SP".equalsIgnoreCase(selType))
                    {
                        Thread.sleep(30000);
                        inqPage.selectShipPopulation();
                        Thread.sleep(25000);
                        inqPage.selectDataSrc(dataSrc);
                        Thread.sleep(10000);
                        Thread.sleep(3000);
                        inqPage.selectProcessField(process);
                        Thread.sleep(3000);
                        Thread.sleep(3000);
                        Thread.sleep(3000);
                        shPage.selectShippedFiles(shFile);
                        commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
                        inqPage.selectProjectOpt(projectOpt, projSrcValue);
                        inqPage.selectMemberOpt(member, memValue);
                        inqPage.selectTypeOptns(type, typeValue);
                        // inqPage.selectDateForShippedPop(month1, day1, year1);
                        /*
                         * inqPage.clickPostInfDateImg(); inqPage.selectDate();
                         */
                        // inqPage.selectDateOptns(date, month1, day1, century, year1);
                        inqPage.selectDateForShippedPop(month1, day1, year1);
                        inqPage.selectNCcustID(dataSrc, ncCustId);
                    } else if ("No_Inq".equalsIgnoreCase(selType))
                    {
                        inqPage.selectNoInq();
                        // inqPage.clickShDateImg();
                        inqPage.selectDate();
                    }
                    if (!"NA".equalsIgnoreCase(shProc))
                    {
                        inqPage.selShFldDrpDwn(shProc);
                        inqPage.selShJobDrpDwn(shJob);
                    }
                    if ("INQ_ID_045".equalsIgnoreCase(tc_Id))
                    {
                        driver.findElement(By.xpath("//input[@id='chkBoxDataSources1']")).click();
                        driver.findElement(By.xpath("//input[@id='chkBoxDataSources2']")).click();
                    }
                    inqPage.clickSave();

                    if ("INQ_ID_059".equalsIgnoreCase(tc_Id) || "INQ_ID_062".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(10000);
                        inqPage.selectNoInq();
                        inqPage.selectDate();
                        inqPage.clickSave();
                    }
                    if ("INQ_ID_060".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(10000);
                        inqPage.selectNetDown();
                        Thread.sleep(2000);
                        inqPage.selectDataSrc(dataSrc);
                        inqPage.selectDate();
                        // inqPage.selectDateForNetDown(month1, day1, year1);
                        inqPage.selectProcessField(process);
                        Thread.sleep(2000);
                        // inqPage.selectJobField(job);
                        inqPage.selectDataField(data);
                        inqPage.selectProjectOpt(projectOpt, projSrcValue);
                        inqPage.selectMemberOpt(member, memValue);
                        inqPage.selectTypeOptns(type, typeValue);
                        inqPage.selectDateOptns(date, month1, day1, century, year1);
                        inqPage.selectNCcustID(dataSrc, ncCustId);
                        inqPage.clickSave();
                    }

                    if ("INQ_ID_067".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(10000);
                        inqPage.selectNetDown();
                        Thread.sleep(2000);
                        inqPage.selectDataSrc(dataSrc);
                        inqPage.selectDate();
                        // inqPage.selectDateForNetDown(month1, day1, year1);
                        inqPage.selectProcessField(process);
                        Thread.sleep(2000);
                        // inqPage.selectJobField(job);
                        inqPage.selectDataField(data);
                        inqPage.selectProjectOpt(projectOpt, projSrcValue);
                        inqPage.selectMemberOpt(member, memValue);
                        inqPage.selectTypeOptns(type, typeValue);
                        inqPage.selectDateOptns(date, month1, day1, century, year1);
                        inqPage.selectNCcustID(dataSrc, ncCustId);
                        inqPage.clickSave();
                        String errMsg = driver.findElement(By.xpath("//div[@class='errMsg copyErrMsg']/span[1]/li/label")).getText();
                        commMethods.verifyString(errMsg, "Error: Please enter the Process Name.");
                    }
                    if ("INQ_ID_061".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(30000);
                        inqPage.selectShipPopulation();
                        Thread.sleep(25000);
                        inqPage.selectDataSrc(dataSrc);
                        Thread.sleep(10000);
                        inqPage.selectProcessField(process);
                        shPage.selectShippedFiles(shFile);
                        commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
                        inqPage.selectProjectOpt(projectOpt, projSrcValue);
                        inqPage.selectMemberOpt(member, memValue);
                        inqPage.selectTypeOptns(type, typeValue);
                        inqPage.CreditFile_Rbtn.click();
                        inqPage.selectNCcustID(dataSrc, ncCustId);
                        inqPage.clickSave();
                    }

                    if ("INQ_ID_045".equalsIgnoreCase(tc_Id))
                    {
                        String errMsg = driver.findElement(By.xpath("//div[@class='errMsg copyErrMsg']/span[@class='liErrDiv']/li[1]")).getText();
                        commMethods.verifyString(errMsg, "Error: NC+ is not allowed with type Net Down");
                    } else if ("INQ_ID_050".equalsIgnoreCase(tc_Id))
                    {
                        String errMsg = driver.findElement(By.xpath("//label[@class='error']")).getText();
                        commMethods.verifyString(errMsg, "Error: NC+ is not allowed without Credit data Source");
                    } else if ("INQ_ID_035".equalsIgnoreCase(tc_Id))
                    {
                        // String pageTitle = driver.findElement(By.xpath("(//h3[@class='fusion-h3Title'])[1]")).getText();
                        // commMethods.verifyString(pageTitle,
                        // "Inquiry Posting   Enter in the information below, and then click 'Save' or 'Submit'.");

                        Thread.sleep(2000);
                        inqPage.clickBackBtn();
                        Thread.sleep(2000);
                        commMethods.verifyboolean(inqPage.isHomePageDisplayed(), true);

                    } else if ("INQ_ID_040".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(10000);
                        inqHomePage.clickInqPostingTab();
                        status = commMethods.getInquiryProcessStatus();
                        commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                        module.initializeDriver(driver);
                        module.selectEdit();
                        String datefld = driver.findElement(By.id("infoPostingDate")).getAttribute("value");
                        commMethods.verifyboolean(datefld.equals(""), false);
                        inqHomePage.clickInqPostingTab();
                        module.selectDuplicate();
                        status = commMethods.getInquiryProcessStatus();
                        commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                        module.selectSummary();
                        Thread.sleep(3000);
                        String pageTitle = driver.findElement(By.xpath("//h3[@class='fusion-h3Title']")).getText();
                        commMethods.verifyString(pageTitle,
                                "Summary: Inquiry Posting\nReview the information below, and then click 'Back' or 'Submit'.");
                        String procSum = driver.findElement(By.xpath("//span[contains(text(),'" + process + "')]")).getText();
                        commMethods.verifyString(procSum, process);
                        inqSumPage.clickSubmitButton();
                        status = commMethods.getInquiryProcessStatus();
                        commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                    } else if ("INQ_ID_055".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();
                        Thread.sleep(10000);
                        inqHomePage.clickInqPostingTab();
                        status = commMethods.getInquiryProcessStatus();
                        commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                    } else
                    {
                        Thread.sleep(10000);
                        rfCommon.handleAlert();

                        Thread.sleep(10000);

                        inqPage.clickSubmit();
                        rfCommon.handleAlert();
                        // driver.switchTo().alert().accept();
                        if ("INQ_ID_118".equalsIgnoreCase(tc_Id))
                        {
                            String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
                            commMethods
                                    .verifyString(
                                            errMsg,
                                            "The Shipment selected as Input contains records that did not pull credit files via Data Menu process. You may not post inquiries for this shipment. Please make another selection.");
                        } else if ("INQ_ID_046".equalsIgnoreCase(tc_Id))
                        {
                            String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
                            commMethods.verifyString(errMsg, "Error: Please uncheck the NC+ selection as the Input Process selected is not NC+.");
                            WebElement creditChBx = driver.findElement(By.id("chkBoxDataSources1"));
                            WebElement ncChBx = driver.findElement(By.id("chkBoxDataSources2"));
                            commMethods.verifyboolean(creditChBx.isSelected(), true);
                            commMethods.verifyboolean(ncChBx.isSelected(), true);
                        } else if ("INQ_ID_105".equalsIgnoreCase(tc_Id) || "INQ_ID_058".equalsIgnoreCase(tc_Id)
                                || "INQ_ID_059".equalsIgnoreCase(tc_Id))
                        {
                            Thread.sleep(5000);
                            inqHomePage.clickInqPostingTab();
                            Thread.sleep(5000);
                            status = commMethods.getInquiryProcessStatus();
                            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                        } else
                        {
                            Thread.sleep(2000);

                            if ("INQ_ID_002".equalsIgnoreCase(tc_Id) || "INQ_ID_004".equalsIgnoreCase(tc_Id) || "INQ_ID_008".equalsIgnoreCase(tc_Id)
                                    || "INQ_ID_016".equalsIgnoreCase(tc_Id) || "INQ_ID_043".equalsIgnoreCase(tc_Id)
                                    || "INQ_ID_053".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String finalStatus = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(finalStatus, "PASS");
                            } else if ("INQ_ID_001".equalsIgnoreCase(tc_Id) || "INQ_ID_008".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String finalStatus = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(finalStatus, "PASS");
                                driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')])[1]//preceding::span[1]")).click();
                                Thread.sleep(2000);
                                driver.findElement(By.xpath("(//span[contains(text(),'" + procId + "')])[2]//preceding::span[1]")).click();
                                Thread.sleep(2000);
                                String inq_accounting = driver.findElement(By.xpath("//span[contains(text(),'INQ_ACCOUNTING')]")).getText().trim();
                                commMethods.verifyString(inq_accounting, "INQ_ACCOUNTING");
                            } else if ("INQ_ID_051".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String finalStatus = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(finalStatus, "PASS");
                                driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click();
                                Thread.sleep(2000);
                                driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img"))
                                        .click();
                                Thread.sleep(2000);
                                driver.findElement(
                                        By.xpath("//td[contains(text(),'"
                                                + procId
                                                + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'INQ_GPEXPORT')]//following::td[5]/a[contains(text(),'View')]"))
                                        .click();
                                driver.switchTo().frame("sb-player");
                                String actFileName = inqStats.shFileInInqStats(shFile);
                                commMethods.verifyString(actFileName, " " + shFile + " ");
                            } else if ("INQ_ID_081".equalsIgnoreCase(tc_Id) || "INQ_ID_094".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String finalStatus = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(finalStatus, "PASS");
                                driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click();
                                Thread.sleep(2000);
                                driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img"))
                                        .click();
                                Thread.sleep(2000);
                                String inq_gpexport = driver
                                        .findElement(
                                                By.xpath("//td[contains(text(),'" + procId
                                                        + "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'INQ_GPEXPORT')]")).getText()
                                        .trim();
                                commMethods.verifyString(inq_gpexport, "INQ_GPEXPORT");
                                String inq_xjob = driver.findElement(
                                        By.xpath("//td[contains(text(),'" + procId
                                                + "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'INQ_XJOB')]")).getText();
                                commMethods.verifyString(inq_xjob, "INQ_XJOB");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                                // driver.switchTo().frame("sb-player");
                                String fixedFileStats = driver.findElement(By.xpath("//div[contains(text(),'Records Written To')]")).getText();
                                commMethods.verifyboolean(fixedFileStats.endsWith("_INQ_GPEXPORT.fixed :"), true);
                            } else if ("INQ_ID_005".equalsIgnoreCase(tc_Id))
                            {
                                ProjDashBoardPage.clickHomeTab();
                                String finalStatus = ProjDashBoardPage.verifyProcess(procId);
                                commMethods.verifyString(finalStatus, "PASS");
                                ProjDashBoardPage.clickTreeV2statsViewForChrome(procId);
                                // driver.switchTo().frame("sb-player");
                                driver.findElement(By.xpath("//a[contains(text(),'STATS')]")).click();
                                Thread.sleep(2000);

                                String statsTitle = driver.findElement(By.xpath("//div[@id='popupTitle']/div[1]")).getText();
                                commMethods.verifyString(statsTitle, "Job Stats Counters");
                            }
                        }
                    }
                }
            }
        }
    }

    @Title("Inquiry Posting Process Duplicate, Ready and Submit Verification")
    @Description("Inquiry Posting Process Duplicate, ready and submit Verification")
    @Test(dataProvider = "InqDRS", priority = 2, enabled = false)
    public void inqPostDuplicateVerification(String tc, String testRun, String testcase, String description, String procName, String testOnly,
            String selType, String dataSrc, String process, String job, String data, String shFile, String allRecords, String accepts,
            String rejects, String projectOpt, String projSrcValue, String member, String memValue, String type, String typeValue, String date,
            String month1, String day1, String century, String year1, String ncCustId, ITestContext testContext) throws InterruptedException,
            SQLException
    {
        String status = null;
        testContext.setAttribute("WebDriver", InqPostingProcess.driver);
        inqHomePage.clickInqPostingTab();
        inqHomePage.clickPostInqButton();
        inqPage.processNameField(procName);
        if ("Net_Down".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectNetDown();
            Thread.sleep(10000);
            inqPage.selectDataSrc(dataSrc);
            // inqPage.selectDate();
            inqPage.selectDateForNetDown(month1, day1, year1);
            inqPage.selectProcessField(process);
            Thread.sleep(2000);
            // inqPage.selectJobField(job);
            // inqPage.selectDataField(data);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateOptns(date, month1, day1, century, year1);
            inqPage.selectNCcustID(dataSrc, ncCustId);
        } else if ("SP".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectShipPopulation();
            inqPage.selectDataSrc(dataSrc);
            Thread.sleep(10000);
            inqPage.selectProcessField(process);
            shPage.selectShippedFiles(shFile);
            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateForShippedPop(month1, day1, year1);
            inqPage.selectNCcustID(dataSrc, ncCustId);
        } else
        {
            inqPage.selectNoInq();
            inqPage.selectDate();
        }
        inqPage.clickSave();
        rfCommon.handleAlert();
        inqHomePage.clickInqPostingTab();
        status = commMethods.getInquiryProcessStatus();
        commMethods.verifyStringEB(status.trim(), StatusEnum.READY.name());
        module.selectDuplicate();
        status = commMethods.getInquiryProcessStatus();
        commMethods.verifyString(status.trim(), StatusEnum.READY.name());
        module.selectSummary();
        inqSumPage.clickSubmitButton();
        status = commMethods.getInquiryProcessStatus();
        commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
        LOGGER.info("STATUS has been verified !!!");
    }

    @Title("Inquiry Posting UI Validations")
    @Description("Inquiry Posting Process UI Validations")
    @Test(dataProvider = "InqUI", priority = 3, enabled = false)
    public void inqPostUIVerification(String testRun, String testcase, String description, String procName, String testOnly, String selType,
            String dataSrc, String process, String job, String data, String shFile, String allRecords, String accepts, String rejects,
            String projectOpt, String projSrcValue, String member, String memValue, String type, String typeValue, String date, String month1,
            String day1, String century, String year1, String ncCustId, ITestContext testContext) throws InterruptedException, SQLException
    {
        testContext.setAttribute("WebDriver", InqPostingProcess.driver);
        inqHomePage.clickInqPostingTab();
        inqHomePage.clickPostInqButton();

        if ("Net_Down".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectNetDown();
            Thread.sleep(10000);
            inqPage.selectDataSrc(dataSrc);
            // inqPage.selectDate();
            inqPage.selectDateForNetDown(month1, day1, year1);
            inqPage.selectProcessField(process);
            Thread.sleep(2000);
            // inqPage.selectJobField(job);
            // inqPage.selectDataField(data);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateOptns(date, month1, day1, century, year1);

            inqPage.selectNCcustID(dataSrc, ncCustId);

        } else if ("SP".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectShipPopulation();
            inqPage.selectDataSrc(dataSrc);
            Thread.sleep(10000);
            inqPage.selectProcessField(process);
            shPage.selectShippedFiles(shFile);
            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateForShippedPop(month1, day1, year1);
            inqPage.selectNCcustID(dataSrc, ncCustId);

        } else
        {
            inqPage.selectNoInq();
            inqPage.selectDate();
        }
        inqPage.clickSubmit();

        String errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/li/label")).getText();
        commMethods.verifyString(errMsg, "Process Name is required.");

        inqPage.processNameField(procName);
        inqPage.selectDataSrc(dataSrc);
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/li[2]/label")).getText();
        commMethods.verifyString(errMsg, "Please select Data Source");

        inqPage.selectDataSrc(dataSrc);
        inqPage.selectProcessField("Select");
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/li[3]/label")).getText();
        commMethods.verifyString(errMsg, "Please select Process.");

        inqPage.selectProcessField(process);
        inqPage.selectTypeOptns(type, typeValue);
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/li[3]/label")).getText();
        commMethods.verifyString(errMsg, "Please select a process with atleast one artifact.");

        shPage.selectShippedFiles(shFile);
        commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/span/li/label")).getText();
        commMethods.verifyString(errMsg, "Please select Record Types.");

        commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
        inqPage.selectTypeOptns(type, "Select");
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]/li[4]/label")).getText();
        commMethods.verifyString(errMsg, "Please mention type.");

        inqPage.selectTypeOptns(type, typeValue);
        inqPage.selectMemberOpt(member, "");
        inqPage.clickSubmit();

        errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[1]")).getText();
        commMethods.verifyString(errMsg, "Please mention Member Number.");
        if (testcase.equalsIgnoreCase("INQ_ID_039"))
        {
            inqPage.clickSave();
            commMethods.verifyStringEB("Date should be earlier than shipping date.", inqPage.getShippedDateValidationMessage());
            // String processName1 = commMethods.getFinalProcessName();
        }
        inqPage.selectMemberOpt(member, memValue);
        inqPage.clickSubmit();
    }

    @Title("Inquiry Posting Process Ready and Submit Verification")
    @Description("Inquiry Posting Process ready and submit Verification")
    @Test(dataProvider = "InqCBA", priority = 1)
    public void inqPostVerification(String tc, String testRun, String testcase, String description, String procName, String testOnly, String selType,
            String dataSrc, String process, String job, String data, String shFile, String allRecords, String accepts, String rejects,
            String projectOpt, String projSrcValue, String member, String memValue, String type, String typeValue, String date, String month1,
            String day1, String century, String year1, String ncCustId, ITestContext testContext) throws InterruptedException, SQLException,
            ParseException
    {

        String status = null;
        testContext.setAttribute("WebDriver", InqPostingProcess.driver);

        inqHomePage.clickInqPostingTab();
        inqHomePage.clickPostInqButton();
        Thread.sleep(30000);
        inqPage.processNameField(procName);
        String procId = commMethods.getProcId();
        Thread.sleep(10000);
        inqPage.selectTestOnly(testOnly);
        if ("Net_Down".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectNetDown();
            Thread.sleep(10000);
            Thread.sleep(10000);
            inqPage.selectDataSrc(dataSrc);
            // inqPage.selectDate();
            inqPage.selectDateForNetDown(month1, day1, year1);
            inqPage.selectProcessField(process);
            Thread.sleep(3000);
            // inqPage.selectJobField(job);
            // inqPage.selectDataField(data);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateOptns(date, month1, day1, century, year1);
            Thread.sleep(1000);

            inqPage.selectNCcustID(dataSrc, ncCustId);

        } else if ("SP".equalsIgnoreCase(selType))
        {
            Thread.sleep(10000);
            inqPage.selectShipPopulation();
            inqPage.selectDataSrc(dataSrc);
            Thread.sleep(10000);
            inqPage.selectProcessField(process);
            shPage.selectShippedFiles(shFile);
            commMethods.selectRecordTypes(process, allRecords, accepts, rejects);
            inqPage.selectProjectOpt(projectOpt, projSrcValue);
            inqPage.selectMemberOpt(member, memValue);
            inqPage.selectTypeOptns(type, typeValue);
            inqPage.selectDateForShippedPop(month1, day1, year1);
            inqPage.selectNCcustID(dataSrc, ncCustId);

        } else
        {
            Thread.sleep(10000);
            inqPage.selectNoInq();
            inqPage.selectDate();
        }

        inqPage.clickSubmit();
        if (testcase.equalsIgnoreCase("DB_INQ_01"))
        {
            ProjDashBoardPage.clickHomeTab();
            ProjDashBoardPage.openProcessGearBox(procName);
            ProjDashBoardPage.clickGearBoxCancel();
            Thread.sleep(5000);
            ProjDashBoardPage.clickConfirmationOK();
            String proName = ProjDashBoardPage.jobName();
            String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
            commMethods.verifyString(finalStat, "CANCELLED");
            ProjDashBoardPage.openProcessGearBox(procName);

            commMethods.verifyboolean(ProjDashBoardPage.isRetryOptionVisible(), true);

        }
        // status = commMethods.getInquiryProcessStatus();
        // Thread.sleep(5000);
        // commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());

        ProjDashBoardPage.clickHomeTab();
        Thread.sleep(3000);
        String ProcessName1 = ProjDashBoardPage.jobName();
        String finalStatus = ProjDashBoardPage.verifyProcess(procId);
        if ("FAIL".equalsIgnoreCase(finalStatus))
        {
            ProjDashBoardPage.viewStats(ProcessName1);
            LOGGER.info("Process Failed with error message --->>" + ProjDashBoardPage.getErrorWarningMessage());
        }
        commMethods.verifyString(finalStatus, "PASS");

        if (testcase.equalsIgnoreCase("INQ_ID_009"))
        {
            // String pName = ProjDashBoardPage.jobName();
            ProjDashBoardPage.expandProcess(procId);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
            Thread.sleep(3000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            commMethods.verifyString("INQ_GPEXPORT", artifactList.get(0));
            commMethods.verifyString("INQ_XJOB", artifactList.get(1));

        }

        if (testcase.equalsIgnoreCase("INQ_ID_010"))
        {
            // inqPage.viewNetDownInqStats(ProcessName1);
            ProjDashBoardPage.viewStats(ProcessName1);
            String fixedFilePath = inqPage.getFixedFilePathForInqGpExport();
            if (fixedFilePath.contains(".fixed"))
            {
                LOGGER.info("File exists");
            }
        }

        if (testcase.equalsIgnoreCase("INQ_ID_011"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);

            String fixedFilePath = inqPage.getFixedFilePathForInqGpExport();
            commMethods.verifyboolean(true, fixedFilePath.contains(".fixed"));
        }
        if (testcase.equalsIgnoreCase("INQ_ID_036"))
        {
            String processToExpand = process.replace(":", "_");
            System.out.println("test-------->>" + processToExpand);
            commMethods.searchProcessOnDashboardAndViewStats(processToExpand);

            Map<String, Long> map = new HashMap<String, Long>();
            map = shippingStats.getTheCountOfRecordsShipped(shFile);
            String shippedRecCount = null;
            for (Map.Entry<String, Long> entry : map.entrySet())
            {
                String key = entry.getKey();
                Long value = Long.valueOf(entry.getValue());
                shippedRecCount = value.toString();
            }
            ProjDashBoardPage.clickCloseStats();

            commMethods.searchProcessOnDashboardAndViewStats(ProcessName1);
            commMethods.verifyboolean(inqStats.getShippedFileName().contains(shFile), true);
            commMethods.verifyString(inqStats.getShippedFileRecCount().replace(",", ""), shippedRecCount.replace(",", ""));

        }
        if (testcase.equalsIgnoreCase("INQ_ID_012"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);

            String path = inqPage.getOutputPath();
            String contentLabel = inqPage.getStatFileContent();

            File f = new File(path);
            // Validate that XJob stat file path and Xjob stat file content are created and displayed in job stats as output of INQ_XJOB
            if (StringUtils.isNotEmpty(path) && f.exists() && !f.isDirectory())
            {
                LOGGER.info("Path is not blank :" + path);
            }
            commMethods.verifyString("STATS", contentLabel);
        }

        if (testcase.equalsIgnoreCase("INQ_ID_013"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);
            String content = inqPage.statsContent();
            commMethods.verifyboolean(content.contains("/nas/a4data/AppData/InqPost/Stats/"), true);
        }
        if (testcase.equalsIgnoreCase("INQ_ID_014"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);
            inqPage.clickStatLink();
            Thread.sleep(2000);
            commMethods.verifyboolean(inqPage.isDistributionStatsDisplayed(), true);
        }
        if (testcase.equalsIgnoreCase("INQ_ID_023") || testcase.equalsIgnoreCase("INQ_ID_026") || testcase.equalsIgnoreCase("INQ_ID_011"))
        {
            Thread.sleep(2000);
            ProjDashBoardPage.viewStats(ProcessName1);
            String completeFilePath = inqStats.getInqGpExportFileLocation();
            String actualPath[] = completeFilePath.split(" ");
            String path = actualPath[3];
            String contentLabel = inqPage.getStatFileContent();

            if (IS_UNIX)
            {
                System.out.println("goes to --->>" + path);
                int len = new File(path).listFiles().length;
                File file = new File(path);
                for (File f : file.listFiles())
                {
                    if (f.getName().contains(".fixed"))
                    {
                        System.out.println("PASS");
                        inqStats.readDateFromFile(path, "INQ_POST_DATE");
                    }
                }

            } else
            {
                System.out.println("goes to --->>" + "C:" + path.replace("/", "\\"));
                String newPath = "C:" + path.replace("/", "\\");
                File file = new File(newPath);

                if (file.getName().contains(".fixed"))
                {
                    System.out.println("PASS");
                    String fieldname = "INQ_POST_DATE";
                    inqStats.readDateFromFile(newPath, fieldname);
                }

            }
            commMethods.verifyString("STATS", contentLabel);

        }

        if (testcase.equalsIgnoreCase("INQ_ID_024"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);
            inqPage.clickStatLink();
            commMethods.verifyboolean(inqPage.isOutputFileDisplayed(), true);
        }
        if (testcase.equalsIgnoreCase("INQ_ID_025"))
        {
            ProjDashBoardPage.viewStats(ProcessName1);
            inqPage.clickStatLink();
            commMethods.verifyboolean(inqPage.isDistributionStatsDisplayed(), true);
        }
        if (testcase.equalsIgnoreCase("INQ_ID_020"))
        {
            // /////
            ProjDashBoardPage.expandProcess(procId);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
            Thread.sleep(3000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            commMethods.verifyString("INQ_GPEXPORT", artifactList.get(0));
            commMethods.verifyString("INQ_XJOB", artifactList.get(1));
            ProjDashBoardPage.viewStats(procName);
            String fixedFilePath = inqPage.getFixedFilePathForInqGpExport();
            commMethods.verifyboolean(true, fixedFilePath.contains(".fixed"));
            // verification for month format pending

        }

        if (testcase.equalsIgnoreCase("INQ_ID_021"))
        {
            ProjDashBoardPage.expandProcess(procId);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
            Thread.sleep(3000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            commMethods.verifyString("INQ_GPEXPORT", artifactList.get(0));
            inqStats.collapseWorkItems(procName);
            ProjDashBoardPage.viewStats(procName);
            String fixedFilePath = inqPage.getFixedFilePathForInqGpExport();
            commMethods.verifyboolean(true, fixedFilePath.contains(".fixed"));

        }
        if (testcase.equalsIgnoreCase("INQ_ID_022"))
        {
            ProjDashBoardPage.expandProcess(procId);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":");
            Thread.sleep(3000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            Thread.sleep(3000);
            commMethods.verifyString("INQ_GPEXPORT", artifactList.get(0));
            commMethods.verifyString("INQ_XJOB", artifactList.get(1));
            inqStats.collapseWorkItems(procName);
            ProjDashBoardPage.viewStats(procName);
            String fixedFilePath = inqPage.getFixedFilePathForInqGpExport();

            if (IS_UNIX)
            {
                System.out.println("goes to --->>" + fixedFilePath);
                commMethods.verifyboolean(fixedFilePath.contains(".fixed"), true);

            } else
            {
                System.out.println("goes to --->>" + "C:" + fixedFilePath.replace("/", "\\"));
                String newPath = "C:" + fixedFilePath.replace("/", "\\");
                LOGGER.info("new Path is ---->>" + newPath);
                commMethods.verifyboolean(fixedFilePath.contains(".fixed"), true);

            }

        }

        if (testcase.equalsIgnoreCase("INQ_ID_029"))
        {
            ProjDashBoardPage.expandProcess(procId + "_" + procName);
            Thread.sleep(5000);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":" + procName);
            Thread.sleep(5000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            commMethods.verifyString("INQ_ACCOUNTING", artifactList.get(0));

        }

        // Validate that entry is present in Accounting table regarding no Inquiries Inquiry Posting Process- pending.
        if (testcase.equalsIgnoreCase("INQ_ID_030"))
        {

            ProjDashBoardPage.expandProcess(procId + "_" + procName);
            ProjDashBoardPage.expandProcessToViewWorkItems(procId + ":" + procName);
            Thread.sleep(3000);
            List<String> artifactList = inqStats.checkWokItemsCreatedForParticularProcess(ProcessName1);
            commMethods.verifyString("INQ_ACCOUNTING", artifactList.get(0));
            Thread.sleep(3000);
            ProjDashBoardPage.viewStats(ProcessName1);
            Thread.sleep(2000);
            commMethods.verifyString(inqPage.validateAccountingTableInsert(), "Successfully inserted in the project accounting staging table. ");
        }

    }

    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] InqCBA() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "INQprocess", "Y");
        return testObjArray_CBA;
    }

    @DataProvider
    public Object[][] inq_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "INQprocess", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] InqDRS() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "INQprocess", "DRS");
        return testObjArray_DRS;
    }

    @DataProvider
    public Object[][] InqUI() throws Exception
    {
        Object[][] testObjArray_UI = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "INQprocess", "UI");
        return testObjArray_UI;
    }

    /*
     * @AfterMethod public void destroy() { driver.quit(); }
     */
}

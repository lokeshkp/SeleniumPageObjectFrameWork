package com.equifax.cms.fusion.test.random;

import java.util.List;

import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.FusionCoreTestContext;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.RandomNthVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;

@Features("Random Nth process Save/Edit/Duplicate ")
public class RandomNthTest extends AbstractCoreTest {

	private static final String DATA_PROCESSING = "Data Processing";
	private static final Logger LOGGER = LoggerFactory.getLogger(RandomNthTest.class);

	WebDriverWait wait = new WebDriverWait(driver, 10);

	@Step("Random Nth process Save/Edit/Duplicate")
	@Test
	public void testRandomNthPositiveProcess() throws Exception {

		LOGGER.debug("-- random nth -- ");
		List<RandomNthVO> list = reader.getRandomNthInputData();

		userLogin();
		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);

		for (RandomNthVO vo : list) {
			// Save source match process
			if (ProcessOperationEnum.SAVE.name().equalsIgnoreCase(vo.getOperation())) {
				saveRandomNthProcess(vo.getProcessName(), vo);

			} else if (ProcessOperationEnum.EDIT.name().equalsIgnoreCase(vo.getOperation())) {
				// Test edit
				editGridRandomNthProcess(vo.getProcessName(), vo);
			}

		}
		// userLogout();
		LOGGER.debug("--  logout -- ");
	}

	@Step("Save Random Nth process with all records {0} ")
	private void saveRandomNthProcess(String processName, RandomNthVO vo) {

		createAttachment(vo.toString());

		navigateToProcess(DATA_PROCESSING);
		navigateToNewProcessPage("Random Nth");

		// Generated Code Start
		driver.findElement(By.id("name")).clear();
		driver.findElement(By.id("name")).sendKeys(vo.getProcessName());
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
		new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(vo.getOutputTable());
		driver.findElement(By.id("numberOutput")).clear();
		driver.findElement(By.id("numberOutput")).sendKeys(vo.getNumOfOutput());
		driver.findElement(By.id("allRecordsAccRej")).click();
		// Generated Code ends

		selectSave();
	}


	@Step("Edit Random Nth process with all records {0} ")
	private void editGridRandomNthProcess(String processName, RandomNthVO vo) {

		createAttachment(vo.toString());
		navigateToProcess(DATA_PROCESSING);

		delayThread(3000);
		List<WebElement> inputs = driver.findElements(By.xpath("//*[@id='dnsTable']/tbody/tr"));

		delayThread(5000);
		for (WebElement element : inputs) {

			List<WebElement> columns = element.findElements(By.xpath("td"));

			if (null != columns) {
				if (columns.get(1).getText().trim().contains(vo.getProcessName())) {
					modifyGridRandomNthProcess(vo, columns);
					break;
			}
			}
		}
	}


	private void modifyGridRandomNthProcess(RandomNthVO vo, List<WebElement> columns) {

		columns.get(0).click();

		WebElement editElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Edit")));
		editElement.click();
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
		new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(vo.getOutputTable());
		driver.findElement(By.id("numberOutput")).clear();
		driver.findElement(By.id("numberOutput")).sendKeys(vo.getNumOfOutput());

		//

		String recordTypes = vo.getRecordType();
		String[] collectiveRecords = recordTypes.split(",");
		boolean allRejects = false;
		boolean allAccept = false;

		for (String record : collectiveRecords) {

			if (FusionCoreTestContext.ALL.equalsIgnoreCase(record.trim())) {
				allAccept = true;
				driver.findElement(By.id("allRecordsAccRej")).click();
				break;
			}

			if (FusionCoreTestContext.ACCEPTS.equalsIgnoreCase(record.trim())) {
				driver.findElement(By.xpath("//*[@id='acceptCodeChkbx_0']")).click();
			}

			if (FusionCoreTestContext.REJECTS.equalsIgnoreCase(record.trim())) {
				allRejects = true;
				driver.findElement(By.xpath("//*[@id='checkAll']")).click();
			}

		}

		if (!allRejects || !allAccept) {
			verifyRejectCodes(collectiveRecords);
		}
		selectSave();

	}

	private void verifyRejectCodes(String[] collectiveRecords) {

		delayThread(5000);
		List<WebElement> inputs = driver
				.findElements(By.xpath("//*[@id='ppCodeDiv']/div[3]/div[2]/div/table/tbody/tr"));


		delayThread(5000);
		for (WebElement element : inputs) {

			List<WebElement> tds = element.findElements(By.xpath("td"));
				for (int i = 0; i < tds.size(); ++i) {
				LOGGER.info("Test " + tds.get(2).getText().trim());
				for (String recordType : collectiveRecords) {
					if (recordType.trim().equalsIgnoreCase(tds.get(1).getText())) {
						tds.get(0).click();
					}
				}
			}

		}



	}

	@Step("Edit Random Nth process with all records {0} ")
	private void editRandomNthProcess(String processName, RandomNthVO vo) {

		createAttachment(vo.toString());
		navigateToProcess(DATA_PROCESSING);
		List<WebElement> inputs = driver.findElements(By.xpath("//*[@id='dnsTable']/tbody/tr"));

		for (WebElement element : inputs) {
			List<WebElement> columns = element.findElements(By.xpath("td"));
			if (columns.get(1).getText().trim().contains(vo.getProcessName())) {
				modifyRandomNthProcess(vo, columns);
			}
		}
	}

	private void modifyRandomNthProcess(RandomNthVO vo, List<WebElement> columns) {
		columns.get(0).click();
		WebDriverWait wait = new WebDriverWait(driver, 10);
		WebElement editElement = wait.until(ExpectedConditions.visibilityOfElementLocated(By.id("Edit")));
		editElement.click();
		new Select(driver.findElement(By.id("fromProcessId"))).selectByVisibleText(vo.getInputProcess());
		new Select(driver.findElement(By.id("itemTableId"))).selectByVisibleText(vo.getData());
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
		driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(vo.getOutputTable());
		driver.findElement(By.id("numberOutput")).clear();
		driver.findElement(By.id("numberOutput")).sendKeys(vo.getNumOfOutput());
		selectSave();
	}

}

package com.equifax.cms.fusion.test.qarf;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.SkipException;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.RFPages.CEoptionsPage;
import com.equifax.cms.fusion.test.RFPages.CustomHholdModPage;
import com.equifax.cms.fusion.test.RFPages.DedupeOptionsPage;
import com.equifax.cms.fusion.test.RFPages.HholdCustomPage;
import com.equifax.cms.fusion.test.RFPages.HholdSplitPage;
import com.equifax.cms.fusion.test.RFPages.HholdingKeyConfigPage;
import com.equifax.cms.fusion.test.RFPages.NegativeHholdDropPage;
import com.equifax.cms.fusion.test.RFPages.NewRFSetupPage;
import com.equifax.cms.fusion.test.RFPages.RFCommonMethods;
import com.equifax.cms.fusion.test.RFPages.RFHomePage;
import com.equifax.cms.fusion.test.RFPages.RFStatsView;
import com.equifax.cms.fusion.test.RFPages.RFSummaryPage;
import com.equifax.cms.fusion.test.RFPages.SuppressionOptionsPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

@Title("Refinement Process UI")
public class RFProcessUI_Validations extends AbstractCoreTest {

	public static WebDriver driver;
	private ProjectDashBoardPage ProjDashBoardPage;
	private RFHomePage rfHomePage;
	private NewRFSetupPage rfSetupPage;
	private DedupeOptionsPage dedupePage;
	private SuppressionOptionsPage supprOptionsPage;
	private CEoptionsPage cePage;
	private HholdingKeyConfigPage hhKeyConfigPage;
	private NegativeHholdDropPage nhhdPage;
	private HholdCustomPage chHPage;
	private CustomHholdModPage custHholdPage;
	private HholdSplitPage hhSplitRegPage;
	private RFStatsView rfStats;
	private RFSummaryPage sumPage;
	private RFCommonMethods rfCommMethods;
	private CommonMethods commMethods;
	private OracleDBHelper db;

	@Title("User Login with akp8 ")
	@Step("User Login")
	@BeforeTest
	(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
	public void LoginandSearchProj() throws InterruptedException {

		//driver = FusionFirefoxDriver.getDriver();
	    driver = FusionChromeDriver.getDriver();
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		rfHomePage = PageFactory.initElements(driver, RFHomePage.class);
		rfSetupPage = PageFactory.initElements(driver, NewRFSetupPage.class);
		dedupePage = PageFactory.initElements(driver, DedupeOptionsPage.class);
		supprOptionsPage = PageFactory.initElements(driver, SuppressionOptionsPage.class);
		cePage = PageFactory.initElements(driver, CEoptionsPage.class);
		hhKeyConfigPage = PageFactory.initElements(driver, HholdingKeyConfigPage.class);
		nhhdPage = PageFactory.initElements(driver, NegativeHholdDropPage.class);
		hhSplitRegPage = PageFactory.initElements(driver, HholdSplitPage.class);
		chHPage = PageFactory.initElements(driver, HholdCustomPage.class);
		custHholdPage = PageFactory.initElements(driver, CustomHholdModPage.class);
		rfStats = PageFactory.initElements(driver, RFStatsView.class);
		rfCommMethods = PageFactory.initElements(driver, RFCommonMethods.class);
		sumPage = PageFactory.initElements(driver, RFSummaryPage.class);

		commMethods.userLogin();
		commMethods.searchProject();
	}

	@Test(dataProvider = "InputData", priority=1,
			description = "TS1: New Refinement Setup Page UI Validations")
	public void newRfSetupPageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {

			testContext.setAttribute("WebDriver", this.driver);
			driver.findElement(By.xpath(".//a[contains(text(),'Refinement')]")).click();
			//ProjDashBoardPage.clickRFTab();
			rfHomePage.clickRFSetupButton();

			rfSetupPage.clickContinueButton();
			commMethods.verifyString(rfSetupPage.getErrMsg(), "Please enter valid process name.");

			rfSetupPage.processNameField(processName);
			rfSetupPage.clickContinueButton();
			commMethods.verifyString(rfSetupPage.getErrMsg(), "Select input table");

			rfSetupPage.selectProcessField(process);
			rfSetupPage.clickContinueButton();
			commMethods.verifyString(rfSetupPage.getErrMsg(), "Select input table");

			rfSetupPage.selectDataField(data);
			rfSetupPage.clickContinueButton();
			commMethods.verifyString(rfSetupPage.getErrMsg(), "Please select atleast one Refinement Option.");

			rfSetupPage.clickHholding();
			rfSetupPage.clickContinueButton();
			commMethods.verifyString(rfSetupPage.getErrMsg(), "Select Standard Household option.");

			rfSetupPage.clickNegativeHholdDrop();
			rfSetupPage.clickHholdSplitRegHholdDrop();
			rfSetupPage.clickCustomerElimination();
			rfSetupPage.clickSuppression();
			rfSetupPage.clickDedupe();
			rfSetupPage.clickContinueButton();
		}

	@Test(dataProvider = "InputData", priority=2, 
			description = "TS2: Householding Key Configuration Page UI Validations")
	public void hhKeyConfigPageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {

			commMethods.verifyString(hhKeyConfigPage.getTitle(), "Householding Key Configuration Complete the required information below, and then click 'Save' or 'Continue'.");
			hhKeyConfigPage.clickCustomRbutton();
			hhKeyConfigPage.clickContinueButton();
			commMethods.verifyString(hhKeyConfigPage.getErrMsg(), "At least one Household Key Field and a Priority Field must be selected for a Custom Household Key to process successfully.");

			rfCommMethods.selectCustomFields(keycustFields, keyPriField);
			hhKeyConfigPage.clickContinueButton();
			/*commMethods.verifyString(hhKeyConfigPage.getErrMsg(), "At least one Household Key Field and a Priority Field must be selected for a Custom Household Key to process successfully.");

			rfCommMethods.selectCustomFields(keycustFields, keyPriField);
			rfCommMethods.selectPriorityLevel(keyPriLevel);
			hhKeyConfigPage.clickContinueButton();*/
		}

	@Test(dataProvider = "InputData", priority=3,
			description = "TS3: Negative Household Drop Page UI Validation")
	public void nhhdPageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {

			commMethods.verifyString(nhhdPage.getTitle(), "Householding: Negative Household Drop Complete the required information below, and then click 'Save' or 'Continue'.");
			nhhdPage.clickContinueButton();
			commMethods.verifyString(nhhdPage.getErrMsg(), "Please select Record Types");

			commMethods.selectRecordTypes(process, nhdAllRecords, nhdAccepts, nhdRejects);
			nhhdPage.clickContinueButton();
			commMethods.verifyString(nhhdPage.getErrMsg(), "Please add at least one row in NHHD options.");

			nhhdPage.clickAddCondition();
			nhhdPage.criteriaLevel(nhhdCritLevel);
			nhhdPage.clickContinueButton();

			String errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[2]")).getText();
			commMethods.verifyString(errMsg, "Provide value for Reject Codes in row 1");

			nhhdPage.tagValue(nhhdTagValue);
			nhhdPage.clearCriteriaLevel();
			nhhdPage.rejectCode(nhhdRejCode);
			nhhdPage.clickContinueButton();

			errMsg = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/div[2]")).getText();
			commMethods.verifyString(errMsg, "Provide value for Criteria Level in row 1");

			nhhdPage.criteriaLevel(nhhdCritLevel);
			nhhdPage.clickContinueButton();	

		}
	
	@Test(dataProvider = "InputData", priority=4,
			description = "TS4: Household Split Page UI Validation")
	public void hhSplitPageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {
	
			commMethods.verifyString(hhSplitRegPage.getTitle(), "Household Complete the required information below, and then click 'Save' or 'Continue'.");

			hhSplitRegPage.clickContinueButton();
			commMethods.verifyString(hhSplitRegPage.getErrMsg(), "Please select Record Types");

			commMethods.selectRecordTypes(process, hhsAllRecords, hhsAccepts, hhsRejects);

			hhSplitRegPage.clickContinueButton();

		}

	@Test(dataProvider = "InputData", priority=5,
			description = "TS5: Household Customer Elemination Page UI Validation")
	public void cePageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {

			commMethods.verifyString(cePage.getTitle(), "Customer Elimination Options Complete the required information below, and then click 'Save' or 'Continue'.");

			cePage.clickContinueButton();
			commMethods.verifyString(cePage.getErrMsg(), "Please select Record Types");

			commMethods.selectRecordTypes(process, ceAllRecords, ceAccepts, ceRejects);
			rfCommMethods.selectRecordStatus(ceRecStatus);
			rfCommMethods.selectImportedFileRbutton(ceFromProcessImp);
			rfCommMethods.selectProcessForImpFile(ceProcess);
			rfCommMethods.selectDataForImpFile(ceData);
			cePage.clickContinueButton();

		}

	@Test(dataProvider = "InputData", priority=6,
			description = "TS6: Suppression Options Page UI Validation")
	public void suppressionPageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {

			commMethods.verifyString(supprOptionsPage.getTitle(), "Suppression Options Complete the required information below, and then click 'Save' or 'Continue'.");

			supprOptionsPage.clickContinueButton();
			commMethods.verifyString(supprOptionsPage.getErrMsg(), "Please select Record Types");

			commMethods.selectRecordTypes(process, supAllRecords, supAccepts, supRejects);
			supprOptionsPage.clickContinueButton();
			commMethods.verifyString(supprOptionsPage.getErrMsg(), "Select the Shipped file for previous project.");

			rfCommMethods.selectRecordStatus(supRecStatus);
			rfCommMethods.selectImportedFileRbutton(supFromProcImp);
			supprOptionsPage.clickContinueButton();
			commMethods.verifyString(supprOptionsPage.getErrMsg(), "Select the Process for Import file.");

			rfCommMethods.selectProcessForImpFile(supProcess);
			supprOptionsPage.clickContinueButton();
			commMethods.verifyString(supprOptionsPage.getErrMsg(), "Select the Data for Import file.");

			rfCommMethods.selectDataForImpFile(supData);
			supprOptionsPage.clickContinueButton();
		}

	@Test(dataProvider = "InputData", priority=7,
			description = "TS7: Dedupe Options Page UI Validation")
	public void dedupePageUI(String testRun, String TC, String Description,  String processName,
			String process, String data, String Hholding, String keyConfigField, String keycustFields,
			String keyPriField, String keyPriLevel, String nhhd, String nhdAllRecords, String nhdAccepts, 
			String nhdRejects, String nhdRecStatus, String nhhdCritLevel,String nhhdTagValue, String nhhdRejCode, 
			String hhSplit, String hhOptions, String hhsAllRecords, String hhsAccepts, String hhsRejects, 
			String hhsRecStatus, String customhh, String chAllRecords, String chAccepts, String chRejects, 
			String chRecStatus, String module1, String ce, String ceAllRecords, String ceAccepts, String ceRejects, 
			String ceRecStatus, String ceFromProcessImp, String ceProcess, String ceData, String suppression, 
			String supType, String supAllRecords, String supAccepts, String supRejects, String supRecStatus, 
			String supFromProcImp, String supProcess, String supData, String supLeftFields, String supRightFields, 
			String dedupe, String dedOptions, String dedAllRecords, String dedAccepts, String dedRejects, 
			String dedRecStatus, String customFields, String priorityField, String prioritySet, ITestContext testContext)
					throws Exception {
		String status = null;
		Modules module = new Modules();

			commMethods.verifyString(dedupePage.getTitle(), "Dedupe Options Complete the required information below, and then click 'Save' or 'Continue'.");

			dedupePage.clickContinueButton();
			commMethods.verifyString(dedupePage.getErrMsg(), "Please select dedupe option.");

			dedupePage.selectDedupeOptions(dedOptions);
			dedupePage.clickContinueButton();
			commMethods.verifyString(dedupePage.getErrMsg(), "Please select Record Types");

			commMethods.selectRecordTypes(process, dedAllRecords, dedAccepts, dedRejects);
			rfCommMethods.selectRecordStatus(dedRecStatus);
			dedupePage.clickContinueButton();
			commMethods.verifyString(dedupePage.getErrMsg(), "Please add fileds for dedupe fields");

/*			rfCommMethods.selectCustomFields(customFields, null);
			dedupePage.clickContinueButton();
			commMethods.verifyString(dedupePage.getErrMsg(), "Please add field for set priority");*/

			rfCommMethods.selectCustomFields(customFields, priorityField);
			dedupePage.clickContinueButton();

			String actRfSummary = driver.findElement(By.xpath(".//*[@id='contentArea']/div[3]/div/h3")).getText();
			String expRfSummary = "Summary: Refinement Review the information below, and then click on 'Submit' or 'Back'.";
			if(expRfSummary.equalsIgnoreCase(actRfSummary)){
				ProjDashBoardPage.clickRFTab();
				module.initializeDriver(driver);
				status =rfHomePage.getProcessStatus(processName);
				commMethods.verifyString(StatusEnum.READY.name(), status.trim());
			}
		}

	@DataProvider
	public Object[][] InputData() throws Exception {

		Object[][] testObjArray = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir")+PropertiesUtils.getProperty("path"), "RFprocess","UI");

		return (testObjArray);

	}

}

package com.equifax.cms.fusion.test.ip;

import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.utils.ExcelReader;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.InputLayoutVO;
import com.equifax.cms.fusion.test.vo.InputProcessVO;

public class InputDelimitedTestCase extends AbstractCoreTest
{
    private static final String EXISTING_LAYOUT = "Existing Layout";
	private static final String CREATE_NEW_LAYOUT = "Create New Layout";
	private static final String ASCII_DELIMITED = "ASCII Delimited";
    private static final Logger LOGGER = LoggerFactory.getLogger(InputDelimitedTestCase.class);
    private static final String IP = "Input";
    WebDriverWait wait;

    ExcelReader reader = new ExcelReader();

    @Step("IP Delim Save/Edit/Duplicate/Submit flow")
    @Test
    public void testIPDelimitedProcess() throws Exception
    {
        LOGGER.debug("-- IP delimited input -- ");
        List<InputProcessVO> list = reader.getInputProcessData();

        userLogin();
        String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
        searchProject(projectNumber);
        for (InputProcessVO vo : list)
        {
            if (ASCII_DELIMITED.equalsIgnoreCase(vo.getFormat()))
            {
                // Save ip process
                if (ProcessOperationEnum.SAVE.name().equalsIgnoreCase(vo.getOperation()))
                {
                    saveIPDelimitedProcess(vo.getProcessName(), vo);
                } else if (ProcessOperationEnum.EDIT.name().equalsIgnoreCase(vo.getOperation()))
                {
                    editIPDelimitedProcess(vo.getProcessName(), vo);
                } else if (ProcessOperationEnum.DUPLICATE.name().equalsIgnoreCase(vo.getOperation()))
                {
                    duplicateIPDelimitedProcess(vo.getProcessName(), vo);
                } else if (ProcessOperationEnum.SUBMIT.name().equalsIgnoreCase(vo.getOperation()))
                {
                    submitIPDelimitedProcess(vo.getProcessName(), vo);
                }
            }
        }
        userLogout();
        LOGGER.debug("--  logout -- ");

    }

    @Step("Save Input process {0}")
    public void saveIPDelimitedProcess(String processName, InputProcessVO vo) throws Exception
    {
        String status = null;

        navigateToProcess(IP);
        navigateToNewProcessPage("Import New File");
        // Test Case : Create a new input process, create a new layout,add one value in the layout selecting from customize, save, continue, do not //
        // run datacheck
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys(vo.getProcessName());
        new Select(driver.findElement(By.id("fileType"))).selectByVisibleText(vo.getType());// Get from csv
        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText(vo.getPurpose());// Get from csv
        driver.findElement(By.id("filePath")).clear();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys(vo.getLocation());// Get from csv
        driver.findElement(By.id("format3")).click();
        new Select(driver.findElement(By.id("delimiter"))).selectByVisibleText(vo.getDelimiter());
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(vo.getStartingSeq());

        // Get layout field details
        List<InputLayoutVO> layout = reader.getInputLayout(vo.getLayoutName());

        // Create a new layout with the fields provided in csv
        if (CREATE_NEW_LAYOUT.equalsIgnoreCase(vo.getInputLayout()))
        {
            driver.findElement(By.id("newLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            createNewLayout(vo.getLayoutName(), vo.getFormat());
        }
        // Use existing layout with the fields provided in csv from current project
        if (EXISTING_LAYOUT.equalsIgnoreCase(vo.getInputLayout()) && null == vo.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();

            int i = 1;
            boolean flag = false;
            int noOfRows = getNumberOfRowsExistingLayoutsForIPDelimited();
            while (flag == false && i <= noOfRows)
            {
                String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable1']/tbody/tr[" + i + "]/td[2]")).getText();
                if (str.equals(vo.getLayoutName())) // Get from csv
                {
                    flag = true;
                    // Gets the radio button that is closest to the layout to be selected
                    driver.findElement(By.xpath("//table[@id='savedLayoutsTable1']/tbody/tr[" + i + "]/td[1]/input")).click();
                    break;
                }
                i++;
            }
            editExistingLayout(layout, vo.getFormat(), vo.getLayoutNameNew());
        } else if (EXISTING_LAYOUT.equalsIgnoreCase(vo.getInputLayout()) && null != vo.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();
            searchLayoutFromOtherProject(vo.getLayoutName(), vo.getFormat(), vo.getSearchLayoutFromOtherProj());
            editExistingLayout(layout, vo.getFormat(), vo.getLayoutNameNew());
        }

        selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        delayThread(30000);

        // No datacheck functionality in delimited

        navigateToProcess(IP);

        status = getStatusIP();
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());
    }

    @Step("Edit existing process {0} ")
    private void editIPDelimitedProcess(String processName, InputProcessVO vo)
    {
        createAttachment(vo.toString());
        navigateToProcess(IP);
        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Edit")).click();
                modifyIPDelimitedProcess(vo, columns);
                break;
            }
        }
    }

    @Step("Duplicate Input process {0}")
    public void duplicateIPDelimitedProcess(String processName, InputProcessVO vo) throws Exception
    {
        // TestCase : Duplicate functionality works with all values complete
        navigateToProcess(IP);
        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                duplicateProcess();
                break;
            }
        }

        String status = getStatusIP();
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());
    }

    @Step("Submit Input process {0}")
    public void submitIPDelimitedProcess(String processName, InputProcessVO vo) throws Exception
    {
        // TestCase : View Summary
        // selectSummary();

        String status = null;

        navigateToProcess(IP);

        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Summary")).click();
                break;
            }
        }

        // Verification with user provided values, if values are coming correct from database in summary
        String ipProcessName = driver.findElement(By.xpath("//form[@id='ifpForm']/span")).getText();
        /*
         * int first = ipProcessName.indexOf(':') + 1; int second = ipProcessName.indexOf(':', first + 1);
         * Assert.assertEquals(vo.getProcessName().toLowerCase(), ipProcessName.substring(second + 1).toLowerCase().trim());
         */

        int first = ipProcessName.indexOf(':') + 1;
        Assert.assertEquals(vo.getProcessName().toLowerCase(), ipProcessName.substring(first + 1).toLowerCase().trim());

        String fileName = driver.findElement(By.xpath("//form[@id='ifpForm']/table/tbody/tr/td/span")).getText();
        if (null != vo.getLocation() && !("".equals(vo.getLocation())))
        {
        Assert.assertEquals(vo.getLocation().toLowerCase(), fileName.toLowerCase().trim());
        }
        
        String type = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[1]/td[2]")).getText();
        if (null != vo.getType() && !("".equals(vo.getType())))
            Assert.assertEquals(vo.getType().toLowerCase(), type.toLowerCase().trim());

        String purpose = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[2]/td[2]")).getText();
        if (null != vo.getPurpose() && !("".equals(vo.getPurpose())))
        {
        Assert.assertEquals(vo.getPurpose().toLowerCase(), purpose.toLowerCase().trim());
        }

        String format = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[3]/td[2]")).getText();
        if (null != vo.getFormat() && !("".equals(vo.getFormat())))
        {
        format = format.replaceAll("[_]", " ");
        Assert.assertEquals(vo.getFormat().toLowerCase(), format.toLowerCase().trim());
        }

        String startingSeq = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[7]/td[2]")).getText();
        if (null != vo.getStartingSeq() && !("".equals(vo.getStartingSeq())))
        {
        Assert.assertEquals(vo.getStartingSeq().toLowerCase(), startingSeq.toLowerCase().trim());
        }

        // TODO add invalid blank checkbox

        // Test Case : Submit the process with no datacheck from summary
        selectSubmit();
        navigateToProcess(IP);
        // String status = getStatusIP();

        // Status for the process should change to submitted
        List<WebElement> inputs1 = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs1)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                status = columns.get(3).getText().trim();
                break;
            }
        }
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());

        navigateToHome();
        String jobId = getJobId();

        testIPSubmitNoDC(jobId);
    }

    private void modifyIPDelimitedProcess(InputProcessVO vo, List<WebElement> columns)
    {
        // driver.findElement(By.id("processName")).clear();
        // driver.findElement(By.id("processName")).sendKeys(vo.getProcessName());
        new Select(driver.findElement(By.id("fileType"))).selectByVisibleText(vo.getType());// Get from csv
        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText(vo.getPurpose());// Get from csv
        driver.findElement(By.id("filePath")).clear();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys(vo.getLocation());// Get from csv
        driver.findElement(By.id("format3")).click();
        new Select(driver.findElement(By.id("delimiter"))).selectByVisibleText(vo.getDelimiter());
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(vo.getStartingSeq());

        // Get layout field details
        List<InputLayoutVO> layout = reader.getInputLayout(vo.getLayoutName());

        // Create a new layout with the fields provided in csv
        if (CREATE_NEW_LAYOUT.equalsIgnoreCase(vo.getInputLayout()))
        {
            driver.findElement(By.id("newLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            createNewLayout(vo.getLayoutName(), vo.getFormat());
        }
        // Use existing layout with the fields provided in csv from current project
        if (EXISTING_LAYOUT.equalsIgnoreCase(vo.getInputLayout()) && null == vo.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();

            int i = 1;
            boolean flag = false;
            int noOfRows = getNumberOfRowsExistingLayoutsForIPDelimited();
            while (flag == false && i <= noOfRows)
            {
                String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable1']/tbody/tr[" + i + "]/td[2]")).getText();
                if (str.equals(vo.getLayoutName())) // Get from csv
                {
                    flag = true;
                    // Gets the radio button that is closest to the layout to be selected
                    driver.findElement(By.xpath("//table[@id='savedLayoutsTable1']/tbody/tr[" + i + "]/td[1]/input")).click();
                    break;
                }
                i++;
            }
            editExistingLayout(layout, vo.getFormat(), vo.getLayoutNameNew());
        } else if (EXISTING_LAYOUT.equalsIgnoreCase(vo.getInputLayout()) && null != vo.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();
            searchLayoutFromOtherProject(vo.getLayoutName(), vo.getFormat(), vo.getSearchLayoutFromOtherProj());
            editExistingLayout(layout, vo.getFormat(), vo.getLayoutNameNew());
        }

        selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        delayThread(30000);

        // No datacheck functionality in delimited

        navigateToProcess(IP);

        String status = getStatusIP();
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());
    }

    @Step("Create new layout {0} ")
    private void createNewLayout(String layoutName, String format)
    {

        List<InputLayoutVO> layout = reader.getInputLayout(layoutName);
        driver.findElement(By.id("layoutName")).sendKeys(layoutName);

        // Fieldtype starts from 1
        int position = 1;
        int constCounter = 0;

        boolean selectAll = false;
        for (InputLayoutVO field : layout)
        {
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }

            /*
             * if(null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows()); //
             * If alert is present accept the alert acceptAndGetAlertText();
             */

            if (null != field.getFileType())
                new Select(driver.findElement(By.id("type"))).selectByVisibleText(field.getFileType());
            if (null != field.getPurpose())
                new Select(driver.findElement(By.id("purpose"))).selectByVisibleText(field.getPurpose());// get from csv
            if (null != field.getFieldType())
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());

            if (null != field.getCheckMulti())
            {
                if (field.getCheckMulti().equals("1"))
                {
                    driver.findElement(By.id("multi")).click();
            }
            }
            if (null != field.getCheckSingle())
            {
                if (field.getCheckSingle().equals("1"))
                {
                    driver.findElement(By.id("single")).click();
                }
            }

            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getFieldName())
            {
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
            }

            if (null != field.getConstName())
            {
                // Add constant
                driver.findElement(By.id("addField")).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());
                constCounter++;
            }

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }

    }

    @Step("Edit existing layout {0} ")
    private void editExistingLayout(List<InputLayoutVO> layout, String format, String layoutName)
    {
        // Go to existing layout page
        driver.findElement(By.id("submitLayout")).click();

        // Fieldtype starts from 1
        int position = getNumberOfColumnsLayoutTable();
        int constCounter = getNumberOfRowsConstTable();

        boolean selectAll = false;
        for (InputLayoutVO field : layout)
        {
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }

            /*
             * if (null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows()); //
             * If alert is present accept the alert acceptAndGetAlertText();
             */

            // Layout name is not null in case of edit layout when new layout name is provided
            if (null != layoutName)
            {
                driver.findElement(By.id("layoutNameNew")).clear();
                driver.findElement(By.id("layoutNameNew")).sendKeys(field.getLayoutName());
            }

            if (null != field.getFileType())
                new Select(driver.findElement(By.id("type"))).selectByVisibleText(field.getFileType());
            if (null != field.getPurpose())
                new Select(driver.findElement(By.id("purpose"))).selectByVisibleText(field.getPurpose());// get from csv

            // Set the fieldtypes and fieldnames

            if (null != field.getFieldType())
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());

            if (null != field.getFieldName())
            {
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
            }

            if (null != field.getCheckMulti())
            {
                if (field.getCheckMulti().equals("1"))
                {
                    driver.findElement(By.id("multi")).click();
                }
            }
            if (null != field.getCheckSingle())
            {
                if (field.getCheckSingle().equals("1"))
                {
                    driver.findElement(By.id("single")).click();
                }
            }
            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getConstName())
            {
                // Add constant
                driver.findElement(By.id("addField")).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());
                constCounter++;
            }

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }
    }

    @Step("Search layout from existing process")
    private void searchLayoutFromOtherProject(String layoutName, String format, String projNum)
    {
        // Click on search button
        driver.findElement(By.id("layoutSearchButton")).click();
        driver.findElement(By.id("projnum")).clear();
        driver.findElement(By.id("projnum")).sendKeys(projNum);
        driver.findElement(By.id("search")).click();
        int i = 1;
        boolean flag = false;
        int noOfRows = getNumberOfRowsOtherProjectLayoutTable();

        while (flag == false && i <= noOfRows)
        {
            String str = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[" + i + "]/td[1]/label")).getText();
            if (str.equals(layoutName)) // Get from csv
            {
                flag = true;
                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[" + i + "]/td[1]/input")).click();
                break;
            }
            i++;
        }
        // Continue to input process screen
        driver.findElement(By.cssSelector("input.orange-btn")).click();

    }


}


package com.equifax.cms.fusion.test.qareporting;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.REPORTINGPages.ReportingHomePage;
import com.equifax.cms.fusion.test.SRPPages.SRPStatsView;
import com.equifax.cms.fusion.test.SRPPages.SRPSummary;
import com.equifax.cms.fusion.test.SRPPages.StandardReportPages;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class StandardReportProcess
{
    public WebDriver driver;
    private CommonMethods commMethods;
    private ProjectDashBoardPage projDashBoardPage;
    private ReportingHomePage reportHomePage;
    private StandardReportPages StandardReportPages;
    private SRPStatsView srpStats;

    private OracleDBHelper oracleConnect;
    private SRPSummary srpSummary;
    private static final Logger LOGGER = LoggerFactory.getLogger(StandardReportProcess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        projDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        reportHomePage = PageFactory.initElements(driver, ReportingHomePage.class);
        StandardReportPages = PageFactory.initElements(driver, StandardReportPages.class);
        srpSummary = PageFactory.initElements(driver, SRPSummary.class);
        srpStats = PageFactory.initElements(driver, SRPStatsView.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "reg_SRP_Y", priority = 1)
    public void standardReportProcessY(String tc_Id, String testRun, String TC, String Description, String copyProject, String copyProcess,
            String processName, String process, String jobNumber, String data, String groups, String rangeOption, ITestContext testContext)
            throws InterruptedException
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        testContext.setAttribute("WebDriver", driver);
        if ("STRPT_ID_207".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickReportingTab();
            commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
            reportHomePage.selectEdit();
            commMethods.verifyString(StandardReportPages.processName_Field.getAttribute("value"), processName);
            commMethods.verifyString(StandardReportPages.getTableSelected(), data);
            commMethods.verifyString(StandardReportPages.getRangeValueSelected(), rangeOption);
        } else if ("STRPT_ID_208".equalsIgnoreCase(tc_Id))
        {
            projDashBoardPage.inputProjNum(copyProject);
            projDashBoardPage.clickCopyProjSrchBtn();
            projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
            projDashBoardPage.clickCopySelectBtn();
            projDashBoardPage.clickReportingTab();
            commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            reportHomePage.selectDuplicate();
            commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.ERROR.name().trim());
            reportHomePage.selectEdit();
            commMethods.verifyString(projDashBoardPage.getPageTitle(),
                    "Standard Report Package Complete the required information below, and then click 'Create Reports'.");

        } else
        {
            reportHomePage.clickReportingTab();
            reportHomePage.clickStandardReportbtn();
            String fProName = commMethods.getFinalProcessName();
            String procId = commMethods.getProcId();
            StandardReportPages.inputProcessName(processName);
            StandardReportPages.selectProcessField(process);
            StandardReportPages.selectDataField(data);
            commMethods.selectTheGroups(groups);
            StandardReportPages.clickRangeValueRadioButton(rangeOption);
            if ("STRPT_ID_211".equalsIgnoreCase(tc_Id) || "STRPT_ID_073".equalsIgnoreCase(tc_Id) || "STRPT_ID_074".equalsIgnoreCase(tc_Id)
                    || "STRPT_ID_075".equalsIgnoreCase(tc_Id) || "STRPT_ID_076".equalsIgnoreCase(tc_Id) || "STRPT_ID_077".equalsIgnoreCase(tc_Id))
            {
                StandardReportPages.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                String finalStat = projDashBoardPage.verifyProcess(fProName);
                commMethods.verifyString(finalStat, "PASS");
            } else if ("STRPT_ID_098".equalsIgnoreCase(tc_Id))
            {
                StandardReportPages.clickSaveButton();
                projDashBoardPage.clickReportingTab();
                commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                reportHomePage.selectDuplicate();
                commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.READY.name().trim());
                reportHomePage.selectSummary();
                srpSummary.clickSubmitBtn();
                commMethods.verifyString(reportHomePage.getProcessStatus(), StatusEnum.SUBMITTED.name().trim());
            } else if ("STRPT_ID_083".equalsIgnoreCase(tc_Id) || "STRPT_ID_088".equalsIgnoreCase(tc_Id) || "STRPT_ID_089".equalsIgnoreCase(tc_Id)
                    || "STRPT_ID_090".equalsIgnoreCase(tc_Id) || "STRPT_ID_091".equalsIgnoreCase(tc_Id) || "STRPT_ID_094".equalsIgnoreCase(tc_Id))
            {
                StandardReportPages.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                String finalStat = projDashBoardPage.verifyProcess(fProName);
                commMethods.verifyString(finalStat, "PASS");

            } else if ("STRPT_ID_186".equalsIgnoreCase(tc_Id))
            {
                commMethods.verifyString(StandardReportPages.processName_Field.getAttribute("type"), "text");
                commMethods.verifyString(StandardReportPages.processName_Field.getAttribute("name"), "name");
                StandardReportPages.clickSubmitButton();
                commMethods.verifyString(StandardReportPages.getErrorMsg_Text(), "Please enter the Process Name.");
            } else if ("STRPT_ID_078".equalsIgnoreCase(tc_Id) || "STRPT_ID_079".equalsIgnoreCase(tc_Id) || "STRPT_ID_080".equalsIgnoreCase(tc_Id)
                    || "STRPT_ID_081".equalsIgnoreCase(tc_Id))
            {
                StandardReportPages.clickSubmitButton();
                projDashBoardPage.clickHomeTab();
                String finalStat = projDashBoardPage.verifyProcess(fProName);
                commMethods.verifyString(finalStat, "PASS");
            }
        }

    }

    @Test(dataProvider = "reg_SRP_CPY", priority = 1, description = "TS: SRP process Verification", enabled = false)
    public void copySRPProcess(String tc_ID, String testRun, String tc, String description, String copyProject, String copyProcess,
            String processName, String process, String data, String jobNumberWhenMulArchive, String rangeOption, ITestContext testContext)
            throws InterruptedException
    {
        String status = null;
        Modules module = new Modules();
        projDashBoardPage.inputProjNum(copyProject);
        projDashBoardPage.clickCopyProjSrchBtn();
        projDashBoardPage.selectCopyPrevProjProcName(copyProcess);
        projDashBoardPage.clickCopySelectBtn();
        projDashBoardPage.clickDataProcessingTab();
        module.initializeDriver(driver);
        if ("STRPT_ID_207".equalsIgnoreCase(tc))
        {
            status = commMethods.getProcessStatus();
            commMethods.verifyString(status, StatusEnum.ERROR.name().trim());
            module.selectEdit();
            commMethods.verifyString(StandardReportPages.processNameValue(), processName);
            commMethods.verifyboolean(StandardReportPages.isSpecificRangeValueRadioButton(rangeOption), true);
        }
        if ("STRPT_ID_208".equalsIgnoreCase(tc))
        {
            status = commMethods.getProcessStatus();
            commMethods.verifyString(status, StatusEnum.ERROR.name().trim());
            module.selectEdit();
            StandardReportPages.inputProcessName("NewProcessName");
            StandardReportPages.clickSaveButton();
            reportHomePage.clickReportingTab();
            module.selectEdit();
            commMethods.verifyString(StandardReportPages.processNameValue(), "NewProcessName");

        }

    }

    @Test(dataProvider = "reg_SRP_CBA", priority = 1)
    public void standardReportProcessCBA(String tc_Id, String testRun, String TC, String Description, String copyProject, String copyProcess,
            String processName, String process, String jobNumberWhenMulArchive, String data, String groups, String rangeOption,
            ITestContext testContext) throws InterruptedException
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        testContext.setAttribute("WebDriver", driver);
        oracleConnect = new OracleDBHelper();
        reportHomePage.clickReportingTab();
        reportHomePage.clickStandardReportbtn();
        String fProName = commMethods.getFinalProcessName();
        String procId = commMethods.getProcId();
        StandardReportPages.inputProcessName(processName);
        StandardReportPages.selectProcessField(process);
        StandardReportPages.selectDataField(data);
        if ("STRPT_ID_195".equalsIgnoreCase(TC))
        {
            commMethods.verifyboolean(StandardReportPages.ifThreeRadioButtonsDisplayed(), true);
        }
        StandardReportPages.clickRangeValueRadioButton(rangeOption);

        if ("STRPT_ID_095".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String finalStat = projDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(finalStat, "PASS");
            projDashBoardPage.viewStats(procId);

            commMethods.verifyboolean(StandardReportPages.isDistributionReportInStats(), true);

        }
        if ("STRPT_ID_096".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickSubmitButton();
            projDashBoardPage.clickHomeTab();
            String finalStat = projDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(finalStat, "PASS");
            oracleConnect.getConnection();
            String jobNo = oracleConnect.getJobEntryInFulfillmentJobTable(fProName + "_" + processName);
            String getJobNumber = commMethods.getJobNum();
            commMethods.verifyString(jobNo, getJobNumber);

        }
        if ("STRPT_ID_097".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickSubmitButton();
            status = StandardReportPages.getSRPStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            module.selectDuplicate();
            String[] part = procId.split("(?<=\\D)(?=\\d)");
            System.out.println(part[0]);
            System.out.println(part[1]);
            module.selectSummary();
            commMethods.verifyString(srpSummary.getProcessName(), process);

        }
        if ("STRPT_ID_099".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickSubmitButton();
            status = StandardReportPages.getSRPStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            module.selectDuplicate();
            Thread.sleep(2000);
            module.selectEdit();
            StandardReportPages.inputProcessName("new_process");
            commMethods.verifyboolean(processName.equals("new_process"), false);
        }
        if ("STRPT_ID_100".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickSubmitButton();
            status = StandardReportPages.getSRPStatus();
            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            module.selectDuplicate();
            Thread.sleep(2000);
            module.selectEdit();
            commMethods.verifyString(StandardReportPages.processNameValue(), processName);
            commMethods.verifyString(StandardReportPages.getSelectedProcess(), process);
            commMethods.verifyString(StandardReportPages.getSelectedData(), data);
            commMethods.verifyboolean(StandardReportPages.isSpecificRangeValueRadioButton(rangeOption), true);

        }

        if ("STRPT_ID_196".equalsIgnoreCase(TC))
        {
            StandardReportPages.clickBackButton();
            // driver.switchTo().alert();
            commMethods.verifyString("Do you want to leave this site?", driver.switchTo().alert().getText());

            // commMethods.verifyString("This page is asking you to confirm that you want to leave - data you have entered may not be saved.", driver
            // .switchTo().alert().getText());
            LOGGER.info("Confirmation Message :" + driver.switchTo().alert().getText());

        }
        if ("STRPT_ID_197".equalsIgnoreCase(TC))
        {
            commMethods.verifyboolean(StandardReportPages.isSelectElementPresent(), true);
            commMethods.verifyboolean(StandardReportPages.isOptionAvailable(), true);
        }
        // later
        if ("STRPT_ID_210".equalsIgnoreCase(TC))
        {
            StandardReportPages.selectJobField(jobNumberWhenMulArchive);
            StandardReportPages.clickSubmitButton();
            String errMsg = procId
                    + " : "
                    + processName
                    + " : There are multiple tables associated with due to multiple Credit Datasets selected in the associated Data Menu. The job number must be selected for the input.";
            commMethods.verifyString(StandardReportPages.getErrorMessage(), errMsg);
            StandardReportPages.selectJobField(jobNumberWhenMulArchive);
            StandardReportPages.clickSubmitButton();

            projDashBoardPage.clickHomeTab();
            String Status = projDashBoardPage.verifyProcess(procId);
            commMethods.verifyString(Status, "PASS");
            projDashBoardPage.viewStats(procId);

            commMethods.verifyboolean(StandardReportPages.isDistributionReportInStats(), true);

        }
    }
    
	@Test(dataProvider = "reg_SRP_BASE") // BaseProcess
	public void standardReportBaseProcess(String tc_Id, String testRun, String TC, String Description,
			String copyProject, String copyProcess, String processName, String process, String jobNumber, String data,
			String groups, String rangeOption, ITestContext testContext) throws InterruptedException {
		String executionStatus = commMethods.getTheExecutionStatus(process);
		if (executionStatus.equalsIgnoreCase("COMPLETED")) {
			String status = null;
			Modules module = new Modules();
			module.initializeDriver(driver);
			testContext.setAttribute("WebDriver", driver);
			reportHomePage.clickReportingTab();
			reportHomePage.clickStandardReportbtn();
			String fProName = commMethods.getFinalProcessName();
			String procId = commMethods.getProcId();
			StandardReportPages.inputProcessName(processName);
			StandardReportPages.selectProcessField(process);
			StandardReportPages.selectDataField(data);
			commMethods.selectTheGroups(groups);
			StandardReportPages.clickRangeValueRadioButton(rangeOption);
			srpSummary.clickSubmitBtn();
		}
	}
    
    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] reg_SRP_Y() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SRPprocess", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] reg_SRP_CPY() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SRPprocess", "CPY");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] reg_SRP_CBA() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SRPprocess", "CBA");
        return testObjArray_Y;
    }
    
    @DataProvider
    public Object[][] reg_SRP_BASE() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SRPprocess", "BAS");
        return testObjArray_Y;
    }

}

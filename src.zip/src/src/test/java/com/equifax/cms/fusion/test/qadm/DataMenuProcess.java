package com.equifax.cms.fusion.test.qadm;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang3.StringUtils;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.DMPages.APmodulePage;
import com.equifax.cms.fusion.test.DMPages.ConfigDeStandPage;
import com.equifax.cms.fusion.test.DMPages.ConfigIdScanPage;
import com.equifax.cms.fusion.test.DMPages.CreditInputPage;
import com.equifax.cms.fusion.test.DMPages.CriteriaRejectsPage;
import com.equifax.cms.fusion.test.DMPages.DMFilterConfigPage;
import com.equifax.cms.fusion.test.DMPages.DMSummaryPage;
import com.equifax.cms.fusion.test.DMPages.DataMenuHomePage;
import com.equifax.cms.fusion.test.DMPages.DataOriginPage;
import com.equifax.cms.fusion.test.DMPages.DmStatsView;
import com.equifax.cms.fusion.test.DMPages.DoubleCheckPage;
import com.equifax.cms.fusion.test.DMPages.ModuleDependenciesPage;
import com.equifax.cms.fusion.test.DMPages.ModuleOutputsPage;
import com.equifax.cms.fusion.test.DMPages.PointScoreDropsPage;
import com.equifax.cms.fusion.test.DMPages.PreSelectsPage;
import com.equifax.cms.fusion.test.DMPages.ProcessNamePage;
import com.equifax.cms.fusion.test.DMPages.ProductPage;
import com.equifax.cms.fusion.test.DMPages.ScoreModelsPage;
import com.equifax.cms.fusion.test.DMPages.SourceInputPage;
import com.equifax.cms.fusion.test.DMPages.StateZipCodeInputPage;
import com.equifax.cms.fusion.test.FILPages.DataProcessingTabFIL;
import com.equifax.cms.fusion.test.FILPages.FilteringPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
//import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeDriverService;

import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

public class DataMenuProcess extends AbstractCoreTest
{

    boolean flag = false;
    public WebDriver driver;
    public OracleDBHelper db;
    public static int i = 1;
    public static List<WebElement> scoreModelElem;
    private ProjectDashBoardPage ProjDashBoardPage;
    private APmodulePage APModPag;
    private ConfigDeStandPage ConfigDEPag;
    private ConfigIdScanPage ConfigIDPag;
    private CreditInputPage CreditInPag;
    private CriteriaRejectsPage CritRejPag;
    private DataMenuHomePage DataMenuHomPag;
    private DataOriginPage DataOriginPag;
    private DMFilterConfigPage DMFilterConPag;
    private DMSummaryPage DMSummPag;
    private DmStatsView DmStatView;
    private DoubleCheckPage DoubleChckPag;
    private ModuleDependenciesPage ModDepenPag;
    private ModuleOutputsPage ModOutptPag;
    private PointScoreDropsPage PointScrDropPag;
    private PreSelectsPage PreSelPag;
    private ProcessNamePage ProcesNamePag;
    private ProductPage ProdPag;
    private ScoreModelsPage ScreModlPag;
    private StateZipCodeInputPage StZipCodInPag;
    private CommonMethods commMethods;
    private SourceInputPage SrcInpPag;
    private Modules module;
    private DataProcessingTabFIL dpHomePage;
    private FilteringPage filterPage;

    private static final String DIM_ERRMSG = "Please select credit dataset with dimensions.";
    private static final Logger LOGGER = LoggerFactory.getLogger(DataMenuProcess.class);
    private static final String SAVETOFILE = "Save to File";
    private static final List<String> ACCEPTCODES = Arrays.asList("A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q",
            "R", "S", "T", "U", "V", "W", "X", "Y", "Z");
        
    @Step("Login and Search Project No.")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginAndSearchProj() throws InterruptedException, IOException
    {
        //driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        
        
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS); 
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        APModPag = PageFactory.initElements(driver, APmodulePage.class);
        ConfigDEPag = PageFactory.initElements(driver, ConfigDeStandPage.class);
        ConfigIDPag = PageFactory.initElements(driver, ConfigIdScanPage.class);
        CreditInPag = PageFactory.initElements(driver, CreditInputPage.class);
        CritRejPag = PageFactory.initElements(driver, CriteriaRejectsPage.class);
        DataMenuHomPag = PageFactory.initElements(driver, DataMenuHomePage.class);
        DataOriginPag = PageFactory.initElements(driver, DataOriginPage.class);
        DMFilterConPag = PageFactory.initElements(driver, DMFilterConfigPage.class);
        DMSummPag = PageFactory.initElements(driver, DMSummaryPage.class);
        DoubleChckPag = PageFactory.initElements(driver, DoubleCheckPage.class);
        ModDepenPag = PageFactory.initElements(driver, ModuleDependenciesPage.class);
        ModOutptPag = PageFactory.initElements(driver, ModuleOutputsPage.class);
        PointScrDropPag = PageFactory.initElements(driver, PointScoreDropsPage.class);
        PreSelPag = PageFactory.initElements(driver, PreSelectsPage.class);
        ProcesNamePag = PageFactory.initElements(driver, ProcessNamePage.class);
        ProdPag = PageFactory.initElements(driver, ProductPage.class);
        ScreModlPag = PageFactory.initElements(driver, ScoreModelsPage.class);
        StZipCodInPag = PageFactory.initElements(driver, StateZipCodeInputPage.class);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        SrcInpPag = PageFactory.initElements(driver, SourceInputPage.class);
        DmStatView = PageFactory.initElements(driver, DmStatsView.class);
        module = PageFactory.initElements(driver, Modules.class);
        dpHomePage = PageFactory.initElements(driver, DataProcessingTabFIL.class);
        filterPage = PageFactory.initElements(driver, FilteringPage.class);

        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Title("Data Menu Validations")
    @Description("Data Menu with dimension datasets, xml validations, submit validations")
    @Test(dataProvider = "dm_Reg1", priority = 2) //DEV
    public void dataMenuValidationTesting(String tc_Id, String testRun, String TC, String Description, String copyProj, String copyProcName,
            String processName, String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess,
            String dataField, String zipCodeInput, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
            String APModuleCriteria, String depProj, String depFile, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
            String NCPScoreModel, String pointScoreDrop, String scoreParams, String idScan, String idScanRejects, String deStandard,
            String doublechck, String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, String cid_CNX,
            String availableDataSets, String dataSetType, String DataSet, String runStatus, ITestContext testContext) throws Exception
    {

        List<String> scoreParamNameList = new ArrayList<>();

        testContext.setAttribute("WebDriver", this.driver);

        ProjDashBoardPage.clickDataMenuTab();
        DataMenuHomPag.clickDataMenuButton();

        ProcesNamePag.InputProcessNameField(processName);
        ProcesNamePag.clickContinueButton();
        DataOriginPag.selectDataOriginField(DataOriginField);
        DataOriginPag.clickContinueButton();

        if ("DM_ID_222".equalsIgnoreCase(tc_Id) || "DM_ID_232".equalsIgnoreCase(tc_Id) || "DM_ID_233".equalsIgnoreCase(tc_Id)
                || "DM_ID_234".equalsIgnoreCase(tc_Id) || "DM_ID_235".equalsIgnoreCase(tc_Id) || "DM_ID_236".equalsIgnoreCase(tc_Id)
                || "DM_ID_237".equalsIgnoreCase(tc_Id) || "DM_ID_238".equalsIgnoreCase(tc_Id) || "DM_ID_240".equalsIgnoreCase(tc_Id)
                || "DM_ID_244".equalsIgnoreCase(tc_Id) || "DM_ID_247".equalsIgnoreCase(tc_Id) || "DM_ID_251".equalsIgnoreCase(tc_Id))
        {
            ProdPag.selectProductField(Product);
            if (!"NA".equals(productId) && !"NA".equals(MemNum))
            {
                ProdPag.productIdField(productId);
                ProdPag.memberNumberField(MemNum);
            }
        }

        ProdPag.clickContinueButton();

        if (DataOriginField.equalsIgnoreCase("List Source"))
        {
            SrcInpPag.selectProcessField(smProcess);
            SrcInpPag.selectDataField(dataField);
            SrcInpPag.clickContinueButton();
        }

        if ("DM_ID_004".equalsIgnoreCase(tc_Id))
        {
            StZipCodInPag.selectZipCodeInputField(zipCodeInput);
        }

        StZipCodInPag.selectStatesList(stateList);

        // Test cases requiring state drop down values
        if ("DM_ID_254".equalsIgnoreCase(tc_Id) || "DM_ID_410".equalsIgnoreCase(tc_Id) || "DM_ID_413".equalsIgnoreCase(tc_Id)
                || "DM_ID_411".equalsIgnoreCase(tc_Id))
        {
            StZipCodInPag.selectStatesDropDwn(states);
        }

        if ("DM_ID_254".equalsIgnoreCase(tc_Id))
        {
            StZipCodInPag.Ele_reject.click();
        }

        StZipCodInPag.clickContinueButton();

        // dont select any apmodule
        if ("DM_ID_150".equalsIgnoreCase(tc_Id) || "DM_ID_153".equalsIgnoreCase(tc_Id) || "DM_ID_154".equalsIgnoreCase(tc_Id))
        {
            APModPag.clickContinueButton();
        } else
        {
            // select an apmodule
        	APModPag.clickUseProdAPmoduleOnly(prodAPmod);
        	Thread.sleep(3000);
        	APModPag.selApModNonCriteria(APModuleNonCriteria);
        	APModPag.selAPmodWithCritRej(APModuleCriteria);
            Thread.sleep(3000);
            APModPag.selScoreModel(scoreModel);
            Thread.sleep(3000);
            
            APModPag.errorToReadyInGrid();
            
            APModPag.numPerAccValue(NumPerAccCode);
            APModPag.numPerRejValue(NumPerRejCode);
            APModPag.checkHoldMvSt(HoldData);
            APModPag.clickContinueButton();
        }

        if ("DM_ID_130".equalsIgnoreCase(tc_Id))
        {
            CritRejPag.clickContinueButton();
        }

        if ("DM_ID_029".equalsIgnoreCase(tc_Id) || "DM_ID_131".equalsIgnoreCase(tc_Id))
        {
            CritRejPag.clickRejectRadiobutton();
            CritRejPag.clickContinueButton();
        }

        if ("DM_ID_028".equalsIgnoreCase(tc_Id))
        {
            ModOutptPag.InputnumperAcceptCodeField(NumPerAccCode);
            ModOutptPag.InputnumperRejectCodeField(NumPerRejCode);
        }

        if ("DM_ID_150".equalsIgnoreCase(tc_Id))
        {
            // do nothing
        } else
        {
//            ModOutptPag.clickContinueButton();
        }

        // tc requiring multiple score models
        if ("DM_ID_150".equalsIgnoreCase(tc_Id) || "DM_ID_283".equalsIgnoreCase(tc_Id))
        {
            String[] scoreModelSplit = scoreModel.split(",");
            String[] scoreParamsSplit = scoreParams.split(",");
            int i = 0;
            while (i < scoreModelSplit.length)
            {
                ScreModlPag.clickAddScoreModelButton();
                ScreModlPag.selectScoreModelFieldById(scoreModelSplit[i], i);
                Thread.sleep(2000);
                int k = 0;
                while (commMethods.isElementPresent_Xpath(".//*[@id='scoreParamDiv" + (i + 1) + "']/table/tbody/tr[" + (k + 2) + "]/td[1]/span"))
                {
                    // Get param names to be used in xml
                    scoreParamNameList.add(driver
                            .findElement(By.xpath(".//*[@id='scoreParamDiv" + (i + 1) + "']/table/tbody/tr[" + (k + 2) + "]/td[1]/span")).getText());
                    new Select(driver.findElement(By.xpath(".//*[@id='scoreParamDiv" + (i + 1) + "']/table/tbody/tr[" + (k + 2) + "]/td[2]/select")))
                            .selectByVisibleText(scoreParamsSplit[k]);
                    k++;
                }
                i++;

            }
        } else
        {
            /*if (!"NA".equals(scoreModel))
            {
                ScreModlPag.clickAddScoreModelButton();
                ScreModlPag.selectScoreModelField(scoreModel);
                Thread.sleep(2000);
                if (!"NA".equals(scoreParams))
                {
                    ScreModlPag.selectScoreParameters(scoreParams);
                }
            }*/
        }

        if ("DM_ID_029".equalsIgnoreCase(tc_Id))
        {
            ScreModlPag.selectRejectScoreModel();
        }

        /*if (!"NA".equals(APModuleNonCriteria))
            ScreModlPag.clickContinueButton();*/

        if ("DM_ID_150".equalsIgnoreCase(tc_Id))
            ScreModlPag.clickContinueButton();

        if ("DM_ID_120".equalsIgnoreCase(tc_Id) || "DM_ID_150".equalsIgnoreCase(tc_Id) || "DM_ID_153".equalsIgnoreCase(tc_Id)
                || "DM_ID_154".equalsIgnoreCase(tc_Id) || "DM_ID_261".equalsIgnoreCase(tc_Id) || "DM_ID_263".equalsIgnoreCase(tc_Id)
                || "DM_ID_578".equalsIgnoreCase(tc_Id) || "DM_ID_579".equalsIgnoreCase(tc_Id) || "DM_ID_580".equalsIgnoreCase(tc_Id))
            ConfigIDPag.clickRunIdScanCheckBox();

        if ("DM_ID_053".equalsIgnoreCase(tc_Id))
        {
            ConfigIDPag.ClickCheckAllCB();
            ConfigIDPag.Ele_ssnNeverIssuedCB.click();
            ConfigIDPag.Ele_addrMutliDwellingCB.click();
            ConfigIDPag.Ele_addressMisused.click();
        }

        if ("DM_ID_056".equalsIgnoreCase(tc_Id))
        {
            ConfigIDPag.clickRejectRButton();
            ConfigIDPag.ClickCheckAllCB();
            ConfigIDPag.Ele_ssnNeverIssuedCB.click();
            ConfigIDPag.Ele_addrMutliDwellingCB.click();
            ConfigIDPag.Ele_addressMisused.click();
        }

        // DM_ID_058
        if ("DM_ID_126".equalsIgnoreCase(tc_Id))
        {
            ConfigIDPag.clickTagRButton();
            ConfigIDPag.ClickCheckAllCB();
            ConfigIDPag.Ele_ssnNeverIssuedCB.click();
            ConfigIDPag.Ele_addrMutliDwellingCB.click();
            ConfigIDPag.Ele_addressMisused.click();
        }

        if ("DM_ID_128".equalsIgnoreCase(tc_Id) || "DM_ID_029".equalsIgnoreCase(tc_Id))
        {
            ConfigIDPag.clickRejectRButton();
        }

        if ("DM_ID_129".equalsIgnoreCase(tc_Id))
        {
            ConfigIDPag.clickTagRButton();
        }

        ConfigIDPag.clickContinueButton();

        if ("DM_ID_120".equalsIgnoreCase(tc_Id) || "DM_ID_153".equalsIgnoreCase(tc_Id) || "DM_ID_154".equalsIgnoreCase(tc_Id)
                || "DM_ID_261".equalsIgnoreCase(tc_Id) || "DM_ID_263".equalsIgnoreCase(tc_Id) || "DM_ID_578".equalsIgnoreCase(tc_Id)
                || "DM_ID_579".equalsIgnoreCase(tc_Id) || "DM_ID_580".equalsIgnoreCase(tc_Id))
            ConfigDEPag.clickRunDeStandardsChckBox();

        ConfigDEPag.clickContinueButton();

        if ("DM_ID_029".equalsIgnoreCase(tc_Id) || "DM_ID_077".equalsIgnoreCase(tc_Id) || "DM_ID_081".equalsIgnoreCase(tc_Id)
                || "DM_ID_092".equalsIgnoreCase(tc_Id))
        {
            DoubleChckPag.clickRunDoubleChckBox();
            DoubleChckPag.clickEditImage();
            DoubleChckPag.CB_CC_A.click();
            DoubleChckPag.CB_CC_B.click();
            DoubleChckPag.CB_CC_C.click();
            DoubleChckPag.A_PHASE_SSN_DBCK.click();
            DoubleChckPag.B_ANB_BNKCRD_SSN_DBCK.click();
            DoubleChckPag.C_ANB_BNKCRD_ADR_DBCK.click();
            DoubleChckPag.D_ANB_PRV_LAB_SSN_DBCK.click();
            DoubleChckPag.E_ANB_PRV_LAB_ADR_DBCK.click();
            DoubleChckPag.saveEditCritCodeWindow();
            driver.switchTo().defaultContent();
            Thread.sleep(2000);

            if ("DM_ID_029".equalsIgnoreCase(tc_Id) || "DM_ID_081".equalsIgnoreCase(tc_Id))
            {
                DoubleChckPag.sel_SSN_Reject();
                DoubleChckPag.sel_Addr_Reject();
            }

            if ("DM_ID_092".equalsIgnoreCase(tc_Id))
            {
                DoubleChckPag.sel_SSN_Tag();;
                DoubleChckPag.sel_Addr_Tag();;
            }
        }

        if ("DM_ID_108".equalsIgnoreCase(tc_Id))
        {
            DoubleChckPag.clickRunDoubleChckBox();
            DoubleChckPag.selectDoubleChckType("Citi");
            DoubleChckPag.EditImage1.click();
            driver.switchTo().frame("sb-player");
            DoubleChckPag.CB_CC_A.click();
            DoubleChckPag.CB_CC_B.click();
            DoubleChckPag.CB_CC_C.click();
            DoubleChckPag.A_PHASE_SSN_DBCK.click();
            DoubleChckPag.B_ANB_BNKCRD_SSN_DBCK.click();
            DoubleChckPag.C_ANB_BNKCRD_ADR_DBCK.click();
            DoubleChckPag.D_ANB_PRV_LAB_SSN_DBCK.click();
            DoubleChckPag.E_ANB_PRV_LAB_ADR_DBCK.click();
            DoubleChckPag.saveEditCritCodeWindow();
            driver.switchTo().defaultContent();
            Thread.sleep(2000);
            DoubleChckPag.sel_SSN_Tag();;
            DoubleChckPag.sel_Addr_Tag();;
        }

        DoubleChckPag.clickContinueButton();

        if ("DM_ID_009".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.click_Edit_Invalid_Drop();
            DMFilterConPag.click_Conf_Inv_Drop_ALL();
            DMFilterConPag.CB_Conf_Inv_Street_Address.click();
            DMFilterConPag.SaveInvalidDropWindow.click();
        }

        if ("DM_ID_013".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.click_Edit_Invalid_Drop();
            DMFilterConPag.click_Conf_Inv_Drop_ALL();
            DMFilterConPag.CB_Inv_SubName.click();
            DMFilterConPag.SaveInvalidDropWindow.click();
        }

        if ("DM_ID_045".equalsIgnoreCase(tc_Id))
        {

            // WebElement element = driver.findElement(By.name("source")); WebElement target = driver.findElement(By.name("target")); (new
            // Actions(driver)).dragAndDrop(element, target).perform();

            // TODO drag not working
            WebElement element = DMFilterConPag.idScanDiv;
            WebElement target = DMFilterConPag.deStdDiv;
            (new Actions(driver)).dragAndDrop(element, target).build().perform();
        }

        if ("DM_ID_119".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickFactActEdit();
            DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code.click();
            DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            DMFilterConPag.click540file();
            DMFilterConPag.click_Save_button_Fact_Act();
        }

        if ("DM_ID_120".equalsIgnoreCase(tc_Id) || "DM_ID_261".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.clickFactActEdit();
            DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code.click();
            DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            DMFilterConPag.click540file();
            DMFilterConPag.click_Save_button_Fact_Act();
        }

        if ("DM_ID_263".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.clickFactActEdit();
            // check all unchecked fact act options
            DMFilterConPag.CB_Reject_Address_Variance_Code.click();
            DMFilterConPag.click_Save_button_Fact_Act();
        }

        // Validate that following element is added to the JobRun section <keyValue name="MLA_JOB">Y</keyValue>
        if ("DM_ID_447".equalsIgnoreCase(tc_Id) || "DM_ID_450".equalsIgnoreCase(tc_Id) || "DM_ID_471".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickMLAStatusCB();
        }

        if ("DM_ID_578".equalsIgnoreCase(tc_Id) || "DM_ID_579".equalsIgnoreCase(tc_Id) || "DM_ID_580".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            // DMFilterConPag.click_Edit_Invalid_Drop();
            // DMFilterConPag.click_Conf_Inv_Drop_ALL();
            // DMFilterConPag.SaveInvalidDropWindow.click();
            DMFilterConPag.clickFactActEdit();
            // DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code.click();
            // DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            DMFilterConPag.click540file();
            DMFilterConPag.click_Save_button_Fact_Act();
        }

        if ("DM_ID_150".equalsIgnoreCase(tc_Id) || "DM_ID_153".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.clickFactActEdit();
            Thread.sleep(1000);
            DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code.click();
            DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            DMFilterConPag.click_Save_button_Fact_Act();
            DMFilterConPag.click_Edit_Invalid_Drop();
            Thread.sleep(1000);
            DMFilterConPag.click_Conf_Inv_Drop_ALL();
            DMFilterConPag.SaveInvalidDropWindow.click();
        }

        if ("DM_ID_154".equalsIgnoreCase(tc_Id))
        {
            DMFilterConPag.clickDNSdropChckBox();
            DMFilterConPag.clickInvalidBlankAgeChckBox();
            // Dont uncheck test file drop
            // DMFilterConPag.clickTestFileDropChckBox();
            DMFilterConPag.clickFactActEdit();
            DMFilterConPag.CB_Fact_Act_Reject_Fraud_Code.click();
            DMFilterConPag.CB_Fact_Act_Reject_AFS_Alert_Data_BFMN.click();
            DMFilterConPag.click_Save_button_Fact_Act();
            DMFilterConPag.click_Edit_Invalid_Drop();
            DMFilterConPag.click_Conf_Inv_Drop_ALL();
            DMFilterConPag.SaveInvalidDropWindow.click();
        }

        DMFilterConPag.clickContinueButton();

        // Validate that when "CMS segment" check box is checked, dataset with CMS segments are only displayed in available datasets.
        if ("DM_ID_148".equalsIgnoreCase(tc_Id) || "DM_ID_149".equalsIgnoreCase(tc_Id))
        {
            List<String> idList = CreditInPag.getLiIdForDimensionsCB();
            List<String> idListNoCMSSegment = new ArrayList<>();
            List<String> idListCMSSegment = new ArrayList<>();
            int i = 0;
            while (i < idList.size())
            {
                if (idList.get(i).contains("segmentCMS"))
                    idListCMSSegment.add(idList.get(i));
                else
                    idListNoCMSSegment.add(idList.get(i));
                i++;
            }

            Assert.assertTrue(idListNoCMSSegment.isEmpty());
            Assert.assertTrue(!idListCMSSegment.isEmpty());
        }

        // Validate that if none among 6 options is selected, than CMS segment check box is deslected ,enabled and all datasets are displayed in
        // available datasets.
        if ("DM_ID_150".equalsIgnoreCase(tc_Id) || "DM_ID_153".equalsIgnoreCase(tc_Id))
        {
            CreditInPag.selectSpcificDataSet();

            String disabledAttr = CreditInPag.cb_segmentCMS.getAttribute("disabled");
            String checkedAttr = CreditInPag.cb_segmentCMS.getAttribute("checked");

            commMethods.verifyString(disabledAttr, null);
            commMethods.verifyString(checkedAttr, null);

            List<String> idList = CreditInPag.getLiIdForDimensionsCB();
            List<String> idListNoCMSSegment = new ArrayList<>();
            List<String> idListCMSSegment = new ArrayList<>();
            int i = 0;
            while (i < idList.size())
            {
                if (idList.get(i).contains("segmentCMS"))
                    idListCMSSegment.add(idList.get(i));
                else
                    idListNoCMSSegment.add(idList.get(i));
                i++;
            }

            Assert.assertTrue(!idListNoCMSSegment.isEmpty());
            Assert.assertTrue(!idListCMSSegment.isEmpty());

        }

        // Validate that if any of the 6 options is selected, than CMS segment check box is selected and disabled
        if ("DM_ID_154".equalsIgnoreCase(tc_Id))
        {
            CreditInPag.selectSpcificDataSet();

            String disabledAttr = CreditInPag.cb_segmentCMS.getAttribute("disabled");
            String checkedAttr = CreditInPag.cb_segmentCMS.getAttribute("checked");

            commMethods.verifyString(disabledAttr, "true");
            commMethods.verifyString(checkedAttr, "true");

        }

        // Validate in DE DM job that when the job requires NC+ data, the user is restricted to credit datasets with Resplit flag (split by Connexus)
        // that are no older than the most recent Golden.
        if ("DM_ID_234".equalsIgnoreCase(tc_Id) || "DM_ID_235".equalsIgnoreCase(tc_Id))
        {
            List<String> availableDatasetsId = CreditInPag.getDatasetIdsFromAvailableDatasets();
            int i = 0;
            WebElement recentGoldenEle = driver.findElement(By.id(DataSet));
            String recentGolden = recentGoldenEle.getAttribute("id");
            String recentGolden_1PCT = null;
            if (recentGolden.contains("_1PCT"))
            {
                recentGolden_1PCT = recentGolden.substring(0, recentGolden.indexOf("_1PCT"));

            }
            while (i < availableDatasetsId.size())
            {
                if (availableDatasetsId.get(i).contains("_1PCT"))
                {
                    if (null != recentGolden_1PCT)
                    {
                        Date availableDate = new SimpleDateFormat("yyyyMMdd")
                                .parse(availableDatasetsId.get(i).substring(0, recentGolden_1PCT.indexOf("_1PCT")));
                        Date recentGoldenDate = new SimpleDateFormat("yyyyMMdd").parse(recentGolden_1PCT);
                        Assert.assertTrue(availableDate.compareTo(recentGoldenDate) >= 0);
                    }
                } else
                {
                    Date availableDate = new SimpleDateFormat("yyyyMMdd").parse(availableDatasetsId.get(i));
                    Date recentGoldenDate = new SimpleDateFormat("yyyyMMdd").parse(recentGolden);
                    Assert.assertTrue(availableDate.compareTo(recentGoldenDate) >= 0);
                }
                i++;
            }
        }

        // Validate that �Dimensions � filter Option is displayed along with a checkbox under �Search for datasets of type:� section on the �Credit
        // Input� Screen.
        if ("DM_ID_322".equalsIgnoreCase(tc_Id))
        {
            try
            {
                CreditInPag.selectDimensionsCB();
                commMethods.verifyString("checks", CreditInPag.getParentIdTextForDimensionsCB());
            } catch (NoSuchElementException e)
            {
                Assert.assertFalse(false);
            }
        }
        // Validate that when �Dimensions� check box is selected then only credit datasets with available Dimension Datasets are listed down under
        // �Available Datasets� section.
        if ("DM_ID_323".equalsIgnoreCase(tc_Id))
        {
            CreditInPag.selectDimensionsCB();
            List<String> dimList = CreditInPag.getLiIdForDimensionsCB();
            int i = 0;
            while (i < dimList.size())
            {
                Assert.assertTrue(dimList.get(i).contains("dimensions"));
                i++;
            }

        }

        // Validate that when �Dimensions� check box is not selected then No Dimension Datasets associated with credit dataset are populated under
        // �Available Datasets� and credit datasets are displayed as is.
        if ("DM_ID_325".equalsIgnoreCase(tc_Id))
        {
            List<String> dimList = CreditInPag.getLiIdForDimensionsCB();
            int i = 0;
            List<String> idListNoDimensions = new ArrayList<>();
            List<String> idListDimensions = new ArrayList<>();
            while (i < dimList.size())
            {
                if (dimList.get(i).contains("dimensions"))
                    idListDimensions.add(dimList.get(i));
                else
                    idListNoDimensions.add(dimList.get(i));
                i++;
            }

            Assert.assertTrue(!idListNoDimensions.isEmpty());
            Assert.assertTrue(!idListDimensions.isEmpty());
        }

        if ("DM_ID_326".equalsIgnoreCase(tc_Id))
        {
            List<WebElement> elements = CreditInPag.getDimensionDatasets(DataSet);
            int i = 0;
            Date availableDate = new SimpleDateFormat("yyyyMMdd").parse(DataSet);
            while (i < elements.size())
            {
                String elementId = elements.get(i).getAttribute("id");
                Date dimDate = new SimpleDateFormat("yyyyMMdd").parse(elementId);
                Assert.assertTrue(availableDate.compareTo(dimDate) >= 0);
                i++;
            }

        }

        // Validate that when �Dimensions� check box is not selected then No Dimension Datasets associated with credit dataset are populated under
        // �Available Datasets� and credit datasets are displayed as is.
        if ("DM_ID_328".equalsIgnoreCase(tc_Id) || "DM_ID_330".equalsIgnoreCase(tc_Id))
        {
            // First check the total number of dimensions datasets
            CreditInPag.selectDimensionsCB();
            List<WebElement> dimList = CreditInPag.getDimensionsDatasetsFromAvailableDatasets();
            // unselect the dimensions CB now
            CreditInPag.selectDimensionsCB();
            // check if the available datasets have dimension datasets
            List<WebElement> availableDatasets = CreditInPag.getAvailableDatasets();
            int i = 0;
            while (i < dimList.size())
            {
                Assert.assertTrue(availableDatasets.contains(dimList.get(i)));
                i++;
            }

        }

        // Validate that if added Autopilot Module does have a dependency on Dimensions then �Dimensions� option is disabled and checked.
        if ("DM_ID_327".equalsIgnoreCase(tc_Id) || "DM_ID_329".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyString(CreditInPag.dimensionsChkBox.getAttribute("disabled"), "true");
            commMethods.verifyString(CreditInPag.dimensionsChkBox.getAttribute("checked"), "true");
        }

        JavascriptExecutor js = (JavascriptExecutor) driver;
        String[] datasets = DataSet.split(",");

        // Test cases for selecting only credit dataset and no dimensions
        if ("DM_ID_004".equalsIgnoreCase(tc_Id) || "DM_ID_009".equalsIgnoreCase(tc_Id) || "DM_ID_013".equalsIgnoreCase(tc_Id)
                || "DM_ID_022".equalsIgnoreCase(tc_Id) || "DM_ID_028".equalsIgnoreCase(tc_Id) || "DM_ID_029".equalsIgnoreCase(tc_Id)
                || "DM_ID_045".equalsIgnoreCase(tc_Id) || "DM_ID_053".equalsIgnoreCase(tc_Id) || "DM_ID_056".equalsIgnoreCase(tc_Id)
                || "DM_ID_077".equalsIgnoreCase(tc_Id) || "DM_ID_081".equalsIgnoreCase(tc_Id) || "DM_ID_092".equalsIgnoreCase(tc_Id)
                || "DM_ID_108".equalsIgnoreCase(tc_Id) || "DM_ID_119".equalsIgnoreCase(tc_Id) || "DM_ID_120".equalsIgnoreCase(tc_Id)
                || "DM_ID_126".equalsIgnoreCase(tc_Id) || "DM_ID_127".equalsIgnoreCase(tc_Id) || "DM_ID_128".equalsIgnoreCase(tc_Id)
                || "DM_ID_129".equalsIgnoreCase(tc_Id) || "DM_ID_130".equalsIgnoreCase(tc_Id) || "DM_ID_131".equalsIgnoreCase(tc_Id)
                || "DM_ID_151".equalsIgnoreCase(tc_Id) || "DM_ID_222".equalsIgnoreCase(tc_Id) || "DM_ID_232".equalsIgnoreCase(tc_Id)
                || "DM_ID_233".equalsIgnoreCase(tc_Id) || "DM_ID_236".equalsIgnoreCase(tc_Id) || "DM_ID_237".equalsIgnoreCase(tc_Id)
                || "DM_ID_238".equalsIgnoreCase(tc_Id) || "DM_ID_240".equalsIgnoreCase(tc_Id) || "DM_ID_244".equalsIgnoreCase(tc_Id)
                || "DM_ID_247".equalsIgnoreCase(tc_Id) || "DM_ID_251".equalsIgnoreCase(tc_Id) || "DM_ID_254".equalsIgnoreCase(tc_Id)
                || "DM_ID_261".equalsIgnoreCase(tc_Id) || "DM_ID_263".equalsIgnoreCase(tc_Id) || "DM_ID_283".equalsIgnoreCase(tc_Id)
                || "DM_ID_291".equalsIgnoreCase(tc_Id) || "DM_ID_324".equalsIgnoreCase(tc_Id) || "DM_ID_347".equalsIgnoreCase(tc_Id)
                || "DM_ID_348".equalsIgnoreCase(tc_Id) || "DM_ID_352".equalsIgnoreCase(tc_Id) || "DM_ID_410".equalsIgnoreCase(tc_Id)
                || "DM_ID_413".equalsIgnoreCase(tc_Id) || "DM_ID_417".equalsIgnoreCase(tc_Id) || "DM_ID_447".equalsIgnoreCase(tc_Id)
                || "DM_ID_448".equalsIgnoreCase(tc_Id) || "DM_ID_449".equalsIgnoreCase(tc_Id) || "DM_ID_450".equalsIgnoreCase(tc_Id)
                || "DM_ID_471".equalsIgnoreCase(tc_Id) || "DM_ID_474".equalsIgnoreCase(tc_Id) || "DM_ID_489".equalsIgnoreCase(tc_Id)
                || "DM_ID_411".equalsIgnoreCase(tc_Id) || "DM_ID_437".equalsIgnoreCase(tc_Id) || "DM_ID_511".equalsIgnoreCase(tc_Id)
                || "DM_ID_578".equalsIgnoreCase(tc_Id) || "DM_ID_579".equalsIgnoreCase(tc_Id) || "DM_ID_580".equalsIgnoreCase(tc_Id)
                || "DM_ID_438".equalsIgnoreCase(tc_Id) || "DM_ID_439".equalsIgnoreCase(tc_Id) || "DM01_BASE".equalsIgnoreCase(tc_Id)
                || "DM02_BASE".equalsIgnoreCase(tc_Id) || "DM03_BASE".equalsIgnoreCase(tc_Id) || "DM04_BASE".equalsIgnoreCase(tc_Id) 
                || "DM05_BASE".equalsIgnoreCase(tc_Id) || "DM06_BASE".equalsIgnoreCase(tc_Id) || "DM07_BASE".equalsIgnoreCase(tc_Id) 
                || "DM08_BASE".equalsIgnoreCase(tc_Id) || "DM09_BASE".equalsIgnoreCase(tc_Id) || "DM10_BASE".equalsIgnoreCase(tc_Id) 
                || "DM11_BASE".equalsIgnoreCase(tc_Id) || "DM12_BASE".equalsIgnoreCase(tc_Id) || "DM13_BASE".equalsIgnoreCase(tc_Id) 
                || "DM14_BASE".equalsIgnoreCase(tc_Id) || "DM15_BASE".equalsIgnoreCase(tc_Id) || "DM16_BASE".equalsIgnoreCase(tc_Id) 
                || "DM17_BASE".equalsIgnoreCase(tc_Id) || "DM18_BASE".equalsIgnoreCase(tc_Id) )
        {
//            CreditInPag.selectSpcificDataSet();

            if ("DM_ID_324".equalsIgnoreCase(tc_Id))
            {
                CreditInPag.dimensionsChkBox.click();
            }

            CreditInPag.selectPullType_CB(cid_CNX);
            CreditInPag.click_Unique_CID();
            if ("SPECIFIC".equalsIgnoreCase(availableDataSets))
            {
                CreditInPag.selectSpcificDataSet();
                CreditInPag.selectDataSetType(dataSetType);
                CreditInPag.selectSpecificDataSet(DataSet);
            } else
            {
                CreditInPag.selectAvailablDataset(availableDataSets);
            }
            CreditInPag.clickContinueButton();
        } else if ("DM_ID_333".equalsIgnoreCase(tc_Id) || "DM_ID_343".equalsIgnoreCase(tc_Id) || "DM_ID_344".equalsIgnoreCase(tc_Id)
                || "DM_ID_345".equalsIgnoreCase(tc_Id) || "DM_ID_346".equalsIgnoreCase(tc_Id) || "DM_ID_472".equalsIgnoreCase(tc_Id)
                || "DM_ID_473".equalsIgnoreCase(tc_Id) || "DM_ID_332".equalsIgnoreCase(tc_Id))
        {
            // Credit and Dimension datasets
            CreditInPag.selectDataSetType(dataSetType);
            int i = 0;
            while (i < datasets.length)
            {
                List<WebElement> elements1 = driver.findElements(By.xpath("//*[@id='" + datasets[i].trim() + "']"));
                int k1 = 0;
                while (k1 < elements1.size())
                {
                    if (elements1.get(k1).getAttribute("class").contains("creditDataSet"))
                    {
                        js.executeScript("arguments[0].setAttribute('class', 'name1 active')", elements1.get(k1));
                        break;
                    }
                    k1++;
                }

                List<WebElement> elements = driver.findElements(By.xpath("//*[@id='" + datasets[i].trim() + "']/parent::li/ul/li/a"));
                int k = 0;
                while (k < elements.size())
                {
                    if (elements.get(k).getAttribute("id").equals(datasets[i + 1].trim()))
                        js.executeScript("arguments[0].setAttribute('class', 'dimension active')", elements.get(k));
                    k++;
                }
                Thread.sleep(500);
                CreditInPag.clickAddButton();
                i = i + 2;
            }
            CreditInPag.clickContinueButton();
        }

        // Validate that Summary screen of DM job contains line item "Dimension Dataset" and displays the selected dataset by the user
        if ("DM_ID_333".equalsIgnoreCase(tc_Id))
        {
            int k = 0;
            while (k < datasets.length)
            {
                commMethods.verifyContainsString(DMSummPag.dimensionInput.getText(), datasets[k].trim());
                k++;
            }
        }

        // Validate that Data Menu Summary contains Process Name , Job ,Data and Count of Input Process selected under Input tab in case of List
        // Source Data Menu
        if ("DM_ID_291".equalsIgnoreCase(tc_Id))
        {
            Assert.assertTrue(DMSummPag.getSMTableDetails("1") != "");
            Assert.assertTrue(DMSummPag.getSMTableDetails("2") != "");
            Assert.assertTrue(DMSummPag.getSMTableDetails("3") != "");
        }

        // Validate that when DE Data Menu job is submitted taking Dimension dependent AP Module,Score model and Dimension dataset, then Job XML must
        // map Dimension dataset under �mapped sources� and �Dataset� tag

        if ("DM_ID_151".equalsIgnoreCase(tc_Id) || "DM_ID_232".equalsIgnoreCase(tc_Id) || "DM_ID_233".equalsIgnoreCase(tc_Id)
                || "DM_ID_236".equalsIgnoreCase(tc_Id) || "DM_ID_237".equalsIgnoreCase(tc_Id) || "DM_ID_238".equalsIgnoreCase(tc_Id)
                || "DM_ID_240".equalsIgnoreCase(tc_Id) || "DM_ID_244".equalsIgnoreCase(tc_Id) || "DM_ID_247".equalsIgnoreCase(tc_Id)
                || "DM_ID_251".equalsIgnoreCase(tc_Id) || "DM_ID_283".equalsIgnoreCase(tc_Id) || "DM_ID_343".equalsIgnoreCase(tc_Id)
                || "DM_ID_344".equalsIgnoreCase(tc_Id) || "DM_ID_345".equalsIgnoreCase(tc_Id) || "DM_ID_346".equalsIgnoreCase(tc_Id)
                || "DM_ID_347".equalsIgnoreCase(tc_Id) || "DM_ID_348".equalsIgnoreCase(tc_Id) || "DM_ID_410".equalsIgnoreCase(tc_Id)
                || "DM_ID_413".equalsIgnoreCase(tc_Id) || "DM_ID_417".equalsIgnoreCase(tc_Id) || "DM_ID_447".equalsIgnoreCase(tc_Id)
                || "DM_ID_448".equalsIgnoreCase(tc_Id) || "DM_ID_449".equalsIgnoreCase(tc_Id) || "DM_ID_450".equalsIgnoreCase(tc_Id)
                || "DM_ID_471".equalsIgnoreCase(tc_Id) || "DM_ID_472".equalsIgnoreCase(tc_Id) || "DM_ID_473".equalsIgnoreCase(tc_Id)
                || "DM_ID_474".equalsIgnoreCase(tc_Id) || "DM_ID_438".equalsIgnoreCase(tc_Id))
        {
            // View xml test cases
            DMSummPag.clickViewXMLbtn();

            String xmlContent = DMSummPag.getJobXmlContents();
            String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", "");
            xmlString = xmlString.replaceAll("\\s", "");

            // Validate that when datasets with CMS segment is selected, XML created should have CMS Segment data as mapped source.
            if ("DM_ID_151".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<ns2:mappedSources>");
                int index1 = xmlString.indexOf("</ns2:mappedSources>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<dataSetproduct=\"CMSSegment\"provider=\"CMS\""));
            }

            // Validate that when a DE DM has a dependency upon NC+ dataset the xml must include the following in the mapped sources section
            if ("DM_ID_232".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains(
                        "<dataSetproduct=\"NCPlus\"provider=\"GDS\"required=\"true\"mapping=\"3\"><additionalOptions><keyValuename=\"indexName\">cx2</keyValue><keyValuename=\"keyColumn\">2</keyValue><keyValuename=\"productFeature\">rollup</keyValue></additionalOptions><dataSetName>$(NCPLUS_CURRENT)</dataSetName><mappedDataSetName>$(DataSet_GDS_NCPlus)/$(NCPLUS_CURRENT)</mappedDataSetName></dataSet>"));
            }

            // Validate in DE DM job that when a step that requires NC+ data then add the datset mapping for that step in XML
            if ("DM_ID_233".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("<dataSet name=\"ncplus\" mapping=\"3\"/>"));
            }

            // Validate that the source file's delimited layout has column name and number tag for CNX in the XMLwhen NC+ data source is chosen for a
            // direct extraction data menu
            if ("DM_ID_236".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<delimitedLayoutdelimiter");
                int index1 = xmlString.indexOf("</delimitedLayout>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<columnname=\"cnx\"number=\"2\"/>"));
            }

            // Validate that dataset tag for NCPlus is present in the mapped source section in the XMLwhen NC+ data source is chosen for a direct
            // extraction data menu
            if ("DM_ID_237".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<ns2:mappedSources>");
                int index1 = xmlString.indexOf("</ns2:mappedSources>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<dataSetproduct=\"NCPlus\"provider=\"GDS\"required=\"true\"mapping=\"3\">"));
            }

            // Validate that the step NCPlusSuppression is added as a step of the job in the XML after the dataset plugin when NC+ data source is
            // chosen for a direct extraction data menu
            if ("DM_ID_238".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<jobCallFlow>");
                int index1 = xmlString.indexOf("</jobCallFlow>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<stepstepName=\"NCPlusSuppression\"moduleId=\"NCPlusSuppression\">"));
            }

            // Validate that the mapping Sources tag in XML has the Dataset name "ncplus" present under the NCPlus suppression step when NC+ data
            // source is chosen for a direct extraction data menu
            // DM_ID_242 , DM_ID_245
            if ("DM_ID_240".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<stepstepName=\"NCPlusSuppression\"moduleId=\"NCPlusSuppression\">");
                int index1 = xmlString.indexOf("</ns2:InquiryPostRules>/>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<dataSetname=\"ncplus\"mapping=\"3\"/>"));
                // DM_ID_242 Validate that the mapping Sources tag in XML has the Dataset name "creditrecord" present when NC+ data source is chosen
                // for a direct extraction data menu
                Assert.assertTrue(str.contains("<dataSetname=\"creditrecord\"mapping=\"1\"/>"));
                // DM_ID_245 Validate that the step InquiryPost is added as a step of the job in the XML just before the HHKey plugin when NC+ data
                // source is chosen for a direct extraction data menu
                Assert.assertTrue(str.contains(
                        "<stepstepName=\"NCPlusSuppression\"moduleId=\"NCPlusSuppression\"><ns2:mappingSources><dataSetname=\"creditrecord\"mapping=\"1\"/><dataSetname=\"ncplus\"mapping=\"3\"/></ns2:mappingSources><config><ns2:NCPlusSuppressionRules/></config></step><stepstepName=\"InquiryPost\"moduleId=\"InquiryPost\">"));
            }

            // Validate that config tag under NCPlus suppression step has "NCPlusSuppressionRules" tag in the XML when NC+ data source is chosen in
            // the process for a direct extraction data menu
            if ("DM_ID_244".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains("<config><ns2:NCPlusSuppressionRules/></config>"));
            }

            // Validate that the mapping Sources tag in XML has the Dataset name "ncplus" present in the InquiryPost step when NC+ data source is
            // chosen in the process for a direct extraction data menu
            // "DM_ID_246" , DM_ID_249 , DM_ID_250, DM_ID_248
            if ("DM_ID_247".equalsIgnoreCase(tc_Id))
            {
                // DM_ID_246 Validate that the moduleID for InquiryPost step is displayed in the XML when NC+ data source is chosen in the process for
                // a direct
                // extraction data menu
                Assert.assertTrue(xmlContent.contains("<step stepName=\"InquiryPost\" moduleId=\"InquiryPost\">"));

                int index = xmlString.indexOf("<stepstepName=\"InquiryPost\"moduleId=\"InquiryPost\">");
                int index1 = xmlString.indexOf("</ns2:InquiryPostRules>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<dataSetname=\"ncplus\"mapping=\"3\"/>"));

                // "DM_ID_249" , "DM_ID_250"
                Assert.assertTrue(str.contains("<dataSetname=\"creditrecord\"mapping=\"1\"/>"));
            }

            // Validate that config tag under InquiryPost step has "InquiryPostRules" tag in the XML when NC+ data source is chosen in the process for
            // a direct extraction data menu
            if ("DM_ID_251".equalsIgnoreCase(tc_Id))
            {
                int index = xmlString.indexOf("<stepstepName=\"InquiryPost\"moduleId=\"InquiryPost\">");
                int index1 = xmlString.indexOf("</ns2:InquiryPostRules></config>");
                String str = xmlString.substring(index, index1);
                Assert.assertTrue(str.contains("<ns2:InquiryPostRules>"));
            }

            // Validate that Duplicate alias elements are not created in source layout in job XML when same source fields are selected for multiple
            // score models.
            if ("DM_ID_283".equalsIgnoreCase(tc_Id))
            {
                int i = 0;
                while (i < scoreParamNameList.size())
                {
                    Assert.assertTrue(StringUtils.countMatches(xmlContent, "<alias name=\"" + scoreParamNameList.get(i).substring(1) + "\"/>") == 1);
                    i++;
                }
            }

            // Verify that Upon clicking the View XML button on the Data Menu Summary page, the user must have the option to save the XML to a file.
            if ("DM_ID_417".equalsIgnoreCase(tc_Id))
            {
                try
                {
                    commMethods.verifyString(DMSummPag.getSaveToFile(), SAVETOFILE);
                } catch (Exception e)
                {
                    Assert.assertFalse(false);
                }
            }

            // Validate that the xml layout section has a field name as 'S_DOB' in the xml displayed on clicking 'View XML' on the summary for a list
            // source DM process
            if ("DM_ID_438".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains("<columnname=\"S_DOB\""));
            }

            // Validate that following element is added to the JobRun section <keyValue name="MLA_JOB">Y</keyValue>
            if ("DM_ID_447".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlContent.contains("<keyValue name=\"MLA_JOB\">Y</keyValue>"));
            }

            // Validate that following element is omitted from the JobRun section <keyValue name="MLA_JOB">N</keyValue>
            if ("DM_ID_448".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(!xmlContent.contains("<keyValue name=\"MLA_JOB\">Y</keyValue>"));
            }
            // Validate that following element is added to the InquiryPost plugin's InquiryPostRules : <checkMLAHitFlag>false</checkMLAHitFlag>.when
            // the option is off <checkMLAHitFlag>false</checkMLAHitFlag> .
            if ("DM_ID_449".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(inquiryPostStr.contains("<checkMLAHitFlag>false</checkMLAHitFlag>"));
            }

            // Validate that following element is added to the InquiryPost plugin's InquiryPostRules : <checkMLAHitFlag>true</checkMLAHitFlag>.when
            // the option is ON <checkMLAHitFlag>true</checkMLAHitFlag> .
            if ("DM_ID_450".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(inquiryPostStr.contains("<checkMLAHitFlag>true</checkMLAHitFlag>"));
            }

            // Validate that 'checkCMSHitFlag' element is not added to the InquiryPost plugin's InquiryPostRules.
            if ("DM_ID_471".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(!inquiryPostStr.contains("<checkCMSHitFlag>"));
            }

            // Validate that when Dimensions data set is mapped in the InquiryPost step and in the InquiryPost rules section
            if ("DM_ID_472".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(inquiryPostStr.contains("<dataSet name=\"trendeddata\" mapping=\"3\"/>"));
            }

            // Validate that when Dimensions data set is mapped in the InquiryPost step and in the InquiryPost rules section
            if ("DM_ID_473".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(inquiryPostStr.contains("<checkTrendedHitFlag>true</checkTrendedHitFlag>"));
            }

            // Validate that element is added to the InquiryPost plugin's InquiryPostRules of Job XML (Present on DM summary)
            if ("DM_ID_474".equalsIgnoreCase(tc_Id))
            {
                String inquiryPostStr = getInquiryPostingText(xmlContent);

                Assert.assertTrue(inquiryPostStr.contains("<checkTrendedHitFlag>false</checkTrendedHitFlag>"));
            }

            // Validate that when DE Data Menu job is submitted taking Dimension dependent AP Module,Score model and Dimension dataset, then Job XML
            // must map Dimension dataset under �mapped sources� and �Dataset� tag
            if ("DM_ID_343".equalsIgnoreCase(tc_Id))
            {
                int k = 0;
                while (k < datasets.length)
                {
                    Assert.assertTrue(
                            xmlString.contains("<dataSetproduct=\"Dimensions\"provider=\"ACRO\"required=\"true\"name=\"" + datasets[k + 1].trim()
                                    + "\"mapping=\"3\"><additionalOptions><keyValuename=\"indexName\">cid</keyValue><keyValuename=\"keyColumn\">1</keyValue></additionalOptions><dataSetName>"
                                    + datasets[k + 1].trim() + "</dataSetName><mappedDataSetName>" + datasets[k + 1].trim()
                                    + "</mappedDataSetName></dataSet>"));
                    k = k + 2;
                }

            }
            // Validate that selected Dimension dependent AP Module (suppose JXH_DIMENSION) under job call flow also has Dimension dataset mapping to
            // it for DE Data Menu Job
            if ("DM_ID_344".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains("<stepstepName=\"" + APModuleNonCriteria + "\"moduleId=\"" + APModuleNonCriteria
                        + "\"><ns2:mappingSources><dataSetname=\"creditrecord\"mapping=\"1\"/><dataSetname=\"cmssegment\"mapping=\"2\"/><dataSetname=\"trendeddata\"mapping=\"3\"/></ns2:mappingSources>"));
            }

            // Validate that selected Dimension Dependent Score Model plugin also has Dimension dataset mapping to it for DE Data Menu Job
            if ("DM_ID_345".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains("<stepstepName=\"MDL" + scoreModel
                        + "\"moduleId=\"ModelDriver\"><ns2:mappingSources><dataSetname=\"trendeddata\"mapping=\"3\"/><dataSetname=\"creditrecord\"mapping=\"1\"/></ns2:mappingSources>"));
            }
            // Validate that when DE Data Menu job is submitted taking AP Module,Score model which is not dimension dependent then Job XML must not
            // map Dimension dataset under �mapped sources� and �Dataset� tag(only credit data set mapping should be done)
            if ("DM_ID_346".equalsIgnoreCase(tc_Id))
            {
                int k = 0;
                while (k < datasets.length)
                {
                    Assert.assertTrue(xmlString.contains("<dataSetproduct=\"Credit\"provider=\"ACRO\"required=\"true\"name=\"" + datasets[k].trim()
                            + "\"mapping=\"1\"><additionalOptions><keyValuename=\"indexName\">cidu</keyValue><keyValuename=\"keyColumn\">1</keyValue></additionalOptions><dataSetName>"
                            + datasets[k].trim() + "</dataSetName></dataSet>"));
                    Assert.assertTrue(
                            !xmlString.contains("<dataSetproduct=\"Credit\"provider=\"ACRO\"required=\"true\"name=\"" + datasets[k + 1].trim() + ""));
                    k = k + 2;
                }
            }

            // Validate that AP Module which is not Dimension dependent under job call flow does not have Dimension dataset mapping to it for DE Data
            // Menu Job(only credit dataset mapping should be done)
            if ("DM_ID_347".equalsIgnoreCase(tc_Id))
            {
                int k = 0;
                while (k < datasets.length)
                {
                    Assert.assertTrue(xmlString.contains("<dataSetproduct=\"Credit\"provider=\"ACRO\"required=\"true\"name=\"" + datasets[k].trim()
                            + "\"mapping=\"1\"><additionalOptions><keyValuename=\"indexName\">cidu</keyValue><keyValuename=\"keyColumn\">1</keyValue></additionalOptions><dataSetName>"
                            + datasets[k].trim() + "</dataSetName></dataSet>"));

                    k++;
                }
            }

            // Validate that Score Model which is not dimension dependent under job call flow does not have Dimension dataset mapping to it for DE
            // Data Menu Job(only credit dataset mapping should be done)
            if ("DM_ID_348".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains("<stepstepName=\"MDL" + scoreModel
                        + "\"moduleId=\"ModelDriver\"><ns2:mappingSources><dataSetname=\"creditrecord\"mapping=\"1\"/></ns2:mappingSources>"));
            }

            // Validate that Job xml must include Geoselect step with each individual state and territory
            if ("DM_ID_410".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(xmlString.contains(
                        "<ns2:GeoSelectRules><includeStates><state>AK</state><state>AL</state><state>AR</state><state>AZ</state><state>CA</state><state>CO</state><state>CT</state><state>DC</state><state>DE</state><state>FL</state><state>GA</state><state>HI</state><state>IA</state><state>ID</state><state>IL</state><state>IN</state><state>KS</state><state>KY</state><state>LA</state><state>MA</state><state>MD</state><state>ME</state><state>MI</state><state>MN</state><state>MO</state><state>MS</state><state>MT</state><state>NC</state><state>ND</state><state>NE</state><state>NH</state><state>NJ</state><state>NM</state><state>NV</state><state>NY</state><state>OH</state><state>OK</state><state>OR</state><state>PA</state><state>RI</state><state>SC</state><state>SD</state><state>TN</state><state>TX</state><state>UT</state><state>VA</state><state>VT</state><state>WA</state><state>WI</state><state>WV</state><state>WY</state><state>AA</state><state>AE</state><state>AP</state><state>AS</state><state>FM</state><state>GU</state><state>MH</state><state>MP</state><state>PR</state><state>PW</state><state>UM</state><state>VI</state>"));
            }

            // Validate that Job xml must include Geoselect step not having each individual state and territory listed
            if ("DM_ID_413".equalsIgnoreCase(tc_Id))
            {
                Assert.assertTrue(!xmlString.contains(
                        "<ns2:GeoSelectRules><includeStates><state>AK</state><state>AL</state><state>AR</state><state>AZ</state><state>CA</state><state>CO</state><state>CT</state><state>DC</state><state>DE</state><state>FL</state><state>GA</state><state>HI</state><state>IA</state><state>ID</state><state>IL</state><state>IN</state><state>KS</state><state>KY</state><state>LA</state><state>MA</state><state>MD</state><state>ME</state><state>MI</state><state>MN</state><state>MO</state><state>MS</state><state>MT</state><state>NC</state><state>ND</state><state>NE</state><state>NH</state><state>NJ</state><state>NM</state><state>NV</state><state>NY</state><state>OH</state><state>OK</state><state>OR</state><state>PA</state><state>RI</state><state>SC</state><state>SD</state><state>TN</state><state>TX</state><state>UT</state><state>VA</state><state>VT</state><state>WA</state><state>WI</state><state>WV</state><state>WY</state><state>AA</state><state>AE</state><state>AP</state><state>AS</state><state>FM</state><state>GU</state><state>MH</state><state>MP</state><state>PR</state><state>PW</state><state>UM</state><state>VI</state>"));
            }
        }

        // Validate that the DM process appears in 'Ready' state in the DM menu screen when score model such as �5152� is selected and user has
        // provided all required inputs
        if ("DM_ID_489".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickDataMenuTab();
            String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(status.trim(), StatusEnum.READY.name());
        }

        // Submit test cases

        if ("DM_ID_352".equalsIgnoreCase(tc_Id))
        {
            DMSummPag.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            String ProcessName1 = ProjDashBoardPage.jobName();
            String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.clickDataMenuTab();
            module.initializeDriver(driver);
            module.selectDuplicate1();
            module.selectEdit();

            driver.findElement(By.xpath("//a[contains(text(),'" + APModuleNonCriteria + "')]")).click();
            APModPag.deleteFirstModule();
            APModPag.clickAddAPmodButton();
            APModPag.selectAPModuleNonCriteriaAfterDelete("JXH_DIMENSIONS");
            APModPag.clickContinueButton();
            driver.findElement(By.xpath(".//*[@id='sb-player']/div/div/a")).click();
            ModOutptPag.clickContinueButton();
            ScreModlPag.clickContinueButton();
            ConfigIDPag.clickContinueButton();
            ConfigDEPag.clickContinueButton();
            DoubleChckPag.clickContinueButton();
            DMFilterConPag.clickContinueButton();
            CreditInPag.clickContinueButton();
            String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();

            commMethods.verifyString(errMsg, DIM_ERRMSG);
            ProjDashBoardPage.clickDataMenuTab();
            String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(status.trim(), StatusEnum.ERROR.name());
        }

        // Validate that for DM job if added AP Module has dependency on Dimensions dataset then the Process should get COMPLETED successfully
        if ("DM_ID_004".equalsIgnoreCase(tc_Id) || "DM_ID_009".equalsIgnoreCase(tc_Id) || "DM_ID_013".equalsIgnoreCase(tc_Id)
                || "DM_ID_022".equalsIgnoreCase(tc_Id) || "DM_ID_028".equalsIgnoreCase(tc_Id) || "DM_ID_029".equalsIgnoreCase(tc_Id)
                || "DM_ID_045".equalsIgnoreCase(tc_Id) || "DM_ID_053".equalsIgnoreCase(tc_Id) || "DM_ID_056".equalsIgnoreCase(tc_Id)
                || "DM_ID_077".equalsIgnoreCase(tc_Id) || "DM_ID_081".equalsIgnoreCase(tc_Id) || "DM_ID_092".equalsIgnoreCase(tc_Id)
                || "DM_ID_108".equalsIgnoreCase(tc_Id) || "DM_ID_119".equalsIgnoreCase(tc_Id) || "DM_ID_120".equalsIgnoreCase(tc_Id)
                || "DM_ID_126".equalsIgnoreCase(tc_Id) || "DM_ID_127".equalsIgnoreCase(tc_Id) || "DM_ID_128".equalsIgnoreCase(tc_Id)
                || "DM_ID_129".equalsIgnoreCase(tc_Id) || "DM_ID_130".equalsIgnoreCase(tc_Id) || "DM_ID_131".equalsIgnoreCase(tc_Id)
                || "DM_ID_222".equalsIgnoreCase(tc_Id) || "DM_ID_254".equalsIgnoreCase(tc_Id) || "DM_ID_261".equalsIgnoreCase(tc_Id)
                || "DM_ID_263".equalsIgnoreCase(tc_Id) || "DM_ID_324".equalsIgnoreCase(tc_Id) || "DM_ID_332".equalsIgnoreCase(tc_Id)
                || "DM_ID_411".equalsIgnoreCase(tc_Id) || "DM_ID_437".equalsIgnoreCase(tc_Id) || "DM_ID_511".equalsIgnoreCase(tc_Id)
                || "DM_ID_578".equalsIgnoreCase(tc_Id) || "DM_ID_579".equalsIgnoreCase(tc_Id) || "DM_ID_580".equalsIgnoreCase(tc_Id)
                || "DM_ID_439".equalsIgnoreCase(tc_Id) || "DM01_BASE".equalsIgnoreCase(tc_Id) || "DM03_BASE".equalsIgnoreCase(tc_Id) || "DM04_BASE".equalsIgnoreCase(tc_Id) 
                || "DM05_BASE".equalsIgnoreCase(tc_Id) || "DM06_BASE".equalsIgnoreCase(tc_Id) || "DM07_BASE".equalsIgnoreCase(tc_Id) 
                || "DM08_BASE".equalsIgnoreCase(tc_Id) || "DM09_BASE".equalsIgnoreCase(tc_Id) || "DM10_BASE".equalsIgnoreCase(tc_Id) 
                || "DM11_BASE".equalsIgnoreCase(tc_Id) || "DM12_BASE".equalsIgnoreCase(tc_Id) || "DM13_BASE".equalsIgnoreCase(tc_Id) 
                || "DM14_BASE".equalsIgnoreCase(tc_Id) || "DM15_BASE".equalsIgnoreCase(tc_Id) || "DM16_BASE".equalsIgnoreCase(tc_Id) 
                || "DM17_BASE".equalsIgnoreCase(tc_Id) || "DM18_BASE".equalsIgnoreCase(tc_Id) )
        {
            DMSummPag.clickSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            String processName1 = ProjDashBoardPage.jobName();
            String status = ProjDashBoardPage.verifyProcess(processName1);
            commMethods.verifyString(status, "PASS");
        }
        else if("DM02_BASE".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickHomeTab();
            String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
            commMethods.verifyString(status.trim(), StatusEnum.READY.name());
        }
        	
            /*
             * // String processName1 = "DM503_dm_scoreparamsxmltest"; // TODO xmls are not same if ("DM_ID_576".equalsIgnoreCase(tc_Id)) {
             * ProjDashBoardPage.clickStatsView(processName1); driver.switchTo().frame("sb-player"); String path = DmStatView.getJobDirectoryJETDM();
             * int index = path.lastIndexOf("/"); String filePath = path.substring(0, index); filePath = filePath.concat("/FusionRequestToJet.xml");
             * String xmlFromFile = commMethods.readFileString(filePath); String xmlString1 = xmlFromFile.replaceAll("[\\t\\n\\r]", ""); xmlString1 =
             * xmlString1.replaceAll("\\s", ""); DmStatView.clickJetJobXml(); driver.switchTo().frame("sb-player"); String xmlContent =
             * DmStatView.getJobXMLContentStatsDM(); String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", ""); xmlString =
             * xmlString.replaceAll("\\s", ""); commMethods.verifyString(xmlString1, xmlString); }
             */

            // String processName1 = "DM911_dm263_factactalloptionstest";

            if ("DM_ID_004".equalsIgnoreCase(tc_Id) || "DM_ID_009".equalsIgnoreCase(tc_Id) || "DM_ID_013".equalsIgnoreCase(tc_Id)
                    || "DM_ID_022".equalsIgnoreCase(tc_Id) || "DM_ID_028".equalsIgnoreCase(tc_Id) || "DM_ID_029".equalsIgnoreCase(tc_Id)
                    || "DM_ID_053".equalsIgnoreCase(tc_Id) || "DM_ID_056".equalsIgnoreCase(tc_Id) || "DM_ID_077".equalsIgnoreCase(tc_Id)
                    || "DM_ID_081".equalsIgnoreCase(tc_Id) || "DM_ID_092".equalsIgnoreCase(tc_Id) || "DM_ID_120".equalsIgnoreCase(tc_Id)
                    || "DM_ID_126".equalsIgnoreCase(tc_Id) || "DM_ID_127".equalsIgnoreCase(tc_Id) || "DM_ID_128".equalsIgnoreCase(tc_Id)
                    || "DM_ID_129".equalsIgnoreCase(tc_Id) || "DM_ID_130".equalsIgnoreCase(tc_Id) || "DM_ID_131".equalsIgnoreCase(tc_Id)
                    || "DM_ID_263".equalsIgnoreCase(tc_Id) || "DM_ID_254".equalsIgnoreCase(tc_Id))
            {
                ProjDashBoardPage.clickStatsView(processName);
//                driver.switchTo().frame("sb-player");
                String headerTableNameDM = DmStatView.getHeaderTableNameDM();

                if ("DM_ID_004".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

                    String inputRecords = counterString.substring(counterString.indexOf("GeoSelect"),
                            counterString.indexOf("Records excluded due to Zip code selection"));

                    String zipRecords = inputRecords.substring(inputRecords.indexOf("RECORDS_EXCL_ZIP"),
                            inputRecords.indexOf("RECORDS_EXCL_ZIP") + 57);
                    Assert.assertTrue(!zipRecords.substring(17).trim().equals("0"));
                }

                // Validate that for DE DM records dropped at Invalid Street Address are recorded against "Total dropped for invalid street address"
                // in COUNTERS stats and are not processd further.
                if ("DM_ID_009".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

                    String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                            counterString.indexOf("Total dropped for invalid street address"));

                    String invalidRecords = inputRecords.substring(inputRecords.indexOf("04_INVLD_ADDRESS_DROPS"),
                            inputRecords.indexOf("04_INVLD_ADDRESS_DROPS") + 57);
                    // Assert.assertTrue(!invalidRecords.substring(23).trim().equals("0"));

                    String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                            counterString.indexOf("Total Input records to FilterSelect"));
                    String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"),
                            totalInputRecords.indexOf("RECORDS") + 57);

                    String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                            counterString.indexOf("Total Records Available After FilterSelect"));
                    String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                            totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                    commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                            Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(invalidRecords.substring(23).trim()));

                }

                // Validate that for DE DM records dropped at Invalid Sub Name are recorded against "Total dropped for invalid name" in COUNTERS stats
                // and are not processed further.
                if ("DM_ID_013".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

                    String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                            counterString.indexOf("Total dropped for invalid name"));

                    String invalidRecords = inputRecords.substring(inputRecords.indexOf("06_INVLD_NAME_DROPS"),
                            inputRecords.indexOf("06_INVLD_NAME_DROPS") + 57);
                    Assert.assertTrue(!invalidRecords.substring(23).trim().equals("0"));
                }

                // Validate that for DE DM "Total Dropped records" shown for filterselect in counters stats
                if ("DM_ID_022".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                            counterString.indexOf("Total Input records to FilterSelect"));

                    String testFileDropsRecords = inputRecords.substring(inputRecords.indexOf("02_TEST_FILE_DROPS"),
                            inputRecords.indexOf("02_TEST_FILE_DROPS") + 57);

                    String dnsDropsRecords = inputRecords.substring(inputRecords.indexOf("03_DO_NOT_SOLICIT_DROPS"),
                            inputRecords.indexOf("03_DO_NOT_SOLICIT_DROPS") + 57);

                    String invalidAddressRecords = inputRecords.substring(inputRecords.indexOf("04_INVLD_ADDRESS_DROPS"),
                            inputRecords.indexOf("04_INVLD_ADDRESS_DROPS") + 57);

                    String missingAddressDropsRecords = inputRecords.substring(inputRecords.indexOf("05_MISSING_ADDRESS_DROPS"),
                            inputRecords.indexOf("05_MISSING_ADDRESS_DROPS") + 57);

                    String invalidNameDropsRecords = inputRecords.substring(inputRecords.indexOf("06_INVLD_NAME_DROPS"),
                            inputRecords.indexOf("06_INVLD_NAME_DROPS") + 57);

                    String offensiveNameDropsRecords = inputRecords.substring(inputRecords.indexOf("07_OFFENSIVE_NAME_DROPS"),
                            inputRecords.indexOf("07_OFFENSIVE_NAME_DROPS") + 57);

                    String derogNameDropsRecords = inputRecords.substring(inputRecords.indexOf("08_DEROG_NAME_DROPS"),
                            inputRecords.indexOf("08_DEROG_NAME_DROPS") + 57);

                    String businessNameDropsRecords = inputRecords.substring(inputRecords.indexOf("09_BUSINESS_NAME_DROPS"),
                            inputRecords.indexOf("09_BUSINESS_NAME_DROPS") + 57);

                    String totalDroppedRecords = inputRecords.substring(inputRecords.indexOf("11_TOTAL_FILTER_DROPS"),
                            inputRecords.indexOf("11_TOTAL_FILTER_DROPS") + 57);

                    int dropRecords = Integer.parseInt(testFileDropsRecords.substring(27).trim())
                            + Integer.parseInt(dnsDropsRecords.substring(27).trim()) + Integer.parseInt(invalidAddressRecords.substring(27).trim())
                            + Integer.parseInt(missingAddressDropsRecords.substring(27).trim())
                            + Integer.parseInt(invalidNameDropsRecords.substring(27).trim())
                            + Integer.parseInt(offensiveNameDropsRecords.substring(27).trim())
                            + Integer.parseInt(derogNameDropsRecords.substring(27).trim())
                            + Integer.parseInt(businessNameDropsRecords.substring(27).trim());

                    commMethods.verifyInt(dropRecords, Integer.parseInt(totalDroppedRecords.substring(27).trim()));

                }

                if ("DM_ID_028".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    String inputRecords = counterString.substring(counterString.indexOf("CreditAudit"), counterString.indexOf("Total Audit Records"));
                    String auditRecords = inputRecords.substring(inputRecords.indexOf("AUDITRECORDS"), inputRecords.indexOf("AUDITRECORDS") + 57);

                    Assert.assertTrue(!auditRecords.substring(13).trim().equals("0"));

                    // DM_ID_026
                    String destdStr = counterString.substring(counterString.indexOf("DEStandard"), counterString.indexOf("Total records dropped"));
                    String totalDeStdRecordsStr = destdStr.substring(destdStr.indexOf("RECORDS"),
                            destdStr.indexOf("Total Input records to DEStandard"));
                    String totalDeStdRecords = totalDeStdRecordsStr.substring(totalDeStdRecordsStr.indexOf("RECORDS"),
                            totalDeStdRecordsStr.indexOf("RECORDS") + 57);

                    String passedRecordsStr = destdStr.substring(destdStr.indexOf("TOTAL_DE_STNDS_PASSED"),
                            destdStr.indexOf("Total  records passed"));
                    String passedRecords = passedRecordsStr.substring(passedRecordsStr.indexOf("TOTAL_DE_STNDS_PASSED"),
                            passedRecordsStr.indexOf("TOTAL_DE_STNDS_PASSED") + 57);

                    String droppedRecordsStr = destdStr.substring(destdStr.indexOf("TOTAL_DE_STND_DROPPED"));
                    String droppedRecords = droppedRecordsStr.substring(droppedRecordsStr.indexOf("TOTAL_DE_STND_DROPPED"),
                            droppedRecordsStr.indexOf("TOTAL_DE_STND_DROPPED") + 57);

                    commMethods.verifyInt(
                            Integer.parseInt(passedRecords.substring(22).trim()) + Integer.parseInt(droppedRecords.substring(22).trim()),
                            Integer.parseInt(totalDeStdRecords.substring(7).trim()));

                    // DM_ID_025 //DM_ID_24 //DM_ID_23
                    String sourceRuleDropStr = counterString.substring(counterString.indexOf("DEStandard"),
                            counterString.indexOf("Two Source Rule records dropped"));
                    String sourceRuleDrops = sourceRuleDropStr.substring(sourceRuleDropStr.indexOf("DE_STND_2_SOURCE_RULE_DROPS"),
                            sourceRuleDropStr.indexOf("DE_STND_2_SOURCE_RULE_DROPS") + 57);
                    String deStd6MonthsStr = counterString.substring(counterString.indexOf("DEStandard"),
                            counterString.indexOf("Date Not Within 6 Months"));
                    String deStd6Months = deStd6MonthsStr.substring(deStd6MonthsStr.indexOf("DE_STND_>6_MTHS"),
                            deStd6MonthsStr.indexOf("DE_STND_>6_MTHS") + 57);

                    commMethods.verifyInt(
                            Integer.parseInt(sourceRuleDrops.substring(27).trim()) + Integer.parseInt(deStd6Months.substring(17).trim()),
                            Integer.parseInt(droppedRecords.substring(22).trim()));
                }

                // Validate that for DE DM rejected records for plugins are present in Header Table with corresponding fail code in fail code column.
                // DM_ID_032 Validate that for DE DM fail code distribution is shown in DM job stats as per fail code present in header table and
                // verified by running query in greenplum
                if ("DM_ID_029".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    String tempKey = null;
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues1.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    Assert.assertTrue(entry1.getValue() != "" && entry1.getValue() != null);
                                }
                            }
                        }
                    }

                    long dbCount = DmStatView.getFailCodeCounts("DB", headerTableNameDM);
                    long idCount = DmStatView.getFailCodeCounts("ID", headerTableNameDM);
                    long psCount = DmStatView.getFailCodeCounts("PS", headerTableNameDM);
                    long rjCount = DmStatView.getFailCodeCounts("RJ", headerTableNameDM);

                    Long doubleChkRejectCount = DmStatView.getDbCheckCountDM();
                    Long idScanCount = DmStatView.getIDScanCountDM();
                    Long pointScoreCount = DmStatView.getPointScoreCountDM();
                    Long rejectCriteriaCount = DmStatView.getCritRejCountDM();

                    commMethods.verifyLong(dbCount, doubleChkRejectCount);
                    commMethods.verifyLong(idCount, idScanCount);
                    commMethods.verifyLong(psCount, pointScoreCount);
                    commMethods.verifyLong(rjCount, rejectCriteriaCount);

                }

                // Validate that for DE DM none of the records should have ID scan code in the id_scan_code column when Drop is selected
                if ("DM_ID_053".equalsIgnoreCase(tc_Id))
                {
                    List<String> idScanValues = DmStatView.getIdScanCodeColumnValuesFromGP(headerTableNameDM);
                    Assert.assertTrue(idScanValues.isEmpty());
                }

                // Validate that for DE DM the record, that got rejected for the particular ID scan code, should have fail code as "ID" when "Reject"
                // is selected
                if ("DM_ID_056".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    String tempKey = null;
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues1.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    commMethods.verifyString(entry1.getValue(), "ID");
                                }
                            }
                        }
                    }

                }

                // DM_ID_077 Validate that for DE DM correct record count is populated in counters file for Citi doublecheck type.
                if ("DM_ID_077".equalsIgnoreCase(tc_Id))
                {
                    // DM_ID_079 Validate that record count for each double check option in counter should match with that of Header table.
                    List<String> dbchkValues = DmStatView.getDblChkCodeColumnValuesFromGP(headerTableNameDM);
                    Assert.assertTrue(dbchkValues.isEmpty());

                    // DM_ID_080 Validate that record are dropped when drop option is selected at doublecheck and fail code "DB" is not populated
                    // against them in Header Table.
                    Map<String, String> failCodeValues = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);

                    for (Map.Entry<String, String> entry : failCodeValues.entrySet())
                    {
                        // DM_ID_096 Validate that record are dropped when drop option is selected at doublecheck and fail code "DB" is not populated
                        // against them in Hedaer PDL file.
                        Assert.assertTrue(entry.getValue() != "DB");
                        // DM_ID_095 Validate that record are dropped when drop option is selected at doublecheck and not processed further and there
                        // should not be any dbck_code populated against them in Header Table.
                        Assert.assertTrue(entry.getValue() == null);
                    }

                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

                    String inputRecords = counterString.substring(counterString.indexOf("DoubleCheck"),
                            counterString.indexOf("Total Input records to DoubleCheck"));
                    String levelARecords = inputRecords.substring(inputRecords.indexOf("_A SSN DoubleCheck"),
                            inputRecords.indexOf("_A SSN DoubleCheck") + 52);
                    String levelBRecords = inputRecords.substring(inputRecords.indexOf("_B SSN DoubleCheck"),
                            inputRecords.indexOf("_B SSN DoubleCheck") + 52);

                    String ssnAA = inputRecords.substring(inputRecords.indexOf("_A SSNOption A"), inputRecords.indexOf("_A SSNOption A") + 50);
                    String ssnAB = inputRecords.substring(inputRecords.indexOf("_A SSNOption B"), inputRecords.indexOf("_A SSNOption B") + 50);
                    String ssnAC = inputRecords.substring(inputRecords.indexOf("_A SSNOption C"), inputRecords.indexOf("_A SSNOption C") + 50);
                    String ssnAD = inputRecords.substring(inputRecords.indexOf("_A SSNOption D"), inputRecords.indexOf("_A SSNOption D") + 50);
                    String ssnAE = inputRecords.substring(inputRecords.indexOf("_A SSNOption E"), inputRecords.indexOf("_A SSNOption E") + 50);

                    String ssnBA = inputRecords.substring(inputRecords.indexOf("_B SSNOption A"), inputRecords.indexOf("_B SSNOption A") + 50);
                    String ssnBB = inputRecords.substring(inputRecords.indexOf("_B SSNOption B"), inputRecords.indexOf("_B SSNOption B") + 50);
                    String ssnBC = inputRecords.substring(inputRecords.indexOf("_B SSNOption C"), inputRecords.indexOf("_B SSNOption C") + 50);
                    String ssnBD = inputRecords.substring(inputRecords.indexOf("_B SSNOption D"), inputRecords.indexOf("_B SSNOption D") + 50);
                    String ssnBE = inputRecords.substring(inputRecords.indexOf("_B SSNOption E"), inputRecords.indexOf("_B SSNOption E") + 50);

                    commMethods.verifyInt(Integer.parseInt(ssnAA.substring(20).trim()) + Integer.parseInt(ssnAB.substring(20).trim())
                            + Integer.parseInt(ssnAC.substring(20).trim()) + Integer.parseInt(ssnAD.substring(20).trim())
                            + Integer.parseInt(ssnAE.substring(20).trim()), Integer.parseInt(levelARecords.substring(25).trim()));
                    commMethods.verifyInt(Integer.parseInt(ssnBA.substring(20).trim()) + Integer.parseInt(ssnBB.substring(20).trim())
                            + Integer.parseInt(ssnBC.substring(20).trim()) + Integer.parseInt(ssnBD.substring(20).trim())
                            + Integer.parseInt(ssnBE.substring(20).trim()), Integer.parseInt(levelBRecords.substring(25).trim()));

                    levelARecords = inputRecords.substring(inputRecords.indexOf("_A ADR DoubleCheck"),
                            inputRecords.indexOf("_A ADR DoubleCheck") + 52);
                    levelBRecords = inputRecords.substring(inputRecords.indexOf("_B ADR DoubleCheck"),
                            inputRecords.indexOf("_B ADR DoubleCheck") + 52);

                    String addAA = inputRecords.substring(inputRecords.indexOf("_A ADROption A"), inputRecords.indexOf("_A ADROption A") + 50);
                    String addAB = inputRecords.substring(inputRecords.indexOf("_A ADROption B"), inputRecords.indexOf("_A ADROption B") + 50);
                    String addAC = inputRecords.substring(inputRecords.indexOf("_A ADROption C"), inputRecords.indexOf("_A ADROption C") + 50);
                    String addAD = inputRecords.substring(inputRecords.indexOf("_A ADROption D"), inputRecords.indexOf("_A ADROption D") + 50);
                    String addAE = inputRecords.substring(inputRecords.indexOf("_A ADROption E"), inputRecords.indexOf("_A ADROption E") + 50);

                    String addBA = inputRecords.substring(inputRecords.indexOf("_B ADROption A"), inputRecords.indexOf("_B ADROption A") + 50);
                    String addBB = inputRecords.substring(inputRecords.indexOf("_B ADROption B"), inputRecords.indexOf("_B ADROption B") + 50);
                    String addBC = inputRecords.substring(inputRecords.indexOf("_B ADROption C"), inputRecords.indexOf("_B ADROption C") + 50);
                    String addBD = inputRecords.substring(inputRecords.indexOf("_B ADROption D"), inputRecords.indexOf("_B ADROption D") + 50);
                    String addBE = inputRecords.substring(inputRecords.indexOf("_B ADROption E"), inputRecords.indexOf("_B ADROption E") + 50);

                    commMethods.verifyInt(Integer.parseInt(addAA.substring(20).trim()) + Integer.parseInt(addAB.substring(20).trim())
                            + Integer.parseInt(addAC.substring(20).trim()) + Integer.parseInt(addAD.substring(20).trim())
                            + Integer.parseInt(addAE.substring(20).trim()), Integer.parseInt(levelARecords.substring(25).trim()));
                    commMethods.verifyInt(Integer.parseInt(addBA.substring(20).trim()) + Integer.parseInt(addBB.substring(20).trim())
                            + Integer.parseInt(addBC.substring(20).trim()) + Integer.parseInt(addBD.substring(20).trim())
                            + Integer.parseInt(addBE.substring(20).trim()), Integer.parseInt(levelBRecords.substring(25).trim()));

                }

                // Validate that record are rejected and kept i.e all rejected records record of doublecheck should have its fail code column as DB in
                // Header Table.
                // DM_ID_085 DM_ID_086 Validate that dbck_code is populated for all rejects at doublecheck unless dropped i.e. all records with fail
                // code as DB should have a dbck_code populated.
                // DM_ID_097 Validate that record are rejected and kept i.e all rejected records record of doublecheck should have its fail code
                // column as DB in Header Table
                // DM_ID_091 Validate that records rejected at selected options(suppose E) are moved to Header table if not dropped at plugins in
                // between.
                if ("DM_ID_081".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    String tempKey = null;
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues1.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    Assert.assertTrue(entry1.getValue().equals("DB"));
                                    // DM_ID_098 Validate that record are rejected and kept i.e all rejected records record of doublecheck should
                                    // present in Header Table with dbck_code poulated against it.
                                    Assert.assertTrue(entry1.getValue() != null);
                                }
                            }
                        }
                    }

                    // DM_ID_082 Validate that record are rejected and kept i.e all rejected records record of doublecheck should present in Header
                    // Table with dbck_code poulated against it.
                    Long dblrejectCount = DmStatView.getDbCodeRejectCounts(headerTableNameDM, "R");
                    Long doubleChkRejectCount = DmStatView.getDbCheckCountDM();
                    commMethods.verifyLong(dblrejectCount, doubleChkRejectCount);

                    // DM_ID_101 Validate that dbck_code is populated for all rejects at doublecheck unless dropped i.e. all records with fail code as
                    // DB should have a dbck_code populated.
                    // DM_ID_102 Validate that DB fail code is populated for all rejects at doublecheck unless dropped i.e. all records having a
                    // dbck_code populated against them should have their fail code as DB.

                    Map<String, String> mapValues2 = DmStatView.getDpSeqDblchkCodesColumnValuesFromGP(headerTableNameDM);
                    tempKey = null;
                    for (Map.Entry<String, String> entry : mapValues1.entrySet())
                    {
                        if (entry.getValue() != null && entry.getValue().equals("DB"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues2.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    Assert.assertTrue(entry1.getValue() != null);
                                }
                            }
                        }
                    }

                    // DM_ID_083 Validate that stats for doublecheck in counters file should come in order of the processing of scrub type i.e. SSN
                    // and Address.
                    // DM_ID_099 Validate that stats for doublecheck in counters file should come in order of the processing of scrub type i.e. SSN
                    // and Address.
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

                    String inputRecords = counterString.substring(counterString.indexOf("DoubleCheck"),
                            counterString.indexOf("Total Input records to DoubleCheck"));
                    Assert.assertTrue(inputRecords.indexOf("_A SSN DoubleCheck") < inputRecords.indexOf("_A ADR DoubleCheck"));

                    // DM_ID_084 Validate that stats for doublecheck in counters file should have code wise stats for each option followed by
                    // optionwise stats.
                    // DM_ID_100 Validate that stats for doublecheck in counters file should have code wise stats for each option followed by
                    // optionwise stats.
                    Assert.assertTrue(inputRecords.indexOf("_A SSN DoubleCheck") < inputRecords.indexOf("_Option A"));

                    // DM_ID_087 Validate that record count for each double check option in counter should match with that of Header table.
                    // DM_ID_103 Validate that record count for each double check option in counter should match with that of Header table.
                    // DM_ID_078 Validate that record count for each double check option in counter should match with that of Header table.

                    String optionACount = inputRecords.substring(inputRecords.indexOf("_Option A"), inputRecords.indexOf("_Option A") + 50);
                    String optionBCount = inputRecords.substring(inputRecords.indexOf("_Option B"), inputRecords.indexOf("_Option B") + 50);
                    String optionCCount = inputRecords.substring(inputRecords.indexOf("_Option C"), inputRecords.indexOf("_Option C") + 50);
                    String optionDCount = inputRecords.substring(inputRecords.indexOf("_Option D"), inputRecords.indexOf("_Option D") + 50);
                    String optionECount = inputRecords.substring(inputRecords.indexOf("_Option E"), inputRecords.indexOf("_Option E") + 50);

                    long optionACnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "A");
                    long optionBCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "B");
                    long optionCCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "C");
                    long optionDCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "D");
                    long optionECnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "E");

                    commMethods.verifyLong(optionACnt, Long.parseLong(optionACount.substring(12).trim()));
                    commMethods.verifyLong(optionBCnt, Long.parseLong(optionBCount.substring(12).trim()));
                    commMethods.verifyLong(optionCCnt, Long.parseLong(optionCCount.substring(12).trim()));
                    commMethods.verifyLong(optionDCnt, Long.parseLong(optionDCount.substring(12).trim()));
                    commMethods.verifyLong(optionECnt, Long.parseLong(optionECount.substring(12).trim()));

                    // DM_ID_088 Validate that Records rejected at Address level are recorded against "Total Address Record Count" in counters.
                    // DM_ID_104 Validate that Records rejected at Address level are recorded against "Total Address Record Count" in counters.
                    Assert.assertFalse(inputRecords.indexOf("Total Address Record Count") == -1);

                    // DM_ID_089 Validate that Records rejected at SSN level are recorded against "Total SSN Count" in counters.
                    // DM_ID_105 Validate that Records rejected at SSN level are recorded against "Total SSN Record Count" in counters.
                    Assert.assertFalse(inputRecords.indexOf("Total SSN Record Count") == -1);

                    // DM_ID_090 Validate that Total Records rejected at "SSN and address" level are recorded against "Total Rejects Count" in
                    // counters.
                    // DM_ID_106 Validate that Total Records rejected at "SSN and address" level are recorded against "Total Rejects Count" in
                    // counters
                    String ssnCount = inputRecords.substring(inputRecords.indexOf("_TOTALSSNREC"), inputRecords.indexOf("Total SSN Record Count"));
                    String addressCount = inputRecords.substring(inputRecords.indexOf("_TOTALADDRESS"), inputRecords.indexOf("Total Address Count"));
                    String rejectsCount = inputRecords.substring(inputRecords.indexOf("_TOTALREJECTS"), inputRecords.indexOf("Total Rejects Count"));
                    commMethods.verifyInt(Integer.parseInt(rejectsCount.substring(15, 50).trim()),
                            Integer.parseInt(ssnCount.substring(15, 50).trim()) + Integer.parseInt(addressCount.substring(15, 50).trim()));

                }

                // DM_ID_092 Validate that records rejected at selected options(suppose E) are processed through other plugins and goes to Header
                // table if not dropped at plugins in between
                // DM_ID_107 Validate that records rejected at selected options(suppose E) are moved to Header table if not dropped at plugins in
                // between.
                if ("DM_ID_092".equalsIgnoreCase(tc_Id))
                {
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    String inputRecords = counterString.substring(counterString.indexOf("DoubleCheck"),
                            counterString.indexOf("Total Input records to DoubleCheck"));
                    long dblRecCount = DmStatView.getDbCodeOptionNotBlankCounts(headerTableNameDM);
                    String rejectsCount = inputRecords.substring(inputRecords.indexOf("_TOTALREJECTS"), inputRecords.indexOf("Total Rejects Count"));

                    commMethods.verifyLong(dblRecCount, Long.parseLong(rejectsCount.substring(18, 50).trim()));

                    // DM_ID_093 Validate that summation of records of selected code(suppose A) for each option(A,B,C,D,E) run for doublecheck ssn and
                    // address should be equal to the count of each summarized option
                    String levelARecords = inputRecords.substring(inputRecords.indexOf("_A SSN DoubleCheck"),
                            inputRecords.indexOf("_A SSN DoubleCheck") + 52);
                    String levelBRecords = inputRecords.substring(inputRecords.indexOf("_B SSN DoubleCheck"),
                            inputRecords.indexOf("_B SSN DoubleCheck") + 52);

                    String ssnAA = inputRecords.substring(inputRecords.indexOf("_A SSNOption A"), inputRecords.indexOf("_A SSNOption A") + 50);
                    String ssnAB = inputRecords.substring(inputRecords.indexOf("_A SSNOption B"), inputRecords.indexOf("_A SSNOption B") + 50);
                    String ssnAC = inputRecords.substring(inputRecords.indexOf("_A SSNOption C"), inputRecords.indexOf("_A SSNOption C") + 50);
                    String ssnAD = inputRecords.substring(inputRecords.indexOf("_A SSNOption D"), inputRecords.indexOf("_A SSNOption D") + 50);
                    String ssnAE = inputRecords.substring(inputRecords.indexOf("_A SSNOption E"), inputRecords.indexOf("_A SSNOption E") + 50);

                    String ssnBA = inputRecords.substring(inputRecords.indexOf("_B SSNOption A"), inputRecords.indexOf("_B SSNOption A") + 50);
                    String ssnBB = inputRecords.substring(inputRecords.indexOf("_B SSNOption B"), inputRecords.indexOf("_B SSNOption B") + 50);
                    String ssnBC = inputRecords.substring(inputRecords.indexOf("_B SSNOption C"), inputRecords.indexOf("_B SSNOption C") + 50);
                    String ssnBD = inputRecords.substring(inputRecords.indexOf("_B SSNOption D"), inputRecords.indexOf("_B SSNOption D") + 50);
                    String ssnBE = inputRecords.substring(inputRecords.indexOf("_B SSNOption E"), inputRecords.indexOf("_B SSNOption E") + 50);

                    commMethods.verifyInt(Integer.parseInt(ssnAA.substring(20).trim()) + Integer.parseInt(ssnAB.substring(20).trim())
                            + Integer.parseInt(ssnAC.substring(20).trim()) + Integer.parseInt(ssnAD.substring(20).trim())
                            + Integer.parseInt(ssnAE.substring(20).trim()), Integer.parseInt(levelARecords.substring(25).trim()));
                    commMethods.verifyInt(Integer.parseInt(ssnBA.substring(20).trim()) + Integer.parseInt(ssnBB.substring(20).trim())
                            + Integer.parseInt(ssnBC.substring(20).trim()) + Integer.parseInt(ssnBD.substring(20).trim())
                            + Integer.parseInt(ssnBE.substring(20).trim()), Integer.parseInt(levelBRecords.substring(25).trim()));

                    levelARecords = inputRecords.substring(inputRecords.indexOf("_A ADR DoubleCheck"),
                            inputRecords.indexOf("_A ADR DoubleCheck") + 52);
                    levelBRecords = inputRecords.substring(inputRecords.indexOf("_B ADR DoubleCheck"),
                            inputRecords.indexOf("_B ADR DoubleCheck") + 52);

                    String addAA = inputRecords.substring(inputRecords.indexOf("_A ADROption A"), inputRecords.indexOf("_A ADROption A") + 50);
                    String addAB = inputRecords.substring(inputRecords.indexOf("_A ADROption B"), inputRecords.indexOf("_A ADROption B") + 50);
                    String addAC = inputRecords.substring(inputRecords.indexOf("_A ADROption C"), inputRecords.indexOf("_A ADROption C") + 50);
                    String addAD = inputRecords.substring(inputRecords.indexOf("_A ADROption D"), inputRecords.indexOf("_A ADROption D") + 50);
                    String addAE = inputRecords.substring(inputRecords.indexOf("_A ADROption E"), inputRecords.indexOf("_A ADROption E") + 50);

                    String addBA = inputRecords.substring(inputRecords.indexOf("_B ADROption A"), inputRecords.indexOf("_B ADROption A") + 50);
                    String addBB = inputRecords.substring(inputRecords.indexOf("_B ADROption B"), inputRecords.indexOf("_B ADROption B") + 50);
                    String addBC = inputRecords.substring(inputRecords.indexOf("_B ADROption C"), inputRecords.indexOf("_B ADROption C") + 50);
                    String addBD = inputRecords.substring(inputRecords.indexOf("_B ADROption D"), inputRecords.indexOf("_B ADROption D") + 50);
                    String addBE = inputRecords.substring(inputRecords.indexOf("_B ADROption E"), inputRecords.indexOf("_B ADROption E") + 50);

                    commMethods.verifyInt(Integer.parseInt(addAA.substring(20).trim()) + Integer.parseInt(addAB.substring(20).trim())
                            + Integer.parseInt(addAC.substring(20).trim()) + Integer.parseInt(addAD.substring(20).trim())
                            + Integer.parseInt(addAE.substring(20).trim()), Integer.parseInt(levelARecords.substring(25).trim()));
                    commMethods.verifyInt(Integer.parseInt(addBA.substring(20).trim()) + Integer.parseInt(addBB.substring(20).trim())
                            + Integer.parseInt(addBC.substring(20).trim()) + Integer.parseInt(addBD.substring(20).trim())
                            + Integer.parseInt(addBE.substring(20).trim()), Integer.parseInt(levelBRecords.substring(25).trim()));

                    // DM_ID_094 Validate that record count for each double check option in counter should match with that of Header table
                    String optionACount = inputRecords.substring(inputRecords.indexOf("_Option A"), inputRecords.indexOf("_Option A") + 50);
                    String optionBCount = inputRecords.substring(inputRecords.indexOf("_Option B"), inputRecords.indexOf("_Option B") + 50);
                    String optionCCount = inputRecords.substring(inputRecords.indexOf("_Option C"), inputRecords.indexOf("_Option C") + 50);
                    String optionDCount = inputRecords.substring(inputRecords.indexOf("_Option D"), inputRecords.indexOf("_Option D") + 50);
                    String optionECount = inputRecords.substring(inputRecords.indexOf("_Option E"), inputRecords.indexOf("_Option E") + 50);

                    long optionACnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "A");
                    long optionBCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "B");
                    long optionCCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "C");
                    long optionDCnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "D");
                    long optionECnt = DmStatView.getDbCodeOptionCounts(headerTableNameDM, "E");

                    commMethods.verifyLong(optionACnt, Long.parseLong(optionACount.substring(12).trim()));
                    commMethods.verifyLong(optionBCnt, Long.parseLong(optionBCount.substring(12).trim()));
                    commMethods.verifyLong(optionCCnt, Long.parseLong(optionCCount.substring(12).trim()));
                    commMethods.verifyLong(optionDCnt, Long.parseLong(optionDCount.substring(12).trim()));
                    commMethods.verifyLong(optionECnt, Long.parseLong(optionECount.substring(12).trim()));
                }

                // DM_ID_108 Validate that records rejected at selected options(suppose E) are moved to Header table if not dropped at plugins in
                // between.
                // DM_ID_109 Validate that records rejected at selected options(suppose E) are processed through other plugins and goes to Header
                // table if not dropped at plugins in between, so fail code "DB" is populated against those records
                if ("DM_ID_108".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues2 = DmStatView.getDpSeqDblchkCodesColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    String tempKey = null;
                    for (Map.Entry<String, String> entry : mapValues1.entrySet())
                    {
                        if (entry.getValue() != null && entry.getValue().equals("DB"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues2.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    Assert.assertTrue(entry1.getValue() != null);
                                }
                            }
                        }
                    }
                }

                if ("DM_ID_120".equalsIgnoreCase(tc_Id))
                {
                    // checking from factact pdl file

                    String path = DmStatView.getJobDirectoryJETDM();
                    String filePath = path.concat("/jobrun1/FACTACT");
                    File folder = new File(filePath);
                    File[] listOfFiles = folder.listFiles();
                    for (int i = 0; i < listOfFiles.length; i++)
                    {
                        if (listOfFiles[i].isFile())
                        {
                            List<String> fileContents = commMethods.readFile(filePath + "/" + listOfFiles[i].getName());
                            Assert.assertTrue(!fileContents.isEmpty());
                        }
                    }
                }

                // DM_ID_058 Validate that for DE DM the record, that got rejected for the particular ID scan code, should be moved for further
                // processing when "Tag" is selected.
                // DM_ID_126 Validate that for DE DM records rejected at ID scan code processes through other plugins and goes to header table with
                // corresponding Id
                // scan code if they are not dropped at other plugins

                if ("DM_ID_126".equalsIgnoreCase(tc_Id))
                {
                    List<String> idScanValues = DmStatView.getIdScanCodeColumnValuesFromGP(headerTableNameDM);
                    int i = 0;
                    while (i < idScanValues.size())
                    {
                        Assert.assertTrue(idScanValues.get(i).equals("1") || idScanValues.get(i).equals("2") || idScanValues.get(i).equals("A"));
                        i++;
                    }

                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    String inputRecords = counterString.substring(counterString.indexOf("IdentityScan"),
                            counterString.indexOf("Total Input records to IdentityScan"));

                    String deStdRecords = counterString.substring(counterString.indexOf("DEStandard"),
                            counterString.indexOf("Total Input records to DEStandard"));

                    String records = inputRecords.substring(inputRecords.indexOf("RECORDS"), inputRecords.indexOf("RECORDS") + 57);
                    String recordsPassed = deStdRecords.substring(deStdRecords.indexOf("RECORDS"), deStdRecords.indexOf("RECORDS") + 57);

                    commMethods.verifyString(recordsPassed.substring(7).trim(), records.substring(7).trim());

                }

                // Validate that for DE DM none of the records should have ID scan code in the id_scan_code in Header table and ID fail code in fail
                // code
                // column of Header Table when Drop is selected.
                // DM_ID_007 Validate that for DE DM records dropped at NoAgeCheck are recorded against "Total NoAgecheck Record Hits" in COUNTERS
                // stats
                if ("DM_ID_127".equalsIgnoreCase(tc_Id))
                {
                    boolean flag = DmStatView.checkBlankIdScanFailCodeColumnValuesFromGP(headerTableNameDM);
                    commMethods.verifyboolean(flag, false);

                    // DM_ID_007
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    String hitInputRecords = counterString.substring(counterString.indexOf("NoAgeCheck"),
                            counterString.indexOf("Total NoAgecheck Record Hits"));
                    String inputRecordsIdScan = counterString.substring(counterString.indexOf("IdentityScan"),
                            counterString.indexOf("Total Input records to IdentityScan"));

                    String inputRecords = counterString.substring(counterString.indexOf("NoAgeCheck"),
                            counterString.indexOf("Total Input records to NoAgeCheck"));

                    String records = inputRecords.substring(inputRecords.indexOf("RECORDS"), inputRecords.indexOf("RECORDS") + 57);
                    String hitRecords = hitInputRecords.substring(hitInputRecords.indexOf("TOTALNOAGEHITS"),
                            hitInputRecords.indexOf("TOTALNOAGEHITS") + 57);
                    String recordsPassed = inputRecordsIdScan.substring(inputRecordsIdScan.indexOf("RECORDS"),
                            inputRecordsIdScan.indexOf("RECORDS") + 57);

                    commMethods.verifyInt(Integer.parseInt(recordsPassed.substring(7).trim()),
                            Integer.parseInt(records.substring(7).trim()) - Integer.parseInt(hitRecords.substring(14).trim()));

                }

                // Validate that for DE DM the record, that got rejected for the particular ID scan code, should have the corresponding id_scan_code
                // in the Header Table and ID fail code in Header Table
                if ("DM_ID_128".equalsIgnoreCase(tc_Id))
                {
                    String path = DmStatView.getJobDirectoryJETDM();
                    Map<String, String> mapValues = DmStatView.getDpSeqIdScanColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues2 = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);

                    String filePath = path.concat("/jobrun1/Header");
                    File folder = new File(filePath);
                    File[] listOfFiles = folder.listFiles();
                    String dpSeqNo = null;
                    String idScanCode = null;
                    String failCode = null;

                    for (int i = 0; i < listOfFiles.length; i++)
                    {
                        if (listOfFiles[i].isFile())
                        {
                            List<String> fileContentsList = commMethods.readFile(filePath + "/" + listOfFiles[i].getName());

                            int j = 0;
                            while (j < fileContentsList.size())
                            {
                                // get file idScan and failCode values and comparing it with gp values
                                idScanCode = getSubstringBySplitting(fileContentsList.get(j), 28);
                                failCode = getSubstringBySplitting(fileContentsList.get(j), 37);

                                if (idScanCode != null && !idScanCode.equals(""))
                                {
                                    dpSeqNo = getSubstringBySplitting(fileContentsList.get(j), 0);
                                    commMethods.verifyString(idScanCode, mapValues.get(dpSeqNo));
                                    commMethods.verifyString("R", mapValues2.get(dpSeqNo));
                                }
                                if (failCode.equals("ID"))
                                {
                                    dpSeqNo = getSubstringBySplitting(fileContentsList.get(j), 0);
                                    commMethods.verifyString("ID", mapValues1.get(dpSeqNo));
                                }

                                j++;
                            }
                        }
                    }

                }

                // Validate that for DE DM records rejected at ID scan code processes through other plugins and goes to Header table with
                // corresponding Id scan code if they are not dropped at other plugins
                if ("DM_ID_129".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues2 = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);
                    for (Map.Entry<String, String> entry : mapValues2.entrySet())
                    {
                        commMethods.verifyString("A", entry.getValue());
                    }
                }

                // DM_ID_130 Validate that for DE DM all the accepted records should have valid accept value in acc_code
                // DM_ID_132 Validate that for DE DM all the accepted records should have null rej_code
                // DM_ID_070 Validate that for DE DM records accepted at level A,B,C is recorded against "Total criteria Accept Records" in COUNTERS
                // job stats
                // DM_ID_071 Validate thatfor DE DM records rejected at Criteria module is recorded against Total criteria Reject Records in COUNTERS.
                // DM_ID_061 Validate that for DE DM records accepted at A/B/C level is recorded against "Level A/B/C Accepts" in COUNTERS job stats.
                // DM_ID_064 Validate that for DE DM records accepted at A/B/C level in counters has acc_code 'A/B/C' populated against it in Header
                // Table.

                if ("DM_ID_130".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues = DmStatView.getDpSeqAcceptCodesColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqRejectCodesColumnValuesFromGP(headerTableNameDM);

                    // DM_ID_130
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        Assert.assertTrue(ACCEPTCODES.contains(entry.getValue()));
                    }

                    // DM_ID_132
                    for (String key : mapValues1.keySet())
                    {
                        for (Map.Entry<String, String> entry1 : mapValues1.entrySet())
                        {
                            if (entry1.getKey().equals(key))
                            {
                                commMethods.verifyString(entry1.getValue(), null);
                            }
                        }
                    }

                    // DM_ID_061
                    String acceptCodeACount = DmStatView.getCountOfAcceptsDM("4");
                    String acceptCodeBCount = DmStatView.getCountOfAcceptsDM("7");
                    String acceptCodeCCount = DmStatView.getCountOfAcceptsDM("10");

                    // DM_ID_070
                    DmStatView.clickCounters();
//                    driver.switchTo().frame("sb-player");
                    String counterContent = DmStatView.getCounterContentStatsDM();
                    String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");
                    // counterString = counterString.replaceAll("\\s", "");
                    String accepts = counterString.substring(counterString.indexOf(APModuleNonCriteria),
                            counterString.indexOf("Total criteria Accept Records"));
                    String acceptsA = accepts.substring(accepts.indexOf("CRIT_000"), accepts.indexOf("CRIT_000") + 57);
                    String acceptsB = accepts.substring(accepts.indexOf("CRIT_001"), accepts.indexOf("CRIT_001") + 57);
                    String acceptsC = accepts.substring(accepts.indexOf("CRIT_002"), accepts.indexOf("CRIT_002") + 57);
                    String acceptsTotal = accepts.substring(accepts.indexOf("CRIT_099"), accepts.indexOf("CRIT_099") + 57);

                    commMethods.verifyInt(Integer.parseInt(acceptsA.substring(8).trim()) + Integer.parseInt(acceptsB.substring(8).trim())
                            + Integer.parseInt(acceptsC.substring(8).trim()), Integer.parseInt(acceptsTotal.substring(8).trim()));

                    // DM_ID_061,DM_ID_064 counts are different, known issue, may change later
                    Assert.assertTrue(!acceptsA.substring(8).trim().equals(acceptCodeACount));
                    Assert.assertTrue(!acceptsB.substring(8).trim().equals(acceptCodeBCount));
                    Assert.assertTrue(!acceptsC.substring(8).trim().equals(acceptCodeCCount));

                    // DM_ID_071
                    String rejects = counterString.substring(counterString.indexOf(APModuleNonCriteria),
                            counterString.indexOf("Total criteria Reject Records"));
                    String rejectsStr = rejects.substring(rejects.indexOf("CRIT_199"), rejects.indexOf("CRIT_199") + 57);
                    Assert.assertTrue(rejectsStr != null);

                    String recordTotal = counterString.substring(counterString.indexOf(APModuleNonCriteria),
                            counterString.indexOf("Total Input records to " + APModuleNonCriteria));
                    String recordTotalStr = recordTotal.substring(recordTotal.indexOf("RECORDS"), recordTotal.indexOf("RECORDS") + 57);
                    commMethods.verifyInt(Integer.parseInt(acceptsTotal.substring(8).trim()) + Integer.parseInt(rejectsStr.substring(8).trim()),
                            Integer.parseInt(recordTotalStr.substring(8).trim()));

                }

                if ("DM_ID_131".equalsIgnoreCase(tc_Id))
                {
                    Map<String, String> mapValues = DmStatView.getDpSeqRecordStatusColumnValuesFromGP(headerTableNameDM);
                    Map<String, String> mapValues1 = DmStatView.getDpSeqRejectCodesColumnValuesFromGP(headerTableNameDM);
                    String tempKey = null;

                    // DM_ID_131 Validate that for DE DM the reject code should be set correctly for the records rejected at each level ,for,e.g 1
                    // should be set correctly in the rej_code column for all the records that got rejected for Reject Item "1"
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues1.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    Assert.assertTrue(entry1.getValue() != null);
                                }
                            }
                        }
                    }

                    // DM_ID_133 Validate that for DE DM the records rejected at Criteria level should be tagged to fail code "RJ"
                    Map<String, String> mapValues2 = DmStatView.getDpSeqFailCodeColumnValuesFromGP(headerTableNameDM);
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues2.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    commMethods.verifyString(entry1.getValue(), "RJ");
                                }
                            }
                        }
                    }

                    // DM_ID_134 Validate that for DE DM no rejected records should have accept code in the acc_code in the Header Table
                    Map<String, String> mapValues3 = DmStatView.getDpSeqAcceptCodesColumnValuesFromGP(headerTableNameDM);
                    for (Map.Entry<String, String> entry : mapValues.entrySet())
                    {
                        if (entry.getValue().equals("R"))
                        {
                            tempKey = entry.getKey();
                            for (Map.Entry<String, String> entry1 : mapValues3.entrySet())
                            {
                                if (entry1.getKey().equals(tempKey))
                                {
                                    commMethods.verifyString(entry1.getValue(), null);
                                }
                            }
                        }
                    }

                }

                if ("DM_ID_254".equalsIgnoreCase(tc_Id))
                {
                    List<String> failCodesList = DmStatView.getFailCodeColumnValuesFromGP(headerTableNameDM, stateList);
                    int i = 0;
                    while (i < failCodesList.size())
                    {
                        commMethods.verifyString("NP", failCodesList.get(i));
                        i++;
                    }
                }

                if ("DM_ID_263".equalsIgnoreCase(tc_Id))
                {
                    // checking from factact pdl file

                    String path = DmStatView.getJobDirectoryJETDM();
                    String filePath = path.concat("/jobrun1/FACTACT");
                    File folder = new File(filePath);
                    File[] listOfFiles = folder.listFiles();
                    for (int i = 0; i < listOfFiles.length; i++)
                    {
                        if (listOfFiles[i].isFile())
                        {
                            List<String> fileContents = commMethods.readFile(filePath + "/" + listOfFiles[i].getName());
                            Assert.assertTrue(!fileContents.isEmpty());
                        }
                    }

                    // DM_ID_121 Validate that for DE DM all the records with Alert code or Fraud code or address variance are dropped
                    List<String> fraudFlagList = DmStatView.getFraudVictimColumnValuesFromGP(headerTableNameDM);
                    Assert.assertTrue(fraudFlagList.isEmpty());
                }
            }

            if ("DM_ID_578".equalsIgnoreCase(tc_Id) || "DM_ID_579".equalsIgnoreCase(tc_Id))
            {
                ProjDashBoardPage.clickStatsView(processName);

                // Validate that the factact file of l552 bytes is created when user selects the checkbox for 'Create 540 file' from fact act
                // options
                if ("DM_ID_578".equalsIgnoreCase(tc_Id))
                {
                    String records = DmStatView.getFactActTbleNoOfRecords();
                    String path = DmStatView.getJobDirectoryJETDM();
                    String filePath = path.concat("/jobrun1/FACTACT");
                    long length = 0;
                    File folder = new File(filePath);
                    File[] listOfFiles = folder.listFiles();
                    for (int i = 0; i < listOfFiles.length; i++)
                    {
                        if (listOfFiles[i].isFile())
                        {
                            length = length + listOfFiles[i].length();
                        }
                    }

                    String recordLength = String.valueOf(length / (Integer.parseInt(records)));
                    // One extra byte for the linefeed
                    commMethods.verifyString(recordLength, "553");
                }

                // Validate that the factact table created in greenplum has all the required columns
                if ("DM_ID_579".equalsIgnoreCase(tc_Id))
                {
                    List<String> factActColumns = Arrays.asList("presencecode", "fraudphone1type", "fraudphone1internationalcode",
                            "fraudphone1phonenumber", "fraudphone1phoneextension", "fraudphone2type", "fraudphone2internationalcode",
                            "fraudphone2phonenumber", "fraudphone2phoneextension", "fraudphone3type", "fraudphone3internationalcode",
                            "fraudphone3phonenumber", "fraudphone3phoneextension", "fraudaddressline1", "fraudaddressline2", "fraudaddresscity",
                            "fraudaddressstate", "fraudaddresszip", "fraudaddresscountrycode", "fraudtext", "militaryphone1type",
                            "militaryphone1internationalcode", "militaryphone1phonenumber", "militaryphone1phoneextension", "militaryphone2type",
                            "militaryphone2internationalcode", "militaryphone2phonenumber", "militaryphone2phoneextension", "militaryphone3type",
                            "militaryphone3internationalcode", "militaryphone3phonenumber", "militaryphone3phoneextension", "militaryaddressline1",
                            "militaryaddressline2", "militaryaddresscity", "militaryaddressstate", "militaryaddresszip", "militaryaddresscountrycode",
                            "militarytext", "filler");

                    String factActTable = DmStatView.getFactActTble();
                    List<String> columnNames = DmStatView.getColumnNamesFromGP(factActTable);
                    Assert.assertTrue(columnNames.containsAll(factActColumns));
                }

            }
            // Validate that all the fields in the fact act table are available for selection in post DM process.
            if ("DM_ID_580".equalsIgnoreCase(tc_Id))
            {
                ProjDashBoardPage.clickDataProcessingTab();
                dpHomePage.clickFilteringButton();
                String assignedId = processName.split("_")[0];
                int index = processName.indexOf("_");
                String name = assignedId + ":" + processName.substring(index + 1);
                filterPage.selectProcess(name);
                String table = assignedId + ":FACT_ACT";

                List<String> factActColumnsInFilter = Arrays.asList("PresenceCode", "FraudPhone1Type", "FraudPhone1InternationalCode",
                        "FraudPhone1PhoneNumber", "FraudPhone1PhoneExtension", "FraudPhone2Type", "FraudPhone2InternationalCode",
                        "FraudPhone2PhoneNumber", "FraudPhone2PhoneExtension", "FraudPhone3Type", "FraudPhone3InternationalCode",
                        "FraudPhone3PhoneNumber", "FraudPhone3PhoneExtension", "FraudAddressLine1", "FraudAddressLine2", "FraudAddressCity",
                        "FraudAddressState", "FraudAddressZip", "FraudAddressCountryCode", "FraudText", "MilitaryPhone1Type",
                        "MilitaryPhone1InternationalCode", "MilitaryPhone1PhoneNumber", "MilitaryPhone1PhoneExtension", "MilitaryPhone2Type",
                        "MilitaryPhone2InternationalCode", "MilitaryPhone2PhoneNumber", "MilitaryPhone2PhoneExtension", "MilitaryPhone3Type",
                        "MilitaryPhone3InternationalCode", "MilitaryPhone3PhoneNumber", "MilitaryPhone3PhoneExtension", "MilitaryAddressLine1",
                        "MilitaryAddressLine2", "MilitaryAddressCity", "MilitaryAddressState", "MilitaryAddressZip", "MilitaryAddressCountryCode",
                        "MilitaryText", "Filler");

                int i = 0;
                driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table + "')]"))
                        .click();
                while (i < factActColumnsInFilter.size())
                {
                    try
                    {
                        driver.findElement(By.xpath(".//div[@class='available-fields']//div[@class='content']/ul/li/a[contains(text(),'" + table
                                + "')]/following-sibling::ul/li/a[contains(text(),'" + factActColumnsInFilter.get(i) + "')]")).click();
                    } catch (Exception e)
                    {
                        commMethods.verifyString("Element not found", "Element found");
                    }
                    i++;
                }

            }

            if ("DM_ID_119".equalsIgnoreCase(tc_Id) || "DM_ID_222".equalsIgnoreCase(tc_Id) || "DM_ID_261".equalsIgnoreCase(tc_Id)
                    || "DM_ID_411".equalsIgnoreCase(tc_Id) || "DM_ID_437".equalsIgnoreCase(tc_Id) || "DM_ID_511".equalsIgnoreCase(tc_Id)
                    || "DM_ID_439".equalsIgnoreCase(tc_Id))
            {
                ProjDashBoardPage.clickStatsView(processName);
//                driver.switchTo().frame("sb-player");
                DmStatView.clickJetJobXml();
//                driver.switchTo().frame("sb-player");
                String xmlContent = DmStatView.getJobXMLContentStatsDM();
                String xmlString = xmlContent.replaceAll("[\\t\\n\\r]", "");
                xmlString = xmlString.replaceAll("\\s", "");

                // DM_ID_261 Validate that in List Source DM the Fact Act plugin gets added when only the "Create 540 file" option is selected.
                if ("DM_ID_119".equalsIgnoreCase(tc_Id) || "DM_ID_261".equalsIgnoreCase(tc_Id))
                {
                    Assert.assertTrue(xmlContent.contains("<module moduleId=\"FactAct\" fileName=\"libfactact.so\"/>"));
                }

                // "DM_ID_223", "DM_ID_224", "DM_ID_225", "DM_ID_226", "DM_ID_227","DM_ID_228",DM_ID_229,DM_ID_230,DM_ID_231
                if ("DM_ID_222".equalsIgnoreCase(tc_Id))
                {
                    int index = xmlString.indexOf("<ns2:mappedSources>");
                    int index1 = xmlString.indexOf("</jobRun>");
                    String str = xmlString.substring(index, index1);
                    Assert.assertTrue(str.contains("<dataSetproduct=\"NCPlus\"provider=\"GDS\"required=\"true\"mapping=\"3\">"));
                    int index2 = str.indexOf("<additionalOptionsgroup=\"attachValues\">");
                    String str1 = str.substring(index2);

                    // DM_ID_227 Validate that Value entered in KeyValue tags MEMBER_NUMBER/PRODUCT_TYPE/PRODUCT_ID should be those provided by user
                    // while
                    // creating Data menu
                    // DM_ID_228 Validate that Key Value name MEMBER_NUMBER/PRODUCT_TYPE/PRODUCT_ID under additionalOptions should be in upper case
                    // DM_ID_223 Validate that information captured on the Product page will be added to <additionalOptions> under the <jobruns>
                    // section
                    // DM_ID_224 Validate that Product ID keyValue to the additionalOptions is added in JET JOB XML.
                    Assert.assertTrue(str1.contains("<keyValuename=\"PRODUCT_ID\">" + productId + "</keyValue>"));
                    // DM_ID_225 Validate that member number keyValue to the additionalOptions is added in JET JOB XML.
                    Assert.assertTrue(str1.contains("<keyValuename=\"MEMBER_NUMBER\">" + MemNum + "</keyValue>"));
                    // DM_ID_226 Validate that product type keyValue to the additionalOptions is added in JET JOB XML.
                    Assert.assertTrue(str1.contains("<keyValuename=\"PRODUCT_TYPE\">" + Product + "</keyValue>"));

                    // DM_ID_229 Validate that Jet Job XML is constructed to consider the Current NC+dataset
                    int index3 = str.indexOf("<dataSetproduct=\"NCPlus\"");
                    String str3 = str.substring(index3);
                    String tempStr = str3.substring(str3.indexOf("<dataSetName>"), str3.indexOf("</dataSetName>") + 14);
                    Assert.assertTrue(tempStr.matches("<dataSetName>\\d+</dataSetName>"));

                    // DM_ID_230 Validate that both credit and NC+ data is used to generate output.
                    // DM_ID_231 Validate that the Job executes in a way to process the records against Credit source using CID and NC+ source using
                    // CNX
                    // key
                    Assert.assertTrue(str.contains("<dataSetproduct=\"Credit\"provider=\"ACRO\"required=\"true\"name=\"" + DataSet
                            + "\"mapping=\"1\"><additionalOptions><keyValuename=\"indexName\">cidu</keyValue><keyValuename=\"keyColumn\">1</keyValue></additionalOptions><dataSetName>"
                            + DataSet + "</dataSetName><mappedDataSetName>$(DataSet_ACRO_Credit)/" + DataSet + "</mappedDataSetName></dataSet>"));
                    Assert.assertTrue(str.contains(
                            "<dataSetproduct=\"NCPlus\"provider=\"GDS\"required=\"true\"mapping=\"3\"><additionalOptions><keyValuename=\"indexName\">cx2</keyValue><keyValuename=\"keyColumn\">2</keyValue><keyValuename=\"productFeature\">rollup</keyValue></additionalOptions><dataSetName>"));

                }

                // DM_ID_411 : Validate that JET Job Xml must include Geoselect step with each individual state and territory

                if ("DM_ID_411".equalsIgnoreCase(tc_Id))
                {
                    Assert.assertTrue(xmlString.contains(
                            "<ns2:GeoSelectRules><includeStates><state>AK</state><state>AL</state><state>AR</state><state>AZ</state><state>CA</state><state>CO</state><state>CT</state><state>DC</state><state>DE</state><state>FL</state><state>GA</state><state>HI</state><state>IA</state><state>ID</state><state>IL</state><state>IN</state><state>KS</state><state>KY</state><state>LA</state><state>MA</state><state>MD</state><state>ME</state><state>MI</state><state>MN</state><state>MO</state><state>MS</state><state>MT</state><state>NC</state><state>ND</state><state>NE</state><state>NH</state><state>NJ</state><state>NM</state><state>NV</state><state>NY</state><state>OH</state><state>OK</state><state>OR</state><state>PA</state><state>RI</state><state>SC</state><state>SD</state><state>TN</state><state>TX</state><state>UT</state><state>VA</state><state>VT</state><state>WA</state><state>WI</state><state>WV</state><state>WY</state><state>AA</state><state>AE</state><state>AP</state><state>AS</state><state>FM</state><state>GU</state><state>MH</state><state>MP</state><state>PR</state><state>PW</state><state>UM</state><state>VI</state>"));
                }

                // "DM_ID_437" : Validate that the xml layout section has a field name as 'S_DOB' in the jet job xml for a list source DM process
                if ("DM_ID_437".equalsIgnoreCase(tc_Id))
                {
                    Assert.assertTrue(xmlString.contains("<columnname=\"S_DOB\""));
                }

                if ("DM_ID_439".equalsIgnoreCase(tc_Id))
                {
                    int index = xmlContent.indexOf("<column name=\"S_DOB\"");
                    String str = xmlContent.substring(index, index + 35);
                    int indexNo = str.indexOf("number=");
                    // Getting the column number to check in the file dob format
                    String columnNumber = str.substring(indexNo + 8, str.lastIndexOf("\""));
                    driver.switchTo().defaultContent();
                    ProjDashBoardPage.clickCloseButtonShadowBox();
                    Thread.sleep(2000);
                    ProjDashBoardPage.clickStatsView(processName);
//                    driver.switchTo().frame("sb-player");
                    String filePath = DmStatView.getInputFilePath();
                    List<String> fileContents = commMethods.readFile(filePath);
                    String firstLine = fileContents.get(0);
                    String dob = null;
                    int count = 0;
                    for (int i = 0; i < firstLine.length(); i++)
                    {
                        if (firstLine.charAt(i) == '|')
                            count++;
                        if (count == Integer.parseInt(columnNumber) - 1)
                        {
                            dob = firstLine.substring(i + 1, i + 9);
                            try
                            {
                                SimpleDateFormat format = new SimpleDateFormat("yyyyMMdd");
                                format.parse(dob);
                            } catch (Exception ex)
                            {
                                Assert.assertEquals("Wrong date format", "Right date format");
                            }
                            break;
                        }
                    }
                }

                // Validate that Source field Score parameters is mapped correctly in list source DM
                if ("DM_ID_511".equalsIgnoreCase(tc_Id))
                {
                    Assert.assertTrue(xmlContent.contains("<alias name=\"MODELPARAM\"/>"));
                    String[] scoreParamSplit = scoreParams.split(",");
                    for (int i = 0; i < scoreParamSplit.length; i++)
                    {
                        Assert.assertTrue(xmlContent.contains("<field name=\"MODELPARAM\" sourceLayoutName=\"" + scoreParamSplit[i] + "\"/>"));
                    }
                }

            }
            ExcelRead.updateRunStatus(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "DataMenu_QA", tc_Id);
        }

       
    

    private String getSubstringBySplitting(String string, int position)
    {
        String[] s = string.split("\\|");
        int count = 0;
        while (count < s.length)
        {
            if (count == position)
            {
                return s[count];
            }
            count++;
        }
        return null;
    }

    private String getInquiryPostingText(String xmlContent)
    {
        int inquiryPostStart = xmlContent.indexOf("<step stepName=\"InquiryPost\" moduleId=\"InquiryPost\">");
        int inquiryPostEnd = xmlContent.indexOf("</ns2:InquiryPostRules>");

        String inquiryPostStr = xmlContent.substring(inquiryPostStart, inquiryPostEnd);
        return inquiryPostStr;
    }

    @Title("Data Menu Validations")
    @Description("Data Menu with geoselect validations, external files validations, base process validations")
    @Test(dataProvider = "dm_Reg2", priority = 3)
    public void dataMenuValidation1Testing(String tc_Id, String testRun, String TC, String Description, String copyProj, String copyProcName,
            String processName, String DataOriginField, String Product, String gender, String age, String productId, String MemNum, String smProcess,
            String dataField, String zipCodeInput, String states, String stateList, String prodAPmod, String APModuleNonCriteria,
            String APModuleCriteria, String depProj, String depFile, String NumPerAccCode, String NumPerRejCode, String HoldData, String scoreModel,
            String NCPScoreModel, String pointScoreDrop, String scoreParams, String idScan, String idScanRejects, String deStandard,
            String doublechck, String DNSdrop, String ageDrop, String factActOpt, String invalidDrop, String testFileDrop, String cid_CNX,
            String availableDataSets, String dataSetType, String DataSet, String runStatus, ITestContext testContext) throws Exception
    {
        testContext.setAttribute("WebDriver", this.driver);

        /******** Validating using base processes ******/
        if ("DM_ID_008".equalsIgnoreCase(tc_Id) || "DM_ID_010".equalsIgnoreCase(tc_Id) || "DM_ID_011".equalsIgnoreCase(tc_Id)
                || "DM_ID_015".equalsIgnoreCase(tc_Id) || "DM_ID_017".equalsIgnoreCase(tc_Id) || "DM_ID_019".equalsIgnoreCase(tc_Id)
                || "DM_ID_059".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickStatsView(processName);
//            driver.switchTo().frame("sb-player");
            DmStatView.clickCounters();
//            driver.switchTo().frame("sb-player");
            String counterContent = DmStatView.getCounterContentStatsDM();
            String counterString = counterContent.replaceAll("[\\t\\n\\r]", "");

            // Validate that for DE DM records dropped at NoAgeCheck are recorded against "Total NoAgecheck Record Hits" in COUNTERS stats
            if ("DM_ID_008".equalsIgnoreCase(tc_Id))
            {
                String hitInputRecords = counterString.substring(counterString.indexOf("NoAgeCheck"),
                        counterString.indexOf("Total NoAgecheck Record Hits"));
                String inputRecordsFactAct = counterString.substring(counterString.indexOf("FactAct"),
                        counterString.indexOf("Total Input records to FactAct"));

                String inputRecords = counterString.substring(counterString.indexOf("NoAgeCheck"),
                        counterString.indexOf("Total Input records to NoAgeCheck"));

                String records = inputRecords.substring(inputRecords.indexOf("RECORDS"), inputRecords.indexOf("RECORDS") + 57);
                String hitRecords = hitInputRecords.substring(hitInputRecords.indexOf("TOTALNOAGEHITS"),
                        hitInputRecords.indexOf("TOTALNOAGEHITS") + 57);
                String recordsPassed = inputRecordsFactAct.substring(inputRecordsFactAct.indexOf("Total passed recordsFactAct"),
                        inputRecordsFactAct.indexOf("Total passed recordsFactAct") + 116);

                commMethods.verifyInt(Integer.parseInt(recordsPassed.substring(70).trim()),
                        Integer.parseInt(records.substring(7).trim()) - Integer.parseInt(hitRecords.substring(14).trim()));
            }

            // Validate that for DE DM records dropped at Invalid Street Address are recorded against "Total dropped for invalid street address" in
            // COUNTERS stats
            if ("DM_ID_010".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total dropped for invalid street address"));

                String invalidRecords = inputRecords.substring(inputRecords.indexOf("04_INVLD_ADDRESS_DROPS"),
                        inputRecords.indexOf("04_INVLD_ADDRESS_DROPS") + 57);
                Assert.assertTrue(!invalidRecords.substring(23).trim().equals("0"));

                String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Input records to FilterSelect"));
                String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"), totalInputRecords.indexOf("RECORDS") + 57);

                String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Records Available After FilterSelect"));
                String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                        totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                        Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(invalidRecords.substring(23).trim()));

            }

            // DM_ID_011 Validate that for DE DM records dropped at Missing City State or Zip are recorded against "Total dropped for missing city,
            // state, zip" in COUNTERS stats and are not processed further.
            // DM_ID_012 Validate that for DE DM records dropped at Missing City State or Zip are recorded against "Total dropped for missing city,
            // state, zip" in COUNTERS stats and are not included in Header Table.
            if ("DM_ID_011".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total dropped for missing city, state, zip"));

                String invalidRecords = inputRecords.substring(inputRecords.indexOf("05_MISSING_ADDRESS_DROPS"),
                        inputRecords.indexOf("05_MISSING_ADDRESS_DROPS") + 57);
                Assert.assertTrue(!invalidRecords.substring(28).trim().equals("0"));

                String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Input records to FilterSelect"));
                String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"), totalInputRecords.indexOf("RECORDS") + 57);

                String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Records Available After FilterSelect"));
                String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                        totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                        Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(invalidRecords.substring(28).trim()));

            }

            // DM_ID_013 Validate that for DE DM records dropped at Invalid Sub Name are recorded against "Total dropped for invalid name" in COUNTERS
            // stats and are not processed further.
            // DM_ID_014 Validate that for DE DM records dropped at Invalid Sub Name are recorded against "Total dropped for invalid name" in COUNTERS
            // stats and are not included in Header Table.
            if ("DM_ID_013".equalsIgnoreCase(tc_Id))
            {
                // TODO defect raised for invalid subname not getting selected alone
            }

            // Validate that for DE DM records dropped at Derogatory Names are recorded against "Total dropped for derogatory name" in COUNTERS stats
            // and are not processed further.
            // DM_ID_016 Validate that for DE DM records dropped at Derogatory Names are recorded against "Total dropped for derogatory name" in
            // COUNTERS stats and are not included in Header Table.

            if ("DM_ID_015".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total dropped for derogatory name"));

                String derogRecords = inputRecords.substring(inputRecords.indexOf("08_DEROG_NAME_DROPS"),
                        inputRecords.indexOf("08_DEROG_NAME_DROPS") + 57);
                Assert.assertTrue(!derogRecords.substring(23).trim().equals("0"));

                String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Input records to FilterSelect"));
                String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"), totalInputRecords.indexOf("RECORDS") + 57);

                String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Records Available After FilterSelect"));
                String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                        totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                        Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(derogRecords.substring(23).trim()));
            }

            // Validate that for DE DM records dropped at Offensive Names are recorded against "Total dropped for Offensive names" in COUNTERS stats
            // and are not processed further
            // DM_ID_20 Validate that for DE DM records dropped at Business Names are recorded against "Total dropped for Offensive name" in COUNTERS
            // stats and are not included in Header Table.

            if ("DM_ID_019".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total dropped for offensive name"));

                String derogRecords = inputRecords.substring(inputRecords.indexOf("07_OFFENSIVE_NAME_DROPS"),
                        inputRecords.indexOf("07_OFFENSIVE_NAME_DROPS") + 57);
                Assert.assertTrue(!derogRecords.substring(23).trim().equals("0"));

                String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Input records to FilterSelect"));
                String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"), totalInputRecords.indexOf("RECORDS") + 57);

                String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Records Available After FilterSelect"));
                String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                        totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                        Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(derogRecords.substring(23).trim()));
            }

            // Validate that for DE DM records dropped at Business Names are recorded against "Total dropped for Business names" in COUNTERS stats and
            // are not processed further.
            // DM_ID_018 Validate that for DE DM records dropped at Business Names are recorded against "Total dropped for Business name" in COUNTERS
            // stats and are not included in Header Table.
            if ("DM_ID_017".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total dropped for business name"));

                String businessRecords = inputRecords.substring(inputRecords.indexOf("09_BUSINESS_NAME_DROPS"),
                        inputRecords.indexOf("09_BUSINESS_NAME_DROPS") + 57);
                Assert.assertTrue(!businessRecords.substring(23).trim().equals("0"));

                String totalInputRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Input records to FilterSelect"));
                String totalRecords = totalInputRecords.substring(totalInputRecords.indexOf("RECORDS"), totalInputRecords.indexOf("RECORDS") + 57);

                String totalPassedRecords = counterString.substring(counterString.indexOf("FilterSelect"),
                        counterString.indexOf("Total Records Available After FilterSelect"));
                String passedRecords = totalPassedRecords.substring(totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT"),
                        totalPassedRecords.indexOf("01_TOTAL_FILTER_OUTPUT") + 57);

                commMethods.verifyInt(Integer.parseInt(passedRecords.substring(23).trim()),
                        Integer.parseInt(totalRecords.substring(7).trim()) - Integer.parseInt(businessRecords.substring(23).trim()));
            }

            // Validate that for DE DM correct record count is populated in counters file for Citi doublecheck type.
            if ("DM_ID_059".equalsIgnoreCase(tc_Id))
            {
                String inputRecords = counterString.substring(counterString.indexOf("DoubleCheck"),
                        counterString.indexOf("Total Input records to DoubleCheck"));
                String levelARecords = inputRecords.substring(inputRecords.indexOf("0001_A SSN DoubleCheck"),
                        inputRecords.indexOf("0001_A SSN DoubleCheck") + 57);
                String levelBRecords = inputRecords.substring(inputRecords.indexOf("0012_B SSN DoubleCheck"),
                        inputRecords.indexOf("0012_B SSN DoubleCheck") + 57);
                String levelCRecords = inputRecords.substring(inputRecords.indexOf("0023_C SSN DoubleCheck"),
                        inputRecords.indexOf("0023_C SSN DoubleCheck") + 57);
                String levelDRecords = inputRecords.substring(inputRecords.indexOf("0034_D SSN DoubleCheck"),
                        inputRecords.indexOf("0034_D SSN DoubleCheck") + 57);
                String levelERecords = inputRecords.substring(inputRecords.indexOf("0045_E SSN DoubleCheck"),
                        inputRecords.indexOf("0045_E SSN DoubleCheck") + 57);
                String levelFRecords = inputRecords.substring(inputRecords.indexOf("0056_F SSN DoubleCheck"),
                        inputRecords.indexOf("0056_F SSN DoubleCheck") + 57);
                String levelGRecords = inputRecords.substring(inputRecords.indexOf("0067_G SSN DoubleCheck"),
                        inputRecords.indexOf("0067_G SSN DoubleCheck") + 57);
                String levelHRecords = inputRecords.substring(inputRecords.indexOf("0078_H SSN DoubleCheck"),
                        inputRecords.indexOf("0078_H SSN DoubleCheck") + 57);
                String levelIRecords = inputRecords.substring(inputRecords.indexOf("0089_I SSN DoubleCheck"),
                        inputRecords.indexOf("0089_I SSN DoubleCheck") + 57);
                String levelJRecords = inputRecords.substring(inputRecords.indexOf("0100_J SSN DoubleCheck"),
                        inputRecords.indexOf("0100_J SSN DoubleCheck") + 57);
                String levelKRecords = inputRecords.substring(inputRecords.indexOf("0111_K SSN DoubleCheck"),
                        inputRecords.indexOf("0111_K SSN DoubleCheck") + 57);
                String levelLRecords = inputRecords.substring(inputRecords.indexOf("0122_L SSN DoubleCheck"),
                        inputRecords.indexOf("0122_L SSN DoubleCheck") + 57);
                String levelMRecords = inputRecords.substring(inputRecords.indexOf("0133_M SSN DoubleCheck"),
                        inputRecords.indexOf("0133_M SSN DoubleCheck") + 57);
                String levelNRecords = inputRecords.substring(inputRecords.indexOf("0144_N SSN DoubleCheck"),
                        inputRecords.indexOf("0144_N SSN DoubleCheck") + 57);
                String levelORecords = inputRecords.substring(inputRecords.indexOf("0155_O SSN DoubleCheck"),
                        inputRecords.indexOf("0155_O SSN DoubleCheck") + 57);
                String levelPRecords = inputRecords.substring(inputRecords.indexOf("0166_P SSN DoubleCheck"),
                        inputRecords.indexOf("0166_P SSN DoubleCheck") + 57);
                String levelQRecords = inputRecords.substring(inputRecords.indexOf("0177_Q SSN DoubleCheck"),
                        inputRecords.indexOf("0177_Q SSN DoubleCheck") + 57);
                String levelRRecords = inputRecords.substring(inputRecords.indexOf("0188_R SSN DoubleCheck"),
                        inputRecords.indexOf("0188_R SSN DoubleCheck") + 57);
                String levelSRecords = inputRecords.substring(inputRecords.indexOf("0199_S SSN DoubleCheck"),
                        inputRecords.indexOf("0199_S SSN DoubleCheck") + 57);
                String levelTRecords = inputRecords.substring(inputRecords.indexOf("0210_T SSN DoubleCheck"),
                        inputRecords.indexOf("0210_T SSN DoubleCheck") + 57);
                String levelURecords = inputRecords.substring(inputRecords.indexOf("0221_U SSN DoubleCheck"),
                        inputRecords.indexOf("0221_U SSN DoubleCheck") + 57);
                String levelVRecords = inputRecords.substring(inputRecords.indexOf("0232_V SSN DoubleCheck"),
                        inputRecords.indexOf("0232_V SSN DoubleCheck") + 57);
                String levelWRecords = inputRecords.substring(inputRecords.indexOf("0243_W SSN DoubleCheck"),
                        inputRecords.indexOf("0243_W SSN DoubleCheck") + 57);
                String levelXRecords = inputRecords.substring(inputRecords.indexOf("0254_X SSN DoubleCheck"),
                        inputRecords.indexOf("0254_X SSN DoubleCheck") + 57);
                String levelYRecords = inputRecords.substring(inputRecords.indexOf("0265_Y SSN DoubleCheck"),
                        inputRecords.indexOf("0265_Y SSN DoubleCheck") + 57);
                String levelZRecords = inputRecords.substring(inputRecords.indexOf("0276_Z SSN DoubleCheck"),
                        inputRecords.indexOf("0276_Z SSN DoubleCheck") + 57);

                String SSNRecords = inputRecords.substring(inputRecords.indexOf("0287_TOTALSSN"), inputRecords.indexOf("0287_TOTALSSN") + 57);
                commMethods.verifyInt(
                        Integer.parseInt(levelARecords.substring(30).trim()) + Integer.parseInt(levelBRecords.substring(30).trim())
                                + Integer.parseInt(levelCRecords.substring(30).trim()) + Integer.parseInt(levelDRecords.substring(30).trim())
                                + Integer.parseInt(levelERecords.substring(30).trim()) + Integer.parseInt(levelFRecords.substring(30).trim())
                                + Integer.parseInt(levelGRecords.substring(30).trim()) + Integer.parseInt(levelHRecords.substring(30).trim())
                                + Integer.parseInt(levelIRecords.substring(30).trim()) + Integer.parseInt(levelJRecords.substring(30).trim())
                                + Integer.parseInt(levelKRecords.substring(30).trim()) + Integer.parseInt(levelLRecords.substring(30).trim())
                                + Integer.parseInt(levelMRecords.substring(30).trim()) + Integer.parseInt(levelNRecords.substring(30).trim())
                                + Integer.parseInt(levelORecords.substring(30).trim()) + Integer.parseInt(levelPRecords.substring(30).trim())
                                + Integer.parseInt(levelQRecords.substring(30).trim()) + Integer.parseInt(levelRRecords.substring(30).trim())
                                + Integer.parseInt(levelSRecords.substring(30).trim()) + Integer.parseInt(levelTRecords.substring(30).trim())
                                + Integer.parseInt(levelURecords.substring(30).trim()) + Integer.parseInt(levelVRecords.substring(30).trim())
                                + Integer.parseInt(levelWRecords.substring(30).trim()) + Integer.parseInt(levelXRecords.substring(30).trim())
                                + Integer.parseInt(levelYRecords.substring(30).trim()) + Integer.parseInt(levelZRecords.substring(30).trim()),
                        Integer.parseInt(SSNRecords.substring(18).trim()));

                levelARecords = inputRecords.substring(inputRecords.indexOf("0288_A ADR DoubleCheck"),
                        inputRecords.indexOf("0288_A ADR DoubleCheck") + 57);
                levelBRecords = inputRecords.substring(inputRecords.indexOf("0299_B ADR DoubleCheck"),
                        inputRecords.indexOf("0299_B ADR DoubleCheck") + 57);
                levelCRecords = inputRecords.substring(inputRecords.indexOf("0310_C ADR DoubleCheck"),
                        inputRecords.indexOf("0310_C ADR DoubleCheck") + 57);
                levelDRecords = inputRecords.substring(inputRecords.indexOf("0321_D ADR DoubleCheck"),
                        inputRecords.indexOf("0321_D ADR DoubleCheck") + 57);
                levelERecords = inputRecords.substring(inputRecords.indexOf("0332_E ADR DoubleCheck"),
                        inputRecords.indexOf("0332_E ADR DoubleCheck") + 57);
                levelFRecords = inputRecords.substring(inputRecords.indexOf("0343_F ADR DoubleCheck"),
                        inputRecords.indexOf("0343_F ADR DoubleCheck") + 57);
                levelGRecords = inputRecords.substring(inputRecords.indexOf("0354_G ADR DoubleCheck"),
                        inputRecords.indexOf("0354_G ADR DoubleCheck") + 57);
                levelHRecords = inputRecords.substring(inputRecords.indexOf("0365_H ADR DoubleCheck"),
                        inputRecords.indexOf("0365_H ADR DoubleCheck") + 57);
                levelIRecords = inputRecords.substring(inputRecords.indexOf("0376_I ADR DoubleCheck"),
                        inputRecords.indexOf("0376_I ADR DoubleCheck") + 57);
                levelJRecords = inputRecords.substring(inputRecords.indexOf("0387_J ADR DoubleCheck"),
                        inputRecords.indexOf("0387_J ADR DoubleCheck") + 57);
                levelKRecords = inputRecords.substring(inputRecords.indexOf("0398_K ADR DoubleCheck"),
                        inputRecords.indexOf("0398_K ADR DoubleCheck") + 57);
                levelLRecords = inputRecords.substring(inputRecords.indexOf("0409_L ADR DoubleCheck"),
                        inputRecords.indexOf("0409_L ADR DoubleCheck") + 57);
                levelMRecords = inputRecords.substring(inputRecords.indexOf("0420_M ADR DoubleCheck"),
                        inputRecords.indexOf("0420_M ADR DoubleCheck") + 57);
                levelNRecords = inputRecords.substring(inputRecords.indexOf("0431_N ADR DoubleCheck"),
                        inputRecords.indexOf("0431_N ADR DoubleCheck") + 57);
                levelORecords = inputRecords.substring(inputRecords.indexOf("0442_O ADR DoubleCheck"),
                        inputRecords.indexOf("0442_O ADR DoubleCheck") + 57);
                levelPRecords = inputRecords.substring(inputRecords.indexOf("0453_P ADR DoubleCheck"),
                        inputRecords.indexOf("0453_P ADR DoubleCheck") + 57);
                levelQRecords = inputRecords.substring(inputRecords.indexOf("0464_Q ADR DoubleCheck"),
                        inputRecords.indexOf("0464_Q ADR DoubleCheck") + 57);
                levelRRecords = inputRecords.substring(inputRecords.indexOf("0475_R ADR DoubleCheck"),
                        inputRecords.indexOf("0475_R ADR DoubleCheck") + 57);
                levelSRecords = inputRecords.substring(inputRecords.indexOf("0486_S ADR DoubleCheck"),
                        inputRecords.indexOf("0486_S ADR DoubleCheck") + 57);
                levelTRecords = inputRecords.substring(inputRecords.indexOf("0497_T ADR DoubleCheck"),
                        inputRecords.indexOf("0497_T ADR DoubleCheck") + 57);
                levelURecords = inputRecords.substring(inputRecords.indexOf("0508_U ADR DoubleCheck"),
                        inputRecords.indexOf("0508_U ADR DoubleCheck") + 57);
                levelVRecords = inputRecords.substring(inputRecords.indexOf("0519_V ADR DoubleCheck"),
                        inputRecords.indexOf("0519_V ADR DoubleCheck") + 57);
                levelWRecords = inputRecords.substring(inputRecords.indexOf("0530_W ADR DoubleCheck"),
                        inputRecords.indexOf("0530_W ADR DoubleCheck") + 57);
                levelXRecords = inputRecords.substring(inputRecords.indexOf("0541_X ADR DoubleCheck"),
                        inputRecords.indexOf("0541_X ADR DoubleCheck") + 57);
                levelYRecords = inputRecords.substring(inputRecords.indexOf("0552_Y ADR DoubleCheck"),
                        inputRecords.indexOf("0552_Y ADR DoubleCheck") + 57);
                levelZRecords = inputRecords.substring(inputRecords.indexOf("0563_Z ADR DoubleCheck"),
                        inputRecords.indexOf("0563_Z ADR DoubleCheck") + 57);

                String ADRRecords = inputRecords.substring(inputRecords.indexOf("0574_TOTALADRREC"), inputRecords.indexOf("0574_TOTALADRREC") + 57);
                commMethods.verifyInt(
                        Integer.parseInt(levelARecords.substring(30).trim()) + Integer.parseInt(levelBRecords.substring(30).trim())
                                + Integer.parseInt(levelCRecords.substring(30).trim()) + Integer.parseInt(levelDRecords.substring(30).trim())
                                + Integer.parseInt(levelERecords.substring(30).trim()) + Integer.parseInt(levelFRecords.substring(30).trim())
                                + Integer.parseInt(levelGRecords.substring(30).trim()) + Integer.parseInt(levelHRecords.substring(30).trim())
                                + Integer.parseInt(levelIRecords.substring(30).trim()) + Integer.parseInt(levelJRecords.substring(30).trim())
                                + Integer.parseInt(levelKRecords.substring(30).trim()) + Integer.parseInt(levelLRecords.substring(30).trim())
                                + Integer.parseInt(levelMRecords.substring(30).trim()) + Integer.parseInt(levelNRecords.substring(30).trim())
                                + Integer.parseInt(levelORecords.substring(30).trim()) + Integer.parseInt(levelPRecords.substring(30).trim())
                                + Integer.parseInt(levelQRecords.substring(30).trim()) + Integer.parseInt(levelRRecords.substring(30).trim())
                                + Integer.parseInt(levelSRecords.substring(30).trim()) + Integer.parseInt(levelTRecords.substring(30).trim())
                                + Integer.parseInt(levelURecords.substring(30).trim()) + Integer.parseInt(levelVRecords.substring(30).trim())
                                + Integer.parseInt(levelWRecords.substring(30).trim()) + Integer.parseInt(levelXRecords.substring(30).trim())
                                + Integer.parseInt(levelYRecords.substring(30).trim()) + Integer.parseInt(levelZRecords.substring(30).trim()),
                        Integer.parseInt(ADRRecords.substring(18).trim()));

            }

        } else if ("DM_ID_141".equalsIgnoreCase(tc_Id) || "DM_ID_585".equalsIgnoreCase(tc_Id) || "DM_ID_586".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.inputProjNum(copyProj);
            ProjDashBoardPage.clickCopyProjSrchBtn();
            ProjDashBoardPage.selectCopyPrevProjProcName(copyProcName);
            ProjDashBoardPage.clickCopySelectBtn();
            ProjDashBoardPage.clickDataMenuTab();
            module.initializeDriver(driver);
            if ("DM_ID_141".equalsIgnoreCase(tc_Id))
            {
                String status = driver.findElement(By.xpath(".//*[@id='row0jqxgridJobListing']/div[3]/div")).getText();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
            }
            if ("DM_ID_585".equalsIgnoreCase(tc_Id))
            {
                module.selectEdit();
                DMFilterConPag.clickElementInConfigTable(APModuleNonCriteria);
                APModPag.clickContinueButton();
                String errMsg = ModDepenPag.checkIfErrorIsPresent(APModuleNonCriteria);
                Assert.assertTrue(errMsg.contains(APModuleNonCriteria));
            }
            if ("DM_ID_586".equalsIgnoreCase(tc_Id))
            {
                module.selectSummary();
                DMSummPag.clickSubmitButton();
                String errMsg = DMSummPag.checkIfErrorIsPresent(APModuleNonCriteria);
                Assert.assertTrue(errMsg.contains(APModuleNonCriteria));
            }
        } else
        {
            // Current project doesnt have a family code, hence using another project to verify
            if ("DM_ID_581".equalsIgnoreCase(tc_Id))
            {
                driver.findElement(By.id("cms_search")).click();
                driver.findElement(By.id("projectNumber")).clear();
                driver.findElement(By.id("projectNumber")).sendKeys(copyProj);
                driver.findElement(By.id("searchButton")).click();
                driver.findElement(By.linkText(copyProj)).click();
            }

            ProjDashBoardPage.clickDataMenuTab();
            DataMenuHomPag.clickDataMenuButton();

            ProcesNamePag.InputProcessNameField(processName);
            ProcesNamePag.clickContinueButton();
            DataOriginPag.selectDataOriginField(DataOriginField);
            DataOriginPag.clickContinueButton();
            ProdPag.clickContinueButton();

            if (DataOriginField.equalsIgnoreCase("List Source"))
            {
                SrcInpPag.selectProcessField(smProcess);
                SrcInpPag.selectDataField(dataField);
                SrcInpPag.clickContinueButton();
            }

            // Validate that A new option 'Do not Reject states' must be added to the drop list for State Input in the Data Menu.
            if ("DM_ID_412".equalsIgnoreCase(tc_Id))
            {
                try
                {
                    StZipCodInPag.selectStatesDropDwn("Do Not Reject States");
                } catch (Exception e)
                {
                    Assert.assertEquals("Value No Present", "Value Present");
                }

            }

            if ("DM_ID_581".equalsIgnoreCase(tc_Id) || "DM_ID_582".equalsIgnoreCase(tc_Id) || "DM_ID_583".equalsIgnoreCase(tc_Id)
                    || "DM_ID_288".equalsIgnoreCase(tc_Id) || "DM_ID_289".equalsIgnoreCase(tc_Id))
            {
                StZipCodInPag.selectStatesList(stateList);
                StZipCodInPag.clickBetaBtn();

                APModPag.clickUseProdAPmoduleOnly(prodAPmod);
                Thread.sleep(5000);
                APModPag.selectAPModuleNonCriteria(APModuleNonCriteria);
                APModPag.clickContinueButton();

                // DM_ID_582 Validate that user is able to view the external file created with such a customer which does not have a high family code
                // i.e. has
                // SYSTEM as
                // family code, on module dependencies screen in external dependencies dropdown of any data menu.
                // DM_ID_581 Valdiate that user is able to view the external file created under a specific high family code, on module dependencies
                // screen in external dependencies dropdown of a data menu which is created under same high family code.(SAUTO01 doesn�t have a high
                // family code, hence using other project under copyProject)

                if ("DM_ID_581".equalsIgnoreCase(tc_Id) || "DM_ID_582".equalsIgnoreCase(tc_Id))
                {
                    ModDepenPag.checkOptionsModuleDependencies(depFile);
                }

                // Validate that the external dependencies dropdown on module dependencies screen is sorted by external file name.
                if ("DM_ID_583".equalsIgnoreCase(tc_Id))
                {
                    List<String> options = ModDepenPag.getOptionsModuleDependencies();

                    boolean sorted = true;
                    for (int i = 2; i < options.size(); i++)
                    {
                        if (options.get(i - 1).toLowerCase().compareTo(options.get(i).toLowerCase()) > 0)
                            sorted = false;
                    }
                    commMethods.verifyboolean(true, sorted);
                }

                if ("DM_ID_288".equalsIgnoreCase(tc_Id) || "DM_ID_289".equalsIgnoreCase(tc_Id))
                {
                    ModOutptPag.clickContinueButton();
                    ScreModlPag.clickAddScoreModelButton();
                    ScreModlPag.selectScoreModelField(scoreModel);
                    Thread.sleep(2000);

                    // Validate that for a list source DM Process, list of all the Optional and Required Parameter pertaining to the added score model
                    // are
                    // populated on the Score Model Screen
                    if ("DM_ID_288".equalsIgnoreCase(tc_Id))
                    {
                        int i = 0;
                        List<String> paramNames = new ArrayList<>();
                        while (commMethods.isElementPresent_Xpath(".//*[@id='scoreParamDiv1']/table/tbody/tr[" + (i + 2) + "]/td[1]/span"))
                        {
                            paramNames.add(driver.findElement(By.xpath(".//*[@id='scoreParamDiv1']/table/tbody/tr[" + (i + 2) + "]/td[1]/span"))
                                    .getText().substring(1)); // removing the * from the text
                            i++;
                        }
                        String[] scoreParamsSplit = scoreParams.split(",");
                        i = 0;
                        while (i < scoreParamsSplit.length)
                        {
                            Assert.assertTrue(paramNames.contains(scoreParamsSplit[i]));
                            i++;
                        }
                    }

                    // Validate that score parameter drop down list field populates the fields from Import New File process that is in the up
                    // hierarchy of
                    // the List Source data menu process being created
                    if ("DM_ID_289".equalsIgnoreCase(tc_Id))
                    {
                        ScreModlPag.clickContinueButton();
                        String errMsg = ScreModlPag.getErrorMessage();
                        commMethods.verifyContainsString(errMsg, "Provide value for parameter");

                    }

                }

            }
        } // end else

        // Update runstatus in the end once tc is complete
        ExcelRead.updateRunStatus(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "DataMenu_QA", tc_Id);

    }

    @AfterMethod
    public void tearDown()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] dm_Reg1() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DataMenu_QA", "BAS");        							
        return (testObjArray_Y);
    }

    @DataProvider
    public Object[][] dm_Reg2() throws Exception
    {
        Object[][] testObjArray = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "DataMenu_QA", "Y");
        return (testObjArray);
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    public void getscreenshot() throws Exception
    {
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        // The below method will save the screen shot in d drive with name "screenshot.png"
        // FileUtils.copyFile(scrFile, new File("C:\\Users\\akp8\\Desktop\\screenshot.png"));
    }

}

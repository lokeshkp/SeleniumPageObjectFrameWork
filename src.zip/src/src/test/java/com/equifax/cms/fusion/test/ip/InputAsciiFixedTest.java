package com.equifax.cms.fusion.test.ip;

import java.util.List;

import org.junit.Assert;
import org.junit.experimental.theories.Theories;
import org.junit.experimental.theories.Theory;
import org.junit.runner.RunWith;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.AbstractCoreTest;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.InputLayoutVO;
import com.equifax.cms.fusion.test.vo.InputProcessVO;

@Features("Input fixed ascii fixed process")
@RunWith(Theories.class)
public class InputAsciiFixedTest extends AbstractCoreTest {


	private static final Logger LOGGER = LoggerFactory.getLogger(InputAsciiFixedTest.class);
	private static final String IP = "Input";
    private static final String EXISTINGLAYOUT = "Existing Layout";
    private static final String NEWLAYOUT = "Create New Layout";

	WebDriverWait wait;

	@Theory
	public void testInputFixed() throws Exception {
		userLogin();
		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);

		List<InputProcessVO> list = reader.getInputProcessData();
		for (InputProcessVO input : list) {
			if (ASCII_FIXED.equalsIgnoreCase(input.getFormat())
					&& ProcessOperationEnum.SAVE.name().equalsIgnoreCase(input.getOperation())) {
				saveInputAsciiProcess(input.getProcessName(), input);
			} else if (ASCII_FIXED.equalsIgnoreCase(input.getFormat())
					&& ProcessOperationEnum.EDIT.name().equalsIgnoreCase(input.getOperation())) {
				editInputAsciiProcess(input.getProcessName(), input);
			}
 else if (ASCII_FIXED.equalsIgnoreCase(input.getFormat())
                    && ProcessOperationEnum.DUPLICATE.name().equalsIgnoreCase(input.getOperation()))
            {
                duplicateInputAsciiProcess(input.getProcessName(), input);
            } else if (ASCII_FIXED.equalsIgnoreCase(input.getFormat()) && ProcessOperationEnum.SUBMIT.name().equalsIgnoreCase(input.getOperation()))
            {
                submitInputAsciiProcess(input.getProcessName(), input);
            }
		}
	}


	@Step("Create ASCII Fixed process : {0} ")
	private void saveInputAsciiProcess(String processName, InputProcessVO input) {

        navigateToProcess(IP);
		driver.findElement(By.linkText("Import New File")).click();
		// Test Case : Create a new input process, create a new layout,add one
		// value in the layout selecting from customize, save, continue, do not
		driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys(input.getProcessName());// Get from csv
        new Select(driver.findElement(By.id("fileType"))).selectByVisibleText(input.getType());// Get from csv
        new Select(driver.findElement(By.id("purpose"))).selectByVisibleText(input.getPurpose());// Get from csv
		driver.findElement(By.id("filePath")).clear();
		// Get from csv
		driver.findElement(By.id("filePath")).sendKeys(input.getLocation());
		driver.findElement(By.id("recLen")).clear();
		driver.findElement(By.id("recLen")).sendKeys(input.getRecordLength());
		driver.findElement(By.id("gpSeqNumStartFrom")).clear();
		driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(input.getStartingSeq());
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).clear();
        driver.findElement(By.id("listVirtualArtifacts0.userProvidedName")).sendKeys(input.getOutputTable());

        // Get layout field details
        List<InputLayoutVO> layout = reader.getInputLayout(input.getLayoutName());

        // driver.findElement(By.id("layoutName")).clear();

        if (NEWLAYOUT.equalsIgnoreCase(input.getInputLayout()))
        {
            driver.findElement(By.id("newLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            createNewLayout(input.getLayoutName(), input.getFormat(), input.getInputLayout());
		}
        // Use existing layout with the fields provided in csv from current project
        if (EXISTINGLAYOUT.equalsIgnoreCase(input.getInputLayout()) && null == input.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();

            int i = 1;
            boolean flag = false;
            int noOfRows = getNumberOfRowsExistingLayoutsForIPFixed();
            while (flag == false && i <= noOfRows)
            {
                String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]")).getText();
                if (str.equals(input.getLayoutName())) // Get from csv
                {
                    flag = true;
                    // Gets the radio button that is closest to the layout to be selected
                    driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[1]/input")).click();
                    break;
                }
                i++;
            }
            editExistingLayout(layout, input.getFormat(), input.getInputLayout());
        } else if (EXISTINGLAYOUT.equalsIgnoreCase(input.getInputLayout()) && null != input.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();
            searchLayoutFromOtherProject(input.getLayoutName(), input.getFormat(), input.getSearchLayoutFromOtherProj());
            editExistingLayout(layout, input.getFormat(), input.getInputLayout());
        }

        selectSubmit();

		// Due to big time lag let thread sleep for 1minute so that it reaches
		// the next screen
		delayThread(20000);

        // If datacheck checkbox is not selected, values need to be there
        if (("0").equals(input.getIsDataCheck()))
        {
            new Select(driver.findElement(By.id("fileIdentifier"))).selectByVisibleText(input.getFileIdentifier());
            driver.findElement(By.id("maxNoOfBlankFields")).clear();
            driver.findElement(By.id("maxNoOfBlankFields")).sendKeys(input.getBlankFields());
            driver.findElement(By.id("maxNoOfSingleFields")).clear();
            driver.findElement(By.id("maxNoOfSingleFields")).sendKeys(input.getSingleValueFields());
            driver.findElement(By.id("maxNoOfUnknownFields")).clear();
            driver.findElement(By.id("maxNoOfUnknownFields")).sendKeys(input.getUnknownFields());
            new Select(driver.findElement(By.id("runtimeB"))).selectByVisibleText(input.getRuntimeB());
        }
 else
        {
            driver.findElement(By.id("isDataCheck")).click();
        }

        // continue to summary page
        selectSubmit();

        // Verification with user provided values, if values are coming correct from database in summary
        String ipProcessName = driver.findElement(By.xpath("//form[@id='ifpForm']/span")).getText();

        int first = ipProcessName.indexOf(':') + 1;
        int second = ipProcessName.indexOf(':', first + 1);
        Assert.assertEquals(input.getProcessName().toLowerCase(), ipProcessName.substring(second + 1).toLowerCase().trim());

       // int first = ipProcessName.indexOf(':') + 1;
        // Assert.assertEquals(input.getProcessName().toLowerCase(), ipProcessName.substring(first + 1).toLowerCase().trim());

        String fileName = driver.findElement(By.xpath("//form[@id='ifpForm']/table/tbody/tr/td/span")).getText();
        if (null != input.getLocation() && !("".equals(input.getLocation())))
        {
            Assert.assertEquals(input.getLocation().toLowerCase(), fileName.toLowerCase().trim());
        }

        String type = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[1]/td[2]")).getText();
        if (null != input.getType() && !("".equals(input.getType())))
            Assert.assertEquals(input.getType().toLowerCase(), type.toLowerCase().trim());

        String purpose = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[2]/td[2]")).getText();
        if (null != input.getPurpose() && !("".equals(input.getPurpose())))
        {
            Assert.assertEquals(input.getPurpose().toLowerCase(), purpose.toLowerCase().trim());
        }

        String format = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[3]/td[2]")).getText();
        if (null != input.getFormat() && !("".equals(input.getFormat())))
        {
            format = format.replaceAll("[_]", " ");
            Assert.assertEquals(input.getFormat().toLowerCase(), format.toLowerCase().trim());
        }

        String startingSeq = driver.findElement(By.xpath("//form[@id='ifpForm']/table[3]/tbody/tr[7]/td[2]")).getText();
        if (null != input.getStartingSeq() && !("".equals(input.getStartingSeq())))
        {
            Assert.assertEquals(input.getStartingSeq().toLowerCase(), startingSeq.toLowerCase().trim());
        }

        // TODO add invalid blank checkbox

        navigateToProcess(IP);

        String status = getStatusIP();
		Assert.assertEquals(StatusEnum.READY.name(), status.trim());
		Assert.assertEquals(input.getExpectedStatus(), status.trim());
	}

    @Step("Edit input ascii process {0}")
    private void editInputAsciiProcess(String processName, InputProcessVO input) throws Exception
    {
        createAttachment(input.toString());
        navigateToProcess(IP);
        // Test Case : Edit the input process, select a new layout, continue,
        // add a field and constant and continue
        // selectEdit();

        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(input.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Edit")).click();
                modifyAsciiFixedProcess(input, columns);
                break;
            }
        }

        navigateToProcess(IP);

        String status = getStatusIP();
        Assert.assertEquals(input.getExpectedStatus(), status.trim());

    }

    private void modifyAsciiFixedProcess(InputProcessVO input, List<WebElement> columns)
    {
        // driver.findElement(By.id("processName")).clear();
        // driver.findElement(By.id("processName")).sendKeys(input);// Get from csv
        driver.findElement(By.id("filePath")).clear();
        // Get from csv
        driver.findElement(By.id("filePath")).sendKeys(input.getLocation());
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("recLen")).sendKeys(input.getRecordLength());
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(input.getStartingSeq());

        // Get layout field details
        List<InputLayoutVO> layout = reader.getInputLayout(input.getLayoutName());

        if (NEWLAYOUT.equalsIgnoreCase(input.getInputLayout()))
        {
            driver.findElement(By.id("newLayoutRadio")).click();
            driver.findElement(By.id("submitLayout")).click();
            createNewLayout(input.getLayoutName(), input.getFormat(), input.getInputLayout());
        }
        // Use existing layout with the fields provided in csv from current project
        if (EXISTINGLAYOUT.equalsIgnoreCase(input.getInputLayout()) && null == input.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();

            int i = 1;
            boolean flag = false;
            int noOfRows = getNumberOfRowsExistingLayoutsForIPFixed();
            while (flag == false && i <= noOfRows)
            {
                String str = driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[2]")).getText();
                if (str.equals(input.getLayoutName())) // Get from csv
                {
                    flag = true;
                    // Gets the radio button that is closest to the layout to be selected
                    driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[1]/input")).click();
                    break;
                }
                i++;
            }
            editExistingLayout(layout, input.getFormat(), input.getInputLayout());
        } else if (EXISTINGLAYOUT.equalsIgnoreCase(input.getInputLayout()) && null != input.getSearchLayoutFromOtherProj())
        {
            driver.findElement(By.id("existingLayoutRadio")).click();
            searchLayoutFromOtherProject(input.getLayoutName(), input.getFormat(), input.getSearchLayoutFromOtherProj());
            editExistingLayout(layout, input.getFormat(), input.getInputLayout());
        }

        selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches
        // the next screen
        delayThread(20000);
        // continue to summary screen
        // If datacheck checkbox is not selected, values need to be there
        if (("0").equals(input.getIsDataCheck()))
        {
            new Select(driver.findElement(By.id("fileIdentifier"))).selectByVisibleText(input.getFileIdentifier());
            driver.findElement(By.id("maxNoOfBlankFields")).clear();
            driver.findElement(By.id("maxNoOfBlankFields")).sendKeys(input.getBlankFields());
            driver.findElement(By.id("maxNoOfSingleFields")).clear();
            driver.findElement(By.id("maxNoOfSingleFields")).sendKeys(input.getSingleValueFields());
            driver.findElement(By.id("maxNoOfUnknownFields")).clear();
            driver.findElement(By.id("maxNoOfUnknownFields")).sendKeys(input.getUnknownFields());
            new Select(driver.findElement(By.id("runtimeB"))).selectByVisibleText(input.getRuntimeB());
        } else
        {
            if (!driver.findElement(By.id("isDataCheck")).isSelected())
                driver.findElement(By.id("isDataCheck")).click();
        }
        selectSubmit();

    }


    @Step("Duplicate input ascii process {0}")
    private void duplicateInputAsciiProcess(String processName, InputProcessVO input) throws Exception
    {
        // TestCase : Duplicate functionality works with all values complete
        navigateToProcess(IP);
        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(input.getProcessName()))
            {
                columns.get(0).click();
                duplicateProcess();
                break;
            }
        }
        String status = getStatusIP();
        Assert.assertEquals(input.getExpectedStatus(), status.trim());

    }

    @Step("Submit input ascii process {0}")
    private void submitInputAsciiProcess(String processName, InputProcessVO vo) throws Exception
    {

        String status = null;

        navigateToProcess(IP);

        List<WebElement> inputs = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                columns.get(0).click();
                driver.findElement(By.id("Summary")).click();
                break;
            }
        }


        // Test Case : Submit the process with no datacheck from summary
        selectSubmit();
        navigateToProcess(IP);
        // String status = getStatusIP();

        // Status for the process should change to submitted
        List<WebElement> inputs1 = driver.findElements(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr"));

        for (WebElement element : inputs1)
        {
            List<WebElement> columns = element.findElements(By.xpath("td"));
            if (columns.get(1).getText().trim().contains(vo.getProcessName()))
            {
                status = columns.get(3).getText().trim();
                break;
            }
        }
        Assert.assertEquals(vo.getExpectedStatus(), status.trim());

        navigateToHome();

        String jobId = getJobId();

        if (("0").equals(vo.getIsDataCheck()))
        {
            testIPSubmitWithDC(jobId);
        } else
        {
            testIPSubmitNoDC(jobId);
        }

        // Verification with greenplum values
    }

    @Step("Create new layout {0} ")
    private void createNewLayout(String layoutName, String format, String inputLayout)
    {

        List<InputLayoutVO> layout = reader.getInputLayout(layoutName);
        driver.findElement(By.id("layoutName")).sendKeys(layoutName);

        // Fieldtype starts from 0
        int position = 0;
        int constCounter = 0;

        boolean selectAll = false;
        for (InputLayoutVO field : layout)
        {
            if (inputLayout.equals(field.getInputLayout()))
            {
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }

            /*
             * if (null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows()); //
             * If alert is present accept the alert acceptAndGetAlertText();
             */
            if (null != field.getFieldType())
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());

            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getFieldName())
            {
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
            }

            if (null != field.getStartPos())
            {
                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("start" + position)).sendKeys(field.getStartPos());
            }
            if (null != field.getEndPos())
            {
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("end" + position)).sendKeys(field.getEndPos());
            }

            driver.findElement(By.id("addField")).click();

            if (null != field.getConstName())
            {
                // Add constant
                List<WebElement> list = driver.findElements(By.id("addField"));
                // Click the second addField button for constant
                list.get(1).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());
                constCounter++;
            }

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }
        }

    }
    @Step("Edit existing layout {0} ")
    private void editExistingLayout(List<InputLayoutVO> layout, String format, String inputLayout)
    {
        // Go to existing layout page
        driver.findElement(By.id("submitLayout")).click();

        // Fieldtype starts from 1
        int position = getNumberOfRowsLayoutTable() + 1;
        int constCounter = getNumberOfRowsConstTable();

        boolean selectAll = false;
        for (InputLayoutVO field : layout)
        {
            if (inputLayout.equals(field.getInputLayout()))
            {
            driver.findElement(By.id("addField")).click();
            if (!selectAll)
            {
                selectAllFieldType("fieldType" + position, format);
                selectAll = true;
            }

            /*
             * if (null != field.getHeaderRows()) new Select(driver.findElement(By.id("headerLines"))).selectByVisibleText(field.getHeaderRows()); //
             * If alert is present accept the alert acceptAndGetAlertText();
             */
            if (null != field.getCheckCleanse())
            {
                if (field.getCheckCleanse().equals("1"))
                    driver.findElement(By.id("cleanse1")).click();
            }

            if (null != field.getFieldName())
            {
                new Select(driver.findElement(By.id("fieldType" + position))).selectByVisibleText(field.getFieldType());
                driver.findElement(By.id("name" + position)).clear();
                driver.findElement(By.id("name" + position)).sendKeys(field.getFieldName());
                driver.findElement(By.id("start" + position)).clear();
                driver.findElement(By.id("start" + position)).sendKeys(field.getStartPos());
                driver.findElement(By.id("end" + position)).clear();
                driver.findElement(By.id("end" + position)).sendKeys(field.getEndPos());
            }

            if (null != field.getConstName())
            {
                // Add constant
                List<WebElement> list = driver.findElements(By.id("addField"));
                // Click the second addField button for constant
                list.get(1).click();
                driver.findElement(By.id("constName" + constCounter)).clear();
                driver.findElement(By.id("constName" + constCounter)).sendKeys(field.getConstName());
                driver.findElement(By.id("constValue" + constCounter)).clear();
                driver.findElement(By.id("constValue" + constCounter)).sendKeys(field.getConstValue());
                constCounter++;
            }

            // some reason second element start from 2
            //
            if (position == 0)
            {
                position++;
            }
            position++;
        }
        }

    }

    @Step("Search layout from existing process")
    private void searchLayoutFromOtherProject(String layoutName, String format, String projNum)
    {
        // Click on search button
        driver.findElement(By.id("layoutSearchButton")).click();
        driver.findElement(By.id("projnum")).clear();
        driver.findElement(By.id("projnum")).sendKeys(projNum);
        driver.findElement(By.id("search")).click();
        int i = 1;
        boolean flag = false;
        int noOfRows = getNumberOfRowsOtherProjectLayoutTable();

        while (flag == false && i <= noOfRows)
        {
            String str = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[" + i + "]/td[1]/label")).getText();
            if (str.equals(layoutName)) // Get from csv
            {
                flag = true;
                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[" + i + "]/td[1]/input")).click();
                break;
            }
            i++;
        }
        // Continue to input process screen
        driver.findElement(By.cssSelector("input.orange-btn")).click();

    }



}

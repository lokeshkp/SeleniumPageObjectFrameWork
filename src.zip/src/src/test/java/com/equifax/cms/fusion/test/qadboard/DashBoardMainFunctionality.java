package com.equifax.cms.fusion.test.qadboard;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.DBoardPages.DashBoardMainPage;
import com.equifax.cms.fusion.test.DBoardPages.ProjOrderDetailsPage;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Title;

public class DashBoardMainFunctionality {

	public static WebDriver driver = null;
	private CommonMethods commMethods;
	private ProjectDashBoardPage ProjDashBoardPage;
	private DashBoardMainPage DBoardMainPage;
	private ProjOrderDetailsPage PrOrderDetPage;

	@Title("User Login")
	@BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
	public void LoginandSearchProj() throws InterruptedException {
		// driver = FusionFirefoxDriver.getDriver();
		driver = FusionChromeDriver.getDriver();
		driver.manage().timeouts().implicitlyWait(120, TimeUnit.SECONDS);
		commMethods = PageFactory.initElements(driver, CommonMethods.class);
		ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
		DBoardMainPage = PageFactory.initElements(driver, DashBoardMainPage.class);
		PrOrderDetPage = PageFactory.initElements(driver, ProjOrderDetailsPage.class);
		commMethods.userLogin();
	}

	@Test(dataProvider = "dBoard_Y_Reg")
	public void selDBoardMainFunctionality(String tc_id, String testRun, String testcase, String desc, String workingAs,
			String projNum, String analyst, String primPrmer, String chckerPrmer, String status, String dataPump,
			ITestContext testContext) throws InterruptedException {
		DBoardMainPage.clickDashBoardTab();
		if ("DBR_ID_021".equalsIgnoreCase(tc_id)) {
			DBoardMainPage.selWorkingAs("Fulfillment Analyst");
			DBoardMainPage.listWorkingAs(workingAs);
		} else {
			DBoardMainPage.ProjNumFld(projNum);
			DBoardMainPage.clickImportBtn();
			if ("DBR_ID_001".equalsIgnoreCase(tc_id)) {
				PrOrderDetPage.clickContinueBtn();
				String errMsg = driver.findElement(By.xpath("(.//*[@id='textMsgFulfillmentDetail'])[1]")).getText()
						.trim();
				commMethods.verifyString(errMsg,
						"Error:Please Select Fulfillment Analyst.\nError:Please select Final shipped Date.");
			} else if ("DBR_ID_002".equalsIgnoreCase(tc_id)) {
				PrOrderDetPage.selAnalyst(analyst);
				PrOrderDetPage.selectDate();
				PrOrderDetPage.selPriProgrammer(primPrmer);
				PrOrderDetPage.selCheckerProgrammer(chckerPrmer);
				PrOrderDetPage.clickContinueBtn();
				String fulFillmentAnalyst = ProjDashBoardPage.fulfilmentAnalyst();
				commMethods.verifyString(fulFillmentAnalyst, analyst);
			} else if ("DBR_ID_005".equalsIgnoreCase(tc_id)) {
				PrOrderDetPage.TeamFld.clear();
				PrOrderDetPage.clickContinueBtn();
				String errMsg = driver.findElement(By.xpath("(.//*[@id='textMsgFulfillmentDetail'])[1]")).getText()
						.trim();
				commMethods.verifyString(errMsg,
						"Error:Please enter team values in between 0-9 and A-Z\nError:Please Select Fulfillment Analyst.\nError:Please select Final shipped Date.");
			} else if ("DBR_ID_006".equalsIgnoreCase(tc_id)) {
				String teamFld = PrOrderDetPage.TeamFld.getText();
				commMethods.verifyString(teamFld, "");
			} else if ("DBR_ID_014".equalsIgnoreCase(tc_id)) {
				WebElement familyCode = driver
						.findElement(By.xpath("//label[contains(text(),'Family Code:')]/following::td[1]"));
				commMethods.verifyboolean(familyCode.isDisplayed(), true);
			} else if ("DBR_ID_015".equalsIgnoreCase(tc_id)) {
				commMethods.verifyboolean(PrOrderDetPage.analystNames(analyst), true);
			} else if ("DBR_ID_011".equalsIgnoreCase(tc_id)) {
				PrOrderDetPage.selAuditDate();
			} else if ("DBR_ID_012".equalsIgnoreCase(tc_id)) {
				commMethods.verifyboolean(PrOrderDetPage.activeFlds(status), true);
			} else if ("DBR_ID_016".equalsIgnoreCase(tc_id)) {
				commMethods.verifyboolean(PrOrderDetPage.PurgeDays.isEnabled(), false);
				String value = PrOrderDetPage.PurgeDays.getAttribute("value");
				commMethods.verifyString(value, "90");
			} else if ("DBR_ID_018".equalsIgnoreCase(tc_id)) {
				commMethods.verifyboolean(PrOrderDetPage.ExecuteSite.isEnabled(), false);
				String siteValue = PrOrderDetPage.ExecuteSite.getAttribute("value");
				commMethods.verifyString(siteValue, "A");
			} else if ("DBR_ID_020".equalsIgnoreCase(tc_id)) {
				String value = PrOrderDetPage.DataPumpSeries.getAttribute("value");
				commMethods.verifyString(value, "1.0");
			}
		}
	}

	@DataProvider
	public Object[][] dBoard_Y_Reg() throws Exception {
		Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(
				System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "DashBoard", "Y");
		return testObjArray_Y;

	}

}

/*package com.equifax.cms.fusion.test;

import java.util.List;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.utils.ProcessOperationEnum;
import com.equifax.cms.fusion.test.vo.SMProcessInputVO;

import ru.yandex.qatools.allure.annotations.Features;
import ru.yandex.qatools.allure.annotations.Step;

//This is template test class
//can be used for templating/ modification purpose
@Features("You feature name ")
public class TemplateTest extends AbstractCoreTest {

	private static final Logger LOGGER = LoggerFactory.getLogger(TemplateTest.class);
	

	@Step("you step name or detailed description")
	@Test
	public void testTemplateProcess() throws Exception {

		LOGGER.debug("-- random nth -- ");
		// get input data for your process
		//List<SMProcessInputVO> list = reader.getSourceMatchInputData();

		userLogin();
		String projectNumber = reader.getTestProperties().get("PROJECT_NUMBER");
		searchProject(projectNumber);

		// list all the data available in excel
		/*for (SMProcessInputVO vo : list) {
			// Save source match process
			// Condition should be
			if (ProcessOperationEnum.VALIDATE.name().equalsIgnoreCase(vo.getOperation())) {
				doSomeTestOperaiton(vo.getProcessName(), vo);

			}
		}*/
		/*userLogout();
		LOGGER.debug("--  logout -- ");*/
/*	}

	@Step("do this step for the operation {0}")
	private void doSomeTestOperaiton(String processName, SMProcessInputVO vo) {
		// add input into report
		createAttachment(vo.toString());

	}
*/
/*}
*/
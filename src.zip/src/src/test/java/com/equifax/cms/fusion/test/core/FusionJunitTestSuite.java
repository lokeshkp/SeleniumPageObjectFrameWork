package com.equifax.cms.fusion.test.core;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.equifax.cms.fusion.test.sourcematch.SoureMatchTestCase;
import com.equifax.cms.fusion.test.sourcematch.SoureMatchValidationTest;
@RunWith(Suite.class)
@Suite.SuiteClasses({
		// InputAsciiFixedTest.class,
	SoureMatchTestCase.class,
	SoureMatchValidationTest.class
})
public class FusionJunitTestSuite {
}
package com.equifax.cms.fusion.test.input;

import org.junit.AfterClass;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.repository.OracleDBHelper;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class IPSearchLayoutTest extends AbstractMethodError
{
    private WebDriver driver;
    private StringBuffer verificationErrors = new StringBuffer();
	private static final Logger LOGGER = LoggerFactory.getLogger(IPSearchLayoutTest.class);
	private OracleDBHelper db;
    private static final String IP = "Input";
    private boolean acceptNextAlert = true;
    WebDriverWait wait;

  @Test
    public void searchLayout() throws Exception
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        module.userLogin();
        module.searchProject();
        module.navigateToProcess(IP);
        module.navigateToNewProcessPage("Import New File");
        driver.findElement(By.id("processName")).clear();
        driver.findElement(By.id("processName")).sendKeys("iptest-search");// Get from csv
        driver.findElement(By.id("filePath")).clear();
        driver.findElement(By.id("filePath")).sendKeys(PropertiesUtils.getProperty("ipFilePath"));// get from csv
        driver.findElement(By.id("recLen")).clear();
        driver.findElement(By.id("recLen")).sendKeys(PropertiesUtils.getProperty("ipReclen"));
        driver.findElement(By.id("gpSeqNumStartFrom")).clear();
        driver.findElement(By.id("gpSeqNumStartFrom")).sendKeys(PropertiesUtils.getProperty("ipSeqno"));
        driver.findElement(By.id("existingLayoutRadio")).click();
        driver.findElement(By.id("layoutSearchButton")).click();
        driver.findElement(By.id("projnum")).clear();
        driver.findElement(By.id("projnum")).sendKeys("6000005"); // get from csv
        driver.findElement(By.id("search")).click();

        int i = 1;
        boolean flag = false;
        while (flag == false && i < 100)
        {
            String str = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[" + i + "]/td[1]/label")).getText();
            if (str.equals("test_layout_1101")) // Get from csv
            {
                flag = true;

                // Gets the radio button that is closest to the layout to be selected
                driver.findElement(By.xpath("//table[@id='savedLayoutsTable']/tbody/tr[" + i + "]/td[1]/input")).click();
                break;
            }
            i++;
        }

        /*
         * for (int second = 0;; second++) { if (second >= 30) fail("timeout"); try { if (isElementPresent(By.id("layout_3188"))) break; } catch
         * (Exception e) { System.out.println(e); } try { Thread.sleep(1000); } catch (InterruptedException e) { // TODO Auto-generated catch block
         * e.printStackTrace(); } }
         */
        driver.findElement(By.cssSelector("input.orange-btn")).click();

        // driver.findElement(By.xpath("//table('@id='DataTables_Table_0')/tbody/tr[5]/td[1]/label")) // get from csv
        driver.findElement(By.id("submitLayout")).click();

        module.selectSubmit();

        // Due to big time lag let thread sleep for 1minute so that it reaches the next screen
        Thread.sleep(60000);

        driver.findElement(By.id("submitButton")).click();
  }
  
	@AfterClass
	public void destroy() {
		
		if ( null != driver)  {
			driver.quit();
		}
	}

}

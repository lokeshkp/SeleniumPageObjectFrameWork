package com.equifax.cms.fusion.test.qash;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map.Entry;
import java.util.concurrent.TimeUnit;

import org.apache.commons.collections.CollectionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Description;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.FFFPages.DataProcessingTab;
import com.equifax.cms.fusion.test.FFFPages.FFFStatsView;
import com.equifax.cms.fusion.test.OPPages.OpHomePage;
import com.equifax.cms.fusion.test.OPPages.OpSummaryPage;
import com.equifax.cms.fusion.test.SHPages.QCProjectPage;
import com.equifax.cms.fusion.test.SHPages.ShippingHomePage;
import com.equifax.cms.fusion.test.SHPages.ShippingPage;
import com.equifax.cms.fusion.test.SHPages.ShippingStats;
import com.equifax.cms.fusion.test.SHPages.ShippingSummaryPage;
import com.equifax.cms.fusion.test.STPages.JobStackingPage;
import com.equifax.cms.fusion.test.STPages.StackingPage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qaop.OutputProcess;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class ShippingProcess
{
    private static final Logger LOGGER = LoggerFactory.getLogger(ShippingProcess.class);
    public WebDriver driver = null;
    private Modules module;
    private ShippingHomePage shHomePage;
    private ShippingPage shPage;
    private CommonMethods commMethods;
    private ShippingSummaryPage shSumPage;
    private QCProjectPage qcPage;
    private ProjectDashBoardPage ProjDashBoardPage;
    private StackingPage stackingPage;
    private JobStackingPage jobStackingPage;
    private OpHomePage opHPage;
    private OpSummaryPage opSumPage;
    private ShippingStats shStats;
    private OutputProcess opProcess;
    private DataProcessingTab dpHomePage;
    private FFFStatsView fffStatsView;

    @Title("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
        //driver = FusionFirefoxDriver.getDriver();
    	
        driver = FusionChromeDriver.getDriver();
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
        module = new Modules();
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        shPage = PageFactory.initElements(driver, ShippingPage.class);
        shHomePage = PageFactory.initElements(driver, ShippingHomePage.class);
        shSumPage = PageFactory.initElements(driver, ShippingSummaryPage.class);
        shStats = PageFactory.initElements(driver, ShippingStats.class);
        qcPage = PageFactory.initElements(driver, QCProjectPage.class);
        stackingPage = PageFactory.initElements(driver, StackingPage.class);
        jobStackingPage = PageFactory.initElements(driver, JobStackingPage.class);
        opHPage = PageFactory.initElements(driver, OpHomePage.class);
        opSumPage = PageFactory.initElements(driver, OpSummaryPage.class);
        opProcess = PageFactory.initElements(driver, OutputProcess.class);
        fffStatsView = PageFactory.initElements(driver, FFFStatsView.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Title("Shipping Process Regression Test")
    @Description("Shipping Process end to end testing")
    @Test(dataProvider = "sh_Reg")
    public void shStatsVerification(String tc_Id, String testRun, String TC, String Description,String copyProject, String copyProcess,String projectName, String processName,String selPurpose,
    		String runType,String inputType,String reportOnly,String process, String job, String shFiles, String rawCount, String delType,String hostORscriptFile, 
    		String schId,String delFileName, String recEmailAdd, String emailSub, String emailBody,String process_2, String job_2, String shFiles_2, String hostORscriptFile2,
    		String procNameForStack, String deliveryFileNamesForJob2, String futureDate, String ProcessesForStack, String ProjNum ,ITestContext testContext) throws Exception
    {
        String status = null;
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        
        shHomePage.clickShippingHomeTab();
        shHomePage.clickShippingProcess();
        if ("SH_ID_164".equalsIgnoreCase(tc_Id))
        {
            shPage.rawNamesCount(rawCount);
            shPage.clickSubmitButton();
            // String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Please enter the Process Name.");
            shPage.selectPurposeRB(selPurpose);
            shPage.selectInputType(inputType);
            shPage.selectProcess(process);
            shPage.selectJob(job);
            shPage.selectShippedFiles(shFiles);
            shPage.clickAddButton();
            shPage.clickSubmitButton();

            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Shipped date is required.");
            shPage.selectDate();
            shPage.selectProcess("Select");
            shPage.clickSubmitButton();
            // errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
            // commMethods.verifyString(errMsg, "Please select process.");
            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Please select process.");

            shPage.selectProcess(selPurpose);
            shPage.clickSubmitButton();
            /*
             * errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText(); commMethods.verifyString(errMsg, "Please select job.");
             */
            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Please select job.");
            shPage.selectJob(job);
            shPage.rawNamesCount_Field.clear();
            shPage.clickSubmitButton();

            /*
             * errMsg = driver.findElement(By.xpath(".//*[@id='shpForm']/div[1]/span[2]/li/label")).getText(); commMethods.verifyString(errMsg,
             * "Raw Names Count is required.");
             */
            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Raw Names Count is required.");
            shPage.rawNamesCount(rawCount);
            shPage.clickRemoveIcon();
            shPage.clickSubmitButton();
            /*
             * errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText(); commMethods.verifyString(errMsg,
             * "Please select atleast one artifact.");
             */
            commMethods.verifyString(shPage.fetchTheErrorMessage(), "Error: Please select at least one artifact.");

            shPage.selectShippedFiles(shFiles);
            shPage.clickSubmitButton();
            /*
             * errMsg = driver.findElement(By.xpath(".//*[@id='inqForm']/div[1]/span[2]/li/label")).getText(); commMethods.verifyString(errMsg,
             * "Please select atleast one artifact.");
             */

        } else
        {
            String processName1 = commMethods.getFinalProcessName();
            shPage.inputProcessName(processName);
            String procId = commMethods.getProcId();
            shPage.selectPurposeRB(selPurpose);
            shPage.selectInputType(inputType);
            if ("SH_ID_044".equalsIgnoreCase(tc_Id) || "SH_ID_053".equalsIgnoreCase(tc_Id))
            {
                shPage.firstProc(process);
                shPage.selFirstSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                shPage.secondProc(process);
                shPage.selSecSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.selectDeliveryType("Connect Direct");
                shPage.inputScriptFilePath("/nas/dropzone/TechSupport/bart/FUSIONCD.cd");
                shPage.clickSavePopUp();
                shPage.clickSaveButton();

                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                shHomePage.clickShippingHomeTab();
                status = commMethods.getProcessStatus();
               // commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = commMethods.getProcessStatus();
                //commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();

                String Status = ProjDashBoardPage.verifyProcess(processName1);
                commMethods.verifyString(Status, "PASS");
                /*
                 * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click(); Thread.sleep(2000);
                 * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
                 * Thread.sleep(2000); String shp_sftp = driver .findElement( By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'SHP_SFTP')]")) .getText().trim(); commMethods.verifyString(shp_sftp,
                 * "SHP_SFTP"); String shp_accounting = driver .findElement( By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'SHP_ACCOUNTING')]")).getText().trim();
                 * commMethods.verifyString(shp_accounting, "SHP_ACCOUNTING"); String shp_directconnect = driver .findElement(
                 * By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[4]/td[contains(text(),'SHP_DIRECTCONNECT')]")).getText().trim();
                 * commMethods.verifyString(shp_directconnect, "SHP_DIRECTCONNECT"); String shp_accounting2 = driver .findElement(
                 * By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[5]/td[contains(text(),'SHP_ACCOUNTING')]")).getText().trim();
                 * commMethods.verifyString(shp_accounting2, "SHP_ACCOUNTING"); ProjDashBoardPage.clickStatsView(processName1); //
                 * driver.switchTo().frame("sb-player");
                 */
            } else if ("SH_ID_047".equalsIgnoreCase(tc_Id) || "SH_ID_055".equalsIgnoreCase(tc_Id))
            {
                shPage.firstProc(process);
                shPage.selFirstSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                shPage.secondProc(process);
                shPage.selSecSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.selectDeliveryType("Other");
                shPage.provideDelFileNames("xyz");
                shPage.clickSavePopUp();
                shPage.clickSaveButton();
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                shHomePage.clickShippingHomeTab();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();

                String Status = ProjDashBoardPage.verifyProcess(processName1);
                commMethods.verifyString(Status, "PASS");
                /*
                 * qcPage.approvesTheShippinginQC1(); shHomePage.clickShippingHomeTab(); status = commMethods.getProcessStatus();
                 * commMethods.verifyString(status.trim(), StatusEnum.READY.name()); module.initializeDriver(driver); module.selectSummary();
                 * shSumPage.clickSubmitButton(); status = commMethods.getProcessStatus(); commMethods.verifyString(status.trim(),
                 * StatusEnum.SUBMITTED.name()); ProjDashBoardPage.clickHomeTab(); String ProcessName1 = ProjDashBoardPage.jobName(); String Status =
                 * ProjDashBoardPage.verifyProcess(ProcessName1); commMethods.verifyString(Status, "PASS");
                 * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click(); Thread.sleep(2000);
                 * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")).click();
                 * Thread.sleep(2000); String shp_sftp = driver .findElement( By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'SHP_SFTP')]")) .getText().trim(); commMethods.verifyString(shp_sftp,
                 * "SHP_SFTP"); String shp_accounting = driver .findElement( By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'SHP_ACCOUNTING')]")).getText().trim();
                 * commMethods.verifyString(shp_accounting, "SHP_ACCOUNTING"); String shp_other = driver .findElement(
                 * By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr[1]//following::tr[4]/td[contains(text(),'SHP_OTHER')]"))
                 * .getText().trim(); commMethods.verifyString(shp_other, "SHP_OTHER"); String shp_accounting2 = driver .findElement(
                 * By.xpath("//td[contains(text(),'" + procId +
                 * "')]//parent::tr[1]//following::tr[5]/td[contains(text(),'SHP_ACCOUNTING')]")).getText().trim();
                 * commMethods.verifyString(shp_accounting2, "SHP_ACCOUNTING"); ProjDashBoardPage.clickStatsView(processName1);
                 * driver.switchTo().frame("sb-player");
                 */
            } else if ("SH_ID_065".equalsIgnoreCase(tc_Id))
            {
                shPage.firstProc(process);
                shPage.selFirstSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                shPage.secondProc(process);
                shPage.selSecSplitShFiles(shFiles);
                shPage.clickAddButton();
                shPage.selectDeliveryType("Other");
                shPage.provideDelFileNames("xyz");
                shPage.clickSavePopUp();
                shPage.clickSaveButton();
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                shHomePage.clickShippingHomeTab();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                // ProjDashBoardPage.clickHomeTab();
                // qcPage.approvesTheShippinginQC1();
                shHomePage.clickShippingHomeTab();
                // status = commMethods.getProcessStatus();
                // commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                module.initializeDriver(driver);
                module.selectDuplicate();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(StatusEnum.READY.name(), status.trim());
                module.clickOnEdit();
                shPage.clickRemoveIcon();
                shPage.clickSubmitButton();
                String errMsg = driver.findElement(By.xpath("//div[@class='errMsgSrcMatch']")).getText();
                commMethods
                        .verifyboolean(
                                errMsg.startsWith("The following QC items are pending approval or rejected. All QC items must be approved before Shipping is permitted."),
                                true);
                shPage.clickSaveButton();
                String shpId2 = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove2 = commMethods.getProcessListToApproveInQC(shpId2);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove2);
                shHomePage.clickShippingHomeTab();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = commMethods.getProcessStatus();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
            } else
            {
                shPage.selectProcess(process);
                shPage.selectJob(job);
                shPage.rawNamesCount(rawCount);
                if ("SH_ID_025".equalsIgnoreCase(tc_Id) || "SH_ID_111".equalsIgnoreCase(tc_Id))
                {
                    String shipFileName = driver.findElement(By.xpath("//label[contains(text(),'" + shFiles + "')]")).getText();
                   Assert.assertTrue(shipFileName.contains(shFiles));
                } else if ("SH_ID_067".equalsIgnoreCase(tc_Id))
                {
                    String shipFileName = driver.findElement(By.xpath("//label[contains(text(),'" + shFiles + "')]")).getText();
                    Assert.assertTrue(shipFileName.contains(shFiles));
                    shPage.deliverFilesOnly_RB.click();
                    shipFileName = driver.findElement(By.xpath("//label[contains(text(),'" + shFiles + "')]")).getText();
                    Assert.assertTrue(shipFileName.contains(shFiles));
                } else if ("SH_ID_042".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickSaveButton();
                    Thread.sleep(2500);
                    shHomePage.clickShippingHomeTab();
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(status.trim(), StatusEnum.ERROR.name());
                } else
                {
                    Thread.sleep(5000);
                    shPage.selectShippedFiles(shFiles);
                    if ("PS_Only".equalsIgnoreCase(selPurpose))
                    {
                        shPage.selectDate();
                        Thread.sleep(2000);
                        shPage.clickAddButtonForPostShipmentToProjectTrackingOnly();
                    } else
                    {
                        shPage.clickAddButton();
                    }
                    if ("SH_ID_076".equalsIgnoreCase(tc_Id))
                    {
                        shPage.selectPurposeRB("DF_Only");
                        driver.findElement(By.xpath(".//*[@id='row1_1']/td[1]/img")).click();
                        Thread.sleep(2000);
                        String delDetailsTitle = driver.findElement(By.xpath("(//h3[@class='fusion-h3Title'])[2]")).getText();
                        commMethods.verifyString(delDetailsTitle, "Shipping Files Delivery Details Specify the delivery details of shipping files.");
                    } else if ("SH_ID_077".equalsIgnoreCase(tc_Id))
                    {
                        shPage.selectPurposeRB("DF_PS");
                        driver.findElement(By.xpath(".//*[@id='row1_1']/td[1]/img")).click();
                        Thread.sleep(2000);
                        String delDetailsTitle = driver.findElement(By.xpath("(//h3[@class='fusion-h3Title'])[2]")).getText();
                        commMethods.verifyString(delDetailsTitle, "Shipping Files Delivery Details Specify the delivery details of shipping files.");
                    } else if ("SH_ID_071".equalsIgnoreCase(tc_Id))
                    {
                        shPage.selectDeliveryType(delType);
                        shPage.inputScriptFilePath(hostORscriptFile);
                        String fileName = driver.findElement(By.xpath(".//*[@id='custFileName1']")).getAttribute("readonly");
                        Assert.assertNotNull(fileName);
                    } else
                    {
                        shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                        if ("SH_ID_133".equalsIgnoreCase(tc_Id))
                        {
                            String fileName = driver.findElement(By.xpath("//span[contains(text(),'" + shFiles + "')]")).getText();
                            commMethods.verifyString(fileName, shFiles);
                        } else if ("SH_ID_106".equalsIgnoreCase(tc_Id))
                        {
                            shPage.selectInputType("PREDICTED_INPUT");
                            String alertMsg = driver.findElement(By.xpath(".//*[@id='sb-player']/div/h1")).getText();
                            commMethods.verifyString(alertMsg,
                                    "All existing files configured for Delivery/Accounting will be removed.\nAre you sure you wish to continue?");
                            driver.findElement(By.xpath(".//*[@id='sb-nav-close']")).click();
                            String pageTitle = driver.findElement(By.xpath("(//h3[@class='fusion-h3Title'])[1]")).getText();
                            commMethods.verifyString(pageTitle, "Shipping Enter in the Information below, and then click 'Save' or 'Submit'.");
                        } else if ("SH_ID_072".equalsIgnoreCase(tc_Id))
                        {
                            String alertMsg = driver.switchTo().alert().getText();
                            commMethods.verifyString(alertMsg, "Please provide a valid value for Delivery File Names field.");
                            driver.switchTo().alert().accept();
                        } else if ("SH_ID_069".equalsIgnoreCase(tc_Id))
                        {
                            shPage.clickSubmitButton();
                            String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                            commMethods.verifyboolean(errMsg.endsWith("are not allowed."), true);
                        } else if ("SH_ID_059".equalsIgnoreCase(tc_Id))
                        {
                            shPage.clickRemoveIcon();
                            try
                            {
                                WebElement fileIngrid = driver.findElement(By.xpath("(//span[contains(text(),'" + shFiles + "')])[1]"));
                                commMethods.verifyboolean(fileIngrid.isDisplayed(), false);
                            } catch (org.openqa.selenium.NoSuchElementException e)
                            {
                                System.out.println("Element not displayed..");
                            }
                        } else if ("SH_ID_060".equalsIgnoreCase(tc_Id))
                        {
                            shPage.clickRemoveIcon();
                            shPage.clickSaveButton();
                            qcPage.approvesTheShippinginQC1();
                            shHomePage.clickShippingHomeTab();
                            status = commMethods.getProcessStatus();
                            commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                            module.initializeDriver(driver);
                            module.selectSummary();
                            shSumPage.clickSubmitButton();
                            status = commMethods.getProcessStatus();
                            commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                            ProjDashBoardPage.clickHomeTab();
                            String ProcessName1 = ProjDashBoardPage.jobName();
                            String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                            commMethods.verifyString(Status, "PASS");
                            ProjDashBoardPage.clickStatsView(processName1);
                            driver.switchTo().frame("sb-player");
                            try
                            {
                                WebElement fileInStats = driver.findElement(By
                                        .xpath("//div[contains(text(),'File Name')]//following::div[contains(text(),'" + shPage.splitShFile(shFiles)
                                                + "')]"));
                                commMethods.verifyboolean(fileInStats.isDisplayed(), false);
                            } catch (org.openqa.selenium.NoSuchElementException e)
                            {
                                System.out.println("Element Not Present in Stats !!!");
                            }
                        } else if ("SH_DF_1483".equalsIgnoreCase(tc_Id))
                        {
                            shPage.clickSaveButton();
                            // shPage.selRunType("TAS");
                            shPage.clickSubmitButton();
                            Thread.sleep(3000);
                            String errMsg = driver.findElement(By.xpath("//div[@class='errMsgSrcMatch']")).getText().trim();
                            commMethods
                                    .verifyboolean(
                                            errMsg.startsWith("The following QC items are pending approval or rejected. All QC items must be approved before Shipping is permitted."),
                                            true);
                        } else
                        {
                            shPage.clickSaveButton();
                            if ("SH_ID_003".equalsIgnoreCase(tc_Id))
                            {
                               commMethods.verifyString("Enter in the Information below, and then click 'Save' or 'Submit'.",driver.findElement(By.xpath("//h3[@class='fusion-h3Title']//span")).getText());
                               // shSumPage.clickSubmitButton();
                            } else if ("SH_ID_039".equalsIgnoreCase(tc_Id) || "SH_ID_211".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_212".equalsIgnoreCase(tc_Id) || "SH_ID_213".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_214".equalsIgnoreCase(tc_Id) || "SH_ID_215".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_216".equalsIgnoreCase(tc_Id) || "SH_ID_217".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_218".equalsIgnoreCase(tc_Id) || "SH_ID_220".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_221".equalsIgnoreCase(tc_Id) || "SH_ID_222".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_223".equalsIgnoreCase(tc_Id) || "SH_ID_224".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_225".equalsIgnoreCase(tc_Id) || "SH_ID_226".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_227".equalsIgnoreCase(tc_Id) || "SH_ID_228".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_229".equalsIgnoreCase(tc_Id) || "SH_ID_230".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_231".equalsIgnoreCase(tc_Id) || "SH_ID_232".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_233".equalsIgnoreCase(tc_Id) || "SH_ID_234".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_235".equalsIgnoreCase(tc_Id) || "SH_ID_236".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_237".equalsIgnoreCase(tc_Id) || "SH_ID_238".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_239".equalsIgnoreCase(tc_Id) || "SH_ID_240".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_241".equalsIgnoreCase(tc_Id) || "SH_ID_242".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_243".equalsIgnoreCase(tc_Id) || "SH_ID_244".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_245".equalsIgnoreCase(tc_Id) || "SH_ID_246".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_193".equalsIgnoreCase(tc_Id) || "SH_ID_194".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_195".equalsIgnoreCase(tc_Id) || "SH_ID_196".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_197".equalsIgnoreCase(tc_Id) || "SH_ID_198".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_199".equalsIgnoreCase(tc_Id) || "SH_ID_200".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_201".equalsIgnoreCase(tc_Id) || "SH_ID_202".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_203".equalsIgnoreCase(tc_Id) || "SH_ID_204".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_205".equalsIgnoreCase(tc_Id) || "SH_ID_206".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_207".equalsIgnoreCase(tc_Id) || "SH_ID_208".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_209".equalsIgnoreCase(tc_Id) || "SH_ID_210".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_179".equalsIgnoreCase(tc_Id) || "SH_ID_180".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_181".equalsIgnoreCase(tc_Id) || "SH_ID_182".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_183".equalsIgnoreCase(tc_Id) || "SH_ID_184".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_185".equalsIgnoreCase(tc_Id) || "SH_ID_186".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_187".equalsIgnoreCase(tc_Id) || "SH_ID_188".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_189".equalsIgnoreCase(tc_Id) || "SH_ID_190".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_191".equalsIgnoreCase(tc_Id) || "SH_ID_192".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_175".equalsIgnoreCase(tc_Id)||"SH_ID_176".equalsIgnoreCase(tc_Id)
                                    ||"SH_ID_177".equalsIgnoreCase(tc_Id)||"SH_ID_178".equalsIgnoreCase(tc_Id))
                            {

                            	 shPage.clickSaveButton();
                                 Thread.sleep(2500);

                                 String shpId = commMethods.getShippingProcessId(processName1, processName);
                                 List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                                 qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                              
                                Thread.sleep(1000);
                                shHomePage.clickShippingHomeTab();
                                Thread.sleep(3000);
                                commMethods.handleAlert();
                                Thread.sleep(2000);                                
                                module.initializeDriver(driver);
                                module.selectSummary();
                                shSumPage.clickSubmitButton();
                                Thread.sleep(2000);
                                commMethods.handleAlert();
                                Thread.sleep(2000);
                                status = shHomePage.getStatusSH();
                                Thread.sleep(2000);
                                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                                Thread.sleep(3000);
                                ProjDashBoardPage.clickHomeTab();
                                String Status = ProjDashBoardPage.verifyProcess(processName1);
                                commMethods.verifyString(Status, "PASS");
                            } else if ("SH_ID_014".equalsIgnoreCase(tc_Id) || "SH_ID_015".equalsIgnoreCase(tc_Id)
                                    || "SH_ID_016".equalsIgnoreCase(tc_Id))
                            {
                            	 shPage.clickSaveButton();
                                 Thread.sleep(2500);

                                 String shpId = commMethods.getShippingProcessId(processName1, processName);
                                 List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                                 qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                              
                                Thread.sleep(1000);
                                shHomePage.clickShippingHomeTab();
                                Thread.sleep(1000);
                                module.initializeDriver(driver);
                                module.selectSummary();
                                shSumPage.clickSubmitButton();
                                Thread.sleep(1000);
                                status = shHomePage.getStatusSH();
                                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                                Thread.sleep(3000);
                                ProjDashBoardPage.clickHomeTab();
                                //commMethods.searchProcessOnDashboardAndViewStats(processName1);
                                Thread.sleep(1500);

                                List<String> workItemNameList = shStats.getTheCountandNamesOfWorkItem(procId, processName);
                                for (String workItem : workItemNameList)
                                {
                                    if ("SH_ID_014".equalsIgnoreCase(tc_Id))
                                    {
                                        Assert.assertTrue(workItem.equalsIgnoreCase("SHP_ACCOUNTING") || workItem.equalsIgnoreCase("SHP_SFTP"));
                                    }
                                    if ("SH_ID_015".equalsIgnoreCase(tc_Id))
                                    {
                                        Assert.assertTrue(workItem.equalsIgnoreCase("SHP_ACCOUNTING")
                                                || workItem.equalsIgnoreCase("SHP_DIRECTCONNECT"));
                                    }
                                    if ("SH_ID_016".equalsIgnoreCase(tc_Id))
                                    {
                                        Assert.assertTrue(workItem.equalsIgnoreCase("SHP_ACCOUNTING") || workItem.equalsIgnoreCase("SHP_OTHER"));
                                    }
                                }
                            }
                            /*
                             * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click();
                             * Thread.sleep(2000); driver.findElement(By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[1]/td[3]/img")) .click(); Thread.sleep(2000); String shp_sftp = driver .findElement(
                             * By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'SHP_SFTP')]")).getText().trim();
                             * commMethods.verifyString(shp_sftp, "SHP_SFTP"); String shp_accounting = driver .findElement(
                             * By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'SHP_ACCOUNTING')]")).getText() .trim();
                             * commMethods.verifyString(shp_accounting, "SHP_ACCOUNTING");
                             */
                            /*
                             * } else if ("SH_ID_015".equalsIgnoreCase(tc_Id)) { qcPage.approvesTheShippinginQC1(); shHomePage.clickShippingHomeTab();
                             * module.initializeDriver(driver); module.selectSummary(); shSumPage.clickSubmitButton(); status =
                             * shHomePage.getStatusSH(); commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                             * ProjDashBoardPage.clickHomeTab(); String ProcessName1 = ProjDashBoardPage.jobName(); String Status =
                             * ProjDashBoardPage.verifyProcess(ProcessName1); commMethods.verifyString(Status, "PASS");
                             * driver.findElement(By.xpath("//td[contains(text(),'" + procId + "')]//parent::tr/td[2]/img")).click();
                             * Thread.sleep(2000); driver.findElement(By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[1]/td[3]/img")) .click(); Thread.sleep(2000); String shp_directconnect = driver
                             * .findElement( By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'SHP_DIRECTCONNECT')]")).getText() .trim();
                             * commMethods.verifyString(shp_directconnect, "SHP_DIRECTCONNECT"); String shp_accounting = driver .findElement(
                             * By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'SHP_ACCOUNTING')]")).getText() .trim();
                             * commMethods.verifyString(shp_accounting, "SHP_ACCOUNTING"); } else if ("SH_ID_016".equalsIgnoreCase(tc_Id)) {
                             * qcPage.approvesTheShippinginQC1(); shHomePage.clickShippingHomeTab(); module.initializeDriver(driver);
                             * module.selectSummary(); shSumPage.clickSubmitButton(); status = shHomePage.getStatusSH();
                             * commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name()); ProjDashBoardPage.clickHomeTab(); String
                             * ProcessName1 = ProjDashBoardPage.jobName(); String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                             * commMethods.verifyString(Status, "PASS"); driver.findElement(By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr/td[2]/img")).click(); Thread.sleep(2000); driver.findElement(By.xpath("//td[contains(text(),'" +
                             * procId + "')]//parent::tr[1]//following::tr[1]/td[3]/img")) .click(); Thread.sleep(2000); String shp_other = driver
                             * .findElement( By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[2]/td[contains(text(),'SHP_OTHER')]")).getText().trim();
                             * commMethods.verifyString(shp_other, "SHP_OTHER"); String shp_accounting = driver .findElement(
                             * By.xpath("//td[contains(text(),'" + procId +
                             * "')]//parent::tr[1]//following::tr[3]/td[contains(text(),'SHP_ACCOUNTING')]")).getText() .trim();
                             * commMethods.verifyString(shp_accounting, "SHP_ACCOUNTING"); }
                             */else
                            {
                                shPage.selectPurposeRB(selPurpose);
                                if ("DF_PS".equalsIgnoreCase(selPurpose))
                                {
                                    if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
                                    {
                                        /*
                                         * shPage.clickPredictInput(); shPage.selectDate(); if ("CHECK".equalsIgnoreCase (reportOnly)) {
                                         * shPage.rawNamesCountForReportOnly (rawCount); } else { shPage.selectProcess(process);
                                         * shPage.selectShippedFiles(shFiles); shPage.clickAddButton(); shPage.shipFilesDeliveryDetls (delType,
                                         * hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody); }
                                         */} else if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
                                    {
                                        /*
                                         * shPage.clickCompletedJob(); shPage.selectDate(); if ("CHECK".equalsIgnoreCase (reportOnly)) {
                                         * shPage.rawNamesCountForReportOnly (rawCount); } else { shPage.selectProcess(process);
                                         * shPage.selectJob(job); shPage.selectShippedFiles(shFiles); shPage.rawNamesCount(rawCount);
                                         * shPage.clickAddButton(); shPage.shipFilesDeliveryDetls (delType, hostORscriptFile, schId, delFileName,
                                         * recEmailAdd, emailSub, emailBody); }
                                         */} else
                                    {
                                        System.out.println("Select proper value in the Input Sheet !!!");
                                    }
                                } else if ("DF_Only".equalsIgnoreCase(selPurpose))
                                {
                                    if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
                                    {
                                        shPage.clickPredictInput();
                                        shPage.selectProcess(process);
                                        shPage.selectShippedFiles(shFiles);
                                        shPage.clickAddButton();
                                        shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                                    } else if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
                                    {
                                        shPage.clickCompletedJob();
                                        shPage.selectDate();
                                        shPage.selectProcess(process);
                                        shPage.selectJob(job);
                                        shPage.selectShippedFiles(shFiles);
                                        shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                                    }
                                } else if ("PS_Only".equalsIgnoreCase(selPurpose))
                                {
                                    if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
                                    {
                                        /*
                                         * shPage.clickPredictInput(); shPage.selectDate(); if ("CHECK".equalsIgnoreCase (reportOnly)) {
                                         * shPage.rawNamesCountForReportOnly (rawCount); } else { shPage.selectProcess(process);
                                         * shPage.selectShippedFiles(shFiles); shPage.clickAddButton(); }
                                         */} else if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
                                    {
                                        /*
                                         * shPage.clickCompletedJob(); shPage.selectDate(); if ("CHECK".equalsIgnoreCase (reportOnly)) {
                                         * shPage.rawNamesCountForReportOnly (rawCount); } else { shPage.selectProcess(process);
                                         * shPage.selectJob(job); shPage.selectShippedFiles(shFiles); shPage.rawNamesCount(rawCount); }
                                         */}
                                } else
                                {
                                    shPage.clickSubmitButton();
                                    if ("SH_DF_1439".equalsIgnoreCase(tc_Id))
                                    {
                                        String errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                                        commMethods.verifyboolean(errMsg.endsWith("do not exist."), true);
                                        errMsg = driver.findElement(By.xpath(".//*[@id='textMsg']")).getText();
                                        commMethods.verifyboolean(errMsg.startsWith("Error : Job run details for Input Process"), true);
                                    } else
                                    {
                                        String errMsg = driver.findElement(By.xpath("html/body/div[1]/div[3]/div[3]/div/form/div[2]")).getText();
                                        if (errMsg != null)
                                        {
                                            ProjDashBoardPage.clickOutputTab();
                                            String getOPprocNam = driver.findElement(
                                                    By.xpath(".//*[@id='outputTable_wrapper']/div[2]/div[2]/table/tbody/tr/td[contains(text(),'"
                                                            + process + "')]//following::td[1]")).getText();
                                            if ("READY".equalsIgnoreCase(getOPprocNam))
                                            {
                                                opHPage.selectSummaryOP();
                                                opSumPage.clickSubmitButton();
                                                status = opHPage.GetStatusOP();
                                                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                                            }
                                            qcPage.approvesTheShippinginQC();
                                            shHomePage.clickShippingHomeTab();
                                            status = commMethods.getProcessStatus();
                                            commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                                            module.selectSummary();
                                            shSumPage.clickSubmitButton();
                                        } else if (errMsg.startsWith("The following QC items are pending approval or rejected"))
                                        {
                                            qcPage.approvesTheShippinginQC();
                                            shHomePage.clickShippingHomeTab();
                                            status = commMethods.getProcessStatus();
                                            commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                                            module.selectSummary();
                                            shSumPage.clickSubmitButton();
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    @Title("Shipping Process Regression Testing")
    @Description("Shipping Process Testing")
    @Test(dataProvider = "sh_CBA_Reg")
    public void shippingVerification(String tc_Id, String testRun, String TC, String Description,String copyProject, String copyProcess,String projectName, String processName,String selPurpose,
    		String runType,String inputType,String reportOnly,String process, String job, String shFiles, String rawCount, String delType,String hostORscriptFile, 
    		String schId,String delFileName, String recEmailAdd, String emailSub, String emailBody,String process_2, String job_2, String shFiles_2, String hostORscriptFile2,
    		String procNameForStack, String deliveryFileNamesForJob2, String futureDate, String ProcessesForStack, String ProjNum ,ITestContext testContext) throws Exception
    {
        String status = null;
        /* testContext.setAttribute("WebDriver",driver); */
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        shHomePage.clickShippingHomeTab();
        Thread.sleep(2000);
        shHomePage.clickShippingProcess();
        Thread.sleep(5000);
        String processName1 = commMethods.getFinalProcessName();
        shPage.inputProcessName(processName);
        if ("SH_ID_023".equalsIgnoreCase(tc_Id))
        {
            shPage.clearProcessName();
        }
        String procId = commMethods.getProcId();

        shPage.selectPurposeRB(selPurpose);
        Thread.sleep(4000);
        if ("SH_ID_079".equalsIgnoreCase(tc_Id))
        {
            List<String> inputTypeList = shPage.getTheTypeOfInputSelected(inputType);
            if (CollectionUtils.isNotEmpty(inputTypeList))
            {

                String NameOfTheButton = inputTypeList.get(0);
                String TypeOfTheButton = inputTypeList.get(1);
                commMethods.verifyString("Use Predicted Input", NameOfTheButton);
                commMethods.verifyString("radio", TypeOfTheButton);
            }

        }
        if ("LiveProduction".equalsIgnoreCase(runType))
        {
            Thread.sleep(2000);
            shPage.clickLiveProduction();
        } else if ("TestAutomation".equalsIgnoreCase(runType))
        {
            Thread.sleep(2000);
            shPage.clickTestAutomation();
        }
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            shPage.clickPredictInput();
            Thread.sleep(4000);
            if ("SH_ID_081".equalsIgnoreCase(tc_Id) || "SH_ID_099".equalsIgnoreCase(tc_Id))
            {

                String css_Value_for_Job_Id = shPage.getTheCssValueForJobId();
                commMethods.verifyString("none", css_Value_for_Job_Id);
                String css_Value_for_raw_count = shPage.getTheCssValueForRawNameCount();
                commMethods.verifyString("none", css_Value_for_raw_count);
            } else if ("SH_ID_097".equalsIgnoreCase(tc_Id))
            {
                String css_Value_for_Job_Id_fr_Predicted_Input = shPage.getTheCssValueForJobId();
                Assert.assertTrue("none".equalsIgnoreCase(css_Value_for_Job_Id_fr_Predicted_Input));
                shPage.clickCompletedJob();
                String css_Value_for_Job_Id_fr_CompletedInput = shPage.getTheCssValueForJobId();
                Assert.assertTrue("inline-block".equalsIgnoreCase(css_Value_for_Job_Id_fr_CompletedInput));
                shPage.clickPredictInput();
            }
            Thread.sleep(3000);
        }
        Thread.sleep(4000);

        shPage.selectProcess(process);
        Thread.sleep(4000);
        if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            shPage.selectJob(job);
            if (!"DF_Only".equalsIgnoreCase(selPurpose))
            {
                shPage.rawNamesCount(rawCount);
            }
        } else if ("SH_ID_093".equalsIgnoreCase(tc_Id) || "SH_ID_096".equalsIgnoreCase(tc_Id) || "SH_ID_098".equalsIgnoreCase(tc_Id))
        {
            List<WebElement> shippedFileList = shPage.getListOfShippedFiles();
            int RowCount = shippedFileList.size();
            Assert.assertTrue(RowCount == 4);
            for (int i = 0; i < RowCount; i++)
            {
                String nameOfShippedFiles = shippedFileList.get(i).getText();
                String[] ShippedFilesArr = nameOfShippedFiles.split("\\.");
                Assert.assertTrue(ShippedFilesArr[0].endsWith("_##"));
                LOGGER.info("name of the files shipped -" + nameOfShippedFiles);
                String[] shFilesNames = shFiles.split(",");
                Assert.assertTrue(nameOfShippedFiles.contains(shFilesNames[0]) || nameOfShippedFiles.contains(shFilesNames[1])
                        || nameOfShippedFiles.contains(shFilesNames[2]) || nameOfShippedFiles.contains(shFilesNames[3]));

            }

        }
        if ("PS_Only".equalsIgnoreCase(selPurpose))
        {
            if ("SH_ID_040".equalsIgnoreCase(tc_Id))
            {
                shPage.selectFutureDateFromTheCalendar();
                Thread.sleep(2000);
                shPage.selectShippedFiles(shFiles);
                shPage.clickAddButtonForPostShipmentToProjectTrackingOnly();
                shPage.clickSaveButton();
                String fetchedErrorMsg = shPage.getTheErrorMessageForFutureDate();
                String requiredErrMsg = "Error: Shipped Date cannot be future date.";
                commMethods.verifyString(fetchedErrorMsg, requiredErrMsg);
            } else
            {
                shPage.selectDate();

                Thread.sleep(2000);
                shPage.selectShippedFiles(shFiles);
                Thread.sleep(2000);
                // added a another method to add shipping files on the basis of
                // delivery type
                shPage.clickAddButtonForPostShipmentToProjectTrackingOnly();
            }
        } else if ("DF_PS".equalsIgnoreCase(selPurpose) || "DF_Only".equalsIgnoreCase(selPurpose))
        {
            Thread.sleep(3500);
            shPage.selectShippedFiles(shFiles);
            Thread.sleep(2000);
            if ("SH_ID_001".equalsIgnoreCase(tc_Id))

            {
                shPage.clickAddButton();
                String errorMessage = shPage.getTheErrorMessageForMultiDataSetInput();
                if (errorMessage != null)
                {
                    Assert.assertTrue(errorMessage.contains("The file selected is from a Data Menu using multiple Credit data sets"));
                }

            } else
            {
                shPage.clickAddButton();

                if ("SH_ID_013".equalsIgnoreCase(tc_Id))
                {
                    String classNameOfTitlePopUp = shPage.getClassNameOfFontOfPopUp();
                    commMethods.verifyString("fusion-h3Title", classNameOfTitlePopUp);
                }
                Thread.sleep(2000);
                if ("SH_ID_279".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(shPage.isFTPAvailableAfterConnectDirect(), true);
                }
                if ("SH_ID_299".equalsIgnoreCase(tc_Id))
                {
                    shPage.selectDeliveryType(delType);
                    commMethods.verifyboolean(shPage.isOptionsDisabled(), true);
                }

                if ("SH_ID_289".equalsIgnoreCase(tc_Id))
                {
                    shPage.selectDeliveryType(delType);
                    shPage.selectFTPHost(hostORscriptFile);
                    Thread.sleep(1000);
                    List<String> schidList = shPage.listOptionsForSCHID_FTP();
                    commMethods.verifyboolean(true, shPage.isSCHIDFTPListSorted(schidList));

                }

                if ("SH_ID_291".equalsIgnoreCase(tc_Id))
                {
                    shPage.selectDeliveryType(delType);
                    shPage.selectFTPHost(hostORscriptFile);
                    Thread.sleep(1000);
                    commMethods.verifyboolean(true, shPage.isHostAndSCHIDDisabledWhenTestAutomation());

                }

                // Adding Shipping delivery Details
           shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);

                if ("SH_ID_288".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickEditDeliveryDetails();
                    commMethods.verifyboolean(shPage.validateSCIDContent(), true);
                }

                if ("SH_ID_290".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickEditDeliveryDetails();
                    commMethods.verifyboolean(shPage.validateHostRecordLabelContent(), true);
                }

                if ("SH_ID_283".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickEditDeliveryDetails();
                    boolean val = shPage.validateHostRecordLabelContent();
                    commMethods.verifyboolean(true, val);
                }

                // shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                if ("SH_ID_280".equalsIgnoreCase(tc_Id) || "SH_ID_281".equalsIgnoreCase(tc_Id) || "SH_ID_282".equalsIgnoreCase(tc_Id)
                        || "SH_ID_284".equalsIgnoreCase(tc_Id) || "SH_ID_286".equalsIgnoreCase(tc_Id) || "SH_ID_287".equalsIgnoreCase(tc_Id))
                {
                    String prodPath = null;
                    if ("SH_ID_280".equalsIgnoreCase(tc_Id) || "SH_ID_281".equalsIgnoreCase(tc_Id) || "SH_ID_282".equalsIgnoreCase(tc_Id))
                    {
                        prodPath = "/nas/code/prod/etc/FTP_Tool_credentials.txt";
                    } else if ("SH_ID_284".equalsIgnoreCase(tc_Id))
                    {
                        prodPath = "/nas/fusion/config/sdlc/FTP_Tool_credentials_Test.txt";
                    } else if ("SH_ID_286".equalsIgnoreCase(tc_Id))
                    {
                        prodPath = "/nas/a4data/AppData/SCHID/msr.csv";
                    } else
                    {
                        prodPath = "/nas/fusion/config/sdlc/msr_test.csv";
                    }
                    commMethods.verifyboolean(shPage.validateHostListPopulation(prodPath), true);
                }
                if ("SH_ID_291".equalsIgnoreCase(tc_Id))
                {
                    commMethods.verifyboolean(true, shPage.isFTP_SCHIDStyleDisabled());
                }

                if ("SH_ID_293".equalsIgnoreCase(tc_Id) || "SH_ID_294".equalsIgnoreCase(tc_Id))
                {
                    // shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);

                    shPage.clickSaveButton();
                    Thread.sleep(3000);
                    ProjDashBoardPage.clickShippingProcessTab();
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                    module.initializeDriver(driver);
                    module.selectEdit();
                    shPage.clickEditDeliveryDetails();
                    if ("SH_ID_294".equalsIgnoreCase(tc_Id))
                    {
                        // commMethods.verifyString("Select", shPage.getFTP_SCHIDSelectedOption());
                        commMethods.verifyboolean(true, shPage.isFTP_SCHIDStyleDisabled());

                    } else
                    {
                        shPage.selectSCHID_FTP(schId);
                        // verify error mesasge due as list contains only single SCHID value
                    }

                }

                if ("SH_ID_294".equalsIgnoreCase(tc_Id))
                {
                    shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
                    shPage.clickSaveButton();
                    ProjDashBoardPage.clickShippingProcessTab();
                    status = commMethods.getProcessStatus();
                    commMethods.verifyString(status.trim(), StatusEnum.READY.name());
                    module.initializeDriver(driver);
                    module.selectEdit();
                    shPage.clickEditDeliveryDetails();
                    shPage.selectSCHID_FTP(schId);
                    // verify error mesasge due as list contains only single SCHID value

                }
                if ("SH_ID_292".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickSaveButton();
                    String shpId = commMethods.getShippingProcessId(processName1, processName);
                    List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                    qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                    Thread.sleep(1000);
                    shHomePage.clickShippingHomeTab();
                    module.initializeDriver(driver);
                    module.selectEdit();
                    shPage.clickSubmitButton();
                    ProjDashBoardPage.clickHomeTab();
                    ProjDashBoardPage.changeHomeGridViewSelectionToDefault();
                    String ProcessName1 = ProjDashBoardPage.getJobName();
                    String Status = ProjDashBoardPage.verifyProcess(ProcessName1);
                    commMethods.verifyString(Status, "PASS");

                }

                if ("SH_ID_301".equalsIgnoreCase(tc_Id) || "SH_ID_298".equalsIgnoreCase(tc_Id) || "SH_ID_302".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickSaveButton();
                    Thread.sleep(3000);
                    String shpId = commMethods.getShippingProcessId(processName1, processName);
                    Thread.sleep(1000);
                    List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                    Thread.sleep(5000);
                    qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                    Thread.sleep(1000);
                    shHomePage.clickShippingHomeTab();
                    module.initializeDriver(driver);
                    module.selectEdit();
                    Thread.sleep(1000);
                    shPage.clickSubmitButton();
                    Thread.sleep(1000);
                    // driver.findElement(By.id("btnOk")).click();
                    // click ok on file size confirmation id--->>{btnOk}
                    if ("SH_ID_298".equalsIgnoreCase(tc_Id))
                    {
                        ProjDashBoardPage.clickHomeTab();
                        Thread.sleep(2500);
                        // ProjDashBoardPage.changeHomeGridViewSelectionToDefault();
                        // String ProcessName1 = ProjDashBoardPage.getJobName();
                        String Status = ProjDashBoardPage.verifyProcess(procId);
                        commMethods.verifyString(Status, "PASS");
                    } else if ("SH_ID_301".equalsIgnoreCase(tc_Id))
                    {
                        Thread.sleep(2000);

                        shHomePage.clickShippingHomeTab();
                        Thread.sleep(5000);

                        module.selectDuplicate();

                        Thread.sleep(5000);
                        module.selectEdit();

                        Thread.sleep(3000);
                        shPage.clickEditDeliveryDetails();
                        System.out.println("123");
                        commMethods.verifyString(delType, shPage.getDeliveryType());
                        commMethods.verifyString(recEmailAdd, shPage.getEmailAdress());
                        commMethods.verifyString(schId, shPage.getFTP_SCHIDSelectedOption());
                        commMethods.verifyString(hostORscriptFile, shPage.getHostSelectedOption());
                    }

                    else if ("SH_ID_302".equalsIgnoreCase(tc_Id))
                    {

                        String copyprojectName = driver.findElement(By.xpath("//a[@id='editProjectDetails']")).getText().replaceAll("\\s+", "");
                        commMethods.searchSpecificProject(projectName);

                        ProjDashBoardPage.inputProjNum(copyprojectName);
                        ProjDashBoardPage.clickCopyProjSrchBtn();
                        String[] procArr = process.split(":");
                        ProjDashBoardPage.selectCopyPrevProjProcName(procArr[0]);
                        ProjDashBoardPage.clickCopySelectBtn();
                        module.initializeDriver(driver);
                        shHomePage.clickShippingHomeTab();
                        module.selectEdit();
                        Thread.sleep(5000);
                        shPage.clickEditDeliveryDetails();
                        commMethods.verifyString(delType, shPage.getDeliveryType());
                        commMethods.verifyString(recEmailAdd, shPage.getEmailAdress());
                        commMethods.verifyString(schId, shPage.getFTP_SCHIDSelectedOption());
                        commMethods.verifyString(hostORscriptFile, shPage.getHostSelectedOption());

                    }

                }
                Thread.sleep(3000);
            }
        } else if ("SH_ID_023".equalsIgnoreCase(tc_Id))
        {
            String classNameOfErrorMessage = shPage.getClassNameOfErrorMessage();
            commMethods.verifyString("errMsg", classNameOfErrorMessage);
        }
        if ("SH_ID_084".equalsIgnoreCase(tc_Id) || "SH_ID_100".equalsIgnoreCase(tc_Id))
        {
            shPage.clickCompletedJob();
            Assert.assertTrue(shPage.isLightBoxPresent());
            String errMessage = shPage.getTheErrorMsgOnChangeOfInputType();
            if (!(null == errMessage))
            {
                String requiredErrMsg = "All existing files configured for Delivery/Accounting will be removed.\nAre you sure you wish to continue?";

                commMethods.verifyString(errMessage, requiredErrMsg);
            }
            shPage.clickButtonOfLightBoxWhenInputTypeChanges();
            Thread.sleep(1500);
            // shPage.clickPredictInput();
            shPage.selectProcess(process);
            Thread.sleep(4000);
            shPage.selectJob(job);
            if (!"DF_Only".equalsIgnoreCase(selPurpose))
            {
                shPage.rawNamesCount(rawCount);
            }
            shPage.selectShippedFiles(shFiles);
            Thread.sleep(2000);
            shPage.clickAddButton();
            Thread.sleep(2000);
            shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);

        }
        Thread.sleep(4000);
        if ("SH_ID_101".equalsIgnoreCase(tc_Id))

        {
            shPage.clickPredictInput();
            Assert.assertTrue(shPage.isLightBoxPresent());
            String errMessage = shPage.getTheErrorMsgOnChangeOfInputType();
            LOGGER.info("Fetched Error Message is -" + " " + errMessage);
            if (!(null == errMessage))
            {
                String requiredErrMsg = "All existing files configured for Delivery/Accounting will be removed.\nAre you sure you wish to continue?";

                commMethods.verifyString(errMessage, requiredErrMsg);
            }
            shPage.clickButtonOfLightBoxWhenInputTypeChanges();
            Thread.sleep(1500);

            shPage.selectProcess(process);
            Thread.sleep(4000);
            shPage.selectShippedFiles(shFiles);
            Thread.sleep(2000);
            shPage.clickAddButton();
            Thread.sleep(2000);
            shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);

        }

        // if (!"SH_ID_001".equalsIgnoreCase(tc_Id))
        // {
        // Thread.sleep(2500);
        // shPage.clickSaveButton();
        //
        // }
        Thread.sleep(1500);
        if ("SH_ID_131".equalsIgnoreCase(tc_Id))
        {
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);

            String new_process_name = processName1 + ":" + "" + processName;
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(new_process_name);
            jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(5000);
            jobStackingPage.clickJobStackingSubmitButton();

            String errMsg = jobStackingPage.getTheErrorMessageFromTheJobStackingScreen();
            LOGGER.info("Fetched error message is -" + " " + errMsg);
            if (errMsg != null)
            {
                commMethods.verifyString(errMsg, "Errors: Error : Job run details for Input Process " + "\"" + process + "\""
                        + " selected for process " + new_process_name + " do not exist.");

            }
        }

        if ("SH_ID_300".equalsIgnoreCase(tc_Id))
        {
            // shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
            Thread.sleep(2500);
            shPage.clickSaveButton();
            String shpId = commMethods.getShippingProcessId(processName1, processName);
            List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
            qcPage.approveRequiredQcItemsForShipping(processesToApprove);
            Thread.sleep(1000);
            // shHomePage.clickShippingHomeTab();
            ProjDashBoardPage.clickJobStackingTab();
            stackingPage.clickJobStackingButton();
            jobStackingPage.inputStackName(procNameForStack);

            String new_process_name = processName1 + ":" + "" + processName;
            jobStackingPage.clickProcessDropDown();
            jobStackingPage.selectProcessFromDropdown(new_process_name);
            jobStackingPage.clickOpenFlowChart();
            Thread.sleep(1500);
            List<String> processList = new ArrayList<String>();
            processList.add(new_process_name);
            jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
            jobStackingPage.clickJobStackingSubmitButton();
            Thread.sleep(5000);
            jobStackingPage.clickJobStackingSubmitButton();
            ProjDashBoardPage.clickHomeTab();
            ProjDashBoardPage.changeHomeGridViewSelectionToDefault();
            commMethods.verifyString(ProjDashBoardPage.verifyProcess(stackingPage.getStackId()), "PASS");
        }
        if ("SH_ID_004".equalsIgnoreCase(tc_Id))
        {
            List<String> record_Count_List = shPage.getRecountCountFromDeliveryType(delType, inputType);
            if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
            {

                if (CollectionUtils.isNotEmpty(record_Count_List))
                {
                    for (String count : record_Count_List)
                    {
                        Assert.assertTrue(null != count);
                        String[] str = shFiles.split(",");
                        LOGGER.info("Following is the count displayed for file" + " " + str[0] + " " + "--" + count);
                    }
                }
            }
            if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
            {
                if (CollectionUtils.isNotEmpty(record_Count_List))
                {
                    for (String count : record_Count_List)
                    {
                        Assert.assertTrue(null != count);
                        String[] str = shFiles.split(",");
                        LOGGER.info("Following is the count displayed for file" + " " + str[0] + " " + "--" + count);
                    }
                }

            }
        }

        else if ("SH_ID_005".equalsIgnoreCase(tc_Id))
        {
            boolean is_record_count_editable = shPage.IsEditable(delType);
            LOGGER.info("Is record count column of shipping grid is editable -" + " " + is_record_count_editable);
            Assert.assertTrue(is_record_count_editable);
            if (is_record_count_editable)

            {
                String record_count = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);
                long recordCount = Long.parseLong(record_count);
                LOGGER.info("Record Count is -" + " " + recordCount);
                recordCount++;
                shPage.editRecordCountColumnOfShippingGrid(delType, Long.toString(recordCount));
                shPage.clickSaveButton();
                String new_record_count = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);
                LOGGER.info("New Record Count is -" + " " + recordCount);
                commMethods.verifyString(new_record_count, Long.toString(recordCount));

            }
        } else if ("SH_ID_006".equalsIgnoreCase(tc_Id))
        {
            String fileName = shPage.getFileNameFromDeliveryType(delType);
            
               String[] delFileNameArr = delFileName.split(",");
              commMethods.verifyString(delFileNameArr[0], fileName);
                

            
        } else if ("SH_ID_007".equalsIgnoreCase(tc_Id))
        {
            String delivery_Detail = shPage.getDeliveryTypeOfTableFromDeliveryType(delType);
            String[] deliveryDetailArr = delivery_Detail.split("-");
            commMethods.verifyString(deliveryDetailArr[0], delType);

        } else if ("SH_ID_008".equalsIgnoreCase(tc_Id))
        {
            String[] delFileNameArr = delFileName.split(",");

            String row_id_for_firt_file = shPage.getRowIdOnFromFileName(delFileNameArr[0]);
            String row_id_for_second_file = shPage.getRowIdOnFromFileName(delFileNameArr[1]);
            Assert.assertTrue(row_id_for_firt_file.contains("row1_"));
            Assert.assertTrue(row_id_for_second_file.contains("row1_"));

            LOGGER.info("validated when multiple files of a single output process is selected, they appear in the same row of delievery details in the grid of Shipping screen.");
        } else if ("SH_ID_009".equalsIgnoreCase(tc_Id))
        {
            String[] delFileNameArr = delFileName.split(",");
            String row_id_for_first_file = shPage.getRowIdOnFromFileName(delFileNameArr[0]);
            LOGGER.info("Row Id For First File Is -" + "" + row_id_for_first_file);
            Assert.assertTrue(row_id_for_first_file.contains("row1_"));
            if (!"NA".equalsIgnoreCase(job_2) && !"NA".equalsIgnoreCase(process_2))
            {
                shPage.selectProcess(process_2);
                shPage.selectJob(job_2);
                Thread.sleep(4000);
                shPage.selectShippedFiles(shFiles_2);

                shPage.clickAddButton();
                Thread.sleep(1000);
                shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, deliveryFileNamesForJob2, recEmailAdd, emailSub, emailBody);
                shPage.clickSaveButton();
                String[] delFileNameArrForJob2 = deliveryFileNamesForJob2.split(",");
                String row_id_for_second_file = shPage.getRowIdOnFromFileName(delFileNameArrForJob2[0]);
                LOGGER.info("Row Id For Second File Is -" + "" + row_id_for_second_file);

                Assert.assertTrue(row_id_for_second_file.contains("row2_"));
            }

            LOGGER.info("validated when multiple files of a single output process is selected, they appear in the same row of delievery details in the grid of Shipping screen.");
        }

        else if ("SH_ID_030".equalsIgnoreCase(tc_Id))
        {
            String ProcessName_JobID = shPage.getTheProcessNameAndJobIdFromTheShippingGrid(delType);
            String recordCountFromTheGrid = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);
            recordCountFromTheGrid = recordCountFromTheGrid.replaceAll(",$", "");
            String[] processJobArr = job.split(":");
            String jobNo = processJobArr[1];
            Assert.assertTrue(ProcessName_JobID.contains(jobNo));
            Assert.assertTrue(ProcessName_JobID.contains(process));
            String[] assignedIdForOP = process.split(":");
            shPage.clickSaveButton();
            Thread.sleep(1500);
            ProjDashBoardPage.clickHomeTab();

            // shPage.clickViewStatsForJobLevel(assignedIdForOP[0]);
            commMethods.searchProcessOnDashboardAndViewStats(assignedIdForOP[0]);

            // here getting the shipped files count from the stats of output
            // which is taken as input but only for single shipped file
            // verification is done
            String row_count_fetched_from_OP_Stats = shPage.getTheRecordCountOfFileFromOPStats(shFiles);
            commMethods.verifyString(recordCountFromTheGrid, row_count_fetched_from_OP_Stats);

        }

        else if ("SH_ID_090".equalsIgnoreCase(tc_Id) || "SH_ID_118".equalsIgnoreCase(tc_Id))
        {
            shPage.clickSaveButton();
            Thread.sleep(2500);
            shHomePage.clickShippingHomeTab();
            module.initializeDriver(driver);
            module.selectSummary();
            Thread.sleep(1500);

            shSumPage.clickSubmitButton();
           // shPage.handleTheDialogBox();
            String new_process_name = processName1 + ":" + "" + processName;
            String errMsg = shPage.getTheErrorMessage();
            LOGGER.info("Fetched Error Is -" + " " + errMsg);
            if (errMsg != null)
            {
                Assert.assertTrue(errMsg.contains("Job run details for Input Process " + "\"" + process + "\"" + " selected for process "
                        + new_process_name + " do not exist."));
                // commMethods.verifyString(errMsg, "Job run details for Input Process " + "\"" + process + "\"" + " selected for process "
                // + new_process_name + " do not exist.");
                // commMethods.verifyString(errMsg,"Job run details for Input Process "
                // + " " + "" + process + "" + " "
                // +" selected for process"+""+""+new_process_name
                // +""+"do not exist");
                // Assert.assertTrue(errMsg.contains("Job run details for Input Process "
                // + " " + "" + process + "" + " "
                // +" selected for process"+""+""+new_process_name
                // +""+"do not exist"));
            }

        }

        // end of save part testcases now testcase related to submission starts
        else
        {
            if ("SH_ID_019".equalsIgnoreCase(tc_Id))
            {
                shPage.clickSaveButton();
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();
                module.initializeDriver(driver);
                module.selectEdit();
                shPage.clickSubmitButton();
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();

                module.initializeDriver(driver);
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                module.selectSummary();
                int buttonCount = shPage.getTheCountOfButtonPresentOnShippingSummary();
                LOGGER.info("No of buttons present in the shipping summary screen is :" + " " + buttonCount);
                Assert.assertTrue(1 == buttonCount);
                String buttonName = shPage.getTheNameOfButtonPresentOnShippingSummary();
                LOGGER.info("Name of buttton on summary screen" + " " + buttonName);
                commMethods.verifyString(buttonName, "� Back");
                LOGGER.info("Verified Only Back button present on summary screen");

            } else if ("SH_ID_020".equalsIgnoreCase(tc_Id))
            {
                // qcPage.approvesTheShippinginQC();
                shPage.clickSaveButton();
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                // String JobNo = ProjDashBoardPage
                // .getTheJobNoForTheProcess(procId);
                // shPage.clickTheCollapseButton(procId);
                shPage.clickTheCollapseButton(processName1 + "_" + processName, processName1 + ":" + processName);
                Thread.sleep(1000);
                String result = shPage.isOneWorkItemHasFormed();
                commMethods.verifyString(result, "SHP_ACCOUNTING");
                LOGGER.info("Verified Only one workitem is formed when purpose is Post Shipment to Project Tracking only ");
            }

            else if ("SH_ID_029".equalsIgnoreCase(tc_Id))
            {
                String recordsFromTheGrid = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);
                shPage.clickSaveButton();
                Thread.sleep(2500);
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();
                module.initializeDriver(driver);
                Thread.sleep(3000);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName1), "PASS");
                Thread.sleep(1000);

                // shPage.clickViewStatsForJobLevel(processName1);
                commMethods.searchProcessOnDashboardAndViewStats(processName1);

                Thread.sleep(1000);
                // driver.switchTo().frame("sb-player");
                String recordsShipped = shPage.getTheRecordsShippedFromSHStats();
                String[] recordsShippedArr = recordsShipped.split(",");
                commMethods.verifyString(recordsShippedArr[0], recordsFromTheGrid);
            } else if ("SH_ID_094".equalsIgnoreCase(tc_Id))
            {

                // qcPage.approvesTheShippinginQC();
                shPage.clickSaveButton();
                Thread.sleep(2500);

                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickOutputTab();
                Thread.sleep(1500);
                String[] processArr = process.split(":");
                module.initializeDriver(driver);
                opHPage.selectDuplicateOPFromAssignedId(processArr[0]);

                String procNameOfDuplicatedOP = opHPage.FetchTheProcessNameFromOPHomePage();
                shHomePage.clickShippingHomeTab();
                shHomePage.clickShippingProcess();

                shPage.inputProcessName(processName);

                shPage.selectPurposeRB(selPurpose);
                shPage.clickPredictInput();
                shPage.selectProcess(procNameOfDuplicatedOP);
                List<WebElement> shippedFileList = shPage.getListOfShippedFiles();
                int RowCount = shippedFileList.size();
                Assert.assertTrue(RowCount == 4);
                for (int i = 0; i < RowCount; i++)
                {
                    String nameOfShippedFiles = shippedFileList.get(i).getText();

                    LOGGER.info("name of the files shipped -" + " " + nameOfShippedFiles);

                    String[] ShippedFilesArr = nameOfShippedFiles.split("\\.");
                    Assert.assertTrue(ShippedFilesArr[0].endsWith("_##"));

                }

            } else if ("SH_ID_085".equalsIgnoreCase(tc_Id))
            {
            	 shPage.clickSaveButton();
            	ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(procNameForStack);

                String process_Name = processName1 + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(process_Name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(process_Name);
                processList.add(process);
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);

                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(1000);

                String errMsg = jobStackingPage.getTheErrorMessageFromTheJobStackingScreen();
                LOGGER.info("Fetched error message is -" + " " + errMsg);
                if (errMsg != null)
                {
                    Assert.assertTrue(errMsg
                            .contains("Errors: The following QC items are pending approval or rejected. All QC items must be approved before Shipping is permitted."));

                }
            } else if ("SH_ID_036".equalsIgnoreCase(tc_Id))
            { 
            	shPage.clickSaveButton();

                String recordCntFetchedFromShippingGrid = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);
                String[] shFileNameArr = shFiles.split(",");
                shPage.clickSaveButton();
                Thread.sleep(2500);
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                Thread.sleep(1000);
                shHomePage.clickShippingHomeTab();
                Thread.sleep(1000);
                module.initializeDriver(driver);
                module.selectSummary();
                shSumPage.clickSubmitButton();
                Thread.sleep(1000);
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                Thread.sleep(3000);
                ProjDashBoardPage.clickHomeTab();
                commMethods.searchProcessOnDashboardAndViewStats(processName1);
                Thread.sleep(1500);
                // shPage.isStatsTabOpen();
                String record_count_frm_Shipping_Stats = shPage.getTheRecordCountOfFileFromSHStats(shFileNameArr[0]);
              //  String[] arr = record_count_frm_Shipping_Stats.split(",");
             //   String recordCnt = arr[0] + arr[1];
                LOGGER.info("Record Count From SH Stats -" + " " + record_count_frm_Shipping_Stats);

                commMethods.verifyString(recordCntFetchedFromShippingGrid,record_count_frm_Shipping_Stats);

            } else if ("SH_ID_092".equalsIgnoreCase(tc_Id))
            {	
            	
            	shPage.clickSaveButton();
               String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);

                ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(procNameForStack);
                String stackAssignedId = commMethods.getFinalProcessName();
                String new_process_name = processName1 + ":" + "" + processName;

                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(new_process_name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(new_process_name);
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
                Thread.sleep(15000);
                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(30000);
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(stackAssignedId), "PASS");
                String[] nameArrForOP = process.split(":");
                // shPage.clickViewStatsForJobLevel(nameArrForOP[0]);
                commMethods.searchProcessOnDashboardAndViewStats(nameArrForOP[0]);

                // driver.switchTo().frame("sb-player");
                String[] arr = shFiles.split(",");

                String record_count_for_file_frm_OP_Stats = shPage.getTheRecordCountOfFileFromOPStats(arr[0]);
                ProjDashBoardPage.clickCloseButtonStats1();
                shPage.clearFilter();
                ProjDashBoardPage.clickHomeTab();
                Thread.sleep(2000);
                // shPage.clickViewStatsForJobLevel(assignedId);
                commMethods.searchProcessOnDashboardAndViewStats(stackAssignedId);
                Thread.sleep(1500);
                shPage.isStatsTabOpen();
                // driver.switchTo().frame("sb-player");

                // TODO Here for getting the record count from shipping stats
                // need to pass assigned Id of stack from which the shipping is
                // submiited
                String record_count_for_file_frm_Stack_Stats = shPage.getTheRecordCountOfFileFromStackStats(arr[0]);
                commMethods.verifyString(record_count_for_file_frm_OP_Stats, record_count_for_file_frm_Stack_Stats);

            } else if ("SH_ID_115".equalsIgnoreCase(tc_Id))
            {
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);

                ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(procNameForStack);

                String new_process_name = processName1 + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(new_process_name);

                // jobStackingPage.selectProcessFromDropdown("SH128:Chk_record_cnt");
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(new_process_name);
                // processList.add("SH128:Chk_record_cnt");
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(30000);

                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                Thread.sleep(2000);
                shHomePage.clickShippingHomeTab();
                Thread.sleep(2000);
                module.initializeDriver(driver);
                Thread.sleep(2000);
                module.selectDuplicate();
                Thread.sleep(2000);
                module.selectEdit();
                Thread.sleep(2500);
                String recordCount = shPage.getTheRecordcountFromTheShippingGrid(delType, inputType);

                commMethods.verifyString("Unavailable", recordCount);

            } else if ("SH_ID_102".equalsIgnoreCase(tc_Id))
            {
                shPage.clickSaveButton();
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                // qcPage.calljs(driver, processesToApprove);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);

                ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                jobStackingPage.inputStackName(procNameForStack);
                String assignedId = jobStackingPage.getAssignedId();

                String new_process_name = processName1 + ":" + "" + processName;
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(new_process_name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                List<String> processList = new ArrayList<String>();
                processList.add(new_process_name);
                jobStackingPage.selectTheProcessFromTheFlowChart(processList,30);
                jobStackingPage.clickJobStackingSubmitButton();
                Thread.sleep(5000);
                ProjDashBoardPage.clickJobStackingTab();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                Thread.sleep(2000);
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(assignedId), "PASS");
                Thread.sleep(1000);
                commMethods.searchProcessOnDashboardAndViewStats(assignedId);
                Thread.sleep(1500);
                shPage.isStatsTabOpen();
                // shPage.clickViewStatsForJobLevel(processName1);
                // Thread.sleep(1000);
                // driver.switchTo().frame("sb-player");

                // Integer shFileCount = shStats.getTheCountOfShippedFiles();
                // Assert.assertTrue(shFileCount == 8);
                HashMap<String, Long> shFileNameAndRecordCntMap = shStats.getTheCountOfRecordsShipped(shFiles);

                // ProjDashBoardPage.clickCloseButtonStats();
                ProjDashBoardPage.clickCloseButtonStats1();
                ProjDashBoardPage.clickHomeTab();
                String[] procArr = process.split(":");
                commMethods.searchProcessOnDashboardAndViewStats(procArr[0]);
                Thread.sleep(1000);

                HashMap<String, Long> OPFileNameAndRecordCntMap = shStats.getTheCountOfRecordsOfFileFromOPStats(shFiles);

                // driver.switchTo().defaultContent();
                // ProjDashBoardPage.clickCloseButtonStats();
                ProjDashBoardPage.clickCloseButtonStats1();
                for (Entry<String, Long> entry : OPFileNameAndRecordCntMap.entrySet())
                {
                    for (Entry<String, Long> entry1 : shFileNameAndRecordCntMap.entrySet())
                    {
                        if (entry1.getKey().equalsIgnoreCase(entry.getKey()))
                        {
                            commMethods.verifyLong(entry1.getValue(), entry.getValue());

                        }
                    }
                }

            }

            else if ("SH_ID_087".equalsIgnoreCase(tc_Id) || "SH_ID_088".equalsIgnoreCase(tc_Id))
            {
                String shpId = commMethods.getShippingProcessId(processName1, processName);
                List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                qcPage.approveRequiredQcItemsForShipping(processesToApprove);

                ProjDashBoardPage.clickJobStackingTab();
                stackingPage.clickJobStackingButton();
                String assignedId = jobStackingPage.getAssignedId();
                jobStackingPage.inputStackName(procNameForStack);
                String[] processHierarchyArr = ProcessesForStack.split(",");
                List<String> newList = Arrays.asList(processHierarchyArr);
                List<String> processHierarchyList = new ArrayList<String>();
                String new_process_name = processName1 + ":" + "" + processName;
                processHierarchyList.add(new_process_name);
                processHierarchyList.add(process);
                processHierarchyList.addAll(newList);
                jobStackingPage.clickProcessDropDown();
                jobStackingPage.selectProcessFromDropdown(new_process_name);
                jobStackingPage.clickOpenFlowChart();
                Thread.sleep(1500);
                jobStackingPage.selectTheProcessFromTheFlowChart(processHierarchyList,30);
                Thread.sleep(5000);
                jobStackingPage.clickJobStackingSubmitButton();
                status = shHomePage.getStatusSH();
                commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                ProjDashBoardPage.clickHomeTab();
                commMethods.verifyString(ProjDashBoardPage.verifyProcess(assignedId), "PASS");

            } else if ("SH_ID_273".equalsIgnoreCase(tc_Id) || "SH_ID_274".equalsIgnoreCase(tc_Id) || "SH_ID_275".equalsIgnoreCase(tc_Id)
                    || "SH_ID_276".equalsIgnoreCase(tc_Id) || "SH_ID_277".equalsIgnoreCase(tc_Id))
            {

                String delNo = shPage.getTheDeliveryNumberFromTheGrid();
                // String shpId = commMethods.getShippingProcessId(processName1, processName);
                // List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                // qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                // Thread.sleep(3000);
                // shHomePage.clickShippingHomeTab();
                // module.initializeDriver(driver);
                // module.selectEdit();
                // shPage.clickSubmitButton();
                // Thread.sleep(1500);
                // module.initializeDriver(driver);
                // module.selectEdit();
                shPage.clickSaveButton();
                Thread.sleep(1500);
                shPage.clickTestAutomation();
                shPage.clickSubmitButton();
                Thread.sleep(1500);
                if ("SH_ID_278".equalsIgnoreCase(tc_Id))
                {

                    shPage.clickEditDeliveryDetails();
                    commMethods.verifyboolean(shPage.isTextBoxReadOnly(), true);
                }
                String errorMessage = shPage.getTheErrorMessageForRunTypeSelection();
                if ("SH_ID_273".equalsIgnoreCase(tc_Id))
                {
                    if (errorMessage != null)
                    {
                        commMethods.verifyString(errorMessage, "Error: The script file for delivery number " + delNo
                                + " is not a test file. Please change it to /nas/dropzone/TechSupport/bart/FUSIONCD.cd and try again.");
                    }

                }
                if ("SH_ID_274".equalsIgnoreCase(tc_Id))
                {
                    if (errorMessage != null)
                    {
                        commMethods.verifyString(errorMessage, "Error: The SCHID/Host for delivery number " + delNo
                                + " is not a test SCHID/Host.  Please change SCHID to ST00915 and Host to securetrans and try again.");
                    }

                }
                if ("SH_ID_275".equalsIgnoreCase(tc_Id))
                {
                    if (errorMessage != null)
                    {
                        commMethods.verifyString(errorMessage, "Error: The recipient's address for delivery number " + delNo
                                + " is not current user's address. Please change it to shraddha.shukla@equifax.com and try again.");
                    }

                }

                if ("SH_ID_276".equalsIgnoreCase(tc_Id) || "SH_ID_277".equalsIgnoreCase(tc_Id))
                {
                    shPage.clickRemoveRowIcon();
                    shPage.selectShippedFiles(shFiles);
                    shPage.shipFilesDeliveryDetls(delType, hostORscriptFile2, schId, delFileName, recEmailAdd, emailSub, emailBody);
                    shPage.clickSaveButton();
                    Thread.sleep(1500);
                    String shpId = commMethods.getShippingProcessId(processName1, processName);
                    List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
                    qcPage.approveRequiredQcItemsForShipping(processesToApprove);
                    Thread.sleep(1500);
                    Thread.sleep(1000);
                    shHomePage.clickShippingHomeTab();
                    module.initializeDriver(driver);
                    module.selectSummary();
                    shSumPage.clickSubmitButton();
                    // shPage.clickSubmitButton();
                    Thread.sleep(1500);
                    status = shHomePage.getStatusSH();
                    commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
                    Thread.sleep(2000);
                    ProjDashBoardPage.clickHomeTab();
                    commMethods.verifyString(ProjDashBoardPage.verifyProcess(processName1), "PASS");
                    String processNameForstats = processName1 + "_" + processName;
                    String processNameColon = processName1 + ":" + processName;
                    shPage.viewStatsForAccountingWorkitem(processNameForstats, processNameColon);
                    Thread.sleep(1000);
                    commMethods.verifyString(shPage.fetchTheTextFromStats(), "Test Automation Setup - Project Tracking was not updated. :");
                    List<String> statItemList = shPage.fetchTheStatsForAccountingWorkitem();
                    for (int i = 0; i < statItemList.size(); i++)
                    {
                        Assert.assertTrue(statItemList.get(i).equalsIgnoreCase("Raw Names") || statItemList.get(i).equalsIgnoreCase("Accepts")
                                || statItemList.get(i).equalsIgnoreCase("Records Shipped"));
                    }

                }
            }
        }

    }

    @Test(dataProvider = "shipping_Reg_Base",enabled=true)
    public void createBaseProcess(String tc_Id, String testRun, String TC, String Description,String copyProject, String copyProcess,String projectName, String processName,String selPurpose,
    		String runType,String inputType,String reportOnly,String process, String job, String shFiles, String rawCount, String delType,String hostORscriptFile, 
    		String schId,String delFileName, String recEmailAdd, String emailSub, String emailBody,String process_2, String job_2, String shFiles_2, String hostORscriptFile2,
    		String procNameForStack, String deliveryFileNamesForJob2, String futureDate, String ProcessesForStack, String ProjNum ,ITestContext testContext) throws Exception
    {
        new Modules();
        testContext.setAttribute("WebDriver", driver);
        /* testContext.setAttribute("WebDriver",driver); */
        String executionStatus = commMethods.getTheExecutionStatus(process);
        if (executionStatus.equalsIgnoreCase("COMPLETED"))
        {
        shHomePage.clickShippingHomeTab();
        Thread.sleep(2000);
        shHomePage.clickShippingProcess();
        Thread.sleep(5000);
        String processName1 = commMethods.getFinalProcessName();
        shPage.inputProcessName(processName);
        shPage.selectPurposeRB(selPurpose);
        Thread.sleep(4000);
        if ("LiveProduction".equalsIgnoreCase(runType))
        {
            Thread.sleep(2000);
            shPage.clickLiveProduction();
        } else if ("TestAutomation".equalsIgnoreCase(runType))
        {
            Thread.sleep(2000);
            shPage.clickTestAutomation();
        }
        if ("PREDICTED_INPUT".equalsIgnoreCase(inputType))
        {
            shPage.clickPredictInput();
            Thread.sleep(4000);
        }
        Thread.sleep(4000);

        shPage.selectProcess(process);
        Thread.sleep(4000);
        if ("COMPLETED_JOB".equalsIgnoreCase(inputType))
        {
            shPage.selectJob(job);
            if (!"DF_Only".equalsIgnoreCase(selPurpose))
            {
                shPage.rawNamesCount(rawCount);
            }
        }
        if ("PS_Only".equalsIgnoreCase(selPurpose))
        {
            if ("!NA".equalsIgnoreCase(futureDate))
            {
                shPage.selectFutureDateFromTheCalendar();
                Thread.sleep(2000);
                shPage.selectShippedFiles(shFiles);
                shPage.clickAddButtonForPostShipmentToProjectTrackingOnly();

            } else
            {
                shPage.selectDate();

                Thread.sleep(2000);
                shPage.selectShippedFiles(shFiles);
                Thread.sleep(2000);
                // added a another method to add shipping files on the basis of
                // delivery type
                shPage.clickAddButtonForPostShipmentToProjectTrackingOnly();
            }
        }
        if ("DF_PS".equalsIgnoreCase(selPurpose) || "DF_Only".equalsIgnoreCase(selPurpose))
        {
            Thread.sleep(3500);
            shPage.selectShippedFiles(shFiles);
            Thread.sleep(2000);
        }
        shPage.shipFilesDeliveryDetls(delType, hostORscriptFile, schId, delFileName, recEmailAdd, emailSub, emailBody);
        shPage.clickSaveButton();
        //shPage.clickSaveButton();
        Thread.sleep(1500);
        String shpId = commMethods.getShippingProcessId(processName1, processName);
        List<String> processesToApprove = commMethods.getProcessListToApproveInQC(shpId);
        qcPage.approveRequiredQcItemsForShipping(processesToApprove);
        Thread.sleep(1500);
        Thread.sleep(1000);
        shHomePage.clickShippingHomeTab();
        module.initializeDriver(driver);
        module.selectSummary();
        shSumPage.clickSubmitButton();
        // shPage.clickSubmitButton();
        //Thread.sleep(1500);
        //status = shHomePage.getStatusSH();
        //commMethods.verifyString(status.trim(), StatusEnum.SUBMITTED.name());
        }
        else
        {
            Assert.fail("Issue : Input Process is not in Completed state. Hence cannot continue.");
        }
    }
   
     @AfterMethod
     public void tearDown() 
     { 
         driver.quit(); 
     }
     @DataProvider
     public Object[][] sh_Reg() throws Exception
     {
         Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                 "Shipping", "Y");
         return testObjArray_Y;
     }

    @DataProvider
    public Object[][] sh_CBA_Reg() throws Exception
    {
        Object[][] testObjArray_CBA = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Shipping", "CBA");
        return testObjArray_CBA;
    }
    
    
    @DataProvider
    public Object[][] shipping_Reg_Base() throws Exception
    {
        Object[][] testObjArray_Base = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "Shipping", "BAS");
        return testObjArray_Base;
    }

//    @DataProvider
//    public Object[][] sh_Reg() throws Exception
//    {
//        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
//                "SHprocess", "Y");
//        return testObjArray_Y;
//    }

    /*
     * @DataProvider public Object[][] shStats_Y() throws Exception { Object[][] testObjArray_Y = ExcelRead
     * .getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"), "SHprocess", "Y"); return (testObjArray_Y); }
     
    @DataProvider
    public Object[][] shDRS() throws Exception
    {
        Object[][] testObjArray_DRS = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SHprocess", "DRS");
        return testObjArray_DRS;
    }

    @DataProvider
    public Object[][] shUI() throws Exception
    {
        Object[][] testObjArray_UI = ExcelRead.getTableArrayforSheet(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "SHprocess", "UI");
        return testObjArray_UI;
    }
    sh_CBA_Reg1*/

}

package com.equifax.cms.fusion.test.qaip;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.json.JSONException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.equifax.cms.fusion.test.IPPages.InputHomePage;
import com.equifax.cms.fusion.test.IZpages.IZstats;
import com.equifax.cms.fusion.test.IZpages.InputZipCodesPage;
import com.equifax.cms.fusion.test.IZpages.SummaryIZpage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.FusionFirefoxDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

@Title("Input Zip Codes Process")
public class InputZipCodesProcess
{
    public WebDriver driver;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private InputHomePage IPHomePage;
    private InputZipCodesPage IZcodesPage;
    private SummaryIZpage IZsumPage;
    private IZstats IZstatsPage;
    private Modules module;

    private static final String ERRMSG = "File contains invalid values";

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void LoginandSearchProj() throws InterruptedException
    {
      // driver = FusionFirefoxDriver.getDriver();
       driver = FusionChromeDriver.getDriver();

        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        IPHomePage = PageFactory.initElements(driver, InputHomePage.class);
        IZcodesPage = PageFactory.initElements(driver, InputZipCodesPage.class);
        IZsumPage = PageFactory.initElements(driver, SummaryIZpage.class);
        IZstatsPage = PageFactory.initElements(driver, IZstats.class);
        module = PageFactory.initElements(driver, Modules.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Title("Input Zip Code Process")
    @Test(dataProvider = "iz_Reg", priority = 1, description = "Zip Code Regression Test Cases")
    public void izProcess(String tc_Id, String testRun, String TC, String Desc, String procName, String fileType, String filePurpose, String filePath,
            String opTbl, ITestContext testContext) throws InterruptedException, JSONException, SQLException, IOException
    {
        testContext.setAttribute("WebDriver", this.driver);
        String status = null;
        // Modules module = new Modules();
        ProjDashBoardPage.clickInputTab();
        IPHomePage.clickInputZipCodesBtn();
        String fProName = commMethods.getFinalProcessName();
        IZcodesPage.processNameField(procName);
        IZcodesPage.fileTypeFld(fileType);
        IZcodesPage.filePurposeFld(filePurpose);
        if ("IZ_ID_005".equalsIgnoreCase(tc_Id))
        {
            IZcodesPage.inputZipFilePath(filePath);
            IZcodesPage.clickContinueBtn();
            String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
            commMethods.verifyString(errMsg, ERRMSG);
        } else
        {
            IZcodesPage.inputZipFilePath(filePath);
            // Get the file content into a list
            List<String> zipList = commMethods.readFile(filePath);
            if ("IZ_ID_010".equalsIgnoreCase(tc_Id))
            {
                IZcodesPage.clickSaveBtn();
                ProjDashBoardPage.clickInputTab();
                module.initializeDriver(driver);
                status = module.getStatusIP();
                commMethods.verifyString(status.trim(), StatusEnum.READY.name());
            } else
            {
                IZcodesPage.clickContinueBtn();
                if ("IZ_ID_009".equalsIgnoreCase(tc_Id))
                {
                    ProjDashBoardPage.clickInputTab();
                    module.initializeDriver(driver);
                    module.selectSummary();
                    String title = ProjDashBoardPage.getPageTitle();
                    commMethods.verifyContainsString(title, "Summary: Input Zip Codes");

                } else if ("IZ_ID_001".equalsIgnoreCase(tc_Id))
                {
                    int i = 0;
                    int countZipCodes = 0;
                    while (i < zipList.size())
                    {
                        if (zipList.get(i).matches("[0-9]+") && zipList.get(i).length() <= 5)
                        {
                            countZipCodes++;
                        }
                        i++;
                    }
                    commMethods.verifyString(IZsumPage.zipCodeEntries.getText(), String.valueOf(countZipCodes));

                } else if ("IZ_ID_002".equalsIgnoreCase(tc_Id))
                {
                    Map<String, Integer> dupCount = new HashMap<String, Integer>();
                    int totalDup = 1;

                    for (String z : zipList)
                    {
                        Integer count = dupCount.get(z);
                        dupCount.put(z, (count == null) ? 1 : count + 1);
                    }

                    Collection<Integer> c = dupCount.values();
                    Iterator<Integer> itr = c.iterator();
                    while (itr.hasNext())
                    {
                        if (!itr.next().equals(1))
                            totalDup++;
                    }
                    commMethods.verifyString(IZsumPage.DupliEntries.getText(), String.valueOf(totalDup));

                    // String duplivalue = IZsumPage.initialEntriesSum(dupliEntries);
                    // commMethods.verifyString(duplivalue, "PASS");
                } else if ("IZ_ID_003".equalsIgnoreCase(tc_Id))
                {
                    int i = 0;
                    int countRadiusCodes = 0;
                    while (i < zipList.size())
                    {
                        if (zipList.get(i).matches("...../[0-9]+"))
                        {
                            countRadiusCodes++;
                        }
                        i++;
                    }
                    commMethods.verifyString(IZsumPage.RadEntries.getText(), String.valueOf(countRadiusCodes));
                    // String radValue = IZsumPage.initialEntriesSum(radEntries);
                    // commMethods.verifyString(radValue, "PASS");
                } else if ("IZ_ID_004".equalsIgnoreCase(tc_Id))
                {
                    int i = 0;
                    int countRangeCodes = 0;
                    while (i < zipList.size())
                    {
                        if (zipList.get(i).matches(".....-....."))
                        {
                            countRangeCodes++;
                        }
                        i++;
                    }
                    commMethods.verifyString(IZsumPage.RangeEntries.getText(), String.valueOf(countRangeCodes));
                    // String rangeValue = IZsumPage.initialEntriesSum(rangeEntries);
                    // commMethods.verifyString(rangeValue, "PASS");
                } else if ("IZ_ID_006".equalsIgnoreCase(tc_Id) || "IZ_ID_007".equalsIgnoreCase(tc_Id) || "IZ_ID_008".equalsIgnoreCase(tc_Id))
                {
                    IZsumPage.clickSubmitBtn();
                    module.initializeDriver(driver);
                    status = module.getStatusIP();
                    commMethods.verifyString(StatusEnum.SUBMITTED.name(), status.trim());
                    ProjDashBoardPage.clickHomeTab();
                    String Status = ProjDashBoardPage.verifyProcess(fProName);
                    commMethods.verifyString(Status, "PASS");
                    ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
//                    driver.switchTo().frame("sb-player");
                    if ("IZ_ID_006".equalsIgnoreCase(tc_Id))
                        commMethods.verifyString(IZstatsPage.jobStatsHeader(), "ZIPCODE_EXPANDED_STATS");

                    if ("IZ_ID_008".equalsIgnoreCase(tc_Id))
                    {
                        commMethods.verifyInt(IZstatsPage.getStateNames().size(), IZstatsPage.getStateCounts().size());
                    }
                }
            }
        }
    }

    /*@AfterMethod
    public void tearDown()
    {
        driver.quit();
    }*/

    @DataProvider
    public Object[][] iz_Reg() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "InputZipFile", "Y");
        return (testObjArray_Y);
    }
}

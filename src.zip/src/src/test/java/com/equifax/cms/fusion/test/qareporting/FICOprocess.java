package com.equifax.cms.fusion.test.qareporting;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestContext;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import ru.yandex.qatools.allure.annotations.Step;
import ru.yandex.qatools.allure.annotations.Title;

import com.equifax.cms.fusion.test.FICOpages.CreateFICOreportsPage;
import com.equifax.cms.fusion.test.FICOpages.FICOstats;
import com.equifax.cms.fusion.test.FICOpages.FICOsummaryPage;
import com.equifax.cms.fusion.test.REPORTINGPages.ReportingHomePage;
import com.equifax.cms.fusion.test.modules.Modules;
import com.equifax.cms.fusion.test.modules.StatusEnum;
import com.equifax.cms.fusion.test.qapages.CommonMethods;
import com.equifax.cms.fusion.test.qapages.ExcelRead;
import com.equifax.cms.fusion.test.qapages.ProjectDashBoardPage;
import com.equifax.cms.fusion.test.utils.FusionChromeDriver;
import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class FICOprocess
{
    public WebDriver driver;
    private CommonMethods commMethods;
    private ProjectDashBoardPage ProjDashBoardPage;
    private ReportingHomePage reportHomePage;
    private CreateFICOreportsPage FICOreportPage;
    private FICOstats FICOStatsPage;
    private FICOsummaryPage FICOsumpage;
    private static final boolean IS_UNIX = "/".equals(File.separator);
    private static final Logger LOGGER = LoggerFactory.getLogger(FICOprocess.class);

    @Title("User Login with akp8 ")
    @Step("User Login")
    @BeforeMethod(description = "Login the applications and hit the Project Number and then navigated to Project Dashboard screen")
    public void loginandSearchProj() throws InterruptedException
    {
        // driver = FusionFirefoxDriver.getDriver();
        driver = FusionChromeDriver.getDriver();
        driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
        commMethods = PageFactory.initElements(driver, CommonMethods.class);
        ProjDashBoardPage = PageFactory.initElements(driver, ProjectDashBoardPage.class);
        reportHomePage = PageFactory.initElements(driver, ReportingHomePage.class);
        FICOreportPage = PageFactory.initElements(driver, CreateFICOreportsPage.class);
        FICOStatsPage = PageFactory.initElements(driver, FICOstats.class);
        FICOsumpage = PageFactory.initElements(driver, FICOsummaryPage.class);
        commMethods.userLogin();
        commMethods.searchProject();
    }

    @Test(dataProvider = "reg_FICO", description = "TS1: FICO process Stats Verification") //QA
    public void ficoProcessStats(String tc_Id, String testRun, String TC, String desc, String procName, String process, String jobNo,
            ITestContext testContext) throws InterruptedException
    {
        ProjDashBoardPage.clickHomeTab();

        Modules module = new Modules();
        module.initializeDriver(driver);
        testContext.setAttribute("WebDriver", driver);
        reportHomePage.clickReportingTab();
        reportHomePage.clickFICObtn();
        String fProName = commMethods.getFinalProcessName();
        FICOreportPage.processNameFld(procName);
        FICOreportPage.selectProcFld(process);
        Thread.sleep(2000);
        if ("FICO_ID_190".equalsIgnoreCase(tc_Id))
        {
            commMethods.verifyboolean(FICOreportPage.getJobNo().isEmpty(), false);
            // FICOreportPage.clickBackBtn();
            // String alert = driver.switchTo().alert().getText();
            // commMethods.verifyString(alert, "This page is asking you to confirm that you want to leave - data you have entered may not be saved.");
            // driver.switchTo().alert().accept();
        } else if ("FICO_ID_202".equalsIgnoreCase(tc_Id))
        {
            FICOreportPage.clickSaveBtn();
            reportHomePage.clickReportingTab();
            commMethods.verifyString(commMethods.getProcessStatus().trim(), StatusEnum.READY.name());
            module.selectDuplicate1();
            commMethods.verifyString(commMethods.getProcessStatus().trim(), StatusEnum.READY.name());
            module.selectEdit();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(), "Create FICO Reports Complete the Required Information, and click 'Submit'.");
//            commMethods.verifyString(FICOreportPage.getProcessSelected(), process);
            FICOreportPage.clickSubmitBtn();
            commMethods.verifyString(commMethods.getProcessStatus().trim(), StatusEnum.SUBMITTED.name());
            module.selectSummary();
            commMethods.verifyString(ProjDashBoardPage.getPageTitle(),
                    "Summary: FICO Report\nReview the information below,and then click 'Submit' or 'Back'.");
            // FICOsumpage.clickSubmitBtn();
            // commMethods.verifyString(commMethods.getProcessStatus().trim(), StatusEnum.SUBMITTED.name());
        } else if ("FICO_ID_180".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(3000);
            FICOreportPage.clickSubmitBtn();
            commMethods.verifyboolean(FICOreportPage.getErrorMessage().endsWith("do not exist."), true);
        } else if ("FICO_ID_160".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(2000);
            FICOreportPage.clickSubmitBtn();
            Thread.sleep(2000);
            ProjDashBoardPage.clickHomeTab();
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.clickTreeV2statsViewForChrome(fProName);
            // driver.switchTo().frame("sb-player");
            commMethods.verifyLong(FICOStatsPage.getFICOsampleCount(), 25L);
            commMethods.verifyString(FICOStatsPage.distributionRep(), "DISTRIBUTION_REPORT");
            commMethods.verifyboolean(FICOStatsPage.getOutputFilePath().endsWith("_FICO_GPEXPORT.csv"), true);
            // CH:
            /*
             * Thread.sleep(2000); ProjDashBoardPage.clickCloseBtnOnStats(); driver.switchTo().defaultContent();
             * ProjDashBoardPage.clickJobUpperLevel(fProName); ProjDashBoardPage.clickJobLowerLevel(fProName);
             * commMethods.verifyboolean(ProjDashBoardPage.is_WorkItem_Present("FICO_GPEXPORT"),true);
             */
        } else if ("FICO_ID_137".equalsIgnoreCase(tc_Id))
        {
            FICOreportPage.clickSubmitBtn();
            String errMsg = driver.findElement(By.xpath(".//*[@id='erMsg']")).getText();
            commMethods.verifyboolean(errMsg.startsWith("Error : The DM did not create any score models for"), true);
        } else if ("FICO_ID_183".equalsIgnoreCase(tc_Id))
        {
            FICOreportPage.clickSubmitBtn();
            reportHomePage.clickReportingTab();
            String OriginalID = reportHomePage.getProcessStatusByID(fProName);
            commMethods.verifyString(OriginalID, StatusEnum.SUBMITTED.name());
            module.selectDuplicate();
            module.selectEdit();
            String fProName1 = commMethods.getFinalProcessName();
            ProjDashBoardPage.clickReportingTab();
            String duplicateID = reportHomePage.getProcessStatusByID(fProName1);
            commMethods.verifyboolean(OriginalID.equalsIgnoreCase(duplicateID), false);
        } else if ("FICO_ID_218".equalsIgnoreCase(tc_Id))
        {
            Thread.sleep(5000);
            FICOreportPage.clickSubmitBtn();
            commMethods
                    .verifyString(
                            FICOreportPage.getErrorMessage1(),
                            "There are multiple tables associated with HEADER due to multiple Credit datasets selected in the associated Data Menu. The job number must be selected for the input.");
        }
    }

    @Test(dataProvider = "reg_FICO_CBA", priority = 1, description = "TS: FICO process Verification", enabled=false) //DEV
    public void ficoProcessCBA(String tc_Id, String testRun, String TC, String Description, String processName, String process, String jobNo,
            ITestContext testContext) throws InterruptedException
    {
        String status = null;
        Modules module = new Modules();
        module.initializeDriver(driver);
        testContext.setAttribute("WebDriver", driver);
        reportHomePage.clickReportingTab();
        reportHomePage.clickFICObtn();
        String fProName = commMethods.getFinalProcessName();
        String procId = commMethods.getProcId();
        FICOreportPage.processNameFld(processName);
        FICOreportPage.selectProcFld(process);
        FICOreportPage.submitFicoReport();
        Thread.sleep(2000);

        if ("FICO_ID_150".equalsIgnoreCase(TC))
        {
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(2000);
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.viewStats(fProName);
            Long currentFICOsmplCntUI = FICOStatsPage.getFICOsampleCount();
            commMethods.verifyLong(currentFICOsmplCntUI, 25L);
            ProjDashBoardPage.closeStatsWindow();
        }
        if ("FICO_ID_151".equalsIgnoreCase(TC))
        {
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(2000);
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.viewStats(fProName);
            String path = FICOStatsPage.getReportLocation();

            List<String> pdfFiles = new ArrayList<String>();
            File dir = new File(path);
            // validate pdf present in project folder
            for (File file : dir.listFiles())
            {
                boolean verify = false;
                if (file.getName().endsWith(".pdf"))
                {
                    verify = true;
                }
                commMethods.verifyboolean(true, verify);
            }
            ProjDashBoardPage.closeStatsWindow();
        }

        if ("FICO_ID_152".equalsIgnoreCase(TC) || "FICO_ID_153".equalsIgnoreCase(TC) || "FICO_ID_154".equalsIgnoreCase(TC)
                || "FICO_ID_155".equalsIgnoreCase(TC) || "FICO_ID_156".equalsIgnoreCase(TC) || "FICO_ID_157".equalsIgnoreCase(TC)
                || "FICO_ID_158".equalsIgnoreCase(TC) || "FICO_ID_159".equalsIgnoreCase(TC))
        {
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(2000);
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.viewStats(fProName);

            String path = FICOStatsPage.getReportLocation();
            List<String> pdfFiles = new ArrayList<String>();
            if (IS_UNIX)
            {
                LOGGER.info("goes to --->>" + path);
                int len = new File(path).listFiles().length;
                File file = new File(path);
                for (File f : file.listFiles())
                {
                    if (f.getName().contains(".xml"))
                    {
                        LOGGER.info("Test PASS");
                    }
                }

            } else
            {
                LOGGER.info("goes to --->>" + "C:" + path.replace("/", "\\"));
                String newPath = "C:" + path.replace("/", "\\");
                File file = new File(newPath);

                for (File f : file.listFiles())
                {
                    if (f.getName().contains(".xml"))
                    {
                        LOGGER.info(" Test PASS");
                    }
                }
            }
        }

        if ("FICO_ID_161".equalsIgnoreCase(TC))
        {
            // validate total audit records in counters
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(2000);
            String Status = ProjDashBoardPage.verifyProcess(fProName);
            commMethods.verifyString(Status, "PASS");
            ProjDashBoardPage.viewStats(fProName);

            FICOStatsPage.clickCounterslink();

            commMethods
                    .verifyboolean(true, FICOStatsPage.getCountersContent().contains("Total Audit Records CreditAudit(CreditAuditXML) RECORDS 25"));

        }
        if ("DB_ID_FI01".equalsIgnoreCase(TC))
        {
            ProjDashBoardPage.clickHomeTab();
            Thread.sleep(2000);
            String proName = ProjDashBoardPage.jobName();
            ProjDashBoardPage.openProcessGearBox(proName);
            ProjDashBoardPage.clickGearBoxCancel();
            ProjDashBoardPage.clickConfirmationOK();
            String finalStat = ProjDashBoardPage.verifyProcessCancelStatus(proName);
            commMethods.verifyString(finalStat, "CANCELLED");
            ProjDashBoardPage.openProcessGearBox(proName);
            boolean isRetryDisplayed = ProjDashBoardPage.isRetryOptionAvailable();
            commMethods.verifyboolean(true, isRetryDisplayed);
        }
    }

	@Test(dataProvider = "reg_FICO_Base", description = "TS1: FICO process Stats Verification") // BaseProcess																							// Process
	public void ficoBaseProcess(String tc_Id, String testRun, String TC, String desc, String procName, String process,
			String jobNo, ITestContext testContext) throws InterruptedException {
		String executionStatus = commMethods.getTheExecutionStatus(process);
		if (executionStatus.equalsIgnoreCase("COMPLETED")) {
			ProjDashBoardPage.clickHomeTab();
			Modules module = new Modules();
			module.initializeDriver(driver);
			testContext.setAttribute("WebDriver", driver);
			reportHomePage.clickReportingTab();
			reportHomePage.clickFICObtn();
			String fProName = commMethods.getFinalProcessName();
			FICOreportPage.processNameFld(procName);
			FICOreportPage.selectProcFld(process);
			Thread.sleep(2000);
			FICOreportPage.clickSubmitBtn();
		}
	}
    
    
    @AfterMethod
    public void closeBrowser()
    {
        driver.quit();
    }

    @DataProvider
    public Object[][] reg_FICO() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "FICOprocess", "Y");
        return testObjArray_Y;
    }

    @DataProvider
    public Object[][] reg_FICO_CBA() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "FICOprocess", "CBA");
        return testObjArray_Y;
    }
    
    @DataProvider
    public Object[][] reg_FICO_Base() throws Exception
    {
        Object[][] testObjArray_Y = ExcelRead.getTableArrayforSheet_Reg(System.getProperty("user.dir") + PropertiesUtils.getProperty("path"),
                "FICOprocess", "BAS");
        return testObjArray_Y;
    }

}

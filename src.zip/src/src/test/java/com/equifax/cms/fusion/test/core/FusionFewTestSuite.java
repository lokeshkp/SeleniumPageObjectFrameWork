package com.equifax.cms.fusion.test.core;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import com.equifax.cms.fusion.test.input.InputFixedPositiveTestCases;
@RunWith(Suite.class)
@Suite.SuiteClasses({
	InputFixedPositiveTestCases.class
})
public class FusionFewTestSuite {


}
package com.equifax.cms.fusion.test.modules;

import static org.junit.Assert.fail;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;

import ru.yandex.qatools.allure.annotations.Step;

import com.equifax.cms.fusion.test.utils.PropertiesUtils;

public class Modules
{
    private WebDriver driver;
    private final String baseUrl = "http://afnt1lc9a001.app.c9.equifax.com:9190/cms-fusion-web/login";

    public void initializeDriver(WebDriver dr)
    {
        driver = dr;
        driver.manage().timeouts().implicitlyWait(300, TimeUnit.SECONDS);
    }

    // User login
    public void userLogin()
    {
        driver.get(baseUrl + "/cms-fusion-web/login");
        driver.findElement(By.id("j_username")).clear();
        driver.findElement(By.id("j_username")).sendKeys(PropertiesUtils.getProperty("user"));
        System.out.println("Username : " + PropertiesUtils.getProperty("user"));
        driver.findElement(By.id("j_password")).clear();
        driver.findElement(By.id("j_password")).sendKeys(PropertiesUtils.getProperty("password"));
        System.out.println("Password : " + PropertiesUtils.getProperty("password"));
        driver.findElement(By.id("submitButton")).click();
    }

    @Step("Click Errors Warnings Tab")
    public void clickErrorwarningsTabOnStats()
    {
        driver.findElement(By.xpath("//a[contains(text(),'Errors/Warnings')]")).click();
    }

    // Search a project
    public void searchProject()
    {
        driver.findElement(By.id("cms_search")).click();
        driver.findElement(By.id("projectNumber")).clear();
        driver.findElement(By.id("projectNumber")).sendKeys(PropertiesUtils.getProperty("projectSearchStr"));
        driver.findElement(By.id("searchButton")).click();
        driver.findElement(By.linkText(PropertiesUtils.getProperty("projectNumber"))).click();
        System.out.println("Project Number : " + PropertiesUtils.getProperty("projectNumber"));

    }

    // Navigates to the process
    public void navigateToProcess(String processName)
    {
        driver.findElement(By.linkText(processName)).click();
    }

    // Navigates to new process
    public void navigateToNewProcessPage(String processName)
    {
        driver.findElement(By.linkText(processName)).click();

    }

    // Sets a timeout
    public void setTimeout(int time)
    {
        driver.manage().timeouts().setScriptTimeout(time, TimeUnit.SECONDS);
    }

    // Waits for ajax request to complete
    public void waitForAjax() throws InterruptedException
    {
        while (true)
        {
            Boolean ajaxIsComplete = (Boolean) ((JavascriptExecutor) driver).executeScript("return jQuery.active == 0");
            if (ajaxIsComplete)
            {
                break;
            }
            Thread.sleep(100);
        }
    }

    // Gets status
    public String getStatus()
    {
        String status = driver.findElement(By.xpath("//table[@id='DataTables_Table_0']/tbody/tr[1]/td[3]")).getText();
        return status;
    }

    // Gets status
    public String getStatusIP()
    {
        String status = driver.findElement(By.xpath("//*[@id='row0jqxgridJobListing']/div[4]/div")).getText();
        return status;
    }
    
    public String getSmStatus(){
    	String status = driver.findElement(By.xpath("(//div[contains(text(),'SUBMITTED')])[1]")).getText();
        return status;
    }

    // Selects Edit tab from context menu
    public void selectEdit() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 30)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        Thread.sleep(3500);
        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
        System.out.println("Hello");
    }

    // Selects duplicate tab from context menu and selects yes to duplicate
    public void selectDuplicate() throws InterruptedException
    {

        Thread.sleep(2000);
        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")))
                {
                	Thread.sleep(2000);
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Duplicate')]")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.id("jqxDuplicateWindow")))
                {
                	Thread.sleep(2000);
                    break;
                }
            } catch (Exception e)
            {
                System.out.println(e);
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        /*
         * driver.switchTo().frame("sb-player"); Thread.sleep(2000);
         */
        driver.findElement(By.xpath(".//*[@id='dup-row']")).click();
        try
        {
            Thread.sleep(2000);
        } catch (InterruptedException e)
        {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public void selectDuplicate1() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div[1]/div[1]/div/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//li[contains(text(),'Duplicate')]")).click();
        Thread.sleep(2000);
//        driver.switchTo().frame(0);
//        Thread.sleep(2000);
        driver.findElement(By.xpath(".//*[@id='dup-row']")).click();
        Thread.sleep(2000);
        driver.switchTo().defaultContent();
    }

    public void editSpecificProcess(String processId)
    {
        driver.findElement(
                By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div/div[2]/div[contains(text(),'" + processId + "')]/preceding::img[1]"))
                .click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
    }

    public void clickOnEdit() throws InterruptedException
    {
    	 driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();
        for (int second = 0;; second++)
        {
            if (second >= 20)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(2000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        Thread.sleep(3500);
        driver.findElement(By.xpath("//ul[@id='ContextItems']/li[contains(text(),'Edit')]")).click();
    }

    public void selectSpecificProcessSummary(String assignedId)
    {

        driver.findElement(
                By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div/div[2]/div[contains(text(),'" + assignedId + "')]/preceding::img[1]"))
                .click();

        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(10000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }

        driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
    }

    public void selectSummary() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing'][1]/div[1][@id='row0jqxgridJobListing']/div[1]/div/img")).click();

        for (int second = 0;; second++)
        {
            if (second >= 60)
            {
                fail("timeout");
            }
            try
            {
                if (isElementPresent(By.xpath("//li[contains(text(),'View Summary')]")))
                {
                    break;
                }
            } catch (Exception e)
            {
            }
            try
            {
                Thread.sleep(10000);
            } catch (InterruptedException e)
            {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        }
        Thread.sleep(3500);
        driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
    }

    public void selectSummary1() throws InterruptedException
    {
        driver.findElement(By.xpath("//div[@id='contenttablejqxgridJobListing']/div[1]/div[1]/div/img")).click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//li[contains(text(),'View Summary')]")).click();
    }

    public void selectSave()
    {
        driver.findElement(By.name("submitButton")).click();
    }

    public void selectSubmit()
    {
        driver.findElement(By.id("submitButton")).click();
    }

    public void navigateToHome()
    {
        driver.findElement(By.cssSelector("#home > a")).click();
    }

    public String getJobId()
    {
        String value = driver.findElement(By.cssSelector("td.main-table-border.id-style")).getText();
        String jobId = value.trim();
        return jobId;
    }

    public String acceptAndGetAlertText()
    {
        // WebDriverWait wait = new WebDriverWait(driver, 3);
        // wait.until(ExpectedConditions.alertIsPresent());

        String alertText = null;
        try
        {
            if (isAlertPresent())
            {
                alertText = closeAlertAndGetItsText();
            }

        } catch (Exception e)
        {
            e.printStackTrace();
        }

        return alertText;
    }

    private boolean isAlertPresent() throws InterruptedException
    {
        try
        {
            driver.switchTo().alert();
            return true;
        } catch (NoAlertPresentException e)
        {
            return false;
        }
    }

    private String closeAlertAndGetItsText()
    {
        boolean acceptNextAlert = true;

        try
        {
            Alert alert = driver.switchTo().alert();
            String alertText = alert.getText();
            if (acceptNextAlert)
            {
                alert.accept();
            } else
            {
                alert.dismiss();
            }
            return alertText;
        } finally
        {
            acceptNextAlert = true;
        }
    }

    public boolean isElementPresent(By by)
    {
        try
        {
            driver.findElement(by);
            System.out.println("try");
            return true;
        } catch (NoSuchElementException e)
        {
            return false;
        }
    }

    // Logout
    public void userLogout()
    {
        driver.findElement(By.linkText("Logout")).click();
    }
    /*
     * @After public void tearDown() throws Exception { driver.quit(); String verificationErrorString = verificationErrors.toString(); if
     * (!"".equals(verificationErrorString)) { fail(verificationErrorString); } }
     */

}
